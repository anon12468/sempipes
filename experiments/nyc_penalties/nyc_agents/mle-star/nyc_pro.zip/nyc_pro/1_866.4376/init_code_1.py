
import pandas as pd
import re
import os
from collections import defaultdict

# --- Configuration ---
# Determine if running in a sample data environment or the full dataset environment
IS_DEV = not os.path.exists("./input/X2.csv")

# Set up file paths based on the environment
INPUT_DIR = "./input/sample_data/" if IS_DEV else "./input/"
OUTPUT_DIR = "./working/"
X_PATH = os.path.join(INPUT_DIR, "X2.csv")
Z_PATH = os.path.join(INPUT_DIR, "Z2.csv")
OUTPUT_PATH = os.path.join(OUTPUT_DIR, "output.csv")

# Ensure the directory for output files exists
os.makedirs(OUTPUT_DIR, exist_ok=True)

# --- Constants ---
# Define the target number of candidate pairs to generate.
# Use a smaller number for development/sample data to speed up testing.
TARGET_PAIRS = 2_000_000 if not IS_DEV else 2500

# --- Preprocessing Functions ---
def normalize_text(text):
    """
    Standardizes text by converting to lowercase, removing punctuation,
    and collapsing extra whitespace.
    """
    if not isinstance(text, str):
        return ""
    text = text.lower()
    text = re.sub(r'[^a-z0-9\s]', ' ', text)  # Remove non-alphanumeric characters
    text = re.sub(r'\s+', ' ', text).strip()   # Replace multiple spaces with a single one
    return text

def get_first_token(text):
    """Extracts the first word (token) from a normalized string."""
    return text.split(' ')[0] if text else ''

# --- Blocking & Candidate Generation ---
def generate_candidates_with_sliding_window(df, candidate_pairs, key_column, sort_column, window_size):
    """
    Generates candidate pairs by blocking on a key and using a sliding window.
    This is the core function designed to avoid O(k^2) complexity in large blocks.
    It sorts the dataframe by the blocking key, then by a secondary sort key,
    and iterates through to find groups with the same key. Within each group (block),
    it applies a sliding window to generate a limited number of pairs.
    """
    if len(candidate_pairs) >= TARGET_PAIRS:
        return

    print(f"Blocking on '{key_column}' with window size {window_size}...")

    # Sort the entire dataframe first by the blocking key, then by the secondary sort column.
    # This efficiently groups all records with the same key together, and orders them
    # within the group to bring similar items near each other.
    df_sorted = df.sort_values([key_column, sort_column])
    records = df_sorted.to_dict('records')

    # Use two pointers, 'left' and 'right', to iterate through the sorted records
    # and identify the boundaries of each block (records with the same key).
    left = 0
    while left < len(records):
        right = left
        current_key = records[left][key_column]

        # Find the end of the current block
        while right + 1 < len(records) and records[right + 1][key_column] == current_key:
            right += 1

        # The block is from index `left` to `right`. Apply a sliding window.
        block_indices = range(left, right + 1)
        for i in block_indices:
            # For each item, pair it with the next 'window_size' items in the sorted block.
            for j in range(i + 1, min(i + 1 + window_size, right + 1)):
                id1 = records[i]['id']
                id2 = records[j]['id']

                # Normalize the pair so the smaller ID is always first, ensuring uniqueness.
                pair = tuple(sorted((int(id1), int(id2))))
                candidate_pairs.add(pair)

                # Stop generation immediately if the target is reached to save memory and time.
                if len(candidate_pairs) >= TARGET_PAIRS:
                    print(f"Target of {TARGET_PAIRS} pairs reached. Stopping generation.")
                    return

        # Move to the start of the next block.
        left = right + 1

# --- Evaluation Function ---
def evaluate(output_path, ground_truth_path):
    """Calculates and prints the recall score by comparing generated pairs to the ground truth."""
    try:
        z_df = pd.read_csv(ground_truth_path)
        ground_truth_pairs = {tuple(sorted((int(r['lid']), int(r['rid'])))) for _, r in z_df.iterrows()}

        if not ground_truth_pairs:
            print("Warning: Ground truth is empty.")
            return

        output_df = pd.read_csv(output_path)
        output_pairs = {tuple(sorted((int(r['left_instance_id']), int(r['right_instance_id'])))) for _, r in output_df.iterrows()}

        true_positives = len(ground_truth_pairs.intersection(output_pairs))
        recall = true_positives / len(ground_truth_pairs) if len(ground_truth_pairs) > 0 else 0.0

        print(f"Final Validation Performance: {recall}")

    except FileNotFoundError:
        print(f"Could not find file for evaluation: {ground_truth_path} or {output_path}")
    except Exception as e:
        print(f"An error occurred during evaluation: {e}")

# --- Main Execution ---
def main():
    """Main script logic orchestrating the blocking, pair generation, and evaluation."""
    print("Starting blocking process...")

    # 1. Load and Preprocess Data
    print(f"Loading data from {X_PATH}...")
    try:
        df = pd.read_csv(X_PATH, dtype={'id': str, 'price': str}) # Keep IDs as strings
    except Exception as e:
        print(f"Error loading data: {e}")
        return

    print("Preprocessing text data...")
    df['name_norm'] = df['name'].apply(normalize_text)
    df['brand_norm'] = df['brand'].apply(normalize_text).fillna('unknown')
    df['first_token_name'] = df['name_norm'].apply(get_first_token)
    df['category_norm'] = df['category'].apply(normalize_text).fillna('unknown')

    # 2. Generate Candidate Pairs using a Multi-Stage Strategy
    candidate_pairs = set()

    # Stage 1: High-precision blocking on 'brand'. Sorting by 'name' within the brand
    # brings similar products together. A moderate window size is effective here.
    generate_candidates_with_sliding_window(df, candidate_pairs, 'brand_norm', 'name_norm', window_size=5)

    # Stage 2: Broader blocking on the first token of the product name.
    # This catches matches where brand is missing or differs. A smaller window is used
    # as these blocks can be larger and less precise.
    if len(candidate_pairs) < TARGET_PAIRS:
       generate_candidates_with_sliding_window(df, candidate_pairs, 'first_token_name', 'name_norm', window_size=2)

    # Stage 3: A very broad fallback on 'category' if more pairs are needed.
    # A tiny window is used because these blocks are typically very large and noisy.
    if len(candidate_pairs) < TARGET_PAIRS:
        generate_candidates_with_sliding_window(df, candidate_pairs, 'category_norm', 'name_norm', window_size=1)

    print(f"Generated {len(candidate_pairs)} unique candidate pairs.")

    # 3. Format and Save Output
    output_list = list(candidate_pairs)

    # Truncate the list if we generated more pairs than the target.
    if len(output_list) > TARGET_PAIRS:
        print(f"Truncating pairs from {len(output_list)} to {TARGET_PAIRS}.")
        output_list = output_list[:TARGET_PAIRS]
    elif len(output_list) < TARGET_PAIRS and not IS_DEV:
         print(f"Warning: Generated {len(output_list)} pairs, which is less than the target {TARGET_PAIRS}.")

    print(f"Saving {len(output_list)} pairs to {OUTPUT_PATH}...")
    output_df = pd.DataFrame(output_list, columns=['left_instance_id', 'right_instance_id'])
    output_df.to_csv(OUTPUT_PATH, index=False)

    print("Blocking process complete.")

    # 4. Evaluate Performance against Ground Truth
    print("Starting evaluation...")
    evaluate(OUTPUT_PATH, Z_PATH)


if __name__ == "__main__":
    main()
