
import pandas as pd
import numpy as np
import argparse
import os
import sys
from sklearn.feature_extraction import FeatureHasher
from sklearn.linear_model import SGDRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import StandardScaler
from scipy.sparse import hstack

def clean_col_names(df):
    """Standardizes column names to lowercase with underscores."""
    cols = df.columns
    new_cols = [c.lower().replace(' ', '_') for c in cols]
    df.columns = new_cols
    return df

def feature_engineer(df, street_meta_df, violation_meta_df):
    """Merges the main dataframe with augmentation data."""
    df_fe = df.copy()
    if not street_meta_df.empty:
        df_fe = pd.merge(df_fe, street_meta_df, on='street_name', how='left')
    if not violation_meta_df.empty:
        df_fe = pd.merge(df_fe, violation_meta_df, on='violation_description', how='left')
    return df_fe

def main(args):
    """Main function for training, validation, and creating a submission file."""
    print("--- 1. Loading and Initial Preprocessing ---")
    
    # Load core training data
    try:
        main_df = pd.read_csv(args.train_path)
    except FileNotFoundError:
        print(f"Error: Training file not found at {args.train_path}", file=sys.stderr)
        return
        
    main_df = clean_col_names(main_df)

    # Load augmentation data
    street_meta_path = os.path.join(args.input_dir, 'street_metadata.csv')
    violation_meta_path = os.path.join(args.input_dir, 'violation_type_metadata.csv')
    
    street_meta = pd.read_csv(street_meta_path) if os.path.exists(street_meta_path) else pd.DataFrame()
    violation_meta = pd.read_csv(violation_meta_path) if os.path.exists(violation_meta_path) else pd.DataFrame()

    if not street_meta.empty:
        street_meta = clean_col_names(street_meta)
    if not violation_meta.empty:
        violation_meta = clean_col_names(violation_meta)

    print("--- 2. Feature Engineering on Full Training Data ---")
    df_train = feature_engineer(main_df, street_meta, violation_meta)
    
    # Define feature sets
    cat_cols = ['street_name', 'violation_description', 'boro', 'manhattan_96th_st_below']
    num_cols = ['st_length_m', 'st_width_m']
    target_col = 'violation_count'
    
    # Filter for columns that actually exist after merging
    cat_cols = [col for col in cat_cols if col in df_train.columns]
    num_cols = [col for col in num_cols if col in df_train.columns]
    
    print(f"Using categorical features: {cat_cols}")
    print(f"Using numerical features: {num_cols}")

    # --- 3. Development Validation on 2022 Data ---
    print("\n--- 3. Running Development Validation ---")
    train_sub, val_sub = train_test_split(df_train, test_size=0.2, random_state=42)

    # Preprocess training subset
    y_train_sub_log = np.log1p(train_sub[target_col].values)
    val_sub_medians = pd.Series(dtype='float64')
    if num_cols:
        val_sub_medians = train_sub[num_cols].median()
        train_sub_num = train_sub[num_cols].fillna(val_sub_medians)
    for col in cat_cols:
        train_sub.loc[:, col] = train_sub[col].astype(str).fillna('<NA>')

    val_scaler = StandardScaler()
    X_train_sub_num_scaled = None
    if num_cols:
        X_train_sub_num_scaled = val_scaler.fit_transform(train_sub_num)
    
    X_train_sub_cat_dicts = train_sub[cat_cols].to_dict('records')

    # Train validation models
    val_hasher_1 = FeatureHasher(n_features=2**18, input_type='dict', dtype=np.float32)
    X_train_sub_hashed_1 = val_hasher_1.transform(X_train_sub_cat_dicts)
    X_train_sub_final_1 = hstack([X_train_sub_hashed_1, X_train_sub_num_scaled]) if X_train_sub_num_scaled is not None else X_train_sub_hashed_1
    val_model_1 = SGDRegressor(max_iter=1000, tol=1e-3, random_state=42, early_stopping=True, validation_fraction=0.1)
    val_model_1.fit(X_train_sub_final_1, y_train_sub_log)

    train_sub_preds_log_1 = val_model_1.predict(X_train_sub_final_1)
    val_residuals = y_train_sub_log - train_sub_preds_log_1
    
    val_hasher_2 = FeatureHasher(n_features=2**14, input_type='dict', dtype=np.float32)
    X_train_sub_hashed_2 = val_hasher_2.transform(X_train_sub_cat_dicts)
    X_train_sub_final_2 = hstack([X_train_sub_hashed_2, X_train_sub_num_scaled]) if X_train_sub_num_scaled is not None else X_train_sub_hashed_2
    val_model_2 = SGDRegressor(max_iter=1000, tol=1e-3, random_state=42, early_stopping=True, validation_fraction=0.1, penalty='elasticnet')
    val_model_2.fit(X_train_sub_final_2, val_residuals)

    # Evaluate on validation subset
    val_sub_num = val_sub[num_cols].fillna(val_sub_medians) if num_cols else None
    for col in cat_cols:
        val_sub.loc[:, col] = val_sub[col].astype(str).fillna('<NA>')
    X_val_sub_num_scaled = val_scaler.transform(val_sub_num) if num_cols else None
    X_val_sub_cat_dicts = val_sub[cat_cols].to_dict('records')
    
    X_val_sub_hashed_1 = val_hasher_1.transform(X_val_sub_cat_dicts)
    X_val_sub_final_1 = hstack([X_val_sub_hashed_1, X_val_sub_num_scaled]) if X_val_sub_num_scaled is not None else X_val_sub_hashed_1
    X_val_sub_hashed_2 = val_hasher_2.transform(X_val_sub_cat_dicts)
    X_val_sub_final_2 = hstack([X_val_sub_hashed_2, X_val_sub_num_scaled]) if X_val_sub_num_scaled is not None else X_val_sub_hashed_2

    val_preds_log_1 = val_model_1.predict(X_val_sub_final_1)
    val_preds_residual = val_model_2.predict(X_val_sub_final_2)
    final_val_log_preds = val_preds_log_1 + val_preds_residual
    val_preds = np.expm1(final_val_log_preds)
    val_preds[val_preds < 0] = 0

    validation_rmse = np.sqrt(mean_squared_error(val_sub[target_col], val_preds))
    print(f"Final Validation Performance: {validation_rmse:.4f}")

    # Create vocabularies from training data to identify unseen keys later
    train_vocabs = {col: set(df_train[col].dropna().unique()) for col in ['street_name', 'violation_description']}

    print("\n--- 4. Preprocessing and Training on Full 2022 Data ---")
    y_train_log = np.log1p(df_train[target_col].values)

    num_medians = pd.Series(dtype='float64')
    if num_cols:
        num_medians = df_train[num_cols].median()
        df_train[num_cols] = df_train[num_cols].fillna(num_medians)

    for col in cat_cols:
        df_train[col] = df_train[col].astype(str).fillna('<NA>')

    scaler = StandardScaler()
    X_train_num = None
    if num_cols:
        X_train_num = scaler.fit_transform(df_train[num_cols])

    X_train_cat_dicts = df_train[cat_cols].to_dict('records')

    # --- 4a. STAGE 1: Train Primary "Global" Model ---
    print("--- 4a. Training Stage 1: Primary Global Model on Full Data---")
    hasher_1 = FeatureHasher(n_features=2**18, input_type='dict', dtype=np.float32)
    X_train_hashed_1 = hasher_1.transform(X_train_cat_dicts)
    X_train_final_1 = hstack([X_train_hashed_1, X_train_num]) if X_train_num is not None else X_train_hashed_1
    model_1 = SGDRegressor(max_iter=1000, tol=1e-3, random_state=42, early_stopping=True, validation_fraction=0.1)
    model_1.fit(X_train_final_1, y_train_log)

    # --- 4b. STAGE 2: Train "Residual" Model ---
    print("--- 4b. Training Stage 2: Residual Model on Full Data ---")
    train_preds_log_1 = model_1.predict(X_train_final_1)
    residuals = y_train_log - train_preds_log_1
    hasher_2 = FeatureHasher(n_features=2**14, input_type='dict', dtype=np.float32)
    X_train_hashed_2 = hasher_2.transform(X_train_cat_dicts)
    X_train_final_2 = hstack([X_train_hashed_2, X_train_num]) if X_train_num is not None else X_train_hashed_2
    model_2 = SGDRegressor(max_iter=1000, tol=1e-3, random_state=42, early_stopping=True, validation_fraction=0.1, penalty='elasticnet')
    model_2.fit(X_train_final_2, residuals)

    # --- 5. Inference on Test Set (if provided) ---
    if args.test_path and os.path.exists(args.test_path):
        print(f"\n--- 5. Running inference on {args.test_path} ---")
        test_df = pd.read_csv(args.test_path)
        test_df = clean_col_names(test_df)
        submission_keys = test_df[['street_name', 'violation_description']].copy()
        
        test_df_fe = feature_engineer(test_df, street_meta, violation_meta)
        
        unseen_streets = ~test_df_fe['street_name'].isin(train_vocabs['street_name'])
        unseen_violations = ~test_df_fe['violation_description'].isin(train_vocabs['violation_description'])
        num_unseen = (unseen_streets | unseen_violations).sum()
        print(f"Number of test rows with unseen 'street_name' or 'violation_description': {num_unseen}")

        X_test_num = None
        if num_cols:
            test_df_fe[num_cols] = test_df_fe[num_cols].fillna(num_medians)
            X_test_num = scaler.transform(test_df_fe[num_cols])
            
        for col in cat_cols:
            test_df_fe[col] = test_df_fe[col].astype(str).fillna('<NA>')
        
        X_test_cat_dicts = test_df_fe[cat_cols].to_dict('records')
        
        X_test_hashed_1 = hasher_1.transform(X_test_cat_dicts)
        X_test_final_1 = hstack([X_test_hashed_1, X_test_num]) if X_test_num is not None else X_test_hashed_1

        X_test_hashed_2 = hasher_2.transform(X_test_cat_dicts)
        X_test_final_2 = hstack([X_test_hashed_2, X_test_num]) if X_test_num is not None else X_test_hashed_2

        test_preds_log_1 = model_1.predict(X_test_final_1)
        test_preds_residual = model_2.predict(X_test_final_2)
        final_test_log_preds = test_preds_log_1 + test_preds_residual
        
        test_preds = np.expm1(final_test_log_preds)
        test_preds[test_preds < 0] = 0

        submission_df = submission_keys
        submission_df['predicted_count'] = test_preds
        submission_df.columns = ['street_name', 'violation_type', 'predicted_count']
        
        os.makedirs('./final', exist_ok=True)
        submission_path = './final/submission.csv'
        submission_df.to_csv(submission_path, index=False)
        print(f"Generated submission file at {submission_path}")

        if target_col in test_df_fe.columns:
            test_rmse = np.sqrt(mean_squared_error(test_df_fe[target_col], test_preds))
            print(f"RMSE on provided test file: {test_rmse:.4f}")
    else:
        print("\n--- 5. No valid test path provided or file not found. Skipping inference. ---")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description="NYC Parking Violation Prediction using a Two-Stage Residual Fitting Ensemble.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    
    input_dir = '/Users/USER/Documents/UNI/SS26/nyc_open_data/train/all_data/'
    
    test_path_with_count = os.path.join("/Users/USER/Documents/UNI/SS26/nyc_open_data/violations_per_street_2023.csv")
    test_path_keys_only = os.path.join("/Users/USER/Documents/UNI/SS26/nyc_open_data/violations_per_street_2023.csv")
    
    default_test_path = None
    if os.path.exists(test_path_with_count):
        default_test_path = test_path_with_count
    elif os.path.exists(test_path_keys_only):
        default_test_path = test_path_keys_only

    parser.add_argument('--train-path', type=str, 
                        default=os.path.join(input_dir, 'violations_per_street_2022.csv'))
    parser.add_argument('--test-path', type=str, default=default_test_path)
    parser.add_argument('--input-dir', type=str, default=input_dir)

    args = parser.parse_args(args=[])
    
    print("Running with the following paths:")
    print(f"  Train: {args.train_path}")
    print(f"  Test:  {args.test_path}")
    print(f"  Input: {args.input_dir}")
    
    main(args)
