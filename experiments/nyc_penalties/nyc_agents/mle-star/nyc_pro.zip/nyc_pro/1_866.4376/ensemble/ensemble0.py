
import pandas as pd
import numpy as np
import argparse
import os
import sys
from sklearn.feature_extraction import FeatureHasher
from sklearn.linear_model import SGDRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import StandardScaler
from scipy.sparse import hstack

def clean_col_names(df):
    """Standardizes column names to lowercase with underscores."""
    cols = df.columns
    new_cols = [c.lower().replace(' ', '_') for c in cols]
    df.columns = new_cols
    return df

def feature_engineer(df, street_meta_df, violation_meta_df):
    """Merges the main dataframe with augmentation data."""
    df_fe = df.copy()
    if not street_meta_df.empty:
        df_fe = pd.merge(df_fe, street_meta_df, on='street_name', how='left')
    if not violation_meta_df.empty:
        df_fe = pd.merge(df_fe, violation_meta_df, on='violation_description', how='left')
    return df_fe

def main(args):
    """Main function for training, validation, and prediction."""
    print("--- 1. Loading and Initial Preprocessing ---")
    
    # Load core training data
    try:
        main_df = pd.read_csv(args.train_path)
    except FileNotFoundError:
        print(f"Error: Training file not found at {args.train_path}")
        return
    main_df = clean_col_names(main_df)

    # Load augmentation data
    street_meta_path = os.path.join(args.input_dir, 'street_metadata.csv')
    violation_meta_path = os.path.join(args.input_dir, 'violation_type_metadata.csv')
    
    street_meta = pd.read_csv(street_meta_path) if os.path.exists(street_meta_path) else pd.DataFrame()
    violation_meta = pd.read_csv(violation_meta_path) if os.path.exists(violation_meta_path) else pd.DataFrame()

    if not street_meta.empty:
        street_meta = clean_col_names(street_meta)
    if not violation_meta.empty:
        violation_meta = clean_col_names(violation_meta)

    print("--- 2. Feature Engineering ---")
    main_df_fe = feature_engineer(main_df, street_meta, violation_meta)
    
    # Define feature sets
    cat_cols = ['street_name', 'violation_description', 'boro', 'manhattan_96th_st_below']
    num_cols = ['st_length_m', 'st_width_m']
    target_col = 'violation_count'
    
    # Filter for columns that actually exist after merging
    cat_cols = [col for col in cat_cols if col in main_df_fe.columns]
    num_cols = [col for col in num_cols if col in main_df_fe.columns]
    
    print(f"Using categorical features: {cat_cols}")
    print(f"Using numerical features: {num_cols}")

    # Create vocabularies from training data to identify unseen keys later
    train_vocabs = {col: set(main_df_fe[col].dropna().unique()) for col in ['street_name', 'violation_description']}

    print("--- 3. Data Splitting and Preprocessing ---")
    # Split the data into training and validation sets
    df_train, df_val = train_test_split(main_df_fe, test_size=0.2, random_state=42)
    
    # Store true validation target and apply LOG TRANSFORMATION to training target
    y_train = np.log1p(df_train[target_col].values)
    y_val_true = df_val[target_col].values

    # Impute missing numerical values using the median from the training set
    num_medians = pd.Series(dtype='float64')
    if num_cols:
        num_medians = df_train[num_cols].median()
        df_train[num_cols] = df_train[num_cols].fillna(num_medians)
        df_val[num_cols] = df_val[num_cols].fillna(num_medians)

    # Impute missing categorical values with a placeholder
    for col in cat_cols:
        df_train[col] = df_train[col].astype(str).fillna('<NA>')
        df_val[col] = df_val[col].astype(str).fillna('<NA>')

    # Scale numerical features
    scaler = StandardScaler()
    X_train_num, X_val_num = None, None
    if num_cols:
        X_train_num = scaler.fit_transform(df_train[num_cols])
        X_val_num = scaler.transform(df_val[num_cols])

    # Convert categorical features to the format required by FeatureHasher (list of dicts)
    X_train_cat_dicts = df_train[cat_cols].to_dict('records')
    X_val_cat_dicts = df_val[cat_cols].to_dict('records')

    print("--- 4. Feature Hashing and ENSEMBLE Model Training ---")

    # --- Model 1 and 3 Feature Preparation (n_features=2**16) ---
    print("Hashing features for Model 1 & 3 (n_features=2**16)...")
    hasher1 = FeatureHasher(n_features=2**16, input_type='dict', dtype=np.float32)
    X_train_hashed1 = hasher1.transform(X_train_cat_dicts)
    X_val_hashed1 = hasher1.transform(X_val_cat_dicts)
    X_train_final1 = hstack([X_train_hashed1, X_train_num]) if X_train_num is not None else X_train_hashed1
    X_val_final1 = hstack([X_val_hashed1, X_val_num]) if X_val_num is not None else X_val_hashed1

    # --- Model 2 Feature Preparation (n_features=2**18) ---
    print("Hashing features for Model 2 (n_features=2**18)...")
    hasher2 = FeatureHasher(n_features=2**18, input_type='dict', dtype=np.float32)
    X_train_hashed2 = hasher2.transform(X_train_cat_dicts)
    X_val_hashed2 = hasher2.transform(X_val_cat_dicts)
    X_train_final2 = hstack([X_train_hashed2, X_train_num]) if X_train_num is not None else X_train_hashed2
    X_val_final2 = hstack([X_val_hashed2, X_val_num]) if X_val_num is not None else X_val_hashed2

    # --- Training Models ---
    # Model 1 (Baseline: n_features=2**16, l2 penalty)
    print("Training Model 1 (Baseline)...")
    model1 = SGDRegressor(max_iter=1000, tol=1e-3, random_state=42, early_stopping=True, validation_fraction=0.1)
    model1.fit(X_train_final1, y_train)

    # Model 2 (Larger Feature Space: n_features=2**18, l2 penalty)
    print("Training Model 2 (Larger Feature Space)...")
    model2 = SGDRegressor(max_iter=1000, tol=1e-3, random_state=42, early_stopping=True, validation_fraction=0.1)
    model2.fit(X_train_final2, y_train)

    # Model 3 (Alternative Regularization: n_features=2**16, elasticnet penalty)
    print("Training Model 3 (ElasticNet Regularization)...")
    model3 = SGDRegressor(max_iter=1000, tol=1e-3, random_state=42, early_stopping=True, validation_fraction=0.1, penalty='elasticnet')
    model3.fit(X_train_final1, y_train)

    print("--- 5. Validation Performance ---")
    # Predict on the validation set with each model
    val_preds_log1 = model1.predict(X_val_final1)
    val_preds_log2 = model2.predict(X_val_final2)
    val_preds_log3 = model3.predict(X_val_final1)
    
    # Average the log-predictions
    val_preds_log_avg = (val_preds_log1 + val_preds_log2 + val_preds_log3) / 3.0
    
    # Reverse the log transformation
    val_preds = np.expm1(val_preds_log_avg)
    
    # Clip predictions to be non-negative
    val_preds[val_preds < 0] = 0
    
    # Calculate and report RMSE
    validation_rmse = np.sqrt(mean_squared_error(y_val_true, val_preds))
    print(f"Final Validation Performance: {validation_rmse:.4f}")

    # --- 6. Inference on Test Set (if provided) ---
    if args.test_path:
        print(f"\n--- Running inference on {args.test_path} ---")
        try:
            test_df = pd.read_csv(args.test_path)
        except FileNotFoundError:
            print(f"Error: Test file not found at {args.test_path}")
            return
            
        test_df = clean_col_names(test_df)
        submission_keys = test_df[['street_name', 'violation_description']].copy()
        
        # Apply the same feature engineering
        test_df_fe = feature_engineer(test_df, street_meta, violation_meta)
        
        # Report on unseen keys
        unseen_streets = ~test_df_fe['street_name'].isin(train_vocabs['street_name'])
        unseen_violations = ~test_df_fe['violation_description'].isin(train_vocabs['violation_description'])
        num_unseen = (unseen_streets | unseen_violations).sum()
        print(f"Number of test rows with unseen 'street_name' or 'violation_description': {num_unseen}")
        print("Handling for unseen keys: Feature Hashing naturally maps new values to the feature space.")

        # Preprocess test data using transformers fitted on training data
        if num_cols:
            test_df_fe[num_cols] = test_df_fe[num_cols].fillna(num_medians)
            X_test_num = scaler.transform(test_df_fe[num_cols])
        else:
            X_test_num = None
            
        for col in cat_cols:
            test_df_fe[col] = test_df_fe[col].astype(str).fillna('<NA>')
        
        X_test_cat_dicts = test_df_fe[cat_cols].to_dict('records')
        
        # Hash test features for both hasher settings
        X_test_hashed1 = hasher1.transform(X_test_cat_dicts)
        X_test_hashed2 = hasher2.transform(X_test_cat_dicts)

        # Combine features for both settings
        X_test_final1 = hstack([X_test_hashed1, X_test_num]) if X_test_num is not None else X_test_hashed1
        X_test_final2 = hstack([X_test_hashed2, X_test_num]) if X_test_num is not None else X_test_hashed2

        # Predict with all models
        test_preds_log1 = model1.predict(X_test_final1)
        test_preds_log2 = model2.predict(X_test_final2)
        test_preds_log3 = model3.predict(X_test_final1)
        
        # Average the predictions
        test_preds_log_avg = (test_preds_log1 + test_preds_log2 + test_preds_log3) / 3.0
        
        # Inverse transform and clip
        test_preds = np.expm1(test_preds_log_avg)
        test_preds[test_preds < 0] = 0

        # Create submission file
        submission_df = submission_keys
        submission_df['predicted_count'] = test_preds
        submission_df.columns = ['street_name', 'violation_type', 'predicted_count']
        submission_df.to_csv('submission.csv', index=False)
        print("Generated submission.csv")

        # Report test RMSE if ground truth is available
        if target_col in test_df_fe.columns:
            test_rmse = np.sqrt(mean_squared_error(test_df_fe[target_col], test_preds))
            print(f"RMSE on provided test file: {test_rmse:.4f}")

if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description="NYC Parking Violation Prediction using an Ensemble of Linear Models with Feature Hashing.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    
    input_dir = './input' if os.path.exists('./input') else '.'

    parser.add_argument('--train-path', type=str, 
                        default=os.path.join(input_dir, 'violations_per_street_2022.csv'),
                        help="Path to the training data CSV file.")
    parser.add_argument('--test-path', type=str, default=None,
                        help="Optional: Path to the test data file for prediction.")
    parser.add_argument('--input-dir', type=str, default=input_dir,
                        help="Directory containing augmentation data files.")

    # Check if running in an interactive environment or with specific args
    if len(sys.argv) <= 1:
        print("No CLI arguments provided. Running with default paths.")
        # Attempt to find a default test file for a demonstration run
        test_path_default = os.path.join(input_dir, 'violations_per_street_2023_with_count.csv')
        if not os.path.exists(test_path_default):
             test_path_default = os.path.join(input_dir, 'violations_per_street_2023_keys_only.csv')
             if not os.path.exists(test_path_default):
                 test_path_default = None
                 print("Default test file not found, will only run training and validation.")
        
        args = parser.parse_args(args=[])
        args.test_path = test_path_default # Manually set test path for default run
    else:
        args = parser.parse_args()
    
    main(args)
