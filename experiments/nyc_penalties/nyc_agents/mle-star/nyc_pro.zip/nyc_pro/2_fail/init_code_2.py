
import argparse
import pandas as pd
import numpy as np
import os
from sklearn.model_selection import GroupShuffleSplit
from sklearn.metrics import mean_squared_error
import catboost as cb

def load_data(file_path):
    """
    Loads data from a CSV file and standardizes column names.
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Error: File not found at {file_path}")

    df = pd.read_csv(file_path, low_memory=False)
    
    # Standardize column names
    df.rename(columns={
        'Street Name': 'street_name',
        'Violation Description': 'violation_type',
        'violation_count': 'violation_count'
    }, inplace=True)

    # Ensure key columns are treated as strings
    df['street_name'] = df['street_name'].astype(str)
    df['violation_type'] = df['violation_type'].astype(str)

    return df

def feature_engineer(df, bikelane_streets_set):
    """
    Engineers features for the model.
    """
    # Make a copy to avoid modifying the original DataFrame
    df_featured = df.copy()

    # Feature 1: Check for bike lanes
    df_featured['has_bikelane'] = df_featured['street_name'].isin(bikelane_streets_set).astype(int)

    # Feature 2 & 3: Length of categorical feature strings
    df_featured['street_name_len'] = df_featured['street_name'].str.len()
    df_featured['violation_type_len'] = df_featured['violation_type'].str.len()
    
    return df_featured

def main():
    """
    Main function to run the training and prediction pipeline.
    """
    parser = argparse.ArgumentParser(description="Predict NYC parking violations using CatBoost.")
    parser.add_argument('--train-path', 
                        type=str, 
                        default='./input/violations_per_street_2022.csv',
                        help='Path to the training data CSV file.')
    parser.add_argument('--test-path', 
                        type=str, 
                        default=None,
                        help='Path to the test data CSV file (optional).')
    
    # In a notebook environment, argparse might not work as expected.
    # We'll manually set the args for compatibility.
    try:
        args = parser.parse_args()
    except SystemExit:
        # This will happen in environments like Jupyter or Kaggle kernels
        args = parser.parse_args(args=[])


    train_path = args.train_path
    test_path = args.test_path

    # --- Data Loading and Preparation ---
    print("Loading training data...")
    train_df = load_data(train_path)

    print("Loading augmentation data...")
    bikelane_path = './input/street_with_bikelanes.csv'
    if os.path.exists(bikelane_path):
        bikelane_df = pd.read_csv(bikelane_path)
        bikelane_streets_set = set(bikelane_df['street'].astype(str))
    else:
        print("Warning: Bike lane data not found. 'has_bikelane' feature will be all zeros.")
        bikelane_streets_set = set()

    # --- Feature Engineering ---
    print("Engineering features for training data...")
    train_featured = feature_engineer(train_df, bikelane_streets_set)

    # Log transform the target variable to handle skewness
    train_featured['violation_count_log'] = np.log1p(train_featured['violation_count'])

    # --- Validation Split ---
    print("Splitting data into training and validation sets...")
    # Group by street_name to ensure all violations for a street are in the same set
    splitter = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=42)
    train_indices, val_indices = next(splitter.split(train_featured, groups=train_featured['street_name']))

    dev_train = train_featured.iloc[train_indices]
    dev_val = train_featured.iloc[val_indices]

    # --- Model Training ---
    features = ['street_name', 'violation_type', 'has_bikelane', 'street_name_len', 'violation_type_len']
    categorical_features = ['street_name', 'violation_type']
    
    X_train = dev_train[features]
    y_train = dev_train['violation_count_log']
    
    X_val = dev_val[features]
    y_val = dev_val['violation_count_log']

    print("Training CatBoost model...")
    model = cb.CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=10,
        eval_metric='RMSE',
        random_seed=42,
        verbose=0,
        cat_features=categorical_features,
        allow_writing_files=False
    )

    model.fit(
        X_train, y_train,
        eval_set=(X_val, y_val),
        early_stopping_rounds=50,
        verbose=False
    )

    # --- Validation ---
    print("Evaluating model on the validation set...")
    val_preds_log = model.predict(X_val)
    
    # Inverse transform predictions and clip at zero
    val_preds = np.expm1(val_preds_log)
    val_preds[val_preds < 0] = 0
    
    # Get original scale of validation target for scoring
    y_val_orig = np.expm1(y_val)
    
    final_validation_score = np.sqrt(mean_squared_error(y_val_orig, val_preds))
    print(f"Validation RMSE (2022 holdout): {final_validation_score:.4f}")
    print(f"Final Validation Performance: {final_validation_score}")

    # --- Inference on Test Set (if provided) ---
    if test_path:
        print("\n--- Generating predictions for the test file ---")
        
        print(f"Loading test data from {test_path}...")
        test_df = load_data(test_path)
        
        # Keep original columns for submission file
        submission_df = test_df[['street_name', 'violation_type']].copy()
        
        # Check for unseen keys
        train_keys = set(zip(train_df['street_name'], train_df['violation_type']))
        test_keys = set(zip(test_df['street_name'], test_df['violation_type']))
        unseen_keys_count = len(test_keys - train_keys)
        print(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_keys_count}")
        print("These will be handled by CatBoost's internal categorical feature handling.")

        print("Engineering features for test data...")
        test_featured = feature_engineer(test_df, bikelane_streets_set)
        X_test = test_featured[features]

        print("Predicting on the test set...")
        test_preds_log = model.predict(X_test)
        
        # Inverse transform, clip, and round
        test_preds = np.expm1(test_preds_log)
        test_preds[test_preds < 0] = 0
        submission_df['predicted_count'] = np.round(test_preds).astype(int)

        output_path = 'submission.csv'
        submission_df.to_csv(output_path, index=False)
        print(f"Predictions saved to {output_path}")

        # If ground truth is available in the test file, score it
        if 'violation_count' in test_df.columns:
            test_rmse = np.sqrt(mean_squared_error(test_df['violation_count'], test_preds))
            print(f"\nTest set RMSE (ground truth provided): {test_rmse:.4f}")

if __name__ == '__main__':
    main()
