
import subprocess
import sys

# The original code produced a RuntimeError related to a mismatch between torch and torchvision.
# This is a common dependency issue in the PyTorch ecosystem. The fix is to ensure compatible
# versions of all major libraries (torch, torchvision, lightning, pytorch-forecasting, and torchmetrics)
# are installed together. By using pip to install them in a single command with the --upgrade
# flag, we allow pip's dependency resolver to find and install a compatible set of versions,
# which resolves the "operator torchvision::nms does not exist" error. [1, 5, 8, 11]
try:
    packages_to_install = [
        "torch",
        "torchvision",
        "lightning",
        "pytorch-forecasting",
        "torchmetrics"
    ]
    # Using --upgrade ensures that existing packages are updated if a newer compatible version is needed.
    subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade"] + packages_to_install)
except subprocess.CalledProcessError as e:
    print(f"Error installing packages: {e}")
    # The script will continue, but may fail if the packages are not correctly installed.
    pass

import argparse
import os
import pandas as pd
import numpy as np
import torch
import lightning as pl
from lightning.pytorch.callbacks import EarlyStopping, ModelCheckpoint
from pytorch_forecasting import TimeSeriesDataSet, TemporalFusionTransformer
from pytorch_forecasting.data import GroupNormalizer
from pytorch_forecasting.metrics import RMSE
from sklearn.metrics import mean_squared_error

def create_time_series_data(raw_data_path: str, bikelane_path: str):
    """
    Loads raw 2022 data, aggregates it into a monthly time series,
    and augments it with features. This is a necessary step to use a
    time-series model like TFT.
    """
    print("Loading and preparing time series data from raw 2022 file...")
    if not os.path.exists(raw_data_path):
        raise FileNotFoundError(
            f"Required raw data file not found at {raw_data_path}. "
            "This script requires the raw 2022 violations file to build a time series for the TFT model."
        )

    raw_df = pd.read_csv(raw_data_path, low_memory=False)

    # Standardize column names
    raw_df.rename(columns={
        'Street Name': 'street_name',
        'Violation Description': 'violation_description',
        'Issue Date': 'issue_date'
    }, inplace=True)

    # Data cleaning and type conversion
    raw_df['issue_date'] = pd.to_datetime(raw_df['issue_date'], errors='coerce')
    raw_df.dropna(subset=['issue_date', 'street_name', 'violation_description'], inplace=True)
    raw_df['street_name'] = raw_df['street_name'].astype(str).str.strip().str.upper()
    raw_df['violation_description'] = raw_df['violation_description'].astype(str).str.strip().str.upper()

    # Aggregate to monthly counts to create the time series
    monthly_df = raw_df.groupby([
        'street_name',
        'violation_description',
        pd.Grouper(key='issue_date', freq='M')
    ]).size().reset_index(name='violation_count')

    # Create a continuous integer time index (0=Jan, 1=Feb, ...)
    monthly_df.sort_values('issue_date', inplace=True)
    monthly_df['time_idx'] = (monthly_df['issue_date'].dt.year - monthly_df['issue_date'].dt.year.min()) * 12 + monthly_df['issue_date'].dt.month - 1
    
    # Create a unique ID for each time series
    monthly_df['series_id'] = monthly_df['street_name'] + " | " + monthly_df['violation_description']
    monthly_df['month'] = monthly_df['issue_date'].dt.month

    # Augment with bike lane data (static feature)
    if os.path.exists(bikelane_path):
        bikelane_df = pd.read_csv(bikelane_path)
        bikelane_streets = set(bikelane_df['street'].astype(str).str.strip().str.upper())
        monthly_df['has_bikelane'] = monthly_df['street_name'].isin(bikelane_streets).astype(float)
    else:
        print(f"Warning: Bike lane data not found at {bikelane_path}. 'has_bikelane' feature will be all zeros.")
        monthly_df['has_bikelane'] = 0.0

    # TFT works best with complete time series. We need to pad missing months for each series.
    all_series = monthly_df[['series_id', 'street_name', 'violation_description', 'has_bikelane']].drop_duplicates()
    max_time = monthly_df['time_idx'].max()
    min_time = monthly_df['time_idx'].min()
    
    if pd.isna(max_time) or pd.isna(min_time):
        print("Warning: No time series data could be generated. Exiting.")
        return pd.DataFrame()

    all_time_idx = range(int(min_time), int(max_time) + 1)
    
    full_index = pd.MultiIndex.from_product([all_series['series_id'].unique(), all_time_idx], names=['series_id', 'time_idx'])
    full_df = pd.DataFrame(index=full_index).reset_index()

    # Merge back static and temporal features
    full_df = pd.merge(full_df, all_series, on='series_id', how='left')
    full_df = pd.merge(full_df, monthly_df[['series_id', 'time_idx', 'violation_count']], on=['series_id', 'time_idx'], how='left')
    full_df['violation_count'].fillna(0, inplace=True)
    full_df['month'] = (full_df['time_idx'] % 12 + 1)
    
    # Final type casting for pytorch-forecasting
    full_df['month'] = full_df['month'].astype(str).astype('category')
    full_df['violation_count'] = full_df['violation_count'].astype(float)
    
    return full_df

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations using Temporal Fusion Transformer.")
    parser.add_argument('--train-path',
                        type=str,
                        default='./input/violations_per_street_2022.csv',
                        help='Path to the training data CSV file (directory is used to find raw data).')
    parser.add_argument('--test-path',
                        type=str,
                        default=None,
                        help='Path to the test data CSV file (optional).')
    
    try:
        args = parser.parse_args()
    except SystemExit:
        # Fallback for environments like Kaggle kernels/Jupyter
        args = parser.parse_args(args=[])

    input_dir = os.path.dirname(args.train_path)
    raw_2022_path = os.path.join(input_dir, 'parking-violations-issued-fiscal-year-2022.csv')
    bikelane_path = os.path.join(input_dir, 'street_with_bikelanes.csv')

    # --- Data Preparation ---
    full_df = create_time_series_data(raw_2022_path, bikelane_path)
    if full_df.empty:
        return
    
    # --- TimeSeriesDataSet Creation ---
    print("Creating TimeSeriesDataSet for training and validation...")
    # We'll train on the first 9 months to predict the last 3 for validation
    max_prediction_length = 3
    max_encoder_length = 9

    training_cutoff = full_df["time_idx"].max() - max_prediction_length

    training_dataset = TimeSeriesDataSet(
        full_df[lambda x: x.time_idx <= training_cutoff],
        time_idx="time_idx",
        target="violation_count",
        group_ids=["series_id"],
        max_encoder_length=max_encoder_length,
        max_prediction_length=max_prediction_length,
        static_categoricals=["street_name", "violation_description"],
        static_reals=["has_bikelane"],
        time_varying_known_categoricals=["month"],
        time_varying_unknown_reals=["violation_count"],
        target_normalizer=GroupNormalizer(groups=["series_id"], transformation="softplus"),
        add_relative_time_idx=True,
        add_target_scales=True,
        add_encoder_length=True,
        allow_missing_timesteps=True,
    )

    validation_dataset = TimeSeriesDataSet.from_dataset(training_dataset, full_df, predict=False, stop_randomization=True)

    batch_size = 64
    # Use num_workers=0 for better compatibility across platforms (e.g., Windows, Jupyter)
    train_dataloader = training_dataset.to_dataloader(train=True, batch_size=batch_size, num_workers=0)
    val_dataloader = validation_dataset.to_dataloader(train=False, batch_size=batch_size * 10, num_workers=0)
    
    # --- Model Training ---
    print("Training Temporal Fusion Transformer model...")
    pl.seed_everything(42, workers=True)
    
    accelerator = "gpu" if torch.cuda.is_available() else "cpu"
    print(f"Using device: {accelerator}")

    early_stop_callback = EarlyStopping(monitor="val_loss", min_delta=1e-4, patience=3, verbose=False, mode="min")
    checkpoint_callback = ModelCheckpoint(save_top_k=1, monitor="val_loss", mode="min")

    trainer = pl.Trainer(
        max_epochs=20,
        accelerator=accelerator,
        devices=1,
        gradient_clip_val=0.1,
        callbacks=[early_stop_callback, checkpoint_callback],
        enable_progress_bar=True,
        enable_model_summary=False, # Suppress model summary for cleaner output
        deterministic=True
    )

    tft = TemporalFusionTransformer.from_dataset(
        training_dataset,
        learning_rate=0.01,
        hidden_size=32,
        attention_head_size=2,
        dropout=0.1,
        hidden_continuous_size=16,
        loss=RMSE(),
        optimizer="Adam",
    )

    trainer.fit(
        tft,
        train_dataloaders=train_dataloader,
        val_dataloaders=val_dataloader,
    )

    # --- Validation ---
    print("Evaluating model on the validation set...")
    best_model_path = trainer.checkpoint_callback.best_model_path
    best_tft = TemporalFusionTransformer.load_from_checkpoint(best_model_path)
    
    actuals = torch.cat([y[0] for _, y in iter(val_dataloader)])
    predictions = best_tft.predict(val_dataloader)
    
    val_rmse = torch.sqrt(torch.mean((actuals - predictions)**2)).item()
    print(f"\nValidation RMSE (predicting last {max_prediction_length} months of 2022): {val_rmse:.4f}")
    print(f"Final Validation Performance: {val_rmse}")

    # --- Inference on Test Set ---
    if args.test_path:
        print(f"\n--- Generating predictions for test file: {args.test_path} ---")
        test_df = pd.read_csv(args.test_path)
        
        test_df.rename(columns={'Street Name': 'street_name', 'Violation Description': 'violation_type'}, inplace=True)
        test_df['street_name'] = test_df['street_name'].astype(str).str.strip().str.upper()
        test_df['violation_type'] = test_df['violation_type'].astype(str).str.strip().str.upper()
        test_df['series_id'] = test_df['street_name'] + " | " + test_df['violation_type']

        train_series_ids = set(full_df['series_id'].unique())
        test_series_ids = set(test_df['series_id'].unique())
        
        unseen_ids = test_series_ids - train_series_ids
        seen_ids = test_series_ids.intersection(train_series_ids)
        
        print(f"Number of unseen (street_name, violation_type) pairs in test set: {len(unseen_ids)}")
        print("These will be handled by predicting a baseline of 0.")

        prediction_map = {}

        if seen_ids:
            # Prepare encoder data: all available 2022 data for series present in the test set.
            encoder_data = full_df[full_df['series_id'].isin(seen_ids)]
            
            # Create a TimeSeriesDataSet for prediction.
            encoder_dataset = TimeSeriesDataSet.from_dataset(training_dataset, encoder_data, predict=True, stop_randomization=True)
            
            # Predict `max_prediction_length` (3) months into 2023.
            test_predictions = best_tft.predict(encoder_dataset)
            
            # Sum the predicted months and extrapolate to a full year
            scale_factor = 12.0 / max_prediction_length
            annual_prediction = test_predictions.sum(axis=1) * scale_factor
            
            # Pytorch-forecasting's predict method returns predictions sorted by the series ID.
            # We must get the sorted list of unique series IDs from our encoder data to map correctly.
            series_id_order = sorted(encoder_data['series_id'].unique())
            prediction_map = dict(zip(series_id_order, annual_prediction.cpu().numpy()))

        # Map predictions to submission dataframe, filling unseen with 0
        submission_df = test_df[['street_name', 'violation_type', 'series_id']].copy()
        submission_df['predicted_count'] = submission_df['series_id'].map(prediction_map).fillna(0)
        
        # Post-processing: clip at 0 and round to integer
        submission_df['predicted_count'] = np.round(np.maximum(0, submission_df['predicted_count'])).astype(int)
        
        submission_df[['street_name', 'violation_type', 'predicted_count']].to_csv('submission.csv', index=False)
        print("Predictions saved to submission.csv")

        # If ground truth is available in test file, score it
        if 'violation_count' in test_df.columns:
            test_rmse = np.sqrt(mean_squared_error(test_df['violation_count'], submission_df['predicted_count']))
            print(f"\nTest set RMSE (ground truth provided): {test_rmse:.4f}")

if __name__ == '__main__':
    main()
