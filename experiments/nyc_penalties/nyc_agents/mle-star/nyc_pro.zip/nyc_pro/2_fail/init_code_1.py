
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import GroupShuffleSplit
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
import os

# --- Data Loading and Preprocessing ---

def load_and_preprocess_data(file_path, is_train=True):
    """Loads and preprocesses the violation data."""
    if not os.path.exists(file_path):
        print(f"Error: File not found at {file_path}")
        return None

    df = pd.read_csv(file_path)

    # Standardize column names
    df.rename(columns={
        'Street Name': 'street_name',
        'Violation Description': 'violation_type',
        'violation_count': 'violation_count'
    }, inplace=True)
    
    # Subsampling to keep runtime manageable, as mentioned in instructions
    if is_train and len(df) > 50000:
        df = df.sample(n=50000, random_state=42)

    # Basic feature engineering
    df['street_name_len'] = df['street_name'].astype(str).str.len()
    df['violation_type_len'] = df['violation_type'].astype(str).str.len()

    if is_train:
        # Log transform the target variable to handle skewness
        df['violation_count'] = np.log1p(df['violation_count'])
    
    return df

# --- Feature Engineering with Categorical Data ---

class TargetEncoder:
    """Target encoder for categorical features with smoothing."""
    def __init__(self, target_col='violation_count', smoothing=20):
        self.target_col = target_col
        self.smoothing = smoothing
        self.mappers = {}

    def fit(self, df, cat_features):
        """Fit the encoder based on the training data."""
        df_copy = df.copy()
        for col in cat_features:
            global_mean = df_copy[self.target_col].mean()
            agg = df_copy.groupby(col)[self.target_col].agg(['count', 'mean'])
            counts = agg['count']
            means = agg['mean']
            
            # Compute smoothed mean
            smooth = (counts * means + self.smoothing * global_mean) / (counts + self.smoothing)
            
            self.mappers[col] = smooth
            # Store global mean for unseen values during transformation
            self.mappers[col]['_global_mean_'] = global_mean

    def transform(self, df, cat_features):
        """Transform the data using the fitted mappers."""
        df_transformed = df.copy()
        for col in cat_features:
            mapper = self.mappers[col]
            # Map values, fill unseen with the global mean
            df_transformed[col + '_encoded'] = df_transformed[col].map(mapper).fillna(mapper['_global_mean_'])
        return df_transformed

    def fit_transform(self, df, cat_features):
        """Fit and transform the data in one step."""
        self.fit(df, cat_features)
        return self.transform(df, cat_features)

# --- Main Execution ---

def main():
    """Main function to run the prediction pipeline."""
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', 
                        type=str, 
                        default='./input/violations_per_street_2022.csv',
                        help='Path to the training data CSV file.')
    parser.add_argument('--test-path', 
                        type=str, 
                        default=None,
                        help='Path to the test data CSV file (optional).')
    
    args = parser.parse_args()

    # --- FIX: Use underscores to access parsed arguments ---
    train_path = args.train_path
    test_path = args.test_path
    
    print("Loading and preprocessing training data...")
    train_df = load_and_preprocess_data(train_path, is_train=True)
    if train_df is None:
        return # Stop if the training file is not found

    print("Splitting data into training and validation sets...")
    splitter = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=42)
    train_indices, val_indices = next(splitter.split(train_df, groups=train_df['street_name']))
    
    dev_train = train_df.iloc[train_indices]
    dev_val = train_df.iloc[val_indices]

    y_train = dev_train['violation_count']
    y_val = dev_val['violation_count']

    print("Performing feature engineering...")
    categorical_features = ['street_name', 'violation_type']
    
    encoder = TargetEncoder()
    X_train_encoded = encoder.fit_transform(dev_train, categorical_features)
    X_val_encoded = encoder.transform(dev_val, categorical_features)
    
    feature_cols = [col for col in X_train_encoded.columns if '_encoded' in col or '_len' in col]
    X_train = X_train_encoded[feature_cols]
    X_val = X_val_encoded[feature_cols]

    print("Training the model...")
    model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1, min_samples_leaf=5)
    model.fit(X_train, y_train)

    print("Evaluating model on the validation set...")
    val_preds_log = model.predict(X_val)
    val_preds = np.expm1(val_preds_log) # Inverse log transform
    val_preds[val_preds < 0] = 0 # Ensure non-negativity
    
    y_val_orig = np.expm1(y_val) # Get original scale for scoring
    final_validation_score = np.sqrt(mean_squared_error(y_val_orig, val_preds))
    print(f"Validation RMSE (2022 holdout): {final_validation_score}")
    # This specific line is required for parsing the performance
    print(f"Final Validation Performance: {final_validation_score}")

    if test_path:
        print("\n--- Generating predictions for the test file ---")
        
        print(f"Loading and preprocessing test data from {test_path}...")
        test_df = load_and_preprocess_data(test_path, is_train=False)
        if test_df is None:
            return

        submission_df = test_df[['street_name', 'violation_type']].copy()
        
        train_keys = set(zip(train_df['street_name'], train_df['violation_type']))
        test_keys = set(zip(test_df['street_name'], test_df['violation_type']))
        unseen_keys_count = len(test_keys - train_keys)
        print(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_keys_count}")
        print("These will be handled by the target encoder's global mean.")

        X_test_encoded = encoder.transform(test_df, categorical_features)
        X_test = X_test_encoded[feature_cols]

        print("Predicting on the test set...")
        test_preds_log = model.predict(X_test)
        test_preds = np.expm1(test_preds_log)
        test_preds[test_preds < 0] = 0 # Clip at zero
        
        submission_df['predicted_count'] = test_preds.round()

        output_path = 'submission.csv'
        submission_df.to_csv(output_path, index=False)
        print(f"Predictions saved to {output_path}")

        if 'violation_count' in test_df.columns:
            test_rmse = np.sqrt(mean_squared_error(test_df['violation_count'], test_preds))
            print(f"\nTest set RMSE (ground truth provided): {test_rmse}")

if __name__ == '__main__':
    main()
