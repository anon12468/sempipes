
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os
import glob

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return None
    except pd.errors.EmptyDataError:
        print(f"Warning: File is empty at {file_path}")
        return pd.DataFrame()
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return None

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='/Users/USER/Documents/UNI/SS26/nyc_open_data/train/all_data/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV relative to INPUT_DIR.')
    parser.add_argument('--test-path', type=str, default='/Users/USER/Documents/UNI/SS26/nyc_open_data/violations_per_street_2023.csv',
                        help='Optional path to the test/evaluation data CSV relative to INPUT_DIR for prediction.')
    args = parser.parse_args()

    INPUT_DIR = './input'
    TRAIN_FILE = args.train_path
    TEST_FILE = args.test_path

    # --- 1. Load Training Data ---
    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)
    print(f"Loading training data from: {train_df_path}")
    train_df = load_data(train_df_path)

    if train_df is None or train_df.empty:
        print("Training data could not be loaded or is empty. Exiting.")
        return

    print(f"Original training data shape: {train_df.shape}")
    print("Training data columns:", train_df.columns.tolist())

    # Ensure required columns are present in the training data
    required_train_cols = ['street_name', 'violation_description', 'violation_count']
    if not all(col in train_df.columns for col in required_train_cols):
        print(f"Error: Training data missing one or more required columns: {required_train_cols}")
        print("Available columns:", train_df.columns.tolist())
        return

    # --- 2. Feature Engineering and Augmentation (applied once to full train_df) ---
    # Convert categorical features to string type explicitly for CatBoost
    train_df['street_name'] = train_df['street_name'].astype(str)
    train_df['violation_description'] = train_df['violation_description'].astype(str)
    # Handle potential NaN values in categorical features by filling them with a placeholder
    train_df['street_name'] = train_df['street_name'].fillna('UNKNOWN_STREET')
    train_df['violation_description'] = train_df['violation_description'].fillna('UNKNOWN_VIOLATION')

    # Ensure target variable is numeric and handle potential NaNs (e.g., fill with 0 or mean)
    train_df['violation_count'] = pd.to_numeric(train_df['violation_count'], errors='coerce')
    train_df['violation_count'] = train_df['violation_count'].fillna(0) # Fill NaNs in target with 0
    # Ensure violation counts are non-negative
    train_df['violation_count'] = train_df['violation_count'].clip(lower=0)

    # Enhanced Feature Engineering
    train_df['violation_description_length'] = train_df['violation_description'].apply(len)
    train_df['violation_description_word_count'] = train_df['violation_description'].apply(lambda x: len(str(x).split()))
    train_df['street_name_desc_len_interaction'] = \
        train_df['street_name'].astype(str) + '_' + train_df['violation_description_length'].astype(str)
    train_df['street_name_desc_len_interaction'] = train_df['street_name_desc_len_interaction'].astype(str)

    # --- 3. Prepare Data for Model (for full dataset before KFold) ---
    features = [
        'street_name',
        'violation_description',
        'violation_description_length',
        'violation_description_word_count',
        'street_name_desc_len_interaction'
    ]
    target = 'violation_count'

    X = train_df[features]
    # Apply log1p transformation to the target variable for training
    y = np.log1p(train_df[target])

    # Identify categorical features by their column names (based on full X)
    categorical_features_indices = [i for i, col in enumerate(features) if X[col].dtype == 'object']

    # --- K-Fold Cross-Validation Setup ---
    N_SPLITS = 5 # Number of folds for K-Fold Cross-Validation
    kf = KFold(n_splits=N_SPLITS, shuffle=True, random_state=42)

    oof_predictions_log_list = [] # Store out-of-fold predictions (log scale)
    oof_true_values_log_list = [] # Store true values for out-of-fold (log scale)
    test_predictions_per_fold = [] # Store test predictions from each fold (original scale)
    fold_rmses = [] # Store RMSE for each fold (on original scale)

    # Pre-process test data if available, outside the loop for efficiency
    test_df = None
    X_test_processed = None
    if TEST_FILE:
        test_df_path = os.path.join(INPUT_DIR, TEST_FILE)
        print(f"\nLoading test data from: {test_df_path}")
        test_df = load_data(test_df_path)

        if test_df is None or test_df.empty:
            print("Test data could not be loaded or is empty. Skipping prediction.")
        else:
            print(f"Original test data shape: {test_df.shape}")
            print("Test data columns:", test_df.columns.tolist())
            required_test_cols = ['street_name', 'violation_description']
            if not all(col in test_df.columns for col in required_test_cols):
                print(f"Error: Test data missing one or more required columns: {required_test_cols}")
                print("Available columns:", test_df.columns.tolist())
                test_df = None # Invalidate test_df if critical columns are missing
            else:
                # Apply same feature engineering and type conversion as training data
                test_df['street_name'] = test_df['street_name'].astype(str).fillna('UNKNOWN_STREET')
                test_df['violation_description'] = test_df['violation_description'].astype(str).fillna('UNKNOWN_VIOLATION')
                test_df['violation_description_length'] = test_df['violation_description'].apply(len)
                test_df['violation_description_word_count'] = test_df['violation_description'].apply(lambda x: len(str(x).split()))
                test_df['street_name_desc_len_interaction'] = \
                    test_df['street_name'].astype(str) + '_' + test_df['violation_description_length'].astype(str)
                test_df['street_name_desc_len_interaction'] = test_df['street_name_desc_len_interaction'].astype(str)
                X_test_processed = test_df[features]
                print(f"Processed test data shape: {X_test_processed.shape}")
                
                # Report unseen keys in test set
                train_street_names = set(train_df['street_name'].unique())
                train_violation_descriptions = set(train_df['violation_description'].unique())
                unseen_streets_count = X_test_processed[~X_test_processed['street_name'].isin(train_street_names)].shape[0]
                unseen_violations_count = X_test_processed[~X_test_processed['violation_description'].isin(train_violation_descriptions)].shape[0]
                print(f"Number of test rows with unseen street names: {unseen_streets_count}")
                print(f"Number of test rows with unseen violation descriptions: {unseen_violations_count}")
                print("CatBoost handles unseen categorical features gracefully by assigning them to a default category.")


    # --- K-Fold Loop for Training and Prediction ---
    for fold, (train_index, val_index) in enumerate(kf.split(X, y)):
        print(f"\n--- Fold {fold+1}/{N_SPLITS} ---")
        X_train_fold, X_val_fold = X.iloc[train_index], X.iloc[val_index]
        y_train_fold, y_val_fold = y.iloc[train_index], y.iloc[val_index]

        train_pool = Pool(X_train_fold, y_train_fold, cat_features=categorical_features_indices)
        val_pool = Pool(X_val_fold, y_val_fold, cat_features=categorical_features_indices)

        model = CatBoostRegressor(
            iterations=1000,
            learning_rate=0.03,
            depth=9,
            l2_leaf_reg=3,
            eval_metric='RMSE',
            random_seed=42,
            verbose=0,
            early_stopping_rounds=100,
            thread_count=-1,
        )

        print(f"Training CatBoost model for Fold {fold+1}...")
        model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=100, verbose=False)

        # Record OOF predictions and true values (log scale)
        fold_val_preds_log = model.predict(X_val_fold)
        oof_predictions_log_list.append(fold_val_preds_log)
        oof_true_values_log_list.append(y_val_fold)

        # Calculate fold RMSE on original scale for weighting
        fold_val_preds_original = np.expm1(fold_val_preds_log)
        fold_val_preds_original[fold_val_preds_original < 0] = 0
        fold_true_original = np.expm1(y_val_fold)
        fold_rmse = np.sqrt(mean_squared_error(fold_true_original, fold_val_preds_original))
        fold_rmses.append(fold_rmse)
        print(f"Fold {fold+1} Validation RMSE: {fold_rmse}")

        # Make predictions on the full test set with the current fold's model
        if X_test_processed is not None:
            fold_test_preds_log = model.predict(X_test_processed)
            fold_test_preds_original = np.expm1(fold_test_preds_log)
            fold_test_preds_original[fold_test_preds_original < 0] = 0
            test_predictions_per_fold.append(fold_test_preds_original)

    # --- Ensemble Validation Performance (Overall Out-Of-Fold) ---
    all_oof_predictions_log = np.concatenate(oof_predictions_log_list)
    all_oof_true_values_log = np.concatenate(oof_true_values_log_list)

    all_oof_predictions_original = np.expm1(all_oof_predictions_log)
    all_oof_predictions_original[all_oof_predictions_original < 0] = 0
    all_oof_true_values_original = np.expm1(all_oof_true_values_log)

    overall_oof_rmse = np.sqrt(mean_squared_error(all_oof_true_values_original, all_oof_predictions_original))
    print(f"\nOverall Out-Of-Fold Validation RMSE: {overall_oof_rmse}")
    print(f"Final Validation Performance: {overall_oof_rmse}") # Required output format


    # --- Weighted Average Test Predictions and Submission ---
    if X_test_processed is not None and len(test_predictions_per_fold) > 0:
        print("\nCombining test predictions with performance-weighted averaging...")

        # Calculate Inverse-RMSE Weights
        weights = [1 / (rmse**2 + 1e-9) for rmse in fold_rmses]
        normalized_weights = np.array(weights) / np.sum(weights)
        print(f"Normalized weights for folds: {normalized_weights}")

        # Perform weighted average
        weighted_test_predictions = np.zeros_like(test_predictions_per_fold[0], dtype=float)
        for i, preds in enumerate(test_predictions_per_fold):
            weighted_test_predictions += normalized_weights[i] * preds

        # Final processing: Round to nearest integer and ensure non-negative
        final_test_predictions = weighted_test_predictions.round().astype(int)
        final_test_predictions[final_test_predictions < 0] = 0

        # Create submission file
        submission_df = test_df[['street_name', 'violation_description']].copy()
        submission_df['predicted_count'] = final_test_predictions

        # Create the './final' directory if it doesn't exist
        os.makedirs('./final', exist_ok=True)
        submission_output_path = os.path.join('./final', 'submission.csv')
        submission_df.to_csv(submission_output_path, index=False)
        print(f"Submission file '{submission_output_path}' generated successfully using weighted averaging.")

        # If test file contains 'violation_count', calculate RMSE on the ensemble predictions
        if target in test_df.columns:
            y_test_true_original = pd.to_numeric(test_df[target], errors='coerce').fillna(0).clip(lower=0)
            rmse_test_ensemble = np.sqrt(mean_squared_error(y_test_true_original, final_test_predictions))
            print(f"RMSE on the provided test/evaluation file with ensemble: {rmse_test_ensemble}")
        else:
            print("Test file does not contain 'violation_count'. No RMSE calculated for test set with ensemble.")
    else:
        print("\nNo test file provided or test data could not be processed. Skipping final submission generation.")

if __name__ == "__main__":
    main()
