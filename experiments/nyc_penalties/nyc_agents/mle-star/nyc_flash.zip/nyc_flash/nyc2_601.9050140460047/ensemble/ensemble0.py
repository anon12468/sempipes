
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os
import glob # Used for potential future data discovery/loading if augmentation tables are added

# Ensure required libraries are installed
# You may need to run:
# pip install pandas numpy scikit-learn catboost

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return None
    except pd.errors.EmptyDataError:
        print(f"Warning: File is empty at {file_path}")
        return pd.DataFrame() # Return empty DataFrame to avoid further errors
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return None

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV relative to INPUT_DIR.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional path to the test/evaluation data CSV relative to INPUT_DIR for prediction.')
    args = parser.parse_args()

    INPUT_DIR = './input' # All input data is stored in this directory
    TRAIN_FILE = args.train_path
    TEST_FILE = args.test_path

    # --- 1. Load Training Data ---
    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)
    print(f"Loading training data from: {train_df_path}")
    train_df = load_data(train_df_path)

    if train_df is None or train_df.empty:
        print("Training data could not be loaded or is empty. Exiting.")
        return

    print(f"Original training data shape: {train_df.shape}")
    print("Training data columns:", train_df.columns.tolist())

    # Ensure required columns are present in the training data
    required_train_cols = ['street_name', 'violation_description', 'violation_count']
    if not all(col in train_df.columns for col in required_train_cols):
        print(f"Error: Training data missing one or more required columns: {required_train_cols}")
        print("Available columns:", train_df.columns.tolist())
        return

    # --- 2. Feature Engineering and Augmentation ---
    # Placeholder for feature augmentation.
    # This is where additional datasets from the INPUT_DIR would be loaded and merged.
    # For example, to load and merge census data:
    # try:
    #     census_df_path = os.path.join(INPUT_DIR, 'nyc_census_data.csv')
    #     census_df = load_data(census_df_path)
    #     if census_df is not None and not census_df.empty:
    #         # Example merge: Assuming 'street_name' can be linked to census data
    #         train_df = pd.merge(train_df, census_df, on='street_name', how='left')
    #         print(f"Merged with census data. New training data shape: {train_df.shape}")
    # except Exception as e:
    #     print(f"Could not load/process census data for augmentation: {e}")

    # Convert categorical features to string type explicitly for CatBoost
    train_df['street_name'] = train_df['street_name'].astype(str)
    train_df['violation_description'] = train_df['violation_description'].astype(str)
    # Handle potential NaN values in categorical features by filling them with a placeholder
    train_df['street_name'] = train_df['street_name'].fillna('UNKNOWN_STREET')
    train_df['violation_description'] = train_df['violation_description'].fillna('UNKNOWN_VIOLATION')

    # Ensure target variable is numeric and handle potential NaNs (e.g., fill with 0 or mean)
    train_df['violation_count'] = pd.to_numeric(train_df['violation_count'], errors='coerce')
    train_df['violation_count'] = train_df['violation_count'].fillna(0) # Fill NaNs in target with 0
    # Ensure violation counts are non-negative
    train_df['violation_count'] = train_df['violation_count'].clip(lower=0)


    # --- Enhanced Feature Engineering ---
    # Extract numerical information from 'violation_description'
    train_df['violation_description_length'] = train_df['violation_description'].apply(len)
    train_df['violation_description_word_count'] = train_df['violation_description'].apply(lambda x: len(str(x).split()))

    # Explore simple interaction features
    # Create an interaction feature between 'street_name' and 'violation_description_length'
    train_df['street_name_desc_len_interaction'] = \
        train_df['street_name'].astype(str) + '_' + train_df['violation_description_length'].astype(str)
    # Ensure the new interaction feature is also treated as a string/categorical
    train_df['street_name_desc_len_interaction'] = train_df['street_name_desc_len_interaction'].astype(str)


    # --- 3. Prepare Data for Model ---
    features = [
        'street_name',
        'violation_description',
        'violation_description_length',
        'violation_description_word_count',
        'street_name_desc_len_interaction' # New interaction feature
    ]
    target = 'violation_count'

    X = train_df[features]
    # Apply log1p transformation to the target variable for training
    # This helps stabilize variance and handle skewed count data.
    y = np.log1p(train_df[target])

    # Identify categorical features by their column names
    categorical_features_indices = [i for i, col in enumerate(features) if X[col].dtype == 'object']

    # --- K-Fold Cross-Validation Setup ---
    NFOLDS = 5 # Number of folds for cross-validation
    folds = KFold(n_splits=NFOLDS, shuffle=True, random_state=42)

    # Prepare arrays to store Out-of-Fold (OOF) predictions and test predictions
    oof_preds_log = np.zeros(len(X))
    test_preds_list_log = []

    print(f"\nStarting K-Fold Cross-Validation with {NFOLDS} folds...")

    # --- 4. & 5. Train Multiple Model Instances & Collect Predictions ---
    for fold_, (trn_idx, val_idx) in enumerate(folds.split(X, y)):
        print(f"--- Fold {fold_ + 1}/{NFOLDS} ---")
        X_train_fold, X_val_fold = X.iloc[trn_idx], X.iloc[val_idx]
        y_train_fold, y_val_fold = y.iloc[trn_idx], y.iloc[val_idx]

        train_pool_fold = Pool(X_train_fold, y_train_fold, cat_features=categorical_features_indices)
        val_pool_fold = Pool(X_val_fold, y_val_fold, cat_features=categorical_features_indices)

        model = CatBoostRegressor(
            iterations=1000,
            learning_rate=0.03,
            depth=9,
            l2_leaf_reg=3,
            eval_metric='RMSE',
            random_seed=42,
            verbose=0,
            early_stopping_rounds=100,
            thread_count=-1,
        )

        print(f"Training CatBoost model for Fold {fold_ + 1}...")
        model.fit(train_pool_fold, eval_set=val_pool_fold, early_stopping_rounds=100, verbose=False)

        # Collect OOF predictions
        oof_preds_log[val_idx] = model.predict(X_val_fold)

        # Collect Test Predictions for each fold's model
        if TEST_FILE:
            test_df_path = os.path.join(INPUT_DIR, TEST_FILE)
            test_df_for_fold_prediction = load_data(test_df_path) # Reload to ensure fresh state if needed, though not strictly necessary here

            if test_df_for_fold_prediction is None or test_df_for_fold_prediction.empty:
                print("Test data could not be loaded or is empty. Skipping test predictions for this fold.")
            else:
                # Apply same feature engineering and type conversion as training data
                test_df_for_fold_prediction['street_name'] = test_df_for_fold_prediction['street_name'].astype(str).fillna('UNKNOWN_STREET')
                test_df_for_fold_prediction['violation_description'] = test_df_for_fold_prediction['violation_description'].astype(str).fillna('UNKNOWN_VIOLATION')
                test_df_for_fold_prediction['violation_description_length'] = test_df_for_fold_prediction['violation_description'].apply(len)
                test_df_for_fold_prediction['violation_description_word_count'] = test_df_for_fold_prediction['violation_description'].apply(lambda x: len(str(x).split()))
                test_df_for_fold_prediction['street_name_desc_len_interaction'] = \
                    test_df_for_fold_prediction['street_name'].astype(str) + '_' + test_df_for_fold_prediction['violation_description_length'].astype(str)
                test_df_for_fold_prediction['street_name_desc_len_interaction'] = test_df_for_fold_prediction['street_name_desc_len_interaction'].astype(str)

                X_test_fold = test_df_for_fold_prediction[features]
                test_preds_list_log.append(model.predict(X_test_fold))

    # --- 6. Evaluate Ensemble Performance (OOF RMSE) ---
    # Inverse transform OOF predictions and original targets from log1p scale
    oof_preds = np.expm1(oof_preds_log)
    oof_preds[oof_preds < 0] = 0 # Ensure non-negative
    oof_targets = np.expm1(y)
    oof_targets[oof_targets < 0] = 0 # Ensure non-negative

    final_validation_score = np.sqrt(mean_squared_error(oof_targets, oof_preds))
    print(f"\nFinal Validation Performance: {final_validation_score}") # Required output format

    # --- 7. Final Prediction and Submission ---
    if TEST_FILE:
        test_df_path = os.path.join(INPUT_DIR, TEST_FILE)
        print(f"\nLoading test data from: {test_df_path}")
        test_df = load_data(test_df_path)

        if test_df is None or test_df.empty:
            print("Test data could not be loaded or is empty. Skipping final prediction and submission.")
            return

        print(f"Original test data shape: {test_df.shape}")
        print("Test data columns:", test_df.columns.tolist())

        # Ensure required columns are present in test set (excluding target if not there)
        required_test_cols = ['street_name', 'violation_description']
        if not all(col in test_df.columns for col in required_test_cols):
            print(f"Error: Test data missing one or more required columns: {required_test_cols}")
            print("Available columns:", test_df.columns.tolist())
            return

        # Store original key columns for submission
        submission_keys = test_df[['street_name', 'violation_description']].copy()

        # Apply same feature engineering and type conversion as training data
        test_df['street_name'] = test_df['street_name'].astype(str)
        test_df['violation_description'] = test_df['violation_description'].astype(str)
        test_df['street_name'] = test_df['street_name'].fillna('UNKNOWN_STREET')
        test_df['violation_description'] = test_df['violation_description'].fillna('UNKNOWN_VIOLATION')
        test_df['violation_description_length'] = test_df['violation_description'].apply(len)
        test_df['violation_description_word_count'] = test_df['violation_description'].apply(lambda x: len(str(x).split()))
        test_df['street_name_desc_len_interaction'] = \
            test_df['street_name'].astype(str) + '_' + test_df['violation_description_length'].astype(str)
        test_df['street_name_desc_len_interaction'] = test_df['street_name_desc_len_interaction'].astype(str)

        # Aggregate test predictions
        if test_preds_list_log:
            avg_test_predictions_log = np.mean(test_preds_list_log, axis=0)
            final_test_predictions = np.expm1(avg_test_predictions_log)
            final_test_predictions[final_test_predictions < 0] = 0
        else:
            print("No test predictions were generated across folds. Cannot create submission file.")
            return

        submission_df = submission_keys
        submission_df['predicted_count'] = final_test_predictions.round().astype(int)

        # Save submission file
        submission_output_path = 'submission.csv'
        submission_df.to_csv(submission_output_path, index=False)
        print(f"Submission file '{submission_output_path}' generated successfully.")

        # If test file contains 'violation_count', calculate RMSE
        if target in test_df.columns:
            y_test_true_original = pd.to_numeric(test_df[target], errors='coerce').fillna(0).clip(lower=0)
            rmse_test = np.sqrt(mean_squared_error(y_test_true_original, final_test_predictions))
            print(f"RMSE on the provided test/evaluation file: {rmse_test}")
        else:
            print("Test file does not contain 'violation_count'. No RMSE calculated for test set.")
    else:
        print("No test file provided. Skipping prediction and submission.")


if __name__ == "__main__":
    main()
