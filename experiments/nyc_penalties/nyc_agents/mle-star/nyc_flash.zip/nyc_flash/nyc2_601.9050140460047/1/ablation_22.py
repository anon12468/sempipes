
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os

# Ensure required libraries are installed
# You may need to run:
# pip install pandas numpy scikit-learn catboost

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return None
    except pd.errors.EmptyDataError:
        print(f"Warning: File is empty at {file_path}")
        return pd.DataFrame() # Return empty DataFrame to avoid further errors
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return None

def train_and_evaluate(train_df_original,
                       use_astype_str_for_categoricals=True,
                       use_target_clipping=True,
                       catboost_thread_count=-1,
                       random_seed=42):
    
    # Make a copy to avoid modifying the original dataframe for each experiment
    train_df = train_df_original.copy()

    # Ensure required columns are present in the training data
    required_train_cols = ['street_name', 'violation_description', 'violation_count']
    if not all(col in train_df.columns for col in required_train_cols):
        raise ValueError(f"Training data missing one or more required columns: {required_train_cols}")

    # --- 2. Feature Engineering and Augmentation ---

    # Convert categorical features to string type explicitly for CatBoost (Ablation point 1)
    # This also applies before fillna, so the order is important.
    if use_astype_str_for_categoricals:
        train_df['street_name'] = train_df['street_name'].astype(str)
        train_df['violation_description'] = train_df['violation_description'].astype(str)
    
    # Handle potential NaN values in categorical features by filling them with a placeholder
    train_df['street_name'] = train_df['street_name'].fillna('UNKNOWN_STREET')
    train_df['violation_description'] = train_df['violation_description'].fillna('UNKNOWN_VIOLATION')

    # Ensure target variable is numeric and handle potential NaNs (e.g., fill with 0 or mean)
    train_df['violation_count'] = pd.to_numeric(train_df['violation_count'], errors='coerce')
    train_df['violation_count'] = train_df['violation_count'].fillna(0) # Fill NaNs in target with 0
    
    # Ensure violation counts are non-negative (Ablation point 2)
    if use_target_clipping:
        train_df['violation_count'] = train_df['violation_count'].clip(lower=0)


    # --- Enhanced Feature Engineering ---
    # Extract numerical information from 'violation_description'
    train_df['violation_description_length'] = train_df['violation_description'].apply(len)
    train_df['violation_description_word_count'] = train_df['violation_description'].apply(lambda x: len(str(x).split()))

    # Create an interaction feature between 'street_name' and 'violation_description_length'
    train_df['street_name_desc_len_interaction'] = \
        train_df['street_name'].astype(str) + '_' + train_df['violation_description_length'].astype(str)
    # Ensure the new interaction feature is also treated as a string/categorical
    train_df['street_name_desc_len_interaction'] = train_df['street_name_desc_len_interaction'].astype(str)


    # --- 3. Prepare Data for Model ---
    features = [
        'street_name',
        'violation_description',
        'violation_description_length',
        'violation_description_word_count',
        'street_name_desc_len_interaction' # New interaction feature
    ]
    target = 'violation_count'

    X = train_df[features]
    y = np.log1p(train_df[target]) # Apply log1p transformation to the target variable

    # Identify categorical features by their column names
    # CatBoost can handle various types, but explicitly naming them here is robust.
    categorical_features_cols = ['street_name', 'violation_description', 'street_name_desc_len_interaction']
    categorical_features_indices = [features.index(col) for col in categorical_features_cols]


    # --- 4. Split Training Data for Validation ---
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=random_seed)

    # Create CatBoost Pool objects
    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices)

    # --- 5. Model Training ---
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.03,
        depth=9,
        l2_leaf_reg=3,
        eval_metric='RMSE',
        random_seed=random_seed,
        verbose=0,
        early_stopping_rounds=100,
        thread_count=catboost_thread_count, # Ablation point 3
    )

    model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=100, verbose=False)

    # --- 6. Validation ---
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log)
    val_predictions[val_predictions < 0] = 0

    rmse_val = np.sqrt(mean_squared_error(np.expm1(y_val), val_predictions))
    return rmse_val


def main():
    parser = argparse.ArgumentParser(description="Perform ablation study on NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV relative to INPUT_DIR.')
    args = parser.parse_args()

    INPUT_DIR = './input'
    TRAIN_FILE = args.train_path

    # --- 1. Load Training Data ---
    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)
    print(f"Loading training data from: {train_df_path}")
    train_df = load_data(train_df_path)

    if train_df is None or train_df.empty:
        print("Training data could not be loaded or is empty. Exiting.")
        return

    print(f"Original training data shape: {train_df.shape}")
    print("Training data columns:", train_df.columns.tolist())

    # Store results
    results = {}

    # --- Baseline Experiment ---
    print("\n--- Running Baseline Experiment ---")
    baseline_rmse = train_and_evaluate(train_df,
                                       use_astype_str_for_categoricals=True,
                                       use_target_clipping=True,
                                       catboost_thread_count=-1)
    results['Baseline'] = baseline_rmse
    print(f"Baseline Validation RMSE: {baseline_rmse:.4f}")

    # --- Ablation 1: No explicit astype(str) for categorical features ---
    print("\n--- Running Ablation 1: No explicit astype(str) for categoricals ---")
    ablation1_rmse = train_and_evaluate(train_df,
                                        use_astype_str_for_categoricals=False,
                                        use_target_clipping=True,
                                        catboost_thread_count=-1)
    results['No explicit astype(str) for categoricals'] = ablation1_rmse
    print(f"Ablation 1 (No explicit astype(str)) Validation RMSE: {ablation1_rmse:.4f}")

    # --- Ablation 2: No target variable clipping (.clip(lower=0)) ---
    print("\n--- Running Ablation 2: No target variable clipping (.clip(lower=0)) ---")
    ablation2_rmse = train_and_evaluate(train_df,
                                        use_astype_str_for_categoricals=True,
                                        use_target_clipping=False,
                                        catboost_thread_count=-1)
    results['No target variable clipping'] = ablation2_rmse
    print(f"Ablation 2 (No target clipping) Validation RMSE: {ablation2_rmse:.4f}")
    
    # --- Ablation 3: Change CatBoost thread_count to 1 ---
    print("\n--- Running Ablation 3: Change CatBoost thread_count to 1 ---")
    ablation3_rmse = train_and_evaluate(train_df,
                                        use_astype_str_for_categoricals=True,
                                        use_target_clipping=True,
                                        catboost_thread_count=1)
    results['CatBoost thread_count=1'] = ablation3_rmse
    print(f"Ablation 3 (CatBoost thread_count=1) Validation RMSE: {ablation3_rmse:.4f}")


    # --- Conclusion ---
    print("\n--- Ablation Study Conclusion ---")
    
    baseline_rmse_val = results['Baseline']
    
    most_impactful_change = None
    max_abs_diff = 0

    print(f"Baseline RMSE: {baseline_rmse_val:.4f}")
    for name, rmse in results.items():
        if name == 'Baseline':
            continue
        diff = rmse - baseline_rmse_val
        print(f"'{name}' RMSE: {rmse:.4f} (Change vs Baseline: {diff:+.4f})")
        
        # Determine the most impactful (largest absolute change from baseline)
        if abs(diff) > abs(max_abs_diff):
            max_abs_diff = diff
            most_impactful_change = name

    if most_impactful_change:
        if max_abs_diff > 0:
            print(f"\nThe part of the code that contributed most *negatively* to the overall performance (i.e., its modification led to the largest degradation) is: '{most_impactful_change}' (RMSE increased by {max_abs_diff:+.4f}).")
        else:
            print(f"\nThe part of the code that contributed most *positively* to the overall performance (i.e., its modification led to the largest improvement) is: '{most_impactful_change}' (RMSE decreased by {max_abs_diff:+.4f}).")
    else:
        print("\nNo significant impact observed from ablations compared to the baseline.")

if __name__ == "__main__":
    main()
