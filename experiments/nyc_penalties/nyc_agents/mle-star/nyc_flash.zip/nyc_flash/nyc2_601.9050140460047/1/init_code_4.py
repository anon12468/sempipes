
import pandas as pd
import numpy as np
import os
import argparse
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool

# Function to calculate RMSE
def rmse(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations using CatBoost Regressor.")
    parser.add_argument("--train-path", type=str, default="violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Optional path to the 2023 test data CSV for predictions.")
    args = parser.parse_args()

    INPUT_DIR = os.path.join(os.getcwd(), 'input')

    # Define full file paths for all data files
    train_violations_file = os.path.join(INPUT_DIR, args.train_path)
    parking_codes_file = os.path.join(INPUT_DIR, 'parking_violations_codes.csv')
    street_geo_file = os.path.join(INPUT_DIR, 'nyc_streets_geographic_data.csv')

    # Load data with error handling for FileNotFoundError
    try:
        train_df_raw = pd.read_csv(train_violations_file)
        parking_codes_df_raw = pd.read_csv(parking_codes_file)
        street_geo_df_raw = pd.read_csv(street_geo_file)
    except FileNotFoundError as e:
        print(f"Error loading a data file: {e}")
        print(f"Please ensure all required CSV files are present in the '{INPUT_DIR}' directory. "
              f"Current working directory: {os.getcwd()}")
        return

    # --- Preprocessing for auxiliary tables (done once) ---
    # Parking Codes: Standardize, clean, and make unique for merging
    parking_codes_df = parking_codes_df_raw.copy()
    parking_codes_df_unique = pd.DataFrame(columns=['violation_type_lower', 'violation_code', 'violation_definition'])
    if all(col in parking_codes_df.columns for col in ['Code', 'Description', 'Definition']):
        parking_codes_df.rename(columns={'Code': 'violation_code', 'Description': 'violation_type', 'Definition': 'violation_definition'}, inplace=True)
        parking_codes_df['violation_type_lower'] = parking_codes_df['violation_type'].str.lower().str.strip()
        parking_codes_df_unique = parking_codes_df.drop_duplicates(subset=['violation_type_lower'], keep='first')[['violation_type_lower', 'violation_code', 'violation_definition']]
    else:
        print("Warning: Expected columns 'Code', 'Description', 'Definition' not found in parking_violations_codes.csv. Violation code features will be missing.")

    # Street Geographic Data: Standardize, aggregate (mean for numerical, mode for categorical)
    street_geo_df = street_geo_df_raw.copy()
    street_geo_agg = pd.DataFrame()
    if 'street_name' in street_geo_df.columns and 'borough' in street_geo_df.columns:
        street_geo_df.columns = street_geo_df.columns.str.lower().str.replace(' ', '_')
        street_geo_df['street_name_lower'] = street_geo_df['street_name'].str.lower().str.strip()
        
        if 'zip_code' in street_geo_df.columns:
            street_geo_df['zip_code'] = street_geo_df['zip_code'].astype(str)
        else:
            street_geo_df['zip_code'] = 'Unknown'

        # Aggregate geographical data per street
        agg_functions = {
            'borough': lambda x: x.mode()[0] if not x.mode().empty else 'Unknown',
            'latitude': 'mean',
            'longitude': 'mean',
            'segment_length': 'sum',
            'zip_code': lambda x: x.mode()[0] if not x.mode().empty else 'Unknown'
        }
        # Filter for existing columns to avoid key errors if some numerical columns are missing
        existing_agg_functions = {k: v for k, v in agg_functions.items() if k in street_geo_df.columns}

        street_geo_agg = street_geo_df.groupby('street_name_lower').agg(existing_agg_functions).reset_index()
    else:
        print("Warning: Essential 'street_name' or 'borough' columns not found in nyc_streets_geographic_data.csv. Street geo features will be missing.")

    # --- Feature Engineering Function ---
    def apply_feature_engineering(df, parking_codes_unique_df, street_geo_aggregated_df):
        df_copy = df.copy()

        # Standardize core columns
        df_copy.rename(columns={'Street Name': 'street_name', 'Violation Description': 'violation_type'}, inplace=True)
        
        # Merge parking violation codes
        if 'violation_type' in df_copy.columns and not parking_codes_unique_df.empty:
            df_copy['violation_type_lower'] = df_copy['violation_type'].str.lower().str.strip()
            df_copy = pd.merge(df_copy, parking_codes_unique_df, on='violation_type_lower', how='left')
            df_copy.drop(columns=['violation_type_lower'], errors='ignore', inplace=True) # Drop temp column after merge
        else:
            df_copy['violation_code'] = np.nan
            df_copy['violation_definition'] = np.nan

        # Merge street geographic data
        if 'street_name' in df_copy.columns and not street_geo_aggregated_df.empty:
            df_copy['street_name_lower'] = df_copy['street_name'].str.lower().str.strip()
            df_copy = pd.merge(df_copy, street_geo_aggregated_df, on='street_name_lower', how='left')
            df_copy.drop(columns=['street_name_lower'], errors='ignore', inplace=True) # Drop temp column after merge
        else:
            for col in ['borough', 'latitude', 'longitude', 'segment_length', 'zip_code']:
                df_copy[col] = np.nan

        return df_copy

    # Apply feature engineering to training data
    train_df = apply_feature_engineering(train_df_raw, parking_codes_df_unique, street_geo_agg)
    
    # Define target
    TARGET = 'violation_count'
    
    # Ensure 'violation_count' is numeric and non-negative
    if TARGET not in train_df.columns:
        print(f"Error: Target column '{TARGET}' not found in training data. Cannot proceed.")
        return
    
    train_df[TARGET] = pd.to_numeric(train_df[TARGET], errors='coerce').fillna(0).astype(int)
    train_df = train_df[train_df[TARGET] >= 0] # Filter out any remaining negative counts

    # --- Feature Selection and Type Handling for CatBoost ---
    
    # Identify categorical and numerical features
    categorical_features = ['street_name', 'violation_type', 'violation_code', 'violation_definition', 'borough', 'zip_code']
    numerical_features = ['latitude', 'longitude', 'segment_length']

    # Filter available features based on columns in train_df
    final_categorical_features = [col for col in categorical_features if col in train_df.columns]
    final_numerical_features = [col for col in numerical_features if col in train_df.columns]
    
    # Fill NaN values for CatBoost
    for col in final_categorical_features:
        train_df[col] = train_df[col].fillna('Unknown_Category').astype(str) # CatBoost expects strings for categorical
    for col in final_numerical_features:
        train_df[col] = train_df[col].fillna(0.0).astype(float) # Fill with 0.0 for numerical NaNs

    # Prepare data for CatBoost
    X = train_df[final_categorical_features + final_numerical_features]
    y = train_df[TARGET]

    # Split 2022 data for validation (80% train, 20% validation)
    X_train_model, X_val, y_train_model, y_val = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    print(f"Training data shape: {X_train_model.shape}")
    print(f"Validation data shape: {X_val.shape}")

    # Identify categorical feature indices for CatBoost
    cat_features_indices = [X_train_model.columns.get_loc(col) for col in final_categorical_features]

    # Initialize CatBoost Regressor
    model_catboost = CatBoostRegressor(
        iterations=200,
        learning_rate=0.05,
        depth=6,
        loss_function='RMSE', # Suitable for RMSE metric
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Suppress verbose output
        cat_features=cat_features_indices,
        allow_unseen_features=True # Allow unseen categories in test data
    )

    # Train the model
    print("Starting CatBoost Regressor training...")
    model_catboost.fit(X_train_model, y_train_model,
                       early_stopping_rounds=20, # Use early stopping for robustness
                       eval_set=(X_val, y_val))
    print("Model training complete.")

    # --- Validation Performance ---
    val_predictions = model_catboost.predict(X_val)
    val_predictions = np.maximum(0, np.round(val_predictions)).astype(int) # Clip to non-negative and round to integer
    final_validation_score = rmse(y_val, val_predictions)
    print(f"Final Validation Performance: {final_validation_score}")

    # --- Prediction for Test Data (if provided) ---
    if args.test_path:
        test_violations_file = os.path.join(INPUT_DIR, args.test_path)
        print(f"Loading test data from: {test_violations_file}")
        try:
            test_df_raw = pd.read_csv(test_violations_file)
        except FileNotFoundError as e:
            print(f"Error loading test data: {e}")
            print(f"Please ensure the test file '{args.test_path}' is present in the '{INPUT_DIR}' directory.")
            return

        # Keep original 'Street Name' and 'Violation Description' for submission output
        submission_output_df = test_df_raw[['Street Name', 'Violation Description']].copy()
        
        # Apply the exact same feature engineering steps as training data
        test_df = apply_feature_engineering(test_df_raw, parking_codes_df_unique, street_geo_agg)
        
        # Fill NaN values for CatBoost consistently with training data
        for col in final_categorical_features:
            if col in test_df.columns:
                test_df[col] = test_df[col].fillna('Unknown_Category').astype(str)
            else: # Add missing categorical columns filled with a default
                test_df[col] = 'Unknown_Category'
        for col in final_numerical_features:
            if col in test_df.columns:
                test_df[col] = test_df[col].fillna(0.0).astype(float)
            else: # Add missing numerical columns filled with a default
                test_df[col] = 0.0

        # Prepare test features for CatBoost
        X_test = test_df[final_categorical_features + final_numerical_features]
        
        # Identify unseen key pairs (street_name, violation_type)
        # Using the original (ungrouped) values for this check
        train_keys = set(train_df_raw.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1))
        test_keys = set(test_df_raw.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1))
        unseen_keys_count = len(test_keys - train_keys)
        print(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_keys_count}")

        # Generate predictions for the test data
        print("Generating predictions for test data...")
        test_predictions = model_catboost.predict(X_test)
        test_predictions = np.maximum(0, np.round(test_predictions)).astype(int)

        # Create submission file as specified
        submission_output_df['predicted_count'] = test_predictions
        submission_output_df.rename(columns={'Street Name': 'street_name', 'Violation Description': 'violation_type'}, inplace=True)
        submission_output_df.to_csv('submission.csv', index=False)
        print("Submission file 'submission.csv' created.")

        # If test_df_raw has 'violation_count' (ground truth), calculate and report test RMSE
        test_target_col_name_raw = 'violation_count' 
        
        if test_target_col_name_raw in test_df_raw.columns and not test_df_raw[test_target_col_name_raw].isnull().all():
            test_true_counts_for_eval = pd.to_numeric(test_df_raw[test_target_col_name_raw], errors='coerce')
            valid_test_rows_for_eval = test_true_counts_for_eval.notna()
            
            test_true_counts = test_true_counts_for_eval[valid_test_rows_for_eval].astype(int)
            test_predictions_for_valid_rows = test_predictions[valid_test_rows_for_eval.values]

            if not test_true_counts.empty:
                test_rmse = rmse(test_true_counts, test_predictions_for_valid_rows)
                print(f"Test Set RMSE (against ground truth): {test_rmse}")
            else:
                print("No valid ground truth 'violation_count' available in test file for RMSE calculation.")
        else:
            print("No ground truth 'violation_count' in test file, skipping test RMSE calculation.")

if __name__ == "__main__":
    main()
