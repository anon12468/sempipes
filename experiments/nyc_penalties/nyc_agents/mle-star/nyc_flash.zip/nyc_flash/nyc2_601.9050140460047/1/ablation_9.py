
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os
from sklearn.feature_extraction.text import TfidfVectorizer

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        return None
    except pd.errors.EmptyDataError:
        return pd.DataFrame()
    except Exception as e:
        return None

def train_and_evaluate(train_df, use_tfidf_features, use_frequency_features):
    """
    Trains and evaluates the CatBoost model with specified feature sets.
    Returns the validation RMSE.
    """
    df = train_df.copy() # Work on a copy to avoid modifying original DataFrame

    # Standard preprocessing steps
    df['street_name'] = df['street_name'].astype(str)
    df['violation_description'] = df['violation_description'].astype(str)
    df['street_name'] = df['street_name'].fillna('UNKNOWN_STREET')
    df['violation_description'] = df['violation_description'].fillna('UNKNOWN_VIOLATION')
    df['violation_count'] = pd.to_numeric(df['violation_count'], errors='coerce')
    df['violation_count'] = df['violation_count'].fillna(0)
    df['violation_count'] = df['violation_count'].clip(lower=0)

    # Base Enhanced Feature Engineering (present in the original solution before recent additions)
    df['violation_description_length'] = df['violation_description'].apply(len)
    df['violation_description_word_count'] = df['violation_description'].apply(lambda x: len(str(x).split()))
    df['street_name_desc_len_interaction'] = \
        df['street_name'].astype(str) + '_' + df['violation_description_length'].astype(str)
    df['street_name_desc_len_interaction'] = df['street_name_desc_len_interaction'].astype(str)

    # Initialize feature list with base features
    features_to_use = [
        'street_name',
        'violation_description_length',
        'violation_description_word_count',
        'street_name_desc_len_interaction'
    ]
    
    # Conditionally add TF-IDF features
    if use_tfidf_features:
        tfidf_vectorizer = TfidfVectorizer(max_features=200, stop_words='english')
        description_text = df['violation_description'].fillna('')
        tfidf_description_matrix = tfidf_vectorizer.fit_transform(description_text)
        tfidf_feature_names = tfidf_vectorizer.get_feature_names_out()
        tfidf_df = pd.DataFrame(tfidf_description_matrix.toarray(),
                                columns=[f'tfidf_{col}' for col in tfidf_feature_names],
                                index=df.index)
        df = pd.concat([df, tfidf_df], axis=1)
        features_to_use.extend([f'tfidf_{col}' for col in tfidf_feature_names])

    # Conditionally add Frequency-based features
    if use_frequency_features:
        df['street_name_frequency'] = df['street_name'].map(df['street_name'].value_counts(normalize=True))
        df['violation_description_frequency'] = df['violation_description'].map(df['violation_description'].value_counts(normalize=True))
        df['street_desc_freq_interaction'] = df['street_name_frequency'] * df['violation_description_frequency']
        features_to_use.extend([
            'street_name_frequency',
            'violation_description_frequency',
            'street_desc_freq_interaction'
        ])
    
    # Fill any NaNs that might result from .map() for frequency features if a value was not present
    for col in ['street_name_frequency', 'violation_description_frequency', 'street_desc_freq_interaction']:
        if col in features_to_use and col in df.columns:
            df[col] = df[col].fillna(0)

    target = 'violation_count'
    X = df[features_to_use]
    y = np.log1p(df[target])

    # Identify categorical features
    categorical_features_indices = [i for i, col in enumerate(features_to_use) if X[col].dtype == 'object']

    # Split data for validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    # CatBoost model training
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.03,
        depth=9,
        l2_leaf_reg=3,
        eval_metric='RMSE',
        random_seed=42,
        verbose=0,
        early_stopping_rounds=100,
        thread_count=-1
    )

    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices)

    model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=100, verbose=False)

    # Validation and RMSE calculation
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log)
    val_predictions[val_predictions < 0] = 0 # Ensure predictions are non-negative

    rmse_val = np.sqrt(mean_squared_error(np.expm1(y_val), val_predictions))
    return rmse_val

def main_ablation_study():
    parser = argparse.ArgumentParser(description="Ablation study for NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV relative to INPUT_DIR.')
    args = parser.parse_args()

    INPUT_DIR = './input'
    TRAIN_FILE = args.train_path

    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)
    base_train_df = load_data(train_df_path)

    if base_train_df is None or base_train_df.empty:
        return

    results = {}

    # Baseline: All new features included
    baseline_rmse = train_and_evaluate(base_train_df, use_tfidf_features=True, use_frequency_features=True)
    results['Baseline (All new features)'] = baseline_rmse

    # Ablation 1: Remove TF-IDF features
    ablation1_rmse = train_and_evaluate(base_train_df, use_tfidf_features=False, use_frequency_features=True)
    results['Ablation 1 (No TF-IDF features)'] = ablation1_rmse

    # Ablation 2: Remove Frequency-based features
    ablation2_rmse = train_and_evaluate(base_train_df, use_tfidf_features=True, use_frequency_features=False)
    results['Ablation 2 (No Frequency-based features)'] = ablation2_rmse

    # Ablation 3: Remove both TF-IDF and Frequency-based features
    ablation3_rmse = train_and_evaluate(base_train_df, use_tfidf_features=False, use_frequency_features=False)
    results['Ablation 3 (No TF-IDF and No Frequency features)'] = ablation3_rmse

    # Print results for each ablation
    for name, rmse in results.items():
        print(f"{name}: RMSE = {rmse:.4f}")

    # Determine which part contributes the most
    baseline_rmse = results['Baseline (All new features)']

    changes_from_baseline = {
        'TF-IDF features': ablation1_rmse - baseline_rmse,
        'Frequency-based features': ablation2_rmse - baseline_rmse,
        'Both TF-IDF and Frequency-based features': ablation3_rmse - baseline_rmse
    }

    most_beneficial_component = None
    max_degradation = 0 # Represents the largest increase in RMSE upon removal (i.e., component was beneficial)

    for component, change in changes_from_baseline.items():
        if change > max_degradation:
            max_degradation = change
            most_beneficial_component = component
    
    most_detrimental_component = None
    max_improvement_from_removal = 0 # Represents the largest decrease in RMSE upon removal (i.e., component was detrimental)

    for component, change in changes_from_baseline.items():
        if change < max_improvement_from_removal:
            max_improvement_from_removal = change
            most_detrimental_component = component

    # Print conclusion about the most contributing part
    if most_beneficial_component and max_degradation > 0.001: # Use a small threshold for meaningful change
        print(f"The part of the code that contributes the most positively to the overall performance is: "
              f"'{most_beneficial_component}'. Its presence improved RMSE by approximately {max_degradation:.4f}.")
    elif most_detrimental_component and max_improvement_from_removal < -0.001: # Use a small threshold for meaningful change
        print(f"The part of the code that contributes the most negatively (i.e., is most detrimental) to the overall performance is: "
              f"'{most_detrimental_component}'. Its removal improved RMSE by approximately {-max_improvement_from_removal:.4f}.")
    else:
        print("No single ablated component had a significantly large positive or negative impact on performance based on this study.")

if __name__ == "__main__":
    main_ablation_study()
