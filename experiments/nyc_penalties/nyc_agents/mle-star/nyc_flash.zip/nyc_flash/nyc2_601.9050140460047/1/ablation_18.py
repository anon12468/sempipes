
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os
import glob
from sklearn.preprocessing import LabelEncoder # Import LabelEncoder

# Ensure required libraries are installed
# You may need to run:
# pip install pandas numpy scikit-learn catboost

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return None
    except pd.errors.EmptyDataError:
        print(f"Warning: File is empty at {file_path}")
        return pd.DataFrame() # Return empty DataFrame to avoid further errors
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return None

def preprocess_data(df):
    """
    Performs basic data preparation and feature engineering.
    This function creates all features that might be used in any ablation.
    """
    df['street_name'] = df['street_name'].astype(str).fillna('UNKNOWN_STREET')
    df['violation_description'] = df['violation_description'].astype(str).fillna('UNKNOWN_VIOLATION')
    df['violation_count'] = pd.to_numeric(df['violation_count'], errors='coerce').fillna(0).clip(lower=0)

    # Feature Engineering (create all possible features here)
    df['violation_description_length'] = df['violation_description'].apply(len)
    df['violation_description_word_count'] = df['violation_description'].apply(lambda x: len(x.split()))
    
    # Label encode violation_description for the ablation where it's treated numerically
    le = LabelEncoder()
    # Apply fit_transform only if the column has not been encoded before
    # or if we are sure it's a fresh run. For safety, re-encode.
    df['violation_description_le'] = le.fit_transform(df['violation_description'])

    df['street_name_desc_len_interaction'] = \
        df['street_name'].astype(str) + '_' + df['violation_description_length'].astype(str)
    df['street_name_desc_len_interaction'] = df['street_name_desc_len_interaction'].astype(str)

    return df

def train_and_evaluate(
    df_processed, # Now takes an already processed DataFrame
    features_to_use,
    categorical_features_names_to_use,
    catboost_params,
    apply_log1p_target=True
):
    """
    Trains and evaluates a CatBoost model based on specified features and parameters.
    The DataFrame 'df_processed' is expected to already contain all necessary engineered features.
    """
    df = df_processed.copy()

    # Ensure all features_to_use are present in the DataFrame
    missing_features = [f for f in features_to_use if f not in df.columns]
    if missing_features:
        raise ValueError(f"Missing features in processed DataFrame: {missing_features}")

    target = 'violation_count'
    
    # Select features for X based on the `features_to_use` list.
    X = df[features_to_use]
    y = np.log1p(df[target]) if apply_log1p_target else df[target]

    # Identify categorical features by their column names for CatBoost
    # Ensure only features actually present in X are considered categorical
    categorical_features_indices = [i for i, col in enumerate(X.columns) if col in categorical_features_names_to_use]

    # --- 4. Split Training Data for Validation ---
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    # Create CatBoost Pool objects
    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices)

    # --- 5. Model Training ---
    model = CatBoostRegressor(**catboost_params)

    model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=catboost_params.get('early_stopping_rounds', 100), verbose=False)

    # --- 6. Validation ---
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log) if apply_log1p_target else val_predictions_log
    val_predictions[val_predictions < 0] = 0

    true_val_original_scale = np.expm1(y_val) if apply_log1p_target else y_val
    rmse_val = np.sqrt(mean_squared_error(true_val_original_scale, val_predictions))
    return rmse_val

def main_ablation_study():
    INPUT_DIR = './input'
    TRAIN_FILE = 'violations_per_street_2022.csv'
    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)
    print(f"Loading training data from: {train_df_path}")
    train_df_original = load_data(train_df_path)

    if train_df_original is None or train_df_original.empty:
        print("Training data could not be loaded or is empty. Exiting.")
        return

    # Preprocess the data once to create all potential features
    df_processed = preprocess_data(train_df_original.copy())

    # Base features and categorical features from the original solution
    # Note: 'violation_description' is the string version, 'violation_description_le' is the label-encoded numerical version.
    base_features = [
        'street_name',
        'violation_description', # Use the string version for baseline
        'violation_description_length',
        'violation_description_word_count',
        'street_name_desc_len_interaction'
    ]
    base_categorical_features = [
        'street_name',
        'violation_description', # Explicitly categorical in baseline
        'street_name_desc_len_interaction'
    ]
    base_catboost_params = {
        'iterations': 1000,
        'learning_rate': 0.03,
        'depth': 9,
        'l2_leaf_reg': 3,
        'eval_metric': 'RMSE',
        'random_seed': 42,
        'verbose': 0,
        'early_stopping_rounds': 100,
        'thread_count': -1,
    }

    results = {}

    # --- Baseline Run ---
    print("\n--- Running Baseline Model ---")
    baseline_rmse = train_and_evaluate(
        df_processed,
        base_features,
        base_categorical_features,
        base_catboost_params
    )
    print(f"Baseline Validation RMSE: {baseline_rmse:.4f}")
    results['Baseline'] = baseline_rmse

    # --- Ablation 1: Don't treat 'violation_description' as categorical (treat as numerical via Label Encoding) ---
    # This means 'violation_description' is still a feature in X, but CatBoost will treat it numerically
    # (via Label Encoding here) rather than leveraging its native categorical handling.
    print("\n--- Running Ablation 1: 'violation_description' treated as numerical (Label Encoded) ---")
    # For ablation 1, replace 'violation_description' with its label-encoded version in features
    ablation1_features = [f for f in base_features if f != 'violation_description']
    ablation1_features.append('violation_description_le') # Add the numerical version

    # Ensure 'violation_description_le' is NOT treated as categorical for CatBoost
    ablation1_cat_features = [f for f in base_categorical_features if f != 'violation_description']
    # 'violation_description_le' is a numerical column, so it won't be in this list, which is the desired behavior.

    ablation1_rmse = train_and_evaluate(
        df_processed,
        ablation1_features,
        ablation1_cat_features,
        base_catboost_params
    )
    print(f"Ablation 1 Validation RMSE (violation_description Label Encoded, not explicit categorical): {ablation1_rmse:.4f}")
    results['Ablation 1: "violation_description" treated as numerical (LE)'] = ablation1_rmse

    # --- Ablation 2: Set l2_leaf_reg=0 (disable L2 regularization) ---
    print("\n--- Running Ablation 2: CatBoost l2_leaf_reg=0 ---")
    ablation2_catboost_params = base_catboost_params.copy()
    ablation2_catboost_params['l2_leaf_reg'] = 0
    ablation2_rmse = train_and_evaluate(
        df_processed,
        base_features, # Use baseline features
        base_categorical_features, # Use baseline categorical features
        ablation2_catboost_params
    )
    print(f"Ablation 2 Validation RMSE (l2_leaf_reg=0): {ablation2_rmse:.4f}")
    results['Ablation 2: CatBoost l2_leaf_reg=0'] = ablation2_rmse

    # --- Ablation 3: Remove 'street_name_desc_len_interaction' feature ---
    print("\n--- Running Ablation 3: Remove 'street_name_desc_len_interaction' feature ---")
    ablation3_features = [f for f in base_features if f != 'street_name_desc_len_interaction']
    ablation3_cat_features = [f for f in base_categorical_features if f != 'street_name_desc_len_interaction']
    ablation3_rmse = train_and_evaluate(
        df_processed,
        ablation3_features,
        ablation3_cat_features,
        base_catboost_params
    )
    print(f"Ablation 3 Validation RMSE (no 'street_name_desc_len_interaction'): {ablation3_rmse:.4f}")
    results['Ablation 3: Removed "street_name_desc_len_interaction" feature'] = ablation3_rmse

    # --- Conclusion ---
    print("\n--- Ablation Study Results Summary ---")
    final_validation_score = -1 # Initialize with a default value

    for name, rmse in results.items():
        if name == 'Baseline':
            print(f"{name}: RMSE = {rmse:.4f}")
        else:
            diff = rmse - baseline_rmse
            print(f"{name}: RMSE = {rmse:.4f} (Change vs Baseline: {diff:+.4f})")
    
    # Determine which part contributed most positively
    # A smaller RMSE is better.
    # If baseline is the best, then its components are most beneficial.
    # If an ablation is the best, then the *change* made in that ablation (e.g., removal of a feature) is most beneficial.

    best_performance_key = min(results, key=results.get)
    best_rmse_value = results[best_performance_key]
    final_validation_score = best_rmse_value # Set final validation score to the best RMSE found

    print(f"\nConclusion: The best performing configuration achieved an RMSE of {best_rmse_value:.4f}.")
    
    if best_performance_key == 'Baseline':
        # If Baseline is the best, find which ablated component caused the largest degradation
        largest_degradation = 0
        most_beneficial_original_component = "N/A"
        for name, rmse in results.items():
            if name != 'Baseline':
                degradation = rmse - baseline_rmse # Positive value means original component was beneficial
                if degradation > largest_degradation:
                    largest_degradation = degradation
                    if "violation_description" in name: # Check for the specific change in Ablation 1
                        most_beneficial_original_component = "the explicit treatment of 'violation_description' as a categorical feature using CatBoost's native handling"
                    elif "l2_leaf_reg=0" in name:
                        most_beneficial_original_component = f"the CatBoost 'l2_leaf_reg' parameter set to {base_catboost_params['l2_leaf_reg']}"
                    elif "street_name_desc_len_interaction" in name:
                         most_beneficial_original_component = "the 'street_name_desc_len_interaction' feature"
                    else:
                         most_beneficial_original_component = f"the original configuration of '{name}'"
        
        if most_beneficial_original_component != "N/A":
            print(f"Specifically, {most_beneficial_original_component} contributed most positively to the overall performance, as its ablation caused the largest degradation (increase) in RMSE of {largest_degradation:.4f}.")
        else:
            print("No ablations showed a degradation compared to baseline. This suggests all original components were detrimental or neutral.")

    else:
        # If an ablation performed better than baseline, then the change made in that ablation was beneficial.
        largest_improvement = baseline_rmse - best_rmse_value # Positive value means ablation improved performance
        
        if "violation_description" in best_performance_key:
            print(f"The most positively contributing part was *treating 'violation_description' as a numerical feature (Label Encoded)*, which improved RMSE by {largest_improvement:.4f} compared to baseline.")
        elif "l2_leaf_reg=0" in best_performance_key:
            print(f"The most positively contributing part was *setting CatBoost's 'l2_leaf_reg' parameter to 0* (disabling L2 regularization), which improved RMSE by {largest_improvement:.4f} compared to baseline.")
        elif "street_name_desc_len_interaction" in best_performance_key:
             print(f"The most positively contributing part was *removing the 'street_name_desc_len_interaction' feature*, which improved RMSE by {largest_improvement:.4f} compared to baseline.")
        else:
            print(f"The part related to '{best_performance_key}' (as modified) contributed most positively to the overall performance, improving RMSE by {largest_improvement:.4f} compared to baseline.")

    print(f"Final Validation Performance: {final_validation_score}")

if __name__ == "__main__":
    main_ablation_study()
