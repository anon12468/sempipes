

import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os

# Ensure required libraries are installed
# You may need to run:
# pip install pandas numpy scikit-learn catboost

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        return None
    except pd.errors.EmptyDataError:
        return pd.DataFrame() # Return empty DataFrame to avoid further errors
    except Exception:
        return None

def run_experiment(
    use_violation_description_length: bool = True,
    use_violation_description_word_count: bool = True,
    catboost_random_seed: int = 42,
    train_test_split_random_state: int = 42
):
    """
    Runs a single experiment with specified configurations for ablation study.
    Returns the validation RMSE.
    """
    INPUT_DIR = './input'
    TRAIN_FILE = 'violations_per_street_2022.csv'

    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)
    train_df = load_data(train_df_path)

    if train_df is None or train_df.empty:
        return np.inf # Return infinity for failed experiment

    required_train_cols = ['street_name', 'violation_description', 'violation_count']
    if not all(col in train_df.columns for col in required_train_cols):
        return np.inf

    # --- Feature Engineering and Data Cleaning (unchanged across ablations) ---
    train_df['street_name'] = train_df['street_name'].astype(str)
    train_df['violation_description'] = train_df['violation_description'].astype(str)
    train_df['street_name'] = train_df['street_name'].fillna('UNKNOWN_STREET')
    train_df['violation_description'] = train_df['violation_description'].fillna('UNKNOWN_VIOLATION')

    train_df['violation_count'] = pd.to_numeric(train_df['violation_count'], errors='coerce')
    train_df['violation_count'] = train_df['violation_count'].fillna(0)
    train_df['violation_count'] = train_df['violation_count'].clip(lower=0)

    # Always create the enhanced features and interaction feature,
    # then control their inclusion in the `final_features` list.
    train_df['violation_description_length'] = train_df['violation_description'].apply(len)
    train_df['violation_description_word_count'] = train_df['violation_description'].apply(lambda x: len(str(x).split()))
    train_df['street_name_desc_len_interaction'] = \
        train_df['street_name'].astype(str) + '_' + train_df['violation_description_length'].astype(str)
    train_df['street_name_desc_len_interaction'] = train_df['street_name_desc_len_interaction'].astype(str)

    # --- Prepare Data for Model (features adjusted based on ablation flags) ---
    final_features = [
        'street_name',
        'violation_description',
        'street_name_desc_len_interaction'
    ]

    if use_violation_description_length:
        final_features.append('violation_description_length')
    
    if use_violation_description_word_count:
        final_features.append('violation_description_word_count')
    
    target = 'violation_count'

    X = train_df[final_features]
    y = np.log1p(train_df[target])

    # Identify categorical and text features for CatBoost
    categorical_cols_for_cb = ['street_name', 'street_name_desc_len_interaction']
    categorical_features_indices = [i for i, col in enumerate(final_features) if col in categorical_cols_for_cb]
    
    text_features_indices = [i for i, col in enumerate(final_features) if col == 'violation_description']

    # --- Split Training Data for Validation ---
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=train_test_split_random_state)

    # Create CatBoost Pool objects
    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices, text_features=text_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices, text_features=text_features_indices)

    # --- Model Training ---
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.03,
        depth=9,
        l2_leaf_reg=3,
        eval_metric='RMSE',
        random_seed=catboost_random_seed, # Ablation point 3: CatBoost model's random seed
        verbose=0,
        early_stopping_rounds=100,
        thread_count=-1,
    )

    model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=100, verbose=False)

    # --- Validation ---
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log)
    val_predictions[val_predictions < 0] = 0

    rmse_val = np.sqrt(mean_squared_error(np.expm1(y_val), val_predictions))
    return rmse_val


if __name__ == "__main__":
    # Ensure 'input' directory exists for data loading
    os.makedirs('./input', exist_ok=True)
    # Create a dummy CSV for the purpose of running this code standalone if actual data isn't present.
    # In a real Kaggle environment, 'violations_per_street_2022.csv' would be provided.
    dummy_data_path = './input/violations_per_street_2022.csv'
    if not os.path.exists(dummy_data_path):
        dummy_df = pd.DataFrame({
            'Street Name': ['MAIN ST', 'ELM AVE', 'OAK RD', 'MAIN ST', 'ELM AVE', 'PINE BLVD', 'MAIN ST', 'ELM AVE', 'OAK RD', 'CEDAR ST', 'BIRCH LN'],
            'Violation Description': ['PARKING IN NO STANDING ZONE', 'NO PARKING', 'DOUBLE PARKING', 'EXPIRED METER', 'PARKING IN NO STANDING ZONE', 'NO STANDING', 'EXPIRED METER', 'NO PARKING', 'DOUBLE PARKING', 'FIRE HYDRANT VIOLATION', 'WRONG SIDE OF STREET'],
            'Violation Count': [100, 150, 70, 120, 110, 80, 130, 160, 60, 95, 45]
        })
        dummy_df.to_csv(dummy_data_path, index=False)

    results = {}

    # --- Baseline ---
    print("Running Baseline experiment...")
    baseline_rmse = run_experiment()
    results['Baseline'] = baseline_rmse
    print(f"Baseline RMSE: {baseline_rmse:.4f}")

    # --- Ablation 1: Remove 'violation_description_length' feature ---
    # This feature has shown mixed results in previous studies; re-evaluating its impact.
    print("\nRunning Ablation 1: No 'violation_description_length' feature...")
    ablation1_rmse = run_experiment(use_violation_description_length=False)
    results["Ablation 1: No 'violation_description_length'"] = ablation1_rmse
    print(f"Ablation 1 RMSE: {ablation1_rmse:.4f}")

    # --- Ablation 2: Remove 'violation_description_word_count' feature ---
    # Another feature with inconsistent impact across previous ablation studies.
    print("\nRunning Ablation 2: No 'violation_description_word_count' feature...")
    ablation2_rmse = run_experiment(use_violation_description_word_count=False)
    results["Ablation 2: No 'violation_description_word_count'"] = ablation2_rmse
    print(f"Ablation 2 RMSE: {ablation2_rmse:.4f}")

    # --- Ablation 3: Change CatBoostRegressor random_seed to 101 ---
    # Isolating the impact of CatBoost's internal random seed, while train_test_split's remains fixed.
    print("\nRunning Ablation 3: CatBoostRegressor random_seed = 101 (train_test_split random_state = 42)...")
    ablation3_rmse = run_experiment(catboost_random_seed=101)
    results["Ablation 3: CatBoostRegressor random_seed = 101"] = ablation3_rmse
    print(f"Ablation 3 RMSE: {ablation3_rmse:.4f}")

    print("\n--- Ablation Study Summary ---")
    
    # Track the overall best performing configuration
    best_overall_rmse = baseline_rmse
    best_overall_config_name = "Baseline"

    # Track the component whose *presence* (or specific setting) was most beneficial in the original solution
    # (i.e., its removal/change caused the largest degradation)
    largest_degradation_impact = 0.0
    most_beneficial_original_component = "None identified (all ablations improved or had no effect compared to baseline)"

    for name, rmse in results.items():
        if name == 'Baseline':
            continue
        
        impact_vs_baseline = rmse - baseline_rmse # Positive if RMSE increased (degradation), negative if RMSE decreased (improvement)
        
        print(f"{name}: RMSE = {rmse:.4f}, Impact vs Baseline = {impact_vs_baseline:.4f}")

        if rmse < best_overall_rmse:
            best_overall_rmse = rmse
            best_overall_config_name = name
        
        if impact_vs_baseline > largest_degradation_impact:
            largest_degradation_impact = impact_vs_baseline
            if name == "Ablation 1: No 'violation_description_length'":
                most_beneficial_original_component = "'violation_description_length' feature"
            elif name == "Ablation 2: No 'violation_description_word_count'":
                most_beneficial_original_component = "'violation_description_word_count' feature"
            elif name == "Ablation 3: CatBoostRegressor random_seed = 101":
                most_beneficial_original_component = "CatBoostRegressor's original 'random_seed=42'"
            # Add conditions for other ablations if applicable

    print("\n--- Conclusion ---")
    if best_overall_config_name == "Baseline":
        print(f"The Baseline configuration achieved the best overall RMSE of {best_overall_rmse:.4f} among the tested scenarios.")
    else:
        # If an ablation improved performance, that modification itself contributed most.
        impact_best = best_overall_rmse - baseline_rmse
        if impact_best < 0: # Improvement
            print(f"The most impactful modification for optimal performance is '{best_overall_config_name}', which improved RMSE by {-impact_best:.4f}.")
        else: # Degradation (shouldn't happen if it's the best_overall_config_name unless baseline was worse)
            print(f"The most impactful modification for optimal performance is '{best_overall_config_name}', which achieved an RMSE of {best_overall_rmse:.4f}.")
            
    # Also state the most beneficial component from the original solution (if identified)
    if largest_degradation_impact > 0:
        print(f"The part of the code that contributed most positively to the overall performance (i.e., its removal or change caused the largest degradation) is: {most_beneficial_original_component} (Removing/changing it increased RMSE by {largest_degradation_impact:.4f}).")
    elif best_overall_config_name != "Baseline":
         # If the best overall config was an ablation that improved RMSE, and there was no degradation in other ablations,
         # then the *removal* or *change* leading to the improvement is the highest contributor.
         pass # Already printed as "most impactful modification for optimal performance"
    else:
        print("No specific part among the ablated ones showed a significantly positive contribution (or negative contribution leading to improvement); Baseline configuration is optimal or ablations had neutral/detrimental effects.")

