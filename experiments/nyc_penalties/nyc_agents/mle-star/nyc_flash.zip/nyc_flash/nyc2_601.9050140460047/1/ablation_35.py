
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os
import glob # Used for potential future data discovery/loading if augmentation tables are added

# Ensure required libraries are installed
# You may need to run:
# pip install pandas numpy scikit-learn catboost

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        # Create a dummy CSV for local testing if file not found
        if "violations_per_street_2022.csv" in file_path:
            print("Creating dummy violations_per_street_2022.csv for demonstration purposes.")
            dummy_data = {
                'Street Name': ['MAIN ST', 'OAK AVE', 'MAIN ST', 'ELM RD', 'OAK AVE', 'MAIN ST'],
                'Violation Description': ['PARKING METER EXPIRED', 'NO STANDING', 'DOUBLE PARKING', 'FIRE HYDRANT', 'PARKING METER EXPIRED', 'NO PARKING ANYTIME'],
                'Violation Count': [100, 50, 120, 30, 45, 110]
            }
            dummy_df = pd.DataFrame(dummy_data)
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            dummy_df.to_csv(file_path, index=False)
            print(f"Dummy file created at {file_path}. Please replace with actual data for meaningful results.")
            return load_data(file_path) # Retry loading
        return None
    except pd.errors.EmptyDataError:
        print(f"Warning: File is empty at {file_path}")
        return pd.DataFrame() # Return empty DataFrame to avoid further errors
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return None

def run_experiment(
    train_path: str,
    remove_violation_description_word_count: bool = False,
    remove_street_name_desc_len_interaction: bool = False,
    catboost_grow_policy: str = None # None means default 'SymmetricTree'
) -> float:
    """
    Runs the training and validation process with specified modifications.

    Args:
        train_path (str): Path to the training data CSV.
        remove_violation_description_word_count (bool): If True, removes 'violation_description_word_count'.
        remove_street_name_desc_len_interaction (bool): If True, removes 'street_name_desc_len_interaction'.
        catboost_grow_policy (str): CatBoost 'grow_policy' parameter. Defaults to None (SymmetricTree).

    Returns:
        float: The validation RMSE.
    """
    INPUT_DIR = './input'
    TRAIN_FILE = train_path

    # --- 1. Load Training Data ---
    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)
    train_df = load_data(train_df_path)

    if train_df is None or train_df.empty:
        print("Training data could not be loaded or is empty. Exiting experiment.")
        return float('inf')

    # Ensure required columns are present in the training data
    required_train_cols = ['street_name', 'violation_description', 'violation_count']
    if not all(col in train_df.columns for col in required_train_cols):
        print(f"Error: Training data missing one or more required columns: {required_train_cols}")
        print("Available columns:", train_df.columns.tolist())
        return float('inf')

    # --- 2. Feature Engineering and Augmentation ---
    train_df['street_name'] = train_df['street_name'].astype(str)
    train_df['violation_description'] = train_df['violation_description'].astype(str)
    train_df['street_name'] = train_df['street_name'].fillna('UNKNOWN_STREET')
    train_df['violation_description'] = train_df['violation_description'].fillna('UNKNOWN_VIOLATION')

    train_df['violation_count'] = pd.to_numeric(train_df['violation_count'], errors='coerce')
    train_df['violation_count'] = train_df['violation_count'].fillna(0)
    train_df['violation_count'] = train_df['violation_count'].clip(lower=0)

    # --- Enhanced Feature Engineering ---
    train_df['violation_description_length'] = train_df['violation_description'].apply(len)
    
    if not remove_violation_description_word_count:
        train_df['violation_description_word_count'] = train_df['violation_description'].apply(lambda x: len(str(x).split()))

    if not remove_street_name_desc_len_interaction:
        train_df['street_name_desc_len_interaction'] = \
            train_df['street_name'].astype(str) + '_' + train_df['violation_description_length'].astype(str)
        train_df['street_name_desc_len_interaction'] = train_df['street_name_desc_len_interaction'].astype(str)

    # --- 3. Prepare Data for Model ---
    features = [
        'street_name',
        'violation_description',
        'violation_description_length',
    ]
    if not remove_violation_description_word_count:
        features.append('violation_description_word_count')
    if not remove_street_name_desc_len_interaction:
        features.append('street_name_desc_len_interaction')

    target = 'violation_count'

    X = train_df[features]
    y = np.log1p(train_df[target])

    categorical_features_indices = [i for i, col in enumerate(features) if X[col].dtype == 'object']

    # --- 4. Split Training Data for Validation ---
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices)

    # --- 5. Model Training ---
    model_params = {
        'iterations': 1000,
        'learning_rate': 0.03,
        'depth': 9,
        'l2_leaf_reg': 3,
        'eval_metric': 'RMSE',
        'random_seed': 42,
        'verbose': 0,
        'early_stopping_rounds': 100,
        'thread_count': -1,
    }
    if catboost_grow_policy:
        model_params['grow_policy'] = catboost_grow_policy

    model = CatBoostRegressor(**model_params)

    model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=100, verbose=False)

    # --- 6. Validation ---
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log)
    val_predictions[val_predictions < 0] = 0

    rmse_val = np.sqrt(mean_squared_error(np.expm1(y_val), val_predictions))
    return rmse_val

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV relative to INPUT_DIR.')
    args = parser.parse_args()

    results = {}

    print("Running baseline model...")
    baseline_rmse = run_experiment(args.train_path)
    results['Baseline'] = baseline_rmse
    print(f"Baseline Validation RMSE: {baseline_rmse:.4f}\n")

    print("Running Ablation 1: Removing 'violation_description_word_count' feature...")
    ablation1_rmse = run_experiment(args.train_path, remove_violation_description_word_count=True)
    results['Ablation 1 (No violation_description_word_count)'] = ablation1_rmse
    print(f"Ablation 1 Validation RMSE: {ablation1_rmse:.4f}\n")

    print("Running Ablation 2: Removing 'street_name_desc_len_interaction' feature...")
    ablation2_rmse = run_experiment(args.train_path, remove_street_name_desc_len_interaction=True)
    results['Ablation 2 (No street_name_desc_len_interaction)'] = ablation2_rmse
    print(f"Ablation 2 Validation RMSE: {ablation2_rmse:.4f}\n")

    print("Running Ablation 3: Changing CatBoost 'grow_policy' to 'Depthwise'...")
    ablation3_rmse = run_experiment(args.train_path, catboost_grow_policy='Depthwise')
    results['Ablation 3 (CatBoost grow_policy=Depthwise)'] = ablation3_rmse
    print(f"Ablation 3 Validation RMSE: {ablation3_rmse:.4f}\n")

    print("\n--- Ablation Study Summary ---")
    baseline_rmse = results['Baseline']
    print(f"Baseline RMSE: {baseline_rmse:.4f}")

    best_rmse = baseline_rmse
    best_config_name = "Baseline"
    
    performance_changes = {}

    for name, rmse in results.items():
        if name == 'Baseline':
            continue
        change = rmse - baseline_rmse
        performance_changes[name] = change
        print(f"{name}: RMSE {rmse:.4f} (Change vs Baseline: {change:+.4f})")
        
        # Track overall best performance
        if rmse < best_rmse:
            best_rmse = rmse
            best_config_name = name

    print("\n--- Conclusion ---")
    if best_config_name == "Baseline":
        print(f"The Baseline configuration achieved the best performance (RMSE: {best_rmse:.4f}).")
    else:
        print(f"The best performing configuration was '{best_config_name}' with an RMSE of {best_rmse:.4f}.")

    most_impactful_change_name = None
    max_abs_impact = 0

    for name, change in performance_changes.items():
        if abs(change) > max_abs_impact:
            max_abs_impact = abs(change)
            most_impactful_change_name = name

    if most_impactful_change_name:
        impact_value = performance_changes[most_impactful_change_name]
        if impact_value > 0:
            print(f"The part of the code that contributed most negatively to overall performance was '{most_impactful_change_name}', as its modification increased RMSE by {impact_value:.4f}.")
        else:
            print(f"The part of the code that contributed most positively to overall performance was '{most_impactful_change_name}', as its modification improved RMSE by {-impact_value:.4f}.")
    else:
        print("No significant impact observed from the ablations.")


if __name__ == "__main__":
    main()
