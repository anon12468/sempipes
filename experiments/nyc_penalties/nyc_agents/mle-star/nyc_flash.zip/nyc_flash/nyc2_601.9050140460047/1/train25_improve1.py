
import pandas as pd
import numpy as np
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import mean_squared_error
import argparse
import os

# --- Configuration ---
DEFAULT_TRAIN_PATH = "./input/violations_per_street_2022.csv"
SUBMISSION_FILE = "submission.csv"

# --- Helper Functions ---
def rmse(y_true, y_pred):
    """
    Calculates the Root Mean Squared Error (RMSE).
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def load_data(file_path):
    """
    Loads data from a CSV file, normalizes column names, and checks for required columns.
    Returns None if file not found or required columns are missing.
    """
    if not os.path.exists(file_path):
        print(f"Error: File not found at {file_path}")
        return None
    
    try:
        df = pd.read_csv(file_path)
    except Exception as e:
        print(f"Error reading CSV file {file_path}: {e}")
        return None
    
    # Normalize column names: strip spaces, replace spaces with underscores, lowercase
    df.columns = [col.strip().replace(' ', '_').lower() for col in df.columns]
    
    # Expected core schema columns after normalization
    # 'Street Name' -> 'street_name', 'Violation Description' -> 'violation_description'
    required_cols = ['street_name', 'violation_description']
    
    # Check for presence of these columns
    if not all(col in df.columns for col in required_cols):
        missing_cols = [col for col in required_cols if col not in df.columns]
        print(f"Error: Required columns {missing_cols} not found in {file_path}.")
        print(f"Available columns: {df.columns.tolist()}")
        return None
            
    return df

def feature_engineer(df, is_train=True, encoders=None, train_raw_df_for_unseen_check=None):
    """
    Performs feature engineering including label encoding and basic text features.
    Handles unseen categories during transformation by assigning a new category ID.
    Also calculates the count of unseen (street_name, violation_description) pairs in test mode.
    """
    if encoders is None:
        encoders = {
            'street_name': LabelEncoder(),
            'violation_description': LabelEncoder(),
        }
    
    # Make copies of original columns before modification for feature extraction and unseen checks
    original_street_names = df['street_name'].copy()
    original_violation_descriptions = df['violation_description'].copy()
    
    # Handle NaN values for categorical features before encoding
    df['street_name'] = df['street_name'].fillna('UNKNOWN_STREET').astype(str)
    df['violation_description'] = df['violation_description'].fillna('UNKNOWN_VIOLATION').astype(str)

    encoded_features = []
    for col_name, encoder in encoders.items():
        if is_train:
            df[col_name + '_encoded'] = encoder.fit_transform(df[col_name])
        else:
            # For test data, map existing categories and assign a new ID for unseen ones
            mapping = {cls: i for i, cls in enumerate(encoder.classes_)}
            # Using len(encoder.classes_) as a dedicated ID for unseen categories
            # astype(int) is crucial as fillna might return float if no NaNs initially
            df[col_name + '_encoded'] = df[col_name].map(mapping).fillna(len(encoder.classes_)).astype(int)
        encoded_features.append(col_name + '_encoded')

    # Add simple numerical features derived from text data
    df['street_name_len'] = df['street_name'].apply(len)
    df['violation_desc_len'] = df['violation_description'].apply(len)
    df['violation_desc_word_count'] = df['violation_description'].apply(lambda x: len(str(x).split()))

    # Placeholder for more complex augmentations or external data joins.
    # Example:
    # try:
    #     street_attributes_df = pd.read_csv("./input/street_attributes.csv")
    #     street_attributes_df.columns = [col.strip().replace(' ', '_').lower() for col in street_attributes_df.columns]
    #     df = pd.merge(df, street_attributes_df[['street_name', 'some_numeric_attr']], on='street_name', how='left')
    #     df['some_numeric_attr'] = df['some_numeric_attr'].fillna(df['some_numeric_attr'].median())
    # except FileNotFoundError:
    #     print("Warning: street_attributes.csv not found for augmentation.")

    unseen_keys_count = 0
    if not is_train and train_raw_df_for_unseen_check is not None:
        # Create a set of (street_name, violation_description) from the original training data
        # Ensure 'street_name' and 'violation_description' are treated as strings for consistent hashing
        train_key_set = set(zip(train_raw_df_for_unseen_check['street_name'].astype(str),
                                train_raw_df_for_unseen_check['violation_description'].astype(str)))
        
        # Create a set of (street_name, violation_description) from the current (test) dataframe
        current_key_set = set(zip(original_street_names.astype(str), original_violation_descriptions.astype(str)))
        
        # Count keys in the current set that are not in the training set
        unseen_keys_count = len(current_key_set - train_key_set)
        
    return df, encoders, unseen_keys_count

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument("--train-path", type=str, default=DEFAULT_TRAIN_PATH,
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Optional: Path to the test/evaluation data CSV for 2023 predictions.")
    
    args = parser.parse_args()

    # --- Load Training Data ---
    print(f"Loading training data from {args.train_path}...")
    train_df_raw = load_data(args.train_path)
    if train_df_raw is None:
        print("Failed to load training data. Exiting.")
        return # Graceful exit

    print(f"Training data loaded. Shape: {train_df_raw.shape}")

    # --- Data Cleaning and Preprocessing (initial for training data) ---
    # Ensure 'violation_count' column exists and is numeric
    if 'violation_count' not in train_df_raw.columns:
        print("Error: 'violation_count' column not found in training data. Exiting.")
        return
    
    train_df_raw['violation_count'] = pd.to_numeric(train_df_raw['violation_count'], errors='coerce')
    train_df_raw = train_df_raw.dropna(subset=['violation_count'])
    train_df_raw = train_df_raw[train_df_raw['violation_count'] >= 0]
    
    # --- Feature Engineering for Training Data ---
    print("Performing feature engineering on training data...")
    train_df, encoders, _ = feature_engineer(train_df_raw.copy(), is_train=True)

    # --- Prepare for Training ---
    # Dynamically select features, including encoded ones and new numerical ones
    features = [col for col in train_df.columns if col.endswith('_encoded') or col.endswith('_len') or col.endswith('_word_count')]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    # --- Training/Validation Split ---
    # Using a simple random split for development validation.
    # For count data, a grouped split might be more appropriate if there are large discrepancies
    # between groups. However, for initial modeling, a random split is often sufficient.
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    
    print(f"Training on {len(X_train)} samples, validating on {len(X_val)} samples.")

    # --- Model Training ---
    # Using LightGBM Regressor - generally fast and memory-efficient
    lgb_params = {
        'objective': 'regression_l1', # MAE objective, robust to outliers, good for counts
        'metric': 'rmse',             # Evaluation metric
        'n_estimators': 1500,         # Increased estimators for potentially better accuracy
        'learning_rate': 0.03,        # Slightly reduced learning rate
        'feature_fraction': 0.8,      # Fraction of features considered per iteration
        'bagging_fraction': 0.8,      # Fraction of data considered per iteration
        'bagging_freq': 1,            # Perform bagging at every iteration
        'verbose': -1,                # Suppress verbose output during training
        'n_jobs': -1,                 # Use all available cores
        'seed': 42,
        'boosting_type': 'gbdt',
    }
    
    model = lgb.LGBMRegressor(**lgb_params)
    
    # Use callbacks for early stopping to prevent overfitting and save training time
    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              callbacks=[lgb.early_stopping(stopping_rounds=100, verbose=False)])

    # --- Evaluate on Validation Set ---
    val_predictions = model.predict(X_val)
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions as counts cannot be negative
    validation_rmse = rmse(y_val, val_predictions)
    # Required output format for validation performance
    print(f"Final Validation Performance: {validation_rmse}")

    # --- Prediction on Test Data (if provided) ---
    if args.test_path:
        print(f"\nLoading test data from {args.test_path}...")
        test_df_raw = load_data(args.test_path)
        if test_df_raw is None:
            print("Failed to load test data. Skipping prediction.")
            return

        print(f"Test data loaded. Shape: {test_df_raw.shape}")

        # Store original keys for submission
        submission_keys = test_df_raw[['street_name', 'violation_description']].copy()

        # Handle 'violation_count' if present in test_df_raw (for evaluation)
        test_ground_truth = None
        if 'violation_count' in test_df_raw.columns:
            # Convert to numeric, coerce errors. Drop NaNs for robust RMSE calculation.
            temp_ground_truth = pd.to_numeric(test_df_raw['violation_count'], errors='coerce')
            
            # Align ground truth with predictions by only considering rows where GT is not NaN
            # This requires careful indexing. For simplicity here, we assume if `violation_count`
            # exists, it's mostly clean. For RMSE, we drop NaNs from GT.
            test_ground_truth_indices = temp_ground_truth.dropna().index
            test_ground_truth = temp_ground_truth.loc[test_ground_truth_indices]
            
            # Ensure we don't use it as a feature by dropping from the raw df copy
            test_df_raw.drop(columns=['violation_count'], inplace=True, errors='ignore')
        
        # Feature engineer test data using encoders from training and calculate unseen keys
        # Pass the original training data to feature_engineer to enable unseen key check
        test_df, _, unseen_keys_count = feature_engineer(test_df_raw.copy(), is_train=False, encoders=encoders, train_raw_df_for_unseen_check=train_df_raw)

        print(f"Number of unseen (street_name, violation_description) pairs in test set: {unseen_keys_count}")

        # Ensure test features match training features (order and existence)
        X_test = test_df[features]
        
        # Predict
        print("Generating predictions for test data...")
        test_predictions = model.predict(X_test)
        test_predictions[test_predictions < 0] = 0 # Clip negative predictions
        
        # Round to nearest integer as counts are typically integers
        test_predictions = np.round(test_predictions).astype(int)

        # --- Create Submission File ---
        submission_df = submission_keys
        submission_df['predicted_count'] = test_predictions
        
        # Rename columns as per requirement: 'violation_description' -> 'violation_type'
        submission_df.rename(columns={
            'street_name': 'street_name',
            'violation_description': 'violation_type'
        }, inplace=True)

        submission_df.to_csv(SUBMISSION_FILE, index=False)
        print(f"Submission file '{SUBMISSION_FILE}' created successfully.")

        # --- Evaluate Test Predictions (if ground truth available) ---
        if test_ground_truth is not None and not test_ground_truth.empty:
            # It's crucial that test_predictions aligns with test_ground_truth's filtered indices.
            # Assuming test_predictions is generated for all rows in original test_df_raw,
            # we need to select corresponding predictions for available ground truth.
            
            # This assumes that the order of rows in `test_df_raw` is preserved through
            # `feature_engineer` and `model.predict`.
            # If `test_ground_truth` was filtered (e.g., for NaNs), then `test_predictions`
            # should also be filtered by the same indices.
            
            if len(test_predictions) == len(test_df_raw): # Check if predictions match original test_df_raw length
                 # Select predictions corresponding to available ground truth
                aligned_predictions = pd.Series(test_predictions, index=test_df_raw.index).loc[test_ground_truth.index]
                test_eval_rmse = rmse(test_ground_truth, aligned_predictions)
                print(f"Test Set RMSE (against provided ground truth): {test_eval_rmse}")
            else:
                print("Warning: Mismatch in prediction and original test data length. Cannot compute test RMSE precisely.")
        
    print("\nScript finished.")

if __name__ == "__main__":
    main()
