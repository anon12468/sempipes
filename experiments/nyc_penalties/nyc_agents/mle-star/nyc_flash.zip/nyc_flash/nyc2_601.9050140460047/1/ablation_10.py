
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os

# Ensure required libraries are installed
# You may need to run:
# pip install pandas numpy scikit-learn catboost

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        # print(f"Error: File not found at {file_path}") # Suppress for cleaner ablation output
        return None
    except pd.errors.EmptyDataError:
        # print(f"Warning: File is empty at {file_path}") # Suppress for cleaner ablation output
        return pd.DataFrame() # Return empty DataFrame to avoid further errors
    except Exception as e:
        # print(f"Error loading {file_path}: {e}") # Suppress for cleaner ablation output
        return None

def run_ablation_experiment(
    train_file='violations_per_street_2022.csv',
    test_size_ratio=0.2,
    catboost_depth_param=9,
    explicit_fillna_categorical=True,
):
    INPUT_DIR = './input'
    TRAIN_FILE = train_file

    # --- 1. Load Training Data ---
    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)
    train_df = load_data(train_df_path)

    if train_df is None or train_df.empty:
        print("Training data could not be loaded or is empty. Returning high RMSE.")
        return float('inf')

    # Ensure required columns are present in the training data
    required_train_cols = ['street_name', 'violation_description', 'violation_count']
    if not all(col in train_df.columns for col in required_train_cols):
        print(f"Error: Training data missing one or more required columns: {required_train_cols}. Returning high RMSE.")
        return float('inf')

    # --- 2. Feature Engineering and Augmentation ---
    # Convert categorical features to string type explicitly for CatBoost
    train_df['street_name'] = train_df['street_name'].astype(str)
    train_df['violation_description'] = train_df['violation_description'].astype(str)

    # Ablation point: explicit_fillna_categorical
    if explicit_fillna_categorical:
        train_df['street_name'] = train_df['street_name'].fillna('UNKNOWN_STREET')
        train_df['violation_description'] = train_df['violation_description'].fillna('UNKNOWN_VIOLATION')

    # Ensure target variable is numeric and handle potential NaNs (e.g., fill with 0 or mean)
    train_df['violation_count'] = pd.to_numeric(train_df['violation_count'], errors='coerce')
    train_df['violation_count'] = train_df['violation_count'].fillna(0)
    train_df['violation_count'] = train_df['violation_count'].clip(lower=0)

    # --- Enhanced Feature Engineering ---
    train_df['violation_description_length'] = train_df['violation_description'].apply(len)
    train_df['violation_description_word_count'] = train_df['violation_description'].apply(lambda x: len(str(x).split()))
    train_df['street_name_desc_len_interaction'] = \
        train_df['street_name'].astype(str) + '_' + train_df['violation_description_length'].astype(str)
    train_df['street_name_desc_len_interaction'] = train_df['street_name_desc_len_interaction'].astype(str)


    # --- 3. Prepare Data for Model ---
    features = [
        'street_name',
        'violation_description',
        'violation_description_length',
        'violation_description_word_count',
        'street_name_desc_len_interaction'
    ]
    target = 'violation_count'

    X = train_df[features]
    y = np.log1p(train_df[target])

    # Identify categorical features by their column names.
    categorical_features_indices = [i for i, col in enumerate(features) if X[col].dtype == 'object' or X[col].dtype == 'string']

    # --- 4. Split Training Data for Validation ---
    # Ablation point: test_size_ratio
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=test_size_ratio, random_state=42)

    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices)

    # --- 5. Model Training ---
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.03,
        depth=catboost_depth_param, # Ablation point: catboost_depth_param
        l2_leaf_reg=3,
        eval_metric='RMSE',
        random_seed=42,
        verbose=0,
        early_stopping_rounds=100,
        thread_count=-1,
    )

    model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=100, verbose=False)

    # --- 6. Validation ---
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log)
    val_predictions[val_predictions < 0] = 0

    rmse_val = np.sqrt(mean_squared_error(np.expm1(y_val), val_predictions))
    return rmse_val

if __name__ == "__main__":
    # Create a dummy input directory and file for demonstration
    os.makedirs('./input', exist_ok=True)
    dummy_data = {
        'Street Name': ['MAIN ST', 'ELM AVE', 'OAK BLVD', 'MAIN ST', 'ELM AVE', 'PINE LN', 'OAK BLVD', 'MAIN ST', 'ELM AVE', 'PINE LN', None, 'BROADWAY'],
        'Violation Description': ['PARKING METER', 'NO STANDING', 'FIRE HYDRANT', 'PARKING METER', 'DOUBLE PARKING', 'NO STANDING', None, 'DOUBLE PARKING', 'PARKING METER', 'NO STANDING', 'OTHER VIOLATION', 'PARKING METER'],
        'Violation Count': [100, 150, 50, 110, 160, 60, 55, 120, 140, 70, 80, 90]
    }
    dummy_df = pd.DataFrame(dummy_data)
    dummy_df.to_csv('./input/violations_per_street_2022.csv', index=False)


    # --- Baseline Run ---
    baseline_rmse = run_ablation_experiment(
        test_size_ratio=0.2,
        catboost_depth_param=9,
        explicit_fillna_categorical=True
    )
    print(f"Baseline Validation RMSE: {baseline_rmse:.4f}\n")

    # --- Ablation 1: Change `test_size` to 0.3 ---
    print("Running Ablation 1: Change `test_size` in train_test_split to 0.3...")
    ablation1_rmse = run_ablation_experiment(
        test_size_ratio=0.3,
        catboost_depth_param=9,
        explicit_fillna_categorical=True
    )
    print(f"Ablation 1 Validation RMSE (test_size=0.3): {ablation1_rmse:.4f}")
    print(f"Impact: {'Improved' if ablation1_rmse < baseline_rmse else 'Degraded'} by {(ablation1_rmse - baseline_rmse):.4f}\n")

    # --- Ablation 2: Remove explicit fillna for categorical features ---
    print("Running Ablation 2: Remove explicit fillna for categorical features (let CatBoost handle NaNs)...")
    ablation2_rmse = run_ablation_experiment(
        test_size_ratio=0.2,
        catboost_depth_param=9,
        explicit_fillna_categorical=False
    )
    print(f"Ablation 2 Validation RMSE (no explicit categorical fillna): {ablation2_rmse:.4f}")
    print(f"Impact: {'Improved' if ablation2_rmse < baseline_rmse else 'Degraded'} by {(ablation2_rmse - baseline_rmse):.4f}\n")

    # --- Ablation 3: Change CatBoost depth to 7 ---
    print("Running Ablation 3: Change CatBoost `depth` to 7...")
    ablation3_rmse = run_ablation_experiment(
        test_size_ratio=0.2,
        catboost_depth_param=7,
        explicit_fillna_categorical=True
    )
    print(f"Ablation 3 Validation RMSE (CatBoost depth=7): {ablation3_rmse:.4f}")
    print(f"Impact: {'Improved' if ablation3_rmse < baseline_rmse else 'Degraded'} by {(ablation3_rmse - baseline_rmse):.4f}\n")

    # Determine which part contributes the most
    results = {
        "Baseline": {"rmse": baseline_rmse, "description": "Original configuration"},
        "test_size_ratio=0.3": {"rmse": ablation1_rmse, "description": "Modified 'test_size' to 0.3"},
        "explicit_fillna_categorical=False": {"rmse": ablation2_rmse, "description": "Removed explicit categorical NaN filling"},
        "catboost_depth_param=7": {"rmse": ablation3_rmse, "description": "Modified CatBoost 'depth' to 7"},
    }

    # Calculate impacts relative to baseline
    impacts = {}
    for key, val in results.items():
        if key != "Baseline":
            impacts[key] = val["rmse"] - results["Baseline"]["rmse"]

    # Find the component whose *original* state was most beneficial (largest degradation when modified)
    most_beneficial_original_component = None
    largest_degradation = -float('inf') # Track largest positive change (degradation)

    for component_key, degradation in impacts.items():
        if degradation > largest_degradation:
            largest_degradation = degradation
            if component_key == "test_size_ratio=0.3":
                most_beneficial_original_component = "the 'test_size' parameter (original value: 0.2)"
            elif component_key == "explicit_fillna_categorical=False":
                most_beneficial_original_component = "explicit categorical NaN filling (original state: enabled)"
            elif component_key == "catboost_depth_param=7":
                most_beneficial_original_component = "the CatBoost 'depth' parameter (original value: 9)"
    
    # Print the conclusion
    if largest_degradation > 0:
        print(f"\nAmong the components ablated, {most_beneficial_original_component} contributes the most to the overall performance.")
        print(f"Its modification resulted in the largest degradation in RMSE (an increase of {largest_degradation:.4f}).")
    else:
        # If no modification caused degradation, then find the one that caused the largest improvement
        most_detrimental_original_component = None
        largest_improvement = float('inf') # Track largest negative change (improvement)

        for component_key, improvement in impacts.items():
            if improvement < largest_improvement:
                largest_improvement = improvement
                if component_key == "test_size_ratio=0.3":
                    most_detrimental_original_component = "the 'test_size' parameter (original value: 0.2)"
                elif component_key == "explicit_fillna_categorical=False":
                    most_detrimental_original_component = "explicit categorical NaN filling (original state: enabled)"
                elif component_key == "catboost_depth_param=7":
                    most_detrimental_original_component = "the CatBoost 'depth' parameter (original value: 9)"
        
        if largest_improvement < 0:
             print(f"\nAmong the components ablated, the original setting of {most_detrimental_original_component} had the most negative impact on performance.")
             print(f"Its modification resulted in the largest improvement in RMSE (a decrease of {abs(largest_improvement):.4f}).")
        else:
             print("\nAll ablated components had negligible or no impact on performance in this study.")

