

import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os
import glob # Used for potential future data discovery/loading if augmentation tables are added

# Ensure required libraries are installed
# You may need to run:
# pip install pandas numpy scikit-learn catboost

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return None
    except pd.errors.EmptyDataError:
        print(f"Warning: File is empty at {file_path}")
        return pd.DataFrame() # Return empty DataFrame to avoid further errors
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return None

def run_ablation_scenario(
    original_train_df,
    scenario_name,
    use_log1p_target=True,
    catboost_eval_metric='RMSE',
    fill_na_categoricals=True
):
    """
    Runs a single ablation scenario on the provided training data.
    """
    print(f"\n--- Running Scenario: {scenario_name} ---")

    # Work on a copy of the dataframe to avoid side effects between scenarios
    train_df = original_train_df.copy()

    # Convert categorical features to string type explicitly for CatBoost
    train_df['street_name'] = train_df['street_name'].astype(str)
    train_df['violation_description'] = train_df['violation_description'].astype(str)
    
    # Handle potential NaN values in categorical features by filling them with a placeholder
    if fill_na_categoricals:
        train_df['street_name'] = train_df['street_name'].fillna('UNKNOWN_STREET')
        train_df['violation_description'] = train_df['violation_description'].fillna('UNKNOWN_VIOLATION')
    # If not filling, CatBoost will handle NaNs internally.

    # Ensure target variable is numeric and handle potential NaNs (e.g., fill with 0 or mean)
    train_df['violation_count'] = pd.to_numeric(train_df['violation_count'], errors='coerce')
    train_df['violation_count'] = train_df['violation_count'].fillna(0) # Fill NaNs in target with 0
    # Ensure violation counts are non-negative
    train_df['violation_count'] = train_df['violation_count'].clip(lower=0)


    # --- Enhanced Feature Engineering ---
    # Extract numerical information from 'violation_description'
    train_df['violation_description_length'] = train_df['violation_description'].apply(len)
    train_df['violation_description_word_count'] = train_df['violation_description'].apply(lambda x: len(str(x).split()))

    # Explore simple interaction features
    # Create an interaction feature between 'street_name' and 'violation_description_length'
    train_df['street_name_desc_len_interaction'] = \
        train_df['street_name'].astype(str) + '_' + train_df['violation_description_length'].astype(str)
    # Ensure the new interaction feature is also treated as a string/categorical
    train_df['street_name_desc_len_interaction'] = train_df['street_name_desc_len_interaction'].astype(str)


    # --- Prepare Data for Model ---
    features = [
        'street_name',
        'violation_description',
        'violation_description_length',
        'violation_description_word_count',
        'street_name_desc_len_interaction' # New interaction feature
    ]
    target = 'violation_count'

    X = train_df[features]
    y_original = train_df[target] # Keep original target for final RMSE calculation

    # Apply log1p transformation to the target variable for training if enabled
    if use_log1p_target:
        y = np.log1p(y_original)
    else:
        y = y_original

    # Identify categorical features by their column names
    # CatBoost is robust in handling 'object' dtypes and NaNs in categorical features.
    categorical_features_indices = [i for i, col in enumerate(features) if X[col].dtype == 'object']

    # --- Split Training Data for Validation ---
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Align y_val_original with the split validation set
    y_val_original = y_original.loc[y_val.index]

    # Create CatBoost Pool objects
    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices)

    # --- Model Training ---
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.03,
        depth=9,
        l2_leaf_reg=3,
        eval_metric=catboost_eval_metric, # Ablated parameter
        random_seed=42,
        verbose=0,
        early_stopping_rounds=100,
        thread_count=-1,
    )

    print("Training CatBoost model...")
    model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=100, verbose=False)

    # --- Validation ---
    # Predictions from the model are on the scale it was trained on (log1p or original)
    val_predictions_raw = model.predict(X_val)

    # Inverse transform predictions if log1p was used, otherwise use raw predictions
    if use_log1p_target:
        val_predictions = np.expm1(val_predictions_raw)
    else:
        val_predictions = val_predictions_raw

    # Ensure predictions are non-negative after inverse transformation/raw prediction
    val_predictions[val_predictions < 0] = 0

    # For RMSE calculation, y_val_original (true values) must be on the original scale
    rmse_val = np.sqrt(mean_squared_error(y_val_original, val_predictions))
    print(f"Validation RMSE for {scenario_name}: {rmse_val}")

    return rmse_val

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV relative to INPUT_DIR.')
    args = parser.parse_args()

    INPUT_DIR = './input'
    TRAIN_FILE = args.train_path

    # --- 1. Load Training Data ---
    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)
    print(f"Loading training data from: {train_df_path}")
    original_train_df = load_data(train_df_path)

    if original_train_df is None or original_train_df.empty:
        print("Training data could not be loaded or is empty. Exiting.")
        return

    print(f"Original training data shape: {original_train_df.shape}")
    print("Training data columns:", original_train_df.columns.tolist())

    # Ensure required columns are present in the training data
    required_train_cols = ['street_name', 'violation_description', 'violation_count']
    if not all(col in original_train_df.columns for col in required_train_cols):
        print(f"Error: Training data missing one or more required columns: {required_train_cols}")
        print("Available columns:", original_train_df.columns.tolist())
        return

    # --- Run Ablation Scenarios ---
    results = {}

    # Baseline Scenario: Original solution's configuration
    results['Baseline'] = run_ablation_scenario(
        original_train_df.copy(),
        "Baseline (Original Solution)",
        use_log1p_target=True,
        catboost_eval_metric='RMSE',
        fill_na_categoricals=True
    )

    # Ablation 1: No log1p transformation on the target variable
    results['Ablation 1: No log1p target transformation'] = run_ablation_scenario(
        original_train_df.copy(),
        "Ablation 1: No log1p target transformation",
        use_log1p_target=False,
        catboost_eval_metric='RMSE',
        fill_na_categoricals=True
    )

    # Ablation 2: Change CatBoost eval_metric from RMSE to MAE
    results['Ablation 2: CatBoost eval_metric=MAE'] = run_ablation_scenario(
        original_train_df.copy(),
        "Ablation 2: CatBoost eval_metric=MAE",
        use_log1p_target=True,
        catboost_eval_metric='MAE',
        fill_na_categoricals=True
    )

    # Ablation 3: No explicit fillna for categorical features ('street_name', 'violation_description')
    results['Ablation 3: No explicit fillna for categoricals'] = run_ablation_scenario(
        original_train_df.copy(),
        "Ablation 3: No explicit fillna for categoricals",
        use_log1p_target=True,
        catboost_eval_metric='RMSE',
        fill_na_categoricals=False
    )
    
    # --- Determine Most Contributing Part ---
    print("\n--- Ablation Study Summary ---")
    baseline_rmse = results['Baseline']
    print(f"Baseline RMSE: {baseline_rmse:.4f}")

    most_impactful_change_name = ""
    largest_impact_value = 0.0 # Stores the change in RMSE (baseline_rmse - scenario_rmse)
    
    for scenario, rmse in results.items():
        if scenario == 'Baseline':
            continue
        
        change_vs_baseline = baseline_rmse - rmse # Positive if improvement, negative if degradation
        print(f"{scenario}: RMSE = {rmse:.4f}, Change vs Baseline = {change_vs_baseline:.4f}")

        if abs(change_vs_baseline) > abs(largest_impact_value):
            largest_impact_value = change_vs_baseline
            most_impactful_change_name = scenario

    if most_impactful_change_name:
        original_component_name = most_impactful_change_name.replace('Ablation \d+: ', '').replace('No ', '').replace('Change ', '')
        
        if largest_impact_value < 0: # Removal led to an increase in RMSE -> the removed part was beneficial
            print(f"\nConclusion: The original functionality related to '{original_component_name}' contributes most positively to the overall performance, as its removal degraded RMSE by {abs(largest_impact_value):.4f}.")
        else: # Removal led to a decrease in RMSE -> the removed part was detrimental
             print(f"\nConclusion: The original functionality related to '{original_component_name}' was most detrimental to the overall performance, and its removal improved RMSE by {abs(largest_impact_value):.4f}.")
    else:
        print("\nConclusion: No significant impact observed from ablations compared to baseline.")

if __name__ == "__main__":
    main()

