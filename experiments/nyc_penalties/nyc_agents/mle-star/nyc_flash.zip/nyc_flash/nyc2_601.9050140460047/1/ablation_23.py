
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os
from sklearn.feature_extraction.text import TfidfVectorizer

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        return None
    except pd.errors.EmptyDataError:
        return pd.DataFrame()
    except Exception as e:
        return None

def run_experiment(config):
    INPUT_DIR = './input'
    TRAIN_FILE = 'violations_per_street_2022.csv'

    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)
    train_df = load_data(train_df_path)

    if train_df is None or train_df.empty:
        return None

    required_train_cols = ['street_name', 'violation_description', 'violation_count']
    if not all(col in train_df.columns for col in required_train_cols):
        return None

    train_df['street_name'] = train_df['street_name'].astype(str)
    train_df['violation_description'] = train_df['violation_description'].astype(str)
    train_df['street_name'] = train_df['street_name'].fillna('UNKNOWN_STREET')
    train_df['violation_description'] = train_df['violation_description'].fillna('UNKNOWN_VIOLATION')

    train_df['violation_count'] = pd.to_numeric(train_df['violation_count'], errors='coerce')
    train_df['violation_count'] = train_df['violation_count'].fillna(0)
    train_df['violation_count'] = train_df['violation_count'].clip(lower=0)

    train_df['violation_description_length'] = train_df['violation_description'].apply(len)
    train_df['violation_description_word_count'] = train_df['violation_description'].apply(lambda x: len(str(x).split()))
    train_df['street_name_desc_len_interaction'] = \
        train_df['street_name'].astype(str) + '_' + train_df['violation_description_length'].astype(str)
    train_df['street_name_desc_len_interaction'] = train_df['street_name_desc_len_interaction'].astype(str)

    # --- TF-IDF Feature Engineering ---
    tfidf_ngram_range = config.get('tfidf_ngram_range', (1,2))
    tfidf_stop_words = config.get('tfidf_stop_words', 'english')

    processed_descriptions = train_df['violation_description'].astype(str).fillna('no_description')

    tfidf_vectorizer = TfidfVectorizer(max_features=2000, ngram_range=tfidf_ngram_range, stop_words=tfidf_stop_words)
    tfidf_features_sparse = tfidf_vectorizer.fit_transform(processed_descriptions)
    tfidf_feature_names = [f"tfidf_{name}" for name in tfidf_vectorizer.get_feature_names_out()]
    tfidf_df = pd.DataFrame(tfidf_features_sparse.toarray(), columns=tfidf_feature_names, index=train_df.index)
    train_df = pd.concat([train_df, tfidf_df], axis=1)

    # --- Prepare Data for Model ---
    features = [
        'street_name',
        'violation_description',
        'violation_description_length',
        'violation_description_word_count',
        'street_name_desc_len_interaction'
    ]
    features.extend(tfidf_feature_names)

    target = 'violation_count'

    X = train_df[features]
    y = np.log1p(train_df[target])

    categorical_features = ['street_name', 'violation_description', 'street_name_desc_len_interaction']
    categorical_features_indices = [features.index(col) for col in categorical_features if col in features]

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices)

    # --- Model Training ---
    catboost_iterations = config.get('catboost_iterations', 1000)

    model = CatBoostRegressor(
        iterations=catboost_iterations,
        learning_rate=0.03,
        depth=9,
        l2_leaf_reg=3,
        eval_metric='RMSE',
        random_seed=42,
        verbose=0,
        early_stopping_rounds=100,
        thread_count=-1,
    )

    model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=100, verbose=False)

    # --- Validation ---
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log)
    val_predictions[val_predictions < 0] = 0

    rmse_val = np.sqrt(mean_squared_error(np.expm1(y_val), val_predictions))
    return rmse_val

if __name__ == "__main__":
    all_results = {}

    baseline_config = {
        'description': "Baseline (TF-IDF ngram=(1,2), stop_words='english', iterations=1000)",
        'tfidf_ngram_range': (1,2),
        'tfidf_stop_words': 'english',
        'catboost_iterations': 1000,
    }
    baseline_rmse = run_experiment(baseline_config)
    all_results['Baseline'] = {'rmse': baseline_rmse, 'config': baseline_config}
    print(f"{baseline_config['description']}: RMSE = {baseline_rmse:.4f}")

    ablation1_config = {
        'description': "Ablation 1: TF-IDF ngram_range=(1,1) (unigrams only)",
        'tfidf_ngram_range': (1,1),
        'tfidf_stop_words': 'english',
        'catboost_iterations': 1000,
    }
    ablation1_rmse = run_experiment(ablation1_config)
    all_results['Ablation 1'] = {'rmse': ablation1_rmse, 'config': ablation1_config}
    print(f"{ablation1_config['description']}: RMSE = {ablation1_rmse:.4f}")

    ablation2_config = {
        'description': "Ablation 2: TF-IDF stop_words=None (no stop words)",
        'tfidf_ngram_range': (1,2),
        'tfidf_stop_words': None,
        'catboost_iterations': 1000,
    }
    ablation2_rmse = run_experiment(ablation2_config)
    all_results['Ablation 2'] = {'rmse': ablation2_rmse, 'config': ablation2_config}
    print(f"{ablation2_config['description']}: RMSE = {ablation2_rmse:.4f}")

    ablation3_config = {
        'description': "Ablation 3: CatBoost iterations=500",
        'tfidf_ngram_range': (1,2),
        'tfidf_stop_words': 'english',
        'catboost_iterations': 500,
    }
    ablation3_rmse = run_experiment(ablation3_config)
    all_results['Ablation 3'] = {'rmse': ablation3_rmse, 'config': ablation3_config}
    print(f"{ablation3_config['description']}: RMSE = {ablation3_rmse:.4f}")

    best_overall_rmse = float('inf')
    best_config_description = "N/A"
    
    for name, data in all_results.items():
        if data['rmse'] is not None and data['rmse'] < best_overall_rmse:
            best_overall_rmse = data['rmse']
            best_config_description = data['config']['description']

    print(f"The part of the code that contributes the most to the overall performance is: '{best_config_description}', which achieved the lowest RMSE of {best_overall_rmse:.4f}.")
