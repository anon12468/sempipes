
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os

# Ensure required libraries are installed
# You may need to run:
# pip install pandas numpy scikit-learn catboost

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        return None
    except pd.errors.EmptyDataError:
        return pd.DataFrame()
    except Exception as e:
        return None

def train_evaluate_model(
    train_df_original,
    catboost_model_params,
    features_config,
    ablation_name="Baseline"
):
    """
    Trains and evaluates a CatBoost model based on the given configuration.
    Returns the validation RMSE.
    """
    df = train_df_original.copy()

    # --- Feature Engineering and Augmentation ---
    df['street_name'] = df['street_name'].astype(str)
    df['violation_description'] = df['violation_description'].astype(str)
    df['street_name'] = df['street_name'].fillna('UNKNOWN_STREET')
    df['violation_description'] = df['violation_description'].fillna('UNKNOWN_VIOLATION')

    # Target variable handling
    target = 'violation_count'
    df[target] = pd.to_numeric(df[target], errors='coerce')
    df[target] = df[target].fillna(0)
    df[target] = df[target].clip(lower=0)
    y = np.log1p(df[target])

    current_features = ['street_name'] # Street name is always a base feature
    categorical_features_names = ['street_name'] # street_name is always categorical

    # Apply enhanced features based on config
    violation_desc_len_enabled = features_config.get('enable_violation_desc_len', False)
    violation_desc_word_count_enabled = features_config.get('enable_violation_desc_word_count', False)
    interaction_feature_enabled = features_config.get('enable_interaction_feature', False)

    if violation_desc_len_enabled:
        df['violation_description_length'] = df['violation_description'].apply(len)
        current_features.append('violation_description_length')
    if violation_desc_word_count_enabled:
        df['violation_description_word_count'] = df['violation_description'].apply(lambda x: len(str(x).split()))
        current_features.append('violation_description_word_count')
    if interaction_feature_enabled and violation_desc_len_enabled: # Interaction depends on length feature
        df['street_name_desc_len_interaction'] = \
            df['street_name'].astype(str) + '_' + df['violation_description_length'].astype(str)
        df['street_name_desc_len_interaction'] = df['street_name_desc_len_interaction'].astype(str)
        current_features.append('street_name_desc_len_interaction')
        categorical_features_names.append('street_name_desc_len_interaction')
    elif interaction_feature_enabled and not violation_desc_len_enabled:
        # If interaction feature is requested but its dependency (length) is not, skip it
        # This print is for internal debugging, removed for final output.
        # print(f"Warning: {ablation_name} - 'street_name_desc_len_interaction' requires 'violation_description_length'. Skipping interaction feature.")
        pass

    # Determine how 'violation_description' is handled
    catboost_text_features = []
    if features_config.get('violation_desc_as_text', False):
        catboost_text_features.append('violation_description')
        current_features.append('violation_description') # Add to features list
    else:
        # If not text, it's a regular categorical feature
        categorical_features_names.append('violation_description')
        current_features.append('violation_description') # Add to features list

    # Filter features to ensure they exist in the DataFrame
    final_features = [f for f in current_features if f in df.columns]
    X = df[final_features]

    # Identify categorical and text feature indices for CatBoost Pool
    categorical_features_indices = [i for i, col in enumerate(X.columns) if col in categorical_features_names]
    text_features_indices = [i for i, col in enumerate(X.columns) if col in catboost_text_features]

    # --- Split Training Data for Validation ---
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=catboost_model_params['random_seed'])

    # Create CatBoost Pool objects
    train_pool = Pool(X_train, y_train,
                      cat_features=categorical_features_indices,
                      text_features=text_features_indices)
    val_pool = Pool(X_val, y_val,
                    cat_features=categorical_features_indices,
                    text_features=text_features_indices)

    # --- Model Training ---
    model = CatBoostRegressor(**catboost_model_params)

    fit_params = {
        'eval_set': val_pool,
        'verbose': False
    }
    if catboost_model_params.get('early_stopping_rounds') is not None:
        fit_params['early_stopping_rounds'] = catboost_model_params['early_stopping_rounds']

    model.fit(train_pool, **fit_params)

    # --- Validation ---
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log)
    val_predictions[val_predictions < 0] = 0

    rmse_val = np.sqrt(mean_squared_error(np.expm1(y_val), val_predictions))
    return rmse_val

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV relative to INPUT_DIR.')
    args = parser.parse_args()

    INPUT_DIR = './input'
    TRAIN_FILE = args.train_path

    # --- Load Training Data ---
    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)
    train_df = load_data(train_df_path)

    if train_df is None or train_df.empty:
        print("Training data could not be loaded or is empty. Exiting.")
        return

    required_train_cols = ['street_name', 'violation_description', 'violation_count']
    if not all(col in train_df.columns for col in required_train_cols):
        print(f"Error: Training data missing one or more required columns: {required_train_cols}")
        return

    # --- Baseline Configuration (Current Solution State) ---
    baseline_catboost_params = {
        'iterations': 2000,
        'learning_rate': 0.02,
        'depth': 9,
        'l2_leaf_reg': 3,
        'eval_metric': 'RMSE',
        'random_seed': 42,
        'verbose': 0,
        'early_stopping_rounds': 100,
        'thread_count': -1,
        'bootstrap_type': 'Bernoulli',
        'subsample': 0.8
    }

    baseline_features_config = {
        'enable_violation_desc_len': True,
        'enable_violation_desc_word_count': True,
        'enable_interaction_feature': True, # This interaction feature depends on violation_description_length
        'violation_desc_as_text': False # Current code treats it as categorical
    }

    # Run Baseline
    baseline_rmse = train_evaluate_model(
        train_df,
        baseline_catboost_params,
        baseline_features_config,
        "Baseline"
    )
    print(f"Baseline Validation RMSE: {baseline_rmse}")

    # --- Ablation 1: Use `violation_description` as `text_features` ---
    ablation1_features_config = baseline_features_config.copy()
    ablation1_features_config['violation_desc_as_text'] = True
    ablation1_catboost_params = baseline_catboost_params.copy()

    ablation1_rmse = train_evaluate_model(
        train_df,
        ablation1_catboost_params,
        ablation1_features_config,
        "Ablation 1 (violation_description as text_features)"
    )
    print(f"Ablation 1 (violation_description as text_features) Validation RMSE: {ablation1_rmse}")

    # --- Ablation 2: Remove all 'Enhanced Features' ---
    ablation2_features_config = baseline_features_config.copy()
    ablation2_features_config['enable_violation_desc_len'] = False
    ablation2_features_config['enable_violation_desc_word_count'] = False
    ablation2_features_config['enable_interaction_feature'] = False # This will be skipped as its dependency (length) is false
    ablation2_catboost_params = baseline_catboost_params.copy()

    ablation2_rmse = train_evaluate_model(
        train_df,
        ablation2_catboost_params,
        ablation2_features_config,
        "Ablation 2 (No Enhanced Features)"
    )
    print(f"Ablation 2 (No Enhanced Features) Validation RMSE: {ablation2_rmse}")

    # --- Ablation 3: Disable `early_stopping_rounds` ---
    ablation3_catboost_params = baseline_catboost_params.copy()
    ablation3_catboost_params['early_stopping_rounds'] = None # Explicitly disable early stopping
    ablation3_features_config = baseline_features_config.copy() # Same features as baseline

    ablation3_rmse = train_evaluate_model(
        train_df,
        ablation3_catboost_params,
        ablation3_features_config,
        "Ablation 3 (Disable early_stopping_rounds)"
    )
    print(f"Ablation 3 (Disable early_stopping_rounds) Validation RMSE: {ablation3_rmse}")

    # --- Conclusion ---
    results = {
        "Baseline": baseline_rmse,
        "Ablation 1 (violation_description as text_features)": ablation1_rmse,
        "Ablation 2 (No Enhanced Features)": ablation2_rmse,
        "Ablation 3 (Disable early_stopping_rounds)": ablation3_rmse,
    }

    print("\n--- Ablation Study Conclusion ---")
    
    # Calculate impacts relative to baseline
    impacts = {}
    for name, rmse in results.items():
        if name != "Baseline":
            impacts[name] = baseline_rmse - rmse # Positive if improvement, negative if degradation
    
    if not impacts:
        print("No ablations were performed for comparison.")
        return

    # Determine the configuration with the best RMSE
    best_config_name = min(results, key=results.get)
    best_config_rmse = results[best_config_name]

    print(f"The best performing configuration is '{best_config_name}' with an RMSE of {best_config_rmse:.4f}.")

    # Identify the ablation with the largest absolute impact relative to the baseline
    largest_impact_name = max(impacts, key=lambda k: abs(impacts[k]))
    largest_impact_value = impacts[largest_impact_name]

    if largest_impact_value > 0:
        print(f"The part that contributed most positively to the overall performance (or whose modification led to the largest improvement) was '{largest_impact_name}', improving RMSE by {largest_impact_value:.4f}.")
    elif largest_impact_value < 0:
        print(f"The part that contributed most negatively to the overall performance (or whose modification led to the largest degradation) was '{largest_impact_name}', degrading RMSE by {abs(largest_impact_value):.4f}.")
    else:
        print("All ablations had no significant impact on the performance compared to the baseline.")

if __name__ == "__main__":
    main()
