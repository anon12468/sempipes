
import pandas as pd
import numpy as np
from catboost import CatBoostRegressor, Pool
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import os

# --- Helper functions (adapted from the original script) ---
def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return None
    except pd.errors.EmptyDataError:
        print(f"Warning: File is empty at {file_path}")
        return pd.DataFrame() # Return empty DataFrame to avoid further errors
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return None

def calculate_rmse(y_true, y_pred):
    """Calculates the Root Mean Squared Error."""
    return np.sqrt(mean_squared_error(y_true, y_pred))

# --- Experiment Runner ---
def run_ablation_experiment(
    train_df_original,
    use_street_violation_pair=True,
    clip_predictions=True,
    catboost_learning_rate=0.05,
    experiment_name="Baseline"
):
    print(f"\n--- Running Experiment: {experiment_name} ---")

    train_df = train_df_original.copy()

    # Apply core feature engineering and type conversion
    train_df['street_name'] = train_df['street_name'].astype(str)
    train_df['violation_type'] = train_df['violation_type'].astype(str)

    features = ['street_name', 'violation_type']
    if use_street_violation_pair:
        train_df['street_violation_pair'] = train_df['street_name'] + "_" + train_df['violation_type']
        features.append('street_violation_pair')

    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    # Identify categorical features for CatBoost
    categorical_features_indices = [i for i, col in enumerate(features) if X[col].dtype == 'object']

    # Split data for training and validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    # CatBoost Model Training
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=catboost_learning_rate,
        depth=8,
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Suppress verbose output during training iterations
        early_stopping_rounds=50,
        loss_function='RMSE',
        cat_features=categorical_features_indices
    )

    # Fit the model
    model.fit(X_train, y_train, eval_set=(X_val, y_val), early_stopping_rounds=50, verbose=False)

    # Evaluate on Validation Set
    val_preds = model.predict(X_val)
    if clip_predictions:
        val_preds = np.maximum(0, val_preds) # Ensure predictions are non-negative

    validation_rmse = calculate_rmse(y_val, val_preds)
    print(f'Validation Performance ({experiment_name}): {validation_rmse}')
    return validation_rmse

def main_ablation_study():
    INPUT_DIR = './input'
    TRAIN_FILE = 'violations_per_street_2022.csv'
    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)

    print(f"Loading base training data from: {train_df_path}")
    base_train_df = load_data(train_df_path)

    if base_train_df is None or base_train_df.empty:
        print("Base training data could not be loaded or is empty. Exiting.")
        return

    # Rename `violation_description` to `violation_type` to align with the current `train.py` feature name.
    # `load_data` already converts `Street Name` to `street_name`.
    if 'violation_description' in base_train_df.columns:
        base_train_df.rename(columns={'violation_description': 'violation_type'}, inplace=True)
    
    # Ensure target column is numeric and cleaned as in the original script
    base_train_df['violation_count'] = pd.to_numeric(base_train_df['violation_count'], errors='coerce')
    base_train_df['violation_count'] = base_train_df['violation_count'].fillna(0)
    base_train_df['violation_count'] = base_train_df['violation_count'].clip(lower=0)


    results = {}

    # --- Baseline Experiment ---
    # Matches the provided `train.py`'s current configuration
    baseline_rmse = run_ablation_experiment(
        base_train_df,
        use_street_violation_pair=True,
        clip_predictions=True,
        catboost_learning_rate=0.05,
        experiment_name="Baseline (Original Configuration)"
    )
    results["Baseline (Original Configuration)"] = baseline_rmse

    # --- Ablation 1: Remove 'street_violation_pair' feature ---
    # This feature is newly introduced in the provided solution.
    ablation1_rmse = run_ablation_experiment(
        base_train_df,
        use_street_violation_pair=False,
        clip_predictions=True,
        catboost_learning_rate=0.05,
        experiment_name="Ablation 1: No 'street_violation_pair' feature"
    )
    results["Ablation 1: No 'street_violation_pair' feature"] = ablation1_rmse

    # --- Ablation 2: Remove prediction clipping (np.maximum(0, val_preds)) ---
    # This post-processing step ensures non-negative predictions.
    ablation2_rmse = run_ablation_experiment(
        base_train_df,
        use_street_violation_pair=True,
        clip_predictions=False,
        catboost_learning_rate=0.05,
        experiment_name="Ablation 2: No Prediction Clipping"
    )
    results["Ablation 2: No Prediction Clipping"] = ablation2_rmse

    # --- Ablation 3: Change CatBoost learning_rate from 0.05 to 0.1 ---
    # The learning rate is a critical hyperparameter. Previous studies touched on 0.03 vs 0.1.
    # This tests the impact of the current 0.05 against a higher value.
    ablation3_rmse = run_ablation_experiment(
        base_train_df,
        use_street_violation_pair=True,
        clip_predictions=True,
        catboost_learning_rate=0.1,
        experiment_name="Ablation 3: CatBoost Learning Rate 0.1"
    )
    results["Ablation 3: CatBoost Learning Rate 0.1"] = ablation3_rmse

    print("\n--- Ablation Study Results Summary ---")
    for name, rmse in results.items():
        print(f"{name}: RMSE = {rmse:.4f}")

    # Determine which part contributes the most
    print("\n--- Contribution Analysis ---")
    
    impacts = {}
    
    # Impact of 'street_violation_pair'
    # Positive impact means removing it increased RMSE (it was beneficial)
    impact_ablation1 = ablation1_rmse - baseline_rmse
    impacts["'street_violation_pair' feature"] = impact_ablation1

    # Impact of 'Prediction Clipping'
    # Positive impact means removing it increased RMSE (it was beneficial)
    impact_ablation2 = ablation2_rmse - baseline_rmse
    impacts["Prediction Clipping (np.maximum(0, val_preds))"] = impact_ablation2

    # Impact of 'CatBoost Learning Rate' (0.05 vs 0.1)
    # Positive impact means changing it to 0.1 increased RMSE (0.05 was better)
    impact_ablation3 = ablation3_rmse - baseline_rmse
    impacts["CatBoost Learning Rate (0.05 vs 0.1)"] = impact_ablation3
    
    print(f"Baseline RMSE: {baseline_rmse:.4f}")
    print(f"Impact of removing 'street_violation_pair' feature: {impact_ablation1:.4f} (positive means it was beneficial)")
    print(f"Impact of removing 'Prediction Clipping': {impact_ablation2:.4f} (positive means it was beneficial)")
    print(f"Impact of changing 'CatBoost Learning Rate 0.05 -> 0.1': {impact_ablation3:.4f} (positive means 0.05 was better)")

    # Find the largest absolute impact to identify the most critical component
    if impacts:
        most_impactful_component = max(impacts, key=lambda k: abs(impacts[k]))
        print(f"\nThe part that contributes the most to the overall performance (largest absolute impact on RMSE) is: {most_impactful_component}")
    else:
        print("\nNo impactful components identified (or no ablations performed).")

if __name__ == "__main__":
    main_ablation_study()
