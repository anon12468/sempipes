
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os
import glob # Used for potential future data discovery/loading if augmentation tables are added

# Ensure required libraries are installed
# You may need to run:
# pip install pandas numpy scikit-learn catboost

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return None
    except pd.errors.EmptyDataError:
        print(f"Warning: File is empty at {file_path}")
        return pd.DataFrame() # Return empty DataFrame to avoid further errors
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return None

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV relative to INPUT_DIR.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional path to the test/evaluation data CSV relative to INPUT_DIR for prediction.')
    args = parser.parse_args()

    INPUT_DIR = './input' # All input data is stored in this directory
    TRAIN_FILE = args.train_path
    TEST_FILE = args.test_path

    # --- 1. Load Training Data ---
    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)
    print(f"Loading training data from: {train_df_path}")
    train_df = load_data(train_df_path)

    if train_df is None or train_df.empty:
        print("Training data could not be loaded or is empty. Exiting.")
        return

    print(f"Original training data shape: {train_df.shape}")
    print("Training data columns:", train_df.columns.tolist())

    # Ensure required columns are present in the training data
    required_train_cols = ['street_name', 'violation_description', 'violation_count']
    if not all(col in train_df.columns for col in required_train_cols):
        print(f"Error: Training data missing one or more required columns: {required_train_cols}")
        print("Available columns:", train_df.columns.tolist())
        return

    # --- 2. Feature Engineering and Augmentation ---
    # Placeholder for feature augmentation.
    # This is where additional datasets from the INPUT_DIR would be loaded and merged.
    # For example, to load and merge census data:
    # try:
    #     census_df_path = os.path.join(INPUT_DIR, 'nyc_census_data.csv')
    #     census_df = load_data(census_df_path)
    #     if census_df is not None and not census_df.empty:
    #         # Example merge: Assuming 'street_name' can be linked to census data
    #         train_df = pd.merge(train_df, census_df, on='street_name', how='left')
    #         print(f"Merged with census data. New training data shape: {train_df.shape}")
    # except Exception as e:
    #     print(f"Could not load/process census data for augmentation: {e}")

    # For this current solution, we will only use 'street_name' and 'violation_description'
    # as features to ensure simplicity and focus on fixing the reported error.

    # Convert categorical features to string type explicitly for CatBoost
    train_df['street_name'] = train_df['street_name'].astype(str)
    train_df['violation_description'] = train_df['violation_description'].astype(str)
    # Handle potential NaN values in categorical features by filling them with a placeholder
    train_df['street_name'] = train_df['street_name'].fillna('UNKNOWN_STREET')
    train_df['violation_description'] = train_df['violation_description'].fillna('UNKNOWN_VIOLATION')

    # Ensure target variable is numeric and handle potential NaNs (e.g., fill with 0 or mean)
    train_df['violation_count'] = pd.to_numeric(train_df['violation_count'], errors='coerce')
    train_df['violation_count'] = train_df['violation_count'].fillna(0) # Fill NaNs in target with 0
    # Ensure violation counts are non-negative
    train_df['violation_count'] = train_df['violation_count'].clip(lower=0)


    # --- Enhanced Feature Engineering ---
    # Extract numerical information from 'violation_description'
    train_df['violation_description_length'] = train_df['violation_description'].apply(len)
    train_df['violation_description_word_count'] = train_df['violation_description'].apply(lambda x: len(str(x).split()))

    # Explore simple interaction features
    # Create an interaction feature between 'street_name' and 'violation_description_length'
    train_df['street_name_desc_len_interaction'] = \
        train_df['street_name'].astype(str) + '_' + train_df['violation_description_length'].astype(str)
    # Ensure the new interaction feature is also treated as a string/categorical
    train_df['street_name_desc_len_interaction'] = train_df['street_name_desc_len_interaction'].astype(str)


    # --- 3. Prepare Data for Model ---
    features = [
        'street_name',
        'violation_description',
        'violation_description_length',
        'violation_description_word_count',
        'street_name_desc_len_interaction' # New interaction feature
    ]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    # Identify categorical features by their column names
    # CatBoost can directly handle string type for categorical features,
    # but providing indices is also common.
    # The new interaction feature is also categorical (string type).
    categorical_features_indices = [i for i, col in enumerate(features) if X[col].dtype == 'object']

    # --- 4. Split Training Data for Validation ---
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    # Create CatBoost Pool objects
    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices)

    # --- 5. Model Training ---
    model = CatBoostRegressor(
        iterations=1000, # Increased iterations for potentially better performance
        learning_rate=0.03, # Slightly reduced learning rate
        depth=9, # Slightly increased depth to capture more complex patterns
        l2_leaf_reg=3, # Introduced L2 regularization to prevent overfitting
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Suppress verbose output during training iterations
        early_stopping_rounds=100, # Use early stopping to prevent overfitting
        thread_count=-1, # Use all available threads
        # bootstrap_type='Bernoulli', # Uncomment and adjust subsample if OOM occurs on large datasets
        # subsample=0.8
    )

    print("Training CatBoost model...")
    model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=100, verbose=False) # verbose=False for non-interactive output

    # --- 6. Validation ---
    val_predictions = model.predict(X_val)
    # Ensure predictions are non-negative
    val_predictions[val_predictions < 0] = 0
    rmse_val = np.sqrt(mean_squared_error(y_val, val_predictions))
    print(f"Final Validation Performance: {rmse_val}") # Required output format

    # --- 7. Prediction for Test/Evaluation File ---
    if TEST_FILE:
        test_df_path = os.path.join(INPUT_DIR, TEST_FILE)
        print(f"\nLoading test data from: {test_df_path}")
        test_df = load_data(test_df_path)

        if test_df is None or test_df.empty:
            print("Test data could not be loaded or is empty. Skipping prediction.")
            return

        print(f"Original test data shape: {test_df.shape}")
        print("Test data columns:", test_df.columns.tolist())

        # Ensure required columns are present in test set (excluding target if not there)
        required_test_cols = ['street_name', 'violation_description']
        if not all(col in test_df.columns for col in required_test_cols):
            print(f"Error: Test data missing one or more required columns: {required_test_cols}")
            print("Available columns:", test_df.columns.tolist())
            return

        # Store original key columns for submission
        submission_keys = test_df[['street_name', 'violation_description']].copy()

        # Apply same feature engineering and type conversion as training data
        test_df['street_name'] = test_df['street_name'].astype(str)
        test_df['violation_description'] = test_df['violation_description'].astype(str)
        # Handle potential NaN values in categorical features by filling them with a placeholder
        test_df['street_name'] = test_df['street_name'].fillna('UNKNOWN_STREET')
        test_df['violation_description'] = test_df['violation_description'].fillna('UNKNOWN_VIOLATION')

        X_test = test_df[features]

        # Handle and report unseen keys in test set
        train_street_names = set(X_train['street_name'].unique())
        train_violation_descriptions = set(X_train['violation_description'].unique())

        unseen_streets_count = X_test[~X_test['street_name'].isin(train_street_names)].shape[0]
        unseen_violations_count = X_test[~X_test['violation_description'].isin(train_violation_descriptions)].shape[0]

        print(f"Number of test rows with unseen street names: {unseen_streets_count}")
        print(f"Number of test rows with unseen violation descriptions: {unseen_violations_count}")
        print("CatBoost handles unseen categorical features gracefully by assigning them to a default category.")

        # Predict on test data
        test_predictions = model.predict(X_test)
        # Ensure predictions are non-negative
        test_predictions[test_predictions < 0] = 0

        submission_df = submission_keys
        submission_df['predicted_count'] = test_predictions

        # Save submission file
        submission_output_path = 'submission.csv'
        submission_df.to_csv(submission_output_path, index=False)
        print(f"Submission file '{submission_output_path}' generated successfully.")

        # If test file contains 'violation_count', calculate RMSE
        if target in test_df.columns:
            y_test_true = test_df[target]
            # Ensure target variable is numeric and handle potential NaNs
            y_test_true = pd.to_numeric(y_test_true, errors='coerce').fillna(0).clip(lower=0)
            rmse_test = np.sqrt(mean_squared_error(y_test_true, test_predictions))
            print(f"RMSE on the provided test/evaluation file: {rmse_test}")
        else:
            print("Test file does not contain 'violation_count'. No RMSE calculated for test set.")

if __name__ == "__main__":
    main()
