
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        # print(f"Error: File not found at {file_path}") # Removed print for cleaner ablation output
        return None
    except pd.errors.EmptyDataError:
        # print(f"Warning: File is empty at {file_path}") # Removed print for cleaner ablation output
        return pd.DataFrame() # Return empty DataFrame to avoid further errors
    except Exception as e:
        # print(f"Error loading {file_path}: {e}") # Removed print for cleaner ablation output
        return None

def run_experiment(
    train_path='violations_per_street_2022.csv',
    use_street_name_frequency=True, # Ablation parameter 1
    catboost_learning_rate=0.03,    # Ablation parameter 2
    catboost_depth=9,               # Ablation parameter 3
    random_seed=42,
    verbose_level=0
):
    INPUT_DIR = './input'
    TRAIN_FILE = train_path

    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)
    train_df = load_data(train_df_path)

    if train_df is None or train_df.empty:
        return float('inf') # Return a high RMSE to indicate failure

    required_train_cols = ['street_name', 'violation_description', 'violation_count']
    if not all(col in train_df.columns for col in required_train_cols):
        return float('inf')

    # --- Feature Engineering and Augmentation ---
    train_df['street_name'] = train_df['street_name'].astype(str)
    train_df['violation_description'] = train_df['violation_description'].astype(str)
    train_df['street_name'] = train_df['street_name'].fillna('UNKNOWN_STREET')
    train_df['violation_description'] = train_df['violation_description'].fillna('UNKNOWN_VIOLATION')

    train_df['violation_count'] = pd.to_numeric(train_df['violation_count'], errors='coerce')
    train_df['violation_count'] = train_df['violation_count'].fillna(0)
    train_df['violation_count'] = train_df['violation_count'].clip(lower=0)

    # Enhanced Feature Engineering (from original script)
    train_df['violation_description_length'] = train_df['violation_description'].apply(len)
    train_df['violation_description_word_count'] = train_df['violation_description'].apply(lambda x: len(str(x).split()))
    train_df['street_name_desc_len_interaction'] = \
        train_df['street_name'].astype(str) + '_' + train_df['violation_description_length'].astype(str)
    train_df['street_name_desc_len_interaction'] = train_df['street_name_desc_len_interaction'].astype(str)

    # New feature from plan_implement_agent_1 context, subject to ablation
    if use_street_name_frequency:
        street_name_counts = train_df['street_name'].value_counts()
        train_df['street_name_frequency'] = train_df['street_name'].map(street_name_counts)

    # --- Prepare Data for Model ---
    features = [
        'street_name',
        'violation_description',
        'violation_description_length',
        'violation_description_word_count',
        'street_name_desc_len_interaction'
    ]
    if use_street_name_frequency:
        features.append('street_name_frequency')

    target = 'violation_count'

    X = train_df[features]
    y = np.log1p(train_df[target])

    categorical_features_indices = [i for i, col in enumerate(features) if X[col].dtype == 'object']

    # --- Split Training Data for Validation ---
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=random_seed)

    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices)

    # --- Model Training ---
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=catboost_learning_rate,
        depth=catboost_depth,
        l2_leaf_reg=3,
        eval_metric='RMSE',
        random_seed=random_seed,
        verbose=verbose_level,
        early_stopping_rounds=100,
        thread_count=-1,
    )

    model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=100, verbose=False)

    # --- Validation ---
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log)
    val_predictions[val_predictions < 0] = 0

    rmse_val = np.sqrt(mean_squared_error(np.expm1(y_val), val_predictions))
    return rmse_val

if __name__ == "__main__":
    results = {}

    # Baseline: Current solution's configuration
    print("--- Running Baseline (Current Configuration) ---")
    baseline_rmse = run_experiment(
        use_street_name_frequency=True,
        catboost_learning_rate=0.03,
        catboost_depth=9,
        random_seed=42
    )
    results['Baseline'] = baseline_rmse
    print(f"Baseline RMSE: {baseline_rmse:.4f}\n")

    # Ablation 1: Remove 'street_name_frequency' feature
    print("--- Running Ablation 1: No 'street_name_frequency' feature ---")
    ablation1_rmse = run_experiment(
        use_street_name_frequency=False,
        catboost_learning_rate=0.03,
        catboost_depth=9,
        random_seed=42
    )
    results['Ablation 1 (No street_name_frequency)'] = ablation1_rmse
    print(f"Ablation 1 RMSE (No street_name_frequency): {ablation1_rmse:.4f}")
    print(f"Impact vs. Baseline: {ablation1_rmse - baseline_rmse:+.4f}\n")

    # Ablation 2: Change CatBoost learning_rate from 0.03 to 0.05
    print("--- Running Ablation 2: CatBoost learning_rate = 0.05 ---")
    ablation2_rmse = run_experiment(
        use_street_name_frequency=True,
        catboost_learning_rate=0.05,
        catboost_depth=9,
        random_seed=42
    )
    results['Ablation 2 (CatBoost learning_rate=0.05)'] = ablation2_rmse
    print(f"Ablation 2 RMSE (CatBoost learning_rate=0.05): {ablation2_rmse:.4f}")
    print(f"Impact vs. Baseline: {ablation2_rmse - baseline_rmse:+.4f}\n")

    # Ablation 3: Change CatBoost depth from 9 to 11
    print("--- Running Ablation 3: CatBoost depth = 11 ---")
    ablation3_rmse = run_experiment(
        use_street_name_frequency=True,
        catboost_learning_rate=0.03,
        catboost_depth=11,
        random_seed=42
    )
    results['Ablation 3 (CatBoost depth=11)'] = ablation3_rmse
    print(f"Ablation 3 RMSE (CatBoost depth=11): {ablation3_rmse:.4f}")
    print(f"Impact vs. Baseline: {ablation3_rmse - baseline_rmse:+.4f}\n")

    # --- Ablation Study Conclusion ---
    best_rmse = float('inf')
    best_config_name = ""

    for name, rmse_val in results.items():
        if rmse_val < best_rmse:
            best_rmse = rmse_val
            best_config_name = name

    print("--- Ablation Study Conclusion ---")
    print(f"The overall best performing configuration is '{best_config_name}' with RMSE: {best_rmse:.4f}.")

    impacts = {}
    for name, rmse_val in results.items():
        if name != 'Baseline':
            impacts[name] = baseline_rmse - rmse_val # Positive value means improvement, negative means degradation

    if not impacts:
        print("No ablations were performed besides the baseline.")
    else:
        most_impactful_change_name = None
        largest_abs_impact = 0.0

        for name, impact in impacts.items():
            abs_impact = abs(impact)
            if abs_impact > largest_abs_impact:
                largest_abs_impact = abs_impact
                most_impactful_change_name = name

        if most_impactful_change_name:
            impact_value = impacts[most_impactful_change_name]
            if impact_value > 0:
                print(f"The most impactful change was '{most_impactful_change_name}', which improved RMSE by {impact_value:.4f}.")
                if "No street_name_frequency" in most_impactful_change_name:
                    print(f"This indicates that the removal of the 'street_name_frequency' feature was highly beneficial.")
                elif "learning_rate" in most_impactful_change_name:
                    lr_val = most_impactful_change_name.split('=')[-1].strip()
                    print(f"This indicates that changing the CatBoost learning_rate to {lr_val} was highly beneficial.")
                elif "depth" in most_impactful_change_name:
                    depth_val = most_impactful_change_name.split('=')[-1].strip()
                    print(f"This indicates that changing the CatBoost depth to {depth_val} was highly beneficial.")
            elif impact_value < 0:
                print(f"The most impactful change was '{most_impactful_change_name}', which degraded RMSE by {abs(impact_value):.4f}.")
                print(f"This indicates that the original configuration for '{most_impactful_change_name}' (before ablation) was highly beneficial to performance.")
            else:
                print(f"The most impactful change '{most_impactful_change_name}' had no effect on RMSE.")

    # State the part of the code that contributes most to overall performance (based on lowest RMSE)
    print("\nConclusion: The part of the code that contributes most positively to the overall performance based on this study is:")
    if best_config_name == 'Baseline':
        print(f"- The original settings of including 'street_name_frequency', CatBoost learning_rate=0.03, and depth=9, as this achieved the lowest RMSE of {best_rmse:.4f}.")
    elif "No street_name_frequency" in best_config_name:
        print(f"- The removal of the 'street_name_frequency' feature, achieving the lowest RMSE of {best_rmse:.4f}.")
    elif "learning_rate" in best_config_name:
        lr_val = best_config_name.split('=')[-1].strip()
        print(f"- Setting CatBoost 'learning_rate' to {lr_val}, achieving the lowest RMSE of {best_rmse:.4f}.")
    elif "depth" in best_config_name:
        depth_val = best_config_name.split('=')[-1].strip()
        print(f"- Setting CatBoost 'depth' to {depth_val}, achieving the lowest RMSE of {best_rmse:.4f}.")
