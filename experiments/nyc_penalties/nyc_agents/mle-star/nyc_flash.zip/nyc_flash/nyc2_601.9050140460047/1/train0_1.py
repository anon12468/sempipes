
import pandas as pd
import numpy as np
import os
import argparse
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import lightgbm as lgb

# Function to calculate RMSE
def rmse(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))

# --- Feature Engineering Function (Adapted from Reference Solution) ---
# This function encapsulates common preprocessing steps to be applied consistently
def apply_feature_engineering(df_raw, parking_codes_unique_df, street_geo_aggregated_df):
    df_copy = df_raw.copy()

    # Standardize core columns
    df_copy.rename(columns={'Street Name': 'street_name', 'Violation Description': 'violation_type'}, inplace=True)
    
    # Merge parking violation codes
    if 'violation_type' in df_copy.columns and not parking_codes_unique_df.empty:
        df_copy['violation_type_lower'] = df_copy['violation_type'].str.lower().str.strip()
        df_copy = pd.merge(df_copy, parking_codes_unique_df, on='violation_type_lower', how='left')
        df_copy.drop(columns=['violation_type_lower'], errors='ignore', inplace=True)
    else:
        df_copy['violation_code'] = np.nan
        df_copy['violation_definition'] = np.nan

    # Merge street geographic data
    if 'street_name' in df_copy.columns and not street_geo_aggregated_df.empty:
        df_copy['street_name_lower'] = df_copy['street_name'].str.lower().str.strip()
        df_copy = pd.merge(df_copy, street_geo_aggregated_df, on='street_name_lower', how='left')
        df_copy.drop(columns=['street_name_lower'], errors='ignore', inplace=True)
    else:
        # Ensure these columns exist and are filled with NaNs if merge cannot happen
        for col in ['borough', 'latitude', 'longitude', 'segment_length', 'zip_code']:
            df_copy[col] = np.nan 

    return df_copy


def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument("--train-path", type=str, default="violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Optional path to the 2023 test data CSV for predictions.")
    args = parser.parse_args()

    # Determine the input directory based on the problem statement.
    # Adopting reference solution's INPUT_DIR logic for robustness in different environments.
    INPUT_DIR = os.path.join(os.getcwd(), 'input')

    # Define file paths
    train_violations_file = os.path.join(INPUT_DIR, args.train_path)
    parking_codes_file = os.path.join(INPUT_DIR, 'parking_violations_codes.csv')
    street_geo_file = os.path.join(INPUT_DIR, 'nyc_streets_geographic_data.csv')

    print(f"Loading data from: {train_violations_file}")
    print(f"Loading parking codes from: {parking_codes_file}")
    print(f"Loading street geo data from: {street_geo_file}")

    # Load data with error handling
    try:
        train_df_raw = pd.read_csv(train_violations_file)
        parking_codes_df_raw = pd.read_csv(parking_codes_file)
        street_geo_df_raw = pd.read_csv(street_geo_file)
    except FileNotFoundError as e:
        print(f"Error loading file: {e}. Please ensure files are in the '{INPUT_DIR}' directory and accessible.")
        return # Cannot proceed without necessary files

    # --- Preprocessing for auxiliary tables (parking codes, street geo) ---
    # Adopting reference solution's preprocessing for these auxiliary tables as it's more robust.
    parking_codes_df = parking_codes_df_raw.copy()
    parking_codes_df_unique = pd.DataFrame(columns=['violation_type_lower', 'violation_code', 'violation_definition'])
    if all(col in parking_codes_df.columns for col in ['Code', 'Description', 'Definition']):
        parking_codes_df.rename(columns={'Code': 'violation_code', 'Description': 'violation_type', 'Definition': 'violation_definition'}, inplace=True)
        parking_codes_df['violation_type_lower'] = parking_codes_df['violation_type'].str.lower().str.strip()
        parking_codes_df_unique = parking_codes_df.drop_duplicates(subset=['violation_type_lower'], keep='first')[['violation_type_lower', 'violation_code', 'violation_definition']]
    else:
        print("Warning: Expected columns 'Code', 'Description', 'Definition' not found in parking_violations_codes.csv. Violation code features will be missing.")

    street_geo_df = street_geo_df_raw.copy()
    street_geo_agg = pd.DataFrame() # Initialize to empty
    if 'street_name' in street_geo_df.columns and 'borough' in street_geo_df.columns:
        street_geo_df.columns = street_geo_df.columns.str.lower().str.replace(' ', '_') # Standardize column names
        street_geo_df['street_name_lower'] = street_geo_df['street_name'].str.lower().str.strip()
        
        if 'zip_code' in street_geo_df.columns:
            street_geo_df['zip_code'] = street_geo_df['zip_code'].astype(str)
        else:
            street_geo_df['zip_code'] = 'Unknown' # Add if missing to allow aggregation

        street_geo_agg = street_geo_df.groupby('street_name_lower').agg(
            borough=('borough', lambda x: x.mode()[0] if not x.mode().empty else 'Unknown'),
            latitude=('latitude', 'mean'),
            longitude=('longitude', 'mean'),
            segment_length=('segment_length', 'sum'),
            zip_code=('zip_code', lambda x: x.mode()[0] if not x.mode().empty else 'Unknown')
        ).reset_index()
    else:
        print("Warning: Essential 'street_name' or 'borough' columns not found in nyc_streets_geographic_data.csv. Street geo features will be missing.")

    # Apply common feature engineering to the raw training dataframe
    train_df = apply_feature_engineering(train_df_raw.copy(), parking_codes_df_unique, street_geo_agg)

    # Define all possible categorical and numerical columns that might be in the final dataframe
    expected_categorical_cols = ['street_name', 'violation_type', 'violation_code', 'violation_definition', 'borough', 'zip_code']
    expected_numerical_cols = ['latitude', 'longitude', 'segment_length']

    # Filter to only include columns that are actually present in the dataframe after engineering
    final_categorical_cols = [col for col in expected_categorical_cols if col in train_df.columns]
    final_numerical_cols = [col for col in expected_numerical_cols if col in train_df.columns]

    # Handle missing values and ensure correct types for training data consistently for both models
    for col in final_categorical_cols:
        train_df[col] = train_df[col].fillna('Unknown') # Fill NaNs for categorical features
    for col in final_numerical_cols:
        train_df[col] = train_df[col].fillna(0.0).astype(float) # Fill NaNs with 0 for numerical features

    # Ensure 'violation_count' is numeric and non-negative
    if 'violation_count' not in train_df.columns:
        print("Error: 'violation_count' column not found in training data. Cannot proceed.")
        return
    train_df['violation_count'] = pd.to_numeric(train_df['violation_count'], errors='coerce')
    train_df['violation_count'] = train_df['violation_count'].fillna(0).astype(int)
    train_df = train_df[train_df['violation_count'] >= 0] # Filter out any negative counts

    # Prepare features and target
    features = final_categorical_cols + final_numerical_cols
    X = train_df[features]
    y = train_df['violation_count']

    # Split 2022 data for validation (same split for both models)
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42, shuffle=True)

    print(f"Training data shape: {X_train.shape}")
    print(f"Validation data shape: {X_val.shape}")

    # --- CatBoost Model Training (Base Solution) ---
    print("\n--- Training CatBoost Model ---")
    cat_features_catboost = final_categorical_cols # CatBoost uses column names directly

    # For CatBoost, it's often safer to ensure categorical features are string type
    X_train_catboost = X_train.copy()
    X_val_catboost = X_val.copy()
    for col in cat_features_catboost:
        X_train_catboost[col] = X_train_catboost[col].astype(str)
        X_val_catboost[col] = X_val_catboost[col].astype(str)

    model_catboost = CatBoostRegressor(
        iterations=2000,
        learning_rate=0.03,
        depth=6,
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Suppress verbose output during training for cleaner logs
        early_stopping_rounds=100,
        nan_mode='Min', # Explicitly handle NaNs by treating them as minimum values
        thread_count=-1,
        subsample=0.7,
        bootstrap_type='Bernoulli',
    )

    train_pool_catboost = Pool(X_train_catboost, y_train, cat_features=cat_features_catboost)
    val_pool_catboost = Pool(X_val_catboost, y_val, cat_features=cat_features_catboost)

    try:
        model_catboost.fit(train_pool_catboost, eval_set=val_pool_catboost)
        print("CatBoost model training complete.")
    except Exception as e:
        print(f"Error during CatBoost model fitting: {e}")
        return

    val_predictions_catboost = model_catboost.predict(X_val_catboost)
    val_predictions_catboost = np.maximum(0, val_predictions_catboost) # Clip to non-negative

    # --- LightGBM Model Training (Reference Solution) ---
    print("\n--- Training LightGBM Model ---")
    # For LightGBM, explicitly converting categorical features to 'category' dtype is best practice
    X_train_lgbm = X_train.copy()
    X_val_lgbm = X_val.copy()
    for col in final_categorical_cols:
        X_train_lgbm[col] = X_train_lgbm[col].astype('category')
        X_val_lgbm[col] = X_val_lgbm[col].astype('category')

    lgbm_params = {
        'objective': 'poisson', # Poisson regression is suitable for count data
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 5,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 31,
        'verbose': -1, # Suppress verbose output during training iterations
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt'
    }

    model_lgbm = lgb.LGBMRegressor(**lgbm_params)
    try:
        model_lgbm.fit(X_train_lgbm, y_train,
                       eval_set=[(X_val_lgbm, y_val)],
                       eval_metric='rmse',
                       callbacks=[lgb.early_stopping(stopping_rounds=100, verbose=False)], # Early stopping
                       categorical_feature=final_categorical_cols) # Pass categorical feature names
        print("LightGBM model training complete.")
    except Exception as e:
        print(f"Error during LightGBM model fitting: {e}")
        return

    val_predictions_lgbm = model_lgbm.predict(X_val_lgbm)
    val_predictions_lgbm = np.maximum(0, val_predictions_lgbm) # Clip to non-negative

    # --- Ensemble Validation Predictions ---
    # Simple average ensemble of the two models
    ensembled_val_predictions = (val_predictions_catboost + val_predictions_lgbm) / 2
    ensembled_val_predictions = np.round(ensembled_val_predictions).astype(int) # Round and convert to integer
    final_validation_score = rmse(y_val, ensembled_val_predictions)
    print(f"\nFinal Validation Performance: {final_validation_score}")

    # --- Prediction for Test Data (if provided) ---
    if args.test_path:
        test_violations_file = os.path.join(INPUT_DIR, args.test_path)
        print(f"\nLoading test data from: {test_violations_file}")
        try:
            test_df_raw = pd.read_csv(test_violations_file)
        except FileNotFoundError:
            print(f"Test file not found: {test_violations_file}. Skipping test predictions.")
            return

        # Keep original 'Street Name' and 'Violation Description' for submission output
        submission_df_output = test_df_raw[['Street Name', 'Violation Description']].copy()
        
        # Apply the exact same feature engineering steps as training data
        test_df = apply_feature_engineering(test_df_raw.copy(), parking_codes_df_unique, street_geo_agg)
        
        # Handle missing columns and ensure consistency with training features for test data
        for col in features:
            if col not in test_df.columns:
                if col in final_categorical_cols:
                    test_df[col] = 'Unknown' # Default for missing categorical features
                else: # Numerical features
                    test_df[col] = 0.0 # Default for missing numerical features
        
        # Ensure correct types and handle NaNs for test data features
        for col in final_categorical_cols:
            test_df[col] = test_df[col].fillna('Unknown')
        for col in final_numerical_cols:
            test_df[col] = test_df[col].fillna(0.0).astype(float)
            
        # Ensure feature order is the same as training features for consistent prediction
        X_test = test_df[features]

        # Identify unseen key pairs for informational purposes
        train_df_raw_for_keys = pd.read_csv(train_violations_file) # Reload raw to get original keys
        train_keys = set(train_df_raw_for_keys.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1))
        test_keys = set(test_df_raw.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1))
        unseen_keys_count = len(test_keys - train_keys)
        print(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_keys_count}")

        # --- Generate CatBoost Test Predictions ---
        X_test_catboost = X_test.copy()
        for col in cat_features_catboost:
            X_test_catboost[col] = X_test_catboost[col].astype(str)

        print("Generating CatBoost predictions for test data...")
        test_predictions_catboost = model_catboost.predict(X_test_catboost)
        test_predictions_catboost = np.maximum(0, test_predictions_catboost) # Clip to non-negative

        # --- Generate LightGBM Test Predictions ---
        X_test_lgbm = X_test.copy()
        for col in final_categorical_cols:
            X_test_lgbm[col] = X_test_lgbm[col].astype('category')

        print("Generating LightGBM predictions for test data...")
        test_predictions_lgbm = model_lgbm.predict(X_test_lgbm)
        test_predictions_lgbm = np.maximum(0, test_predictions_lgbm) # Clip to non-negative

        # --- Ensemble Test Predictions ---
        # Simple average ensemble of test predictions
        ensembled_test_predictions = (test_predictions_catboost + test_predictions_lgbm) / 2
        ensembled_test_predictions = np.round(ensembled_test_predictions).astype(int) # Round and convert to integer

        # Create submission file as specified
        submission_df_output['predicted_count'] = ensembled_test_predictions
        submission_df_output.rename(columns={'Street Name': 'street_name', 'Violation Description': 'violation_type'}, inplace=True)
        submission_df_output.to_csv('submission.csv', index=False)
        print("Submission file 'submission.csv' created.")

        # If test_df_raw has 'violation_count' (ground truth), calculate and report test RMSE
        test_target_col_name_raw = 'violation_count'
        
        if test_target_col_name_raw in test_df_raw.columns and not test_df_raw[test_target_col_name_raw].isnull().all():
            test_true_counts_for_eval = pd.to_numeric(test_df_raw[test_target_col_name_raw], errors='coerce')
            valid_test_rows_for_eval = test_true_counts_for_eval.notna()
            
            test_true_counts = test_true_counts_for_eval[valid_test_rows_for_eval].astype(int)
            test_predictions_for_valid_rows = ensembled_test_predictions[valid_test_rows_for_eval.values]

            if not test_true_counts.empty:
                test_rmse = rmse(test_true_counts, test_predictions_for_valid_rows)
                print(f"Test Set RMSE (against ground truth): {test_rmse}")
            else:
                print("No valid ground truth 'violation_count' available in test file for RMSE calculation.")
        else:
            print("No ground truth 'violation_count' in test file, skipping test RMSE calculation.")

if __name__ == "__main__":
    main()
