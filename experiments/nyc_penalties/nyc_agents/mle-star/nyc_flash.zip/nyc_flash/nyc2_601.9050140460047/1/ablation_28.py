
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return None
    except pd.errors.EmptyDataError:
        print(f"Warning: File is empty at {file_path}")
        return pd.DataFrame() # Return empty DataFrame to avoid further errors
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return None

def run_experiment(catboost_params, features_to_exclude=None, experiment_name=""):
    # Load training data
    INPUT_DIR = './input'
    TRAIN_FILE = 'violations_per_street_2022.csv' # Always use the default train path for experiments
    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)
    
    # Use a fresh copy of the original data for each experiment
    original_train_df = load_data(train_df_path)

    if original_train_df is None or original_train_df.empty:
        print(f"Training data could not be loaded or is empty for {experiment_name}. Exiting experiment.")
        return None

    train_df = original_train_df.copy() # Work on a copy

    # Ensure required columns are present in the training data
    required_train_cols = ['street_name', 'violation_description', 'violation_count']
    if not all(col in train_df.columns for col in required_train_cols):
        print(f"Error: Training data missing one or more required columns for {experiment_name}: {required_train_cols}")
        return None

    # --- Feature Engineering and Augmentation ---
    # Convert categorical features to string type explicitly for CatBoost
    train_df['street_name'] = train_df['street_name'].astype(str)
    train_df['violation_description'] = train_df['violation_description'].astype(str)
    # Handle potential NaN values in categorical features by filling them with a placeholder
    train_df['street_name'] = train_df['street_name'].fillna('UNKNOWN_STREET')
    train_df['violation_description'] = train_df['violation_description'].fillna('UNKNOWN_VIOLATION')

    # Ensure target variable is numeric and handle potential NaNs (e.g., fill with 0 or mean)
    train_df['violation_count'] = pd.to_numeric(train_df['violation_count'], errors='coerce')
    train_df['violation_count'] = train_df['violation_count'].fillna(0) # Fill NaNs in target with 0
    # Ensure violation counts are non-negative
    train_df['violation_count'] = train_df['violation_count'].clip(lower=0)


    # --- Enhanced Feature Engineering ---
    train_df['violation_description_length'] = train_df['violation_description'].apply(len)
    train_df['violation_description_word_count'] = train_df['violation_description'].apply(lambda x: len(str(x).split()))
    train_df['street_name_desc_len_interaction'] = \
        train_df['street_name'].astype(str) + '_' + train_df['violation_description_length'].astype(str)
    train_df['street_name_desc_len_interaction'] = train_df['street_name_desc_len_interaction'].astype(str)

    # --- Prepare Data for Model ---
    initial_features = [
        'street_name',
        'violation_description',
        'violation_description_length',
        'violation_description_word_count',
        'street_name_desc_len_interaction'
    ]
    
    # Filter features based on features_to_exclude
    current_features = [f for f in initial_features if f not in (features_to_exclude if features_to_exclude else [])]
    target = 'violation_count'

    X = train_df[current_features]
    y = np.log1p(train_df[target])

    categorical_features_indices = [i for i, col in enumerate(current_features) if X[col].dtype == 'object']

    # --- Split Training Data for Validation ---
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices)

    # --- Model Training ---
    model = CatBoostRegressor(**catboost_params)

    model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=catboost_params.get('early_stopping_rounds', 100), verbose=False)

    # --- Validation ---
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log)
    val_predictions[val_predictions < 0] = 0

    rmse_val = np.sqrt(mean_squared_error(np.expm1(y_val), val_predictions))
    return rmse_val

# Define baseline CatBoost parameters
baseline_catboost_params = {
    'iterations': 1000,
    'learning_rate': 0.03,
    'depth': 9,
    'l2_leaf_reg': 3,
    'eval_metric': 'RMSE',
    'random_seed': 42,
    'verbose': 0,
    'early_stopping_rounds': 100,
    'thread_count': -1
}

# --- Baseline Experiment ---
baseline_rmse = run_experiment(baseline_catboost_params, experiment_name="Baseline")
print(f"Baseline Validation RMSE: {baseline_rmse}")

# --- Ablation 1: CatBoost depth from 9 to 5 ---
ablation1_catboost_params = baseline_catboost_params.copy()
ablation1_catboost_params['depth'] = 5
ablation1_rmse = run_experiment(ablation1_catboost_params, experiment_name="Ablation 1 (Depth 5)")
print(f"Ablation 1 (Depth 5) Validation RMSE: {ablation1_rmse}")

# --- Ablation 2: CatBoost learning_rate from 0.03 to 0.01 ---
ablation2_catboost_params = baseline_catboost_params.copy()
ablation2_catboost_params['learning_rate'] = 0.01
ablation2_rmse = run_experiment(ablation2_catboost_params, experiment_name="Ablation 2 (LR 0.01)")
print(f"Ablation 2 (LR 0.01) Validation RMSE: {ablation2_rmse}")

# --- Ablation 3: Remove 'violation_description_word_count' feature ---
ablation3_rmse = run_experiment(baseline_catboost_params, features_to_exclude=['violation_description_word_count'], experiment_name="Ablation 3 (No Word Count)")
print(f"Ablation 3 (No Word Count) Validation RMSE: {ablation3_rmse}")

# --- Conclusion ---
results = {
    "Baseline": baseline_rmse,
    "Ablation 1 (CatBoost depth changed from 9 to 5)": ablation1_rmse,
    "Ablation 2 (CatBoost learning_rate changed from 0.03 to 0.01)": ablation2_rmse,
    "Ablation 3 (Removal of 'violation_description_word_count' feature)": ablation3_rmse
}

# Ensure all RMSEs are not None before calculating impacts
if all(rmse is not None for rmse in results.values()):
    impacts = {}
    impacts["CatBoost depth changed from 9 to 5"] = results["Ablation 1 (CatBoost depth changed from 9 to 5)"] - baseline_rmse
    impacts["CatBoost learning_rate changed from 0.03 to 0.01"] = results["Ablation 2 (CatBoost learning_rate changed from 0.03 to 0.01)"] - baseline_rmse
    impacts["Removal of 'violation_description_word_count' feature"] = results["Ablation 3 (Removal of 'violation_description_word_count' feature)"] - baseline_rmse

    most_impactful_change_desc = ""
    max_abs_impact = 0

    for desc, impact in impacts.items():
        if abs(impact) > max_abs_impact:
            max_abs_impact = abs(impact)
            most_impactful_change_desc = desc
    
    print_statement = ""
    if most_impactful_change_desc:
        impact_value = impacts[most_impactful_change_desc]
        if impact_value > 0: # Ablation degraded performance -> original component was beneficial
            original_component = ""
            if "depth changed from 9 to 5" in most_impactful_change_desc:
                original_component = "CatBoost depth = 9"
            elif "learning_rate changed from 0.03 to 0.01" in most_impactful_change_desc:
                original_component = "CatBoost learning_rate = 0.03"
            elif "Removal of 'violation_description_word_count' feature" in most_impactful_change_desc:
                original_component = "'violation_description_word_count' feature"
            print_statement = f"The '{original_component}' contributed most positively to the overall performance."
        elif impact_value < 0: # Ablation improved performance -> original component was detrimental
            original_component = ""
            if "depth changed from 9 to 5" in most_impactful_change_desc:
                original_component = "CatBoost depth = 9"
            elif "learning_rate changed from 0.03 to 0.01" in most_impactful_change_desc:
                original_component = "CatBoost learning_rate = 0.03"
            elif "Removal of 'violation_description_word_count' feature" in most_impactful_change_desc:
                original_component = "'violation_description_word_count' feature"
            print_statement = f"The '{original_component}' contributed most negatively to the overall performance."
        else:
            print_statement = "No single component had a dominant impact on performance among the ablations."
    else:
        print_statement = "No significant impact found among the ablations."
    print(print_statement)
else:
    print("Could not determine the most contributing part due to missing experiment results.")

