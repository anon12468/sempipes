
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os
import glob

# Global regex for street types
street_types_regex = r'\b(STREET|AVENUE|ROAD|BOULEVARD|DRIVE|COURT|LANE|PLACE|TERRACE|WAY|PARKWAY|SQUARE|CIRCLE|FREEWAY|HIGHWAY|JUNCTION|LOOP|MOUNTAIN|OVAL|PARK|PASS|PATH|PIKE|POINT|RIVER|RANCH|ROW|ROUTE|SHOALS|SHORE|SPRING|SPUR|STATION|TRACE|TRACK|TRAIL|TUNNEL|UNION|VALLEY|XING|CRK|CTY|DIV|EXPY|FRY|GTWY|GRN|GRV|HOLW|KY|MEWS|MNR|MSN|OPAS|PLZ|RMRK|RUN|SHL|SPGS|TRWY|VLGS)\b'

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return None
    except pd.errors.EmptyDataError:
        print(f"Warning: File is empty at {file_path}")
        return pd.DataFrame()
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return None

def get_avg_word_len(text):
    text_str = str(text)
    words = text_str.split()
    if not words:
        return 0
    return sum(len(word) for word in words) / len(words)

def get_numeric_prop(text):
    text_str = str(text)
    if not text_str:
        return 0
    num_digits = sum(c.isdigit() for c in text_str)
    return num_digits / len(text_str)

def preprocess_and_engineer_features(df):
    """Applies initial preprocessing and all feature engineering steps."""
    
    df_copy = df.copy()

    # Convert categorical features to string type explicitly for CatBoost
    df_copy['street_name'] = df_copy['street_name'].astype(str)
    df_copy['violation_description'] = df_copy['violation_description'].astype(str)
    # Handle potential NaN values in categorical features by filling them with a placeholder
    df_copy['street_name'] = df_copy['street_name'].fillna('UNKNOWN_STREET')
    df_copy['violation_description'] = df_copy['violation_description'].fillna('UNKNOWN_VIOLATION')

    # Ensure target variable is numeric and handle potential NaNs (e.g., fill with 0 or mean)
    df_copy['violation_count'] = pd.to_numeric(df_copy['violation_count'], errors='coerce')
    df_copy['violation_count'] = df_copy['violation_count'].fillna(0)
    df_copy['violation_count'] = df_copy['violation_count'].clip(lower=0)

    # Enhanced Feature Engineering (from original script)
    df_copy['violation_description_length'] = df_copy['violation_description'].apply(len)
    df_copy['violation_description_word_count'] = df_copy['violation_description'].apply(lambda x: len(str(x).split()))

    # Deconstruct 'street_name'
    df_copy['street_name_len'] = df_copy['street_name'].astype(str).str.len()
    df_copy['street_name_has_digit'] = df_copy['street_name'].astype(str).str.contains(r'\d', na=False).astype(int)
    df_copy['street_type'] = df_copy['street_name'].astype(str).str.upper().str.extract(street_types_regex + '$', expand=False).fillna('OTHER')

    # Extract more intricate numerical features from 'violation_description'
    df_copy['violation_desc_avg_word_len'] = df_copy['violation_description'].apply(get_avg_word_len)
    df_copy['violation_desc_numeric_prop'] = df_copy['violation_description'].apply(get_numeric_prop)
    df_copy['violation_desc_punct_count_dot'] = df_copy['violation_description'].astype(str).str.count(r'\.')
    df_copy['violation_desc_punct_count_comma'] = df_copy['violation_description'].astype(str).str.count(r',')
    df_copy['violation_desc_punct_count_qmark'] = df_copy['violation_description'].astype(str).str.count(r'\?')
    df_copy['violation_desc_punct_count_exclam'] = df_copy['violation_description'].astype(str).str.count(r'!')

    # Generate targeted numerical interaction features
    df_copy['street_name_desc_len_interaction'] = \
        df_copy['street_name'].astype(str) + '_' + df_copy['violation_description_length'].astype(str)
    df_copy['street_name_desc_len_interaction'] = df_copy['street_name_desc_len_interaction'].astype(str)

    df_copy['street_len_x_desc_avg_word_len'] = df_copy['street_name_len'] * df_copy['violation_desc_avg_word_len']
    df_copy['street_has_digit_x_desc_num_prop'] = df_copy['street_name_has_digit'] * df_copy['violation_desc_numeric_prop']
    df_copy['desc_len_x_desc_num_prop'] = df_copy['violation_description_length'] * df_copy['violation_desc_numeric_prop']
    df_copy['desc_word_count_x_avg_word_len'] = df_copy['violation_description_word_count'] * df_copy['violation_desc_avg_word_len']
    
    return df_copy

def train_and_evaluate(processed_df, features_to_use, target_col='violation_count'):
    """Trains a CatBoost model and evaluates it, returning RMSE."""

    X = processed_df[features_to_use]
    y = np.log1p(processed_df[target_col])

    # Identify categorical features by their column names
    categorical_features_indices = []
    for i, col in enumerate(features_to_use):
        if X[col].dtype == 'object': # CatBoost can handle string types as categorical
            categorical_features_indices.append(i)

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices)

    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.03,
        depth=9,
        l2_leaf_reg=3,
        eval_metric='RMSE',
        random_seed=42,
        verbose=0,
        early_stopping_rounds=100,
        thread_count=-1,
    )

    model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=100, verbose=False)

    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log)
    val_predictions[val_predictions < 0] = 0

    rmse_val = np.sqrt(mean_squared_error(np.expm1(y_val), val_predictions))
    return rmse_val

if __name__ == "__main__":
    INPUT_DIR = './input'
    TRAIN_FILE = 'violations_per_street_2022.csv'
    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)

    print(f"Loading and preprocessing data from: {train_df_path}")
    raw_train_df = load_data(train_df_path)

    if raw_train_df is None or raw_train_df.empty:
        print("Training data could not be loaded or is empty. Exiting.")
        exit()

    processed_df = preprocess_and_engineer_features(raw_train_df)

    base_features = [
        'street_name',
        'violation_description',
        'violation_description_length',
        'violation_description_word_count',
        'street_name_desc_len_interaction',
        'street_name_len',
        'street_name_has_digit',
        'street_type',
        'violation_desc_avg_word_len',
        'violation_desc_numeric_prop',
        'violation_desc_punct_count_dot',
        'violation_desc_punct_count_comma',
        'violation_desc_punct_count_qmark',
        'violation_desc_punct_count_exclam',
        'street_len_x_desc_avg_word_len',
        'street_has_digit_x_desc_num_prop',
        'desc_len_x_desc_num_prop',
        'desc_word_count_x_avg_word_len'
    ]

    ablation_results = {}

    # --- Baseline ---
    print("\n--- Running Baseline Model ---")
    baseline_rmse = train_and_evaluate(processed_df, base_features)
    ablation_results['Baseline'] = baseline_rmse
    print(f"Baseline Validation RMSE: {baseline_rmse:.4f}")

    # --- Ablation 1: No 'street_type' feature ---
    print("\n--- Running Ablation 1: No 'street_type' feature ---")
    ablation1_features = [f for f in base_features if f != 'street_type']
    ablation1_rmse = train_and_evaluate(processed_df, ablation1_features)
    ablation_results['No street_type feature'] = ablation1_rmse
    print(f"Ablation 1 Validation RMSE (No street_type): {ablation1_rmse:.4f}")

    # --- Ablation 2: No detailed 'violation_description' numerical features ---
    print("\n--- Running Ablation 2: No detailed 'violation_description' numerical features ---")
    detailed_desc_numerical_features = [
        'violation_desc_avg_word_len',
        'violation_desc_numeric_prop',
        'violation_desc_punct_count_dot',
        'violation_desc_punct_count_comma',
        'violation_desc_punct_count_qmark',
        'violation_desc_punct_count_exclam'
    ]
    ablation2_features = [f for f in base_features if f not in detailed_desc_numerical_features]
    ablation2_rmse = train_and_evaluate(processed_df, ablation2_features)
    ablation_results['No detailed violation_description numerical features'] = ablation2_rmse
    print(f"Ablation 2 Validation RMSE (No detailed violation_description numerical features): {ablation2_rmse:.4f}")

    # --- Ablation 3: No new numerical interaction features ---
    print("\n--- Running Ablation 3: No new numerical interaction features ---")
    new_numerical_interaction_features = [
        'street_len_x_desc_avg_word_len',
        'street_has_digit_x_desc_num_prop',
        'desc_len_x_desc_num_prop',
        'desc_word_count_x_avg_word_len'
    ]
    ablation3_features = [f for f in base_features if f not in new_numerical_interaction_features]
    ablation3_rmse = train_and_evaluate(processed_df, ablation3_features)
    ablation_results['No new numerical interaction features'] = ablation3_rmse
    print(f"Ablation 3 Validation RMSE (No new numerical interaction features): {ablation3_rmse:.4f}")

    # --- Conclusion ---
    print("\n--- Ablation Study Conclusion ---")
    
    max_degradation = -float('inf')
    most_contributing_part_name = "None (all ablated parts either had no impact or were detrimental)"
    
    print(f"Baseline RMSE: {ablation_results['Baseline']:.4f}")
    for name, rmse in ablation_results.items():
        if name == 'Baseline':
            continue
        change_from_baseline = rmse - ablation_results['Baseline']
        print(f"'{name}': RMSE {rmse:.4f} (Change vs Baseline: {change_from_baseline:+.4f})")
        
        # A positive change (increase in RMSE) when a part is removed means that part was beneficial.
        # We are looking for the largest positive change to identify the most contributing part.
        if change_from_baseline > max_degradation:
            max_degradation = change_from_baseline
            most_contributing_part_name = name
            
    if max_degradation > 0:
        print(f"\nThe part that contributes most positively to the overall performance (largest RMSE degradation when removed) is: '{most_contributing_part_name}', with a degradation of {max_degradation:.4f} in RMSE.")
    else:
        # This implies no ablation caused a performance degradation (RMSE increase).
        # This means the ablated parts were either neutral or detrimental.
        min_improvement = float('inf')
        most_detrimental_part_name = "None"
        for name, rmse in ablation_results.items():
            if name == 'Baseline':
                continue
            change_from_baseline = rmse - ablation_results['Baseline']
            if change_from_baseline < min_improvement:
                min_improvement = change_from_baseline
                most_detrimental_part_name = name
        
        if min_improvement < 0:
            print(f"\nNo component strongly improved performance when removed (indicating no strong positive contribution from these components). Instead, the most detrimental part among those ablated was: '{most_detrimental_part_name}', as its removal improved the RMSE by {-min_improvement:.4f}.")
        else:
            print("\nAll ablated components had negligible or no impact on performance.")
