
import pandas as pd
import numpy as np
import os
import argparse
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader

# Function to calculate RMSE
def rmse(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))

# Custom Label Encoder to handle unseen categories and NaNs
class CustomLabelEncoder:
    def __init__(self):
        self.mapping = {}
        self.inverse_mapping = {}
        self.next_id = 0
        self.unknown_token = '_UNSEEN_' # Special token for values not seen during fit or NaN

    def fit(self, series):
        unique_values = series.dropna().astype(str).unique()
        for val in unique_values:
            if val not in self.mapping:
                self.mapping[val] = self.next_id
                self.inverse_mapping[self.next_id] = val
                self.next_id += 1
        # Assign a special ID for the unknown token if not already assigned
        if self.unknown_token not in self.mapping:
            self.mapping[self.unknown_token] = self.next_id
            self.inverse_mapping[self.next_id] = self.unknown_token
            self.next_id += 1
        return self

    def transform(self, series):
        # Create a full series initialized with the unknown token ID
        transformed_series = pd.Series(
            np.full(len(series), self.mapping[self.unknown_token], dtype=int),
            index=series.index
        )
        
        # Apply mapping to non-NaN values that were seen during fitting
        known_values_indices = series.dropna().index
        transformed_series.loc[known_values_indices] = series.loc[known_values_indices].astype(str).apply(
            lambda x: self.mapping.get(x, self.mapping[self.unknown_token])
        )
        return transformed_series

    def vocab_size(self):
        return self.next_id # Total number of unique values + 1 for unknown_token

# PyTorch Dataset
class NYC_Parking_Dataset(Dataset):
    def __init__(self, df, categorical_cols, numerical_cols, target_col=None):
        self.categorical_data = df[categorical_cols].values
        self.numerical_data = df[numerical_cols].values
        self.target = df[target_col].values if target_col else None

    def __len__(self):
        return len(self.categorical_data)

    def __getitem__(self, idx):
        cat_features = torch.LongTensor(self.categorical_data[idx])
        num_features = torch.FloatTensor(self.numerical_data[idx])
        if self.target is not None:
            return cat_features, num_features, torch.FloatTensor([self.target[idx]])
        return cat_features, num_features

# Feed-forward Neural Network with Entity Embeddings
class NN_With_Embeddings(nn.Module):
    def __init__(self, embedding_dims, numerical_input_dim, hidden_layers_dims=[128, 64]):
        super().__init__()
        self.embeddings = nn.ModuleList([
            nn.Embedding(num_embeddings, embedding_dim)
            for num_embeddings, embedding_dim in embedding_dims
        ])
        
        # Calculate total size of concatenated features
        total_embedding_dim = sum(embedding_dim for _, embedding_dim in embedding_dims)
        self.input_dim = total_embedding_dim + numerical_input_dim

        layers = []
        # Input layer
        layers.append(nn.Linear(self.input_dim, hidden_layers_dims[0]))
        layers.append(nn.ReLU())
        
        # Hidden layers
        for i in range(len(hidden_layers_dims) - 1):
            layers.append(nn.Linear(hidden_layers_dims[i], hidden_layers_dims[i+1]))
            layers.append(nn.ReLU())
        
        # Output layer - single output for regression
        layers.append(nn.Linear(hidden_layers_dims[-1], 1))
        self.model = nn.Sequential(*layers)

    def forward(self, categorical_inputs, numerical_inputs):
        embedding_outputs = [
            embedding_layer(categorical_inputs[:, i])
            for i, embedding_layer in enumerate(self.embeddings)
        ]
        
        # Concatenate all embedding outputs
        if embedding_outputs:
            all_features = torch.cat(embedding_outputs, 1)
        else: # Case if no categorical features are present
            all_features = torch.empty((numerical_inputs.shape[0], 0), device=numerical_inputs.device)

        # Concatenate with numerical features
        all_features = torch.cat([all_features, numerical_inputs], 1)
        
        # Pass through dense layers
        output = self.model(all_features)
        
        # Apply ReLU activation for non-negative counts as per requirement
        return torch.relu(output)

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations using PyTorch NN with Entity Embeddings.")
    parser.add_argument("--train-path", type=str, default="violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Optional path to the 2023 test data CSV for predictions.")
    args = parser.parse_args()

    INPUT_DIR = os.path.join(os.getcwd(), 'input')

    # Define full file paths for all data files
    train_violations_file = os.path.join(INPUT_DIR, args.train_path)
    parking_codes_file = os.path.join(INPUT_DIR, 'parking_violations_codes.csv')
    street_geo_file = os.path.join(INPUT_DIR, 'nyc_streets_geographic_data.csv')

    # Load data with error handling
    try:
        train_df_raw = pd.read_csv(train_violations_file)
        parking_codes_df_raw = pd.read_csv(parking_codes_file)
        street_geo_df_raw = pd.read_csv(street_geo_file)
    except FileNotFoundError as e:
        print(f"Error loading a data file: {e}")
        print(f"Please ensure all required CSV files are present in the '{INPUT_DIR}' directory. "
              f"Current working directory: {os.getcwd()}")
        return

    # --- Preprocessing for auxiliary tables (done once) ---
    parking_codes_df = parking_codes_df_raw.copy()
    parking_codes_df_unique = pd.DataFrame(columns=['violation_type_lower', 'violation_code', 'violation_definition'])
    if all(col in parking_codes_df.columns for col in ['Code', 'Description', 'Definition']):
        parking_codes_df.rename(columns={'Code': 'violation_code', 'Description': 'violation_type', 'Definition': 'violation_definition'}, inplace=True)
        parking_codes_df['violation_type_lower'] = parking_codes_df['violation_type'].str.lower().str.strip()
        # Keep only unique violation types for merging
        parking_codes_df_unique = parking_codes_df.drop_duplicates(subset=['violation_type_lower'], keep='first')[['violation_type_lower', 'violation_code', 'violation_definition']]
    else:
        print("Warning: Expected columns 'Code', 'Description', 'Definition' not found in parking_violations_codes.csv. Violation code features will be missing.")

    street_geo_df = street_geo_df_raw.copy()
    street_geo_agg = pd.DataFrame()
    if 'street_name' in street_geo_df.columns and 'borough' in street_geo_df.columns:
        street_geo_df.columns = street_geo_df.columns.str.lower().str.replace(' ', '_')
        street_geo_df['street_name_lower'] = street_geo_df['street_name'].str.lower().str.strip()
        
        if 'zip_code' in street_geo_df.columns:
            street_geo_df['zip_code'] = street_geo_df['zip_code'].astype(str)
        else:
            street_geo_df['zip_code'] = 'Unknown'

        agg_functions = {
            'borough': lambda x: x.mode()[0] if not x.mode().empty else 'Unknown',
            'latitude': 'mean',
            'longitude': 'mean',
            'segment_length': 'sum',
            'zip_code': lambda x: x.mode()[0] if not x.mode().empty else 'Unknown'
        }
        # Filter for existing columns to avoid key errors if some numerical columns are missing
        existing_agg_functions = {k: v for k, v in agg_functions.items() if k in street_geo_df.columns}

        street_geo_agg = street_geo_df.groupby('street_name_lower').agg(existing_agg_functions).reset_index()
    else:
        print("Warning: Essential 'street_name' or 'borough' columns not found in nyc_streets_geographic_data.csv. Street geo features will be missing.")

    # --- Feature Engineering Function ---
    def apply_feature_engineering(df, parking_codes_unique_df, street_geo_aggregated_df):
        df_copy = df.copy()

        df_copy.rename(columns={'Street Name': 'street_name', 'Violation Description': 'violation_type'}, inplace=True)
        
        if 'violation_type' in df_copy.columns and not parking_codes_unique_df.empty:
            df_copy['violation_type_lower'] = df_copy['violation_type'].str.lower().str.strip()
            df_copy = pd.merge(df_copy, parking_codes_unique_df, on='violation_type_lower', how='left')
            df_copy.drop(columns=['violation_type_lower'], errors='ignore', inplace=True)
        else:
            df_copy['violation_code'] = np.nan
            df_copy['violation_definition'] = np.nan

        if 'street_name' in df_copy.columns and not street_geo_aggregated_df.empty:
            df_copy['street_name_lower'] = df_copy['street_name'].str.lower().str.strip()
            df_copy = pd.merge(df_copy, street_geo_aggregated_df, on='street_name_lower', how='left')
            df_copy.drop(columns=['street_name_lower'], errors='ignore', inplace=True)
        else:
            for col in ['borough', 'latitude', 'longitude', 'segment_length', 'zip_code']:
                df_copy[col] = np.nan

        return df_copy

    # Apply feature engineering to training data
    train_df = apply_feature_engineering(train_df_raw.copy(), parking_codes_df_unique, street_geo_agg)
    
    TARGET = 'violation_count'
    if TARGET not in train_df.columns:
        print(f"Error: Target column '{TARGET}' not found in training data. Cannot proceed.")
        return
    
    train_df[TARGET] = pd.to_numeric(train_df[TARGET], errors='coerce').fillna(0).astype(int)
    train_df = train_df[train_df[TARGET] >= 0] # Ensure non-negative counts

    # --- Feature Selection and Type Handling ---
    categorical_features_candidates = ['street_name', 'violation_type', 'violation_code', 'violation_definition', 'borough', 'zip_code']
    numerical_features_candidates = ['latitude', 'longitude', 'segment_length']

    # Filter features based on availability in the dataframe
    final_categorical_features = [col for col in categorical_features_candidates if col in train_df.columns]
    final_numerical_features = [col for col in numerical_features_candidates if col in train_df.columns]

    # Prepare data for model: Label Encoding for categorical, Scaling for numerical
    encoders = {col: CustomLabelEncoder() for col in final_categorical_features}
    for col in final_categorical_features:
        train_df[col] = encoders[col].fit_transform(train_df[col])

    # Fill NaN values for numerical features before scaling
    for col in final_numerical_features:
        train_df[col] = train_df[col].fillna(0.0).astype(float) # Using 0 for simplicity, mean/median could be alternatives
    
    scaler = StandardScaler()
    if final_numerical_features: # Only fit scaler if there are numerical features
        train_df[final_numerical_features] = scaler.fit_transform(train_df[final_numerical_features])
    else:
        print("Warning: No numerical features found for scaling.")

    # Split 2022 data for validation
    X = train_df[final_categorical_features + final_numerical_features]
    y = train_df[TARGET]
    
    X_train_model, X_val, y_train_model, y_val = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    # Reconstruct dataframes for dataset creation
    train_data = pd.concat([X_train_model, y_train_model.to_frame()], axis=1)
    val_data = pd.concat([X_val, y_val.to_frame()], axis=1)
    
    train_dataset = NYC_Parking_Dataset(train_data, final_categorical_features, final_numerical_features, TARGET)
    val_dataset = NYC_Parking_Dataset(val_data, final_categorical_features, final_numerical_features, TARGET)

    BATCH_SIZE = 64
    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False)

    # Determine embedding dimensions
    embedding_dims = []
    for col in final_categorical_features:
        vocab_size = encoders[col].vocab_size()
        embedding_dim = min(50, (vocab_size // 2) + 1) # Rule of thumb for embedding dimension
        embedding_dims.append((vocab_size, embedding_dim))
    
    numerical_input_dim = len(final_numerical_features)

    # Initialize model on appropriate device (CPU/GPU)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = NN_With_Embeddings(embedding_dims, numerical_input_dim).to(device)

    # Compile the model
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    loss_fn = nn.MSELoss() # RMSE is sqrt of MSE, so MSE is the direct loss function

    # Train the model
    EPOCHS = 50
    print("Starting model training...")
    for epoch in range(EPOCHS):
        model.train()
        total_loss = 0
        for cat_batch, num_batch, target_batch in train_loader:
            # Move data to device
            cat_batch, num_batch, target_batch = cat_batch.to(device), num_batch.to(device), target_batch.to(device)

            optimizer.zero_grad()
            predictions = model(cat_batch, num_batch)
            loss = loss_fn(predictions, target_batch)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
        
        # Validation evaluation
        model.eval()
        val_preds_list = []
        val_targets_list = []
        with torch.no_grad():
            for cat_batch, num_batch, target_batch in val_loader:
                cat_batch, num_batch, target_batch = cat_batch.to(device), num_batch.to(device), target_batch.to(device)
                predictions = model(cat_batch, num_batch)
                val_preds_list.extend(predictions.cpu().numpy().flatten())
                val_targets_list.extend(target_batch.cpu().numpy().flatten())
        
        val_preds_np = np.array(val_preds_list)
        val_targets_np = np.array(val_targets_list)
        
        # Clip and round predictions for RMSE calculation
        val_rmse = rmse(val_targets_np, np.maximum(0, np.round(val_preds_np)).astype(int))
        if (epoch + 1) % 10 == 0 or epoch == 1: # Print more frequently to show progress
            print(f"Epoch {epoch+1}/{EPOCHS}, Training Loss: {total_loss/len(train_loader):.4f}, Validation RMSE: {val_rmse:.4f}")
    
    print("Model training complete.")

    # --- Final Validation Performance ---
    model.eval()
    val_preds_list = []
    val_targets_list = []
    with torch.no_grad():
        for cat_batch, num_batch, target_batch in val_loader:
            cat_batch, num_batch, target_batch = cat_batch.to(device), num_batch.to(device), target_batch.to(device)
            predictions = model(cat_batch, num_batch)
            val_preds_list.extend(predictions.cpu().numpy().flatten())
            val_targets_list.extend(target_batch.cpu().numpy().flatten())
    
    val_predictions = np.array(val_preds_list)
    val_predictions = np.maximum(0, np.round(val_predictions)).astype(int) # Ensure non-negative and integer predictions
    final_validation_score = rmse(np.array(val_targets_list), val_predictions)
    print(f"Final Validation Performance: {final_validation_score}")

    # --- Prediction for Test Data (if provided) ---
    if args.test_path:
        test_violations_file = os.path.join(INPUT_DIR, args.test_path)
        print(f"Loading test data from: {test_violations_file}")
        try:
            test_df_raw = pd.read_csv(test_violations_file)
        except FileNotFoundError as e:
            print(f"Error loading test data: {e}")
            print(f"Please ensure the test file '{args.test_path}' is present in the '{INPUT_DIR}' directory.")
            return

        submission_output_df = test_df_raw[['Street Name', 'Violation Description']].copy()
        
        test_df = apply_feature_engineering(test_df_raw.copy(), parking_codes_df_unique, street_geo_agg)
        
        # Apply trained encoders and scaler to test data
        for col in final_categorical_features:
            if col in test_df.columns:
                test_df[col] = encoders[col].transform(test_df[col])
            else: # If a categorical column is missing in test, fill with unknown token ID
                test_df[col] = encoders[col].mapping[encoders[col].unknown_token]

        if final_numerical_features:
            for col in final_numerical_features:
                if col not in test_df.columns:
                    test_df[col] = 0.0 # Add missing numerical columns and fill with a default
                test_df[col] = test_df[col].fillna(0.0).astype(float) # Fill NaNs for existing numerical columns
            test_df[final_numerical_features] = scaler.transform(test_df[final_numerical_features])
        else:
            print("Warning: No numerical features in test data based on training configuration.")
        
        # Identify unseen key pairs (street_name, violation_type)
        train_keys = set(train_df_raw.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1))
        test_keys = set(test_df_raw.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1))
        unseen_keys_count = len(test_keys - train_keys)
        print(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_keys_count}")

        # Prepare test dataset and loader
        test_dataset = NYC_Parking_Dataset(test_df, final_categorical_features, final_numerical_features)
        test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False)

        # Generate predictions for the test data
        print("Generating predictions for test data...")
        model.eval()
        test_preds_list = []
        with torch.no_grad():
            for cat_batch, num_batch in test_loader:
                cat_batch, num_batch = cat_batch.to(device), num_batch.to(device)
                predictions = model(cat_batch, num_batch)
                test_preds_list.extend(predictions.cpu().numpy().flatten())
        
        test_predictions = np.array(test_preds_list)
        test_predictions = np.maximum(0, np.round(test_predictions)).astype(int)

        # Create submission file
        submission_output_df['predicted_count'] = test_predictions
        submission_output_df.rename(columns={'Street Name': 'street_name', 'Violation Description': 'violation_type'}, inplace=True)
        submission_output_df.to_csv('submission.csv', index=False)
        print("Submission file 'submission.csv' created.")

        # If test_df_raw has 'violation_count' (ground truth), calculate and report test RMSE
        test_target_col_name_raw = 'violation_count' 
        
        if test_target_col_name_raw in test_df_raw.columns and not test_df_raw[test_target_col_name_raw].isnull().all():
            test_true_counts_for_eval = pd.to_numeric(test_df_raw[test_target_col_name_raw], errors='coerce')
            valid_test_rows_for_eval = test_true_counts_for_eval.notna()
            
            test_true_counts = test_true_counts_for_eval[valid_test_rows_for_eval].astype(int)
            test_predictions_for_valid_rows = test_predictions[valid_test_rows_for_eval.values]

            if not test_true_counts.empty:
                test_rmse = rmse(test_true_counts, test_predictions_for_valid_rows)
                print(f"Test Set RMSE (against ground truth): {test_rmse}")
            else:
                print("No valid ground truth 'violation_count' available in test file for RMSE calculation.")
        else:
            print("No ground truth 'violation_count' in test file, skipping test RMSE calculation.")

if __name__ == "__main__":
    main()
