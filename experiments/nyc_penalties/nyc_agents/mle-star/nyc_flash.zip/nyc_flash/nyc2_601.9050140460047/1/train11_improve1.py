
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import NMF

# Ensure required libraries are installed
# You may need to run:
# pip install pandas numpy scikit-learn catboost

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return None
    except pd.errors.EmptyDataError:
        print(f"Warning: File is empty at {file_path}")
        return pd.DataFrame() # Return empty DataFrame to avoid further errors
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return None

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV relative to INPUT_DIR.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional path to the test/evaluation data CSV relative to INPUT_DIR for prediction.')
    args = parser.parse_args()

    INPUT_DIR = './input' # All input data is stored in this directory
    TRAIN_FILE = args.train_path
    TEST_FILE = args.test_path

    # --- 1. Load Training Data ---
    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)
    print(f"Loading training data from: {train_df_path}")
    train_df = load_data(train_df_path)

    if train_df is None or train_df.empty:
        print("Training data could not be loaded or is empty. Exiting.")
        return

    print(f"Original training data shape: {train_df.shape}")
    print("Training data columns:", train_df.columns.tolist())

    # Ensure required columns are present in the training data
    required_train_cols = ['street_name', 'violation_description', 'violation_count']
    if not all(col in train_df.columns for col in required_train_cols):
        print(f"Error: Training data missing one or more required columns: {required_train_cols}")
        print("Available columns:", train_df.columns.tolist())
        return

    # --- 2. Feature Engineering and Augmentation ---
    # Convert categorical features to string type explicitly for CatBoost
    train_df['street_name'] = train_df['street_name'].astype(str)
    train_df['violation_description'] = train_df['violation_description'].astype(str)
    # Handle potential NaN values in categorical features by filling them with a placeholder
    train_df['street_name'] = train_df['street_name'].fillna('UNKNOWN_STREET')
    train_df['violation_description'] = train_df['violation_description'].fillna('UNKNOWN_VIOLATION')

    # Ensure target variable is numeric and handle potential NaNs (e.g., fill with 0 or mean)
    train_df['violation_count'] = pd.to_numeric(train_df['violation_count'], errors='coerce')
    train_df['violation_count'] = train_df['violation_count'].fillna(0) # Fill NaNs in target with 0
    # Ensure violation counts are non-negative
    train_df['violation_count'] = train_df['violation_count'].clip(lower=0)


    # Enhanced Feature Engineering - Numerical features from 'violation_description'
    train_df['violation_description_length'] = train_df['violation_description'].apply(len)
    train_df['violation_description_word_count'] = train_df['violation_description'].apply(lambda x: len(str(x).split()))

    # Apply NMF for topic modeling on 'violation_description'
    # First, handle potential NaN values by converting to empty strings
    train_df['violation_description_processed'] = train_df['violation_description'].fillna('')

    # Initialize TF-IDF Vectorizer
    # min_df and max_df can be tuned. max_features limits the vocabulary size.
    tfidf_vectorizer = TfidfVectorizer(max_features=5000, stop_words='english', min_df=5, max_df=0.9)
    # Fit TF-IDF on the training data's processed descriptions
    tfidf_matrix = tfidf_vectorizer.fit_transform(train_df['violation_description_processed'])

    # Determine n_topics dynamically to avoid NMF ValueError with 'nndsvda' init
    # The constraint for 'nndsvda' init is n_components <= min(n_samples, n_features)
    # n_samples = tfidf_matrix.shape[0], n_features = tfidf_matrix.shape[1]
    original_desired_n_topics = 10
    min_dim_for_nmf = min(tfidf_matrix.shape[0], tfidf_matrix.shape[1])
    n_topics_for_nmf = min(original_desired_n_topics, min_dim_for_nmf)

    # Initialize NMF related variables
    nmf_model = None
    nmf_feature_names = []

    if n_topics_for_nmf >= 1:
        print(f"Applying NMF with {n_topics_for_nmf} components.")
        nmf_model = NMF(n_components=n_topics_for_nmf, random_state=42, init='nndsvda', max_iter=200)

        # Fit NMF model and transform the TF-IDF matrix to get topic distributions
        nmf_features = nmf_model.fit_transform(tfidf_matrix)

        # Add NMF topic features to the training DataFrame
        for i in range(n_topics_for_nmf):
            col_name = f'violation_topic_{i}'
            train_df[col_name] = nmf_features[:, i]
            nmf_feature_names.append(col_name)
    else:
        print(f"Warning: Skipping NMF feature creation. "
              f"min(n_samples, n_features) = {min_dim_for_nmf}. "
              f"Cannot apply NMF with {original_desired_n_topics} components when dimensions are too small or zero.")

    # Drop the temporary processed column after TF-IDF and NMF
    train_df = train_df.drop(columns=['violation_description_processed'])

    # Explore simple interaction features
    train_df['street_name_desc_len_interaction'] = \
        train_df['street_name'].astype(str) + '_' + train_df['violation_description_length'].astype(str)
    train_df['street_name_desc_len_interaction'] = train_df['street_name_desc_len_interaction'].astype(str)


    # --- 3. Prepare Data for Model ---
    features = [
        'street_name',
        'violation_description',
        'violation_description_length',
        'violation_description_word_count',
        'street_name_desc_len_interaction'
    ]
    # Add NMF features if they were created
    features.extend(nmf_feature_names)

    target = 'violation_count'

    X = train_df[features]
    # Apply log1p transformation to the target variable for training
    # This helps stabilize variance and handle skewed count data.
    y = np.log1p(train_df[target])

    # Identify categorical features dynamically based on the final X DataFrame
    # This must be done after `features` list is finalized and `X` is created
    categorical_features_indices = [i for i, col in enumerate(X.columns) if X[col].dtype == 'object']

    # --- 4. Split Training Data for Validation ---
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    # Create CatBoost Pool objects
    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices)

    # --- 5. Model Training ---
    model = CatBoostRegressor(
        iterations=1000, # Increased iterations for potentially better performance
        learning_rate=0.03, # Slightly reduced learning rate
        depth=9, # Slightly increased depth to capture more complex patterns
        l2_leaf_reg=3, # Introduced L2 regularization to prevent overfitting
        eval_metric='RMSE', # CatBoost will optimize RMSE on the log-transformed target
        random_seed=42,
        verbose=0, # Suppress verbose output during training iterations
        early_stopping_rounds=100, # Use early stopping to prevent overfitting
        thread_count=-1, # Use all available threads
        # bootstrap_type='Bernoulli', # Uncomment and adjust subsample if OOM occurs on large datasets
        # subsample=0.8
    )

    print("Training CatBoost model...")
    model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=100, verbose=False) # verbose=False for non-interactive output

    # --- 6. Validation ---
    # Predictions from the model are on the log1p scale
    val_predictions_log = model.predict(X_val)
    # Inverse transform predictions from log1p scale to original count scale
    val_predictions = np.expm1(val_predictions_log)
    # Ensure predictions are non-negative after inverse transformation
    val_predictions[val_predictions < 0] = 0

    # For RMSE calculation, y_val (true values) must also be inverse-transformed to the original scale
    rmse_val = np.sqrt(mean_squared_error(np.expm1(y_val), val_predictions))
    print(f"Final Validation Performance: {rmse_val}") # Required output format

    # --- 7. Prediction for Test/Evaluation File ---
    if TEST_FILE:
        test_df_path = os.path.join(INPUT_DIR, TEST_FILE)
        print(f"\nLoading test data from: {test_df_path}")
        test_df = load_data(test_df_path)

        if test_df is None or test_df.empty:
            print("Test data could not be loaded or is empty. Skipping prediction.")
            return

        print(f"Original test data shape: {test_df.shape}")
        print("Test data columns:", test_df.columns.tolist())

        # Ensure required columns are present in test set (excluding target if not there)
        required_test_cols = ['street_name', 'violation_description']
        if not all(col in test_df.columns for col in required_test_cols):
            print(f"Error: Test data missing one or more required columns: {required_test_cols}")
            print("Available columns:", test_df.columns.tolist())
            return

        # Store original key columns for submission
        submission_keys = test_df[['street_name', 'violation_description']].copy()

        # Apply same feature engineering and type conversion as training data
        test_df['street_name'] = test_df['street_name'].astype(str)
        test_df['violation_description'] = test_df['violation_description'].astype(str)
        # Handle potential NaN values in categorical features by filling them with a placeholder
        test_df['street_name'] = test_df['street_name'].fillna('UNKNOWN_STREET')
        test_df['violation_description'] = test_df['violation_description'].fillna('UNKNOWN_VIOLATION')

        # Apply same enhanced feature engineering as training data
        test_df['violation_description_length'] = test_df['violation_description'].apply(len)
        test_df['violation_description_word_count'] = test_df['violation_description'].apply(lambda x: len(str(x).split()))

        # NMF part for test data - must use fitted vectorizer and model
        test_df['violation_description_processed'] = test_df['violation_description'].fillna('')
        tfidf_matrix_test = tfidf_vectorizer.transform(test_df['violation_description_processed'])

        # If NMF was applied during training, apply it to the test data
        if nmf_model is not None:
            nmf_features_test = nmf_model.transform(tfidf_matrix_test)
            for i, col_name in enumerate(nmf_feature_names):
                test_df[col_name] = nmf_features_test[:, i]
        
        # Drop the temporary processed column
        test_df = test_df.drop(columns=['violation_description_processed'])

        test_df['street_name_desc_len_interaction'] = \
            test_df['street_name'].astype(str) + '_' + test_df['violation_description_length'].astype(str)
        test_df['street_name_desc_len_interaction'] = test_df['street_name_desc_len_interaction'].astype(str)

        X_test = test_df[features] # Use the *same* features list as training

        # Handle and report unseen keys in test set
        # Get unique features from training data (before log1p transformation for target)
        train_street_names = set(train_df['street_name'].unique())
        train_violation_descriptions = set(train_df['violation_description'].unique())

        unseen_streets_count = X_test[~X_test['street_name'].isin(train_street_names)].shape[0]
        unseen_violations_count = X_test[~X_test['violation_description'].isin(train_violation_descriptions)].shape[0]

        print(f"Number of test rows with unseen street names: {unseen_streets_count}")
        print(f"Number of test rows with unseen violation descriptions: {unseen_violations_count}")
        print("CatBoost handles unseen categorical features gracefully by assigning them to a default category.")

        # Predict on test data (predictions are on the log1p scale)
        test_predictions_log = model.predict(X_test)
        # Inverse transform to original count scale
        test_predictions = np.expm1(test_predictions_log)
        # Ensure predictions are non-negative
        test_predictions[test_predictions < 0] = 0

        submission_df = submission_keys
        submission_df['predicted_count'] = test_predictions.round().astype(int) # Round and convert to int for counts

        # Save submission file
        submission_output_path = 'submission.csv'
        submission_df.to_csv(submission_output_path, index=False)
        print(f"Submission file '{submission_output_path}' generated successfully.")

        # If test file contains 'violation_count', calculate RMSE
        if target in test_df.columns:
            # Ensure true values are numeric, handle NaNs, and clip, then compare with original scale predictions
            y_test_true_original = pd.to_numeric(test_df[target], errors='coerce').fillna(0).clip(lower=0)
            rmse_test = np.sqrt(mean_squared_error(y_test_true_original, test_predictions))
            print(f"RMSE on the provided test/evaluation file: {rmse_test}")
        else:
            print("Test file does not contain 'violation_count'. No RMSE calculated for test set.")

if __name__ == "__main__":
    main()
