
import pandas as pd
import numpy as np
import argparse
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import os
import sys

# Function to load data
def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names for easier access: lowercase, replace spaces with underscores
        df.columns = [col.strip().replace(' ', '_').lower() for col in df.columns]
        
        # Ensure essential columns exist
        required_cols = ['street_name', 'violation_description']
        for col in required_cols:
            if col not in df.columns:
                raise ValueError(f"Required column '{col}' not found in {file_path}")
        
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}. Please check the path.", file=sys.stderr)
        sys.exit(1) # Exit process upon critical error
    except Exception as e:
        print(f"Error loading or processing data from {file_path}: {e}", file=sys.stderr)
        sys.exit(1) # Exit process upon critical error

# Function for feature engineering and preparation
def prepare_data(df, is_training=True):
    """
    Prepares data for CatBoost, identifying categorical features.
    No complex feature engineering beyond direct use of columns.
    """
    # Ensure street_name and violation_description are treated as strings
    df['street_name'] = df['street_name'].astype(str)
    df['violation_description'] = df['violation_description'].astype(str)

    # These columns will be treated as categorical features by CatBoost
    categorical_features_names = ['street_name', 'violation_description']
    features_to_use = ['street_name', 'violation_description']

    if is_training:
        if 'violation_count' not in df.columns:
            raise ValueError("Training data must contain 'violation_count' column.")
        X = df[features_to_use]
        y = df['violation_count']
        return X, y, categorical_features_names
    else:
        X = df[features_to_use]
        return X, categorical_features_names # Return None for y, as it's not applicable for test features

# Main function to run the pipeline
def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 violations training data (default: ./input/violations_per_street_2022.csv).')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional path to the test data for prediction and evaluation (default: None).')
    args = parser.parse_args()

    # --- Training Phase ---
    print(f"Loading training data from {args.train_path}...")
    try:
        train_df = load_data(args.train_path)
    except SystemExit: # Catch the SystemExit from load_data to terminate gracefully
        return

    # Prepare training features and target
    try:
        X_train_full, y_train_full, categorical_features = prepare_data(train_df, is_training=True)
    except ValueError as e:
        print(f"Error preparing training data: {e}", file=sys.stderr)
        sys.exit(1)

    # Split 2022 data into training and validation sets
    # A grouped split might be more robust for time-series-like data if dates were present,
    # but for this schema, a standard train_test_split serves as a basic holdout.
    X_train, X_val, y_train, y_val = train_test_split(
        X_train_full, y_train_full, test_size=0.2, random_state=42
    )

    print(f"Training data shape: {X_train.shape}")
    print(f"Validation data shape: {X_val.shape}")

    # Initialize and train CatBoost Regressor
    # Parameters chosen to balance performance and mitigate OOM risk.
    # `iterations` can be increased for better performance, `early_stopping_rounds` helps prevent overfitting.
    # `cat_features` specifies categorical column names for CatBoost's internal handling.
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=100, # Print progress every 100 iterations
        early_stopping_rounds=50, # Stop if validation RMSE doesn't improve for 50 consecutive rounds
        cat_features=categorical_features, # Specify categorical features by name
        thread_count=-1, # Use all available CPU threads
        # Additional parameters to control memory usage if OOM occurs:
        # max_ctr_complexity=1, # Reduce complexity of categorical feature combinations
        # nan_mode='Forbidden', # Or 'Min'/'Max', depending on how NaNs are handled in preprocessing
        # grow_policy='SymmetricTree' # Default, good for general cases
    )

    print("Starting model training...")
    try:
        model.fit(
            X_train, y_train,
            eval_set=(X_val, y_val),
            early_stopping_rounds=50
        )
    except Exception as e:
        print(f"Error during model training: {e}", file=sys.stderr)
        print("Consider reducing model complexity (e.g., depth, iterations) or adjusting CatBoost parameters to mitigate OOM.", file=sys.stderr)
        sys.exit(1)

    # Evaluate on the validation set
    val_predictions = model.predict(X_val)
    # Clip predictions to be non-negative
    val_predictions[val_predictions < 0] = 0
    final_validation_score = np.sqrt(mean_squared_error(y_val, val_predictions))
    print(f"Development Validation RMSE: {final_validation_score}")
    print(f"Final Validation Performance: {final_validation_score}") # Required output format

    # --- Prediction Phase (if test-path is provided) ---
    if args.test_path:
        print(f"\nLoading test data from {args.test_path}...")
        try:
            test_df_raw = load_data(args.test_path)
        except SystemExit:
            return
        
        # Store original keys for submission file
        test_df_original_keys = test_df_raw[['street_name', 'violation_description']].copy()

        # Prepare test features
        # The categorical features are the same as from training, so no need to explicitly pass them again
        X_test, _ = prepare_data(test_df_raw, is_training=False) 

        print(f"Test data shape: {X_test.shape}")

        # Make predictions
        test_predictions = model.predict(X_test)
        test_predictions[test_predictions < 0] = 0 # Clip predictions to be non-negative

        # Create submission DataFrame
        submission_df = pd.DataFrame({
            'street_name': test_df_original_keys['street_name'],
            'violation_type': test_df_original_keys['violation_description'], # Map to 'violation_type' as required for output
            'predicted_count': test_predictions
        })

        # Save submission file
        output_dir = './'
        os.makedirs(output_dir, exist_ok=True) # Ensure output directory exists
        submission_path = os.path.join(output_dir, 'submission.csv')
        submission_df.to_csv(submission_path, index=False)
        print(f"Predictions saved to {submission_path}")

        # If test data contains actual counts, calculate and report RMSE
        if 'violation_count' in test_df_raw.columns:
            actual_counts = test_df_raw['violation_count'].values
            test_rmse = np.sqrt(mean_squared_error(actual_counts, test_predictions))
            print(f"Test Set RMSE (on provided ground truth): {test_rmse}")

            # Report unseen key pairs
            train_keys = set(X_train_full.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
            test_keys = set(X_test.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
            unseen_keys_in_test = test_keys - train_keys
            print(f"Number of unseen (street_name, violation_type) pairs in test/eval: {len(unseen_keys_in_test)}")
            print("These were handled by CatBoost's internal mechanism for unseen categorical feature values, typically by using a learned default or global mean.")
        else:
            print("Test data does not contain 'violation_count' for RMSE calculation.")

    else:
        print("\nNo test-path provided. Skipping prediction phase.")

if __name__ == "__main__":
    # Ensure necessary packages are installed
    try:
        import pandas
        import numpy
        import sklearn
        import catboost
    except ImportError as e:
        print(f"Missing required package: {e}. Please install with 'pip install pandas numpy scikit-learn catboost'", file=sys.stderr)
        sys.exit(1)
        
    main()
