
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os
import glob # Used for potential future data discovery/loading if augmentation tables are added
import re # Explicitly import re for regex operations

# Ensure required libraries are installed
# You may need to run:
# pip install pandas numpy scikit-learn catboost

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return None
    except pd.errors.EmptyDataError:
        print(f"Warning: File is empty at {file_path}")
        return pd.DataFrame() # Return empty DataFrame to avoid further errors
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return None

# Sophisticated features from 'violation_description'
# This function needs to be defined globally or passed if used inside main
def extract_keywords(description):
    desc = str(description).lower()
    keywords = {
        'desc_has_parking': bool(re.search(r'parking|parked|no parking', desc)),
        'desc_has_stop_sign': bool(re.search(r'stop sign|stop at intersection|disobey stop', desc)),
        'desc_has_speeding': bool(re.search(r'speeding|over speed limit|excessive speed', desc)),
        'desc_has_permit': bool(re.search(r'permit|license|registration|expired|no tag', desc)),
        'desc_has_equipment': bool(re.search(r'equipment|light|signal|tire|window|muffler', desc)),
        'desc_has_safety': bool(re.search(r'safety|seatbelt|child restraint|helmet', desc)),
        'desc_has_commercial': bool(re.search(r'commercial|truck|bus|vehicle for hire', desc)),
        'desc_has_handicap': bool(re.search(r'handicap|disabled parking', desc)),
        'desc_has_lane_violation': bool(re.search(r'lane|turn|changing lanes|improper turn', desc)),
        'desc_has_insurance': bool(re.search(r'insurance', desc))
    }
    return pd.Series(keywords)

def apply_feature_engineering(df, is_training=True, train_data=None):
    """
    Applies feature engineering steps to the DataFrame.
    When is_training is False, it uses frequency mappings from train_data.
    """
    if df is None or df.empty:
        return df

    # Convert categorical features to string type explicitly for CatBoost
    df['street_name'] = df['street_name'].astype(str)
    df['violation_description'] = df['violation_description'].astype(str)
    # Handle potential NaN values in categorical features by filling them with a placeholder
    df['street_name'] = df['street_name'].fillna('UNKNOWN_STREET')
    df['violation_description'] = df['violation_description'].fillna('UNKNOWN_VIOLATION')

    # Enhanced Feature Engineering - Description features
    df['violation_description_length'] = df['violation_description'].apply(lambda x: len(str(x)))
    df['violation_description_word_count'] = df['violation_description'].apply(lambda x: len(str(x).split()))

    # Keyword features from 'violation_description'
    keyword_features = df['violation_description'].apply(extract_keywords)
    df = pd.concat([df, keyword_features], axis=1)

    # Frequency Encoding for high-cardinality categorical features
    if is_training:
        street_name_counts = df['street_name'].astype(str).value_counts()
        violation_desc_counts = df['violation_description'].astype(str).value_counts()
        df['street_name_frequency'] = df['street_name'].astype(str).map(street_name_counts).fillna(0).astype(int)
        df['violation_description_frequency'] = df['violation_description'].astype(str).map(violation_desc_counts).fillna(0).astype(int)
        # Store these mappings for test data
        freq_maps = {'street_name_counts': street_name_counts, 'violation_desc_counts': violation_desc_counts}
    else:
        # Use frequency mappings from training data for consistency
        if train_data is None:
            raise ValueError("train_data must be provided for test feature engineering.")
        df['street_name_frequency'] = df['street_name'].astype(str).map(train_data['street_name_counts']).fillna(0).astype(int)
        df['violation_description_frequency'] = df['violation_description'].astype(str).map(train_data['violation_desc_counts']).fillna(0).astype(int)
        freq_maps = None # Not needed for return in test case

    # Interaction features
    df['street_name_desc_len_interaction'] = \
        df['street_name'].astype(str) + '_' + df['violation_description_length'].astype(str)
    df['street_name_desc_len_interaction'] = df['street_name_desc_len_interaction'].astype(str)

    df['street_freq_desc_len_interaction'] = \
        df['street_name_frequency'].astype(str) + '_' + df['violation_description_length'].astype(str)
    df['street_freq_desc_len_interaction'] = df['street_freq_desc_len_interaction'].astype(str)

    df['desc_freq_word_count_interaction'] = \
        df['violation_description_frequency'].astype(str) + '_' + df['violation_description_word_count'].astype(str)
    df['desc_freq_word_count_interaction'] = df['desc_freq_word_count_interaction'].astype(str)

    df['parking_desc_len_interaction'] = \
        df['desc_has_parking'].astype(str) + '_' + df['violation_description_length'].astype(str)
    df['parking_desc_len_interaction'] = df['parking_desc_len_interaction'].astype(str)

    df['street_freq_speeding_interaction'] = \
        df['street_name_frequency'].astype(str) + '_' + df['desc_has_speeding'].astype(str)
    df['street_freq_speeding_interaction'] = df['street_freq_speeding_interaction'].astype(str)

    return df, freq_maps


def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV relative to INPUT_DIR.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional path to the test/evaluation data CSV relative to INPUT_DIR for prediction.')
    args = parser.parse_args()

    INPUT_DIR = './input' # All input data is stored in this directory
    TRAIN_FILE = args.train_path
    TEST_FILE = args.test_path

    # --- 1. Load Training Data ---
    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)
    print(f"Loading training data from: {train_df_path}")
    train_df = load_data(train_df_path)

    if train_df is None or train_df.empty:
        print("Training data could not be loaded or is empty. Exiting.")
        return

    print(f"Original training data shape: {train_df.shape}")
    print("Training data columns:", train_df.columns.tolist())

    # Ensure required columns are present in the training data
    required_train_cols = ['street_name', 'violation_description', 'violation_count']
    if not all(col in train_df.columns for col in required_train_cols):
        print(f"Error: Training data missing one or more required columns: {required_train_cols}")
        print("Available columns:", train_df.columns.tolist())
        return

    # Ensure target variable is numeric and handle potential NaNs (e.g., fill with 0 or mean)
    train_df['violation_count'] = pd.to_numeric(train_df['violation_count'], errors='coerce')
    train_df['violation_count'] = train_df['violation_count'].fillna(0) # Fill NaNs in target with 0
    # Ensure violation counts are non-negative
    train_df['violation_count'] = train_df['violation_count'].clip(lower=0)

    # --- 2. Feature Engineering and Augmentation ---
    train_df, freq_maps = apply_feature_engineering(train_df, is_training=True)

    # --- 3. Prepare Data for Model ---
    features = [
        'street_name',
        'violation_description',
        'violation_description_length',
        'violation_description_word_count',
        'desc_has_parking',
        'desc_has_stop_sign',
        'desc_has_speeding',
        'desc_has_permit',
        'desc_has_equipment',
        'desc_has_safety',
        'desc_has_commercial',
        'desc_has_handicap',
        'desc_has_lane_violation',
        'desc_has_insurance',
        'street_name_frequency',
        'violation_description_frequency',
        'street_name_desc_len_interaction',
        'street_freq_desc_len_interaction',
        'desc_freq_word_count_interaction',
        'parking_desc_len_interaction',
        'street_freq_speeding_interaction'
    ]
    target = 'violation_count'

    # Filter `features` to only include columns that actually exist in the DataFrame after feature engineering
    # This prevents errors if some feature columns were not created due to empty data or other issues.
    features = [f for f in features if f in train_df.columns]

    X = train_df[features]
    # Apply log1p transformation to the target variable for training
    # This helps stabilize variance and handle skewed count data.
    y = np.log1p(train_df[target])

    # Identify categorical features by their column names
    # CatBoost can handle string categorical features directly without one-hot encoding
    categorical_features_indices = [i for i, col in enumerate(features) if X[col].dtype == 'object' or X[col].dtype == 'bool']

    # --- 4. Split Training Data for Validation ---
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    # Create CatBoost Pool objects
    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices)

    # --- 5. Model Training ---
    model = CatBoostRegressor(
        iterations=1000, # Increased iterations for potentially better performance
        learning_rate=0.03, # Slightly reduced learning rate
        depth=9, # Slightly increased depth to capture more complex patterns
        l2_leaf_reg=3, # Introduced L2 regularization to prevent overfitting
        eval_metric='RMSE', # CatBoost will optimize RMSE on the log-transformed target
        random_seed=42,
        verbose=0, # Suppress verbose output during training iterations
        early_stopping_rounds=100, # Use early stopping to prevent overfitting
        thread_count=-1, # Use all available threads
        # bootstrap_type='Bernoulli', # Uncomment and adjust subsample if OOM occurs on large datasets
        # subsample=0.8
    )

    print("Training CatBoost model...")
    model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=100, verbose=False) # verbose=False for non-interactive output

    # --- 6. Validation ---
    # Predictions from the model are on the log1p scale
    val_predictions_log = model.predict(X_val)
    # Inverse transform predictions from log1p scale to original count scale
    val_predictions = np.expm1(val_predictions_log)
    # Ensure predictions are non-negative after inverse transformation
    val_predictions[val_predictions < 0] = 0

    # For RMSE calculation, y_val (true values) must also be inverse-transformed to the original scale
    rmse_val = np.sqrt(mean_squared_error(np.expm1(y_val), val_predictions))
    print(f"Final Validation Performance: {rmse_val}")

    # --- 7. Prediction for Test/Evaluation File ---
    if TEST_FILE:
        test_df_path = os.path.join(INPUT_DIR, TEST_FILE)
        print(f"\nLoading test data from: {test_df_path}")
        test_df = load_data(test_df_path)

        if test_df is None or test_df.empty:
            print("Test data could not be loaded or is empty. Skipping prediction.")
            return

        print(f"Original test data shape: {test_df.shape}")
        print("Test data columns:", test_df.columns.tolist())

        # Ensure required columns are present in test set (excluding target if not there)
        required_test_cols = ['street_name', 'violation_description']
        if not all(col in test_df.columns for col in required_test_cols):
            print(f"Error: Test data missing one or more required columns: {required_test_cols}")
            print("Available columns:", test_df.columns.tolist())
            return

        # Store original key columns for submission
        submission_keys = test_df[['street_name', 'violation_description']].copy()

        # Apply same feature engineering and type conversion as training data
        test_df, _ = apply_feature_engineering(test_df, is_training=False, train_data=freq_maps)

        # Filter `features` to only include columns that actually exist in the test DataFrame
        # This is crucial for handling cases where `test_df` might be missing some features
        # if the `apply_feature_engineering` function encounters issues.
        X_test_features = [f for f in features if f in test_df.columns]

        # Handle cases where X_test might have missing feature columns compared to X_train
        # For columns in `features` that are missing in `test_df`, add them with appropriate default values.
        # This is important for CatBoost, which expects the same feature set.
        for col in features:
            if col not in test_df.columns:
                print(f"Warning: Feature '{col}' missing in test data. Adding with default value (0 or 'UNKNOWN').")
                if X[col].dtype == 'object' or X[col].dtype == 'bool':
                    test_df[col] = 'UNKNOWN'
                else:
                    test_df[col] = 0

        X_test = test_df[features] # Use the full features list to ensure consistency

        # Handle and report unseen keys in test set
        # Get unique features from training data (before log1p transformation for target)
        train_street_names = set(train_df['street_name'].unique())
        train_violation_descriptions = set(train_df['violation_description'].unique())

        unseen_streets_count = X_test[~X_test['street_name'].isin(train_street_names)].shape[0]
        unseen_violations_count = X_test[~X_test['violation_description'].isin(train_violation_descriptions)].shape[0]

        print(f"Number of test rows with unseen street names: {unseen_streets_count}")
        print(f"Number of test rows with unseen violation descriptions: {unseen_violations_count}")
        print("CatBoost handles unseen categorical features gracefully by assigning them to a default category.")

        # Predict on test data (predictions are on the log1p scale)
        test_predictions_log = model.predict(X_test)
        # Inverse transform to original count scale
        test_predictions = np.expm1(test_predictions_log)
        # Ensure predictions are non-negative
        test_predictions[test_predictions < 0] = 0

        submission_df = submission_keys
        # Round and convert to int for counts. Clip to 0 to ensure non-negative integers.
        submission_df['predicted_count'] = test_predictions.round().astype(int).clip(lower=0)

        # Save submission file
        submission_output_path = 'submission.csv'
        submission_df.to_csv(submission_output_path, index=False)
        print(f"Submission file '{submission_output_path}' generated successfully.")

        # If test file contains 'violation_count', calculate RMSE
        if target in test_df.columns:
            # Ensure true values are numeric, handle NaNs, and clip, then compare with original scale predictions
            y_test_true_original = pd.to_numeric(test_df[target], errors='coerce').fillna(0).clip(lower=0)
            rmse_test = np.sqrt(mean_squared_error(y_test_true_original, test_predictions))
            print(f"RMSE on the provided test/evaluation file: {rmse_test}")
        else:
            print("Test file does not contain 'violation_count'. No RMSE calculated for test set.")

if __name__ == "__main__":
    main()
