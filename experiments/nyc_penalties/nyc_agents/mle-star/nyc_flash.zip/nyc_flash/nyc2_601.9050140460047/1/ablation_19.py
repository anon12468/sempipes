
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os
import glob # Used for potential future data discovery/loading if augmentation tables are added

# Ensure required libraries are installed
# You may need to run:
# pip install pandas numpy scikit-learn catboost

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return None
    except pd.errors.EmptyDataError:
        print(f"Warning: File is empty at {file_path}")
        return pd.DataFrame() # Return empty DataFrame to avoid further errors
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return None

def run_model(train_df, features, target, model_params, ablation_name):
    """
    Runs the CatBoost model with specified features and parameters,
    and returns the validation RMSE.
    """
    print(f"\n--- Running Ablation: {ablation_name} ---")

    X = train_df[features]
    # Apply log1p transformation to the target variable for training
    y = np.log1p(train_df[target])

    # Identify categorical features by their column names for CatBoost
    # Only features present in X are considered
    categorical_features_names = [col for col in features if X[col].dtype == 'object']
    categorical_features_indices = [features.index(col) for col in categorical_features_names]

    # Split data for training and validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    # Create CatBoost Pool objects
    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices)

    # Initialize and train CatBoost model
    model = CatBoostRegressor(**model_params)

    print(f"Training CatBoost model for {ablation_name}...")
    # Use early stopping rounds. verbose=False to suppress iteration output
    model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=model_params.get('early_stopping_rounds', 100), verbose=False)

    # Make predictions on the validation set
    val_predictions_log = model.predict(X_val)
    # Inverse transform predictions from log1p scale to original count scale
    val_predictions = np.expm1(val_predictions_log)
    # Ensure predictions are non-negative
    val_predictions[val_predictions < 0] = 0

    # Calculate RMSE on the original scale
    rmse_val = np.sqrt(mean_squared_error(np.expm1(y_val), val_predictions))
    print(f"Validation RMSE for {ablation_name}: {rmse_val}")
    return rmse_val


def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV relative to INPUT_DIR.')
    # Removed --test-path as per instruction to not load test data for ablation
    args = parser.parse_args()

    INPUT_DIR = './input' # All input data is stored in this directory
    TRAIN_FILE = args.train_path

    # --- 1. Load Training Data ---
    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)
    print(f"Loading training data from: {train_df_path}")
    train_df = load_data(train_df_path)

    if train_df is None or train_df.empty:
        print("Training data could not be loaded or is empty. Exiting.")
        return

    print(f"Original training data shape: {train_df.shape}")
    print("Training data columns:", train_df.columns.tolist())

    # Ensure required columns are present in the training data
    required_train_cols = ['street_name', 'violation_description', 'violation_count']
    if not all(col in train_df.columns for col in required_train_cols):
        print(f"Error: Training data missing one or more required columns: {required_train_cols}")
        print("Available columns:", train_df.columns.tolist())
        return

    # --- 2. Feature Engineering and Augmentation (from current solution + plan_implement_agent_1) ---
    # Convert categorical features to string type explicitly for CatBoost
    train_df['street_name'] = train_df['street_name'].astype(str)
    train_df['violation_description'] = train_df['violation_description'].astype(str)
    # Handle potential NaN values in categorical features by filling them with a placeholder
    train_df['street_name'] = train_df['street_name'].fillna('UNKNOWN_STREET')
    train_df['violation_description'] = train_df['violation_description'].fillna('UNKNOWN_VIOLATION')

    # Ensure target variable is numeric and handle potential NaNs (e.g., fill with 0 or mean)
    train_df['violation_count'] = pd.to_numeric(train_df['violation_count'], errors='coerce')
    train_df['violation_count'] = train_df['violation_count'].fillna(0) # Fill NaNs in target with 0
    # Ensure violation counts are non-negative
    train_df['violation_count'] = train_df['violation_count'].clip(lower=0)


    # Enhanced Feature Engineering (based on plan_implement_agent_1)
    # Extract numerical information from 'violation_description'
    train_df['violation_description_length'] = train_df['violation_description'].apply(len)
    train_df['violation_description_word_count'] = train_df['violation_description'].apply(lambda x: len(str(x).split()))

    # New: Introduce additional insightful numerical features derived from the text descriptions (boolean flags)
    # Convert to lowercase for case-insensitive matching
    train_df['violation_description_lower'] = train_df['violation_description'].str.lower()
    train_df['is_parking_violation'] = train_df['violation_description_lower'].str.contains('parking', na=False, regex=False).astype(int)
    train_df['is_permit_violation'] = train_df['violation_description_lower'].str.contains('permit', na=False, regex=False).astype(int)
    train_df['is_expired_violation'] = train_df['violation_description_lower'].str.contains('expired', na=False, regex=False).astype(int)
    # Drop the temporary lowercased column as it's no longer needed for direct feature use
    train_df = train_df.drop(columns=['violation_description_lower'])

    # New: Add frequency encoding for 'street_name'
    street_name_counts = train_df['street_name'].value_counts(normalize=True)
    train_df['street_name_freq_encoded'] = train_df['street_name'].map(street_name_counts)

    # Explore simple interaction features
    # Create an interaction feature between 'street_name' and 'violation_description_length'
    train_df['street_name_desc_len_interaction'] = \
        train_df['street_name'].astype(str) + '_' + train_df['violation_description_length'].astype(str)
    # Ensure the new interaction feature is also treated as a string/categorical
    train_df['street_name_desc_len_interaction'] = train_df['street_name_desc_len_interaction'].astype(str)

    target_col = 'violation_count'

    # --- Define Baseline Configuration (including new features from plan_implement_agent_1) ---
    base_features = [
        'street_name',
        'violation_description',
        'violation_description_length',
        'violation_description_word_count',
        'street_name_desc_len_interaction',
        'is_parking_violation',
        'is_permit_violation',
        'is_expired_violation',
        'street_name_freq_encoded'
    ]

    base_model_params = {
        'iterations': 1000, # Increased iterations for potentially better performance
        'learning_rate': 0.03, # Slightly reduced learning rate
        'depth': 9, # Slightly increased depth to capture more complex patterns
        'l2_leaf_reg': 3, # Introduced L2 regularization to prevent overfitting
        'eval_metric': 'RMSE', # CatBoost will optimize RMSE on the log-transformed target
        'random_seed': 42,
        'verbose': 0, # Suppress verbose output during training iterations
        'early_stopping_rounds': 100, # Use early stopping to prevent overfitting
        'thread_count': -1, # Use all available threads
    }

    results = {}

    # --- Run Baseline ---
    baseline_rmse = run_model(train_df, base_features, target_col, base_model_params, "Baseline")
    results["Baseline"] = baseline_rmse

    # --- Ablation 1: Remove 'violation_description_word_count' feature ---
    # Several previous studies indicated this feature was detrimental.
    ablation1_features = [f for f in base_features if f != 'violation_description_word_count']
    ablation1_rmse = run_model(train_df, ablation1_features, target_col, base_model_params,
                               "Ablation 1: No violation_description_word_count feature")
    results["Ablation 1"] = ablation1_rmse

    # --- Ablation 2: Remove new boolean features ('is_parking_violation', 'is_permit_violation', 'is_expired_violation') ---
    # These are new features from the latest update, their impact as a group hasn't been explicitly studied.
    boolean_features = ['is_parking_violation', 'is_permit_violation', 'is_expired_violation']
    ablation2_features = [f for f in base_features if f not in boolean_features]
    ablation2_rmse = run_model(train_df, ablation2_features, target_col, base_model_params,
                               "Ablation 2: No new boolean text features")
    results["Ablation 2"] = ablation2_rmse

    # --- Ablation 3: Change CatBoost 'l2_leaf_reg' from 3 to 0 ---
    # Previous studies showed conflicting results for this parameter (3 vs 0), making it a good candidate to re-evaluate.
    ablation3_model_params = base_model_params.copy()
    ablation3_model_params['l2_leaf_reg'] = 0
    ablation3_rmse = run_model(train_df, base_features, target_col, ablation3_model_params,
                               "Ablation 3: CatBoost l2_leaf_reg = 0")
    results["Ablation 3"] = ablation3_rmse

    # --- Print Summary of Results and Conclusion ---
    print("\n--- Ablation Study Summary ---")
    for name, rmse in results.items():
        print(f"{name}: {rmse:.4f}")

    print("\n--- Conclusion ---")
    baseline_rmse = results["Baseline"]
    
    # Initialize with baseline as the "best" so far if no improvement is found
    best_rmse_overall = baseline_rmse
    best_ablation_description = "the Baseline configuration"

    # Find the best performing ablation (lowest RMSE)
    for name, rmse in results.items():
        if rmse < best_rmse_overall:
            best_rmse_overall = rmse
            best_ablation_description = name # This will be refined for readability

    if best_rmse_overall == baseline_rmse:
        print(f"The {best_ablation_description} achieved the lowest RMSE of {baseline_rmse:.4f}. No ablation significantly improved performance.")
    else:
        # Determine how the best ablation improved performance
        improvement_value = baseline_rmse - best_rmse_overall
        
        # Extract meaningful part of the ablation name for the conclusion
        display_name = best_ablation_description.split(': ', 1)[1] if ': ' in best_ablation_description else best_ablation_description
        
        print(f"The most significant improvement in performance (RMSE reduced by {improvement_value:.4f}, to {best_rmse_overall:.4f}) was achieved by '{display_name}'.")

if __name__ == "__main__":
    main()

