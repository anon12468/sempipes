

import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return None
    except pd.errors.EmptyDataError:
        print(f"Warning: File is empty at {file_path}")
        return pd.DataFrame() # Return empty DataFrame to avoid further errors
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return None

def run_ablation_scenario(
    train_df_path,
    catboost_params_override=None,
    remove_interaction_feature=False
):
    """
    Runs the model training and validation with specified ablation parameters.
    Returns the validation RMSE.
    """
    train_df = load_data(train_df_path)

    if train_df is None or train_df.empty:
        print("Training data could not be loaded or is empty. Exiting ablation scenario.")
        return None

    # Ensure required columns are present in the training data
    required_train_cols = ['street_name', 'violation_description', 'violation_count']
    if not all(col in train_df.columns for col in required_train_cols):
        print(f"Error: Training data missing one or more required columns: {required_train_cols}")
        return None

    # --- Feature Engineering ---
    train_df['street_name'] = train_df['street_name'].astype(str)
    train_df['violation_description'] = train_df['violation_description'].astype(str)
    train_df['street_name'] = train_df['street_name'].fillna('UNKNOWN_STREET')
    train_df['violation_description'] = train_df['violation_description'].fillna('UNKNOWN_VIOLATION')

    train_df['violation_count'] = pd.to_numeric(train_df['violation_count'], errors='coerce')
    train_df['violation_count'] = train_df['violation_count'].fillna(0)
    train_df['violation_count'] = train_df['violation_count'].clip(lower=0)

    train_df['violation_description_length'] = train_df['violation_description'].apply(len)
    train_df['violation_description_word_count'] = train_df['violation_description'].apply(lambda x: len(str(x).split()))

    if not remove_interaction_feature:
        train_df['street_name_desc_len_interaction'] = \
            train_df['street_name'].astype(str) + '_' + train_df['violation_description_length'].astype(str)
        train_df['street_name_desc_len_interaction'] = train_df['street_name_desc_len_interaction'].astype(str)

    # --- Prepare Data for Model ---
    features = [
        'street_name',
        'violation_description',
        'violation_description_length',
        'violation_description_word_count',
    ]
    if not remove_interaction_feature:
        features.append('street_name_desc_len_interaction')

    target = 'violation_count'

    X = train_df[features]
    y = np.log1p(train_df[target])

    # Identify categorical features
    categorical_features_names = [col for col in features if X[col].dtype == 'object']
    categorical_features_indices = [X.columns.get_loc(col) for col in categorical_features_names]

    # --- Split Training Data for Validation ---
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices)

    # --- Model Training ---
    model_params = {
        'iterations': 1000,
        'learning_rate': 0.03,
        'depth': 9,
        'l2_leaf_reg': 3,
        'eval_metric': 'RMSE',
        'random_seed': 42,
        'verbose': 0,
        'early_stopping_rounds': 100,
        'thread_count': -1,
    }
    if catboost_params_override:
        model_params.update(catboost_params_override)

    model = CatBoostRegressor(**model_params)

    model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=100, verbose=False)

    # --- Validation ---
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log)
    val_predictions[val_predictions < 0] = 0

    rmse_val = np.sqrt(mean_squared_error(np.expm1(y_val), val_predictions))
    return rmse_val

def main():
    parser = argparse.ArgumentParser(description="Ablation study for NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV relative to INPUT_DIR.')
    args = parser.parse_args()

    INPUT_DIR = './input'
    TRAIN_FILE = args.train_path
    train_df_full_path = os.path.join(INPUT_DIR, TRAIN_FILE)

    results = {}

    # --- Baseline Performance ---
    print("Running Baseline Scenario (current solution configuration)...")
    baseline_rmse = run_ablation_scenario(train_df_full_path)
    if baseline_rmse is not None:
        results['Baseline'] = baseline_rmse
        print(f"Baseline Validation RMSE: {baseline_rmse:.4f}\n")

    # --- Ablation 1: Change CatBoost grow_policy to Lossguide ---
    print("Running Ablation 1: Changing CatBoost grow_policy from default (SymmetricTree) to 'Lossguide'...")
    ablation1_params = {'grow_policy': 'Lossguide'}
    ablation1_rmse = run_ablation_scenario(train_df_full_path, catboost_params_override=ablation1_params)
    if ablation1_rmse is not None:
        results['Ablation 1 (grow_policy=Lossguide)'] = ablation1_rmse
        print(f"Ablation 1 Validation RMSE (grow_policy='Lossguide'): {ablation1_rmse:.4f}")
        print(f"Impact vs Baseline: {ablation1_rmse - baseline_rmse:.4f}\n")

    # --- Ablation 2: Change CatBoost min_data_in_leaf from default (1) to 10 ---
    print("Running Ablation 2: Changing CatBoost min_data_in_leaf from default (1) to 10...")
    ablation2_params = {'min_data_in_leaf': 10}
    ablation2_rmse = run_ablation_scenario(train_df_full_path, catboost_params_override=ablation2_params)
    if ablation2_rmse is not None:
        results['Ablation 2 (min_data_in_leaf=10)'] = ablation2_rmse
        print(f"Ablation 2 Validation RMSE (min_data_in_leaf=10): {ablation2_rmse:.4f}")
        print(f"Impact vs Baseline: {ablation2_rmse - baseline_rmse:.4f}\n")

    # --- Ablation 3: Remove 'street_name_desc_len_interaction' feature ---
    print("Running Ablation 3: Removing 'street_name_desc_len_interaction' feature...")
    ablation3_rmse = run_ablation_scenario(train_df_full_path, remove_interaction_feature=True)
    if ablation3_rmse is not None:
        results['Ablation 3 (No interaction feature)'] = ablation3_rmse
        print(f"Ablation 3 Validation RMSE (No interaction feature): {ablation3_rmse:.4f}")
        print(f"Impact vs Baseline: {ablation3_rmse - baseline_rmse:.4f}\n")

    # --- Conclusion ---
    if results:
        print("--- Ablation Study Conclusion ---")
        sorted_results = sorted(results.items(), key=lambda item: item[1])
        
        best_scenario_name, best_scenario_rmse = sorted_results[0]
        
        if best_scenario_name == 'Baseline' or best_scenario_rmse >= baseline_rmse:
            print(f"The baseline configuration (RMSE: {baseline_rmse:.4f}) contributed most positively to the overall performance among the scenarios tested, as no ablation significantly improved the RMSE.")
        else:
            impact_vs_baseline_positive = baseline_rmse - best_scenario_rmse
            print(f"The part of the code that contributed most positively to the overall performance is achieved by '{best_scenario_name}' (RMSE improved by {impact_vs_baseline_positive:.4f}).")

        worst_scenario_name, worst_scenario_rmse = sorted_results[-1]
        if worst_scenario_name != 'Baseline' and worst_scenario_rmse > baseline_rmse:
            detrimental_impact = worst_scenario_rmse - baseline_rmse
            print(f"The part of the code that contributed most negatively to the overall performance (i.e., its absence or modification degraded performance the most) was related to '{worst_scenario_name}' (RMSE degraded by {detrimental_impact:.4f}).")


if __name__ == "__main__":
    main()
