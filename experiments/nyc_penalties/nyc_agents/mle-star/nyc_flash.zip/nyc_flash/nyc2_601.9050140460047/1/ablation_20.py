
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os

# Ensure required libraries are installed
# You may need to run:
# pip install pandas numpy scikit-learn catboost

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return pd.DataFrame()
    except pd.errors.EmptyDataError:
        print(f"Warning: File is empty at {file_path}")
        return pd.DataFrame()
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return pd.DataFrame()

def run_experiment(
    train_df_original, # Use a copy inside to prevent side effects
    use_grow_policy_lossguide: bool = True,
    use_violation_description_word_count: bool = True,
    use_street_name_desc_len_interaction: bool = True,
    experiment_name: str = "Baseline"
):
    """
    Runs a single CatBoost experiment with specified configurations.
    """
    print(f"\n--- Running Experiment: {experiment_name} ---")

    current_train_df = train_df_original.copy()

    # --- Feature Engineering and Augmentation ---
    current_train_df['street_name'] = current_train_df['street_name'].astype(str)
    current_train_df['violation_description'] = current_train_df['violation_description'].astype(str)
    current_train_df['street_name'] = current_train_df['street_name'].fillna('UNKNOWN_STREET')
    current_train_df['violation_description'] = current_train_df['violation_description'].fillna('UNKNOWN_VIOLATION')

    current_train_df['violation_description_length'] = current_train_df['violation_description'].apply(len)

    # Conditionally create/remove features
    if use_violation_description_word_count:
        current_train_df['violation_description_word_count'] = current_train_df['violation_description'].apply(lambda x: len(str(x).split()))
    else:
        # Ensure the column doesn't exist if not used
        if 'violation_description_word_count' in current_train_df.columns:
            current_train_df = current_train_df.drop(columns=['violation_description_word_count'])

    if use_street_name_desc_len_interaction:
        current_train_df['street_name_desc_len_interaction'] = \
            current_train_df['street_name'].astype(str) + '_' + current_train_df['violation_description_length'].astype(str)
        current_train_df['street_name_desc_len_interaction'] = current_train_df['street_name_desc_len_interaction'].astype(str)
    else:
        # Ensure the column doesn't exist if not used
        if 'street_name_desc_len_interaction' in current_train_df.columns:
            current_train_df = current_train_df.drop(columns=['street_name_desc_len_interaction'])

    # --- Prepare Data for Model ---
    features = [
        'street_name',
        'violation_description',
        'violation_description_length',
    ]

    if use_violation_description_word_count:
        features.append('violation_description_word_count')
    if use_street_name_desc_len_interaction:
        features.append('street_name_desc_len_interaction')

    target = 'violation_count'

    # Filter `features` list to only include columns actually present in `current_train_df`
    features_present = [f for f in features if f in current_train_df.columns]
    X = current_train_df[features_present]

    # Ensure target variable is numeric and handle potential NaNs (e.g., fill with 0 or mean)
    current_train_df['violation_count'] = pd.to_numeric(current_train_df['violation_count'], errors='coerce')
    current_train_df['violation_count'] = current_train_df['violation_count'].fillna(0) # Fill NaNs in target with 0
    current_train_df['violation_count'] = current_train_df['violation_count'].clip(lower=0)

    y = np.log1p(current_train_df[target])

    # Identify categorical features by their column names
    categorical_feature_names = [col for col in X.columns if X[col].dtype == 'object']
    categorical_features_indices = [X.columns.get_loc(col) for col in categorical_feature_names]

    # --- Split Training Data for Validation ---
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    # Create CatBoost Pool objects
    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices)

    # --- Model Training ---
    model_params = {
        'iterations': 1000,
        'learning_rate': 0.03,
        'depth': 9,
        'l2_leaf_reg': 3,
        'eval_metric': 'RMSE',
        'random_seed': 42,
        'verbose': 0,
        'early_stopping_rounds': 100,
        'thread_count': -1,
    }

    if use_grow_policy_lossguide:
        model_params['grow_policy'] = 'Lossguide'
    else:
        model_params['grow_policy'] = 'SymmetricTree' # CatBoost default

    model = CatBoostRegressor(**model_params)

    model.fit(train_pool, eval_set=val_pool, verbose=False)

    # --- Validation ---
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log)
    val_predictions[val_predictions < 0] = 0

    rmse_val = np.sqrt(mean_squared_error(np.expm1(y_val), val_predictions))
    print(f"{experiment_name} Validation RMSE: {rmse_val:.4f}")
    return rmse_val

def main_ablation_study():
    INPUT_DIR = './input'
    TRAIN_FILE = 'violations_per_street_2022.csv'

    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)
    print(f"Loading training data from: {train_df_path}")
    train_df = load_data(train_df_path)

    if train_df.empty:
        print("Training data could not be loaded or is empty. Exiting.")
        return

    print(f"Original training data shape: {train_df.shape}")
    print("Training data columns:", train_df.columns.tolist())

    required_train_cols = ['street_name', 'violation_description', 'violation_count']
    if not all(col in train_df.columns for col in required_train_cols):
        print(f"Error: Training data missing one or more required columns: {required_train_cols}")
        print("Available columns:", train_df.columns.tolist())
        return

    results = {}

    # --- Baseline Experiment ---
    baseline_rmse = run_experiment(
        train_df,
        use_grow_policy_lossguide=True,
        use_violation_description_word_count=True,
        use_street_name_desc_len_interaction=True,
        experiment_name="Baseline (All current components)"
    )
    results["Baseline"] = baseline_rmse

    # --- Ablation 1: Disable grow_policy='Lossguide' (revert to default SymmetricTree) ---
    ablation1_rmse = run_experiment(
        train_df,
        use_grow_policy_lossguide=False,
        use_violation_description_word_count=True,
        use_street_name_desc_len_interaction=True,
        experiment_name="Ablation 1: No grow_policy='Lossguide'"
    )
    results["No grow_policy='Lossguide'"] = ablation1_rmse

    # --- Ablation 2: Remove 'violation_description_word_count' feature ---
    ablation2_rmse = run_experiment(
        train_df,
        use_grow_policy_lossguide=True,
        use_violation_description_word_count=False,
        use_street_name_desc_len_interaction=True,
        experiment_name="Ablation 2: No 'violation_description_word_count' feature"
    )
    results["No 'violation_description_word_count' feature"] = ablation2_rmse

    # --- Ablation 3: Remove 'street_name_desc_len_interaction' feature ---
    ablation3_rmse = run_experiment(
        train_df,
        use_grow_policy_lossguide=True,
        use_violation_description_word_count=True,
        use_street_name_desc_len_interaction=False,
        experiment_name="Ablation 3: No 'street_name_desc_len_interaction' feature"
    )
    results["No 'street_name_desc_len_interaction' feature"] = ablation3_rmse


    print("\n--- Ablation Study Summary ---")
    for name, rmse in results.items():
        print(f"{name}: {rmse:.4f}")

    contributions = {}
    if "Baseline" in results:
        baseline = results["Baseline"]
        
        # Calculate impact of *removing* each component
        # A positive 'impact' value means removing it increased RMSE (component was beneficial)
        # A negative 'impact' value means removing it decreased RMSE (component was detrimental)
        
        if "No grow_policy='Lossguide'" in results:
            impact_grow_policy = results["No grow_policy='Lossguide'"] - baseline
            contributions["grow_policy='Lossguide'"] = impact_grow_policy
            
        if "No 'violation_description_word_count' feature" in results:
            impact_word_count = results["No 'violation_description_word_count' feature"] - baseline
            contributions["'violation_description_word_count' feature"] = impact_word_count
            
        if "No 'street_name_desc_len_interaction' feature" in results:
            impact_interaction = results["No 'street_name_desc_len_interaction' feature"] - baseline
            contributions["'street_name_desc_len_interaction' feature"] = impact_interaction

    if not contributions:
        print("Not enough data to determine contributions.")
        return

    print("\n--- Contribution Analysis ---")
    print(f"Baseline RMSE: {baseline:.4f}")

    for component, impact in contributions.items():
        if impact > 0:
            print(f"Removing '{component}' caused RMSE to increase by {impact:.4f}. This component is beneficial.")
        elif impact < 0:
            print(f"Removing '{component}' caused RMSE to decrease by {abs(impact):.4f}. This component is detrimental.")
        else:
            print(f"Removing '{component}' had no measurable impact on RMSE.")

    print("\n--- Conclusion ---")
    
    # Identify the most beneficial component (largest positive impact from its removal)
    most_beneficial = max(contributions.items(), key=lambda item: item[1])
    if most_beneficial[1] > 0.0001: # Check for a measurable positive impact
        print(f"The part of the code that contributes MOST positively to the overall performance is: '{most_beneficial[0]}'. "
              f"Its removal degraded performance (increased RMSE) by {most_beneficial[1]:.4f}.")
    else:
        print(f"Among the components ablated, none showed a significant positive contribution (removal led to RMSE increase).")

    # Identify the most detrimental component (largest negative impact from its removal)
    most_detrimental = min(contributions.items(), key=lambda item: item[1])
    if most_detrimental[1] < -0.0001: # Check for a measurable negative impact
        print(f"The part of the code that contributes MOST negatively to the overall performance "
              f"(i.e., its removal improved RMSE the most) is: '{most_detrimental[0]}'. "
              f"Its removal improved performance (decreased RMSE) by {abs(most_detrimental[1]):.4f}.")
    else:
        print(f"Among the components ablated, none showed a significant negative contribution (removal led to RMSE decrease).")

if __name__ == "__main__":
    main_ablation_study()
