

import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os
import glob

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return None
    except pd.errors.EmptyDataError:
        print(f"Warning: File is empty at {file_path}")
        return pd.DataFrame()
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return None

def run_experiment(
    train_df_path,
    use_text_features=False,
    include_interaction_feature=True,
    enable_bernoulli_bootstrap=False
):
    # --- 1. Load Training Data ---
    train_df = load_data(train_df_path)

    if train_df is None or train_df.empty:
        print("Training data could not be loaded or is empty. Exiting.")
        return None

    # Ensure required columns are present in the training data
    required_train_cols = ['street_name', 'violation_description', 'violation_count']
    if not all(col in train_df.columns for col in required_train_cols):
        print(f"Error: Training data missing one or more required columns: {required_train_cols}")
        return None

    # --- 2. Feature Engineering and Augmentation ---
    train_df['street_name'] = train_df['street_name'].astype(str)
    train_df['violation_description'] = train_df['violation_description'].astype(str)
    train_df['street_name'] = train_df['street_name'].fillna('UNKNOWN_STREET')
    train_df['violation_description'] = train_df['violation_description'].fillna('UNKNOWN_VIOLATION')

    train_df['violation_count'] = pd.to_numeric(train_df['violation_count'], errors='coerce')
    train_df['violation_count'] = train_df['violation_count'].fillna(0)
    train_df['violation_count'] = train_df['violation_count'].clip(lower=0)

    # Enhanced Feature Engineering
    train_df['violation_description_length'] = train_df['violation_description'].apply(len)
    train_df['violation_description_word_count'] = train_df['violation_description'].apply(lambda x: len(str(x).split()))

    if include_interaction_feature:
        train_df['street_name_desc_len_interaction'] = \
            train_df['street_name'].astype(str) + '_' + train_df['violation_description_length'].astype(str)
        train_df['street_name_desc_len_interaction'] = train_df['street_name_desc_len_interaction'].astype(str)

    # --- 3. Prepare Data for Model ---
    features = [
        'street_name',
        'violation_description',
        'violation_description_length',
        'violation_description_word_count',
    ]
    if include_interaction_feature:
        features.append('street_name_desc_len_interaction')

    target = 'violation_count'

    X = train_df[features]
    y = np.log1p(train_df[target])

    # Identify categorical and text features for CatBoost
    text_features_indices = []
    categorical_features_indices = []

    if use_text_features and 'violation_description' in features:
        text_features_indices.append(features.index('violation_description'))
        # Other object columns are regular categoricals
        categorical_features_indices = [i for i, col in enumerate(features) if X[col].dtype == 'object' and col != 'violation_description']
    else:
        # All object columns are regular categoricals
        categorical_features_indices = [i for i, col in enumerate(features) if X[col].dtype == 'object']

    # --- 4. Split Training Data for Validation ---
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    # Create CatBoost Pool objects
    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices, text_features=text_features_indices if use_text_features else None)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices, text_features=text_features_indices if use_text_features else None)

    # --- 5. Model Training ---
    model_params = {
        'iterations': 1000,
        'learning_rate': 0.03,
        'depth': 9,
        'l2_leaf_reg': 3,
        'eval_metric': 'RMSE',
        'random_seed': 42,
        'verbose': 0,
        'early_stopping_rounds': 100,
        'thread_count': -1,
    }

    if enable_bernoulli_bootstrap:
        model_params['bootstrap_type'] = 'Bernoulli'
        model_params['subsample'] = 0.8

    model = CatBoostRegressor(**model_params)

    model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=100, verbose=False)

    # --- 6. Validation ---
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log)
    val_predictions[val_predictions < 0] = 0

    rmse_val = np.sqrt(mean_squared_error(np.expm1(y_val), val_predictions))
    return rmse_val

def main():
    INPUT_DIR = './input'
    TRAIN_FILE = 'violations_per_street_2022.csv'
    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)

    # --- Baseline ---
    print("Running Baseline experiment (violation_description as categorical, with interaction feature, no Bernoulli bootstrap)...")
    baseline_rmse = run_experiment(
        train_df_path,
        use_text_features=False,
        include_interaction_feature=True,
        enable_bernoulli_bootstrap=False
    )
    print(f"Baseline Validation RMSE: {baseline_rmse}")
    best_rmse = baseline_rmse
    best_config_description = "Baseline (original configuration)"

    # --- Ablation 1: Using CatBoost's text_features for 'violation_description' ---
    print("\nRunning Ablation 1: Using CatBoost's text_features for 'violation_description'...")
    ablation1_rmse = run_experiment(
        train_df_path,
        use_text_features=True,
        include_interaction_feature=True,
        enable_bernoulli_bootstrap=False
    )
    print(f"Ablation 1 (with text_features) Validation RMSE: {ablation1_rmse}")
    if ablation1_rmse < best_rmse:
        best_rmse = ablation1_rmse
        best_config_description = "Ablation 1 (using CatBoost text_features for 'violation_description')"

    # --- Ablation 2: Removing 'street_name_desc_len_interaction' feature ---
    print("\nRunning Ablation 2: Removing 'street_name_desc_len_interaction' feature...")
    ablation2_rmse = run_experiment(
        train_df_path,
        use_text_features=False,
        include_interaction_feature=False,
        enable_bernoulli_bootstrap=False
    )
    print(f"Ablation 2 (without street_name_desc_len_interaction feature) Validation RMSE: {ablation2_rmse}")
    if ablation2_rmse < best_rmse:
        best_rmse = ablation2_rmse
        best_config_description = "Ablation 2 (without 'street_name_desc_len_interaction' feature)"

    # --- Ablation 3: Enabling Bernoulli Bootstrap ---
    print("\nRunning Ablation 3: Enabling Bernoulli Bootstrap (subsample=0.8)...")
    ablation3_rmse = run_experiment(
        train_df_path,
        use_text_features=False,
        include_interaction_feature=True,
        enable_bernoulli_bootstrap=True
    )
    print(f"Ablation 3 (with Bernoulli bootstrap) Validation RMSE: {ablation3_rmse}")
    if ablation3_rmse < best_rmse:
        best_rmse = ablation3_rmse
        best_config_description = "Ablation 3 (with Bernoulli Bootstrap enabled)"

    print(f"\nConclusion: The part of the code that contributed most positively to the overall performance in this study is: {best_config_description} with an RMSE of {best_rmse}")

if __name__ == "__main__":
    main()
