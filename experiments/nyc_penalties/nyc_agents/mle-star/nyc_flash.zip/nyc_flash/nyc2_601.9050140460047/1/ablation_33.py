
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        return None
    except pd.errors.EmptyDataError:
        return pd.DataFrame()
    except Exception as e:
        return None

def train_and_evaluate(config_name, config):
    # Ensure consistent data loading and initial processing for all experiments
    INPUT_DIR = './input'
    TRAIN_FILE = 'violations_per_street_2022.csv'

    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)
    train_df = load_data(train_df_path)

    if train_df is None or train_df.empty:
        return None

    required_train_cols = ['street_name', 'violation_description', 'violation_count']
    if not all(col in train_df.columns for col in required_train_cols):
        return None

    # --- Feature Engineering and Augmentation ---
    train_df['street_name'] = train_df['street_name'].astype(str)
    train_df['violation_description'] = train_df['violation_description'].astype(str)
    train_df['street_name'] = train_df['street_name'].fillna('UNKNOWN_STREET')
    train_df['violation_description'] = train_df['violation_description'].fillna('UNKNOWN_VIOLATION')

    train_df['violation_count'] = pd.to_numeric(train_df['violation_count'], errors='coerce')
    train_df['violation_count'] = train_df['violation_count'].fillna(0)
    train_df['violation_count'] = train_df['violation_count'].clip(lower=0)

    train_df['violation_description_length'] = train_df['violation_description'].apply(len)
    train_df['violation_description_word_count'] = train_df['violation_description'].apply(lambda x: len(str(x).split()))
    train_df['street_name_desc_len_interaction'] = \
        train_df['street_name'].astype(str) + '_' + train_df['violation_description_length'].astype(str)
    train_df['street_name_desc_len_interaction'] = train_df['street_name_desc_len_interaction'].astype(str)

    # --- Prepare Data for Model ---
    features = [
        'street_name',
        'violation_description',
        'violation_description_length',
        'violation_description_word_count',
        'street_name_desc_len_interaction'
    ]
    target = 'violation_count'

    X = train_df[features]
    y = np.log1p(train_df[target])

    # --- Ablation 1: CatBoost text_features for 'violation_description' ---
    cat_features_for_current_run = [col for col in features if X[col].dtype == 'object']
    text_features_for_catboost = []

    if config.get('use_text_features', False):
        if 'violation_description' in cat_features_for_current_run:
            cat_features_for_current_run.remove('violation_description')
        text_features_for_catboost.append('violation_description')

    categorical_features_indices = [X.columns.get_loc(col) for col in cat_features_for_current_run]
    text_features_indices = [X.columns.get_loc(col) for col in text_features_for_catboost]

    # --- Split Training Data for Validation ---
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    # Create CatBoost Pool objects
    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices, text_features=text_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices, text_features=text_features_indices)

    # --- CatBoost Model Parameters (with ablations) ---
    catboost_params = {
        'iterations': 1000,
        'learning_rate': 0.03,
        'depth': 9,
        'l2_leaf_reg': 3,
        'eval_metric': 'RMSE',
        'random_seed': 42,
        'verbose': 0,
        'early_stopping_rounds': 100,
        'thread_count': -1,
    }

    # Ablation 2: Enable Bernoulli Bootstrap
    if config.get('use_bernoulli_bootstrap', False):
        catboost_params['bootstrap_type'] = 'Bernoulli'
        catboost_params['subsample'] = 0.8

    # Ablation 3: Change grow_policy
    if config.get('grow_policy'):
        catboost_params['grow_policy'] = config['grow_policy']

    model = CatBoostRegressor(**catboost_params)

    # --- Model Training ---
    model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=100, verbose=False)

    # --- Validation ---
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log)
    val_predictions[val_predictions < 0] = 0

    rmse_val = np.sqrt(mean_squared_error(np.expm1(y_val), val_predictions))
    return rmse_val

# --- Ablation Study ---
ablation_results = {}

# Baseline
baseline_config = {
    'use_text_features': False,
    'use_bernoulli_bootstrap': False,
    'grow_policy': 'SymmetricTree' # Default CatBoost grow_policy
}
baseline_rmse = train_and_evaluate('Baseline', baseline_config)
if baseline_rmse is not None:
    ablation_results['Baseline'] = baseline_rmse
    print(f"Baseline Validation RMSE: {baseline_rmse:.4f}")

# Ablation 1: Enable CatBoost text_features for 'violation_description'
ablation1_config = baseline_config.copy()
ablation1_config['use_text_features'] = True
ablation1_rmse = train_and_evaluate('Ablation 1: CatBoost text_features for violation_description', ablation1_config)
if ablation1_rmse is not None:
    ablation_results['Ablation 1: CatBoost text_features for violation_description'] = ablation1_rmse
    print(f"Ablation 1 Validation RMSE: {ablation1_rmse:.4f}")

# Ablation 2: Enable Bernoulli Bootstrap
ablation2_config = baseline_config.copy()
ablation2_config['use_bernoulli_bootstrap'] = True
ablation2_rmse = train_and_evaluate('Ablation 2: Bernoulli Bootstrap', ablation2_config)
if ablation2_rmse is not None:
    ablation_results['Ablation 2: Bernoulli Bootstrap'] = ablation2_rmse
    print(f"Ablation 2 Validation RMSE: {ablation2_rmse:.4f}")

# Ablation 3: Change grow_policy to 'Depthwise'
ablation3_config = baseline_config.copy()
ablation3_config['grow_policy'] = 'Depthwise'
ablation3_rmse = train_and_evaluate('Ablation 3: grow_policy = Depthwise', ablation3_config)
if ablation3_rmse is not None:
    ablation_results['Ablation 3: grow_policy = Depthwise'] = ablation3_rmse
    print(f"Ablation 3 Validation RMSE: {ablation3_rmse:.4f}")

# --- Determine and print the most contributing part ---
if baseline_rmse is not None and len(ablation_results) > 1:
    
    best_rmse_overall = baseline_rmse
    best_component_overall = "Baseline (original configuration)"
    
    largest_improvement = 0.0
    most_beneficial_change = ""
    
    largest_degradation = 0.0
    most_detrimental_change = ""

    for name, rmse in ablation_results.items():
        if name == 'Baseline':
            continue 

        impact_vs_baseline = baseline_rmse - rmse
        print(f"{name}: RMSE {rmse:.4f} (Impact vs. Baseline: {impact_vs_baseline:+.4f})")

        if rmse < best_rmse_overall:
            best_rmse_overall = rmse
            best_component_overall = name
        
        if impact_vs_baseline > largest_improvement:
            largest_improvement = impact_vs_baseline
            most_beneficial_change = name
        
        if impact_vs_baseline < largest_degradation:
            largest_degradation = impact_vs_baseline
            most_detrimental_change = name

    print(f"\nThe best performing configuration achieved an RMSE of {best_rmse_overall:.4f}, which was from: {best_component_overall}")
    
    if most_beneficial_change:
        print(f"The most positively contributing change compared to the baseline was '{most_beneficial_change}', which improved RMSE by {largest_improvement:.4f}.")
    if most_detrimental_change:
        print(f"The most negatively contributing change compared to the baseline was '{most_detrimental_change}', which degraded RMSE by {abs(largest_degradation):.4f}.")

else:
    print("Not enough ablation results to draw a conclusion.")
