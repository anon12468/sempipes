
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import NMF

# Helper function to load data
def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return None
    except pd.errors.EmptyDataError:
        print(f"Warning: File is empty at {file_path}")
        return pd.DataFrame() # Return empty DataFrame to avoid further errors
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return None

def run_ablation_experiment(
    train_file_path: str,
    use_nmf_features: bool = True,
    catboost_depth: int = 9,
    catboost_l2_leaf_reg: float = 3.0,
    random_seed: int = 42 # Added to ensure reproducibility across runs if not already consistent
) -> float:
    """
    Runs a modified version of the training process and returns the validation RMSE.
    """
    INPUT_DIR = './input'
    
    train_df_path = os.path.join(INPUT_DIR, train_file_path)
    train_df = load_data(train_df_path)

    if train_df is None or train_df.empty:
        print("Training data could not be loaded or is empty. Exiting.")
        return float('inf') # Return a very high RMSE to indicate failure

    # Ensure required columns are present in the training data
    required_train_cols = ['street_name', 'violation_description', 'violation_count']
    if not all(col in train_df.columns for col in required_train_cols):
        print(f"Error: Training data missing one or more required columns: {required_train_cols}")
        print("Available columns:", train_df.columns.tolist())
        return float('inf')

    # --- Feature Engineering and Augmentation ---
    train_df['street_name'] = train_df['street_name'].astype(str)
    train_df['violation_description'] = train_df['violation_description'].astype(str)
    train_df['street_name'] = train_df['street_name'].fillna('UNKNOWN_STREET')
    train_df['violation_description'] = train_df['violation_description'].fillna('UNKNOWN_VIOLATION')

    train_df['violation_count'] = pd.to_numeric(train_df['violation_count'], errors='coerce')
    train_df['violation_count'] = train_df['violation_count'].fillna(0)
    train_df['violation_count'] = train_df['violation_count'].clip(lower=0)

    train_df['violation_description_length'] = train_df['violation_description'].apply(len)
    train_df['violation_description_word_count'] = train_df['violation_description'].apply(lambda x: len(str(x).split()))

    nmf_feature_names = []
    if use_nmf_features:
        # Check if there's enough data to perform NMF.
        # This check prevents errors when tfidf_matrix dimensions are too small or zero.
        if not train_df['violation_description'].empty:
            train_df['violation_description_processed'] = train_df['violation_description'].fillna('')
            tfidf_vectorizer = TfidfVectorizer(max_features=5000, stop_words='english', min_df=5, max_df=0.9)
            
            # Fit and transform, handling potential empty vocabulary
            try:
                tfidf_matrix = tfidf_vectorizer.fit_transform(train_df['violation_description_processed'])
            except ValueError as e:
                print(f"Warning: TF-IDF vectorization failed: {e}. Skipping NMF features.")
                use_nmf_features = False # Disable NMF if TF-IDF fails
            
            if use_nmf_features: # Proceed with NMF if TF-IDF was successful
                original_desired_n_topics = 10
                min_dim_for_nmf = min(tfidf_matrix.shape[0], tfidf_matrix.shape[1])
                n_topics_for_nmf = min(original_desired_n_topics, min_dim_for_nmf)

                if n_topics_for_nmf >= 1:
                    nmf_model = NMF(n_components=n_topics_for_nmf, random_state=random_seed, init='nndsvda', max_iter=200)
                    nmf_features = nmf_model.fit_transform(tfidf_matrix)
                    for i in range(n_topics_for_nmf):
                        col_name = f'violation_topic_{i}'
                        train_df[col_name] = nmf_features[:, i]
                        nmf_feature_names.append(col_name)
                train_df = train_df.drop(columns=['violation_description_processed'])
        else:
            print("Warning: 'violation_description' column is empty, skipping NMF features.")
            use_nmf_features = False # Disable NMF if description column is empty


    train_df['street_name_desc_len_interaction'] = \
        train_df['street_name'].astype(str) + '_' + train_df['violation_description_length'].astype(str)
    train_df['street_name_desc_len_interaction'] = train_df['street_name_desc_len_interaction'].astype(str)

    # --- Prepare Data for Model ---
    features = [
        'street_name',
        'violation_description',
        'violation_description_length',
        'violation_description_word_count',
        'street_name_desc_len_interaction'
    ]
    if use_nmf_features and nmf_feature_names: # Only extend if NMF was actually applied and produced features
        features.extend(nmf_feature_names)

    target = 'violation_count'

    # Filter out features that might not exist in case of issues (e.g., NMF didn't run)
    actual_features = [f for f in features if f in train_df.columns]
    if not actual_features:
        print("Error: No features available for training. Exiting.")
        return float('inf')

    X = train_df[actual_features]
    y = np.log1p(train_df[target])

    categorical_features_indices = [i for i, col in enumerate(X.columns) if X[col].dtype == 'object']

    # --- Split Training Data for Validation ---
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=random_seed)

    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices)

    # --- Model Training ---
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.03,
        depth=catboost_depth,
        l2_leaf_reg=catboost_l2_leaf_reg,
        eval_metric='RMSE',
        random_seed=random_seed,
        verbose=0,
        early_stopping_rounds=100,
        thread_count=-1,
    )

    model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=100, verbose=False)

    # --- Validation ---
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log)
    val_predictions[val_predictions < 0] = 0

    rmse_val = np.sqrt(mean_squared_error(np.expm1(y_val), val_predictions))
    return rmse_val

if __name__ == "__main__":
    train_data_file = 'violations_per_street_2022.csv'
    
    # --- Baseline ---
    print("Running Baseline (Original Configuration)...")
    baseline_rmse = run_ablation_experiment(train_data_file)
    print(f"Baseline Validation RMSE: {baseline_rmse:.4f}\n")

    # --- Ablation 1: Remove NMF Features ---
    print("Running Ablation 1: Removing NMF Features...")
    rmse_ablation1 = run_ablation_experiment(train_data_file, use_nmf_features=False)
    print(f"Ablation 1 (No NMF Features) Validation RMSE: {rmse_ablation1:.4f}")
    print(f"Impact: {rmse_ablation1 - baseline_rmse:.4f} (compared to baseline)\n")

    # --- Ablation 2: Change CatBoost depth from 9 to 11 ---
    print("Running Ablation 2: Changing CatBoost depth to 11...")
    rmse_ablation2 = run_ablation_experiment(train_data_file, catboost_depth=11)
    print(f"Ablation 2 (CatBoost depth=11) Validation RMSE: {rmse_ablation2:.4f}")
    print(f"Impact: {rmse_ablation2 - baseline_rmse:.4f} (compared to baseline)\n")

    # --- Ablation 3: Change CatBoost l2_leaf_reg from 3 to 0 ---
    print("Running Ablation 3: Changing CatBoost l2_leaf_reg to 0...")
    rmse_ablation3 = run_ablation_experiment(train_data_file, catboost_l2_leaf_reg=0.0)
    print(f"Ablation 3 (CatBoost l2_leaf_reg=0) Validation RMSE: {rmse_ablation3:.4f}")
    print(f"Impact: {rmse_ablation3 - baseline_rmse:.4f} (compared to baseline)\n")

    # Determine the most contributing part
    # A component contributes positively if its presence (or baseline setting) leads to a lower RMSE.
    # An ablation that *increases* RMSE means the baseline was beneficial.
    # An ablation that *decreases* RMSE means the baseline was detrimental, and the ablation was beneficial.

    impacts = {
        "NMF Features (removed)": rmse_ablation1 - baseline_rmse,
        "CatBoost depth (changed 9 -> 11)": rmse_ablation2 - baseline_rmse,
        "CatBoost l2_leaf_reg (changed 3 -> 0)": rmse_ablation3 - baseline_rmse
    }

    print("Overall Conclusion:")
    
    # Find the ablation with the largest absolute change
    largest_impact_key = max(impacts, key=lambda k: abs(impacts[k]))
    largest_impact_value = impacts[largest_impact_key]

    if largest_impact_value > 0:
        # The ablation degraded performance, meaning the original component/setting was beneficial.
        if largest_impact_key == "NMF Features (removed)":
            part_name = "NMF Features"
            contribution_desc = "highly beneficial (its presence was crucial, removing it degraded RMSE significantly)"
        elif largest_impact_key == "CatBoost depth (changed 9 -> 11)":
            part_name = "CatBoost depth (original setting of 9)"
            contribution_desc = "beneficial (changing it to 11 degraded RMSE, implying 9 is better)"
        elif largest_impact_key == "CatBoost l2_leaf_reg (changed 3 -> 0)":
            # This case means changing l2_leaf_reg to 0 degraded performance, so 3 was better.
            part_name = "CatBoost l2_leaf_reg (original setting of 3)"
            contribution_desc = "beneficial (changing it to 0 degraded RMSE, implying 3 is better)"
    else:
        # The ablation improved performance, meaning the original component/setting was detrimental.
        if largest_impact_key == "NMF Features (removed)":
            part_name = "NMF Features"
            contribution_desc = "detrimental (its presence increased RMSE, removing it improved RMSE significantly)"
        elif largest_impact_key == "CatBoost depth (changed 9 -> 11)":
            part_name = "CatBoost depth (original setting of 9)"
            contribution_desc = "detrimental (changing it to 11 improved RMSE, implying 9 is worse)"
        elif largest_impact_key == "CatBoost l2_leaf_reg (changed 3 -> 0)":
            # This case means changing l2_leaf_reg to 0 improved performance, so 3 was detrimental.
            part_name = "CatBoost l2_leaf_reg (original setting of 3)"
            contribution_desc = "detrimental (changing it to 0 improved RMSE, implying 3 is worse)"

    print(f"The part that contributes the most to the overall performance (i.e., has the largest absolute impact on RMSE) is: {part_name}.")
    print(f"Its modification resulted in an absolute RMSE change of {abs(largest_impact_value):.4f}, indicating it was {contribution_desc}.")

