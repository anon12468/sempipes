
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os

# --- Utility functions (copied from original solution) ---
def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names.
    If the file is not found, a dummy CSV is created for demonstration purposes."""
    try:
        df = pd.read_csv(file_path)
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        print(f"Warning: File not found at {file_path}. Creating a dummy file for demonstration.")
        # Create dummy data to allow the script to run
        dummy_data = {
            'Street Name': ['MAIN ST', 'ELM AVE', 'OAK BLVD', 'MAIN ST', 'ELM AVE', 'MAPLE DR', 'ELM AVE', 'PINE ST', 'MAIN ST', 'OAK BLVD'],
            'Violation Description': ['PARKING METER', 'NO STANDING', 'FIRE HYDRANT', 'NO STANDING', 'PARKING METER', 'FIRE HYDRANT', 'NO STANDING', 'NO PARKING', 'OVERTIME PARKING', 'DOUBLE PARKING'],
            'Violation Count': [100, 50, 10, 80, 60, 15, 45, 25, 110, 30]
        }
        df = pd.DataFrame(dummy_data)
        df.to_csv(file_path, index=False)
        print(f"Dummy file created at {file_path}. Reloading.")
        df = pd.read_csv(file_path)
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except pd.errors.EmptyDataError:
        print(f"Warning: File is empty at {file_path}")
        return pd.DataFrame()
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return None

# --- Experiment Runner ---
def run_experiment(experiment_name, base_train_df, features_to_use, enable_early_stopping=True):
    """
    Runs a single CatBoost regression experiment with specified features and early stopping.

    Args:
        experiment_name (str): Name of the current experiment.
        base_train_df (pd.DataFrame): The base training DataFrame.
        features_to_use (list): List of features (column names) to use for this experiment.
        enable_early_stopping (bool): Whether to enable early stopping during training.

    Returns:
        float: Validation RMSE for the experiment, or NaN if the experiment fails.
    """
    print(f"\n--- Running Experiment: {experiment_name} ---")

    current_df = base_train_df.copy()

    # Apply type conversion and NaN handling for selected features
    for col in features_to_use:
        if col not in current_df.columns:
            print(f"Error: Feature '{col}' not found in DataFrame for experiment '{experiment_name}'. Skipping.")
            return np.nan
        current_df[col] = current_df[col].astype(str).fillna(f'UNKNOWN_{col.upper()}')

    target = 'violation_count'
    if target not in current_df.columns:
        print(f"Error: Target column '{target}' not found in DataFrame for experiment '{experiment_name}'. Skipping.")
        return np.nan
    current_df[target] = pd.to_numeric(current_df[target], errors='coerce').fillna(0).clip(lower=0)

    X = current_df[features_to_use]
    y = current_df[target]

    if X.empty or y.empty:
        print(f"No valid data or features left for experiment '{experiment_name}'. Skipping.")
        return np.nan

    # Identify categorical features for CatBoost
    categorical_features_indices = [i for i, col in enumerate(features_to_use) if X[col].dtype == 'object']

    # Split data for training and validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices)

    # CatBoost model parameters
    model_params = {
        'iterations': 1000,
        'learning_rate': 0.03,
        'depth': 8,
        'eval_metric': 'RMSE',
        'random_seed': 42,
        'verbose': 0, # Suppress verbose output
        'thread_count': -1, # Use all available threads
    }

    model = CatBoostRegressor(**model_params)

    print(f"Training model with features: {features_to_use}")
    fit_params = {'verbose': False} # Always suppress iteration output from fit
    if enable_early_stopping:
        fit_params['eval_set'] = val_pool
        fit_params['early_stopping_rounds'] = 100

    model.fit(train_pool, **fit_params)

    # Make predictions and evaluate
    val_predictions = model.predict(X_val)
    val_predictions[val_predictions < 0] = 0 # Ensure predictions are non-negative
    rmse_val = np.sqrt(mean_squared_error(y_val, val_predictions))
    print(f"Validation RMSE for '{experiment_name}': {rmse_val:.4f}")
    return rmse_val

def main_ablation_study():
    INPUT_DIR = './input'
    TRAIN_FILE = 'violations_per_street_2022.csv'
    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)

    if not os.path.exists(INPUT_DIR):
        os.makedirs(INPUT_DIR)

    print(f"Loading base training data from: {train_df_path}")
    base_train_df = load_data(train_df_path)

    if base_train_df is None or base_train_df.empty:
        print("Base training data could not be loaded or is empty. Exiting ablation study.")
        return

    print(f"Base training data shape: {base_train_df.shape}")

    results = {}

    # --- 1. Baseline Run (Original Solution's Training Logic) ---
    baseline_features = ['street_name', 'violation_description']
    baseline_rmse = run_experiment("Baseline (Original Solution)",
                                   base_train_df,
                                   baseline_features,
                                   enable_early_stopping=True)
    results["Baseline (Original Solution)"] = baseline_rmse

    # --- 2. Ablation: Remove 'violation_description' feature ---
    ablation1_features = ['street_name']
    ablation1_rmse = run_experiment("Ablation 1: Remove 'violation_description'",
                                    base_train_df,
                                    ablation1_features,
                                    enable_early_stopping=True)
    results["Ablation 1: Remove 'violation_description'"] = ablation1_rmse

    # --- 3. Ablation: Disable Early Stopping ---
    ablation2_features = ['street_name', 'violation_description']
    ablation2_rmse = run_experiment("Ablation 2: Disable Early Stopping",
                                    base_train_df,
                                    ablation2_features,
                                    enable_early_stopping=False)
    results["Ablation 2: Disable Early Stopping"] = ablation2_rmse

    # --- Summarize Results ---
    print("\n--- Ablation Study Summary ---")
    for name, rmse in results.items():
        if not np.isnan(rmse):
            print(f"- {name}: RMSE = {rmse:.4f}")
        else:
            print(f"- {name}: Failed to run or returned NaN RMSE.")

    # --- Contribution Analysis ---
    print("\n--- Contribution Analysis ---")
    if np.isnan(results.get("Baseline (Original Solution)")):
        print("Baseline experiment failed, cannot perform contribution analysis.")
        return

    baseline_rmse = results["Baseline (Original Solution)"]
    impacts = {}

    if not np.isnan(results.get("Ablation 1: Remove 'violation_description'")):
        impacts["'violation_description' feature"] = results["Ablation 1: Remove 'violation_description'"] - baseline_rmse
    if not np.isnan(results.get("Ablation 2: Disable Early Stopping")):
        impacts["Early Stopping"] = results["Ablation 2: Disable Early Stopping"] - baseline_rmse

    if not impacts:
        print("No ablation results available for comparison.")
        return

    most_impactful_component = None
    max_abs_impact = 0.0

    for component, impact_val in impacts.items():
        performance_change_type = '(worse)' if impact_val > 0 else ('(better)' if impact_val < 0 else '(no change)')
        print(f"- Change by modifying '{component}' (relative to baseline): {impact_val:.4f} RMSE {performance_change_type}")

        if abs(impact_val) > max_abs_impact:
            max_abs_impact = abs(impact_val)
            most_impactful_component = component

    if most_impactful_component:
        print(f"\nBased on the observed changes, the part contributing most significantly (with the largest absolute impact on RMSE) is: '{most_impactful_component}'.")
        impact_value = impacts[most_impactful_component]
        if impact_value > 0:
            print(f"Modifying '{most_impactful_component}' (e.g., by removing or disabling it) resulted in a {impact_value:.4f} increase in RMSE compared to the baseline.")
            print(f"This indicates that '{most_impactful_component}' was a beneficial component, contributing positively by reducing RMSE in the original solution.")
        elif impact_value < 0:
            print(f"Modifying '{most_impactful_component}' resulted in a {-impact_value:.4f} decrease in RMSE compared to the baseline.")
            print(f"This indicates that the original setting for '{most_impactful_component}' was suboptimal, and the ablated version performed better.")
        else:
            print(f"Modifying '{most_impactful_component}' resulted in no change in RMSE.")
    else:
        print("No impactful changes were observed from the ablations.")


if __name__ == "__main__":
    main_ablation_study()
