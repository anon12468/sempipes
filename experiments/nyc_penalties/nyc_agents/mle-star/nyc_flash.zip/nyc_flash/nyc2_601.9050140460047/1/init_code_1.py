
import pandas as pd
import numpy as np
import os
import argparse
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool

# Function to calculate RMSE
def rmse(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument("--train-path", type=str, default="violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Optional path to the 2023 test data CSV for predictions.")
    args = parser.parse_args()

    SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
    INPUT_DIR = os.path.join(SCRIPT_DIR, 'input')

    # Define file paths
    train_violations_file = os.path.join(INPUT_DIR, args.train_path)
    parking_codes_file = os.path.join(INPUT_DIR, 'parking_violations_codes.csv')
    street_geo_file = os.path.join(INPUT_DIR, 'nyc_streets_geographic_data.csv')

    print(f"Loading data from: {train_violations_file}")
    print(f"Loading parking codes from: {parking_codes_file}")
    print(f"Loading street geo data from: {street_geo_file}")

    # Load data
    try:
        train_df = pd.read_csv(train_violations_file)
        parking_codes_df = pd.read_csv(parking_codes_file)
        street_geo_df = pd.read_csv(street_geo_file)
    except FileNotFoundError as e:
        print(f"Error loading file: {e}. Please ensure files are in the 'input' directory and accessible.")
        return # Exit if files are not found

    # Rename columns for consistency and robustness
    train_df.rename(columns={'Street Name': 'street_name', 'Violation Description': 'violation_type', 'violation_count': 'violation_count'}, inplace=True)
    
    # Check if columns exist before renaming to avoid KeyError if schema deviates
    if 'Code' in parking_codes_df.columns and 'Description' in parking_codes_df.columns and 'Definition' in parking_codes_df.columns:
        parking_codes_df.rename(columns={'Code': 'violation_code', 'Description': 'violation_type', 'Definition': 'violation_definition'}, inplace=True)
    else:
        print("Warning: Expected columns 'Code', 'Description', 'Definition' not found in parking_violations_codes.csv. Some features might be missing.")

    expected_geo_cols = ['street_name', 'borough', 'latitude', 'longitude', 'segment_length', 'zip_code']
    if all(col in street_geo_df.columns for col in expected_geo_cols):
        street_geo_df.rename(columns={'street_name': 'street_name', 'borough': 'borough', 'latitude': 'latitude', 'longitude': 'longitude', 'segment_length': 'segment_length', 'zip_code': 'zip_code'}, inplace=True)
    else:
        print(f"Warning: Not all expected columns {expected_geo_cols} found in nyc_streets_geographic_data.csv. Some features might be missing.")

    # --- Feature Engineering ---

    # Merge parking violation codes
    train_df['violation_type_lower'] = train_df['violation_type'].str.lower().str.strip()
    if 'violation_type' in parking_codes_df.columns and 'violation_code' in parking_codes_df.columns and 'violation_definition' in parking_codes_df.columns:
        parking_codes_df['violation_type_lower'] = parking_codes_df['violation_type'].str.lower().str.strip()
        parking_codes_df_unique = parking_codes_df.drop_duplicates(subset=['violation_type_lower'], keep='first')
        train_df = pd.merge(train_df, parking_codes_df_unique[['violation_type_lower', 'violation_code', 'violation_definition']],
                            on='violation_type_lower', how='left')
    else:
        print("Warning: 'violation_type', 'violation_code', or 'violation_definition' not found in parking codes after processing, skipping merge with parking codes.")
        train_df['violation_code'] = np.nan
        train_df['violation_definition'] = np.nan

    # Merge street geographic data
    train_df['street_name_lower'] = train_df['street_name'].str.lower().str.strip()
    if 'street_name' in street_geo_df.columns and 'borough' in street_geo_df.columns: # Check essential geo columns
        street_geo_df['street_name_lower'] = street_geo_df['street_name'].str.lower().str.strip()
        street_geo_df['zip_code'] = street_geo_df['zip_code'].astype(str) # Ensure zip_code is string for mode

        # Aggregate street_geo_df if multiple entries for a street
        street_geo_agg = street_geo_df.groupby('street_name_lower').agg(
            borough=('borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan),
            latitude=('latitude', 'mean'),
            longitude=('longitude', 'mean'),
            segment_length=('segment_length', 'sum'),
            zip_code=('zip_code', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
        ).reset_index()

        train_df = pd.merge(train_df, street_geo_agg, on='street_name_lower', how='left')
    else:
        print("Warning: Essential 'street_name' or 'borough' not found in street geo data after processing, skipping merge with street geo data.")
        for col in ['borough', 'latitude', 'longitude', 'segment_length', 'zip_code']:
            train_df[col] = np.nan

    # Drop temporary lower case columns
    train_df.drop(columns=['violation_type_lower', 'street_name_lower'], errors='ignore', inplace=True)

    # Define categorical and numerical columns that are expected in the final dataframe
    categorical_cols = ['street_name', 'violation_type', 'violation_code', 'violation_definition', 'borough', 'zip_code']
    numerical_cols = ['latitude', 'longitude', 'segment_length']

    # Handle missing values after merges for training data
    for col in categorical_cols:
        if col in train_df.columns:
            train_df[col] = train_df[col].fillna('Unknown').astype(str)
        else:
            train_df[col] = 'Unknown' # Add missing categorical column
    for col in numerical_cols:
        if col in train_df.columns:
            train_df[col] = train_df[col].fillna(0.0)
        else:
            train_df[col] = 0.0 # Add missing numerical column

    # Ensure 'violation_count' is numeric and non-negative
    if not pd.api.types.is_numeric_dtype(train_df['violation_count']):
        print("Warning: 'violation_count' is not numeric. Attempting to convert.")
        train_df['violation_count'] = pd.to_numeric(train_df['violation_count'], errors='coerce')
    train_df['violation_count'] = train_df['violation_count'].fillna(0).astype(int) # Fill NaNs from coercion with 0, then convert to int
    train_df = train_df[train_df['violation_count'] >= 0] # Filter out any remaining negative counts

    # --- Model Training ---
    features = [col for col in train_df.columns if col not in ['violation_count']]
    cat_features = [col for col in categorical_cols if col in features] # Use column names for CatBoost

    X = train_df[features]
    y = train_df['violation_count']

    # Split 2022 data for validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42, shuffle=True)

    print(f"Training data shape: {X_train.shape}")
    print(f"Validation data shape: {X_val.shape}")

    # Initialize CatBoostRegressor with optimized parameters for stability and performance
    model = CatBoostRegressor(
        iterations=2000,
        learning_rate=0.03,
        depth=6, # Default depth, often good balance for memory and performance
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=200, # Print every 200 iterations for progress tracking
        early_stopping_rounds=100, # Stop if validation RMSE doesn't improve for 100 rounds
        nan_mode='Min', # Explicitly handle NaNs by treating them as minimum values
        thread_count=-1, # Use all available CPU threads
        subsample=0.7, # Use subsampling to reduce overfitting and memory usage
        bootstrap_type='Bernoulli', # Recommended with subsample
        # use_best_model=True is default when eval_set is provided
    )

    # Create CatBoost Pool objects (using column names for categorical features)
    train_pool = Pool(X_train, y_train, cat_features=cat_features)
    val_pool = Pool(X_val, y_val, cat_features=cat_features)

    print("Starting model training...")
    try:
        model.fit(train_pool, eval_set=val_pool)
        print("Model training complete.")
    except Exception as e:
        print(f"Error during CatBoost model fitting: {e}")
        return # Exit if training fails

    # --- Validation Performance ---
    val_predictions = model.predict(X_val)
    val_predictions = np.maximum(0, val_predictions).round().astype(int) # Clip to non-negative and round
    final_validation_score = rmse(y_val, val_predictions)
    print(f"Final Validation Performance: {final_validation_score}")

    # --- Prediction for Test Data (if provided) ---
    if args.test_path:
        test_violations_file = os.path.join(INPUT_DIR, args.test_path)
        print(f"Loading test data from: {test_violations_file}")
        try:
            test_df = pd.read_csv(test_violations_file)
        except FileNotFoundError:
            print(f"Test file not found: {test_violations_file}. Skipping test predictions.")
            return

        # Prepare test data: Apply same feature engineering steps as training data
        test_df.rename(columns={'Street Name': 'street_name', 'Violation Description': 'violation_type', 'violation_count': 'violation_count'}, inplace=True)
        submission_df = test_df[['street_name', 'violation_type']].copy()

        # Merge parking violation codes
        test_df['violation_type_lower'] = test_df['violation_type'].str.lower().str.strip()
        if 'violation_type' in parking_codes_df.columns and 'violation_code' in parking_codes_df.columns and 'violation_definition' in parking_codes_df.columns:
            test_df = pd.merge(test_df, parking_codes_df_unique[['violation_type_lower', 'violation_code', 'violation_definition']],
                                on='violation_type_lower', how='left')
        else:
            test_df['violation_code'] = np.nan
            test_df['violation_definition'] = np.nan

        # Merge street geographic data
        test_df['street_name_lower'] = test_df['street_name'].str.lower().str.strip()
        if 'street_name' in street_geo_df.columns and 'borough' in street_geo_df.columns:
            test_df = pd.merge(test_df, street_geo_agg, on='street_name_lower', how='left')
        else:
            for col in ['borough', 'latitude', 'longitude', 'segment_length', 'zip_code']:
                test_df[col] = np.nan

        test_df.drop(columns=['violation_type_lower', 'street_name_lower'], errors='ignore', inplace=True)

        # Handle missing values for test data (ensure consistency with training features)
        for col in categorical_cols:
            if col in test_df.columns:
                test_df[col] = test_df[col].fillna('Unknown').astype(str)
            else:
                test_df[col] = 'Unknown' # Add missing categorical column
        for col in numerical_cols:
            if col in test_df.columns:
                test_df[col] = test_df[col].fillna(0.0)
            else:
                test_df[col] = 0.0 # Add missing numerical column

        # Ensure all features used in training are present in the test set, create if missing
        for feature in features:
            if feature not in test_df.columns:
                if feature in categorical_cols:
                    test_df[feature] = 'Unknown'
                else: # Default for numerical or other missing features
                    test_df[feature] = 0.0
        
        # Ensure feature order is the same as training features
        X_test = test_df[features]

        # Identify unseen key pairs
        train_keys = set(train_df.apply(lambda row: (row['street_name'], row['violation_type']), axis=1))
        test_keys = set(test_df.apply(lambda row: (row['street_name'], row['violation_type']), axis=1))
        unseen_keys_count = len(test_keys - train_keys)
        print(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_keys_count}")

        # Predict
        print("Generating predictions for test data...")
        try:
            test_predictions = model.predict(X_test)
            test_predictions = np.maximum(0, test_predictions).round().astype(int)
        except Exception as e:
            print(f"Error during prediction on test data: {e}")
            test_predictions = np.zeros(len(X_test)).astype(int) # Fallback to zero predictions if prediction fails

        # Create submission file
        submission_df['predicted_count'] = test_predictions
        submission_df.to_csv('submission.csv', index=False)
        print("Submission file 'submission.csv' created.")

        # If test_df has 'violation_count' (ground truth), calculate RMSE
        if 'violation_count' in test_df.columns and not test_df['violation_count'].isnull().all():
            valid_test_rows = test_df['violation_count'].notna()
            test_true_counts = test_df.loc[valid_test_rows, 'violation_count'].astype(int)
            test_predictions_for_valid_rows = test_predictions[valid_test_rows.values]

            if not test_true_counts.empty:
                test_rmse = rmse(test_true_counts, test_predictions_for_valid_rows)
                print(f"Test Set RMSE (against ground truth): {test_rmse}")
            else:
                print("No valid ground truth 'violation_count' available in test file for RMSE calculation.")
        else:
            print("No ground truth 'violation_count' in test file, skipping test RMSE calculation.")

if __name__ == "__main__":
    main()
