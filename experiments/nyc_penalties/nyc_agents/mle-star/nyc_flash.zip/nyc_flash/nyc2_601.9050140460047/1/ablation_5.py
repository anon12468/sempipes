

import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        return None
    except pd.errors.EmptyDataError:
        return pd.DataFrame()
    except Exception as e:
        return None

def run_ablation_experiment(train_df_processed, experiment_name, features_to_use, actual_categorical_cols_for_catboost):
    """
    Runs a single ablation experiment with a given set of features.
    `actual_categorical_cols_for_catboost`: List of column names that CatBoost should treat as categorical for *this specific experiment*.
    """
    X = train_df_processed[features_to_use]
    y = train_df_processed['violation_count']

    # Get indices for categorical features that are *actually present* in X for this experiment
    categorical_features_indices = [X.columns.get_loc(col) for col in actual_categorical_cols_for_catboost if col in X.columns]

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices)

    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.03,
        depth=8,
        eval_metric='RMSE',
        random_seed=42,
        verbose=0,
        early_stopping_rounds=100,
        thread_count=-1,
    )

    model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=100, verbose=False)

    val_predictions = model.predict(X_val)
    val_predictions[val_predictions < 0] = 0
    rmse_val = np.sqrt(mean_squared_error(y_val, val_predictions))
    return rmse_val

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV relative to INPUT_DIR.')
    args = parser.parse_args()

    INPUT_DIR = './input'
    TRAIN_FILE = args.train_path

    train_df = load_data(os.path.join(INPUT_DIR, TRAIN_FILE))

    if train_df is None or train_df.empty:
        return

    required_train_cols = ['street_name', 'violation_description', 'violation_count']
    if not all(col in train_df.columns for col in required_train_cols):
        return

    # --- Feature Engineering (common for all experiments) ---
    # Perform all feature engineering first on the full dataframe
    train_df['street_name'] = train_df['street_name'].astype(str)
    train_df['violation_description'] = train_df['violation_description'].astype(str)
    train_df['street_name'] = train_df['street_name'].fillna('UNKNOWN_STREET')
    train_df['violation_description'] = train_df['violation_description'].fillna('UNKNOWN_VIOLATION')

    train_df['violation_count'] = pd.to_numeric(train_df['violation_count'], errors='coerce')
    train_df['violation_count'] = train_df['violation_count'].fillna(0).clip(lower=0)

    train_df['violation_description_length'] = train_df['violation_description'].apply(len)
    train_df['violation_description_word_count'] = train_df['violation_description'].apply(lambda x: len(str(x).split()))

    train_df['violation_description_lower'] = train_df['violation_description'].str.lower()
    violation_keywords = ['parking', 'standing', 'zone', 'meter', 'handicap', 'fire lane', 'hydrant', 'loading', 'permit', 'expired']
    keyword_feature_names = []
    for keyword in violation_keywords:
        col_name = f'has_{keyword.replace(" ", "_")}'
        train_df[col_name] = train_df['violation_description_lower'].str.contains(keyword, na=False)
        train_df[col_name] = train_df[col_name].astype(int) # Convert boolean to int (0/1) for CatBoost
        keyword_feature_names.append(col_name)

    def categorize_violation(description_lower):
        if 'parking' in description_lower: return 'parking_related'
        elif 'standing' in description_lower: return 'standing_related'
        elif 'zone' in description_lower or 'meter' in description_lower: return 'zone_meter_related'
        elif 'handicap' in description_lower or 'disabled' in description_lower: return 'handicap_related'
        elif 'fire' in description_lower: return 'fire_safety_related'
        elif 'loading' in description_lower: return 'loading_zone_related'
        elif 'expired' in description_lower or 'permit' in description_lower: return 'permit_expired_related'
        else: return 'other_violation'

    train_df['violation_category'] = train_df['violation_description_lower'].apply(categorize_violation)
    train_df['violation_category'] = train_df['violation_category'].astype(str) # CatBoost handles string as categorical

    train_df['street_name_desc_len_interaction'] = \
        train_df['street_name'].astype(str) + '_' + train_df['violation_description_length'].astype(str)
    train_df['street_name_desc_len_interaction'] = train_df['street_name_desc_len_interaction'].astype(str)

    train_df = train_df.drop(columns=['violation_description_lower'])

    # --- Define Feature Sets and Categorical Features for Ablation ---
    base_features_always_present = [
        'street_name',
        'violation_description',
        'violation_description_length',
        'violation_description_word_count',
        'street_name_desc_len_interaction'
    ]

    # These are the column names that CatBoost should be told are categorical (string type)
    base_catboost_categorical_cols = [
        'street_name',
        'violation_description',
        'street_name_desc_len_interaction'
    ]

    ablation_results = {}

    # Experiment 1: Baseline (All features, including keyword booleans and violation_category)
    features_exp1 = base_features_always_present + keyword_feature_names + ['violation_category']
    categorical_cols_exp1 = base_catboost_categorical_cols + ['violation_category']
    ablation_results['Baseline (All Features)'] = run_ablation_experiment(
        train_df, 'Baseline (All Features)', features_exp1, categorical_cols_exp1
    )

    # Experiment 2: No Keyword Boolean Features
    # Removes all 'has_keyword' features. These are numerical, so they are not in the categorical_cols list.
    features_exp2 = base_features_always_present + ['violation_category']
    categorical_cols_exp2 = base_catboost_categorical_cols + ['violation_category']
    ablation_results['No Keyword Boolean Features'] = run_ablation_experiment(
        train_df, 'No Keyword Boolean Features', features_exp2, categorical_cols_exp2
    )

    # Experiment 3: No Categorical `violation_category` Feature
    features_exp3 = base_features_always_present + keyword_feature_names
    categorical_cols_exp3 = base_catboost_categorical_cols
    ablation_results['No Violation Category Feature'] = run_ablation_experiment(
        train_df, 'No Violation Category Feature', features_exp3, categorical_cols_exp3
    )

    # --- Conclusion ---
    print("\n--- Ablation Study Results ---")
    for name, rmse in ablation_results.items():
        print(f"{name}: RMSE = {rmse}")

    baseline_rmse = ablation_results['Baseline (All Features)']
    most_impactful_change_name = "None found"
    max_impact_value = 0.0

    print("\nImpact compared to Baseline:")
    for name, rmse in ablation_results.items():
        if name == 'Baseline (All Features)':
            continue
        
        diff = rmse - baseline_rmse
        print(f"Removing '{name}' led to an RMSE change of: {diff:.4f}")

        if abs(diff) > abs(max_impact_value):
            max_impact_value = diff
            most_impactful_change_name = name

    if max_impact_value > 0: # Removal caused degradation, so the component was beneficial
        print(f"\nConclusion: The part of the code that contributes most positively to the overall performance is the inclusion of the features associated with '{most_impactful_change_name}'. Its removal caused the largest degradation in RMSE.")
    elif max_impact_value < 0: # Removal caused improvement, so the component was detrimental
        print(f"\nConclusion: The part of the code that contributes most negatively (or least positively) to the overall performance is the inclusion of the features associated with '{most_impactful_change_name}'. Its removal caused the largest improvement in RMSE.")
    else:
        print("\nConclusion: All ablated components had negligible impact on performance.")

if __name__ == "__main__":
    main()
