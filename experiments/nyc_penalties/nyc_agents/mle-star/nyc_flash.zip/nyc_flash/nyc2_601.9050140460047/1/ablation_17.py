
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return None
    except pd.errors.EmptyDataError:
        print(f"Warning: File is empty at {file_path}")
        return pd.DataFrame() # Return empty DataFrame to avoid further errors
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return None

def run_ablation_model(
    train_df,
    use_enhanced_features=True,
    use_catboost_text_features=True,
    random_seed_value=42,
    iteration_label="Baseline"
):
    print(f"\n--- Running Ablation: {iteration_label} ---")
    
    df_processed = train_df.copy()

    # Convert categorical features to string type explicitly for CatBoost
    df_processed['street_name'] = df_processed['street_name'].astype(str)
    df_processed['violation_description'] = df_processed['violation_description'].astype(str)
    # Handle potential NaN values in categorical features by filling them with a placeholder
    df_processed['street_name'] = df_processed['street_name'].fillna('UNKNOWN_STREET')
    df_processed['violation_description'] = df_processed['violation_description'].fillna('UNKNOWN_VIOLATION')

    # Ensure target variable is numeric and handle potential NaNs (e.g., fill with 0 or mean)
    df_processed['violation_count'] = pd.to_numeric(df_processed['violation_count'], errors='coerce')
    df_processed['violation_count'] = df_processed['violation_count'].fillna(0) # Fill NaNs in target with 0
    # Ensure violation counts are non-negative
    df_processed['violation_count'] = df_processed['violation_count'].clip(lower=0)

    # Base features
    features_to_use = [
        'street_name',
        'violation_description'
    ]

    # Enhanced Feature Engineering (conditional)
    if use_enhanced_features:
        df_processed['violation_description_length'] = df_processed['violation_description'].apply(len)
        df_processed['violation_description_word_count'] = df_processed['violation_description'].apply(lambda x: len(str(x).split()))
        df_processed['street_name_desc_len_interaction'] = \
            df_processed['street_name'].astype(str) + '_' + df_processed['violation_description_length'].astype(str)
        df_processed['street_name_desc_len_interaction'] = df_processed['street_name_desc_len_interaction'].astype(str)
        
        features_to_use.extend([
            'violation_description_length',
            'violation_description_word_count',
            'street_name_desc_len_interaction'
        ])

    target = 'violation_count'

    X = df_processed[features_to_use]
    y = np.log1p(df_processed[target])

    # Identify categorical and text features for CatBoost Pool
    categorical_feature_names = []
    text_feature_names_for_pool = [] # Only for CatBoost's text_features parameter

    for col in features_to_use:
        if X[col].dtype == 'object':
            if col == 'violation_description' and use_catboost_text_features:
                text_feature_names_for_pool.append(col)
            else:
                categorical_feature_names.append(col)

    # Convert feature names to their indices in the 'features_to_use' list for CatBoost Pool
    feature_to_idx = {col: i for i, col in enumerate(features_to_use)}
    categorical_features_indices = [feature_to_idx[name] for name in categorical_feature_names]
    text_features_indices = [feature_to_idx[name] for name in text_feature_names_for_pool]

    # Split Training Data for Validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=random_seed_value)

    # Create CatBoost Pool objects
    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices, text_features=text_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices, text_features=text_features_indices)

    # Model Training
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.03,
        depth=9,
        l2_leaf_reg=3,
        eval_metric='RMSE',
        random_seed=random_seed_value,
        verbose=0,
        early_stopping_rounds=100,
        thread_count=-1
    )

    print(f"Training CatBoost model for {iteration_label}...")
    model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=100, verbose=False)

    # Validation
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log)
    val_predictions[val_predictions < 0] = 0

    rmse_val = np.sqrt(mean_squared_error(np.expm1(y_val), val_predictions))
    print(f"Validation RMSE for {iteration_label}: {rmse_val}")
    return rmse_val

def main():
    INPUT_DIR = './input'
    TRAIN_FILE = 'violations_per_street_2022.csv'

    # --- Load Training Data ---
    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)
    print(f"Loading training data from: {train_df_path}")
    train_df_original = load_data(train_df_path)

    if train_df_original is None or train_df_original.empty:
        print("Training data could not be loaded or is empty. Exiting.")
        return

    print(f"Original training data shape: {train_df_original.shape}")
    print("Training data columns:", train_df_original.columns.tolist())

    required_train_cols = ['street_name', 'violation_description', 'violation_count']
    if not all(col in train_df_original.columns for col in required_train_cols):
        print(f"Error: Training data missing one or more required columns: {required_train_cols}")
        print("Available columns:", train_df_original.columns.tolist())
        return

    results = {}

    # --- Baseline Run ---
    baseline_rmse = run_ablation_model(
        train_df_original,
        use_enhanced_features=True,
        use_catboost_text_features=True,
        random_seed_value=42,
        iteration_label="Baseline (Original Configuration)"
    )
    results["Baseline"] = baseline_rmse

    # --- Ablation 1: Remove Enhanced Features ---
    # Removes 'violation_description_length', 'violation_description_word_count', 'street_name_desc_len_interaction'
    # Multiple previous studies (2, 3, 8, 17) suggested these features might be detrimental.
    ablation1_rmse = run_ablation_model(
        train_df_original,
        use_enhanced_features=False,
        use_catboost_text_features=True,
        random_seed_value=42,
        iteration_label="Ablation 1: No Enhanced Features"
    )
    results["Ablation 1: No Enhanced Features"] = ablation1_rmse

    # --- Ablation 2: Disable CatBoost's explicit text feature processing ---
    # The current solution explicitly uses CatBoost's text feature handling; this has not been ablated.
    # Treats 'violation_description' as a plain categorical feature for CatBoost instead.
    ablation2_rmse = run_ablation_model(
        train_df_original,
        use_enhanced_features=True,
        use_catboost_text_features=False,
        random_seed_value=42,
        iteration_label="Ablation 2: No CatBoost Text Features"
    )
    results["Ablation 2: No CatBoost Text Features"] = ablation2_rmse

    # --- Ablation 3: Change Random Seed to 101 ---
    # Ablation study 9 indicated a significant performance improvement by changing random_seed from 42 to 101.
    ablation3_rmse = run_ablation_model(
        train_df_original,
        use_enhanced_features=True,
        use_catboost_text_features=True,
        random_seed_value=101,
        iteration_label="Ablation 3: Random Seed 101"
    )
    results["Ablation 3: Random Seed 101"] = ablation3_rmse

    print("\n--- Ablation Study Results Summary ---")
    for name, rmse in results.items():
        print(f"{name}: RMSE = {rmse:.4f}")

    print("\n--- Conclusion on Contribution ---")
    
    baseline_rmse_val = results["Baseline"]
    
    # Calculate impacts relative to baseline (positive impact_val means degradation, negative means improvement)
    impact_ab1 = ablation1_rmse - baseline_rmse_val # Change in RMSE from removing Enhanced Features
    impact_ab2 = ablation2_rmse - baseline_rmse_val # Change in RMSE from disabling CatBoost Text Features
    impact_ab3 = ablation3_rmse - baseline_rmse_val # Change in RMSE from random_seed 42 to 101

    max_abs_impact = 0
    most_impactful_description = ""

    # Evaluate Ablation 1: Enhanced Features
    abs_impact_ab1 = abs(impact_ab1)
    if abs_impact_ab1 > max_abs_impact:
        max_abs_impact = abs_impact_ab1
        if impact_ab1 < 0: # RMSE improved when removed, so original component was detrimental
            most_impactful_description = f"The 'Enhanced Features' (violation_description_length, violation_description_word_count, street_name_desc_len_interaction) contributed most negatively to the overall performance, as their removal improved RMSE by {-impact_ab1:.4f}."
        else: # RMSE degraded when removed, so original component was beneficial
            most_impactful_description = f"The 'Enhanced Features' (violation_description_length, violation_description_word_count, street_name_desc_len_interaction) contributed most positively to the overall performance, as their removal degraded RMSE by {impact_ab1:.4f}."

    # Evaluate Ablation 2: CatBoost Text Features
    abs_impact_ab2 = abs(impact_ab2)
    if abs_impact_ab2 > max_abs_impact:
        max_abs_impact = abs_impact_ab2
        if impact_ab2 < 0: # RMSE improved when disabled, so original component was detrimental
            most_impactful_description = f"The explicit use of CatBoost's Text Features for 'violation_description' contributed most negatively to the overall performance, as disabling it improved RMSE by {-impact_ab2:.4f}."
        else: # RMSE degraded when disabled, so original component was beneficial
            most_impactful_description = f"The explicit use of CatBoost's Text Features for 'violation_description' contributed most positively to the overall performance, as disabling it degraded RMSE by {impact_ab2:.4f}."

    # Evaluate Ablation 3: Random Seed 42 vs 101
    abs_impact_ab3 = abs(impact_ab3)
    if abs_impact_ab3 > max_abs_impact:
        max_abs_impact = abs_impact_ab3
        if impact_ab3 < 0: # RMSE improved with new seed, so original seed (42) was detrimental
            most_impactful_description = f"The 'random_seed=42' setting contributed most negatively to the overall performance, as changing it to 101 improved RMSE by {-impact_ab3:.4f}."
        else: # RMSE degraded with new seed, so original seed (42) was beneficial
            most_impactful_description = f"The 'random_seed=42' setting contributed most positively to the overall performance, as changing it to 101 degraded RMSE by {impact_ab3:.4f}."

    print(most_impactful_description)

if __name__ == "__main__":
    main()
