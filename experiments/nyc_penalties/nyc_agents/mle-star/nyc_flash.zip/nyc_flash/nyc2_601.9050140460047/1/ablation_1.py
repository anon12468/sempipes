
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return None
    except pd.errors.EmptyDataError:
        print(f"Warning: File is empty at {file_path}")
        return pd.DataFrame() # Return empty DataFrame to avoid further errors
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return None

def run_ablation_experiment(
    train_file_path,
    use_enhanced_features=True,
    catboost_iterations=1000,
    catboost_learning_rate=0.03,
    catboost_depth=8,
    apply_target_fillna_clip=True,
    experiment_name="Baseline"
):
    print(f"\n--- Running Experiment: {experiment_name} ---")

    # Load data
    train_df = load_data(train_file_path)

    if train_df is None or train_df.empty:
        print("Training data could not be loaded or is empty. Exiting experiment.")
        return None

    # Ensure required columns are present in the training data
    required_train_cols = ['street_name', 'violation_description', 'violation_count']
    if not all(col in train_df.columns for col in required_train_cols):
        print(f"Error: Training data missing one or more required columns: {required_train_cols}")
        print("Available columns:", train_df.columns.tolist())
        return None

    # Type conversion and NaN handling for categorical features
    train_df['street_name'] = train_df['street_name'].astype(str).fillna('UNKNOWN_STREET')
    train_df['violation_description'] = train_df['violation_description'].astype(str).fillna('UNKNOWN_VIOLATION')

    # Target variable handling
    target = 'violation_count'
    train_df[target] = pd.to_numeric(train_df[target], errors='coerce')
    
    if apply_target_fillna_clip:
        train_df[target] = train_df[target].fillna(0)
        train_df[target] = train_df[target].clip(lower=0)
    else:
        # If not applying fillna/clip, ensure we remove rows with NaNs in target
        initial_rows = len(train_df)
        train_df.dropna(subset=[target], inplace=True)
        rows_after_dropna = len(train_df)
        if initial_rows != rows_after_dropna:
            print(f"Warning: Target variable cleaning (fillna/clip) disabled. Removed {initial_rows - rows_after_dropna} rows due to NaN in target.")
        else:
            print("Target variable cleaning (fillna/clip) disabled. No NaNs found in target after coercion.")

    features = [
        'street_name',
        'violation_description',
    ]

    if use_enhanced_features:
        train_df['violation_description_length'] = train_df['violation_description'].apply(len)
        train_df['violation_description_word_count'] = train_df['violation_description'].apply(lambda x: len(str(x).split()))
        train_df['street_name_desc_len_interaction'] = \
            train_df['street_name'].astype(str) + '_' + train_df['violation_description_length'].astype(str)
        train_df['street_name_desc_len_interaction'] = train_df['street_name_desc_len_interaction'].astype(str)

        features.extend([
            'violation_description_length',
            'violation_description_word_count',
            'street_name_desc_len_interaction'
        ])

    X = train_df[features]
    y = train_df[target]

    # Identify categorical features by their column names
    categorical_features_indices = [i for i, col in enumerate(features) if X[col].dtype == 'object']

    # Split Training Data for Validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    # Create CatBoost Pool objects
    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices)

    # Model Training
    model = CatBoostRegressor(
        iterations=catboost_iterations,
        learning_rate=catboost_learning_rate,
        depth=catboost_depth,
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Suppress verbose output during training iterations
        early_stopping_rounds=100, # Use early stopping to prevent overfitting
        thread_count=-1, # Use all available threads
    )

    print("Training CatBoost model...")
    model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=100, verbose=False) # verbose=False for non-interactive output

    # Validation
    val_predictions = model.predict(X_val)
    # Ensure predictions are non-negative
    val_predictions[val_predictions < 0] = 0
    rmse_val = np.sqrt(mean_squared_error(y_val, val_predictions))
    print(f"{experiment_name} - Validation RMSE: {rmse_val:.4f}")
    return rmse_val

def main_ablation_study():
    INPUT_DIR = './input'
    TRAIN_FILE = 'violations_per_street_2022.csv'
    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)

    results = {}

    # --- Baseline (Current Solution) ---
    baseline_rmse = run_ablation_experiment(
        train_df_path,
        use_enhanced_features=True,
        catboost_iterations=1000,
        catboost_learning_rate=0.03,
        catboost_depth=8,
        apply_target_fillna_clip=True,
        experiment_name="Baseline (Current Solution)"
    )
    results["Baseline"] = baseline_rmse

    # --- Ablation 1: Remove Enhanced Feature Engineering ---
    # This disables 'violation_description_length', 'violation_description_word_count', 'street_name_desc_len_interaction'
    ablation1_rmse = run_ablation_experiment(
        train_df_path,
        use_enhanced_features=False, # Ablation
        catboost_iterations=1000,
        catboost_learning_rate=0.03,
        catboost_depth=8,
        apply_target_fillna_clip=True,
        experiment_name="Ablation 1: No Enhanced Features"
    )
    results["Ablation 1: No Enhanced Features"] = ablation1_rmse

    # --- Ablation 2: Revert CatBoost Hyperparameters (Depth, Learning Rate, Iterations) ---
    # Revert to more common defaults or less optimized values for CatBoost
    ablation2_rmse = run_ablation_experiment(
        train_df_path,
        use_enhanced_features=True,
        catboost_iterations=500, # Ablation
        catboost_learning_rate=0.1, # Ablation
        catboost_depth=6, # Ablation
        apply_target_fillna_clip=True,
        experiment_name="Ablation 2: Revert CatBoost Hyperparameters"
    )
    results["Ablation 2: Revert CatBoost Hyperparameters"] = ablation2_rmse

    # --- Ablation 3: Remove Target Variable Cleaning (fillna(0) and clip(lower=0)) ---
    ablation3_rmse = run_ablation_experiment(
        train_df_path,
        use_enhanced_features=True,
        catboost_iterations=1000,
        catboost_learning_rate=0.03,
        catboost_depth=8,
        apply_target_fillna_clip=False, # Ablation
        experiment_name="Ablation 3: No Target Fillna/Clip"
    )
    results["Ablation 3: No Target Fillna/Clip"] = ablation3_rmse


    print("\n--- Ablation Study Summary ---")
    for name, rmse in results.items():
        if rmse is not None:
            print(f"{name}: RMSE = {rmse:.4f}")
        else:
            print(f"{name}: Failed to run or returned no RMSE.")

    # Determine the most contributing part based on performance drop (RMSE increase)
    if baseline_rmse is not None:
        performance_impacts = {}
        if results["Ablation 1: No Enhanced Features"] is not None:
            performance_impacts["Enhanced Feature Engineering"] = results["Ablation 1: No Enhanced Features"] - baseline_rmse
        if results["Ablation 2: Revert CatBoost Hyperparameters"] is not None:
            performance_impacts["CatBoost Hyperparameters (Depth, LR, Iterations)"] = results["Ablation 2: Revert CatBoost Hyperparameters"] - baseline_rmse
        if results["Ablation 3: No Target Fillna/Clip"] is not None:
            performance_impacts["Target Variable Cleaning (fillna/clip)"] = results["Ablation 3: No Target Fillna/Clip"] - baseline_rmse

        if performance_impacts:
            # Filter for positive RMSE increases (performance degradation when removed/changed)
            degradations = {k: v for k, v in performance_impacts.items() if v > 0}
            if degradations:
                most_impactful_change = max(degradations, key=degradations.get)
                largest_drop_value = degradations[most_impactful_change]
                print(f"\nThe part of the code that contributes the most to the overall performance (indicated by the largest RMSE increase when removed/changed) is: {most_impactful_change} (RMSE increased by {largest_drop_value:.4f}).")
            else:
                print("\nNone of the ablated parts significantly degraded performance (or some improved it). Further analysis needed.")
        else:
            print("\nCould not determine the most contributing part due to missing or failed ablation results.")
    else:
        print("\nBaseline RMSE could not be determined. Cannot conclude most contributing part.")


if __name__ == "__main__":
    main_ablation_study()
