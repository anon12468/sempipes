
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return None
    except pd.errors.EmptyDataError:
        print(f"Warning: File is empty at {file_path}")
        return pd.DataFrame() # Return empty DataFrame to avoid further errors
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return None

def train_and_evaluate(X_train, y_train, X_val, y_val, features, categorical_features_indices, model_params):
    """Trains a CatBoostRegressor model and evaluates its RMSE on the validation set."""
    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices)

    model = CatBoostRegressor(**model_params)

    # verbose=False for non-interactive output as per task requirements
    model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=100, verbose=False)

    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log)
    val_predictions[val_predictions < 0] = 0

    rmse_val = np.sqrt(mean_squared_error(np.expm1(y_val), val_predictions))
    return rmse_val

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV relative to INPUT_DIR.')
    args = parser.parse_args()

    INPUT_DIR = './input'
    TRAIN_FILE = args.train_path

    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)
    train_df = load_data(train_df_path)

    if train_df is None or train_df.empty:
        print("Training data could not be loaded or is empty. Exiting.")
        return

    required_train_cols = ['street_name', 'violation_description', 'violation_count']
    if not all(col in train_df.columns for col in required_train_cols):
        print(f"Error: Training data missing one or more required columns: {required_train_cols}")
        print("Available columns:", train_df.columns.tolist())
        return

    # Feature Engineering and Augmentation
    train_df['street_name'] = train_df['street_name'].astype(str)
    train_df['violation_description'] = train_df['violation_description'].astype(str)
    train_df['street_name'] = train_df['street_name'].fillna('UNKNOWN_STREET')
    train_df['violation_description'] = train_df['violation_description'].fillna('UNKNOWN_VIOLATION')

    train_df['violation_count'] = pd.to_numeric(train_df['violation_count'], errors='coerce')
    train_df['violation_count'] = train_df['violation_count'].fillna(0)
    train_df['violation_count'] = train_df['violation_count'].clip(lower=0)

    train_df['violation_description_length'] = train_df['violation_description'].apply(len)
    train_df['violation_description_word_count'] = train_df['violation_description'].apply(lambda x: len(str(x).split()))
    train_df['street_name_desc_len_interaction'] = \
        train_df['street_name'].astype(str) + '_' + train_df['violation_description_length'].astype(str)
    train_df['street_name_desc_len_interaction'] = train_df['street_name_desc_len_interaction'].astype(str)

    base_features = [
        'street_name',
        'violation_description',
        'violation_description_length',
        'violation_description_word_count',
        'street_name_desc_len_interaction'
    ]
    target = 'violation_count'

    X = train_df[base_features]
    y = np.log1p(train_df[target])

    base_categorical_features_indices = [i for i, col in enumerate(base_features) if X[col].dtype == 'object']

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    # Define base model parameters
    base_model_params = {
        'iterations': 1000,
        'learning_rate': 0.03,
        'depth': 9,
        'l2_leaf_reg': 3,
        'eval_metric': 'RMSE',
        'random_seed': 42,
        'verbose': 0,
        'early_stopping_rounds': 100,
        'thread_count': -1,
    }

    # --- Baseline Performance ---
    baseline_rmse = train_and_evaluate(X_train, y_train, X_val, y_val, base_features, base_categorical_features_indices, base_model_params)
    print(f"Baseline RMSE: {baseline_rmse}")

    # --- Ablation 1: Change CatBoost grow_policy to 'Depthwise' ---
    # The default grow_policy when `depth` is specified is 'SymmetricTree'.
    abl1_model_params = base_model_params.copy()
    abl1_model_params['grow_policy'] = 'Depthwise'
    abl1_rmse = train_and_evaluate(X_train, y_train, X_val, y_val, base_features, base_categorical_features_indices, abl1_model_params)
    print(f"Ablation 1 (grow_policy='Depthwise') RMSE: {abl1_rmse}")

    # --- Ablation 2: Add CatBoost colsample_bylevel=0.8 ---
    # This parameter is not present in the current solution (default is 1.0).
    abl2_model_params = base_model_params.copy()
    abl2_model_params['colsample_bylevel'] = 0.8
    abl2_rmse = train_and_evaluate(X_train, y_train, X_val, y_val, base_features, base_categorical_features_indices, abl2_model_params)
    print(f"Ablation 2 (colsample_bylevel=0.8) RMSE: {abl2_rmse}")

    # --- Ablation 3: Remove 'violation_description_word_count' feature ---
    # This feature has shown mixed impact in previous studies, so re-evaluating its contribution.
    abl3_features = [f for f in base_features if f != 'violation_description_word_count']
    X_abl3 = train_df[abl3_features]
    abl3_categorical_features_indices = [i for i, col in enumerate(abl3_features) if X_abl3[col].dtype == 'object']
    
    # Re-split data to reflect the new feature set for ablation 3
    X_train_abl3, X_val_abl3, y_train_abl3, y_val_abl3 = train_test_split(X_abl3, y, test_size=0.2, random_state=42)

    abl3_rmse = train_and_evaluate(X_train_abl3, y_train_abl3, X_val_abl3, y_val_abl3, abl3_features, abl3_categorical_features_indices, base_model_params)
    print(f"Ablation 3 (no 'violation_description_word_count') RMSE: {abl3_rmse}")

    # --- Conclusion ---
    results_map = {
        "Baseline": baseline_rmse,
        "Ablation 1 (grow_policy='Depthwise')": abl1_rmse,
        "Ablation 2 (colsample_bylevel=0.8)": abl2_rmse,
        "Ablation 3 (no 'violation_description_word_count')": abl3_rmse
    }

    # Calculate impacts relative to baseline
    impacts = {
        "CatBoost grow_policy='Depthwise'": abl1_rmse - baseline_rmse,
        "CatBoost colsample_bylevel=0.8": abl2_rmse - baseline_rmse,
        "Removal of 'violation_description_word_count' feature": abl3_rmse - baseline_rmse
    }

    most_impactful_component = None
    max_abs_impact = 0.0

    for component, change in impacts.items():
        if abs(change) > max_abs_impact:
            max_abs_impact = abs(change)
            most_impactful_component = component
    
    if most_impactful_component is None or max_abs_impact == 0.0:
        print("No significant impact observed from any ablation.")
    else:
        impact_value = impacts[most_impactful_component]
        if impact_value < 0:
            print(f"The part of the code that contributed most to the overall performance is: {most_impactful_component} (improved RMSE by {-impact_value:.4f})")
        else: # impact_value > 0
            print(f"The part of the code that contributed most to the overall performance is: {most_impactful_component} (degraded RMSE by {impact_value:.4f})")

if __name__ == "__main__":
    main()
