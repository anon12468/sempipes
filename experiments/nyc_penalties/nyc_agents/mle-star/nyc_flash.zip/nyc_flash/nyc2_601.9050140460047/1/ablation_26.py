
import argparse
import pandas as pd
import numpy as np
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import mean_squared_error
import os

# --- Configuration ---
DEFAULT_TRAIN_PATH = "./input/violations_per_street_2022.csv"

# --- Helper Functions (copied from provided train.py) ---
def rmse(y_true, y_pred):
    """
    Calculates the Root Mean Squared Error (RMSE).
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def load_data(file_path):
    """
    Loads data from a CSV file, normalizes column names, and checks for required columns.
    Returns None if file not found or required columns are missing.
    """
    if not os.path.exists(file_path):
        print(f"Error: File not found at {file_path}")
        return None
    
    try:
        df = pd.read_csv(file_path)
    except Exception as e:
        print(f"Error reading CSV file {file_path}: {e}")
        return None
    
    # Normalize column names: strip spaces, replace spaces with underscores, lowercase
    df.columns = [col.strip().replace(' ', '_').lower() for col in df.columns]
    
    # Expected core schema columns after normalization
    required_cols = ['street_name', 'violation_description']
    
    # Check for presence of these columns
    if not all(col in df.columns for col in required_cols):
        missing_cols = [col for col in required_cols if col not in df.columns]
        print(f"Error: Required columns {missing_cols} not found in {file_path}.")
        print(f"Available columns: {df.columns.tolist()}")
        return None
            
    return df

def feature_engineer(df, is_train=True, encoders=None): 
    """
    Performs feature engineering including label encoding and basic text features.
    Handles unseen categories during transformation by assigning a new category ID.
    """
    if encoders is None:
        encoders = {
            'street_name': LabelEncoder(),
            'violation_description': LabelEncoder(),
        }
    
    # Handle NaN values for categorical features before encoding
    df['street_name'] = df['street_name'].fillna('UNKNOWN_STREET').astype(str)
    df['violation_description'] = df['violation_description'].fillna('UNKNOWN_VIOLATION').astype(str)

    encoded_features = []
    for col_name, encoder in encoders.items():
        if is_train:
            df[col_name + '_encoded'] = encoder.fit_transform(df[col_name])
        else:
            # For test data, map existing categories and assign a new ID for unseen ones
            mapping = {cls: i for i, cls in enumerate(encoder.classes_)}
            df[col_name + '_encoded'] = df[col_name].map(mapping).fillna(len(encoder.classes_)).astype(int)
        encoded_features.append(col_name + '_encoded')

    # Add simple numerical features derived from text data
    df['street_name_len'] = df['street_name'].apply(len)
    df['violation_desc_len'] = df['violation_description'].apply(len)
    df['violation_desc_word_count'] = df['violation_description'].apply(lambda x: len(str(x).split()))

    return df, encoders

# --- Main Experiment Runner ---
def run_experiment(train_df_raw, experiment_name,
                   use_log1p_target=False,
                   lgbm_objective='regression_l1',
                   lgbm_reg_lambda=None): # Use None to signify default
    
    print(f"\n--- Running Experiment: {experiment_name} ---")

    # --- Data Cleaning and Preprocessing (initial for training data) ---
    train_df_exp = train_df_raw.copy()
    train_df_exp['violation_count'] = pd.to_numeric(train_df_exp['violation_count'], errors='coerce')
    train_df_exp = train_df_exp.dropna(subset=['violation_count'])
    train_df_exp = train_df_exp[train_df_exp['violation_count'] >= 0]
    
    # --- Feature Engineering for Training Data ---
    train_df_exp, encoders = feature_engineer(train_df_exp.copy(), is_train=True)

    # --- Prepare for Training ---
    features = [col for col in train_df_exp.columns if col.endswith('_encoded') or col.endswith('_len') or col.endswith('_word_count')]
    target = 'violation_count'

    X = train_df_exp[features]
    y_original = train_df_exp[target] # Store original target for final RMSE calculation

    # Apply log1p transformation if enabled
    if use_log1p_target:
        y = np.log1p(y_original)
    else:
        y = y_original

    # --- Training/Validation Split ---
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # --- Model Training ---
    lgb_params = {
        'objective': lgbm_objective,
        'metric': 'rmse',             # Evaluation metric (always RMSE for comparison)
        'n_estimators': 1500,
        'learning_rate': 0.03,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }
    
    if lgbm_reg_lambda is not None:
        lgb_params['reg_lambda'] = lgbm_reg_lambda
    
    model = lgb.LGBMRegressor(**lgb_params)
    
    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              callbacks=[lgb.early_stopping(stopping_rounds=100, verbose=False)])

    # --- Evaluate on Validation Set ---
    val_predictions = model.predict(X_val)
    
    # Inverse transform if log1p was used
    if use_log1p_target:
        val_predictions = np.expm1(val_predictions)
        y_val_for_rmse = np.expm1(y_val) # Inverse transform true y_val for RMSE calculation
    else:
        y_val_for_rmse = y_val # y_val is already on original scale

    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    validation_rmse = rmse(y_val_for_rmse, val_predictions)
    print(f"Validation Performance ({experiment_name}): {validation_rmse}")
    return validation_rmse

def main():
    parser = argparse.ArgumentParser(description="Ablation study for NYC parking violations prediction.")
    parser.add_argument("--train-path", type=str, default=DEFAULT_TRAIN_PATH,
                        help="Path to the 2022 training data CSV.")

    args = parser.parse_args()

    # --- Load Training Data ---
    print(f"Loading training data from {args.train_path}...")
    train_df_raw = load_data(args.train_path)
    if train_df_raw is None:
        print("Failed to load training data. Exiting.")
        return 

    print(f"Training data loaded. Shape: {train_df_raw.shape}")

    results = {}

    # --- Baseline ---
    baseline_rmse = run_experiment(
        train_df_raw,
        experiment_name="Baseline (LGBM regression_l1, no log1p, default reg_lambda)"
    )
    results["Baseline"] = baseline_rmse

    # --- Ablation 1: Apply log1p transformation to target ---
    ablation1_rmse = run_experiment(
        train_df_raw,
        experiment_name="Ablation 1 (Apply log1p target transformation)",
        use_log1p_target=True
    )
    results["Ablation 1 (log1p target)"] = ablation1_rmse

    # --- Ablation 2: Change LGBM objective to regression_l2 ---
    # This also uses RMSE as metric for comparison, but the internal optimization objective changes
    ablation2_rmse = run_experiment(
        train_df_raw,
        experiment_name="Ablation 2 (LGBM objective: regression_l2)",
        lgbm_objective='regression_l2'
    )
    results["Ablation 2 (objective regression_l2)"] = ablation2_rmse

    # --- Ablation 3: Set LGBM reg_lambda (L2 regularization) to 1 (from default 0) ---
    # Default reg_lambda for LGBM is 0, so changing it to 1 tests the effect of adding L2 regularization
    ablation3_rmse = run_experiment(
        train_df_raw,
        experiment_name="Ablation 3 (LGBM reg_lambda=1)",
        lgbm_reg_lambda=1
    )
    results["Ablation 3 (reg_lambda=1)"] = ablation3_rmse

    # --- Conclusion ---
    print("\n--- Ablation Study Results ---")
    for name, rmse_val in results.items():
        print(f"{name}: RMSE = {rmse_val:.4f}")

    # Determine the part of the code that contributes the most to the overall performance.
    # This typically refers to the original component whose modification caused the largest degradation (increase in RMSE).
    baseline = results["Baseline"]
    
    largest_degradation = 0
    most_contributing_part = "The entire baseline configuration" # Default if no degradation is found

    for name, rmse_val in results.items():
        if name == "Baseline":
            continue
        
        degradation = rmse_val - baseline
        
        if degradation > largest_degradation:
            largest_degradation = degradation
            # Infer the original component that was modified
            if "log1p target transformation" in name:
                most_contributing_part = "the original direct target prediction (absence of log1p transformation)"
            elif "objective: regression_l2" in name:
                most_contributing_part = "the original LGBM objective 'regression_l1'"
            elif "reg_lambda=1" in name:
                most_contributing_part = "the original LGBM reg_lambda set to its default value (0)"

    print(f"\nThe part of the code that contributes the most to the overall performance is {most_contributing_part}.")
    if largest_degradation > 0:
        print(f"Its modification resulted in the largest degradation of RMSE by {largest_degradation:.4f}.")
    else:
        print("No single modification degraded performance more than keeping the baseline, implying the baseline is highly optimized for the tested components.")

if __name__ == "__main__":
    main()
