
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os
import glob # Used for potential future data discovery/loading if augmentation tables are added

# Ensure required libraries are installed
# You may need to run:
# pip install pandas numpy scikit-learn catboost

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame and standardizes column names."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names: lowercase, replace spaces with underscores
        df.columns = [col.replace(' ', '_').lower() for col in df.columns]
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return None
    except pd.errors.EmptyDataError:
        print(f"Warning: File is empty at {file_path}")
        return pd.DataFrame() # Return empty DataFrame to avoid further errors
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return None

def run_ablation_experiment(
    train_df,
    use_word_count_feature=True,
    use_grouped_interaction_feature=True,
    l2_reg_strength=3,
    verbose=False
):
    """
    Runs a single training and evaluation cycle with specified ablation parameters.
    Returns the validation RMSE.
    """
    df_copy = train_df.copy() # Work on a copy to avoid modifying original df across runs

    # --- Feature Engineering and Augmentation (as per plan_implement_agent_1) ---
    df_copy['street_name'] = df_copy['street_name'].astype(str)
    df_copy['violation_description'] = df_copy['violation_description'].astype(str)
    df_copy['street_name'] = df_copy['street_name'].fillna('UNKNOWN_STREET')
    df_copy['violation_description'] = df_copy['violation_description'].fillna('UNKNOWN_VIOLATION')

    # Ensure target variable is numeric and handle potential NaNs (e.g., fill with 0 or mean)
    df_copy['violation_count'] = pd.to_numeric(df_copy['violation_count'], errors='coerce')
    df_copy['violation_count'] = df_copy['violation_count'].fillna(0) # Fill NaNs in target with 0
    df_copy['violation_count'] = df_copy['violation_count'].clip(lower=0)

    # Extract numerical information from 'violation_description'
    # 'violation_description_length' was removed by plan_implement_agent_1, so not adding it here
    df_copy['violation_description_word_count'] = df_copy['violation_description'].apply(lambda x: len(str(x).split()))

    # Group infrequent violation descriptions into an 'Other' category
    description_counts = df_copy['violation_description'].value_counts()
    min_freq_threshold = 50 # Example threshold: descriptions occurring less than 50 times
    infrequent_descriptions = description_counts[description_counts < min_freq_threshold].index
    df_copy['violation_description_grouped'] = df_copy['violation_description'].replace(infrequent_descriptions, 'Other')
    df_copy['violation_description_grouped'] = df_copy['violation_description_grouped'].astype(str)

    # Create a novel interaction feature combining 'street_name' with the cardinality-reduced 'violation_description'
    df_copy['street_desc_grouped_interaction'] = \
        df_copy['street_name'].astype(str) + '_' + df_copy['violation_description_grouped'].astype(str)
    df_copy['street_desc_grouped_interaction'] = df_copy['street_desc_grouped_interaction'].astype(str)


    # --- Prepare Data for Model ---
    features = [
        'street_name',
        'violation_description_grouped',
    ]

    if use_word_count_feature:
        features.append('violation_description_word_count')
    if use_grouped_interaction_feature:
        features.append('street_desc_grouped_interaction')

    target = 'violation_count'

    X = df_copy[features]
    y = np.log1p(df_copy[target])

    # Identify categorical features by their column names
    categorical_features_indices = [i for i, col in enumerate(features) if X[col].dtype == 'object']

    # --- Split Training Data for Validation ---
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    # Create CatBoost Pool objects
    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices)

    # --- Model Training ---
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.03,
        depth=9,
        l2_leaf_reg=l2_reg_strength, # Ablation point
        eval_metric='RMSE',
        random_seed=42,
        verbose=0,
        early_stopping_rounds=100,
        thread_count=-1,
    )

    if verbose:
        print(f"Training CatBoost model with features: {features}, l2_leaf_reg: {l2_reg_strength}")
    model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=100, verbose=False)

    # --- Validation ---
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log)
    val_predictions[val_predictions < 0] = 0

    rmse_val = np.sqrt(mean_squared_error(np.expm1(y_val), val_predictions))
    return rmse_val

def main():
    INPUT_DIR = './input'
    TRAIN_FILE = 'violations_per_street_2022.csv' # Hardcoded for ablation study simplicity

    train_df_path = os.path.join(INPUT_DIR, TRAIN_FILE)
    print(f"Loading training data from: {train_df_path}")
    original_train_df = load_data(train_df_path)

    if original_train_df is None or original_train_df.empty:
        print("Training data could not be loaded or is empty. Exiting.")
        return

    print(f"Original training data shape: {original_train_df.shape}")
    print("Training data columns:", original_train_df.columns.tolist())

    required_train_cols = ['street_name', 'violation_description', 'violation_count']
    if not all(col in original_train_df.columns for col in required_train_cols):
        print(f"Error: Training data missing one or more required columns: {required_train_cols}")
        print("Available columns:", original_train_df.columns.tolist())
        return

    results = {}

    # --- Baseline ---
    print("\n--- Running Baseline Model ---")
    baseline_rmse = run_ablation_experiment(
        original_train_df,
        use_word_count_feature=True,
        use_grouped_interaction_feature=True,
        l2_reg_strength=3,
        verbose=True
    )
    results['Baseline'] = baseline_rmse
    print(f"Baseline Validation RMSE: {baseline_rmse:.4f}")

    # --- Ablation 1: Removing 'violation_description_word_count' feature ---
    print("\n--- Running Ablation 1: No 'violation_description_word_count' feature ---")
    ablation1_rmse = run_ablation_experiment(
        original_train_df,
        use_word_count_feature=False, # Ablation: Set to False to remove feature
        use_grouped_interaction_feature=True,
        l2_reg_strength=3,
        verbose=True
    )
    results['No violation_description_word_count'] = ablation1_rmse
    print(f"Ablation 1 (No 'violation_description_word_count') Validation RMSE: {ablation1_rmse:.4f}")
    print(f"Impact: {ablation1_rmse - baseline_rmse:.4f} (compared to baseline)")

    # --- Ablation 2: Removing 'street_desc_grouped_interaction' feature ---
    print("\n--- Running Ablation 2: No 'street_desc_grouped_interaction' feature ---")
    ablation2_rmse = run_ablation_experiment(
        original_train_df,
        use_word_count_feature=True,
        use_grouped_interaction_feature=False, # Ablation: Set to False to remove feature
        l2_reg_strength=3,
        verbose=True
    )
    results['No street_desc_grouped_interaction'] = ablation2_rmse
    print(f"Ablation 2 (No 'street_desc_grouped_interaction') Validation RMSE: {ablation2_rmse:.4f}")
    print(f"Impact: {ablation2_rmse - baseline_rmse:.4f} (compared to baseline)")

    # --- Ablation 3: Changing CatBoost l2_leaf_reg from 3 to 0 ---
    print("\n--- Running Ablation 3: CatBoost l2_leaf_reg = 0 ---")
    ablation3_rmse = run_ablation_experiment(
        original_train_df,
        use_word_count_feature=True,
        use_grouped_interaction_feature=True,
        l2_reg_strength=0, # Ablation: Change L2 regularization strength
        verbose=True
    )
    results['CatBoost l2_leaf_reg = 0'] = ablation3_rmse
    print(f"Ablation 3 (CatBoost l2_leaf_reg = 0) Validation RMSE: {ablation3_rmse:.4f}")
    print(f"Impact: {ablation3_rmse - baseline_rmse:.4f} (compared to baseline)")

    print("\n--- Ablation Study Conclusion ---")
    best_performance = min(results.values())
    
    impact_word_count = ablation1_rmse - baseline_rmse
    impact_grouped_interaction = ablation2_rmse - baseline_rmse
    impact_l2_reg = ablation3_rmse - baseline_rmse

    all_impacts = {
        "'violation_description_word_count' feature removal": impact_word_count,
        "'street_desc_grouped_interaction' feature removal": impact_grouped_interaction,
        "CatBoost 'l2_leaf_reg' changed to 0": impact_l2_reg,
    }

    if baseline_rmse == best_performance:
        most_beneficial_change_desc = "The baseline configuration achieved the best performance. No single ablation improved performance more."
        most_contributing_part = "The combination of all components in the baseline configuration."
    else:
        # Find the component whose modification (removal or change) led to the lowest RMSE (highest improvement)
        # Or, if all changes degraded, find the one that degraded the least.
        # Let's rephrase to find the "most impactful change" where impact is measured by absolute value
        # and then describe if it was an improvement or degradation.

        max_abs_impact_key = max(all_impacts, key=lambda k: abs(all_impacts[k]))
        max_abs_impact_value = all_impacts[max_abs_impact_key]

        if max_abs_impact_value < 0: # This change improved performance
            most_beneficial_change_desc = f"The most beneficial change was: {max_abs_impact_key}, leading to a significant improvement of {abs(max_abs_impact_value):.4f} RMSE."
            if "removal" in max_abs_impact_key:
                most_contributing_part = f"The *presence* of the feature implied by '{max_abs_impact_key}' was most detrimental, as its removal led to the greatest improvement."
            else: # e.g. l2_leaf_reg change
                most_contributing_part = f"The original setting for '{max_abs_impact_key.replace(' changed to 0', '')}' was most detrimental, as the change led to the greatest improvement."
        else: # This change degraded performance, meaning the original component was highly beneficial
            most_beneficial_change_desc = f"The component whose removal/modification led to the largest degradation was: {max_abs_impact_key}, resulting in a degradation of {max_abs_impact_value:.4f} RMSE. This indicates that the original state of this component was highly beneficial."
            if "removal" in max_abs_impact_key:
                most_contributing_part = f"The feature implied by '{max_abs_impact_key}' is most beneficial, as its removal led to the greatest degradation."
            else: # e.g. l2_leaf_reg change
                most_contributing_part = f"The original setting for '{max_abs_impact_key.replace(' changed to 0', '')}' is most beneficial, as its change led to the greatest degradation."

    print(most_beneficial_change_desc)
    print(f"Overall, the part of the code that contributes the most to the overall performance (either positively or negatively, relative to optimal performance) is: {most_contributing_part}")


if __name__ == "__main__":
    main()
