
#!/usr/bin/env python3
import argparse
import pandas as pd
import numpy as np
import os
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor

# Define global constants for column names
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
VIOLATION_COUNT_COL = 'violation_count'
PREDICTED_COUNT_COL = 'predicted_count'

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame."""
    try:
        df = pd.read_csv(file_path)
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return None
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return None

def feature_engineer(df, is_training=True):
    """
    Performs feature engineering on the DataFrame.
    Augments features from 'Street Name' and 'Violation Description'.
    """
    if df is None:
        return None

    df_copy = df.copy()

    # Create a composite key for (street_name, violation_type)
    df_copy['street_violation_key'] = df_copy[STREET_NAME_COL].fillna('UNKNOWN_STREET') + "_" + \
                                      df_copy[VIOLATION_DESC_COL].fillna('UNKNOWN_VIOLATION')

    # Basic features from 'Street Name'
    df_copy['street_name_len'] = df_copy[STREET_NAME_COL].fillna('').apply(len)
    df_copy['street_name_word_count'] = df_copy[STREET_NAME_COL].fillna('').apply(lambda x: len(x.split()))
    df_copy['is_avenue'] = df_copy[STREET_NAME_COL].fillna('').str.contains('AVE|AVENUE', case=False, na=False).astype(int)
    df_copy['is_street'] = df_copy[STREET_NAME_COL].fillna('').str.contains('ST|STREET', case=False, na=False).astype(int)
    df_copy['has_number_in_street'] = df_copy[STREET_NAME_COL].fillna('').str.contains(r'\d', na=False).astype(int)

    # Basic features from 'Violation Description'
    df_copy['violation_desc_len'] = df_copy[VIOLATION_DESC_COL].fillna('').apply(len)
    df_copy['violation_desc_word_count'] = df_copy[VIOLATION_DESC_COL].fillna('').apply(lambda x: len(x.split()))
    
    # Example of potential augmentation (if corresponding files exist and schema is known)
    # This is illustrative; actual augmentation would depend on specific file content.
    # For now, we'll keep it simple to avoid assumptions about auxiliary file schemas.
    # If other datasets were loaded, they would be merged here.
    
    # For demonstration, let's create a dummy 'borough' feature based on street name prefix
    # In a real scenario, this would come from a geospatial join or external data
    def assign_borough(street):
        street_lower = str(street).lower()
        if 'manhattan' in street_lower or 'm' in street_lower.split(): # Simplified for demo
            return 'Manhattan'
        elif 'brooklyn' in street_lower or 'bk' in street_lower.split():
            return 'Brooklyn'
        elif 'queens' in street_lower or 'qns' in street_lower.split():
            return 'Queens'
        elif 'bronx' in street_lower or 'bx' in street_lower.split():
            return 'Bronx'
        elif 'staten' in street_lower or 'si' in street_lower.split():
            return 'Staten Island'
        return 'Unknown'
    
    df_copy['borough_guess'] = df_copy[STREET_NAME_COL].apply(assign_borough)

    return df_copy

def run_pipeline():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument("--train-path", type=str, default="/Users/USER/Documents/UNI/SS26/nyc_open_data/train/all_data/violations_per_street_2022.csv",
                        help="Path to the training data CSV file (default: violations_per_street_2022.csv).")
    parser.add_argument("--test-path", type=str, default="/Users/USER/Documents/UNI/SS26/nyc_open_data/violations_per_street_2023.csv",
                        help="Optional path to the test data CSV file for predictions.")
    args = parser.parse_args()

    # Ensure the input directory exists
    input_dir = "/Users/USER/Documents/UNI/SS26/nyc_open_data/train/all_data/"
    if not os.path.exists(input_dir):
        print(f"Error: Input directory '{input_dir}' not found.")
        return

    train_file_path = os.path.join(input_dir, args.train_path)
    train_df = load_data(train_file_path)
    if train_df is None:
        return

    # Feature Engineering for training data
    train_df_fe = feature_engineer(train_df.copy())
    if train_df_fe is None:
        return

    # Target transformation (log1p to handle skewed counts)
    train_df_fe[VIOLATION_COUNT_COL] = np.log1p(train_df_fe[VIOLATION_COUNT_COL])

    # Define features and target
    features = [
        STREET_NAME_COL, VIOLATION_DESC_COL,
        'street_name_len', 'street_name_word_count', 'is_avenue', 'is_street', 'has_number_in_street',
        'violation_desc_len', 'violation_desc_word_count', 'borough_guess'
    ]
    categorical_features = [
        STREET_NAME_COL, VIOLATION_DESC_COL, 'borough_guess'
    ]
    target = VIOLATION_COUNT_COL

    # Split 2022 data into training and validation sets
    X_train, X_val, y_train, y_val = train_test_split(
        train_df_fe[features], train_df_fe[target],
        test_size=0.2, random_state=42, shuffle=True
    )

    print(f"Training data shape: {X_train.shape}")
    print(f"Validation data shape: {X_val.shape}")

    # CatBoost Regressor Model
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=8,
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0,
        early_stopping_rounds=50,
        cat_features=[f for f in categorical_features if f in X_train.columns] # Ensure features exist
    )

    print("Training CatBoost model...")
    model.fit(X_train, y_train, eval_set=(X_val, y_val), early_stopping_rounds=50)

    # Validate model
    val_preds_log = model.predict(X_val)
    val_preds = np.expm1(val_preds_log)
    val_preds[val_preds < 0] = 0 # Clip negative predictions

    validation_rmse = np.sqrt(mean_squared_error(np.expm1(y_val), val_preds))
    print(f"Development Validation RMSE: {validation_rmse:.4f}")

    # Prepare for submission or test evaluation
    submission_df_rows = []
    
    # Keep track of unique keys in training data for unseen pair reporting
    train_keys = set(train_df_fe['street_violation_key'].unique())

    if args.test_path:
        test_file_path = os.path.join(input_dir, args.test_path)
        if not os.path.exists(test_file_path):
            print(f"Warning: Test file not found at {test_file_path}. Skipping test predictions.")
        else:
            test_df = load_data(test_file_path)
            if test_df is None:
                return

            test_df_fe = feature_engineer(test_df.copy(), is_training=False)
            if test_df_fe is None:
                return
            
            # Identify unseen key pairs
            test_keys = set(test_df_fe['street_violation_key'].unique())
            unseen_keys_count = len(test_keys - train_keys)
            print(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_keys_count}")


            # Predict on test data
            test_preds_log = model.predict(test_df_fe[features])
            test_preds = np.expm1(test_preds_log)
            test_preds[test_preds < 0] = 0 # Clip negative predictions

            # Create submission dataframe
            submission_df = pd.DataFrame({
                STREET_NAME_COL: test_df_fe[STREET_NAME_COL],
                VIOLATION_DESC_COL: test_df_fe[VIOLATION_DESC_COL],
                PREDICTED_COUNT_COL: test_preds.round().astype(int) # Round to nearest integer as counts
            })
            
            # If test_df contains 'violation_count', calculate and report RMSE
            if VIOLATION_COUNT_COL in test_df.columns:
                actual_counts = test_df[VIOLATION_COUNT_COL]
                test_rmse = np.sqrt(mean_squared_error(actual_counts, submission_df[PREDICTED_COUNT_COL]))
                print(f"Test Set RMSE: {test_rmse:.4f}")
            
            submission_df.to_csv("submission.csv", index=False)
            print("Predictions saved to submission.csv")
    else:
        print("No test-path provided. Skipping test predictions.")

    print(f"Final Validation Performance: {validation_rmse}")


if __name__ == "__main__":
    run_pipeline()

