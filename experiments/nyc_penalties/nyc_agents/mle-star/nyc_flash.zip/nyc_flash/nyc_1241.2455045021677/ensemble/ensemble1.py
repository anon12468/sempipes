
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GroupKFold
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import os
import lightgbm as lgb
import gc

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv'

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Performs feature engineering on the input DataFrame.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Handle missing values
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Label Encoding for categorical features
    categorical_cols = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col].astype(str)) # Fit on string type
                encoder_dict[col] = le
            else:
                if col in encoder_dict:
                    # Use transform for existing categories, map unknown to -1
                    # Ensure all values are strings before calling transform or mapping
                    df[col + '_encoded'] = df[col].astype(str).map(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else -1)
                else:
                    # Assign a default for entirely new categories if no encoder or if encoder not found for this column
                    df[col + '_encoded'] = -1 

    # Log transform target if present, good for count data
    if TARGET_COLUMN in df.columns and is_training:
        df[TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series) -> lgb.Booster:
    """
    Trains a LightGBM model.
    """
    # LightGBM expects feature names as strings and sanitized names
    original_train_cols = X_train.columns.copy() # Keep a copy for categorical feature mapping
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    # Identify categorical features based on the plan
    categorical_features_names = []
    if 'street_name_encoded' in original_train_cols: # Check against original names before sanitizing
        categorical_features_names.append("street_name_encoded")
    if 'violation_description_encoded' in original_train_cols:
        categorical_features_names.append("violation_description_encoded")

    # Sanitize categorical feature names as well for LightGBM
    categorical_features_names = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in categorical_features_names]

    # LightGBM parameters
    params = {
        'objective': 'poisson',
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 63,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)],
              categorical_feature=categorical_features_names)

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional: Path to the 2023 test/evaluation data CSV.')
    args = parser.parse_args()

    print(f"Loading training data from: {args.train_path}")
    # encoder_dict will be fit on the entire 2022 dataset to ensure consistent encoding across folds and test set
    df_2022_raw, encoder_dict = load_and_preprocess_data(args.train_path, is_training=True)

    # Prepare data for K-fold
    df_2022_raw['group_id'] = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]
    
    # Define features once based on the full preprocessed training data
    features = [col for col in df_2022_raw.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower(), 'group_id']]
    
    X = df_2022_raw[features]
    y = df_2022_raw[TARGET_COLUMN]
    groups = df_2022_raw['group_id']

    # Initialize lists to store fold results
    oof_rmse_scores = []
    test_predictions_folds_log = [] # Store log predictions for each fold
    
    # Initialize GroupKFold
    N_SPLITS = 5 # Using 5 folds as a standard choice for cross-validation
    gkf = GroupKFold(n_splits=N_SPLITS)

    print(f"Starting {N_SPLITS}-fold Grouped Cross-Validation...")

    X_test = None # Initialize X_test outside the loop
    df_test_raw = None # Initialize df_test_raw outside the loop

    for fold, (train_idx, val_idx) in enumerate(gkf.split(X, y, groups=groups)):
        print(f"--- Fold {fold+1}/{N_SPLITS} ---")
        X_train_fold, X_val_fold = X.iloc[train_idx].copy(), X.iloc[val_idx].copy() # Use .copy() to avoid SettingWithCopyWarning
        y_train_fold, y_val_fold = y.iloc[train_idx].copy(), y.iloc[val_idx].copy()

        print("Training model for current fold...")
        model_fold = train_model(X_train_fold, y_train_fold, X_val_fold, y_val_fold)

        # Predict on validation set of current fold for OOF RMSE calculation
        val_predictions_log_fold = model_fold.predict(X_val_fold)
        val_predictions_fold = np.expm1(val_predictions_log_fold) # Inverse transform
        val_predictions_fold[val_predictions_fold < 0] = 0 # Clip negative predictions

        # Calculate RMSE for current fold
        rmse_fold = calculate_rmse(np.expm1(y_val_fold), val_predictions_fold) # Calculate RMSE on original scale
        oof_rmse_scores.append(rmse_fold)
        print(f"Fold {fold+1} Validation RMSE: {rmse_fold}")

        # If a test path is provided, generate predictions for the actual test set
        if args.test_path:
            if fold == 0: # Load and preprocess test data only once before the first fold
                print(f"Loading test data from: {args.test_path}")
                df_test_raw, _ = load_and_preprocess_data(args.test_path, is_training=False, encoder_dict=encoder_dict)

                # Ensure test data has the same features as training data X
                test_features_present = [col for col in features if col in df_test_raw.columns]
                X_test = df_test_raw[test_features_present].copy()

                # Align columns: add missing cols with 0, remove extra cols
                missing_cols = set(X.columns) - set(X_test.columns)
                for c in missing_cols:
                    X_test[c] = 0
                extra_cols = set(X_test.columns) - set(X.columns)
                X_test = X_test.drop(columns=list(extra_cols))
                X_test = X_test[X.columns] # Ensure column order is the same as the full training set X

                # Sanitize test set column names, similar to how train_model does it for X_train/X_val
                X_test.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_test.columns]
            
            print(f"Generating test predictions for Fold {fold+1}...")
            test_predictions_log_fold = model_fold.predict(X_test)
            test_predictions_folds_log.append(test_predictions_log_fold)

    print("\n--- Cross-Validation Complete ---")
    print(f"OOF RMSE Scores per fold: {oof_rmse_scores}")
    
    # Calculate overall validation performance (average RMSE of folds)
    avg_oof_rmse = np.mean(oof_rmse_scores)
    print(f"Final Validation Performance: {avg_oof_rmse}")

    # Process test predictions with weighted averaging based on ensemble plan
    if args.test_path:
        print("Applying weighted average to test predictions based on ensemble plan...")
        
        # Calculate weights based on OOF RMSE scores (inverse of square of RMSE)
        weights = 1 / (np.array(oof_rmse_scores)**2)
        weights /= weights.sum() # Normalize weights so they sum to 1
        print(f"Normalized Fold weights: {weights}")

        # Compute the final test predictions by taking the weighted sum of log predictions from each fold
        final_test_predictions_log = np.average(test_predictions_folds_log, axis=0, weights=weights)

        # Inverse transform, clip, and round predictions
        final_test_predictions = np.expm1(final_test_predictions_log)
        final_test_predictions[final_test_predictions < 0] = 0 # Clip negative predictions
        final_test_predictions = np.round(final_test_predictions).astype(int) # Round to nearest integer

        # Create submission file
        submission_df = pd.DataFrame({
            STREET_NAME_COL: df_test_raw[STREET_NAME_COL.replace(' ', '_').lower()],
            VIOLATION_DESC_COL: df_test_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()],
            PREDICTED_COUNT_COL: final_test_predictions
        })
        # Restore original column names for submission file
        submission_df.columns = [STREET_NAME_COL, VIOLATION_DESC_COL, PREDICTED_COUNT_COL]

        submission_df.to_csv(OUTPUT_SUBMISSION_FILE, index=False)
        print(f"Submission file '{OUTPUT_SUBMISSION_FILE}' created successfully.")

        # If test_path contains 'violation_count', calculate RMSE for the final ensemble prediction
        if TARGET_COLUMN in df_test_raw.columns:
            y_test_true = np.expm1(df_test_raw[TARGET_COLUMN]) # Inverse log transform for actual values
            test_rmse = calculate_rmse(y_test_true, final_test_predictions)
            print(f"RMSE on provided test/evaluation data (final ensemble): {test_rmse}")

            # Report unseen key pairs for context
            train_keys = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]
            test_keys = df_test_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + df_test_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

            unseen_keys_count = test_keys.isin(train_keys).value_counts().get(False, 0)
            total_test_keys = len(test_keys)
            print(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {unseen_keys_count} out of {total_test_keys}")
            print("Unseen pairs are handled by the model's ability to generalize based on encoded features and numerical interaction features, "
                  "and by assigning -1 for unknown categories during Label Encoding transform.")

    gc.collect()

if __name__ == "__main__":
    main()
