
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import GroupKFold
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc
import os

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv'

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Performs feature engineering on the input DataFrame.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Handle missing values
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Label Encoding for categorical features
    categorical_cols = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col] = le
            else:
                if col in encoder_dict:
                    # Use transform for existing categories, map unknown to -1
                    # Ensure all values in the column are strings before mapping/transforming
                    df[col] = df[col].astype(str)
                    df[col + '_encoded'] = df[col].map(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else -1)
                else:
                    df[col + '_encoded'] = -1 # Assign a default for entirely new categories if no encoder

    # Log transform target if present, good for count data
    if TARGET_COLUMN in df.columns and is_training:
        df[TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series) -> lgb.Booster:
    """
    Trains a LightGBM model.
    """
    # LightGBM expects feature names as strings and sanitized names
    original_train_cols = X_train.columns.tolist() # Keep original column names for categorical feature identification
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    # Identify categorical features based on the plan
    categorical_features_names = []
    if 'street_name_encoded' in original_train_cols:
        categorical_features_names.append("street_name_encoded")
    if 'violation_description_encoded' in original_train_cols:
        categorical_features_names.append("violation_description_encoded")

    # LightGBM parameters
    params = {
        'objective': 'poisson',
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 63,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)],
              categorical_feature=categorical_features_names)

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional: Path to the 2023 test/evaluation data CSV.')
    args = parser.parse_args()

    # --- Step 1: Modify main() for K-Fold Setup ---

    print(f"Loading training data from: {args.train_path}")
    df_2022_raw, encoder_dict = load_and_preprocess_data(args.train_path, is_training=True)

    # Create a unique identifier for grouped splitting
    df_2022_raw['group_id'] = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

    # Define features and target
    features = [col for col in df_2022_raw.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower(), 'group_id']]

    # Load and preprocess test data once if provided
    df_test_raw = None
    X_test = None
    if args.test_path:
        print(f"Loading test data from: {args.test_path}")
        df_test_raw, _ = load_and_preprocess_data(args.test_path, is_training=False, encoder_dict=encoder_dict)

        # Prepare X_test: ensure it has the same features and column order as training data
        test_features_present = [col for col in features if col in df_test_raw.columns]
        X_test = df_test_raw[test_features_present]

        # Align columns for X_test - crucial for consistent predictions
        missing_cols = set(features) - set(X_test.columns)
        for c in missing_cols:
            X_test[c] = 0 # Add missing columns with a default value (0)
        extra_cols = set(X_test.columns) - set(features)
        X_test = X_test.drop(columns=list(extra_cols))
        X_test = X_test[features] # Ensure column order is the same as training features

    # Initialize lists for K-fold
    test_predictions_folds = []
    oof_rmse_scores = [] # To store RMSE for each fold's validation set

    gkf = GroupKFold(n_splits=5) # 5-fold cross-validation

    print("Starting K-Fold Cross-Validation...")
    # --- Step 2: K-Fold Training Loop ---
    for fold, (train_idx, val_idx) in enumerate(gkf.split(df_2022_raw, groups=df_2022_raw['group_id'])):
        print(f"--- Fold {fold + 1}/{gkf.n_splits} ---")

        df_train_fold = df_2022_raw.iloc[train_idx].copy()
        df_val_fold = df_2022_raw.iloc[val_idx].copy()

        # Extract features and target for the current fold
        X_train_fold = df_train_fold[features]
        y_train_fold = df_train_fold[TARGET_COLUMN]
        X_val_fold = df_val_fold[features]
        y_val_fold = df_val_fold[TARGET_COLUMN]

        print(f"Training model for Fold {fold + 1}...")
        model_fold = train_model(X_train_fold, y_train_fold, X_val_fold, y_val_fold)

        # Make predictions on the validation set of the current fold
        val_predictions_log = model_fold.predict(X_val_fold)
        val_predictions = np.expm1(val_predictions_log)
        val_predictions[val_predictions < 0] = 0

        fold_rmse = calculate_rmse(np.expm1(y_val_fold), val_predictions)
        oof_rmse_scores.append(fold_rmse)
        print(f"Fold {fold + 1} Validation RMSE: {fold_rmse}")

        # Predict on the preprocessed test set using the current fold's model
        if X_test is not None:
            print(f"Generating test predictions for Fold {fold + 1}...")
            # Ensure X_test columns are sanitized to match model's expected input
            X_test_sanitized = X_test.copy()
            X_test_sanitized.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_test_sanitized.columns]
            fold_test_predictions_log = model_fold.predict(X_test_sanitized)
            test_predictions_folds.append(fold_test_predictions_log)
        
        gc.collect()

    # Calculate and print the overall validation performance (average OOF RMSE)
    final_validation_rmse = np.mean(oof_rmse_scores)
    print(f"\nFinal Validation Performance: {final_validation_rmse}")

    # --- Step 3: Aggregate Test Predictions ---
    if X_test is not None:
        print("\nAggregating test predictions...")
        final_test_predictions_log = np.mean(test_predictions_folds, axis=0)
        final_test_predictions = np.expm1(final_test_predictions_log)
        final_test_predictions[final_test_predictions < 0] = 0
        final_test_predictions = np.round(final_test_predictions).astype(int)

        # --- Step 4: Generate Submission ---
        submission_df = pd.DataFrame({
            STREET_NAME_COL: df_test_raw[STREET_NAME_COL.replace(' ', '_').lower()],
            VIOLATION_DESC_COL: df_test_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()],
            PREDICTED_COUNT_COL: final_test_predictions
        })
        # Original column names for submission
        submission_df.columns = [STREET_NAME_COL, VIOLATION_DESC_COL, PREDICTED_COUNT_COL]

        submission_df.to_csv(OUTPUT_SUBMISSION_FILE, index=False)
        print(f"Submission file '{OUTPUT_SUBMISSION_FILE}' created successfully.")

        # If test_path contains 'violation_count', calculate RMSE
        if TARGET_COLUMN in df_test_raw.columns:
            y_test_true = np.expm1(df_test_raw[TARGET_COLUMN]) # Inverse log transform for actual values
            test_rmse = calculate_rmse(y_test_true, final_test_predictions)
            print(f"RMSE on provided test/evaluation data: {test_rmse}")

            # Report unseen key pairs
            train_keys = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]
            test_keys = df_test_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + df_test_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

            unseen_keys_count = (~test_keys.isin(train_keys)).sum() # Corrected count for unseen
            total_test_keys = len(test_keys)
            print(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {unseen_keys_count} out of {total_test_keys}")
            print("Unseen pairs are handled by the model's ability to generalize based on encoded features and numerical interaction features, "
                  "and by assigning -1 for unknown categories during Label Encoding transform.")
    else:
        print("No test path provided. Skipping final prediction generation.")

    gc.collect()

if __name__ == "__main__":
    main()
