
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, KFold
from sklearn.metrics import mean_squared_error
import lightgbm as lgb
import gc
import os

# Define constants for ORIGINAL column names from the dataset schema
ORIGINAL_TARGET_COLUMN = 'violation_count'
ORIGINAL_STREET_NAME_COL = 'Street Name'
ORIGINAL_VIOLATION_DESC_COL = 'Violation Description'

# Output file constants
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv'

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> (pd.DataFrame, dict):
    """
    Performs feature engineering on the input DataFrame, including Target Encoding.
    Standardizes column names to lowercase with underscores.
    """
    if encoder_dict is None:
        encoder_dict = {}

    # Standardize ALL column names in the DataFrame
    df.columns = df.columns.str.replace(' ', '_').str.lower()

    # Get standardized names for the key columns for internal use
    standardized_target_col = ORIGINAL_TARGET_COLUMN.replace(' ', '_').lower()
    standardized_street_name_col = ORIGINAL_STREET_NAME_COL.replace(' ', '_').lower()
    standardized_violation_desc_col = ORIGINAL_VIOLATION_DESC_COL.replace(' ', '_').lower()
    
    categorical_cols_for_target_encoding = [standardized_street_name_col, standardized_violation_desc_col]
    
    # Handle missing values for target-encoded categorical features
    for col in categorical_cols_for_target_encoding:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # --- Target Encoding Preprocessing (Log Transform Target) ---
    if is_training:
        if standardized_target_col in df.columns:
            # Store global mean of log1p transformed target for handling unseen categories during inference
            df[standardized_target_col] = np.log1p(df[standardized_target_col])
            encoder_dict['global_target_mean_log1p'] = df[standardized_target_col].mean()
        else:
            print(f"Warning: Target column '{standardized_target_col}' not found during training. "
                  "Target encoding will use a default of 0 if target means cannot be computed.")
            encoder_dict['global_target_mean_log1p'] = 0.0 # Fallback for inference if target missing

    # --- Target Encoding ---
    for col in categorical_cols_for_target_encoding:
        if col in df.columns:
            encoded_col_name = col + '_target_encoded'
            if is_training:
                if standardized_target_col in df.columns:
                    # Out-of-fold encoding to prevent data leakage
                    kf = KFold(n_splits=5, shuffle=True, random_state=42)
                    oof_encodings = np.zeros(df.shape[0])
                    
                    for fold, (train_idx, val_idx) in enumerate(kf.split(df)):
                        df_train_fold, df_val_fold = df.iloc[train_idx], df.iloc[val_idx]
                        
                        # Calculate mean target for each category in the training fold
                        fold_target_map = df_train_fold.groupby(col)[standardized_target_col].mean()
                        
                        # Apply to validation fold, filling unseen categories with the global mean
                        # (from the entire training set's transformed target)
                        oof_encodings[val_idx] = df_val_fold[col].map(fold_target_map).fillna(
                            encoder_dict['global_target_mean_log1p']
                        ).values

                    df[encoded_col_name] = oof_encodings

                    # Store the overall target map for inference (calculated on full training data)
                    full_target_map = df.groupby(col)[standardized_target_col].mean().to_dict()
                    encoder_dict[col + '_target_map'] = full_target_map
                else:
                    # If target column is missing, assign a default of 0.0
                    df[encoded_col_name] = 0.0
            else: # Inference
                if col + '_target_map' in encoder_dict:
                    # Use stored map for inference
                    # Fill unseen categories with the global target mean from training
                    default_value = encoder_dict.get('global_target_mean_log1p', 0.0)
                    df[encoded_col_name] = df[col].map(encoder_dict[col + '_target_map']).fillna(default_value)
                else:
                    # Assign a default for entirely new categories if no encoder map is found
                    df[encoded_col_name] = 0.0

    # --- Interaction feature (using the newly created target-encoded features) ---
    if (standardized_street_name_col + '_target_encoded' in df.columns) and \
       (standardized_violation_desc_col + '_target_encoded' in df.columns):
        df['street_violation_interaction'] = (
            df[standardized_street_name_col + '_target_encoded'] * 
            df[standardized_violation_desc_col + '_target_encoded']
        )

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None) -> (pd.DataFrame, dict):
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    # The _engineer_features function performs column name standardization internally
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series) -> lgb.Booster:
    """
    Trains a LightGBM model.
    """
    # LightGBM expects feature names as strings and can have issues with special characters.
    # Standardize column names for LightGBM.
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'regression_l1',  # MAE objective, generally robust to outliers in count data
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 31,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)]) # Use callbacks for early stopping

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional: Path to the 2023 test/evaluation data CSV.')
    args = parser.parse_args()

    print(f"Loading training data from: {args.train_path}")
    df_2022_raw, encoder_dict = load_and_preprocess_data(args.train_path, is_training=True)

    # Get standardized names for the key columns for internal use, after _engineer_features has run
    standardized_target_col = ORIGINAL_TARGET_COLUMN.replace(' ', '_').lower()
    standardized_street_name_col = ORIGINAL_STREET_NAME_COL.replace(' ', '_').lower()
    standardized_violation_desc_col = ORIGINAL_VIOLATION_DESC_COL.replace(' ', '_').lower()

    # Split 2022 data for training and validation
    # Use grouped holdout for (street_name, violation_type) pairs
    # Create a unique identifier for splitting
    df_2022_raw['group_id'] = df_2022_raw[standardized_street_name_col] + '_' + \
                               df_2022_raw[standardized_violation_desc_col]

    # Get unique groups
    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    # Drop the temporary group_id
    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    # Define features and target
    features = [col for col in df_train_raw.columns if col not in [standardized_target_col, standardized_street_name_col, standardized_violation_desc_col]]

    # Prepare training data
    X_train = df_train_raw[features]
    y_train = df_train_raw[standardized_target_col]

    # Prepare validation data
    X_val = df_val_raw[features]
    y_val = df_val_raw[standardized_target_col]

    print("Training model...")
    model = train_model(X_train, y_train, X_val, y_val)

    # Predict on validation set for performance reporting
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log) # Inverse transform from log1p
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions to 0

    final_validation_rmse = calculate_rmse(np.expm1(y_val), val_predictions) # Calculate RMSE on original scale
    print(f"Final Validation Performance: {final_validation_rmse}")

    # If a test path is provided, generate predictions
    if args.test_path:
        print(f"Loading test data from: {args.test_path}")
        df_test_raw, _ = load_and_preprocess_data(args.test_path, is_training=False, encoder_dict=encoder_dict)

        # Ensure test data has the same features as training data
        test_features = [col for col in features if col in df_test_raw.columns]
        X_test = df_test_raw[test_features]

        # Align columns - crucial for consistent predictions
        # Add missing columns to X_test with 0, remove extra columns
        missing_cols = set(X_train.columns) - set(X_test.columns)
        for c in missing_cols:
            X_test[c] = 0
        extra_cols = set(X_test.columns) - set(X_train.columns)
        X_test = X_test.drop(columns=list(extra_cols), axis=1) # Explicitly specify axis for safety
        X_test = X_test[X_train.columns] # Ensure column order is the same as training data

        print("Generating predictions for test data...")
        test_predictions_log = model.predict(X_test)
        test_predictions = np.expm1(test_predictions_log) # Inverse transform from log1p
        test_predictions[test_predictions < 0] = 0 # Clip negative predictions
        test_predictions = np.round(test_predictions).astype(int) # Round to nearest integer

        # Create submission file using ORIGINAL column names for output headers
        submission_df = pd.DataFrame({
            ORIGINAL_STREET_NAME_COL: df_test_raw[standardized_street_name_col],
            ORIGINAL_VIOLATION_DESC_COL: df_test_raw[standardized_violation_desc_col],
            PREDICTED_COUNT_COL: test_predictions
        })
        
        submission_df.to_csv(OUTPUT_SUBMISSION_FILE, index=False)
        print(f"Submission file '{OUTPUT_SUBMISSION_FILE}' created successfully.")

        # If test_path contains 'violation_count', calculate RMSE
        if standardized_target_col in df_test_raw.columns:
            y_test_true = np.expm1(df_test_raw[standardized_target_col]) # Inverse log transform for actual values
            test_rmse = calculate_rmse(y_test_true, test_predictions)
            print(f"RMSE on provided test/evaluation data: {test_rmse}")

            # Report unseen key pairs
            train_keys = df_2022_raw[standardized_street_name_col] + '_' + df_2022_raw[standardized_violation_desc_col]
            test_keys = df_test_raw[standardized_street_name_col] + '_' + df_test_raw[standardized_violation_desc_col]

            unseen_keys_count = (~test_keys.isin(train_keys)).sum() # Count keys in test_keys not present in train_keys
            total_test_keys = len(test_keys)
            print(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {unseen_keys_count} out of {total_test_keys}")
            print("Unseen pairs are handled by the model's ability to generalize based on encoded features and numerical interaction features, "
                  "and by assigning a global mean during target encoding for unseen categories.")

    gc.collect()

if __name__ == "__main__":
    main()
