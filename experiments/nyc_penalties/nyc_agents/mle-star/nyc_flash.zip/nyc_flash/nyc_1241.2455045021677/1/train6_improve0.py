
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import lightgbm as lgb
import gc
import warnings

# Suppress specific LightGBM warnings
warnings.filterwarnings("ignore", category=UserWarning, module="lightgbm")

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv'

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Performs feature engineering on the input DataFrame.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Standardized column names for convenience
    street_col_std = STREET_NAME_COL.replace(' ', '_').lower()
    violation_col_std = VIOLATION_DESC_COL.replace(' ', '_').lower()

    # Handle missing values
    for col in [street_col_std, violation_col_std]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Frequency Encoding for categorical features (replacing Label Encoding)
    categorical_cols_to_encode = [street_col_std, violation_col_std]
    for col in categorical_cols_to_encode:
        if col in df.columns:
            encoded_col_name = col + '_freq_encoded'
            encoder_key = col + '_freq_map'

            if is_training:
                # Calculate frequencies and store map in encoder_dict
                freq_map = df[col].value_counts(normalize=True).to_dict()
                encoder_dict[encoder_key] = freq_map
                df[encoded_col_name] = df[col].map(freq_map)
            else:
                # Use stored frequencies, handle unseen categories by mapping them to 0
                if encoder_key in encoder_dict:
                    freq_map = encoder_dict[encoder_key]
                    df[encoded_col_name] = df[col].map(freq_map).fillna(0.0) # Fill unseen with 0.0
                else:
                    df[encoded_col_name] = 0.0 # Assign 0.0 if no frequency map was trained

    # Retain and enhance interaction features using frequency encoded values
    street_encoded_col_name = street_col_std + '_freq_encoded'
    violation_encoded_col_name = violation_col_std + '_freq_encoded'

    if (street_encoded_col_name in df.columns) and \
       (violation_encoded_col_name in df.columns):
        # Retain the proven beneficial interaction (now using frequency encoded values)
        df['street_violation_interaction'] = df[street_encoded_col_name] * df[violation_encoded_col_name]

        # Add more diverse interaction features
        df['street_violation_interaction_sum'] = df[street_encoded_col_name] + df[violation_encoded_col_name]
        df['street_violation_interaction_diff'] = df[street_encoded_col_name] - df[violation_encoded_col_name]
        # Potentially more interaction types like mean, min, max, etc. could be added here

    # Log transform of the target variable was removed from here.
    # The model now trains on the original scale of 'violation_count'.

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series) -> lgb.Booster:
    """
    Trains a LightGBM model.
    """
    # LightGBM expects feature names as strings
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'regression_l1',  # MAE objective, suitable for counts, robust to outliers
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 31,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)]) # Use callbacks for early stopping

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional: Path to the 2023 test/evaluation data CSV.')
    args = parser.parse_args()

    print(f"Loading training data from: {args.train_path}")
    df_2022_raw, encoder_dict = load_and_preprocess_data(args.train_path, is_training=True)

    # Split 2022 data for training and validation
    # Use grouped holdout for (street_name, violation_type) pairs
    # Create a unique identifier for splitting
    df_2022_raw['group_id'] = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

    # Get unique groups
    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    # Drop the temporary group_id
    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])

    # Define features and target
    # Ensure target column is included if it exists in the raw data after feature engineering
    # But it must not be used as a feature itself.
    features = [col for col in df_train_raw.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower(), 'group_id']]
    # Filter out columns that might not exist in the dataframe or were created temporarily
    features = [f for f in features if f in df_train_raw.columns]

    # Prepare training data
    X_train = df_train_raw[features]
    y_train = df_train_raw[TARGET_COLUMN]

    # Prepare validation data
    X_val = df_val_raw[features]
    y_val = df_val_raw[TARGET_COLUMN]

    print("Training model...")
    model = train_model(X_train, y_train, X_val, y_val)

    # Predict on validation set for performance reporting
    val_predictions = model.predict(X_val)
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    # Calculate RMSE on original scale, as log transform was removed
    final_validation_rmse = calculate_rmse(y_val, val_predictions)
    print(f"Final Validation Performance: {final_validation_rmse}")

    # If a test path is provided, generate predictions
    if args.test_path:
        print(f"Loading test data from: {args.test_path}")
        df_test_raw, _ = load_and_preprocess_data(args.test_path, is_training=False, encoder_dict=encoder_dict)

        # Ensure test data has the same features as training data
        test_features = [col for col in features if col in df_test_raw.columns]
        X_test = df_test_raw[test_features]

        # Align columns - crucial for consistent predictions
        # Add missing columns to X_test with 0, remove extra columns
        missing_cols = set(X_train.columns) - set(X_test.columns)
        for c in missing_cols:
            X_test[c] = 0
        extra_cols = set(X_test.columns) - set(X_train.columns)
        X_test = X_test.drop(columns=list(extra_cols))
        X_test = X_test[X_train.columns] # Ensure column order is the same

        # Ensure column names are in the format expected by LightGBM
        X_test.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_test.columns]

        print("Generating predictions for test data...")
        test_predictions = model.predict(X_test)
        test_predictions[test_predictions < 0] = 0 # Clip negative predictions
        test_predictions = np.round(test_predictions).astype(int) # Round to nearest integer

        # Create submission file
        submission_df = pd.DataFrame({
            STREET_NAME_COL: df_test_raw[STREET_NAME_COL.replace(' ', '_').lower()],
            VIOLATION_DESC_COL: df_test_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()],
            PREDICTED_COUNT_COL: test_predictions
        })
        # Original column names for submission
        submission_df.columns = [STREET_NAME_COL, VIOLATION_DESC_COL, PREDICTED_COUNT_COL]

        submission_df.to_csv(OUTPUT_SUBMISSION_FILE, index=False)
        print(f"Submission file '{OUTPUT_SUBMISSION_FILE}' created successfully.")

        # If test_path contains 'violation_count', calculate RMSE
        if TARGET_COLUMN in df_test_raw.columns:
            # y_test_true is already on the original scale
            y_test_true = df_test_raw[TARGET_COLUMN]
            test_rmse = calculate_rmse(y_test_true, test_predictions)
            print(f"RMSE on provided test/evaluation data: {test_rmse}")

            # Report unseen key pairs
            train_keys = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]
            test_keys = df_test_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + df_test_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

            # Handle cases where test_keys might be different in length or composition
            unseen_keys = test_keys[~test_keys.isin(train_keys)]
            unseen_keys_count = len(unseen_keys)
            total_test_keys = len(test_keys)
            print(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {unseen_keys_count} out of {total_test_keys}")
            print("Unseen pairs are handled by mapping unseen categorical feature frequencies to 0, allowing the model to generalize based on other features.")

    gc.collect()

if __name__ == "__main__":
    main()
