
import pandas as pd
import numpy as np
import lightgbm as lgb
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import argparse
import os
import logging
import warnings

# Suppress specific LightGBM warnings or all warnings
warnings.filterwarnings('ignore', category=UserWarning, module='lightgbm')
warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore') # General warning suppression

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Helper functions ---
def calculate_rmse(y_true, y_pred):
    """Calculates the Root Mean Squared Error."""
    return np.sqrt(mean_squared_error(y_true, y_pred))

# --- Main script ---
def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Optional path to the 2023 test/evaluation data CSV.")
    parser.add_argument("--n-splits", type=int, default=5,
                        help="Number of folds for KFold cross-validation.")
    parser.add_argument("--random-state", type=int, default=42,
                        help="Random state for reproducibility.")
    args = parser.parse_args()

    logging.info(f"Starting prediction pipeline with train_path: {args.train_path}")

    # --- Load Training Data ---
    try:
        train_df = pd.read_csv(args.train_path)
        # Clean column names: strip whitespace, replace spaces with underscores
        train_df.columns = [col.strip().replace(' ', '_') for col in train_df.columns]
        logging.info(f"Loaded training data with {len(train_df)} rows.")
        logging.debug(f"Training data columns: {train_df.columns.tolist()}")
    except FileNotFoundError:
        logging.error(f"Training data not found at {args.train_path}. Please check the path.")
        return
    except Exception as e:
        logging.error(f"Error loading training data: {e}")
        return

    # Rename columns to a consistent snake_case format as per schema description
    train_df = train_df.rename(columns={
        'Street_Name': 'street_name',
        'Violation_Description': 'violation_type',
        'violation_count': 'violation_count' # Ensure this matches if it was already lowercase
    })

    # Ensure consistent data types
    train_df['street_name'] = train_df['street_name'].astype(str)
    train_df['violation_type'] = train_df['violation_type'].astype(str)
    train_df['violation_count'] = train_df['violation_count'].astype(float) # Target for regression

    # --- Feature Engineering for Training Data ---
    logging.info("Starting feature engineering for training data.")

    # Frequency Encoding based on training data
    street_freq_map = train_df['street_name'].value_counts().to_dict()
    violation_freq_map = train_df['violation_type'].value_counts().to_dict()
    
    # Pair frequency map - important for unseen pairs in test
    street_violation_pair_freq_map = train_df.groupby(['street_name', 'violation_type']).size().to_dict()

    train_df['street_name_freq'] = train_df['street_name'].map(street_freq_map)
    train_df['violation_type_freq'] = train_df['violation_type'].map(violation_freq_map)
    train_df['street_violation_pair_freq'] = train_df.apply(lambda row: street_violation_pair_freq_map.get((row['street_name'], row['violation_type']), 0), axis=1)


    # Label Encoding (for street_name and violation_type)
    # Encoders are fitted on training data and reused for test data.
    street_encoder = LabelEncoder()
    train_df['street_name_encoded'] = street_encoder.fit_transform(train_df['street_name'])

    violation_encoder = LabelEncoder()
    train_df['violation_type_encoded'] = violation_encoder.fit_transform(train_df['violation_type'])

    # --- Augmentation (Data Discovery Placeholder) ---
    # In a real scenario, you would list files in './input', check their schemas,
    # and merge relevant information (e.g., street characteristics, violation details).
    # For this task, we proceed with features derived from the main training data.
    input_dir = os.path.dirname(args.train_path) if os.path.dirname(args.train_path) else './input'
    if os.path.exists(input_dir) and os.path.isdir(input_dir):
        logging.info(f"Checking for additional data in {input_dir}")
        for filename in os.listdir(input_dir):
            if filename.endswith(".csv") and filename != os.path.basename(args.train_path):
                logging.debug(f"Found potential augmentation file: {filename}. (Not used in this baseline script)")
                # Example of how you might load and merge:
                # try:
                #     aug_df = pd.read_csv(os.path.join(input_dir, filename))
                #     # ... preprocess and merge aug_df with train_df ...
                # except Exception as e:
                #     logging.warning(f"Could not load or process {filename}: {e}")

    features = [
        'street_name_encoded', 'violation_type_encoded',
        'street_name_freq', 'violation_type_freq', 'street_violation_pair_freq'
        # Add features from augmentation tables here after merging
    ]
    target = 'violation_count'

    # Filter out rows where target is NaN (should not happen with `violation_count` from original)
    train_df = train_df.dropna(subset=[target])
    logging.info(f"Training data after feature engineering and dropping NaNs: {len(train_df)} rows.")

    X = train_df[features]
    y = train_df[target]

    # --- Model Training (LightGBM) ---
    logging.info("Starting model training using KFold cross-validation.")
    kf = KFold(n_splits=args.n_splits, shuffle=True, random_state=args.random_state)
    oof_preds = np.zeros(len(train_df))
    models = []
    fold_rmses = []

    for fold, (train_idx, val_idx) in enumerate(kf.split(X, y)):
        X_train, X_val = X.iloc[train_idx], X.iloc[val_idx]
        y_train, y_val = y.iloc[train_idx], y.iloc[val_idx]

        # Define LightGBM parameters
        lgb_params = {
            'objective': 'regression_l1', # Mean Absolute Error (less sensitive to outliers)
            'metric': 'rmse',             # Evaluation metric
            'n_estimators': 1500,         # Increased estimators for better performance
            'learning_rate': 0.03,        # Slightly reduced learning rate
            'feature_fraction': 0.8,
            'bagging_fraction': 0.8,
            'bagging_freq': 1,
            'lambda_l1': 0.1,             # L1 regularization
            'lambda_l2': 0.1,             # L2 regularization
            'num_leaves': 31,
            'verbose': -1,                # Suppress verbose output
            'n_jobs': -1,                 # Use all available cores
            'seed': args.random_state + fold, # Different seed for each fold
            'boosting_type': 'gbdt',
        }

        model = lgb.LGBMRegressor(**lgb_params)
        model.fit(X_train, y_train,
                  eval_set=[(X_val, y_val)],
                  eval_metric='rmse',
                  callbacks=[lgb.early_stopping(100, verbose=False)]) # Early stopping

        val_preds = model.predict(X_val)
        val_preds[val_preds < 0] = 0 # Clip negative predictions to zero
        oof_preds[val_idx] = val_preds
        fold_rmse = calculate_rmse(y_val, val_preds)
        fold_rmses.append(fold_rmse)
        logging.info(f"Fold {fold+1} - Validation RMSE: {fold_rmse:.4f}")
        models.append(model) # Store model for later prediction

    overall_oof_rmse = calculate_rmse(y, oof_preds)
    logging.info(f"Final Validation Performance: {overall_oof_rmse}") # REQUIRED OUTPUT

    # --- Prediction for Test Data (if provided) ---
    if args.test_path:
        logging.info(f"Loading test data from {args.test_path}")
        try:
            test_df = pd.read_csv(args.test_path)
            test_df.columns = [col.strip().replace(' ', '_') for col in test_df.columns]
            logging.info(f"Loaded test data with {len(test_df)} rows.")
            logging.debug(f"Test data columns: {test_df.columns.tolist()}")
        except FileNotFoundError:
            logging.error(f"Test data not found at {args.test_path}. Skipping prediction.")
            return
        except Exception as e:
            logging.error(f"Error loading test data: {e}. Skipping prediction.")
            return

        # Rename columns for consistency
        test_df = test_df.rename(columns={
            'Street_Name': 'street_name',
            'Violation_Description': 'violation_type',
            'violation_count': 'violation_count' # Keep if present for scoring, but not for features
        })

        test_df['street_name'] = test_df['street_name'].astype(str)
        test_df['violation_type'] = test_df['violation_type'].astype(str)

        # Store original street_name and violation_type for submission output
        submission_df = test_df[['street_name', 'violation_type']].copy()

        # --- Feature Engineering for Test Data ---
        logging.info("Starting feature engineering for test data using training data maps.")

        # Frequency Encoding for Test Data (use maps from training data, fill unseen with 0)
        test_df['street_name_freq'] = test_df['street_name'].map(street_freq_map).fillna(0)
        test_df['violation_type_freq'] = test_df['violation_type'].map(violation_freq_map).fillna(0)
        test_df['street_violation_pair_freq'] = test_df.apply(lambda row: street_violation_pair_freq_map.get((row['street_name'], row['violation_type']), 0), axis=1)

        # Label Encoding for Test Data (using encoders fitted on training data)
        def safe_transform_label_encoder(encoder, series):
            """Transforms series using fitted encoder, mapping unseen values to -1."""
            mapping = {label: idx for idx, label in enumerate(encoder.classes_)}
            return series.map(mapping).fillna(-1).astype(int)

        test_df['street_name_encoded'] = safe_transform_label_encoder(street_encoder, test_df['street_name'])
        test_df['violation_type_encoded'] = safe_transform_label_encoder(violation_encoder, test_df['violation_type'])

        # Identify unseen key pairs for reporting
        train_key_pairs = set(zip(train_df['street_name'], train_df['violation_type']))
        test_key_pairs = set(zip(test_df['street_name'], test_df['violation_type']))
        unseen_in_test_count = len(test_key_pairs - train_key_pairs)
        logging.info(f"Number of (street_name, violation_type) pairs in test set unseen in training: {unseen_in_test_count}")

        # Predict using all trained models (ensemble averaging)
        test_predictions = np.zeros(len(test_df))
        for model in models:
            preds = model.predict(test_df[features])
            test_predictions += preds / len(models)

        test_predictions[test_predictions < 0] = 0 # Clip any negative predictions to zero

        submission_df['predicted_count'] = test_predictions
        # Round to nearest integer and cast, as counts are typically integers
        submission_df['predicted_count'] = submission_df['predicted_count'].round().astype(int)

        # Save submission file
        submission_output_path = 'submission.csv'
        submission_df.to_csv(submission_output_path, index=False)
        logging.info(f"Predictions saved to {submission_output_path}")

        # If test_df has actual violation_count, calculate and report RMSE
        if 'violation_count' in test_df.columns and test_df['violation_count'].notna().any():
            true_counts = test_df['violation_count'].values
            # Filter out NaN values from true_counts if any, for RMSE calculation
            valid_indices = ~np.isnan(true_counts)
            if valid_indices.any():
                test_rmse = calculate_rmse(true_counts[valid_indices], test_predictions[valid_indices])
                logging.info(f"RMSE on provided test set (where ground truth is available): {test_rmse:.4f}")
            else:
                logging.warning("Test set 'violation_count' column found but contains no valid numbers for RMSE calculation.")
        else:
            logging.info("Test set does not contain 'vi_count' for scoring. Generated pure predictions.")

if __name__ == "__main__":
    main()
