
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import catboost as cb
import os
import lightgbm as lgb
import gc

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv'

import pandas as pd
import numpy as np

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Performs feature engineering on the input DataFrame, introducing Leave-One-Out (LOO) Target Encoding
    and statistical text features.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Standardize column names from global constants to match DataFrame columns
    _STREET_NAME_COL = STREET_NAME_COL.replace(' ', '_').lower()
    _VIOLATION_DESC_COL = VIOLATION_DESC_COL.replace(' ', '_').lower()
    _TARGET_COLUMN_STANDARDIZED = TARGET_COLUMN.replace(' ', '_').lower() if TARGET_COLUMN else None

    # Handle missing values for categorical features before engineering
    for col in [_STREET_NAME_COL, _VIOLATION_DESC_COL]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)
    
    # Leave-One-Out (LOO) Target Encoding for specified categorical features
    # This replaces the original simple Label Encoding for these columns.
    loo_categorical_cols = [_STREET_NAME_COL, _VIOLATION_DESC_COL]
    LOO_SMOOTHING = 50.0 # Smoothing parameter for robust generalization
    LOO_ENCODED_SUFFIX = "_loo_encoded"

    if is_training and (_TARGET_COLUMN_STANDARDIZED not in df.columns or df[_TARGET_COLUMN_STANDARDIZED].isnull().all()):
        raise ValueError(f"Target column '{_TARGET_COLUMN_STANDARDIZED}' is required and must contain non-null values for LOO Target Encoding during training.")

    for col in loo_categorical_cols:
        if col in df.columns:
            encoded_col_name = col + LOO_ENCODED_SUFFIX

            if is_training:
                global_mean = df[_TARGET_COLUMN_STANDARDIZED].mean()

                # Calculate per-row category statistics using transform
                category_mean_per_row = df.groupby(col)[_TARGET_COLUMN_STANDARDIZED].transform('mean')
                category_count_per_row = df.groupby(col)[_TARGET_COLUMN_STANDARDIZED].transform('count')

                # Calculate the raw Leave-One-Out value for each row:
                # (sum of targets for category - current target) / (count for category - 1)
                # which simplifies to (category_mean * category_count - current_target) / (category_count - 1)
                loo_raw_value = (category_mean_per_row * category_count_per_row - df[_TARGET_COLUMN_STANDARDIZED]) / \
                                (category_count_per_row - 1)

                # Apply smoothing to the LOO values.
                # The smoothed value is a weighted average of the LOO estimate and the global mean:
                # (LOO_estimate * (count-1) + global_mean * smoothing) / (count-1 + smoothing)
                df[encoded_col_name] = ((category_count_per_row - 1) * loo_raw_value + LOO_SMOOTHING * global_mean) / \
                                       (category_count_per_row - 1 + LOO_SMOOTHING)

                # Fill NaNs for categories with count <= 1 (where count-1 was 0 or negative).
                # These should be filled with the global mean, as no reliable LOO estimate can be made.
                df[encoded_col_name] = df[encoded_col_name].fillna(global_mean)

                # Store the mapping for inference. This mapping uses the full training data
                # to calculate smoothed target means per category, which is applied consistently to all instances
                # of a category in the test set.
                # Formula: (sum_target_for_category + smoothing * global_mean) / (count_for_category + smoothing)
                agg_stats = df.groupby(col)[_TARGET_COLUMN_STANDARDIZED].agg(
                    sum_target='sum',
                    count='count'
                )
                smoothed_mapping_for_inference = (agg_stats['sum_target'] + LOO_SMOOTHING * global_mean) / \
                                                 (agg_stats['count'] + LOO_SMOOTHING)
                
                encoder_dict[col] = {
                    'mapping': smoothed_mapping_for_inference.to_dict(),
                    'global_mean': global_mean
                }
            else: # is_training is False (inference phase)
                if col in encoder_dict:
                    mapping = encoder_dict[col]['mapping']
                    global_mean = encoder_dict[col]['global_mean']
                    # Use stored mapping and fill unseen categories with the global mean from training.
                    df[encoded_col_name] = df[col].map(mapping).fillna(global_mean)
                else:
                    # If no encoder is found for the column during inference,
                    # assign a default (e.g., 0.0) or handle as an error.
                    # Using 0.0 as a safe default if no training information exists.
                    # In a real scenario, this might indicate an issue with encoder persistence or missing columns.
                    df[encoded_col_name] = 0.0

    # Extract simple statistical text features from violation_description
    if _VIOLATION_DESC_COL in df.columns:
        # Ensure column is string type, handling potential NaNs by filling with empty string
        df[_VIOLATION_DESC_COL] = df[_VIOLATION_DESC_COL].fillna('').astype(str)
        df['violation_desc_length'] = df[_VIOLATION_DESC_COL].apply(len)
        df['violation_desc_word_count'] = df[_VIOLATION_DESC_COL].apply(lambda x: len(x.split()))

    # Example: Simple interaction feature using the new LOO encoded columns
    street_loo_col = _STREET_NAME_COL + LOO_ENCODED_SUFFIX
    violation_loo_col = _VIOLATION_DESC_COL + LOO_ENCODED_SUFFIX
    if (street_loo_col in df.columns) and (violation_loo_col in df.columns):
        df['street_violation_interaction_loo'] = df[street_loo_col] * df[violation_loo_col]

    # Log transform target if present and training, typically done as a last step for target manipulation
    if _TARGET_COLUMN_STANDARDIZED in df.columns and is_training:
        df[_TARGET_COLUMN_STANDARDIZED] = np.log1p(df[_TARGET_COLUMN_STANDARDIZED])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series) -> lgb.Booster:
    """
    Trains a LightGBM model.
    """
    # LightGBM expects feature names as strings
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'regression_l1',  # MAE objective
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 31,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)]) # Use callbacks for early stopping

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional: Path to the 2023 test/evaluation data CSV.')
    args = parser.parse_args()

    print(f"Loading training data from: {args.train_path}")
    df_2022_raw, encoder_dict = load_and_preprocess_data(args.train_path, is_training=True)

    # Split 2022 data for training and validation
    # Use grouped holdout for (street_name, violation_type) pairs
    # Create a unique identifier for splitting
    df_2022_raw['group_id'] = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

    # Get unique groups
    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    # Drop the temporary group_id
    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    # Define features and target
    features = [col for col in df_train_raw.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]]

    # Prepare training data
    X_train = df_train_raw[features]
    y_train = df_train_raw[TARGET_COLUMN]

    # Prepare validation data - CRITICAL FIX HERE: Extract y_val *before* any potential dropping or mismatch
    X_val = df_val_raw[features]
    y_val = df_val_raw[TARGET_COLUMN] # This ensures y_val is correctly assigned from the raw df_val_raw

    print("Training model...")
    model = train_model(X_train, y_train, X_val, y_val)

    # Predict on validation set for performance reporting
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log) # Inverse transform
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(np.expm1(y_val), val_predictions) # Calculate RMSE on original scale
    print(f"Final Validation Performance: {final_validation_rmse}")

    # If a test path is provided, generate predictions
    if args.test_path:
        print(f"Loading test data from: {args.test_path}")
        df_test_raw, _ = load_and_preprocess_data(args.test_path, is_training=False, encoder_dict=encoder_dict)

        # Ensure test data has the same features as training data
        test_features = [col for col in features if col in df_test_raw.columns]
        X_test = df_test_raw[test_features]

        # Align columns - crucial for consistent predictions
        # Add missing columns to X_test with 0, remove extra columns
        missing_cols = set(X_train.columns) - set(X_test.columns)
        for c in missing_cols:
            X_test[c] = 0
        extra_cols = set(X_test.columns) - set(X_train.columns)
        X_test = X_test.drop(columns=list(extra_cols))
        X_test = X_test[X_train.columns] # Ensure column order is the same

        print("Generating predictions for test data...")
        test_predictions_log = model.predict(X_test)
        test_predictions = np.expm1(test_predictions_log) # Inverse transform
        test_predictions[test_predictions < 0] = 0 # Clip negative predictions
        test_predictions = np.round(test_predictions).astype(int) # Round to nearest integer

        # Create submission file
        submission_df = pd.DataFrame({
            STREET_NAME_COL: df_test_raw[STREET_NAME_COL.replace(' ', '_').lower()],
            VIOLATION_DESC_COL: df_test_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()],
            PREDICTED_COUNT_COL: test_predictions
        })
        # Original column names for submission
        submission_df.columns = [STREET_NAME_COL, VIOLATION_DESC_COL, PREDICTED_COUNT_COL]

        submission_df.to_csv(OUTPUT_SUBMISSION_FILE, index=False)
        print(f"Submission file '{OUTPUT_SUBMISSION_FILE}' created successfully.")

        # If test_path contains 'violation_count', calculate RMSE
        if TARGET_COLUMN in df_test_raw.columns:
            y_test_true = np.expm1(df_test_raw[TARGET_COLUMN]) # Inverse log transform for actual values
            test_rmse = calculate_rmse(y_test_true, test_predictions)
            print(f"RMSE on provided test/evaluation data: {test_rmse}")

            # Report unseen key pairs
            train_keys = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]
            test_keys = df_test_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + df_test_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

            unseen_keys_count = test_keys.isin(train_keys).value_counts().get(False, 0)
            total_test_keys = len(test_keys)
            print(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {unseen_keys_count} out of {total_test_keys}")
            print("Unseen pairs are handled by the model's ability to generalize based on encoded features and numerical interaction features, "
                  "and by assigning -1 for unknown categories during Label Encoding transform.")

    gc.collect()

if __name__ == "__main__":
    main()
