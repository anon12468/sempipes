
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc
import copy

# Define constants - replicated from the original script
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv' # Not used in ablation, but kept for completeness

# --- Baseline _engineer_features function (with Label Encoding) ---
def _engineer_features_baseline(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> (pd.DataFrame, dict):
    """
    Performs feature engineering on the input DataFrame using Label Encoding.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Handle missing values
    _street_name_col_processed = STREET_NAME_COL.replace(' ', '_').lower()
    _violation_desc_col_processed = VIOLATION_DESC_COL.replace(' ', '_').lower()

    for col in [_street_name_col_processed, _violation_desc_col_processed]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Label Encoding for categorical features
    categorical_cols = [_street_name_col_processed, _violation_desc_col_processed]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col] = le
            else:
                if col in encoder_dict:
                    # Use transform for existing categories, map unknown to -1
                    df[col + '_encoded'] = df[col].map(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else -1)
                else:
                    df[col + '_encoded'] = -1 # Assign a default for entirely new categories if no encoder

    # Log transform target if present, good for count data
    _target_column = TARGET_COLUMN.replace(' ', '_').lower()
    if _target_column in df.columns and is_training:
        df[_target_column] = np.log1p(df[_target_column])

    return df, encoder_dict

# --- Ablation 1 _engineer_features function (with Frequency Encoding) ---
def _engineer_features_fe(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> (pd.DataFrame, dict):
    """
    Performs feature engineering on the input DataFrame using Frequency Encoding.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    _street_name_col_processed = STREET_NAME_COL.replace(' ', '_').lower()
    _violation_desc_col_processed = VIOLATION_DESC_COL.replace(' ', '_').lower()

    for col in [_street_name_col_processed, _violation_desc_col_processed]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Frequency Encoding for categorical features
    fe_cols = [_street_name_col_processed, _violation_desc_col_processed]
    for col in fe_cols:
        if col in df.columns:
            if is_training:
                # Calculate frequencies on the training data
                frequency_map = df[col].value_counts(normalize=True).to_dict()
                df[col + '_frequency_encoded'] = df[col].map(frequency_map).fillna(0) # fillna(0) for safety
                encoder_dict[col] = frequency_map
            else:
                if col in encoder_dict:
                    df[col + '_frequency_encoded'] = df[col].map(encoder_dict[col]).fillna(0)
                else:
                    df[col + '_frequency_encoded'] = 0 # Default for entirely new categories

    _target_column = TARGET_COLUMN.replace(' ', '_').lower()
    if _target_column in df.columns and is_training:
        df[_target_column] = np.log1p(df[_target_column])

    return df, encoder_dict


def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None, feature_engineering_fn=None) -> pd.DataFrame:
    """
    Loads data from a CSV file and applies initial preprocessing using a specified FE function.
    """
    if feature_engineering_fn is None:
        feature_engineering_fn = _engineer_features_baseline # Default to baseline if not specified

    df = pd.read_csv(file_path)
    df, encoder_dict = feature_engineering_fn(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series, params_override: dict = None, categorical_features_names: list = None) -> lgb.Booster:
    """
    Trains a LightGBM model with optional parameter overrides.
    """
    # LightGBM expects feature names as strings and sanitized names
    X_train_sanitized = X_train.copy()
    X_val_sanitized = X_val.copy()
    
    X_train_sanitized.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val_sanitized.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    # LightGBM parameters - Baseline
    params = {
        'objective': 'poisson',
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 63,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }
    if params_override:
        params.update(params_override)

    model = lgb.LGBMRegressor(**params)

    # If categorical features are explicitly passed, use them. Otherwise, LGBM will infer.
    # The current baseline does use explicit declaration, so we define it.
    if categorical_features_names is None:
        # Default categorical features for the baseline (Label Encoded)
        _street_name_col_processed = STREET_NAME_COL.replace(' ', '_').lower() + '_encoded'
        _violation_desc_col_processed = VIOLATION_DESC_COL.replace(' ', '_').lower() + '_encoded'
        categorical_features_names = []
        if _street_name_col_processed in X_train.columns:
            categorical_features_names.append("street_name_encoded")
        if _violation_desc_col_processed in X_train.columns:
            categorical_features_names.append("violation_description_encoded")
        
        # Ensure sanitized names are used for categorical_feature parameter
        categorical_features_names = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in categorical_features_names]

    
    fit_params = {
        'eval_set': [(X_val_sanitized, y_val)],
        'eval_metric': params['metric'], # Use the metric from params, which might be overridden
        'callbacks': [lgb.early_stopping(100, verbose=False)],
    }
    if categorical_features_names:
        fit_params['categorical_feature'] = categorical_features_names

    model.fit(X_train_sanitized, y_train, **fit_params)

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_experiment(name: str, train_path: str, feature_engineering_fn, model_params_override: dict = None, categorical_features_handling: str = 'auto', fe_output_suffix: str = '_encoded'):
    """
    Runs a single experiment (baseline or ablation) and returns the validation RMSE.
    """
    print(f"\n--- Running Experiment: {name} ---")

    df_2022_raw, encoder_dict = load_and_preprocess_data(train_path, is_training=True, feature_engineering_fn=feature_engineering_fn)

    _street_name_col_processed = STREET_NAME_COL.replace(' ', '_').lower()
    _violation_desc_col_processed = VIOLATION_DESC_COL.replace(' ', '_').lower()
    _target_column = TARGET_COLUMN.replace(' ', '_').lower()

    # Split 2022 data for training and validation
    df_2022_raw['group_id'] = df_2022_raw[_street_name_col_processed] + '_' + df_2022_raw[_violation_desc_col_processed]
    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    # Define features based on the FE function used
    features = [col for col in df_train_raw.columns if col not in [_target_column, _street_name_col_processed, _violation_desc_col_processed]]
    
    X_train = df_train_raw[features]
    y_train = df_train_raw[_target_column]
    X_val = df_val_raw[features]
    y_val = df_val_raw[_target_column]

    print("Training model...")
    categorical_features_for_lgbm = None
    if categorical_features_handling == 'explicit':
        # Re-derive categorical features names based on the FE output suffix
        categorical_features_for_lgbm = []
        if _street_name_col_processed + fe_output_suffix in X_train.columns:
            categorical_features_for_lgbm.append(_street_name_col_processed + fe_output_suffix)
        if _violation_desc_col_processed + fe_output_suffix in X_train.columns:
            categorical_features_for_lgbm.append(_violation_desc_col_processed + fe_output_suffix)
        # Ensure sanitized names are used
        categorical_features_for_lgbm = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in categorical_features_for_lgbm]
    elif categorical_features_handling == 'auto':
        categorical_features_for_lgbm = [] # LGBM will infer, or no explicit declaration

    model = train_model(X_train, y_train, X_val, y_val, params_override=model_params_override, categorical_features_names=categorical_features_for_lgbm)

    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log)
    val_predictions[val_predictions < 0] = 0

    final_validation_rmse = calculate_rmse(np.expm1(y_val), val_predictions)
    print(f"Validation RMSE: {final_validation_rmse:.4f}")
    gc.collect()
    return final_validation_rmse

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()

    results = {}

    # --- Baseline ---
    # The original script uses Label Encoding and explicit categorical feature declaration.
    # LGBM metric and eval_metric are 'rmse'. L1/L2 regularization lambda_l1=0.1, lambda_l2=0.1.
    baseline_params = {} # Using default params in train_model
    results['Baseline'] = run_experiment(
        "Baseline (Label Encoding, RMSE metric, L1/L2=0.1)",
        args.train_path,
        _engineer_features_baseline,
        baseline_params,
        categorical_features_handling='explicit',
        fe_output_suffix='_encoded'
    )

    # --- Ablation 1: Replace Label Encoding with Frequency Encoding ---
    # Change the feature engineering function and the expected suffix for features,
    # also ensure categorical_features_names are correctly passed for FE.
    ablation1_params = {} # Keep model params same as baseline
    results['Ablation 1 (Frequency Encoding)'] = run_experiment(
        "Ablation 1: Replace Label Encoding with Frequency Encoding",
        args.train_path,
        _engineer_features_fe, # Use FE function
        ablation1_params,
        categorical_features_handling='explicit', # Explicitly declare FE features
        fe_output_suffix='_frequency_encoded' # New suffix
    )
    
    # --- Ablation 2: Align LGBM metric and eval_metric to 'poisson' ---
    # Change model parameters only, keep feature engineering as baseline (Label Encoding)
    ablation2_params = {
        'metric': 'poisson',
        'eval_metric': 'poisson', # eval_metric in fit_params will use this
    }
    results['Ablation 2 (Metric/Eval Metric Poisson)'] = run_experiment(
        "Ablation 2: Align LGBM metric and eval_metric to 'poisson'",
        args.train_path,
        _engineer_features_baseline,
        ablation2_params,
        categorical_features_handling='explicit',
        fe_output_suffix='_encoded'
    )

    # --- Ablation 3: Remove L1/L2 Regularization ---
    # Change model parameters only, keep feature engineering as baseline (Label Encoding)
    ablation3_params = {
        'lambda_l1': 0.0,
        'lambda_l2': 0.0,
    }
    results['Ablation 3 (No L1/L2 Regularization)'] = run_experiment(
        "Ablation 3: Remove L1/L2 Regularization",
        args.train_path,
        _engineer_features_baseline,
        ablation3_params,
        categorical_features_handling='explicit',
        fe_output_suffix='_encoded'
    )

    print("\n--- Ablation Study Results ---")
    for name, rmse in results.items():
        print(f"{name}: RMSE = {rmse:.4f}")

    best_performance_name = min(results, key=results.get)
    best_rmse = results[best_performance_name]

    print(f"\nConclusion: The part that contributes the most to the overall performance (i.e., yields the lowest RMSE) is: {best_performance_name} with RMSE = {best_rmse:.4f}")

if __name__ == "__main__":
    main()
