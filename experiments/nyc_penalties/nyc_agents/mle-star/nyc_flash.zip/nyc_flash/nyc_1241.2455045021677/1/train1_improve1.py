
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import catboost as cb
import os
import lightgbm as lgb
import gc

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv'

import pandas as pd
import numpy as np
from sklearn.model_selection import KFold

# Assume STREET_NAME_COL, VIOLATION_DESC_COL, TARGET_COLUMN are globally defined constants.
# Example:
# STREET_NAME_COL = "Street Name"
# VIOLATION_DESC_COL = "Violation Description"
# TARGET_COLUMN = "fine_amount" # Example target column

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> (pd.DataFrame, dict):
    """
    Performs feature engineering on the input DataFrame, implementing a robust Target Encoding strategy.

    Args:
        df (pd.DataFrame): The input DataFrame.
        is_training (bool): A flag indicating if the function is called during training.
        encoder_dict (dict): A dictionary to store/retrieve encoders for categorical features.

    Returns:
        tuple[pd.DataFrame, dict]: A tuple containing the engineered DataFrame and the updated encoder dictionary.
    """
    if encoder_dict is None:
        encoder_dict = {}

    # Standardize column names to lowercase and snake_case for consistency
    df.columns = df.columns.str.replace(' ', '_').str.lower()

    # Standardized constant names for internal use based on global constants
    std_street_name_col = STREET_NAME_COL.replace(' ', '_').lower()
    std_violation_desc_col = VIOLATION_DESC_COL.replace(' ', '_').lower()
    
    # Standardize target column name if it exists and is provided
    std_target_column = TARGET_COLUMN.replace(' ', '_').lower() if TARGET_COLUMN else None
    
    # Handle missing values for key categorical columns
    for col in [std_street_name_col, std_violation_desc_col]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # --- Log transform target BEFORE target encoding calculation ---
    # This ensures target encoding uses the transformed target values.
    # The 'target_transform' key in encoder_dict prevents double transformation during re-evaluation.
    if is_training and std_target_column and std_target_column in df.columns:
        if encoder_dict.get('target_transform', {}).get('is_log1p') is not True:
            df[std_target_column] = np.log1p(df[std_target_column])
            encoder_dict['target_transform'] = {'is_log1p': True} # Mark as transformed

    # --- Target Encoding implementation for specified categorical features ---
    target_encoding_cols = [std_street_name_col, std_violation_desc_col]
    SMOOTHING_ALPHA = 100 # Hyperparameter for smoothing, can be tuned

    for col in target_encoding_cols:
        if col in df.columns:
            encoded_col_name = col + '_target_encoded'
            
            if is_training:
                # Ensure target column is available for training and target encoding
                if std_target_column and std_target_column in df.columns:
                    kf = KFold(n_splits=5, shuffle=True, random_state=42) # Use fixed random_state for reproducibility
                    df[encoded_col_name] = 0.0 # Initialize column with float type for target encoded values

                    # Calculate the global mean of the target for smoothing and unseen categories
                    global_target_mean_for_encoding = df[std_target_column].mean()

                    # Store necessary components in encoder_dict for inference
                    encoder_dict[col] = {
                        'global_target_mean': global_target_mean_for_encoding,
                        'smoothing_alpha': SMOOTHING_ALPHA,
                        'mapping': {} # This will store the final mapping after K-Fold processing
                    }

                    # K-Fold Cross-Validation for Target Encoding to prevent data leakage
                    for fold, (train_idx, val_idx) in enumerate(kf.split(df)):
                        df_train_fold = df.loc[train_idx]
                        
                        # Calculate smoothed target mean for each category in the training fold
                        agg_df = df_train_fold.groupby(col)[std_target_column].agg(
                            count='count', mean_target='mean'
                        ).reset_index()

                        # Apply smoothing formula: (count * mean_target + global_mean * alpha) / (count + alpha)
                        agg_df['smoothed_mean'] = (
                            agg_df['count'] * agg_df['mean_target'] + 
                            global_target_mean_for_encoding * SMOOTHING_ALPHA
                        ) / (agg_df['count'] + SMOOTHING_ALPHA)

                        # Create a mapping dictionary for this specific fold's training data
                        fold_mapping = agg_df.set_index(col)['smoothed_mean'].to_dict()

                        # Apply mapping to the validation set of the current fold
                        # Fill unseen categories (those not in fold_mapping) with the global_target_mean
                        df.loc[val_idx, encoded_col_name] = df.loc[val_idx, col].map(fold_mapping).fillna(global_target_mean_for_encoding)

                    # After all folds, calculate the final target mapping using the *entire* training dataset
                    # This final mapping is stored and used for future inference on new, unseen data.
                    final_agg_df = df.groupby(col)[std_target_column].agg(
                        count='count', mean_target='mean'
                    ).reset_index()
                    final_agg_df['smoothed_mean'] = (
                        final_agg_df['count'] * final_agg_df['mean_target'] + 
                        global_target_mean_for_encoding * SMOOTHING_ALPHA
                    ) / (final_agg_df['count'] + SMOOTHING_ALPHA)
                    encoder_dict[col]['mapping'] = final_agg_df.set_index(col)['smoothed_mean'].to_dict()
                else:
                    # Fallback if target column is not present during training, e.g., for feature-only data
                    df[encoded_col_name] = 0.0 # Assign a default value if target encoding cannot be performed
                    print(f"Warning: Cannot perform target encoding for '{col}' during training as '{std_target_column}' is not in DataFrame.")
            else: # Inference mode
                # During inference, apply pre-computed mappings from encoder_dict
                if col in encoder_dict and 'mapping' in encoder_dict[col] and 'global_target_mean' in encoder_dict[col]:
                    mapping = encoder_dict[col]['mapping']
                    global_mean = encoder_dict[col]['global_target_mean']
                    # Apply pre-computed mapping, filling unseen categories with the stored global mean
                    df[encoded_col_name] = df[col].map(mapping).fillna(global_mean)
                else:
                    # If no valid encoder is found for this column (e.g., new column not seen in training)
                    # or if encoder_dict is incomplete, assign a default value.
                    df[encoded_col_name] = encoder_dict.get(col, {}).get('global_target_mean', 0.0) # Fallback to 0.0
                    print(f"Warning: No valid target encoder found for '{col}'. Assigning default value.")

    # --- Interaction feature using the new target-encoded values ---
    te_street_col = std_street_name_col + '_target_encoded'
    te_violation_col = std_violation_desc_col + '_target_encoded'
    if te_street_col in df.columns and te_violation_col in df.columns:
        df['street_violation_interaction'] = df[te_street_col] * df[te_violation_col]
    
    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series) -> lgb.Booster:
    """
    Trains a LightGBM model.
    """
    # LightGBM expects feature names as strings
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'regression_l1',  # MAE objective
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 31,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)]) # Use callbacks for early stopping

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional: Path to the 2023 test/evaluation data CSV.')
    args = parser.parse_args()

    print(f"Loading training data from: {args.train_path}")
    df_2022_raw, encoder_dict = load_and_preprocess_data(args.train_path, is_training=True)

    # Split 2022 data for training and validation
    # Use grouped holdout for (street_name, violation_type) pairs
    # Create a unique identifier for splitting
    df_2022_raw['group_id'] = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

    # Get unique groups
    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    # Drop the temporary group_id
    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    # Define features and target
    features = [col for col in df_train_raw.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]]

    # Prepare training data
    X_train = df_train_raw[features]
    y_train = df_train_raw[TARGET_COLUMN]

    # Prepare validation data - CRITICAL FIX HERE: Extract y_val *before* any potential dropping or mismatch
    X_val = df_val_raw[features]
    y_val = df_val_raw[TARGET_COLUMN] # This ensures y_val is correctly assigned from the raw df_val_raw

    print("Training model...")
    model = train_model(X_train, y_train, X_val, y_val)

    # Predict on validation set for performance reporting
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log) # Inverse transform
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(np.expm1(y_val), val_predictions) # Calculate RMSE on original scale
    print(f"Final Validation Performance: {final_validation_rmse}")

    # If a test path is provided, generate predictions
    if args.test_path:
        print(f"Loading test data from: {args.test_path}")
        df_test_raw, _ = load_and_preprocess_data(args.test_path, is_training=False, encoder_dict=encoder_dict)

        # Ensure test data has the same features as training data
        test_features = [col for col in features if col in df_test_raw.columns]
        X_test = df_test_raw[test_features]

        # Align columns - crucial for consistent predictions
        # Add missing columns to X_test with 0, remove extra columns
        missing_cols = set(X_train.columns) - set(X_test.columns)
        for c in missing_cols:
            X_test[c] = 0
        extra_cols = set(X_test.columns) - set(X_train.columns)
        X_test = X_test.drop(columns=list(extra_cols))
        X_test = X_test[X_train.columns] # Ensure column order is the same

        print("Generating predictions for test data...")
        test_predictions_log = model.predict(X_test)
        test_predictions = np.expm1(test_predictions_log) # Inverse transform
        test_predictions[test_predictions < 0] = 0 # Clip negative predictions
        test_predictions = np.round(test_predictions).astype(int) # Round to nearest integer

        # Create submission file
        submission_df = pd.DataFrame({
            STREET_NAME_COL: df_test_raw[STREET_NAME_COL.replace(' ', '_').lower()],
            VIOLATION_DESC_COL: df_test_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()],
            PREDICTED_COUNT_COL: test_predictions
        })
        # Original column names for submission
        submission_df.columns = [STREET_NAME_COL, VIOLATION_DESC_COL, PREDICTED_COUNT_COL]

        submission_df.to_csv(OUTPUT_SUBMISSION_FILE, index=False)
        print(f"Submission file '{OUTPUT_SUBMISSION_FILE}' created successfully.")

        # If test_path contains 'violation_count', calculate RMSE
        if TARGET_COLUMN in df_test_raw.columns:
            y_test_true = np.expm1(df_test_raw[TARGET_COLUMN]) # Inverse log transform for actual values
            test_rmse = calculate_rmse(y_test_true, test_predictions)
            print(f"RMSE on provided test/evaluation data: {test_rmse}")

            # Report unseen key pairs
            train_keys = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]
            test_keys = df_test_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + df_test_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

            unseen_keys_count = test_keys.isin(train_keys).value_counts().get(False, 0)
            total_test_keys = len(test_keys)
            print(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {unseen_keys_count} out of {total_test_keys}")
            print("Unseen pairs are handled by the model's ability to generalize based on encoded features and numerical interaction features, "
                  "and by assigning -1 for unknown categories during Label Encoding transform.")

    gc.collect()

if __name__ == "__main__":
    main()
