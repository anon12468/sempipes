
# Required libraries:
# pip install pandas numpy scikit-learn catboost

import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def load_data(file_path, required_columns=None):
    """Loads a CSV file into a pandas DataFrame."""
    try:
        df = pd.read_csv(file_path)
        logging.info(f"Successfully loaded data from {file_path}. Shape: {df.shape}")
        if required_columns:
            missing_cols = [col for col in required_columns if col not in df.columns]
            if missing_cols:
                logging.warning(f"Missing required columns in {file_path}: {missing_cols}. This might cause issues.")
        return df
    except FileNotFoundError:
        logging.error(f"Error: File not found at {file_path}")
        raise
    except Exception as e:
        logging.error(f"Error loading data from {file_path}: {e}")
        raise

def preprocess_and_feature_engineer(df, is_training=True, encoders=None, input_data_dir='./input'):
    """
    Applies preprocessing and feature engineering steps.
    If is_training is True, fits encoders. Otherwise, uses provided encoders.
    """
    if encoders is None:
        encoders = {}

    # Create a copy to avoid SettingWithCopyWarning
    df_copy = df.copy()

    # Rename columns for consistency
    df_copy = df_copy.rename(columns={
        'Street Name': 'street_name',
        'Violation Description': 'violation_type',
        'violation_count': 'target' # This will be the target if available
    })

    # Ensure required columns are present for feature engineering
    if 'street_name' not in df_copy.columns or 'violation_type' not in df_copy.columns:
        logging.error("Missing 'street_name' or 'violation_type' after renaming. Check input file schema.")
        raise ValueError("Missing essential columns for feature engineering.")
    
    # Load augmentation tables
    # Determine the base directory for augmentation tables
    if not os.path.isdir(input_data_dir):
        logging.warning(f"Input data directory '{input_data_dir}' does not exist. Trying './input'.")
        input_data_dir = './input'
        if not os.path.isdir(input_data_dir):
            logging.error(f"Neither '{os.path.dirname(file_path)}' nor './input' exists for augmentation files.")
            # Continue without merging augmentation tables if path is invalid

    # Street features
    street_features_path = os.path.join(input_data_dir, 'street_features.csv')
    try:
        street_features_df = load_data(street_features_path)
        # Ensure 'Street Name' is consistent for merging
        street_features_df = street_features_df.rename(columns={'Street Name': 'street_name'})
        df_copy = pd.merge(df_copy, street_features_df, on='street_name', how='left')
        logging.info(f"Merged with street_features. Current shape: {df_copy.shape}")
    except FileNotFoundError:
        logging.warning(f"street_features.csv not found at {street_features_path}. Skipping merge.")
    except Exception as e:
        logging.warning(f"Error merging with street_features: {e}. Skipping merge.")

    # Violation codes (for potential additional violation type features)
    violation_codes_path = os.path.join(input_data_dir, 'violation_codes.csv')
    try:
        violation_codes_df = load_data(violation_codes_path)
        # Ensure 'Violation Description' is consistent for merging
        violation_codes_df = violation_codes_df.rename(columns={'Violation Description': 'viilation_type_original_name'}) # Rename to avoid conflict
        # Use a common column if available, else merge on violation_type
        # Assuming 'Violation Description' in violation_codes_df maps to 'violation_type' in main df
        df_copy = pd.merge(df_copy, violation_codes_df, left_on='violation_type', right_on='viilation_type_original_name', how='left')
        df_copy = df_copy.drop(columns=['viilation_type_original_name'], errors='ignore') # Drop the temporary merge column
        logging.info(f"Merged with violation_codes. Current shape: {df_copy.shape}")
    except FileNotFoundError:
        logging.warning(f"violation_codes.csv not found at {violation_codes_path}. Skipping merge.")
    except Exception as e:
        logging.warning(f"Error merging with violation_codes: {e}. Skipping merge.")

    # Simple feature engineering
    df_copy['street_name_len'] = df_copy['street_name'].apply(lambda x: len(str(x)) if pd.notna(x) else 0)
    df_copy['violation_type_len'] = df_copy['violation_type'].apply(lambda x: len(str(x)) if pd.notna(x) else 0)

    # Frequency encoding for street_name and violation_type
    for col in ['street_name', 'violation_type']:
        if is_training:
            freq_map = df_copy[col].value_counts(normalize=True).to_dict()
            encoders[f'{col}_freq_encoder'] = freq_map
        else:
            freq_map = encoders.get(f'{col}_freq_encoder', {})

        df_copy[f'{col}_freq'] = df_copy[col].map(freq_map).fillna(0) # Fill unseen with 0

    # Handle NaNs in numerical features before model training
    for col in df_copy.columns:
        if df_copy[col].dtype == 'float64' or df_copy[col].dtype == 'int64':
            if df_copy[col].isnull().any():
                # Use median from training data if available for consistent imputation
                if is_training:
                    median_val = df_copy[col].median()
                    encoders[f'{col}_median'] = median_val
                else:
                    median_val = encoders.get(f'{col}_median', 0) # Default to 0 if median not found
                df_copy[col] = df_copy[col].fillna(median_val)
        elif df_copy[col].dtype == 'object' or df_copy[col].dtype == 'category':
            df_copy[col] = df_copy[col].fillna('Unknown') # 'Unknown' for categorical

    return df_copy, encoders


def train_model(X_train, y_train, categorical_features_indices):
    """Trains the CatBoost Regressor model."""
    logging.info("Starting model training...")
    model = CatBoostRegressor(
        iterations=1000, # Reduced iterations to mitigate OOM and speed up training
        learning_rate=0.05,
        depth=8, # Reduced depth
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=100, # Print progress every 100 iterations
        early_stopping_rounds=50, # Early stopping to prevent overfitting and save time
        subsample=0.7, # Row sampling to prevent OOM for large datasets
        bootstrap_type='Bernoulli',
        # thread_count=-1 # Use all available threads - uncomment if needed and safe
        # `nan_mode='Min'` or `'Forbidden'` can be specified if NaNs are expected, but we impute them.
    )

    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    
    model.fit(train_pool, plot=False) # plot=False to avoid matplotlib dependency or display issues in some environments
    logging.info("Model training complete.")
    return model

def predict_and_evaluate(model, df_raw, encoders, features, categorical_features_indices, has_target=True, input_data_dir='./input'):
    """
    Generates predictions and evaluates if target is available.
    Returns predictions, RMSE, and count of unseen key pairs.
    """
    df_processed, _ = preprocess_and_feature_engineer(df_raw.copy(), is_training=False, encoders=encoders, input_data_dir=input_data_dir)
    
    # Ensure all features used in training are present in the prediction dataframe
    # Fill missing features with appropriate defaults
    for col in features:
        if col not in df_processed.columns:
            if col in [f for f_idx, f in enumerate(features) if f_idx in categorical_features_indices]:
                df_processed[col] = 'Unknown' # Default for categorical
            else:
                df_processed[col] = encoders.get(f'{col}_median', 0) # Default for numerical, use median from train if available, else 0

    # Ensure order of columns matches training for prediction
    X = df_processed[features]
    
    # Explicitly convert categorical columns to string for CatBoost Pool
    for col_idx in categorical_features_indices:
        col_name = features[col_idx]
        if col_name in X.columns:
            X[col_name] = X[col_name].astype(str)

    predictions = model.predict(X)
    predictions[predictions < 0] = 0 # Clip negative predictions to 0

    rmse = None
    unseen_key_pairs_count = 0

    if has_target:
        true_labels = df_processed['target']
        rmse = np.sqrt(mean_squared_error(true_labels, predictions))
        
        # Identify unseen key pairs (street_name, violation_type)
        train_keys = set(encoders.get('train_keys', []))
        current_keys = set(df_processed.apply(lambda row: (row['street_name'], row['violation_type']), axis=1))
        unseen_key_pairs_count = len(current_keys - train_keys)
        logging.info(f"Number of unseen (street_name, violation_type) pairs in evaluation/test set: {unseen_key_pairs_count}")

    return predictions, rmse, unseen_key_pairs_count, df_processed[['street_name', 'violation_type']].copy()


def main(args):
    logging.info("Starting script execution.")

    # Create output directory if it doesn't exist
    output_dir = './output'
    os.makedirs(output_dir, exist_ok=True)

    # Determine input data directory from train_path or default to './input'
    input_data_dir = os.path.dirname(args.train_path)
    if not input_data_dir or not os.path.exists(input_data_dir):
        input_data_dir = './input'
        if not os.path.exists(input_data_dir):
            logging.error(f"Cannot find input data directory. Neither '{os.path.dirname(args.train_path)}' nor './input' exists.")
            raise FileNotFoundError("Input data directory not found.")
        else:
            logging.warning(f"Adjusting input data directory to: {input_data_dir}")

    # --- Load and Preprocess Training Data ---
    logging.info(f"Loading training data from: {args.train_path}")
    train_raw_df = load_data(args.train_path, required_columns=['Street Name', 'Violation Description', 'violation_count'])
    
    # Store original keys for unseen detection later
    train_raw_df['key_pair_for_split'] = train_raw_df.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1)

    # Split training data for development validation
    # A simple random split is used here for initial development validation.
    # For a true grouped holdout, one would split on unique street_name or violation_type.
    train_df_full, validation_df_full = train_test_split(
        train_raw_df, test_size=0.2, random_state=42
    )

    logging.info(f"Training data split into {train_df_full.shape[0]} for actual training and {validation_df_full.shape[0]} for validation.")

    # Preprocess and feature engineer training data
    train_processed_df, encoders = preprocess_and_feature_engineer(train_df_full.copy(), is_training=True, input_data_dir=input_data_dir)
    
    # Store training keys for later unseen detection
    encoders['train_keys'] = set(train_processed_df.apply(lambda row: (row['street_name'], row['violation_type']), axis=1))

    # Define features and target
    target_col = 'target'
    features = [col for col in train_processed_df.columns if col not in [target_col, 'key_pair_for_split']]
    
    X_train = train_processed_df[features]
    y_train = train_processed_df[target_col]

    # Identify categorical features for CatBoost
    categorical_features_indices = [
        i for i, col in enumerate(features)
        if X_train[col].dtype == 'object' or X_train[col].dtype == 'category'
    ]
    
    # Explicitly convert object columns to string type for CatBoost if they are categorical
    for col_idx in categorical_features_indices:
        col_name = features[col_idx]
        if col_name in X_train.columns:
            X_train[col_name] = X_train[col_name].astype(str)

    # --- Train Model ---
    model = train_model(X_train, y_train, categorical_features_indices)

    # --- Evaluate on Validation Set ---
    logging.info("Evaluating model on validation set...")
    val_predictions, val_rmse, unseen_val_count, _ = predict_and_evaluate(
        model, validation_df_full, encoders, features, categorical_features_indices, has_target=True, input_data_dir=input_data_dir
    )
    logging.info(f"Validation RMSE: {val_rmse:.4f}")
    logging.info(f"Unseen (street_name, violation_type) pairs in validation set: {unseen_val_count}")
    print(f"Final Validation Performance: {val_rmse:.4f}")

    # --- Generate Predictions for Test Data (if provided) ---
    if args.test_path:
        logging.info(f"Loading test data from: {args.test_path}")
        test_raw_df = load_data(args.test_path, required_columns=['Street Name', 'Violation Description'])
        
        # Check if 'violation_count' (target) is present in the test file
        test_has_target = 'violation_count' in test_raw_df.columns
        
        logging.info("Generating predictions for the test set...")
        test_predictions, test_rmse, unseen_test_count, test_keys_df = predict_and_evaluate(
            model, test_raw_df, encoders, features, categorical_features_indices, has_target=test_has_target, input_data_dir=input_data_dir
        )

        submission_df = pd.DataFrame({
            'street_name': test_keys_df['street_name'],
            'violation_type': test_keys_df['violation_type'],
            'predicted_count': test_predictions
        })
        
        submission_path = os.path.join(output_dir, 'submission.csv')
        submission_df.to_csv(submission_path, index=False)
        logging.info(f"Predictions saved to {submission_path}")

        if test_has_target:
            logging.info(f"Test Set RMSE: {test_rmse:.4f}")
            logging.info(f"Unseen (street_name, violation_type) pairs in test set: {unseen_test_count}")
        else:
            logging.info("Test file does not contain 'violation_count', so RMSE cannot be computed.")
            logging.info(f"Unseen (street_name, violation_type) pairs in test set: {unseen_test_count}")
    
    logging.info("Script execution finished.")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the training data CSV file (2022 violations).')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional path to the test data CSV file for predictions.')
    
    args = parser.parse_args()

    # Determine the directory where input files are expected
    # This logic aims to find the 'input' folder relative to the script or specified path
    train_path_dir = os.path.dirname(args.train_path)
    if train_path_dir == '': # If train_path is just a filename (e.g., "violations_per_street_2022.csv")
        # Assume input files are in './input'
        if not os.path.exists('./input'):
            logging.error("The '--train-path' is a filename, and the default './input' directory does not exist.")
            raise FileNotFoundError("Input data directory not found. Please specify a full path or ensure './input' exists.")
        args.train_path = os.path.join('./input', args.train_path)
        logging.warning(f"Adjusted train-path to: {args.train_path}")
    elif not os.path.exists(train_path_dir): # If the specified directory doesn't exist
        # Fallback to './input'
        if os.path.exists('./input'):
            args.train_path = os.path.join('./input', os.path.basename(args.train_path))
            logging.warning(f"Adjusted train-path to: {args.train_path}")
        else:
            logging.error(f"Neither the specified training data directory '{train_path_dir}' nor './input' exists.")
            raise FileNotFoundError("Training data directory not found.")
            
    # Apply similar logic for test-path
    if args.test_path:
        test_path_dir = os.path.dirname(args.test_path)
        if test_path_dir == '':
            if not os.path.exists('./input'):
                logging.error("The '--test-path' is a filename, and the default './input' directory does not exist.")
                raise FileNotFoundError("Input data directory not found. Please specify a full path or ensure './input' exists.")
            args.test_path = os.path.join('./input', args.test_path)
            logging.warning(f"Adjusted test-path to: {args.test_path}")
        elif not os.path.exists(test_path_dir):
            if os.path.exists('./input'):
                args.test_path = os.path.join('./input', os.path.basename(args.test_path))
                logging.warning(f"Adjusted test-path to: {args.test_path}")
            else:
                logging.error(f"Neither the specified test data directory '{test_path_dir}' nor './input' exists.")
                raise FileNotFoundError("Test data directory not found.")

    main(args)

