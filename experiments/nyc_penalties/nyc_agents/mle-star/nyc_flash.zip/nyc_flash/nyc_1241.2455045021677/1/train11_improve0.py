
import pandas as pd
import numpy as np
import argparse
import os
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument(
        "--train-path",
        type=str,
        default=os.path.join("input", "violations_per_street_2022.csv"),
        help="Path to the training data CSV file (2022 violations).",
    )
    parser.add_argument(
        "--test-path",
        type=str,
        default=None,
        help="Path to the test/evaluation data CSV file.",
    )
    args = parser.parse_args()

    train_file_path = args.train_path
    test_file_path = args.test_path

    # --- Data Loading ---
    print(f"Loading training data from: {train_file_path}")
    try:
        train_df = pd.read_csv(train_file_path)
    except FileNotFoundError:
        print(f"Error: Training file not found at {train_file_path}")
        return
    except Exception as e:
        print(f"Error loading training data: {e}")
        return

    # Rename columns for easier access and consistency
    train_df = train_df.rename(
        columns={
            "Street Name": "street_name",
            "Violation Description": "violation_type",
            "violation_count": "violation_count",
        }
    )

    # --- Feature Engineering (Simple from core data) ---
    # Convert street_name and violation_type to string type to avoid issues with CatBoost
    # and handle potential NaNs.
    train_df["street_name"] = train_df["street_name"].astype(str).fillna("UNKNOWN_STREET")
    train_df["violation_type"] = train_df["violation_type"].astype(str).fillna("UNKNOWN_VIOLATION")

    # Add a simple numerical feature: length of street name
    train_df["street_name_len"] = train_df["street_name"].apply(len)

    # Define features and target
    features = ["street_name", "violation_type", "street_name_len"]
    target = "violation_count"

    X = train_df[features]
    y = train_df[target]

    # Identify categorical features for CatBoost
    # CatBoost handles categorical features natively, including unseen ones.
    categorical_features_indices = [
        X.columns.get_loc(col) for col in ["street_name", "violation_type"]
    ]

    # --- Data Splitting for Validation ---
    print("Splitting training data for validation...")
    # Using a simple random split for now. For aggregate yearly data,
    # a time-based split is not directly applicable. A grouped split could be an improvement.
    X_train, X_val, y_train, y_val = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    # --- CatBoost Model Training ---
    print("Training CatBoost Regressor...")
    model = CatBoostRegressor(
        iterations=1000,  # Number of boosting iterations
        learning_rate=0.05,
        depth=8,         # Depth of the trees
        loss_function="RMSE",
        random_seed=42,
        verbose=100,     # Print progress every 100 iterations
        cat_features=categorical_features_indices,
        early_stopping_rounds=50, # Stop if validation RMSE doesn't improve for 50 rounds
        # task_type="GPU", # Uncomment if GPU is available and setup, potentially reduces OOM
        # devices='0' # If using GPU, specify device index
    )

    # Fit the model. eval_set is used for early stopping.
    model.fit(X_train, y_train, eval_set=(X_val, y_val))

    # --- Validation Performance ---
    val_predictions = model.predict(X_val)
    # Ensure predictions are non-negative as violation counts cannot be negative
    val_predictions[val_predictions < 0] = 0
    rmse_val = np.sqrt(mean_squared_error(y_val, val_predictions))
    # Required output format for validation performance
    print(f"Final Validation Performance: {rmse_val}")

    # --- Handle Test Data (if provided) ---
    if test_file_path:
        print(f"\nLoading test data from: {test_file_path}")
        try:
            test_df = pd.read_csv(test_file_path)
        except FileNotFoundError:
            print(f"Error: Test file not found at {test_file_path}")
            return
        except Exception as e:
            print(f"Error loading test data: {e}")
            return

        test_df = test_df.rename(
            columns={
                "Street Name": "street_name",
                "Violation Description": "violation_type",
                "violation_count": "violation_count", # This column might be optional for pure prediction
            }
        )

        # Apply same feature engineering as training data
        test_df["street_name"] = test_df["street_name"].astype(str).fillna("UNKNOWN_STREET")
        test_df["violation_type"] = test_df["violation_type"].astype(str).fillna("UNKNOWN_VIOLATION")
        test_df["street_name_len"] = test_df["street_name"].apply(len)

        # Extract features for prediction
        X_test = test_df[features]

        # Identify unseen key pairs
        # Create unique (street_name, violation_type) tuples for train and test
        train_key_pairs = set(train_df.apply(lambda row: (row['street_name'], row['violation_type']), axis=1))
        test_key_pairs = set(test_df.apply(lambda row: (row['street_name'], row['violation_type']), axis=1))
        unseen_key_pairs_count = len(test_key_pairs - train_key_pairs)
        print(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_key_pairs_count}")
        print("Unseen categorical features are handled by CatBoost's internal mechanisms, treating them as new categories.")


        # Make predictions on test data
        print("Generating predictions for test data...")
        test_predictions = model.predict(X_test)
        test_predictions[test_predictions < 0] = 0 # Clip negative predictions

        # Create submission file
        submission_df = pd.DataFrame(
            {
                "street_name": test_df["street_name"],
                "violation_type": test_df["violation_type"],
                "predicted_count": test_predictions.round().astype(int), # Round to nearest integer and convert type for counts
            }
        )
        submission_df.to_csv("submission.csv", index=False)
        print("Predictions saved to submission.csv")

        # Report RMSE if 'violation_count' is present in the test file and has actual values
        if target in test_df.columns and not test_df[target].isnull().all():
            y_test = test_df[target]
            rmse_test = np.sqrt(mean_squared_error(y_test, test_predictions))
            print(f"RMSE on the provided test data: {rmse_test}")
        else:
            print("Test file does not contain 'violation_count' for scoring.")
    else:
        print("\nNo test-path provided. Skipping prediction generation.")

if __name__ == "__main__":
    main()
