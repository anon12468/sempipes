
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc
import os

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv'

# Standardized column names for internal use
street_name_col_std = STREET_NAME_COL.replace(' ', '_').lower()
violation_desc_col_std = VIOLATION_DESC_COL.replace(' ', '_').lower()
target_column_std = TARGET_COLUMN.replace(' ', '_').lower()

def _engineer_features_abl(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None,
                           use_target_encoding: bool = True, use_te_interactions: bool = True) -> (pd.DataFrame, dict):
    """
    Performs feature engineering on the input DataFrame.
    Modified to accept flags for ablation study:
    - use_target_encoding: If True, uses Target Encoding. If False, reverts to Label Encoding.
    - use_te_interactions: If True, creates interaction features based on Target Encoded values.
                           This flag is only relevant if use_target_encoding is True.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df_copy = df.copy()
    df_copy.columns = df_copy.columns.str.replace(' ', '_').str.lower()

    # Handle missing values
    for col in [street_name_col_std, violation_desc_col_std]:
        if col in df_copy.columns:
            df_copy[col] = df_copy[col].fillna('unknown').astype(str)

    # Categorical Feature Encoding (either Target Encoding or Label Encoding)
    if use_target_encoding:
        categorical_cols_to_encode = [street_name_col_std, violation_desc_col_std]
        global_mean_target = 0.0
        if is_training and target_column_std in df_copy.columns:
            global_mean_target = df_copy[target_column_std].mean()
            encoder_dict['global_mean_target'] = global_mean_target
        elif 'global_mean_target' in encoder_dict:
            global_mean_target = encoder_dict['global_mean_target']

        for col in categorical_cols_to_encode:
            if col in df_copy.columns:
                encoded_col_name = f'{col}_target_encoded'
                if is_training and target_column_std in df_copy.columns:
                    mean_mapping = df_copy.groupby(col)[target_column_std].mean().to_dict()
                    df_copy[encoded_col_name] = df_copy[col].map(mean_mapping).fillna(global_mean_target)
                    encoder_dict[f'{col}_target_encoder'] = mean_mapping
                else:
                    if f'{col}_target_encoder' in encoder_dict:
                        mean_mapping = encoder_dict[f'{col}_target_encoder']
                        df_copy[encoded_col_name] = df_copy[col].map(mean_mapping).fillna(global_mean_target)
                    else:
                        df_copy[encoded_col_name] = global_mean_target
    else: # Revert to LabelEncoder
        categorical_cols_to_encode = [street_name_col_std, violation_desc_col_std]
        for col in categorical_cols_to_encode:
            if col in df_copy.columns:
                encoded_col_name = f'{col}_encoded' # Use a different suffix to distinguish from TE
                if is_training:
                    le = LabelEncoder()
                    df_copy[encoded_col_name] = le.fit_transform(df_copy[col])
                    encoder_dict[col + '_le'] = le # Store LabelEncoder
                else:
                    if col + '_le' in encoder_dict:
                        le = encoder_dict[col + '_le']
                        # Use transform for existing categories, map unknown to -1
                        df_copy[encoded_col_name] = df_copy[col].map(lambda s: le.transform([s])[0] if s in le.classes_ else -1)
                    else:
                        df_copy[encoded_col_name] = -1

    # Generate interaction features IF Target Encoding is used AND interactions are enabled
    if use_target_encoding and use_te_interactions:
        street_te_col = f'{street_name_col_std}_target_encoded'
        violation_te_col = f'{violation_desc_col_std}_target_encoded'

        if street_te_col in df_copy.columns and violation_te_col in df_copy.columns:
            street_te = df_copy[street_te_col]
            violation_te = df_copy[violation_te_col]

            epsilon = 1e-6 # To prevent division by zero
            df_copy['street_violation_te_interaction'] = street_te * violation_te
            df_copy['street_violation_te_sum'] = street_te + violation_te
            df_copy['street_violation_te_ratio'] = street_te / (violation_te + epsilon)
            df_copy['violation_street_te_ratio'] = violation_te / (street_te + epsilon)
            df_copy['street_violation_te_diff'] = street_te - violation_te

    return df_copy, encoder_dict

def load_and_preprocess_data_abl(file_path: str, is_training: bool = True, encoder_dict: dict = None,
                                  use_target_encoding: bool = True, use_te_interactions: bool = True) -> (pd.DataFrame, dict):
    """
    Loads data from a CSV file and applies feature engineering based on ablation flags.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features_abl(df, is_training=is_training, encoder_dict=encoder_dict,
                                              use_target_encoding=use_target_encoding, use_te_interactions=use_te_interactions)
    return df, encoder_dict

def train_model_abl(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series,
                    use_l1_l2_regularization: bool = True) -> lgb.Booster:
    """
    Trains a LightGBM model.
    Modified to accept flag for L1/L2 regularization.
    """
    # LightGBM expects feature names as strings
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'regression_l1',
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'num_leaves': 31,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }
    if use_l1_l2_regularization:
        params['lambda_l1'] = 0.1
        params['lambda_l2'] = 0.1
    else: # Disable regularization
        params['lambda_l1'] = 0.0
        params['lambda_l2'] = 0.0

    model = lgb.LGBMRegressor(**params)
    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)])
    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_ablation_scenario(scenario_name: str,
                          use_target_encoding: bool,
                          use_te_interactions: bool,
                          use_l1_l2_regularization: bool) -> float:
    """
    Runs a single ablation scenario and returns its validation RMSE.
    """
    print(f"\n--- Running Ablation Scenario: {scenario_name} ---")

    train_path = './input/violations_per_street_2022.csv'
    
    # Each scenario gets a fresh encoder_dict to avoid leakage/interference between runs
    df_2022_processed, encoder_dict = load_and_preprocess_data_abl(
        train_path, is_training=True, encoder_dict=None,
        use_target_encoding=use_target_encoding,
        use_te_interactions=use_te_interactions
    )

    df_2022_processed['group_id'] = df_2022_processed[street_name_col_std] + '_' + \
                                     df_2022_processed[violation_desc_col_std]

    unique_groups = df_2022_processed['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train = df_2022_processed[df_2022_processed['group_id'].isin(train_groups)].copy()
    df_val = df_2022_processed[df_2022_processed['group_id'].isin(val_groups)].copy()

    df_train = df_train.drop(columns=['group_id'])
    df_val = df_val.drop(columns=['group_id'])
    
    # Dynamically build features list based on ablation flags
    all_current_df_features = [col for col in df_train.columns if col not in [target_column_std, street_name_col_std, violation_desc_col_std]]
    
    final_features = []
    for f in all_current_df_features:
        is_te_feature = f.endswith('_target_encoded')
        is_le_feature = f.endswith('_encoded') and not f.endswith('_target_encoded')
        is_te_interaction_feature = f.startswith('street_violation_te_') or f.startswith('violation_street_te_')

        if is_te_interaction_feature:
            if use_target_encoding and use_te_interactions:
                final_features.append(f)
        elif is_te_feature:
            if use_target_encoding:
                final_features.append(f)
        elif is_le_feature:
            if not use_target_encoding: # Only include LE features if TE is OFF
                final_features.append(f)
        else: # Regular non-categorical, non-interaction features
            final_features.append(f)
    
    features = list(set(final_features)) # Remove potential duplicates and convert to list

    X_train = df_train[features]
    y_train = df_train[target_column_std]

    X_val = df_val[features]
    y_val = df_val[target_column_std]

    # Align columns between X_train and X_val to avoid issues
    missing_cols_val = set(X_train.columns) - set(X_val.columns)
    for c in missing_cols_val:
        X_val[c] = 0 # Impute missing columns with 0, or suitable default
    extra_cols_val = set(X_val.columns) - set(X_train.columns)
    X_val = X_val.drop(columns=list(extra_cols_val))
    X_val = X_val[X_train.columns] # Ensure order

    model = train_model_abl(X_train, y_train, X_val, y_val,
                            use_l1_l2_regularization=use_l1_l2_regularization)

    val_predictions = model.predict(X_val)
    val_predictions[val_predictions < 0] = 0
    val_predictions = np.round(val_predictions).astype(int)

    final_validation_rmse = calculate_rmse(y_val, val_predictions)
    print(f"{scenario_name} Validation RMSE: {final_validation_rmse}")
    gc.collect()
    return final_validation_rmse

def main():
    # Make sure 'input' directory exists for the dummy file
    os.makedirs('./input', exist_ok=True)
    # Create a dummy CSV if it doesn't exist, for local testing
    if not os.path.exists('./input/violations_per_street_2022.csv'):
        print("Creating dummy training data file...")
        dummy_data = {
            'Street Name': ['MAIN ST', 'ELM ST', 'OAK AVE', 'MAIN ST', 'ELM ST', 'PINE ST', 'MAIN ST', 'OAK AVE', 'BIRCH ST', 'MAIN ST'],
            'Violation Description': ['PARKING METER', 'NO STANDING', 'FIRE HYDRANT', 'NO PARKING', 'PARKING METER', 'NO STANDING', 'FIRE HYDRANT', 'NO PARKING', 'DOUBLE PARK', 'PARKING METER'],
            'violation_count': [100, 50, 10, 80, 45, 12, 110, 95, 20, 105]
        }
        pd.DataFrame(dummy_data).to_csv('./input/violations_per_street_2022.csv', index=False)
        print("Dummy data created at ./input/violations_per_street_2022.csv")

    results = {}

    # 0. Baseline (Original solution settings from the provided code)
    # Uses Target Encoding, TE Interactions, and L1/L2 Regularization
    results['Baseline'] = run_ablation_scenario(
        "Baseline (All Features & Settings Enabled)",
        use_target_encoding=True,
        use_te_interactions=True,
        use_l1_l2_regularization=True
    )

    # 1. Ablation: No Target-Encoded Interaction Features
    # Keeps Target Encoding, but disables the 5 interaction features
    results['Ablation: No Target-Encoded Interaction Features'] = run_ablation_scenario(
        "Ablation: No Target-Encoded Interaction Features",
        use_target_encoding=True,
        use_te_interactions=False,
        use_l1_l2_regularization=True
    )

    # 2. Ablation: Revert to Label Encoding (instead of Target Encoding)
    # Disables Target Encoding, which will trigger Label Encoding.
    # TE Interactions are implicitly off as they depend on TE.
    results['Ablation: Revert to Label Encoding'] = run_ablation_scenario(
        "Ablation: Revert to Label Encoding (from Target Encoding)",
        use_target_encoding=False,
        use_te_interactions=False, # Irrelevant, but explicitly setting for clarity
        use_l1_l2_regularization=True
    )

    # 3. Ablation: No L1/L2 Regularization
    # Keeps Target Encoding and TE Interactions, but disables L1/L2 regularization
    results['Ablation: No L1/L2 Regularization'] = run_ablation_scenario(
        "Ablation: No L1/L2 Regularization",
        use_target_encoding=True,
        use_te_interactions=True,
        use_l1_l2_regularization=False
    )

    print("\n--- Ablation Study Summary ---")
    sorted_results = sorted(results.items(), key=lambda item: item[1])
    for scenario, rmse in sorted_results:
        print(f"{scenario}: {rmse:.4f}")

    baseline_rmse = results['Baseline']
    print(f"\nBaseline RMSE: {baseline_rmse:.4f}")
    
    print("\n--- Contribution Analysis ---")
    
    # Calculate difference for each ablation compared to baseline
    # A positive difference in RMSE when a component is REMOVED means the component was beneficial.
    # A negative difference in RMSE when a component is REMOVED means the component was detrimental.

    impacts = {}
    for scenario, rmse in results.items():
        if scenario == 'Baseline (All Features & Settings Enabled)':
            continue
        impact_value = rmse - baseline_rmse
        impacts[scenario] = impact_value
        print(f"Impact of '{scenario}' (relative to Baseline): {impact_value:.4f} RMSE")

    most_beneficial_component = None
    max_degradation_from_removal = 0 # Largest positive change in RMSE after removal/modification

    most_detrimental_component = None
    max_improvement_from_removal = 0 # Largest negative change in RMSE after removal/modification

    # Analyze based on the ablation descriptions
    # 1. No Target-Encoded Interaction Features
    if 'Ablation: No Target-Encoded Interaction Features' in impacts:
        diff = impacts['Ablation: No Target-Encoded Interaction Features']
        if diff > max_degradation_from_removal: # Removing it degraded performance
            max_degradation_from_removal = diff
            most_beneficial_component = "Target-Encoded Interaction Features"
        if diff < max_improvement_from_removal: # Removing it improved performance
            max_improvement_from_removal = diff
            most_detrimental_component = "Target-Encoded Interaction Features"
    
    # 2. Revert to Label Encoding (effectively removing Target Encoding and its interactions)
    if 'Ablation: Revert to Label Encoding (from Target Encoding)' in impacts:
        diff = impacts['Ablation: Revert to Label Encoding (from Target Encoding)']
        # If removing Target Encoding increases RMSE, then Target Encoding was beneficial compared to Label Encoding
        if diff > max_degradation_from_removal:
            max_degradation_from_removal = diff
            most_beneficial_component = "Target Encoding (compared to Label Encoding)"
        # If removing Target Encoding decreases RMSE, then Target Encoding was detrimental compared to Label Encoding
        if diff < max_improvement_from_removal:
            max_improvement_from_removal = diff
            most_detrimental_component = "Target Encoding (compared to Label Encoding)"

    # 3. No L1/L2 Regularization
    if 'Ablation: No L1/L2 Regularization' in impacts:
        diff = impacts['Ablation: No L1/L2 Regularization']
        if diff > max_degradation_from_removal: # Removing it degraded performance
            max_degradation_from_removal = diff
            most_beneficial_component = "L1/L2 Regularization"
        if diff < max_improvement_from_removal: # Removing it improved performance
            max_improvement_from_removal = diff
            most_detrimental_component = "L1/L2 Regularization"

    print("\n--- Final Conclusion ---")
    if most_beneficial_component and max_degradation_from_removal > 0:
        print(f"The component that contributes the MOST positively to the overall performance (its removal caused the largest RMSE increase) is: '{most_beneficial_component}'. Removing it resulted in an RMSE increase of {max_degradation_from_removal:.4f}.")
    elif most_detrimental_component and max_improvement_from_removal < 0:
        print(f"The component that contributes the MOST negatively to the overall performance (its removal caused the largest RMSE decrease, implying it was detrimental) is: '{most_detrimental_component}'. Removing it resulted in an RMSE decrease of {abs(max_improvement_from_removal):.4f}.")
    else:
        print("Based on this ablation study, no clear most impactful component was identified, or all ablations led to negligible changes.")

if __name__ == "__main__":
    main()
