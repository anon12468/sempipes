
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import os
import lightgbm as lgb
import gc

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None, apply_log_transform: bool = True) -> (pd.DataFrame, dict):
    """
    Performs feature engineering on the input DataFrame.
    Added apply_log_transform parameter for ablation.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Handle missing values
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Label Encoding for categorical features
    categorical_cols = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col] = le
            else:
                if col in encoder_dict:
                    # Use transform for existing categories, map unknown to -1
                    df[col + '_encoded'] = df[col].map(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else -1)
                else:
                    df[col + '_encoded'] = -1 # Assign a default for entirely new categories if no encoder

    # Log transform target if present and enabled for training data
    if TARGET_COLUMN in df.columns and is_training and apply_log_transform:
        df[TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None, apply_log_transform: bool = True) -> (pd.DataFrame, dict):
    """
    Loads data from a CSV file and applies initial preprocessing.
    Added apply_log_transform parameter for ablation.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict, apply_log_transform=apply_log_transform)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series, l1_reg: float = 0.1, l2_reg: float = 0.1) -> lgb.Booster:
    """
    Trains a LightGBM model.
    Added l1_reg and l2_reg parameters for ablation.
    """
    # LightGBM expects feature names as strings
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'poisson',
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': l1_reg, # Ablation point
        'lambda_l2': l2_reg, # Ablation point
        'num_leaves': 63,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)])

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_ablation_scenario(scenario_name: str, train_path: str, apply_log_transform: bool, l1_reg: float, l2_reg: float, validation_test_size: float) -> float:
    """
    Runs a single ablation scenario and returns its validation RMSE.
    """
    print(f"\n--- Running Scenario: {scenario_name} ---")

    # Load and preprocess data. The apply_log_transform flag affects how TARGET_COLUMN is handled during loading.
    df_2022_raw, encoder_dict = load_and_preprocess_data(train_path, is_training=True, apply_log_transform=apply_log_transform)

    # Split 2022 data for training and validation using grouped holdout
    df_2022_raw['group_id'] = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=validation_test_size, random_state=42) # Ablation point for test_size

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    # Define features and target
    features = [col for col in df_train_raw.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]]

    X_train = df_train_raw[features]
    y_train = df_train_raw[TARGET_COLUMN]

    X_val = df_val_raw[features]
    y_val = df_val_raw[TARGET_COLUMN]

    print("Training model...")
    model = train_model(X_train, y_train, X_val, y_val, l1_reg=l1_reg, l2_reg=l2_reg)

    val_predictions_output_scale = model.predict(X_val)
    
    # Inverse transform predictions if log transform was applied to the target
    if apply_log_transform:
        val_predictions_output_scale = np.expm1(val_predictions_output_scale)

    val_predictions_output_scale[val_predictions_output_scale < 0] = 0

    # Calculate RMSE on the original scale of the target variable
    # If log transform was applied, y_val is currently log-transformed, so expm1 is needed.
    # Otherwise, y_val is already on the original scale.
    true_y_val_original_scale = np.expm1(y_val) if apply_log_transform else y_val
    final_validation_rmse = calculate_rmse(true_y_val_original_scale, val_predictions_output_scale)
    
    print(f"Scenario '{scenario_name}' Validation RMSE: {final_validation_rmse}")
    gc.collect() # Clean up memory
    return final_validation_rmse

def main_ablation():
    parser = argparse.ArgumentParser(description="Perform ablation study on NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()

    results = {}

    # Scenario 1: Baseline (current solution settings)
    # Log transform enabled, L1/L2 reg (0.1, 0.1), test_size=0.2
    results['Baseline (Current Solution)'] = run_ablation_scenario(
        'Baseline (Current Solution)', args.train_path,
        apply_log_transform=True, l1_reg=0.1, l2_reg=0.1, validation_test_size=0.2
    )

    # Scenario 2: Ablation - No Log Transform on Target
    # Log transform disabled, L1/L2 reg (0.1, 0.1), test_size=0.2
    results['Ablation: No Log Transform on Target'] = run_ablation_scenario(
        'Ablation: No Log Transform on Target', args.train_path,
        apply_log_transform=False, l1_reg=0.1, l2_reg=0.1, validation_test_size=0.2
    )

    # Scenario 3: Ablation - No L1/L2 Regularization
    # Log transform enabled, L1/L2 reg (0, 0), test_size=0.2
    results['Ablation: No L1/L2 Regularization'] = run_ablation_scenario(
        'Ablation: No L1/L2 Regularization', args.train_path,
        apply_log_transform=True, l1_reg=0.0, l2_reg=0.0, validation_test_size=0.2
    )
    
    # Scenario 4: Ablation - Validation Split test_size=0.3
    # Log transform enabled, L1/L2 reg (0.1, 0.1), test_size=0.3
    results['Ablation: Validation Split test_size=0.3'] = run_ablation_scenario(
        'Ablation: Validation Split test_size=0.3', args.train_path,
        apply_log_transform=True, l1_reg=0.1, l2_reg=0.1, validation_test_size=0.3
    )

    print("\n--- Ablation Study Summary ---")
    baseline_rmse = results['Baseline (Current Solution)']
    for scenario, rmse in results.items():
        if scenario == 'Baseline (Current Solution)':
            print(f"  {scenario}: RMSE = {rmse:.4f} (Baseline)")
        else:
            diff = rmse - baseline_rmse
            impact = "improved" if diff < 0 else "degraded"
            print(f"  {scenario}: RMSE = {rmse:.4f} (Change vs Baseline: {diff:.4f}, {impact})")
    
    print("\n--- Conclusion on Most Impactful Component ---")
    
    # Analyze the impact to find the most impactful change
    most_impactful_change_name = ""
    largest_impact_value = 0.0 # Absolute difference from baseline
    
    for scenario, rmse in results.items():
        if scenario == 'Baseline (Current Solution)':
            continue
        
        diff = rmse - baseline_rmse
        absolute_diff = abs(diff)
        
        if absolute_diff > largest_impact_value:
            largest_impact_value = absolute_diff
            most_impactful_change_name = scenario.replace('Ablation: ', '')
            
    if most_impactful_change_name:
        final_rmse_for_impact = results['Ablation: ' + most_impactful_change_name]
        diff_for_impact = final_rmse_for_impact - baseline_rmse
        impact_type = "improved" if diff_for_impact < 0 else "degraded"
        
        print(f"The most impactful change observed was: {most_impactful_change_name}.")
        print(f"This modification {impact_type} the RMSE by {abs(diff_for_impact):.4f} compared to the baseline.")
    else:
        print("No single ablation showed a significantly dominant positive or negative impact among those tested.")


if __name__ == "__main__":
    main_ablation()
