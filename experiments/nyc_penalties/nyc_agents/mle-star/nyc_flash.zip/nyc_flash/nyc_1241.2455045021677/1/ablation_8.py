
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, KFold
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc
import os

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv'
N_SPLITS = 5 # Number of folds for K-Fold Target Encoding

# Global flags for ablation study to control components
_USE_K_FOLD_TARGET_ENCODING = True
_USE_LOG_TRANSFORM_TARGET = True
_L1_REGULARIZATION = 0.1
_L2_REGULARIZATION = 0.1

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> (pd.DataFrame, dict):
    """
    Performs feature engineering on the input DataFrame.
    """
    if encoder_dict is None:
        encoder_dict = {}
    if 'label_encoders' not in encoder_dict:
        encoder_dict['label_encoders'] = {}
    if 'freq_maps' not in encoder_dict:
        encoder_dict['freq_maps'] = {}
    if 'target_encode_maps' not in encoder_dict:
        encoder_dict['target_encode_maps'] = {}
    if 'global_target_mean' not in encoder_dict:
        encoder_dict['global_target_mean'] = None

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Standardized column names for convenience
    street_name_col_std = STREET_NAME_COL.replace(' ', '_').lower()
    violation_desc_col_std = VIOLATION_DESC_COL.replace(' ', '_').lower()
    target_column_std = None
    if TARGET_COLUMN.replace(' ', '_').lower() in df.columns:
        target_column_std = TARGET_COLUMN.replace(' ', '_').lower()

    # Handle missing values
    for col in [street_name_col_std, violation_desc_col_std]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # --- Frequency Encoding ---
    freq_cols = [street_name_col_std, violation_desc_col_std]
    for col in freq_cols:
        if col in df.columns:
            freq_col_name = col + '_freq_encoded'
            if is_training:
                freq_map = df[col].value_counts(normalize=True).to_dict()
                df[freq_col_name] = df[col].map(freq_map).fillna(0.0) # Fill unseen in training with 0.0
                encoder_dict['freq_maps'][col] = freq_map
            else:
                if col in encoder_dict['freq_maps']:
                    freq_map = encoder_dict['freq_maps'][col]
                    df[freq_col_name] = df[col].map(freq_map).fillna(0.0) # Fill unseen in test with 0.0
                else:
                    df[freq_col_name] = 0.0 # Default to 0.0 if no freq map was trained

    # --- Label Encoding for categorical features ---
    categorical_cols = [street_name_col_std, violation_desc_col_std]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict['label_encoders'][col] = le
            else:
                if col in encoder_dict['label_encoders']:
                    le = encoder_dict['label_encoders'][col]
                    known_classes = set(le.classes_)
                    df[col + '_encoded'] = df[col].apply(lambda s: le.transform([s])[0] if str(s) in known_classes else -1)
                else:
                    df[col + '_encoded'] = -1

    # --- K-Fold Target Encoding for street_violation_pair ---
    target_encoded_col_name = 'street_violation_pair_target_encoded' # Define outside for consistency in feature list filtering
    if _USE_K_FOLD_TARGET_ENCODING:
        pair_col_name = 'street_violation_pair'
        
        if street_name_col_std in df.columns and violation_desc_col_std in df.columns:
            df[pair_col_name] = df[street_name_col_std].astype(str) + '_' + df[violation_desc_col_std].astype(str)

            if is_training and target_column_std and target_column_std in df.columns:
                kf = KFold(n_splits=N_SPLITS, shuffle=True, random_state=42)
                df[target_encoded_col_name] = np.nan # Initialize with NaN

                global_target_mean = df[target_column_std].mean()
                encoder_dict['global_target_mean'] = global_target_mean

                for fold, (train_idx, val_idx) in enumerate(kf.split(df)):
                    X_train_fold = df.loc[train_idx]
                    X_val_fold_pairs = df.loc[val_idx, pair_col_name]

                    mean_map = X_train_fold.groupby(pair_col_name)[target_column_std].mean()
                    df.loc[val_idx, target_encoded_col_name] = X_val_fold_pairs.map(mean_map).fillna(global_target_mean)

                encoder_dict['target_encode_maps'][pair_col_name] = df.groupby(pair_col_name)[target_column_std].mean().to_dict()

            elif not is_training:
                if pair_col_name in encoder_dict['target_encode_maps'] and encoder_dict['global_target_mean'] is not None:
                    mean_map = encoder_dict['target_encode_maps'][pair_col_name]
                    global_target_mean = encoder_dict['global_target_mean']
                    df[target_encoded_col_name] = df[pair_col_name].map(mean_map).fillna(global_target_mean)
                else:
                    df[target_encoded_col_name] = encoder_dict['global_target_mean'] if encoder_dict['global_target_mean'] is not None else 0.0
            
            # Drop the temporary 'street_violation_pair' column if it was created
            if pair_col_name in df.columns:
                df = df.drop(columns=[pair_col_name])
    else:
        # If target encoding is disabled, ensure the column is not created or added
        # And ensure that it's not in `features` later.
        if target_encoded_col_name in df.columns:
             df = df.drop(columns=[target_encoded_col_name])

    # Log transform target if present, good for count data
    if _USE_LOG_TRANSFORM_TARGET and target_column_std and target_column_std in df.columns and is_training:
        df[target_column_std] = np.log1p(df[target_column_std])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None) -> (pd.DataFrame, dict):
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series) -> lgb.Booster:
    """
    Trains a LightGBM model.
    """
    # LightGBM expects feature names as strings
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'regression_l1',  # MAE objective
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': _L1_REGULARIZATION, # Use global flag
        'lambda_l2': _L2_REGULARIZATION, # Use global flag
        'num_leaves': 31,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)]) # Use callbacks for early stopping

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_ablation(ablation_name: str, use_k_fold_te: bool, use_log_transform: bool, l1_reg: float, l2_reg: float):
    global _USE_K_FOLD_TARGET_ENCODING, _USE_LOG_TRANSFORM_TARGET, _L1_REGULARIZATION, _L2_REGULARIZATION

    # Set global flags for this ablation run
    _USE_K_FOLD_TARGET_ENCODING = use_k_fold_te
    _USE_LOG_TRANSFORM_TARGET = use_log_transform
    _L1_REGULARIZATION = l1_reg
    _L2_REGULARIZATION = l2_reg

    print(f"\n--- Running Ablation: {ablation_name} ---")
    
    # Reload and preprocess data for current ablation settings
    # This is crucial because feature engineering depends on global flags
    df_2022_raw, encoder_dict = load_and_preprocess_data('./input/violations_per_street_2022.csv', is_training=True)

    street_name_col_std = STREET_NAME_COL.replace(' ', '_').lower()
    violation_desc_col_std = VIOLATION_DESC_COL.replace(' ', '_').lower()
    target_column_std = TARGET_COLUMN.replace(' ', '_').lower()

    df_2022_raw['group_id'] = df_2022_raw[street_name_col_std].astype(str) + '_' + \
                               df_2022_raw[violation_desc_col_std].astype(str)
    
    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])

    # Dynamically define features based on what was actually created
    features = [col for col in df_train_raw.columns if col not in [target_column_std, street_name_col_std, violation_desc_col_std]]
    
    X_train = df_train_raw[features]
    y_train = df_train_raw[target_column_std]

    X_val = df_val_raw[features]
    y_val = df_val_raw[target_column_std]

    # Train model
    model = train_model(X_train, y_train, X_val, y_val)

    # Predict on validation set
    val_predictions_log = model.predict(X_val)
    
    # Inverse transform logic
    if _USE_LOG_TRANSFORM_TARGET:
        val_predictions = np.expm1(val_predictions_log)
        y_val_original_scale = np.expm1(y_val)
    else:
        val_predictions = val_predictions_log
        y_val_original_scale = y_val # Already in original scale

    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(y_val_original_scale, val_predictions)
    print(f"Validation RMSE for {ablation_name}: {final_validation_rmse}")
    
    del df_2022_raw, df_train_raw, df_val_raw, X_train, y_train, X_val, y_val, model
    gc.collect()
    
    return final_validation_rmse

def main():
    # Store results to find the most contributing part
    results = {}

    # BASELINE RUN
    results['Baseline'] = run_ablation(
        "Baseline (All features & settings enabled)",
        use_k_fold_te=True,
        use_log_transform=True,
        l1_reg=0.1,
        l2_reg=0.1
    )

    # ABLATION 1: No K-Fold Target Encoding
    results['No K-Fold Target Encoding'] = run_ablation(
        "Ablation: No K-Fold Target Encoding",
        use_k_fold_te=False,
        use_log_transform=True,
        l1_reg=0.1,
        l2_reg=0.1
    )

    # ABLATION 2: No Log Transform on Target
    results['No Log Transform on Target'] = run_ablation(
        "Ablation: No Log Transform on Target",
        use_k_fold_te=True,
        use_log_transform=False,
        l1_reg=0.1,
        l2_reg=0.1
    )

    # ABLATION 3: No L1/L2 Regularization
    results['No L1/L2 Regularization'] = run_ablation(
        "Ablation: No L1/L2 Regularization",
        use_k_fold_te=True,
        use_log_transform=True,
        l1_reg=0.0,
        l2_reg=0.0
    )

    print("\n--- Ablation Study Summary ---")
    baseline_rmse = results['Baseline']
    print(f"Baseline RMSE: {baseline_rmse:.4f}")

    contributions = {}
    for name, rmse in results.items():
        if name != 'Baseline':
            diff = rmse - baseline_rmse
            contributions[name] = diff
            
    print("\n--- Contribution Analysis ---")
    most_impactful_component = None
    largest_abs_impact = 0.0
    impact_description = ""

    for name, diff in contributions.items():
        abs_diff = abs(diff)
        if diff > 0: # Removal increased RMSE, meaning the component was beneficial
            print(f"  '{name}' removal increased RMSE by {diff:.4f}. This component was beneficial.")
        elif diff < 0: # Removal decreased RMSE, meaning the component was detrimental
            print(f"  '{name}' removal decreased RMSE by {-diff:.4f}. This component was detrimental.")
        else:
            print(f"  '{name}' removal had no measurable impact on RMSE.")
            
        if abs_diff > largest_abs_impact:
            largest_abs_impact = abs_diff
            most_impactful_component = name
            if diff > 0:
                impact_description = f"beneficial (removal increased RMSE by {diff:.4f})"
            elif diff < 0:
                impact_description = f"detrimental (removal decreased RMSE by {-diff:.4f})"
            else:
                impact_description = "neutral (no measurable impact on RMSE)"

    if most_impactful_component:
        print(f"\nThe part that had the most significant impact on the overall performance is: '{most_impactful_component}'. Its impact was {impact_description}.")
    else:
        print("\nNo single component's contribution could be determined as most impactful based on this study.")


if __name__ == "__main__":
    main()
