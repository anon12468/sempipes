
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import catboost as cb # Although imported, not used in the final version.
import os
import lightgbm as lgb
import gc

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv'

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Performs feature engineering on the input DataFrame, introducing a smoothed target-encoded
    interaction feature.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Standardized column names for consistency
    street_col = STREET_NAME_COL.replace(' ', '_').lower()
    violation_col = VIOLATION_DESC_COL.replace(' ', '_').lower()
    target_col = TARGET_COLUMN.replace(' ', '_').lower() # Assuming TARGET_COLUMN also needs standardization

    # Handle missing values for individual features
    for col in [street_col, violation_col]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Create interaction feature: street_violation_combo
    combo_col_name = 'street_violation_combo'
    if street_col in df.columns and violation_col in df.columns:
        df[combo_col_name] = df[street_col].astype(str) + '_' + df[violation_col].astype(str)
        # Ensure the combo feature also has no NaNs
        df[combo_col_name] = df[combo_col_name].fillna('unknown_unknown').astype(str)

    # Label Encoding for individual categorical features (original logic)
    categorical_cols = [street_col, violation_col]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col + '_le'] = le # Store LabelEncoder with a unique key
            else:
                if col + '_le' in encoder_dict:
                    le = encoder_dict[col + '_le']
                    # Map existing categories, use -1 for unseen categories
                    # Use a lambda function to handle unseen labels gracefully, mapping them to -1
                    df[col + '_encoded'] = df[col].apply(lambda s: le.transform([s])[0] if s in le.classes_ else -1)
                else:
                    df[col + '_encoded'] = -1 # Default for entirely new categories if no encoder

    # Smoothed Target Encoding for the new interaction feature
    combo_target_encoded_col_name = combo_col_name + '_target_encoded'
    SMOOTHING_FACTOR = 100 # A hyperparameter for smoothing, can be tuned

    if combo_col_name in df.columns:
        if is_training:
            if target_col in df.columns:
                # Calculate global mean of the target before any transformations (like log1p)
                global_mean = df[target_col].mean()
                encoder_dict[combo_col_name + '_global_mean'] = global_mean # Store global mean for inference

                # Group by interaction feature to calculate counts and mean target for each category
                agg = df.groupby(combo_col_name)[target_col].agg(['count', 'mean'])
                # Apply smoothing formula
                smoothed_map = (agg['count'] * agg['mean'] + SMOOTHING_FACTOR * global_mean) / (agg['count'] + SMOOTHING_FACTOR)
                df[combo_target_encoded_col_name] = df[combo_col_name].map(smoothed_map)
                encoder_dict[combo_col_name + '_target_map'] = smoothed_map.to_dict() # Store the mapping
            else:
                # Should not happen in training if target encoding is intended, but for safety
                df[combo_target_encoded_col_name] = 0 # Default to 0 or NaN if target is missing
        else: # Inference phase
            if combo_col_name + '_target_map' in encoder_dict and combo_col_name + '_global_mean' in encoder_dict:
                target_map = encoder_dict[combo_col_name + '_target_map']
                global_mean = encoder_dict[combo_col_name + '_global_mean']
                # Apply stored map, use global mean for unseen categories
                df[combo_target_encoded_col_name] = df[combo_col_name].map(target_map).fillna(global_mean)
            else:
                # If encoder info is missing during inference
                df[combo_target_encoded_col_name] = 0 # Default to 0

    # Log transform target if present, good for count data
    # This is placed AFTER target encoding to ensure target encoding uses the original scale of the target.
    if target_col in df.columns and is_training:
        df[target_col] = np.log1p(df[target_col])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series) -> lgb.Booster:
    """
    Trains a LightGBM model.
    """
    # LightGBM expects feature names as strings
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'poisson',  # Changed objective to 'poisson' as per plan
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 63,  # Increased num_leaves from 31 to 63 as per plan
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)]) # Use callbacks for early stopping

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional: Path to the 2023 test/evaluation data CSV.')
    args = parser.parse_args()

    print(f"Loading training data from: {args.train_path}")
    df_2022_raw, encoder_dict = load_and_preprocess_data(args.train_path, is_training=True)

    # Standardized column names for consistency
    street_col_std = STREET_NAME_COL.replace(' ', '_').lower()
    violation_col_std = VIOLATION_DESC_COL.replace(' ', '_').lower()
    target_col_std = TARGET_COLUMN.replace(' ', '_').lower()
    combo_col_name = 'street_violation_combo' # This is the string column that caused the error

    # Split 2022 data for training and validation
    # Use grouped holdout for (street_name, violation_type) pairs
    # Create a unique identifier for splitting
    df_2022_raw['group_id'] = df_2022_raw[street_col_std] + '_' + \
                               df_2022_raw[violation_col_std]

    # Get unique groups
    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    # Drop the temporary group_id
    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    # Define features and target
    # FIX: Exclude the original string 'street_violation_combo' column from features
    features_to_exclude = [target_col_std, street_col_std, violation_col_std, combo_col_name]
    features = [col for col in df_train_raw.columns if col not in features_to_exclude]

    # Prepare training data
    X_train = df_train_raw[features]
    y_train = df_train_raw[target_col_std]

    # Prepare validation data - CRITICAL FIX HERE: Extract y_val *before* any potential dropping or mismatch
    X_val = df_val_raw[features]
    y_val = df_val_raw[target_col_std] # This ensures y_val is correctly assigned from the raw df_val_raw

    print("Training model...")
    model = train_model(X_train, y_train, X_val, y_val)

    # Predict on validation set for performance reporting
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log) # Inverse transform
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(np.expm1(y_val), val_predictions) # Calculate RMSE on original scale
    print(f"Final Validation Performance: {final_validation_rmse}")

    # If a test path is provided, generate predictions
    if args.test_path:
        print(f"Loading test data from: {args.test_path}")
        df_test_raw, _ = load_and_preprocess_data(args.test_path, is_training=False, encoder_dict=encoder_dict)

        # Ensure test data has the same features as training data
        test_features = [col for col in features if col in df_test_raw.columns]
        X_test = df_test_raw[test_features]

        # Align columns - crucial for consistent predictions
        # Add missing columns to X_test with 0, remove extra columns
        missing_cols = set(X_train.columns) - set(X_test.columns)
        for c in missing_cols:
            X_test[c] = 0
        extra_cols = set(X_test.columns) - set(X_train.columns)
        X_test = X_test.drop(columns=list(extra_cols))
        X_test = X_test[X_train.columns] # Ensure column order is the same

        print("Generating predictions for test data...")
        test_predictions_log = model.predict(X_test)
        test_predictions = np.expm1(test_predictions_log) # Inverse transform
        test_predictions[test_predictions < 0] = 0 # Clip negative predictions
        test_predictions = np.round(test_predictions).astype(int) # Round to nearest integer

        # Create submission file
        submission_df = pd.DataFrame({
            STREET_NAME_COL: df_test_raw[street_col_std],
            VIOLATION_DESC_COL: df_test_raw[violation_col_std],
            PREDICTED_COUNT_COL: test_predictions
        })
        # Original column names for submission
        submission_df.columns = [STREET_NAME_COL, VIOLATION_DESC_COL, PREDICTED_COUNT_COL]

        submission_df.to_csv(OUTPUT_SUBMISSION_FILE, index=False)
        print(f"Submission file '{OUTPUT_SUBMISSION_FILE}' created successfully.")

        # If test_path contains 'violation_count', calculate RMSE
        if target_col_std in df_test_raw.columns:
            y_test_true = np.expm1(df_test_raw[target_col_std]) # Inverse log transform for actual values
            test_rmse = calculate_rmse(y_test_true, test_predictions)
            print(f"RMSE on provided test/evaluation data: {test_rmse}")

            # Report unseen key pairs
            train_keys = df_2022_raw[street_col_std] + '_' + df_2022_raw[violation_col_std]
            test_keys = df_test_raw[street_col_std] + '_' + df_test_raw[violation_col_std]

            unseen_keys_count = (~test_keys.isin(train_keys)).sum()
            total_test_keys = len(test_keys)
            print(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {unseen_keys_count} out of {total_test_keys}")
            print("Unseen pairs are handled by the model's ability to generalize based on encoded features and numerical interaction features, "
                  "and by assigning -1 for unknown categories during Label Encoding transform.")

    gc.collect()

if __name__ == "__main__":
    main()
