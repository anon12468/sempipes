
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import lightgbm as lgb
import gc
import os

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv'

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Performs feature engineering on the input DataFrame.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df_copy = df.copy() # Work on a copy to avoid modifying the original DataFrame directly and potential SettingWithCopyWarning

    # Standardize column names early for consistency
    df_copy.columns = df_copy.columns.str.replace(' ', '_').str.lower()

    # Standardized column names
    street_name_col_std = STREET_NAME_COL.replace(' ', '_').lower()
    violation_desc_col_std = VIOLATION_DESC_COL.replace(' ', '_').lower()
    target_column_std = TARGET_COLUMN.replace(' ', '_').lower() # Ensure target column is also standardized

    # Handle missing values for specified categorical columns
    for col in [street_name_col_std, violation_desc_col_std]:
        if col in df_copy.columns: # Check if the standardized column name exists
            df_copy[col] = df_copy[col].fillna('unknown').astype(str)

    # Cross-validated Target Encoding for categorical features
    categorical_cols_to_target_encode = [street_name_col_std, violation_desc_col_std]

    # Calculate global mean for smoothing and handling unseen categories during inference
    global_mean_target = 0.0
    if is_training and target_column_std in df_copy.columns:
        global_mean_target = df_copy[target_column_std].mean()
        encoder_dict['global_mean_target'] = global_mean_target
    elif 'global_mean_target' in encoder_dict:
        global_mean_target = encoder_dict['global_mean_target']

    for col in categorical_cols_to_target_encode:
        if col in df_copy.columns: # Check if the standardized column name exists
            encoded_col_name = f'{col}_target_encoded'
            if is_training and target_column_std in df_copy.columns:
                # Calculate mean target for each category
                mean_mapping = df_copy.groupby(col)[target_column_std].mean().to_dict()

                # Apply the target encoding. Fill any categories not present in the mapping
                # with the global mean.
                df_copy[encoded_col_name] = df_copy[col].map(mean_mapping).fillna(global_mean_target)
                encoder_dict[f'{col}_target_encoder'] = mean_mapping

            else: # is_training is False (inference mode)
                if f'{col}_target_encoder' in encoder_dict:
                    mean_mapping = encoder_dict[f'{col}_target_encoder']
                    # Apply stored mapping, fill unseen categories with the global mean from training
                    df_copy[encoded_col_name] = df_copy[col].map(mean_mapping).fillna(global_mean_target)
                else:
                    # If no encoder was fitted for this column (e.g., column not in training data),
                    # assign global mean as a fallback.
                    df_copy[encoded_col_name] = global_mean_target

    # Generate additional domain-inspired interaction features
    street_te_col = f'{street_name_col_std}_target_encoded'
    violation_te_col = f'{violation_desc_col_std}_target_encoded'

    if street_te_col in df_copy.columns and violation_te_col in df_copy.columns:
        street_te = df_copy[street_te_col]
        violation_te = df_copy[violation_te_col]

        # Multiplicative interaction
        df_copy['street_violation_te_interaction'] = street_te * violation_te

        # Additive interaction
        df_copy['street_violation_te_sum'] = street_te + violation_te

        # Ratio interactions (handle division by zero by adding a small epsilon)
        epsilon = 1e-6
        df_copy['street_violation_te_ratio'] = street_te / (violation_te + epsilon)
        df_copy['violation_street_te_ratio'] = violation_te / (street_te + epsilon)

        # Another simple interaction: difference
        df_copy['street_violation_te_diff'] = street_te - violation_te

    return df_copy, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df, is_training=is_training, encoder_dict=encoder_dict)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series) -> lgb.Booster:
    """
    Trains a LightGBM model.
    """
    # LightGBM expects feature names as strings
    # Replace invalid characters in column names
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'regression_l1',  # MAE objective - predicts raw values
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 31,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)])

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional: Path to the 2023 test/evaluation data CSV.')
    args = parser.parse_args()

    print(f"Loading training data from: {args.train_path}")
    df_2022_processed, encoder_dict = load_and_preprocess_data(args.train_path, is_training=True)

    # Standardized column names for internal use
    street_name_col_std = STREET_NAME_COL.replace(' ', '_').lower()
    violation_desc_col_std = VIOLATION_DESC_COL.replace(' ', '_').lower()
    target_column_std = TARGET_COLUMN.replace(' ', '_').lower()

    # Split 2022 data for training and validation
    # Use grouped holdout for (street_name, violation_type) pairs
    # Create a unique identifier for splitting
    df_2022_processed['group_id'] = df_2022_processed[street_name_col_std] + '_' + \
                               df_2022_processed[violation_desc_col_std]

    # Get unique groups
    unique_groups = df_2022_processed['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train = df_2022_processed[df_2022_processed['group_id'].isin(train_groups)].copy()
    df_val = df_2022_processed[df_2022_processed['group_id'].isin(val_groups)].copy()

    # Drop the temporary group_id
    df_train = df_train.drop(columns=['group_id'])
    df_val = df_val.drop(columns=['group_id'])

    # Define features and target
    # Ensure features exclude the original, untransformed street name and violation description,
    # as well as the target itself.
    features = [col for col in df_train.columns if col not in [target_column_std, street_name_col_std, violation_desc_col_std]]

    # Prepare training data
    X_train = df_train[features]
    y_train = df_train[target_column_std] # y_train is on raw scale

    # Prepare validation data
    X_val = df_val[features]
    y_val = df_val[target_column_std] # y_val is on raw scale

    print("Training model...")
    model = train_model(X_train, y_train, X_val, y_val)

    # Predict on validation set for performance reporting
    val_predictions = model.predict(X_val) # Predictions are on raw scale
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions
    val_predictions = np.round(val_predictions).astype(int) # Round to nearest integer for counts

    # Calculate RMSE on original scale. y_val is already on original scale.
    final_validation_rmse = calculate_rmse(y_val, val_predictions)
    print(f"Final Validation Performance: {final_validation_rmse}")

    # If a test path is provided, generate predictions
    if args.test_path:
        print(f"Loading test data from: {args.test_path}")
        df_test_processed, _ = load_and_preprocess_data(args.test_path, is_training=False, encoder_dict=encoder_dict)

        # Ensure test data has the same features as training data
        test_features = [col for col in features if col in df_test_processed.columns]
        X_test = df_test_processed[test_features]

        # Align columns - crucial for consistent predictions
        # Add missing columns to X_test with 0, remove extra columns
        missing_cols = set(X_train.columns) - set(X_test.columns)
        for c in missing_cols:
            X_test[c] = 0
        extra_cols = set(X_test.columns) - set(X_train.columns)
        X_test = X_test.drop(columns=list(extra_cols))
        X_test = X_test[X_train.columns] # Ensure column order is the same

        print("Generating predictions for test data...")
        test_predictions = model.predict(X_test) # Predictions are on raw scale
        test_predictions[test_predictions < 0] = 0 # Clip negative predictions
        test_predictions = np.round(test_predictions).astype(int) # Round to nearest integer

        # Create submission file
        submission_df = pd.DataFrame({
            STREET_NAME_COL: df_test_processed[street_name_col_std],
            VIOLATION_DESC_COL: df_test_processed[violation_desc_col_std],
            PREDICTED_COUNT_COL: test_predictions
        })
        # Original column names for submission (header)
        submission_df.columns = [STREET_NAME_COL, VIOLATION_DESC_COL, PREDICTED_COUNT_COL]

        submission_df.to_csv(OUTPUT_SUBMISSION_FILE, index=False)
        print(f"Submission file '{OUTPUT_SUBMISSION_FILE}' created successfully.")

        # If target_column_std exists in the test data, calculate RMSE
        if target_column_std in df_test_processed.columns:
            y_test_true = df_test_processed[target_column_std] # Target is on raw scale, no inverse transform needed
            test_rmse = calculate_rmse(y_test_true, test_predictions)
            print(f"RMSE on provided test/evaluation data: {test_rmse}")

            # Report unseen key pairs
            train_keys = df_2022_processed[street_name_col_std] + '_' + df_2022_processed[violation_desc_col_std]
            test_keys = df_test_processed[street_name_col_std] + '_' + df_test_processed[violation_desc_col_std]

            # Count rows in test_keys that are NOT present in train_keys
            unseen_keys_count = (~test_keys.isin(train_keys)).sum()
            total_test_keys = len(test_keys)
            print(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {unseen_keys_count} out of {total_test_keys}")
            print("Unseen pairs are handled by the model's ability to generalize based on encoded features and numerical interaction features, "
                  "and by assigning the global mean during target encoding for unseen categories.")

    gc.collect()

if __name__ == "__main__":
    main()
