
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc

# Define constants from the original solution
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv' # Not used in ablation, but kept for completeness

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Performs feature engineering on the input DataFrame. This is the _engineer_features from the provided solution.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Handle missing values
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Label Encoding for categorical features
    categorical_cols = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col] = le
            else:
                if col in encoder_dict:
                    # Use transform for existing categories, map unknown to -1
                    df[col + '_encoded'] = df[col].map(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else -1)
                else:
                    df[col + '_encoded'] = -1 # Assign a default for entirely new categories if no encoder

    # Log transform target if present, good for count data
    if TARGET_COLUMN in df.columns and is_training:
        df[TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    return df, encoder_dict

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_experiment(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series,
                   description: str, base_params: dict, params_override: dict, eval_metric_override: str) -> float:
    """
    Runs a single LightGBM experiment with specified parameters and returns validation RMSE.
    """
    print(f"\n--- Running Experiment: {description} ---")
    current_params = base_params.copy()
    current_params.update(params_override)

    # LightGBM expects feature names as strings and sanitized names
    original_train_cols = X_train.columns
    X_train_sanitized = X_train.copy()
    X_val_sanitized = X_val.copy()
    X_train_sanitized.columns = ["".join(c if c.isalnum() else "_" for c in str(x)) for x in original_train_cols]
    X_val_sanitized.columns = ["".join(c if c.isalnum() else "_" for c in str(x)) for x in original_train_cols]

    categorical_features_names = []
    if 'street_name_encoded' in original_train_cols:
        categorical_features_names.append("street_name_encoded")
    if 'violation_description_encoded' in original_train_cols:
        categorical_features_names.append("violation_description_encoded")

    model = lgb.LGBMRegressor(**current_params)

    model.fit(X_train_sanitized, y_train,
              eval_set=[(X_val_sanitized, y_val)],
              eval_metric=eval_metric_override,
              callbacks=[lgb.early_stopping(100, verbose=False)], # Using fixed early stopping rounds
              categorical_feature=categorical_features_names)

    val_predictions_log = model.predict(X_val_sanitized)
    val_predictions = np.expm1(val_predictions_log) # Inverse transform
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    current_rmse = calculate_rmse(np.expm1(y_val), val_predictions) # Calculate RMSE on original scale
    print(f"Validation RMSE: {current_rmse:.4f}")
    return current_rmse

def main_ablation_study():
    # Setup: Load and preprocess data once
    train_path = './input/violations_per_street_2022.csv'
    df_2022_raw, encoder_dict = load_and_preprocess_data(train_path, is_training=True)

    # Split 2022 data for training and validation using grouped holdout
    df_2022_raw['group_id'] = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    # Define features and target
    features = [col for col in df_train_raw.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]]

    X_train_global = df_train_raw[features]
    y_train_global = df_train_raw[TARGET_COLUMN]
    X_val_global = df_val_raw[features]
    y_val_global = df_val_raw[TARGET_COLUMN]

    # Baseline LightGBM parameters (from the provided solution)
    base_params = {
        'objective': 'poisson',
        'metric': 'rmse', # Baseline metric for internal optimization
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 63,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }
    base_eval_metric = 'rmse' # Metric for early stopping evaluation

    # --- Run Baseline ---
    baseline_rmse = run_experiment(X_train_global, y_train_global, X_val_global, y_val_global,
                                   "Baseline Model", base_params, {}, base_eval_metric)
    
    results = {'Baseline': {'rmse': baseline_rmse, 'impact': 0.0}}

    # --- Ablation 1: Align LGBM metric/eval_metric with objective (poisson) ---
    # Change both 'metric' in params and 'eval_metric' in fit to 'poisson'
    desc1 = "Ablation 1: Align LGBM metric and eval_metric with objective (poisson)"
    params1_override = {'metric': 'poisson'}
    eval_metric1_override = 'poisson'
    rmse1 = run_experiment(X_train_global, y_train_global, X_val_global, y_val_global,
                           desc1, base_params, params1_override, eval_metric1_override)
    results[desc1] = {'rmse': rmse1, 'impact': rmse1 - baseline_rmse}

    # --- Ablation 2: Remove all sampling strategies ---
    # Set feature_fraction, bagging_fraction to 1.0 and bagging_freq to 0
    desc2 = "Ablation 2: Disable feature/bagging fraction and bagging frequency"
    params2_override = {'feature_fraction': 1.0, 'bagging_fraction': 1.0, 'bagging_freq': 0}
    rmse2 = run_experiment(X_train_global, y_train_global, X_val_global, y_val_global,
                           desc2, base_params, params2_override, base_eval_metric)
    results[desc2] = {'rmse': rmse2, 'impact': rmse2 - baseline_rmse}

    # --- Ablation 3: Introduce max_depth parameter ---
    # Set max_depth to 7 (a common value)
    desc3 = "Ablation 3: Set max_depth=7"
    params3_override = {'max_depth': 7}
    rmse3 = run_experiment(X_train_global, y_train_global, X_val_global, y_val_global,
                           desc3, base_params, params3_override, base_eval_metric)
    results[desc3] = {'rmse': rmse3, 'impact': rmse3 - baseline_rmse}

    # --- Determine Most Impactful ---
    print("\n--- Ablation Study Conclusion ---")

    best_rmse_overall = baseline_rmse
    best_config_name = 'Baseline'
    for desc, data in results.items():
        if data['rmse'] < best_rmse_overall:
            best_rmse_overall = data['rmse']
            best_config_name = desc

    print(f"The overall best RMSE achieved was {best_rmse_overall:.4f} by the '{best_config_name}' configuration.")

    if best_config_name == 'Baseline':
        worst_impact_degradation = 0.0
        most_degrading_part = 'None'
        for desc, data in results.items():
            if desc == 'Baseline':
                continue
            if data['impact'] > worst_impact_degradation:
                worst_impact_degradation = data['impact']
                most_degrading_part = desc
        if most_degrading_part != 'None':
            print(f"The baseline model's original configuration contributes the most positively to performance. Modifying it to '{most_degrading_part}' resulted in the largest degradation of {worst_impact_degradation:.4f} RMSE.")
        else:
            print("All ablations had negligible impact, suggesting the tested components are robust or not critical drivers of performance in this setup.")
    else:
        print(f"The most impactful positive contribution to overall performance was from '{best_config_name}', leading to an RMSE improvement of {abs(results[best_config_name]['impact']):.4f} compared to the baseline.")

    gc.collect()

if __name__ == "__main__":
    main_ablation_study()
