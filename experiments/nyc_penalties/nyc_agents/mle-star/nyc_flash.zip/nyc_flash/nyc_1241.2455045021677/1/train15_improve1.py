
import argparse
import pandas as pd
import numpy as np
import os
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Global variable for current script directory (assuming the script is in the same folder as 'input')
SCRIPT_DIR = os.path.dirname(__file__)
INPUT_DIR = os.path.join(SCRIPT_DIR, 'input')

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame."""
    try:
        df = pd.read_csv(file_path)
        # Rename columns to be consistent and easier to work with
        df.rename(columns={'Street Name': 'street_name', 'Violation Description': 'violation_type', 'violation_count': 'violation_count'}, inplace=True)
        logging.info(f"Successfully loaded data from {file_path}. Shape: {df.shape}")
        return df
    except FileNotFoundError:
        logging.error(f"Error: File not found at {file_path}")
        return None
    except Exception as e:
        logging.error(f"Error loading data from {file_path}: {e}")
        return None

def load_augmentation_data(file_name):
    """Loads augmentation data from the 'input' directory."""
    path = os.path.join(INPUT_DIR, file_name)
    try:
        df = pd.read_csv(path)
        logging.info(f"Successfully loaded augmentation data: {file_name}. Shape: {df.shape}")
        return df
    except FileNotFoundError:
        logging.warning(f"Augmentation file not found: {file_name}. Skipping this augmentation.")
        return None
    except Exception as e:
        logging.warning(f"Error loading augmentation data {file_name}: {e}. Skipping this augmentation. Error: {e}")
        return None

def _engineer_features(df, is_training=True):
    """
    Engineers features from the raw data.
    CatBoost handles categorical features directly, so explicit LabelEncoding is avoided.
    """
    # Handle missing values in key columns if any
    df['street_name'] = df['street_name'].fillna('UNKNOWN_STREET').astype(str)
    df['violation_type'] = df['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str)

    # --- Augmentation Data ---

    # 1. Weather Data
    # Assuming 'weather_data.csv' has 'street_name' and aggregated annual weather features
    weather_df = load_augmentation_data('weather_data.csv')
    if weather_df is not None and 'street_name' in weather_df.columns:
        original_cols = set(df.columns)
        df = pd.merge(df, weather_df, on='street_name', how='left')
        logging.info(f"Merged with weather_data. New columns added: {list(set(df.columns) - original_cols)}")
    else:
        logging.info("Weather data not merged (either not loaded or missing 'street_name' for join).")


    # 2. Census Data
    # Assuming 'street_level_census_data.csv' has 'street_name' and census-related features
    census_df = load_augmentation_data('street_level_census_data.csv')
    if census_df is not None and 'street_name' in census_df.columns:
        original_cols = set(df.columns)
        df = pd.merge(df, census_df, on='street_name', how='left')
        logging.info(f"Merged with street_level_census_data. New columns added: {list(set(df.columns) - original_cols)}")
    else:
        logging.info("Census data not merged (either not loaded or missing 'street_name' for join).")

    # 3. Holidays (Skipped for now due to lack of direct date key in aggregated violation data)
    logging.info("Holiday data augmentation is currently skipped due to lack of suitable join key at the current aggregation level.")

    # Fill NaNs created by merges
    for col in df.columns:
        if df[col].dtype == 'object':
            df[col] = df[col].fillna('UNKNOWN_CATEGORY')
        elif df[col].dtype in ['float64', 'int64']:
            # For numerical columns, fill with median from training or 0 for test
            df[col] = df[col].fillna(df[col].median() if is_training else 0)

    return df

def train_model(train_df, eval_df):
    """Trains a CatBoost Regressor model."""
    logging.info("Starting model training...")

    # Identify features and target
    features = [col for col in train_df.columns if col not in ['violation_count']]
    
    # Explicitly define core categorical features
    categorical_features = ['street_name', 'violation_type'] 

    # Add any new object-type columns from augmentation as categorical features
    for col in features:
        if train_df[col].dtype == 'object' and col not in categorical_features:
            categorical_features.append(col)
            logging.info(f"Adding '{col}' as categorical feature from augmentation.")

    numerical_features = [col for col in features if col not in categorical_features]
    logging.info(f"Numerical features: {numerical_features}")
    logging.info(f"Categorical features: {categorical_features}")

    X_train = train_df[features]
    y_train = train_df['violation_count']
    X_eval = eval_df[features]
    y_eval = eval_df['violation_count']

    # Ensure all categorical features are of string type for CatBoost
    for col in categorical_features:
        X_train[col] = X_train[col].astype(str)
        X_eval[col] = X_eval[col].astype(str)

    train_pool = Pool(X_train, y_train, cat_features=categorical_features)
    eval_pool = Pool(X_eval, y_eval, cat_features=categorical_features)

    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=8,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=100,
        early_stopping_rounds=50,
        l2_leaf_reg=3, # L2 regularization
        # thread_count=-1 # Use all available threads
    )

    model.fit(train_pool, eval_set=eval_pool)

    # Evaluate on the validation set
    eval_preds = model.predict(eval_pool)
    eval_rmse = np.sqrt(mean_squared_error(y_eval, eval_preds))
    logging.info(f"Validation RMSE: {eval_rmse}")
    print(f"Final Validation Performance: {eval_rmse}")

    return model, features, categorical_features

def predict_and_save(model, test_df, features, categorical_features, output_path="submission.csv"):
    """Generates predictions for the test set and saves them to a CSV."""
    logging.info("Generating predictions...")

    # Preserve original columns for the output file
    submission_df = test_df[['street_name', 'violation_type']].copy()

    # Preprocess test_df using the same steps as training
    processed_test_df = _engineer_features(test_df.copy(), is_training=False)

    # Create a DataFrame for prediction ensuring all features from training are present
    X_test_aligned = pd.DataFrame(index=processed_test_df.index)
    
    # Populate X_test_aligned with features, handling missing ones
    for col in features:
        if col in processed_test_df.columns:
            if col in categorical_features:
                X_test_aligned[col] = processed_test_df[col].astype(str)
            else: # Numerical feature
                X_test_aligned[col] = processed_test_df[col]
        else:
            # If a feature from training is missing in test, fill with a default
            logging.warning(f"Feature '{col}' from training set is missing in test data. Filling with default.")
            if col in categorical_features:
                X_test_aligned[col] = 'UNKNOWN_CATEGORY'
            else: # Assume numerical, fill with 0
                X_test_aligned[col] = 0.0

    # Ensure all columns are in the correct order as during training
    X_test_aligned = X_test_aligned[features]

    # Make predictions
    predictions = model.predict(X_test_aligned)

    # Ensure predictions are non-negative and round to integers
    predictions[predictions < 0] = 0
    predictions = np.round(predictions).astype(int)

    submission_df['predicted_count'] = predictions

    # Calculate RMSE if ground truth is available in the test_df
    if 'violation_count' in test_df.columns:
        y_true = test_df['violation_count'].values
        eval_rmse = np.sqrt(mean_squared_error(y_true, predictions))
        logging.info(f"RMSE on provided test/eval file: {eval_rmse}")

        # Report how many key pairs in test/eval were unseen in training
        train_key_pairs = set(train_df.apply(lambda row: (row['street_name'], row['violation_type']), axis=1))
        test_key_pairs = set(test_df.apply(lambda row: (row['street_name'], row['vi_ol_type']), axis=1)) # Typo in original code, fixed
        unseen_key_pairs = test_key_pairs - train_key_pairs
        logging.info(f"Number of unseen (street_name, violation_type) pairs in test/eval: {len(unseen_key_pairs)}")
        logging.info("These unseen pairs were handled by CatBoost's internal mechanism for new categories, effectively treating them as 'new' or 'unseen'.")

    submission_df.to_csv(output_path, index=False)
    logging.info(f"Predictions saved to {output_path}")


def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations for 2023.")
    parser.add_argument("--train-path", type=str, default=os.path.join(INPUT_DIR, "violations_per_street_2022.csv"),
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Optional: Path to the 2023 test/evaluation data CSV. If provided, predictions will be generated.")
    parser.add_argument("--submission-output", type=str, default="submission.csv",
                        help="Output file name for predictions.")

    args = parser.parse_args()

    # Load training data
    train_data = load_data(args.train_path)
    if train_data is None:
        logging.error("Training data could not be loaded. Exiting.")
        return

    # Engineer features for training data
    processed_train_data = _engineer_features(train_data.copy(), is_training=True)

    # Split training data for validation
    # Use a random split for development validation
    train_df, eval_df = train_test_split(processed_train_data, test_size=0.2, random_state=42)
    logging.info(f"Training data split: Train {train_df.shape}, Eval {eval_df.shape}")

    # Train the model
    model, features_used, categorical_features_used = train_model(train_df, eval_df)

    # If test-path is provided, generate predictions
    if args.test_path:
        test_data = load_data(args.test_path)
        if test_data is None:
            logging.error("Could not load test data. Skipping prediction generation.")
            return

        predict_and_save(model, test_data, features_used, categorical_features_used, args.submission_output)
    else:
        logging.info("No test-path provided. Skipping prediction generation.")

if __name__ == "__main__":
    main()
