
import pandas as pd
import numpy as np
import argparse
import os
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def rmse(y_true, y_pred):
    """Calculates the Root Mean Squared Error."""
    return np.sqrt(mean_squared_error(y_true, y_pred))

def load_data(file_path):
    """
    Loads a CSV file and performs initial cleaning.
    Converts 'Street Name' and 'Violation Description' to uppercase and strips whitespace.
    """
    logging.info(f"Loading data from {file_path}")
    df = pd.read_csv(file_path)
    df.columns = [col.strip() for col in df.columns] # Clean column names
    df['Street Name'] = df['Street Name'].astype(str).str.strip().str.upper()
    df['Violation Description'] = df['Violation Description'].astype(str).str.strip().str.upper()
    logging.info(f"Data loaded successfully. Shape: {df.shape}")
    return df

def feature_engineer(df, is_train=True, train_df_for_aggs=None):
    """
    Performs feature engineering.
    For test data (is_train=False), it uses aggregates learned from train_df_for_aggs
    to prevent data leakage and ensure consistency.
    """
    logging.info(f"Starting feature engineering for {'training' if is_train else 'test'} data...")

    # Basic features
    df['street_name_len'] = df['Street Name'].apply(len)
    df['violation_desc_len'] = df['Violation Description'].apply(len)

    # Determine the dataframe to compute aggregates from
    if is_train:
        df_for_aggs = df.copy()
    else:
        # For test/validation, use aggregates from the full training data
        df_for_aggs = train_df_for_aggs
        if df_for_aggs is None:
            raise ValueError("train_df_for_aggs must be provided when is_train is False.")

    # Global means for fallback for unseen categories in aggregates
    global_mean_violation = df_for_aggs['violation_count'].mean()
    global_median_violation = df_for_aggs['violation_count'].median()

    # Street Name aggregates
    street_agg_counts = df_for_aggs.groupby('Street Name')['violation_count'].agg(
        street_mean='mean',
        street_median='median',
        street_std='std',
        street_violation_types_count='count'
    ).reset_index()
    df = df.merge(street_agg_counts, on='Street Name', how='left')
    # Fill NaN values for streets not seen in training data
    df['street_mean'] = df['street_mean'].fillna(global_mean_violation)
    df['street_median'] = df['street_median'].fillna(global_median_violation)
    df['street_std'] = df['street_std'].fillna(0) # Standard deviation of a single item is 0
    df['street_violation_types_count'] = df['street_violation_types_count'].fillna(0) # Count for unseen street is 0

    # Violation Description aggregates
    violation_agg_counts = df_for_aggs.groupby('Violation Description')['violation_count'].agg(
        violation_mean='mean',
        violation_median='median',
        violation_std='std',
        violation_street_names_count='count'
    ).reset_index()
    df = df.merge(violation_agg_counts, on='Violation Description', how='left')
    # Fill NaN values for violation types not seen in training data
    df['violation_mean'] = df['violation_mean'].fillna(global_mean_violation)
    df['violation_median'] = df['violation_median'].fillna(global_median_violation)
    df['violation_std'] = df['violation_std'].fillna(0)
    df['violation_street_names_count'] = df['violation_street_names_count'].fillna(0)

    logging.info("Feature engineering complete.")
    return df

def augment_with_external_data(df, augmentation_dir):
    """
    Loads and integrates data from augmentation tables like census and parking zones.
    This implementation makes assumptions about column names and join keys.
    """
    logging.info("Attempting to augment with external data...")

    # Augment with nyc_census_data.csv (example: population by borough)
    try:
        census_df = pd.read_csv(os.path.join(augmentation_dir, 'nyc_census_data.csv'))
        census_df.columns = [col.strip() for col in census_df.columns]

        # Heuristic to derive Borough from Street Name (can be improved with geocoding)
        df['Borough'] = 'UNKNOWN'
        df.loc[df['Street Name'].str.contains('MANHATTAN'), 'Borough'] = 'MANHATTAN'
        df.loc[df['Street Name'].str.contains('BROOKLYN'), 'Borough'] = 'BROOKLYN'
        df.loc[df['Street Name'].str.contains('QUEENS'), 'Borough'] = 'QUEENS'
        df.loc[df['Street Name'].str.contains('BRONX'), 'Borough'] = 'BRONX'
        df.loc[df['Street Name'].str.contains('STATEN ISLAND') | df['Street Name'].str.contains('RICHMOND'), 'Borough'] = 'STATEN ISLAND'

        # Attempt to merge if relevant census columns exist
        if 'Borough' in census_df.columns and 'Total Population' in census_df.columns:
            borough_pop = census_df.groupby('Borough')['Total Population'].sum().reset_index()
            borough_pop.columns = ['Borough', 'borough_population']
            df = df.merge(borough_pop, on='Borough', how='left')
            df['borough_population'] = df['borough_population'].fillna(df['borough_population'].mean()) # Fill unseen boroughs with mean
            logging.info("Augmented with borough population from census data.")
        else:
            logging.warning("Skipping census data augmentation: 'Borough' or 'Total Population' column not found or schema mismatch.")

    except FileNotFoundError:
        logging.warning(f"nyc_census_data.csv not found in {augmentation_dir}. Skipping census data augmentation.")
    except Exception as e:
        logging.error(f"Error augmenting with census data: {e}. Skipping.")


    # Augment with nyc_parking_zones.csv (example: parking zone presence)
    try:
        parking_zones_df = pd.read_csv(os.path.join(augmentation_dir, 'nyc_parking_zones.csv'))
        parking_zones_df.columns = [col.strip() for col in parking_zones_df.columns]
        parking_zones_df['Street Name'] = parking_zones_df['Street Name'].astype(str).str.strip().str.upper()

        if 'Street Name' in parking_zones_df.columns and 'Zone Type' in parking_zones_df.columns:
            # Aggregate parking zone info per street
            street_zone_info = parking_zones_df.groupby('Street Name').agg(
                num_unique_zones_on_street=('Zone Type', 'nunique'),
                has_parking_zone=('Zone Type', lambda x: 1) # Binary feature: 1 if street has any parking zone
            ).reset_index()
            df = df.merge(street_zone_info, on='Street Name', how='left')
            df['num_unique_zones_on_street'] = df['num_unique_zones_on_street'].fillna(0)
            df['has_parking_zone'] = df['has_parking_zone'].fillna(0) # Fill with 0 for streets without listed zones
            logging.info("Augmented with parking zone data.")
        else:
            logging.warning("Skipping parking zones augmentation: 'Street Name' or 'Zone Type' column not found or schema mismatch.")

    except FileNotFoundError:
        logging.warning(f"nyc_parking_zones.csv not found in {augmentation_dir}. Skipping parking zone augmentation.")
    except Exception as e:
        logging.error(f"Error augmenting with parking zone data: {e}. Skipping.")

    logging.info("External data augmentation complete.")
    return df

def train_and_predict(train_path, test_path=None, augmentation_dir="./input/"):
    """
    Main function to load data, engineer features, train CatBoost model, and predict.
    """
    # 1. Load Training Data
    train_df_full = load_data(train_path)

    # 2. Split 2022 data for validation
    # Stratify by 'Violation Description' to ensure representation of all violation types
    train_df, val_df = train_test_split(
        train_df_full, test_size=0.2, random_state=42, stratify=train_df_full['Violation Description']
    )
    logging.info(f"Training data shape (80% of 2022): {train_df.shape}")
    logging.info(f"Validation data shape (20% of 2022): {val_df.shape}")

    # 3. Feature Engineering
    # Compute aggregates from the full 2022 dataset (train_df_full) to avoid leakage
    # from validation set and ensure consistent features for test set.
    train_df = feature_engineer(train_df, is_train=True, train_df_for_aggs=train_df_full)
    val_df = feature_engineer(val_df, is_train=False, train_df_for_aggs=train_df_full)
    
    # 4. Augment with External Data
    train_df = augment_with_external_data(train_df, augmentation_dir)
    val_df = augment_with_external_data(val_df, augmentation_dir)

    # Define features and target
    target = 'violation_count'
    categorical_cols = [
        'Street Name', 'Violation Description', 'Borough'
    ]
    
    # Filter for categorical columns that actually exist in the dataframe
    categorical_cols_existing = [col for col in categorical_cols if col in train_df.columns]
    
    # All features except the target
    features = [col for col in train_df.columns if col != target]

    # Align columns between train and validation sets
    common_features = list(set(train_df.columns) & set(val_df.columns) - {target})
    
    X_train = train_df[common_features]
    y_train = train_df[target]
    X_val = val_df[common_features]
    y_val = val_df[target]

    # Ensure categorical_features_indices are correctly mapped to the aligned X_train columns
    categorical_features_indices = [
        X_train.columns.get_loc(col) for col in categorical_cols_existing if col in X_train.columns
    ]
    
    logging.info(f"Features used for training ({len(common_features)}): {common_features}")
    logging.info(f"Categorical features ({len(categorical_features_indices)}): {[X_train.columns[i] for i in categorical_features_indices]}")

    # 5. CatBoost Model Training
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=8,
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Set to 100 for more detailed output during training
        early_stopping_rounds=50,
        cat_features=categorical_features_indices,
        # Uncomment and install 'catboost-gpu' for GPU acceleration if available:
        # task_type="GPU",
        # devices='0'
    )

    logging.info("Starting CatBoost model training...")
    model.fit(X_train, y_train,
              eval_set=(X_val, y_val),
              early_stopping_rounds=50,
              verbose=False) # Suppress detailed output during fit for cleaner final logs

    # 6. Evaluate on validation set
    val_predictions = model.predict(X_val)
    val_rmse = rmse(y_val, val_predictions)
    logging.info(f"Final Validation Performance: {val_rmse}")

    # 7. Handle test data if provided
    if test_path:
        logging.info(f"Loading test data from {test_path}")
        test_df = load_data(test_path)
        
        # Keep original keys for submission file
        test_original_keys = test_df[['Street Name', 'Violation Description']].copy()

        # Feature engineering for test data, using aggregates from full 2022 data
        test_df = feature_engineer(test_df, is_train=False, train_df_for_aggs=train_df_full)
        test_df = augment_with_external_data(test_df, augmentation_dir)
        
        # Ensure test_df has the same columns as X_train and in the same order
        # Fill missing numerical features with 0 (or a more appropriate default like mean/median if applicable)
        for col in common_features:
            if col not in test_df.columns:
                logging.warning(f"Feature '{col}' missing in test data. Adding with default value (0).")
                test_df[col] = 0 
        
        X_test = test_df[common_features]

        # Identify unseen pairs in test set
        train_pairs = set(train_df_full.set_index(['Street Name', 'Violation Description']).index)
        test_pairs = set(test_df.set_index(['Street Name', 'Violation Description']).index)
        unseen_pairs_count = len(test_pairs - train_pairs)
        logging.info(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_pairs_count}")

        # Generate predictions
        test_predictions = model.predict(X_test)
        
        # Clip predictions to be non-negative and round to nearest integer
        test_predictions[test_predictions < 0] = 0
        test_predictions = np.round(test_predictions).astype(int)

        # Create submission file
        submission_df = test_original_keys
        submission_df['predicted_count'] = test_predictions
        submission_df.rename(columns={'Street Name': 'street_name', 'Violation Description': 'violation_type'}, inplace=True)
        submission_df.to_csv('submission.csv', index=False)
        logging.info("Submission file 'submission.csv' created.")

        # If test_df has 'violation_count' (ground truth), compute RMSE
        if target in test_df.columns:
            test_true_counts = test_df[target]
            test_rmse = rmse(test_true_counts, test_predictions)
            logging.info(f"RMSE on provided test/eval file: {test_rmse}")
        else:
            logging.info("Test file does not contain 'violation_count'. Skipping RMSE calculation for test set.")

    logging.info("Prediction pipeline finished.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Predict NYC parking violations for 2023.")
    parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Path to the 2023 test/evaluation data CSV (optional).")
    parser.add_argument("--augmentation-dir", type=str, default="./input/",
                        help="Directory containing augmentation tables (e.g., census, parking zones).")
    
    args = parser.parse_args()

    # Ensure the input directory exists
    if not os.path.exists("./input"):
        os.makedirs("./input")
        logging.warning("Created './input' directory. Please place your data files here.")
    
    # Check if the default train file exists before proceeding
    if not os.path.exists(args.train_path):
        logging.error(f"Training data file not found at {args.train_path}. Please ensure it exists before running the script.")
        # The program will likely fail on pd.read_csv if file doesn't exist, which is expected.
    else:
        train_and_predict(args.train_path, args.test_path, args.augmentation_dir)
