
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc
import sys
import io

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'

# --- Original functions (adapted for ablation) ---

def _engineer_features_ablation(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None,
                                ablation_no_astype_str: bool = False) -> pd.DataFrame:
    """
    Performs feature engineering on the input DataFrame.
    ablation_no_astype_str: If True, removes .astype(str) from fillna for categorical columns.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Handle missing values
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            if ablation_no_astype_str:
                df.loc[:, col] = df[col].fillna('unknown') # Ablation: Remove .astype(str)
            else:
                df.loc[:, col] = df[col].fillna('unknown').astype(str)

    # Label Encoding for categorical features
    categorical_cols = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df.loc[:, col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col] = le
            else:
                if col in encoder_dict:
                    # Use transform for existing categories, map unknown to -1
                    encoded_values = df[col].map(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else -1)
                    df.loc[:, col + '_encoded'] = encoded_values
                else:
                    df.loc[:, col + '_encoded'] = -1 # Assign a default for entirely new categories if no encoder

    # Log transform target if present, good for count data
    if TARGET_COLUMN in df.columns and is_training:
        df.loc[:, TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

def load_and_preprocess_data_ablation(file_path: str, is_training: bool = True, encoder_dict: dict = None,
                                     ablation_no_astype_str: bool = False) -> pd.DataFrame:
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features_ablation(df.copy(), is_training=is_training, encoder_dict=encoder_dict,
                                                  ablation_no_astype_str=ablation_no_astype_str)
    return df, encoder_dict

def train_model_ablation(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series,
                         ablation_no_categorical_declaration: bool = False) -> lgb.Booster:
    """
    Trains a LightGBM model.
    ablation_no_categorical_declaration: If True, removes explicit categorical_feature declaration.
    """
    # LightGBM expects feature names as strings and sanitized names
    original_train_cols = X_train.columns
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    # Identify categorical features based on the plan
    categorical_features_names = []
    if 'street_name_encoded' in original_train_cols:
        categorical_features_names.append("street_name_encoded")
    if 'violation_description_encoded' in original_train_cols:
        categorical_features_names.append("violation_description_encoded")

    # LightGBM parameters
    params = {
        'objective': 'poisson',
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 63,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    fit_params = {
        'eval_set': [(X_val, y_val)],
        'eval_metric': 'rmse',
        'callbacks': [lgb.early_stopping(100, verbose=False)],
    }

    if not ablation_no_categorical_declaration:
        if categorical_features_names: # Only pass if not empty
            fit_params['categorical_feature'] = categorical_features_names

    model.fit(X_train, y_train, **fit_params)

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

# --- Ablation Study Main Function ---

def run_ablation_scenario(args, ablation_name: str, ablation_no_astype_str: bool = False,
                 ablation_group_by_street_only: bool = False,
                 ablation_no_categorical_declaration: bool = False) -> float:

    print(f"Running Ablation: {ablation_name}")

    df_2022_raw, encoder_dict = load_and_preprocess_data_ablation(
        args.train_path, is_training=True, ablation_no_astype_str=ablation_no_astype_str
    )
    
    street_col_lower = STREET_NAME_COL.replace(' ', '_').lower()
    violation_col_lower = VIOLATION_DESC_COL.replace(' ', '_').lower()

    # Split 2022 data for training and validation
    # Use grouped holdout for (street_name, violation_type) pairs or just street_name
    if ablation_group_by_street_only:
        df_2022_raw['group_id'] = df_2022_raw[street_col_lower]
    else:
        df_2022_raw['group_id'] = df_2022_raw[street_col_lower] + '_' + \
                                   df_2022_raw[violation_col_lower]

    # Get unique groups
    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    # Drop the temporary group_id
    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])

    # Define features and target
    features = [col for col in df_train_raw.columns if col not in [TARGET_COLUMN, street_col_lower, violation_col_lower]]

    # Prepare training data
    X_train = df_train_raw[features]
    y_train = df_train_raw[TARGET_COLUMN]

    # Prepare validation data
    X_val = df_val_raw[features]
    y_val = df_val_raw[TARGET_COLUMN]

    model = train_model_ablation(X_train, y_train, X_val, y_val,
                                 ablation_no_categorical_declaration=ablation_no_categorical_declaration)

    # Predict on validation set for performance reporting
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log) # Inverse transform
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(np.expm1(y_val), val_predictions) # Calculate RMSE on original scale

    gc.collect()
    return final_validation_rmse

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Ablation study for NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()

    # Store results
    results = {}

    # --- Baseline Run ---
    results['Baseline'] = run_ablation_scenario(args, "Baseline")
    print(f"Baseline: RMSE = {results['Baseline']:.4f}")

    # --- Ablation 1: Remove .astype(str) for fillna('unknown') ---
    results['Ablation 1: No .astype(str) for fillna'] = run_ablation_scenario(args, "Ablation 1: No .astype(str) for fillna",
                                                                       ablation_no_astype_str=True)
    print(f"Ablation 1: No .astype(str) for fillna: RMSE = {results['Ablation 1: No .astype(str) for fillna']:.4f}")

    # --- Ablation 2: Group by Street Name only for validation split ---
    results['Ablation 2: Group by Street only for split'] = run_ablation_scenario(args, "Ablation 2: Group by Street only for split",
                                                                           ablation_group_by_street_only=True)
    print(f"Ablation 2: Group by Street only for split: RMSE = {results['Ablation 2: Group by Street only for split']:.4f}")

    # --- Ablation 3: Remove explicit categorical_feature declaration ---
    results['Ablation 3: No explicit categorical_feature'] = run_ablation_scenario(args, "Ablation 3: No explicit categorical_feature",
                                                                            ablation_no_categorical_declaration=True)
    print(f"Ablation 3: No explicit categorical_feature: RMSE = {results['Ablation 3: No explicit categorical_feature']:.4f}")


    # Determine most impactful
    baseline_rmse = results['Baseline']
    most_impactful_change_name = ""
    most_impactful_difference = 0.0 # Positive for improvement, negative for degradation

    for name, rmse in results.items():
        if name == 'Baseline':
            continue

        difference = baseline_rmse - rmse # Positive if improvement, negative if degradation
        
        if abs(difference) > abs(most_impactful_difference):
            most_impactful_difference = difference
            most_impactful_change_name = name

    if most_impactful_change_name:
        if most_impactful_difference > 0:
            print(f"The part that contributes the most to the overall performance is: {most_impactful_change_name}.")
            print(f"It improved the RMSE by {most_impactful_difference:.4f} compared to the Baseline.")
        else:
            print(f"The part that contributes the most to the overall performance is: {most_impactful_change_name}.")
            print(f"It degraded the RMSE by {-most_impactful_difference:.4f} compared to the Baseline.")
    else:
        print("No significant impact observed from the tested ablations.")

    gc.collect()
