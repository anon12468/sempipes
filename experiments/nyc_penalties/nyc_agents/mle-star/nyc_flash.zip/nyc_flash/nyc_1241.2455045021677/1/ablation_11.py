
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
# OUTPUT_SUBMISSION_FILE constant is not strictly needed for ablation focused on validation,
# but kept for consistency if parts of the original code are re-used.

# --- Original functions from the provided solution (Baseline) ---
def _engineer_features_baseline(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Performs feature engineering on the input DataFrame (baseline version).
    Includes standardization, handling missing values with 'unknown', Label Encoding, and log transform on target.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Handle missing values for categorical features
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str) # Baseline: fillna('unknown')

    # Label Encoding for categorical features
    categorical_cols = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col] = le
            else:
                if col in encoder_dict:
                    # Use transform for existing categories, map unknown to -1
                    df[col + '_encoded'] = df[col].map(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else -1)
                else:
                    df[col + '_encoded'] = -1 # Assign a default for entirely new categories if no encoder

    # Log transform target if present, good for count data
    if TARGET_COLUMN in df.columns and is_training:
        df[TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None, engineer_features_func=None) -> tuple[pd.DataFrame, dict]:
    """
    Loads data from a CSV file and applies initial preprocessing.
    Can use a custom feature engineering function.
    """
    df = pd.read_csv(file_path)
    if engineer_features_func is None:
        df, encoder_dict = _engineer_features_baseline(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    else:
        df, encoder_dict = engineer_features_func(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series, params_override: dict = None) -> lgb.Booster:
    """
    Trains a LightGBM model with customizable parameters.
    """
    # LightGBM expects feature names as strings
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'regression_l1',  # MAE objective
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 31,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }
    if params_override:
        params.update(params_override)

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)]) # Use callbacks for early stopping

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

# --- Ablation specific functions/modifications ---

# Ablation 1: Change missing value placeholder in _engineer_features
def _engineer_features_ablation_1(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Feature engineering with 'missing_category' placeholder for NaNs.
    Ablation: Changes fillna('unknown') to fillna('missing_category').
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower()

    # Handle missing values - ABLATION CHANGE HERE
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('missing_category').astype(str) # Changed from 'unknown' to 'missing_category'

    categorical_cols = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col] = le
            else:
                if col in encoder_dict:
                    df[col + '_encoded'] = df[col].map(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else -1)
                else:
                    df[col + '_encoded'] = -1

    if TARGET_COLUMN in df.columns and is_training:
        df[TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict


def run_ablation(train_path: str, engineer_features_func=None, params_override: dict = None) -> float:
    """
    Runs a single ablation scenario on the training and validation set and returns validation RMSE.
    """
    df_2022_raw, encoder_dict = load_and_preprocess_data(train_path, is_training=True, engineer_features_func=engineer_features_func)

    # Split 2022 data for training and validation using grouped holdout
    standardized_street_col = STREET_NAME_COL.replace(' ', '_').lower()
    standardized_violation_col = VIOLATION_DESC_COL.replace(' ', '_').lower()
    
    df_2022_raw['group_id'] = df_2022_raw[standardized_street_col] + '_' + \
                               df_2022_raw[standardized_violation_col]

    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    # Define features and target (encoded categorical columns are included automatically)
    features = [col for col in df_train_raw.columns if col not in [TARGET_COLUMN, standardized_street_col, standardized_violation_col]]

    X_train = df_train_raw[features]
    y_train = df_train_raw[TARGET_COLUMN]

    X_val = df_val_raw[features]
    y_val = df_val_raw[TARGET_COLUMN]

    model = train_model(X_train, y_train, X_val, y_val, params_override=params_override)

    # Predict on validation set for performance reporting
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log) # Inverse transform
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(np.expm1(y_val), val_predictions) # Calculate RMSE on original scale
    
    # Clean up memory
    del df_2022_raw, df_train_raw, df_val_raw, X_train, y_train, X_val, y_val, model
    gc.collect()
    
    return final_validation_rmse


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Ablation study for NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()

    results = {}

    print("--- Running Baseline Model ---")
    baseline_rmse = run_ablation(args.train_path)
    results['Baseline'] = baseline_rmse
    print(f"Baseline Validation RMSE: {baseline_rmse:.4f}\n")

    print("--- Ablation 1: Change missing categorical value placeholder to 'missing_category' ---")
    ablation1_rmse = run_ablation(args.train_path, engineer_features_func=_engineer_features_ablation_1)
    results['Ablation 1 (Placeholder Changed)'] = ablation1_rmse
    print(f"Ablation 1 Validation RMSE (Placeholder Changed): {ablation1_rmse:.4f}\n")

    print("--- Ablation 2: Change Learning Rate to 0.05 ---")
    ablation2_params = {'learning_rate': 0.05}
    ablation2_rmse = run_ablation(args.train_path, params_override=ablation2_params)
    results['Ablation 2 (Learning Rate 0.05)'] = ablation2_rmse
    print(f"Ablation 2 Validation RMSE (Learning Rate 0.05): {ablation2_rmse:.4f}\n")

    print("--- Ablation 3: Remove L1/L2 Regularization (set lambda_l1, lambda_l2 to 0) ---")
    ablation3_params = {'lambda_l1': 0.0, 'lambda_l2': 0.0}
    ablation3_rmse = run_ablation(args.train_path, params_override=ablation3_params)
    results['Ablation 3 (No L1/L2 Regularization)'] = ablation3_rmse
    print(f"Ablation 3 Validation RMSE (No L1/L2 Regularization): {ablation3_rmse:.4f}\n")

    print("\n--- Ablation Study Results Summary ---")
    for name, rmse in results.items():
        print(f"{name}: {rmse:.4f}")

    # Determine the most impactful component
    max_impact_value = 0
    most_impactful_description = ""

    for name, rmse in results.items():
        if name == 'Baseline':
            continue
        
        current_impact = abs(rmse - baseline_rmse)
        if current_impact > max_impact_value:
            max_impact_value = current_impact
            
            # Map ablation name back to baseline component description and describe the change
            if 'Placeholder Changed' in name:
                baseline_component = "Default missing value placeholder ('unknown')"
                ablation_change_desc = "changing it to 'missing_category'"
            elif 'Learning Rate 0.05' in name:
                baseline_component = "Learning Rate of 0.01"
                ablation_change_desc = "changing it to 0.05"
            elif 'No L1/L2 Regularization' in name:
                baseline_component = "L1/L2 Regularization (lambda_l1=0.1, lambda_l2=0.1)"
                ablation_change_desc = "removing it"
            else:
                baseline_component = name # fallback
                ablation_change_desc = "modifying it"

            if rmse < baseline_rmse:
                # Ablation improved performance -> baseline component was detrimental
                most_impactful_description = f"The '{baseline_component}' (as configured in baseline) was detrimental to performance, as {ablation_change_desc} improved RMSE by {max_impact_value:.4f}."
            else:
                # Ablation degraded performance -> baseline component was beneficial
                most_impactful_description = f"The '{baseline_component}' (as configured in baseline) is highly beneficial, as {ablation_change_desc} degraded RMSE by {max_impact_value:.4f}."
    
    if most_impactful_description:
        print(f"\nConclusion on most impactful component:")
        print(most_impactful_description)
    else:
        print("\nNo ablations performed or results inconclusive.")
