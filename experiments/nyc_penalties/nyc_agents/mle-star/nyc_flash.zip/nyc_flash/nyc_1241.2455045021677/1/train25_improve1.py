
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import catboost as cb
import os
import lightgbm as lgb
import gc

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv'

import pandas as pd
import numpy as np
# No longer using sklearn.preprocessing.LabelEncoder for the target-encoded features.

# Assume STREET_NAME_COL, VIOLATION_DESC_COL, TARGET_COLUMN are defined globally.
# For example:
# STREET_NAME_COL = 'Street Name'
# VIOLATION_DESC_COL = 'Violation Description'
# TARGET_COLUMN = 'Fine Amount' # This should be the actual target column name

def _smoothed_target_encoding(df: pd.DataFrame, col: str, target_col: str,
                              min_samples_leaf: int = 50, smoothing: int = 20) -> (pd.Series, float, dict):
    """
    Computes smoothed target encoding for a given column.
    Returns the encoded series, the global mean, and the encoding map.

    min_samples_leaf: The minimum number of samples per category to consider its mean as fully reliable.
                      Categories with fewer samples will have their mean pulled towards the global_mean.
                      (Note: the standard smoothing formula implicitly handles this by weighting).
    smoothing: A parameter that controls the strength of regularization. Higher values mean more regularization,
               pulling category means closer to the global mean, preventing overfitting to rare categories.
    """
    # Calculate global mean of the target from the training data
    global_mean = df[target_col].mean()

    # Aggregate target statistics for each category
    # 'count' is the number of occurrences, 'mean' is the mean of the target for that category
    agg = df.groupby(col)[target_col].agg(['count', 'mean'])
    counts = agg['count']
    means = agg['mean']

    # Compute smoothed mean using the formula:
    # smoothed_mean = (count * category_mean + global_mean * smoothing) / (count + smoothing)
    # This formula effectively blends the category's mean with the global mean.
    # When 'count' is small, the global_mean has a stronger influence (regularization).
    smoothed_means = (counts * means + global_mean * smoothing) / (counts + smoothing)

    # Create encoding map from category to its smoothed target value
    encoding_map = smoothed_means.to_dict()

    # Apply encoding to the column. For categories present in df[col] but not in encoding_map
    # (should ideally not happen if df[col] is the source for groupby),
    # they are filled with the global_mean for robustness.
    encoded_series = df[col].map(encoding_map).fillna(global_mean)

    return encoded_series, global_mean, encoding_map


def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> (pd.DataFrame, dict):
    """
    Performs feature engineering on the input DataFrame, introducing smoothed target encoding
    for specified categorical features.
    """
    if encoder_dict is None:
        encoder_dict = {}

    # Standardize column names: replace spaces with underscores and convert to lowercase
    df.columns = df.columns.str.replace(' ', '_').str.lower()

    # Determine lowercased column names for constants, assuming they are defined globally
    street_name_col_lower = STREET_NAME_COL.replace(' ', '_').lower()
    violation_desc_col_lower = VIOLATION_DESC_COL.replace(' ', '_').lower()
    target_col_lower = TARGET_COLUMN.replace(' ', '_').lower()

    # Identify columns for smoothed target encoding
    # Only include them if they actually exist in the DataFrame after standardization
    cols_to_target_encode = []
    if street_name_col_lower in df.columns:
        cols_to_target_encode.append(street_name_col_lower)
    if violation_desc_col_lower in df.columns:
        cols_to_target_encode.append(violation_desc_col_lower)

    # Handle missing values for the categorical features identified for target encoding
    # 'unknown' will be treated as a regular category by the target encoder.
    for col in cols_to_target_encode:
        df[col] = df[col].fillna('unknown').astype(str)

    # Log transform target if present and in training, BEFORE calculating target encoding.
    # This ensures target encoding is based on the transformed target values.
    if target_col_lower in df.columns and is_training:
        df[target_col_lower] = np.log1p(df[target_col_lower])

    # Smoothed Target Encoding implementation
    # These parameters can be tuned for optimal performance based on cross-validation.
    min_samples_leaf = 50 # Example value: Minimum samples for a category mean to be considered reliable
    smoothing = 20    # Example value: Smoothing factor, higher means more regularization towards global mean

    for col in cols_to_target_encode:
        if is_training:
            # During training, compute the encoding map and global mean
            if target_col_lower not in df.columns:
                # If target column is missing in training data, we cannot perform target encoding for this feature.
                print(f"Warning: Target column '{target_col_lower}' not found for smoothed target encoding of '{col}'. Skipping.")
                continue # Skip target encoding for this feature

            encoded_series, global_mean, encoding_map = _smoothed_target_encoding(
                df=df, col=col, target_col=target_col_lower,
                min_samples_leaf=min_samples_leaf, smoothing=smoothing
            )
            df[col + '_smoothed_encoded'] = encoded_series
            # Store the computed encoding map and global mean in the encoder_dict.
            # This dict will be passed from training to validation/test phases to prevent data leakage.
            encoder_dict[col + '_smoothed_encoder'] = {
                'encoding_map': encoding_map,
                'global_mean': global_mean
            }
        else: # During inference (validation or test phase)
            # Apply the previously learned encoding.
            encoder_key = col + '_smoothed_encoder'
            if encoder_key in encoder_dict:
                encoding_info = encoder_dict[encoder_key]
                encoding_map = encoding_info['encoding_map']
                global_mean = encoding_info['global_mean']

                # Apply the stored encoding map to the current DataFrame.
                # Categories present in the inference set but not in the training set's encoding_map
                # will be mapped to the stored global_mean, preventing data leakage and handling unseen data.
                df[col + '_smoothed_encoded'] = df[col].map(encoding_map).fillna(global_mean)
            else:
                # Fallback if an encoder for this column was not found in the encoder_dict.
                # This could happen if the column was not present during training, or if its encoding was skipped.
                # Assign 0.0 as a safe numerical default to prevent errors.
                print(f"Warning: No smoothed target encoder found for '{col}'. Assigning 0.0 to new feature.")
                df[col + '_smoothed_encoded'] = 0.0

    # The original LabelEncoder logic for 'street_name' and 'violation_description'
    # has been replaced by smoothed target encoding as per the improvement plan.

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series) -> lgb.Booster:
    """
    Trains a LightGBM model.
    """
    # LightGBM expects feature names as strings and sanitized names
    original_train_cols = X_train.columns
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    # Identify categorical features based on the plan
    # Assuming 'street_name_encoded' and 'violation_description_encoded' are present
    # and are the only categorical features to be explicitly handled this way.
    # We need to use their sanitized names.
    categorical_features_names = []
    if 'street_name_encoded' in original_train_cols:
        categorical_features_names.append("street_name_encoded")
    if 'violation_description_encoded' in original_train_cols:
        categorical_features_names.append("violation_description_encoded")

    # LightGBM parameters
    params = {
        'objective': 'poisson',  # Changed objective to 'poisson' as per plan
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 63,  # Increased num_leaves from 31 to 63 as per plan
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)], # Use callbacks for early stopping
              categorical_feature=categorical_features_names) # Explicitly declare categorical features

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional: Path to the 2023 test/evaluation data CSV.')
    args = parser.parse_args()

    print(f"Loading training data from: {args.train_path}")
    df_2022_raw, encoder_dict = load_and_preprocess_data(args.train_path, is_training=True)

    # Split 2022 data for training and validation
    # Use grouped holdout for (street_name, violation_type) pairs
    # Create a unique identifier for splitting
    df_2022_raw['group_id'] = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

    # Get unique groups
    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    # Drop the temporary group_id
    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    # Define features and target
    features = [col for col in df_train_raw.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]]

    # Prepare training data
    X_train = df_train_raw[features]
    y_train = df_train_raw[TARGET_COLUMN]

    # Prepare validation data - CRITICAL FIX HERE: Extract y_val *before* any potential dropping or mismatch
    X_val = df_val_raw[features]
    y_val = df_val_raw[TARGET_COLUMN] # This ensures y_val is correctly assigned from the raw df_val_raw

    print("Training model...")
    model = train_model(X_train, y_train, X_val, y_val)

    # Predict on validation set for performance reporting
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log) # Inverse transform
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(np.expm1(y_val), val_predictions) # Calculate RMSE on original scale
    print(f"Final Validation Performance: {final_validation_rmse}")

    # If a test path is provided, generate predictions
    if args.test_path:
        print(f"Loading test data from: {args.test_path}")
        df_test_raw, _ = load_and_preprocess_data(args.test_path, is_training=False, encoder_dict=encoder_dict)

        # Ensure test data has the same features as training data
        test_features = [col for col in features if col in df_test_raw.columns]
        X_test = df_test_raw[test_features]

        # Align columns - crucial for consistent predictions
        # Add missing columns to X_test with 0, remove extra columns
        missing_cols = set(X_train.columns) - set(X_test.columns)
        for c in missing_cols:
            X_test[c] = 0
        extra_cols = set(X_test.columns) - set(X_train.columns)
        X_test = X_test.drop(columns=list(extra_cols))
        X_test = X_test[X_train.columns] # Ensure column order is the same

        print("Generating predictions for test data...")
        test_predictions_log = model.predict(X_test)
        test_predictions = np.expm1(test_predictions_log) # Inverse transform
        test_predictions[test_predictions < 0] = 0 # Clip negative predictions
        test_predictions = np.round(test_predictions).astype(int) # Round to nearest integer

        # Create submission file
        submission_df = pd.DataFrame({
            STREET_NAME_COL: df_test_raw[STREET_NAME_COL.replace(' ', '_').lower()],
            VIOLATION_DESC_COL: df_test_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()],
            PREDICTED_COUNT_COL: test_predictions
        })
        # Original column names for submission
        submission_df.columns = [STREET_NAME_COL, VIOLATION_DESC_COL, PREDICTED_COUNT_COL]

        submission_df.to_csv(OUTPUT_SUBMISSION_FILE, index=False)
        print(f"Submission file '{OUTPUT_SUBMISSION_FILE}' created successfully.")

        # If test_path contains 'violation_count', calculate RMSE
        if TARGET_COLUMN in df_test_raw.columns:
            y_test_true = np.expm1(df_test_raw[TARGET_COLUMN]) # Inverse log transform for actual values
            test_rmse = calculate_rmse(y_test_true, test_predictions)
            print(f"RMSE on provided test/evaluation data: {test_rmse}")

            # Report unseen key pairs
            train_keys = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]
            test_keys = df_test_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + df_test_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

            unseen_keys_count = test_keys.isin(train_keys).value_counts().get(False, 0)
            total_test_keys = len(test_keys)
            print(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {unseen_keys_count} out of {total_test_keys}")
            print("Unseen pairs are handled by the model's ability to generalize based on encoded features and numerical interaction features, "
                  "and by assigning -1 for unknown categories during Label Encoding transform.")

    gc.collect()

if __name__ == "__main__":
    main()
