
import pandas as pd
import numpy as np
import lightgbm as lgb
import xgboost as xgb
from catboost import CatBoostRegressor, Pool
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import os
import argparse
import logging
from collections import defaultdict

# --- Setup Logging ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Configuration ---
DEFAULT_TRAIN_PATH = './input/violations_per_street_2022.csv'
AUX_VIOLATION_CODES_PATH = './input/nyc_parking_violation_codes.csv'
AUX_STREET_INFO_PATH = './input/nyc_street_names_info.csv'
AUX_BOROUGH_ZIP_VIOLATIONS_PATH = './input/violations_by_borough_and_zipcode_2022.csv'
# Additional files like violations_by_hour_2022.csv and violations_by_zipcode_and_day_2022.csv
# are not directly used for this annual aggregate count prediction task to keep the solution simple
# as per the requirement "This first solution design should be relatively simple".

OUTPUT_DIR = './predictions'
SUBMISSION_FILENAME = 'submission.csv'

TARGET_COLUMN = 'violation_count'
# Standardized key columns for consistent handling across dataframes
KEY_COLUMNS = ['Street_Name', 'Violation_Description']

def parse_args():
    """Parses command line arguments."""
    parser = argparse.ArgumentParser(description="Predict NYC parking violations using an ensemble of LightGBM, XGBoost, and CatBoost.")
    parser.add_argument('--train-path', type=str, default=DEFAULT_TRAIN_PATH,
                        help='Path to the 2022 violations training data.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional path to the 2023 violations test data for prediction/evaluation.')
    return parser.parse_args()

def standardize_column_names(df):
    """Standardizes column names for consistency."""
    if df.empty:
        return df
    # Replace spaces with underscores, then remove any non-alphanumeric/underscore characters
    df.columns = df.columns.str.strip().str.replace(' ', '_').str.replace('[^A-Za-z0-9_]+', '', regex=True)
    return df

def load_data(file_path):
    """Loads CSV data from the given path."""
    logging.info(f"Loading data from {file_path}")
    try:
        df = pd.read_csv(file_path)
        return standardize_column_names(df)
    except FileNotFoundError:
        logging.error(f"File not found: {file_path}")
        return pd.DataFrame() # Return empty DataFrame on error
    except pd.errors.EmptyDataError:
        logging.warning(f"File is empty: {file_path}. Returning empty DataFrame.")
        return pd.DataFrame()
    except Exception as e:
        logging.error(f"Error loading {file_path}: {e}")
        return pd.DataFrame() # Return empty DataFrame on error

def feature_engineer(df, violation_codes_df, street_info_df, borough_zip_violations_df):
    """
    Performs feature engineering by merging auxiliary data and handling NaNs.
    This function is adapted from the base solution, which uses a robust approach
    for categorical features suitable for native handling by tree models.
    """
    if df.empty:
        logging.warning("Input DataFrame for feature engineering is empty. Returning empty DataFrame.")
        return df

    logging.info("Starting feature engineering...")

    # Ensure all auxiliary dataframes have standardized column names and are not empty
    # Make copies to avoid SettingWithCopyWarning if these are slices
    violation_codes_df_copy = standardize_column_names(violation_codes_df.copy())
    street_info_df_copy = standardize_column_names(street_info_df.copy())
    borough_zip_violations_df_copy = standardize_column_names(borough_zip_violations_df.copy())

    # --- Merge with Violation Codes ---
    if not violation_codes_df_copy.empty and 'Violation_Description' in violation_codes_df_copy.columns and 'Violation_Type' in violation_codes_df_copy.columns:
        df = pd.merge(df, violation_codes_df_copy[['Violation_Description', 'Violation_Type']],
                      on='Violation_Description', how='left')
        logging.debug(f"Merged with violation codes. Shape: {df.shape}")
    else:
        logging.warning("Violation codes data is empty or missing required columns. Adding default 'UNKNOWN_VIOLATION_TYPE'.")
        df['Violation_Type'] = 'UNKNOWN_VIOLATION_TYPE' # Add placeholder if merge not possible or data missing

    # --- Merge with Street Info (Borough, Zip Code) ---
    if not street_info_df_copy.empty and 'Street_Name' in street_info_df_copy.columns and 'Borough' in street_info_df_copy.columns and 'Zip_Code' in street_info_df_copy.columns:
        df = pd.merge(df, street_info_df_copy[['Street_Name', 'Borough', 'Zip_Code']],
                      on='Street_Name', how='left')
        logging.debug(f"Merged with street info. Shape: {df.shape}")
    else:
        logging.warning("Street info data is empty or missing required columns. Adding default 'UNKNOWN_BOROUGH' and -1 for Zip_Code.")
        df['Borough'] = 'UNKNOWN_BOROUGH'
        df['Zip_Code'] = -1

    # --- Merge with Borough and Zip Code Violations ---
    # Rename 'violation_count' in the auxiliary table to avoid conflict and make it a feature
    if not borough_zip_violations_df_copy.empty and 'Borough' in borough_zip_violations_df_copy.columns and 'Zip_Code' in borough_zip_violations_df_copy.columns and 'violation_count' in borough_zip_violations_df_copy.columns:
        borough_zip_violations_df_copy = borough_zip_violations_df_copy.rename(columns={'violation_count': 'borough_zip_2022_violation_count'})
        df = pd.merge(df, borough_zip_violations_df_copy[['Borough', 'Zip_Code', 'borough_zip_2022_violation_count']],
                      on=['Borough', 'Zip_Code'], how='left')
        logging.debug(f"Merged with borough_zip_violations_2022. Shape: {df.shape}")
    else:
        logging.warning("Borough-zip violations data is empty or missing required columns. Adding default 0 for aggregate count.")
        df['borough_zip_2022_violation_count'] = 0


    # --- Handle Missing Values (post-merge imputation) ---
    # Fill categorical NaNs with a placeholder string, numerical NaNs with 0 or -1.
    for col in ['Violation_Type', 'Borough']:
        if col in df.columns:
            df[col] = df[col].fillna('UNKNOWN_CATEGORY_MERGE_FAIL').astype(str)
        else: # Should be created by previous steps, but as a safeguard
            df[col] = 'UNKNOWN_CATEGORY_IMPUTED'

    if 'Zip_Code' in df.columns:
        df['Zip_Code'] = df['Zip_Code'].fillna(-1).astype(int)
    else:
        df['Zip_Code'] = -1

    if 'borough_zip_2022_violation_count' in df.columns:
        df['borough_zip_2022_violation_count'] = df['borough_zip_2022_violation_count'].fillna(0)
    else:
        df['borough_zip_2022_violation_count'] = 0

    logging.info("Feature engineering complete.")
    return df

def prepare_features_for_models(df, is_training=False, preprocessor_data=None):
    """
    Perpares features for tree models, handling categorical encoding by converting to 'category' dtype.
    This approach is adapted from the base solution, which is suitable for native categorical feature
    handling in LightGBM, XGBoost, and CatBoost without explicit LabelEncoding.
    For consistent feature sets between train and test, it uses a preprocessor_data dictionary
    to store mapping or column lists.
    """
    if preprocessor_data is None:
        preprocessor_data = {}
    if df.empty:
        logging.warning("Input DataFrame for feature preparation is empty. Returning empty DataFrame and default metadata.")
        return pd.DataFrame(), [], [], [], preprocessor_data

    logging.info(f"Preparing model features for {'training' if is_training else 'evaluation/test'} data...")

    # Define features to use. 'Street_Name' is included as CatBoost and XGBoost can handle high cardinality.
    # Zip_Code is treated as categorical for LightGBM/CatBoost by converting to 'category' dtype
    base_categorical_features = ['Street_Name', 'Violation_Description', 'Violation_Type', 'Borough', 'Zip_Code']
    numerical_features = ['borough_zip_2022_violation_count']

    # Ensure target column is not treated as a feature
    all_possible_features = [col for col in base_categorical_features + numerical_features if col != TARGET_COLUMN]

    # For training data, establish the final feature list and categorical columns
    if is_training:
        # Only include features actually present in the training DF
        features = [col for col in all_possible_features if col in df.columns]
        categorical_features_for_models = [col for col in base_categorical_features if col in features]
        
        preprocessor_data['features'] = features
        preprocessor_data['categorical_features'] = categorical_features_for_models
    else:
        # For test/eval, use the feature list established during training to ensure consistency
        if 'features' not in preprocessor_data:
            raise ValueError("Feature list not established during training. Cannot process test/eval data.")
        
        features = preprocessor_data['features']
        categorical_features_for_models = preprocessor_data['categorical_features']

        # Add any missing features (from training set) to the current DF, filling with defaults
        for col in features:
            if col not in df.columns:
                if col in base_categorical_features:
                    df[col] = 'MISSING_IN_TEST' if col != 'Zip_Code' else -1 # Placeholder for categorical
                elif col in numerical_features:
                    df[col] = 0.0 # Placeholder for numerical
        
        # Remove any extra columns present in current DF but not in training features
        # This prevents issues with models seeing unexpected columns
        df = df[features]

    # Convert categorical features to 'category' dtype for LightGBM/XGBoost
    for col in categorical_features_for_models:
        if col in df.columns:
            # Ensure Zip_Code is treated as categorical for tree models, even though it's numerical
            df[col] = df[col].astype('category')
        # Else: if it's missing, it should have been imputed above, so it should be present.
            
    # CatBoost expects either string column names or integer indices
    # We need indices relative to the 'features' list, not the full dataframe.
    categorical_features_indices_catboost = [features.index(col) for col in categorical_features_for_models if col in features]

    logging.info(f"Final features for models: {features}")
    logging.info(f"Categorical features for models (names): {categorical_features_for_models}")

    return df, features, categorical_features_for_models, categorical_features_indices_catboost, preprocessor_data


def train_and_predict_ensemble(X_train_df, y_train, X_eval_df, y_eval, X_test_df=None,
                                 features=None, categorical_features=None, categorical_features_indices_catboost=None):
    """
    Trains the LightGBM, XGBoost, and CatBoost models and averages their predictions.
    The LightGBM model now incorporates the refined parameters and early stopping from the reference solution.
    """
    if features is None or categorical_features is None or categorical_features_indices_catboost is None:
        raise ValueError("Feature metadata (features, categorical_features, categorical_features_indices_catboost) is required for model training.")
    
    if X_train_df.empty or y_train.empty or X_eval_df.empty or y_eval.empty:
        logging.error("Training or evaluation data is empty. Cannot train ensemble.")
        return np.array([]), float('inf'), np.array([])

    logging.info("Starting ensemble model training and prediction...")

    # Ensure y_train is non-negative for Poisson models
    y_train = y_train.clip(lower=0)

    lgbm_preds_eval = np.zeros(len(X_eval_df))
    xgboost_preds_eval = np.zeros(len(X_eval_df))
    catboost_preds_eval = np.zeros(len(X_eval_df))
    
    test_lgbm_preds = None
    test_xgboost_preds = None
    test_catboost_preds = None

    has_test_data = (X_test_df is not None and not X_test_df.empty)
    if has_test_data:
        test_lgbm_preds = np.zeros(len(X_test_df))
        test_xgboost_preds = np.zeros(len(X_test_df))
        test_catboost_preds = np.zeros(len(X_test_df))

    # --- Train LightGBM (with refined parameters and early stopping from reference) ---
    logging.info("Training LightGBM with refined parameters and early stopping...")
    # LGBM handles 'category' dtype columns automatically if specified or if feature_name=auto
    categorical_features_lgbm_names = [col for col in categorical_features if col in X_train_df.columns]
    
    lgbm_model = lgb.LGBMRegressor(objective='poisson',
                                   random_state=42,
                                   n_estimators=1000, # Increased from 500 (base) to 1000 (reference)
                                   learning_rate=0.05, # From reference
                                   n_jobs=-1,
                                   colsample_bytree=0.7, # From reference
                                   subsample=0.7, # From reference
                                   reg_alpha=0.1, # From reference
                                   reg_lambda=0.1, # From reference
                                   min_child_samples=20, # From reference
                                   verbose=-1 # Suppress verbose output during training
                                  )
    
    # Add early stopping from reference solution
    callbacks = [lgb.early_stopping(100, verbose=False)] # Stop if no improvement for 100 rounds

    lgbm_model.fit(X_train_df[features], y_train,
                    eval_set=[(X_eval_df[features], y_eval)], # Added eval_set for early stopping
                    eval_metric='rmse', # Monitor RMSE for early stopping
                    callbacks=callbacks, # Added callbacks
                    categorical_feature=categorical_features_lgbm_names)
    lgbm_preds_eval = lgbm_model.predict(X_eval_df[features])
    if has_test_data:
        test_lgbm_preds = lgbm_model.predict(X_test_df[features])
    logging.info("LightGBM training complete.")

    # --- Train XGBoost ---
    logging.info("Training XGBoost...")
    # XGBoost with enable_categorical=True handles 'category' dtype columns
    xgboost_model = xgb.XGBRegressor(
        objective='count:poisson',
        eval_metric='rmse', # For internal evaluation, not directly used for ensemble metric
        random_state=42,
        n_estimators=500,
        enable_categorical=True,
        tree_method='hist', # 'hist' for better performance with categorical features
        n_jobs=-1
    )
    xgboost_model.fit(X_train_df[features], y_train)
    xgboost_preds_eval = xgboost_model.predict(X_eval_df[features])
    if has_test_data:
        test_xgboost_preds = xgboost_model.predict(X_test_df[features])
    logging.info("XGBoost training complete.")

    # --- Train CatBoost ---
    logging.info("Training CatBoost...")
    # CatBoost expects either integer indices or column names for categorical features
    # Ensure indices are relative to the X_train_df[features] subset.
    # cat_features_indices_catboost is already prepared in prepare_features_for_models
    
    catboost_model = CatBoostRegressor(
        loss_function='Poisson',
        random_seed=42,
        iterations=500,
        verbose=0, # Suppress verbose output during training
        cat_features=categorical_features_indices_catboost,
        # thread_count=-1 # Can add this for more threads if needed, but default is often good
    )
    catboost_model.fit(X_train_df[features], y_train)
    catboost_preds_eval = catboost_model.predict(X_eval_df[features])
    if has_test_data:
        test_catboost_preds = catboost_model.predict(X_test_df[features])
    logging.info("CatBoost training complete.")

    # --- Ensemble Predictions (Simple Averaging) ---
    logging.info("Averaging ensemble predictions...")
    ensemble_predictions_eval = (lgbm_preds_eval + xgboost_preds_eval + catboost_preds_eval) / 3
    ensemble_predictions_eval = np.maximum(0, np.round(ensemble_predictions_eval)).astype(int)

    # Evaluate ensemble on validation set
    rmse_val = np.sqrt(mean_squared_error(y_eval, ensemble_predictions_eval))
    logging.info(f"Ensemble Validation RMSE: {rmse_val:.4f}")

    ensemble_predictions_test = None
    if has_test_data:
        ensemble_predictions_test = (test_lgbm_preds + test_xgboost_preds + test_catboost_preds) / 3
        ensemble_predictions_test = np.maximum(0, np.round(ensemble_predictions_test)).astype(int)
        logging.info("Ensemble test predictions generated.")
    
    return ensemble_predictions_eval, rmse_val, ensemble_predictions_test

def report_unseen_keys(train_keys_df, eval_keys_df, test_keys_df=None):
    """
    Reports the number of unseen (street_name, violation_description) pairs.
    This function is from the base solution.
    """
    if train_keys_df.empty:
        logging.warning("Training key data is empty. Cannot report unseen keys.")
        return 0, 0

    train_key_set = set(train_keys_df.apply(lambda row: (row['Street_Name'], row['Violation_Description']), axis=1))
    
    unseen_in_eval = 0
    if not eval_keys_df.empty:
        eval_key_set = set(eval_keys_df.apply(lambda row: (row['Street_Name'], row['Violation_Description']), axis=1))
        unseen_in_eval = len(eval_key_set - train_key_set)
        logging.info(f"{unseen_in_eval} out of {len(eval_key_set)} validation (Street_Name, Violation_Description) pairs were unseen in training data.")
    else:
        logging.warning("Evaluation key data is empty. Skipping unseen key reporting for evaluation set.")

    unseen_in_test = 0
    if test_keys_df is not None and not test_keys_df.empty:
        test_key_set = set(test_keys_df.apply(lambda row: (row['Street_Name'], row['Violation_Description']), axis=1))
        unseen_in_test = len(test_key_set - train_key_set)
        logging.info(f"{unseen_in_test} out of {len(test_key_set)} test (Street_Name, Violation_Description) pairs were unseen in training data.")
    else:
        logging.info("No test key data provided or it is empty. Skipping unseen key reporting for test set.")
    return unseen_in_eval, unseen_in_test

def main():
    args = parse_args()

    # Create output directory
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # --- Load Data ---
    train_full_df = load_data(args.train_path)
    if train_full_df.empty:
        logging.error("Training data could not be loaded or is empty. Cannot proceed.")
        return

    # Load auxiliary data
    violation_codes_df = load_data(AUX_VIOLATION_CODES_PATH)
    street_info_df = load_data(AUX_STREET_INFO_PATH)
    borough_zip_violations_df = load_data(AUX_BOROUGH_ZIP_VIOLATIONS_PATH)

    # Check for target column in training data early
    if TARGET_COLUMN not in train_full_df.columns:
        logging.error(f"Target column '{TARGET_COLUMN}' not found in training data. Cannot proceed.")
        return

    # --- Split 2022 data into training and validation ---
    # Using the base solution's more robust stratification strategy
    stratify_col = None
    # Prioritize Borough for stratification if available and has enough unique values
    if 'Borough' in train_full_df.columns and len(train_full_df['Borough'].unique()) > 1:
        stratify_col = train_full_df['Borough']
    # Fallback to Violation_Description if Borough isn't suitable, but be cautious with high cardinality
    elif 'Violation_Description' in train_full_df.columns and len(train_full_df['Violation_Description'].unique()) > 1:
        # Check if any group has only one member which would break stratification
        stratify_counts = train_full_df['Violation_Description'].value_counts()
        if (stratify_counts == 1).any():
            logging.warning("Some Violation_Description categories have only one sample. Stratification by this column might fail. Attempting anyway.")
        stratify_col = train_full_df['Violation_Description']
    
    try:
        if stratify_col is not None:
            train_data_2022, eval_data_2022 = train_test_split(
                train_full_df, test_size=0.2, random_state=42, stratify=stratify_col
            )
        else:
            logging.warning("Could not find a suitable column for stratification or all unique values are single. Using simple random split.")
            train_data_2022, eval_data_2022 = train_test_split(
                train_full_df, test_size=0.2, random_state=42
            )
    except ValueError as e:
        logging.warning(f"Stratification failed even after checks: {e}. Falling back to simple random split.")
        train_data_2022, eval_data_2022 = train_test_split(
            train_full_df, test_size=0.2, random_state=42
        )
    logging.info(f"Split 2022 data: Train {train_data_2022.shape}, Validation {eval_data_2022.shape}")

    # --- Feature Engineering ---
    # Using base solution's feature_engineer which passes auxiliary DFs and handles NaNs.
    train_data_fe = feature_engineer(train_data_2022.copy(), violation_codes_df, street_info_df, borough_zip_violations_df)
    eval_data_fe = feature_engineer(eval_data_2022.copy(), violation_codes_df, street_info_df, borough_zip_violations_df)

    # Check for empty dataframes after feature engineering
    if train_data_fe.empty or eval_data_fe.empty:
        logging.error("Empty DataFrame after feature engineering for train or eval. Cannot proceed.")
        return

    # --- Prepare Features for Models (ensuring consistent columns) ---
    # Using base solution's prepare_features_for_models which converts to 'category' dtype
    model_preprocessor_data = {} # To store feature lists and categorical column info
    
    X_train_df, features, categorical_features, categorical_features_indices_catboost, model_preprocessor_data = \
        prepare_features_for_models(train_data_fe.copy(), is_training=True, preprocessor_data=model_preprocessor_data)
    
    X_eval_df, _, _, _, model_preprocessor_data = \
        prepare_features_for_models(eval_data_fe.copy(), is_training=False, preprocessor_data=model_preprocessor_data)
    
    y_train = train_data_fe[TARGET_COLUMN]
    y_eval = eval_data_fe[TARGET_COLUMN]

    # --- Load and Process Test Data if provided ---
    test_df_original = None # Initialize as None
    X_test_df = pd.DataFrame() # Initialize as empty DataFrame
    if args.test_path:
        test_df_original = load_data(args.test_path)
        if test_df_original.empty:
            logging.error("Could not load test data or it is empty. Skipping test prediction.")
            test_df_original = pd.DataFrame() # Ensure it's an empty DataFrame if load failed
        else:
            # Check if 'violation_count' exists in test_df_original for evaluation
            has_ground_truth_test = TARGET_COLUMN in test_df_original.columns
            if has_ground_truth_test:
                logging.info(f"Test file '{args.test_path}' contains '{TARGET_COLUMN}'. Will report RMSE on it.")
            else:
                logging.info(f"Test file '{args.test_path}' does NOT contain '{TARGET_COLUMN}'. Will only generate predictions.")
            
            # Apply feature engineering to test data
            test_data_fe = feature_engineer(test_df_original.copy(), violation_codes_df, street_info_df, borough_zip_violations_df)
            
            # Prepare features for test data, using preprocessor_data from training
            X_test_df, _, _, _, model_preprocessor_data = \
                prepare_features_for_models(test_data_fe.copy(), is_training=False, preprocessor_data=model_preprocessor_data)
            
            if X_test_df.empty: # Check if prepare_features_for_models resulted in empty DF
                logging.error("Prepared test feature DataFrame is empty. Skipping test prediction.")
                X_test_df = pd.DataFrame() # Ensure it's empty DataFrame for checks later

    # --- Report Unseen Keys ---
    # Pass original DFs to report_unseen_keys as encoding is irrelevant for key comparison
    # Fix: Ensure test_df_original is not None before accessing .empty
    test_keys_for_report = pd.DataFrame()
    if test_df_original is not None and not test_df_original.empty:
        test_keys_for_report = test_df_original[KEY_COLUMNS]

    unseen_eval_pairs, unseen_test_pairs = report_unseen_keys(
        train_data_2022[KEY_COLUMNS], 
        eval_data_2022[KEY_COLUMNS],
        test_keys_for_report
    )

    # --- Train Model and Predict ---
    # The train_and_predict_ensemble function is updated to incorporate the reference's LGBM enhancements
    ensemble_val_predictions, final_validation_rmse, ensemble_test_predictions = train_and_predict_ensemble(
        X_train_df, y_train, X_eval_df, y_eval, X_test_df,
        features=features, categorical_features=categorical_features,
        categorical_features_indices_catboost=categorical_features_indices_catboost
    )

    print(f"Final Validation Performance: {final_validation_rmse:.4f}")

    # --- Generate Submission File ---
    # Only generate if X_test_df was actually provided and processed, and predictions were made
    if not X_test_df.empty and ensemble_test_predictions is not None and len(ensemble_test_predictions) == len(X_test_df):
        submission_df = test_df_original[KEY_COLUMNS].copy() # Use original keys for submission
        submission_df['predicted_count'] = ensemble_test_predictions

        submission_path = os.path.join(OUTPUT_DIR, SUBMISSION_FILENAME)
        submission_df.to_csv(submission_path, index=False)
        logging.info(f"Submission file generated at: {submission_path}")

        # If test set has ground truth, report RMSE for context
        if TARGET_COLUMN in test_df_original.columns:
            test_ground_truth = test_df_original[TARGET_COLUMN]
            rmse_test = np.sqrt(mean_squared_error(test_ground_truth, ensemble_test_predictions))
            logging.info(f"Test Set RMSE (against provided ground truth): {rmse_test:.4f}")
    elif args.test_path: # Test path was provided but processing failed or predictions weren't made for some reason
        logging.warning("No submission file generated due to issues with test data processing or prediction, or empty test data.")

if __name__ == "__main__":
    main()
