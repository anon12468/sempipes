
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import lightgbm as lgb
import gc
import re

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'

# Helper function to standardize column names
def _standardize_col_name(col_name: str) -> str:
    """Standardizes column names by replacing spaces with underscores,
    converting to lowercase, and removing non-alphanumeric characters."""
    return re.sub(r'[^a-z0-9_]', '', col_name.replace(' ', '_').lower())

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None,
                       use_log_transform_target: bool = True, use_interaction_feature: bool = True) -> (pd.DataFrame, dict):
    """
    Performs feature engineering on the input DataFrame.
    Ablation parameters:
    - use_log_transform_target: if False, skips log1p transformation on the target.
    - use_interaction_feature: if False, skips creation of 'street_violation_interaction'.
    """
    if encoder_dict is None:
        encoder_dict = {}

    # Standardize all columns of the DataFrame
    df.columns = [_standardize_col_name(col) for col in df.columns]

    # Standardized constant column names for internal use
    standardized_street_col = _standardize_col_name(STREET_NAME_COL)
    standardized_violation_col = _standardize_col_name(VIOLATION_DESC_COL)
    standardized_target_column = _standardize_col_name(TARGET_COLUMN)

    # Handle missing values for key categorical features
    for col in [standardized_street_col, standardized_violation_col]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # --- Frequency Encoding ---
    categorical_cols_to_encode = [standardized_street_col, standardized_violation_col]

    for col in categorical_cols_to_encode:
        if col in df.columns:
            if is_training:
                freq_map = df[col].value_counts(normalize=True).to_dict()
                encoder_dict[col + '_freq_map'] = freq_map
                df[col + '_freq_encoded'] = df[col].map(freq_map)
            else:
                if col + '_freq_map' in encoder_dict:
                    df[col + '_freq_encoded'] = df[col].map(encoder_dict[col + '_freq_map']).fillna(0)
                else:
                    df[col + '_freq_encoded'] = 0 # Default for new categories if no map

    # --- Smoothed Target Encoding ---
    smoothing_value = 100 # Hyperparameter for smoothing

    for col in categorical_cols_to_encode:
        if col in df.columns:
            if is_training:
                if standardized_target_column in df.columns:
                    # Calculate target encoding on the current (potentially raw) target scale
                    global_mean = df[standardized_target_column].mean()
                    agg = df.groupby(col)[standardized_target_column].agg(['count', 'mean'])
                    smoo_mean = (agg['count'] * agg['mean'] + smoothing_value * global_mean) / (agg['count'] + smoothing_value)
                    encoder_dict[col + '_target_map'] = smoo_mean.to_dict()
                    encoder_dict[col + '_global_mean'] = global_mean # Store global mean for inference
                    df[col + '_target_encoded'] = df[col].map(smoo_mean)
                else:
                    df[col + '_target_encoded'] = 0 # Default if target is missing
            else:
                if col + '_target_map' in encoder_dict and col + '_global_mean' in encoder_dict:
                    target_map = encoder_dict[col + '_target_map']
                    global_mean = encoder_dict[col + '_global_mean']
                    df[col + '_target_encoded'] = df[col].map(target_map).fillna(global_mean) # Fill unseen with global mean
                else:
                    df[col + '_target_encoded'] = 0 # Default if no map exists

    # --- Interaction Feature Ablation ---
    if use_interaction_feature:
        street_target_col_name = standardized_street_col + '_target_encoded'
        violation_target_col_name = standardized_violation_col + '_target_encoded'
        street_freq_col_name = standardized_street_col + '_freq_encoded'
        violation_freq_col_name = standardized_violation_col + '_freq_encoded'

        if (street_target_col_name in df.columns) and (violation_target_col_name in df.columns):
            df['street_violation_interaction'] = df[street_target_col_name] * df[violation_target_col_name]
        elif (street_freq_col_name in df.columns) and (violation_freq_col_name in df.columns):
            df['street_violation_interaction'] = df[street_freq_col_name] * df[violation_freq_col_name]
        # If neither target-encoded nor frequency-encoded features are available, the interaction feature is not created.

    # --- Log Transform Target Ablation ---
    if use_log_transform_target and standardized_target_column in df.columns and is_training:
        df[standardized_target_column] = np.log1p(df[standardized_target_column])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None,
                             use_log_transform_target: bool = True, use_interaction_feature: bool = True) -> (pd.DataFrame, dict):
    """
    Loads data from a CSV file and applies initial preprocessing, passing ablation flags to _engineer_features.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict,
                                         use_log_transform_target=use_log_transform_target,
                                         use_interaction_feature=use_interaction_feature)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series,
                learning_rate: float = 0.01) -> lgb.Booster:
    """
    Trains a LightGBM model.
    Ablation parameter:
    - learning_rate: controls the learning rate of the LGBM model.
    """
    # Ensure column names are compatible with LightGBM
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'regression_l1',  # MAE objective
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': learning_rate, # Ablation point
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 31,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)])

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_experiment(train_path: str, experiment_name: str,
                   use_log_transform_target: bool = True,
                   use_interaction_feature: bool = True,
                   learning_rate: float = 0.01) -> float:
    """
    Runs a single experiment configuration and returns the validation RMSE.
    """
    print(f"\n--- Running Experiment: {experiment_name} ---")

    # Standardized constant column names for consistency
    standardized_street_col = _standardize_col_name(STREET_NAME_COL)
    standardized_violation_col = _standardize_col_name(VIOLATION_DESC_COL)
    standardized_target_column = _standardize_col_name(TARGET_COLUMN)

    # Load and preprocess data with specified ablation flags
    df_2022_raw, encoder_dict = load_and_preprocess_data(
        train_path,
        is_training=True,
        use_log_transform_target=use_log_transform_target,
        use_interaction_feature=use_interaction_feature
    )

    # Split 2022 data for training and validation using grouped holdout
    df_2022_raw['group_id'] = df_2022_raw[standardized_street_col] + '_' + \
                               df_2022_raw[standardized_violation_col]

    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    # Define features (excluding target and original categorical columns)
    features = [col for col in df_train_raw.columns if col not in [standardized_target_column, standardized_street_col, standardized_violation_col]]

    X_train = df_train_raw[features]
    y_train = df_train_raw[standardized_target_column]

    X_val = df_val_raw[features]
    y_val = df_val_raw[standardized_target_column]

    print("Training model...")
    model = train_model(X_train, y_train, X_val, y_val, learning_rate=learning_rate)

    val_predictions_log = model.predict(X_val)

    # Inverse transform predictions and true values if log transform was applied
    if use_log_transform_target:
        val_predictions = np.expm1(val_predictions_log)
        y_val_original_scale = np.expm1(y_val)
    else:
        val_predictions = val_predictions_log # Predictions are already on original scale
        y_val_original_scale = y_val # Target was not log transformed

    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(y_val_original_scale, val_predictions)
    print(f"Validation RMSE for '{experiment_name}': {final_validation_rmse:.4f}")
    
    gc.collect() # Clean up memory
    return final_validation_rmse

def main():
    parser = argparse.ArgumentParser(description="Ablation study for NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()

    results = {}

    # --- Base Model Experiment ---
    results['Base Model'] = run_experiment(
        args.train_path,
        'Base Model (Log Transform, Interaction Feature, LR=0.01)',
        use_log_transform_target=True,
        use_interaction_feature=True,
        learning_rate=0.01
    )

    # --- Ablation 1: No Log Transform on Target ---
    results['Ablation 1: No Log Transform on Target'] = run_experiment(
        args.train_path,
        'No Log Transform on Target',
        use_log_transform_target=False,
        use_interaction_feature=True,
        learning_rate=0.01
    )

    # --- Ablation 2: No Street-Violation Interaction Feature ---
    results['Ablation 2: No Street-Violation Interaction Feature'] = run_experiment(
        args.train_path,
        'No Street-Violation Interaction Feature',
        use_log_transform_target=True,
        use_interaction_feature=False,
        learning_rate=0.01
    )

    # --- Ablation 3: Increase Learning Rate to 0.05 ---
    results['Ablation 3: Learning Rate = 0.05'] = run_experiment(
        args.train_path,
        'Learning Rate = 0.05 (Original 0.01)',
        use_log_transform_target=True,
        use_interaction_feature=True,
        learning_rate=0.05
    )

    print("\n--- Ablation Study Summary ---")
    for name, rmse in results.items():
        print(f"{name}: RMSE = {rmse:.4f}")

    # --- Contribution Analysis ---
    base_rmse = results['Base Model']
    print("\n--- Contribution Analysis ---")

    impacts = {}

    # Impact of Log Transform on Target
    rmse_no_log_transform = results['Ablation 1: No Log Transform on Target']
    diff_log_transform = rmse_no_log_transform - base_rmse
    if diff_log_transform < 0:
        print(f"Removing Log Transform on Target improved performance by {-diff_log_transform:.4f} RMSE (was detrimental).")
    elif diff_log_transform > 0:
        print(f"Removing Log Transform on Target degraded performance by {diff_log_transform:.4f} RMSE (was beneficial).")
    else:
        print("Removing Log Transform on Target had no significant impact on performance.")
    impacts['Log Transform on Target'] = abs(diff_log_transform)
    
    # Impact of Street-Violation Interaction Feature
    rmse_no_interaction = results['Ablation 2: No Street-Violation Interaction Feature']
    diff_interaction = rmse_no_interaction - base_rmse
    if diff_interaction < 0:
        print(f"Removing Street-Violation Interaction Feature improved performance by {-diff_interaction:.4f} RMSE (was detrimental).")
    elif diff_interaction > 0:
        print(f"Removing Street-Violation Interaction Feature degraded performance by {diff_interaction:.4f} RMSE (was beneficial).")
    else:
        print("Removing Street-Violation Interaction Feature had no significant impact on performance.")
    impacts['Street-Violation Interaction Feature'] = abs(diff_interaction)

    # Impact of Learning Rate to 0.05
    rmse_lr_005 = results['Ablation 3: Learning Rate = 0.05']
    diff_lr_005 = rmse_lr_005 - base_rmse
    if diff_lr_005 < 0:
        print(f"Changing Learning Rate to 0.05 improved performance by {-diff_lr_005:.4f} RMSE (was beneficial).")
    elif diff_lr_005 > 0:
        print(f"Changing Learning Rate to 0.05 degraded performance by {diff_lr_005:.4f} RMSE (was detrimental).")
    else:
        print("Changing Learning Rate to 0.05 had no significant impact on performance.")
    impacts['Learning Rate to 0.05'] = abs(diff_lr_005)
    
    # Determine the most impactful change (largest absolute difference in RMSE)
    most_impactful_element = max(impacts, key=impacts.get)
    print(f"\nThe most impactful part identified in this study is: {most_impactful_element}.")

if __name__ == "__main__":
    main()
