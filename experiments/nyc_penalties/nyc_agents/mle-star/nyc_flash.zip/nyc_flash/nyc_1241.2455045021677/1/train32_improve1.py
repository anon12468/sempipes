
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import catboost as cb
import os
import lightgbm as lgb
import gc

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv'

import pandas as pd
import numpy as np
# from sklearn.preprocessing import LabelEncoder # No longer needed for target-encoded features for specified columns

# Assume TARGET_COLUMN, STREET_NAME_COL, VIOLATION_DESC_COL are defined globally
# Example:
# TARGET_COLUMN = 'violation_count'
# STREET_NAME_COL = 'Street Name'
# VIOLATION_DESC_COL = 'Violation Description'


def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Performs feature engineering on the input DataFrame, introducing Target Encoding.
    """
    if encoder_dict is None:
        encoder_dict = {}

    # Standardize column names at the beginning
    df.columns = df.columns.str.replace(' ', '_').str.lower()

    # Get standardized names for target and categorical features
    # These are the names of the columns *after* standardization
    target_col_name = TARGET_COLUMN.replace(' ', '_').lower()
    street_name_col_name = STREET_NAME_COL.replace(' ', '_').lower()
    violation_desc_col_name = VIOLATION_DESC_COL.replace(' ', '_').lower()

    # Handle missing values for target-encoded features
    for col_name in [street_name_col_name, violation_desc_col_name]:
        if col_name in df.columns:
            df[col_name] = df[col_name].fillna('unknown').astype(str)

    # Log transform target if present and training, good for count data.
    # This transformation must happen BEFORE target encoding so that target means are based on log-transformed values.
    if target_col_name in df.columns and is_training:
        df[target_col_name] = np.log1p(df[target_col_name])

    # Target Encoding for specified categorical features
    categorical_cols_for_target_encoding = [street_name_col_name, violation_desc_col_name]

    if is_training:
        if target_col_name in df.columns: # Only perform target encoding if target is available in training
            # Calculate global mean of the log-transformed target
            global_target_mean = df[target_col_name].mean()
            encoder_dict['global_target_mean'] = global_target_mean

            for col in categorical_cols_for_target_encoding:
                if col in df.columns:
                    # Calculate mean of log-transformed target for each category
                    target_map = df.groupby(col)[target_col_name].mean().to_dict()
                    encoder_dict[col + '_target_map'] = target_map
                    # Apply mapping, filling unseen categories with the global target mean
                    df[col + '_target_encoded'] = df[col].map(target_map).fillna(global_target_mean)
                else:
                    # If categorical column not present, create the encoded column with global mean as default
                    df[col + '_target_encoded'] = global_target_mean
        else:
            # If target column is not present in training (e.g., for test set during full training flow),
            # target encoding cannot be done. Assign a default value (e.g., 0.0) to new features.
            for col in categorical_cols_for_target_encoding:
                df[col + '_target_encoded'] = 0.0 # Placeholder if target not available for encoding
    else: # is_training is False (validation or test set)
        # Retrieve global mean and target maps from the trained encoder_dict
        global_target_mean = encoder_dict.get('global_target_mean', 0.0) # Default to 0.0 if not found

        for col in categorical_cols_for_target_encoding:
            if col in df.columns:
                target_map = encoder_dict.get(col + '_target_map', {})
                # Apply stored mapping; unseen categories are imputed by global_target_mean
                df[col + '_target_encoded'] = df[col].map(target_map).fillna(global_target_mean)
            else:
                # If categorical column not present in inference, create the encoded column with global mean as default
                df[col + '_target_encoded'] = global_target_mean

    # The original Label Encoding block for 'street_name' and 'violation_description'
    # has been replaced by the more informative Target Encoding strategy above.
    # No other Label Encoding is specified in the improvement plan for other features,
    # so the original Label Encoding block is removed entirely.

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series) -> lgb.Booster:
    """
    Trains a LightGBM model.
    """
    # LightGBM expects feature names as strings and sanitized names
    original_train_cols = X_train.columns
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    # Identify categorical features based on the plan
    # Assuming 'street_name_encoded' and 'violation_description_encoded' are present
    # and are the only categorical features to be explicitly handled this way.
    # We need to use their sanitized names.
    categorical_features_names = []
    if 'street_name_encoded' in original_train_cols:
        categorical_features_names.append("street_name_encoded")
    if 'violation_description_encoded' in original_train_cols:
        categorical_features_names.append("violation_description_encoded")

    # LightGBM parameters
    params = {
        'objective': 'poisson',  # Changed objective to 'poisson' as per plan
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 63,  # Increased num_leaves from 31 to 63 as per plan
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)], # Use callbacks for early stopping
              categorical_feature=categorical_features_names) # Explicitly declare categorical features

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional: Path to the 2023 test/evaluation data CSV.')
    args = parser.parse_args()

    print(f"Loading training data from: {args.train_path}")
    df_2022_raw, encoder_dict = load_and_preprocess_data(args.train_path, is_training=True)

    # Split 2022 data for training and validation
    # Use grouped holdout for (street_name, violation_type) pairs
    # Create a unique identifier for splitting
    df_2022_raw['group_id'] = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

    # Get unique groups
    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    # Drop the temporary group_id
    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    # Define features and target
    features = [col for col in df_train_raw.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]]

    # Prepare training data
    X_train = df_train_raw[features]
    y_train = df_train_raw[TARGET_COLUMN]

    # Prepare validation data - CRITICAL FIX HERE: Extract y_val *before* any potential dropping or mismatch
    X_val = df_val_raw[features]
    y_val = df_val_raw[TARGET_COLUMN] # This ensures y_val is correctly assigned from the raw df_val_raw

    print("Training model...")
    model = train_model(X_train, y_train, X_val, y_val)

    # Predict on validation set for performance reporting
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log) # Inverse transform
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(np.expm1(y_val), val_predictions) # Calculate RMSE on original scale
    print(f"Final Validation Performance: {final_validation_rmse}")

    # If a test path is provided, generate predictions
    if args.test_path:
        print(f"Loading test data from: {args.test_path}")
        df_test_raw, _ = load_and_preprocess_data(args.test_path, is_training=False, encoder_dict=encoder_dict)

        # Ensure test data has the same features as training data
        test_features = [col for col in features if col in df_test_raw.columns]
        X_test = df_test_raw[test_features]

        # Align columns - crucial for consistent predictions
        # Add missing columns to X_test with 0, remove extra columns
        missing_cols = set(X_train.columns) - set(X_test.columns)
        for c in missing_cols:
            X_test[c] = 0
        extra_cols = set(X_test.columns) - set(X_train.columns)
        X_test = X_test.drop(columns=list(extra_cols))
        X_test = X_test[X_train.columns] # Ensure column order is the same

        print("Generating predictions for test data...")
        test_predictions_log = model.predict(X_test)
        test_predictions = np.expm1(test_predictions_log) # Inverse transform
        test_predictions[test_predictions < 0] = 0 # Clip negative predictions
        test_predictions = np.round(test_predictions).astype(int) # Round to nearest integer

        # Create submission file
        submission_df = pd.DataFrame({
            STREET_NAME_COL: df_test_raw[STREET_NAME_COL.replace(' ', '_').lower()],
            VIOLATION_DESC_COL: df_test_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()],
            PREDICTED_COUNT_COL: test_predictions
        })
        # Original column names for submission
        submission_df.columns = [STREET_NAME_COL, VIOLATION_DESC_COL, PREDICTED_COUNT_COL]

        submission_df.to_csv(OUTPUT_SUBMISSION_FILE, index=False)
        print(f"Submission file '{OUTPUT_SUBMISSION_FILE}' created successfully.")

        # If test_path contains 'violation_count', calculate RMSE
        if TARGET_COLUMN in df_test_raw.columns:
            y_test_true = np.expm1(df_test_raw[TARGET_COLUMN]) # Inverse log transform for actual values
            test_rmse = calculate_rmse(y_test_true, test_predictions)
            print(f"RMSE on provided test/evaluation data: {test_rmse}")

            # Report unseen key pairs
            train_keys = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]
            test_keys = df_test_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + df_test_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

            unseen_keys_count = test_keys.isin(train_keys).value_counts().get(False, 0)
            total_test_keys = len(test_keys)
            print(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {unseen_keys_count} out of {total_test_keys}")
            print("Unseen pairs are handled by the model's ability to generalize based on encoded features and numerical interaction features, "
                  "and by assigning -1 for unknown categories during Label Encoding transform.")

    gc.collect()

if __name__ == "__main__":
    main()
