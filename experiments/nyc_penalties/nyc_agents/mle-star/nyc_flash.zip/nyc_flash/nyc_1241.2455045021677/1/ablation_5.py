
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, KFold
from sklearn.metrics import mean_squared_error
import lightgbm as lgb
import gc
import sys
from io import StringIO

# Define constants for ORIGINAL column names from the dataset schema
ORIGINAL_TARGET_COLUMN = 'violation_count'
ORIGINAL_STREET_NAME_COL = 'Street Name'
ORIGINAL_VIOLATION_DESC_COL = 'Violation Description'

# Standardized column names for internal use
STANDARDIZED_TARGET_COL = ORIGINAL_TARGET_COLUMN.replace(' ', '_').lower()
STANDARDIZED_STREET_NAME_COL = ORIGINAL_STREET_NAME_COL.replace(' ', '_').lower()
STANDARDIZED_VIOLATION_DESC_COL = ORIGINAL_VIOLATION_DESC_COL.replace(' ', '_').lower()

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None,
                       enable_target_encoding: bool = True, enable_interaction_feature: bool = True) -> (pd.DataFrame, dict):
    """
    Performs feature engineering on the input DataFrame, including Target Encoding.
    Standardizes column names to lowercase with underscores.
    """
    if encoder_dict is None:
        encoder_dict = {}

    # Standardize ALL column names in the DataFrame
    df.columns = df.columns.str.replace(' ', '_').str.lower()
    
    categorical_cols_for_processing = [STANDARDIZED_STREET_NAME_COL, STANDARDIZED_VIOLATION_DESC_COL]
    
    # Handle missing values for categorical features
    for col in categorical_cols_for_processing:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # --- Log Transform Target (if present and training) ---
    # This transform is applied regardless of target encoding status for consistency with the baseline's log transform.
    if is_training and STANDARDIZED_TARGET_COL in df.columns:
        df[STANDARDIZED_TARGET_COL] = np.log1p(df[STANDARDIZED_TARGET_COL])
        # Only set global mean if target encoding is actually enabled
        if enable_target_encoding:
            encoder_dict['global_target_mean_log1p'] = df[STANDARDIZED_TARGET_COL].mean()
    elif not is_training and enable_target_encoding and 'global_target_mean_log1p' not in encoder_dict:
        # Fallback for inference if target encoding was enabled during training but global mean not set (shouldn't happen with proper training flow)
        encoder_dict['global_target_mean_log1p'] = 0.0

    # --- Target Encoding ---
    if enable_target_encoding:
        for col in categorical_cols_for_processing:
            if col in df.columns:
                encoded_col_name = col + '_target_encoded'
                if is_training:
                    if STANDARDIZED_TARGET_COL in df.columns:
                        # Out-of-fold encoding to prevent data leakage
                        kf = KFold(n_splits=5, shuffle=True, random_state=42)
                        oof_encodings = np.zeros(df.shape[0])
                        
                        for fold, (train_idx, val_idx) in enumerate(kf.split(df)):
                            df_train_fold, df_val_fold = df.iloc[train_idx], df.iloc[val_idx]
                            
                            # Calculate mean target for each category in the training fold
                            fold_target_map = df_train_fold.groupby(col)[STANDARDIZED_TARGET_COL].mean()
                            
                            # Apply to validation fold, filling unseen categories with the global mean
                            oof_encodings[val_idx] = df_val_fold[col].map(fold_target_map).fillna(
                                encoder_dict.get('global_target_mean_log1p', 0.0) # Use .get for safety
                            ).values

                        df[encoded_col_name] = oof_encodings

                        # Store the overall target map for inference (calculated on full training data)
                        full_target_map = df.groupby(col)[STANDARDIZED_TARGET_COL].mean().to_dict()
                        encoder_dict[col + '_target_map'] = full_target_map
                    else:
                        df[encoded_col_name] = 0.0
                else: # Inference
                    if col + '_target_map' in encoder_dict:
                        default_value = encoder_dict.get('global_target_mean_log1p', 0.0)
                        df[encoded_col_name] = df[col].map(encoder_dict[col + '_target_map']).fillna(default_value)
                    else:
                        df[encoded_col_name] = 0.0
    
    # --- Interaction feature (using the newly created target-encoded features) ---
    if enable_interaction_feature and enable_target_encoding: # Interaction feature only makes sense if target encoding created the base features
        if (STANDARDIZED_STREET_NAME_COL + '_target_encoded' in df.columns) and \
           (STANDARDIZED_VIOLATION_DESC_COL + '_target_encoded' in df.columns):
            df['street_violation_interaction'] = (
                df[STANDARDIZED_STREET_NAME_COL + '_target_encoded'] * 
                df[STANDARDIZED_VIOLATION_DESC_COL + '_target_encoded']
            )

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None,
                             enable_target_encoding: bool = True, enable_interaction_feature: bool = True) -> (pd.DataFrame, dict):
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict,
                                         enable_target_encoding=enable_target_encoding,
                                         enable_interaction_feature=enable_interaction_feature)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series,
                l1_reg: float = 0.1, l2_reg: float = 0.1,
                categorical_features_lgbm: list = None) -> lgb.Booster:
    """
    Trains a LightGBM model.
    """
    if categorical_features_lgbm is None:
        categorical_features_lgbm = []

    # Sanitize column names for LightGBM; LightGBM expects feature names as strings
    # and can have issues with special characters.
    X_train.columns = ["".join(c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join(c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    # Map original categorical feature names to their sanitized versions for LightGBM's categorical_feature parameter
    sanitized_categorical_features = []
    for col_name in categorical_features_lgbm:
        sanitized_name = "".join(c if c.isalnum() else "_" for c in str(col_name))
        if sanitized_name in X_train.columns: # Ensure the sanitized name exists in the dataframe
            sanitized_categorical_features.append(sanitized_name)

    params = {
        'objective': 'regression_l1',  # MAE objective
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': l1_reg,
        'lambda_l2': l2_reg,
        'num_leaves': 31,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)],
              categorical_feature=sanitized_categorical_features if sanitized_categorical_features else 'auto'
              )

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_ablation_experiment(train_path: str, experiment_name: str,
                            enable_target_encoding: bool = True,
                            enable_interaction_feature: bool = True,
                            l1_reg: float = 0.1, l2_reg: float = 0.1,
                            use_lgbm_categorical_handling: bool = False) -> float:
    
    # Store original stdout and redirect to suppress extensive print statements from LightGBM fit
    old_stdout = sys.stdout
    sys.stdout = StringIO()

    try:
        df_2022_raw, encoder_dict = load_and_preprocess_data(
            train_path,
            is_training=True,
            enable_target_encoding=enable_target_encoding,
            enable_interaction_feature=enable_interaction_feature
        )

        # Split 2022 data for training and validation
        df_2022_raw['group_id'] = df_2022_raw[STANDARDIZED_STREET_NAME_COL] + '_' + \
                                   df_2022_raw[STANDARDIZED_VIOLATION_DESC_COL]

        unique_groups = df_2022_raw['group_id'].unique()
        train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

        df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
        df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

        df_train_raw = df_train_raw.drop(columns=['group_id'])
        df_val_raw = df_val_raw.drop(columns=['group_id'])
        
        # Define features and target
        features_to_exclude = [STANDARDIZED_TARGET_COL, 'group_id'] # Ensure group_id is excluded if present
        
        # If target encoding is enabled, exclude the original string categorical columns as they are replaced by encoded ones.
        # Otherwise, they might be used directly as categorical features by LGBM if specified.
        if enable_target_encoding:
            features_to_exclude.extend([STANDARDIZED_STREET_NAME_COL, STANDARDIZED_VIOLATION_DESC_COL])
        
        features = [col for col in df_train_raw.columns if col not in features_to_exclude]
        
        categorical_features_for_lgbm_param = []
        if use_lgbm_categorical_handling:
            # If target encoding is NOT enabled, and we want LGBM to handle categoricals,
            # then the original string columns should be part of the features and identified here.
            # We explicitly add them to the list of features LGBM should treat as categorical.
            if not enable_target_encoding:
                # Ensure these columns are included in `features` if they weren't excluded by `enable_target_encoding`
                if STANDARDIZED_STREET_NAME_COL not in features:
                    features.append(STANDARDIZED_STREET_NAME_COL)
                if STANDARDIZED_VIOLATION_DESC_COL not in features:
                    features.append(STANDARDIZED_VIOLATION_DESC_COL)
            
            # These are the columns that LGBM should treat as categorical.
            categorical_features_for_lgbm_param.extend([STANDARDIZED_STREET_NAME_COL, STANDARDIZED_VIOLATION_DESC_COL])
        
        # Filter features to only include those present in both train and val DFs
        common_features = list(set(features) & set(df_train_raw.columns) & set(df_val_raw.columns))
        # Ensure order is consistent
        common_features = [f for f in features if f in common_features]

        X_train = df_train_raw[common_features]
        y_train = df_train_raw[STANDARDIZED_TARGET_COL]

        X_val = df_val_raw[common_features]
        y_val = df_val_raw[STANDARDIZED_TARGET_COL]

        # Convert specified categorical columns to pandas Categorical type for LightGBM
        # This is crucial for LightGBM to correctly interpret string columns as categories
        # when use_lgbm_categorical_handling is True and they are not target encoded.
        if use_lgbm_categorical_handling:
            for col in [STANDARDIZED_STREET_NAME_COL, STANDARDIZED_VIOLATION_DESC_COL]:
                if col in X_train.columns: # Check if the column is present in the features
                    X_train[col] = X_train[col].astype('category')
                    X_val[col] = X_val[col].astype('category')

        model = train_model(X_train, y_train, X_val, y_val, l1_reg=l1_reg, l2_reg=l2_reg,
                            categorical_features_lgbm=categorical_features_for_lgbm_param)

        val_predictions_log = model.predict(X_val)
        val_predictions = np.expm1(val_predictions_log)
        val_predictions[val_predictions < 0] = 0

        final_validation_rmse = calculate_rmse(np.expm1(y_val), val_predictions)

        gc.collect()
        return final_validation_rmse
    finally:
        # Restore stdout
        sys.stdout = old_stdout

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Ablation study for NYC parking violations model.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()

    results = {}
    print("Starting ablation study...")

    # --- Baseline ---
    # The default behavior of the provided script with Target Encoding, Interaction Feature, and L1/L2 reg (0.1)
    print("\nRunning Baseline experiment...")
    baseline_rmse = run_ablation_experiment(args.train_path, "Baseline")
    results["Baseline"] = baseline_rmse
    print(f"Final Validation Performance: {baseline_rmse:.4f}")

    # --- Ablation 1: Remove Target Encoding (use LGBM's built-in categorical handling instead) ---
    # This also implies no 'street_violation_interaction' feature as it depends on target_encoded features.
    print("\nRunning Ablation 1: Remove Target Encoding (use LGBM categorical handling)")
    ablation1_rmse = run_ablation_experiment(args.train_path, "No Target Encoding",
                                            enable_target_encoding=False,
                                            enable_interaction_feature=False, # Interaction depends on target encoding
                                            use_lgbm_categorical_handling=True)
    results["No Target Encoding (LGBM Categorical Handling)"] = ablation1_rmse
    print(f"Final Validation Performance: {ablation1_rmse:.4f}")

    # --- Ablation 2: Remove Interaction Feature (keeping Target Encoding) ---
    print("\nRunning Ablation 2: Remove Street-Violation Interaction Feature")
    ablation2_rmse = run_ablation_experiment(args.train_path, "No Interaction Feature",
                                            enable_interaction_feature=False)
    results["No Street-Violation Interaction Feature"] = ablation2_rmse
    print(f"Final Validation Performance: {ablation2_rmse:.4f}")

    # --- Ablation 3: Remove L1 and L2 Regularization ---
    print("\nRunning Ablation 3: Remove L1/L2 Regularization")
    ablation3_rmse = run_ablation_experiment(args.train_path, "No L1/L2 Regularization",
                                            l1_reg=0.0, l2_reg=0.0)
    results["No L1/L2 Regularization"] = ablation3_rmse
    print(f"Final Validation Performance: {ablation3_rmse:.4f}")

    print("\n--- Ablation Study Results ---")
    most_impactful_change = {"name": "", "delta": 0, "type": ""} # type: positive (improvement), negative (degradation)

    for name, rmse in results.items():
        if name == "Baseline":
            continue
        
        delta = baseline_rmse - rmse # Positive delta means improvement when removed/changed, negative means degradation
        
        print(f"Experiment: {name}")
        print(f"  RMSE: {rmse:.4f}")
        print(f"  Change vs Baseline: {delta:.4f} (Baseline: {baseline_rmse:.4f})")
        
        # Track the most impactful change (largest absolute delta from baseline)
        if abs(delta) > abs(most_impactful_change["delta"]):
            most_impactful_change["name"] = name
            most_impactful_change["delta"] = delta
            most_impactful_change["type"] = "improvement" if delta > 0 else "degradation"
        print()

    print("\n--- Conclusion ---")
    if most_impactful_change["name"]:
        print(f"The part of the code that contributes the most to the overall performance (largest absolute impact on RMSE) is: {most_impactful_change['name']}.")
        if most_impactful_change["type"] == "improvement":
            print(f"Its removal/modification led to an improvement in RMSE by {abs(most_impactful_change['delta']):.4f}.")
            print("This suggests that the original component was detrimental or less effective than the modified approach.")
        else:
            print(f"Its removal/modification led to a degradation in RMSE by {abs(most_impactful_change['delta']):.4f}.")
            print("This suggests that the original component was beneficial and contributed positively to the model's performance.")
    else:
        print("No significant impact observed from the ablated components.")

