
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc
import copy

# Define constants - these are based on the original Python solution
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> (pd.DataFrame, dict):
    """
    Performs feature engineering on the input DataFrame.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Handle missing values
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Label Encoding for categorical features
    categorical_cols = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col] = le
            else:
                if col in encoder_dict:
                    # Use transform for existing categories, map unknown to -1
                    le = encoder_dict[col]
                    mapping = {cls: le.transform([cls])[0] for cls in le.classes_}
                    df[col + '_encoded'] = df[col].map(mapping).fillna(-1).astype(int)
                else:
                    df[col + '_encoded'] = -1 # Assign a default for entirely new categories if no encoder

    # Log transform target if present, good for count data
    if TARGET_COLUMN in df.columns and is_training:
        df[TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None) -> (pd.DataFrame, dict):
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    return df, encoder_dict

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_experiment(name: str, train_path: str, ablation_config: dict):
    """
    Runs a single experiment (baseline or ablation) and returns validation RMSE.
    """
    print(f"\n--- Running Experiment: {name} ---")

    df_2022_raw, encoder_dict = load_and_preprocess_data(train_path, is_training=True)

    # Split 2022 data for training and validation using grouped holdout
    df_2022_raw['group_id'] = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    # Define features and target
    features = [col for col in df_train_raw.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]]

    X_train = df_train_raw[features]
    y_train = df_train_raw[TARGET_COLUMN]

    X_val = df_val_raw[features]
    y_val = df_val_raw[TARGET_COLUMN]

    # LightGBM expects feature names as strings and sanitized names
    original_train_cols = X_train.columns
    # Apply column sanitization from original code
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]
        
    categorical_features_names = []
    # Use sanitized names for categorical features for LGBM
    if 'street_name_encoded' in original_train_cols:
        categorical_features_names.append("".join (c if c.isalnum() else "_" for c in "street_name_encoded"))
    if 'violation_description_encoded' in original_train_cols:
        categorical_features_names.append("".join (c if c.isalnum() else "_" for c in "violation_description_encoded"))


    # LightGBM parameters (base from current solution)
    params = {
        'objective': 'poisson',
        'metric': ablation_config.get('metric', 'rmse'), # Ablation 1 config
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 63,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': ablation_config.get('boosting_type', 'gbdt'), # Ablation 3 config
    }

    # FIX: Remove bagging parameters if boosting_type is 'goss'
    if params['boosting_type'] == 'goss':
        print(f"Warning: Boosting type is 'goss'. Removing 'bagging_fraction' and 'bagging_freq' from parameters as they are incompatible.")
        params.pop('bagging_fraction', None)
        params.pop('bagging_freq', None)


    model = lgb.LGBMRegressor(**params)

    fit_kwargs = {
        'eval_set': [(X_val, y_val)],
        'eval_metric': ablation_config.get('eval_metric', 'rmse'), # Ablation 1 config
        'categorical_feature': categorical_features_names
    }
    # Ablation 2: No Early Stopping
    if not ablation_config.get('no_early_stopping', False):
        fit_kwargs['callbacks'] = [lgb.early_stopping(100, verbose=False)]

    print("Training model...")
    model.fit(X_train, y_train, **fit_kwargs)

    # Predict on validation set
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log) # Inverse transform
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(np.expm1(y_val), val_predictions) # Calculate RMSE on original scale
    print(f"Validation Performance ({name}): {final_validation_rmse}")
    print(f"Final Validation Performance: {final_validation_rmse}") # Required output line
    
    gc.collect() # Clean up memory for the next experiment

    return final_validation_rmse

def main_ablation_study():
    parser = argparse.ArgumentParser(description="Perform ablation study on NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()

    results = {}

    # 1. Baseline Experiment (Current solution as provided)
    baseline_config = {}
    results['Baseline'] = run_experiment('Baseline', args.train_path, baseline_config)

    # 2. Ablation 1: Align LGBM 'metric' and 'eval_metric' with 'objective' (Poisson)
    # The current solution uses objective='poisson', metric='rmse', eval_metric='rmse'.
    # This ablation aligns both metrics to 'poisson'.
    ablation1_config = {'metric': 'poisson', 'eval_metric': 'poisson'}
    results['Ablation 1: Align Metrics to Poisson'] = run_experiment('Ablation 1: Align Metrics to Poisson', args.train_path, ablation1_config)

    # 3. Ablation 2: No Early Stopping
    # The current solution uses early stopping with patience 100.
    # This ablation removes early stopping, letting the model train for full n_estimators.
    ablation2_config = {'no_early_stopping': True}
    results['Ablation 2: No Early Stopping'] = run_experiment('Ablation 2: No Early Stopping', args.train_path, ablation2_config)

    # 4. Ablation 3: Change Boosting Type to GOSS
    # The current solution uses boosting_type='gbdt'.
    # This ablation changes it to 'goss' (Gradient-based One-Side Sampling).
    ablation3_config = {'boosting_type': 'goss'}
    results['Ablation 3: Boosting Type GOSS'] = run_experiment('Ablation 3: Boosting Type GOSS', args.train_path, ablation3_config)

    print("\n--- Ablation Study Results Summary ---")
    for name, rmse in results.items():
        print(f"{name}: RMSE = {rmse:.4f}")

    # Determine the most impactful change
    baseline_rmse = results['Baseline']
    
    best_rmse_value = baseline_rmse
    most_impactful_component = "Baseline"
    
    print("\n--- Impact Analysis (Change relative to Baseline) ---")
    impacts = {}
    for name, rmse in results.items():
        if name != 'Baseline':
            # Positive impact means lower RMSE (improvement), negative means higher RMSE (degradation)
            impact = baseline_rmse - rmse
            impacts[name] = impact
            print(f"  {name} vs Baseline: Change = {impact:.4f} (positive means improvement, negative means degradation)")
            if rmse < best_rmse_value:
                best_rmse_value = rmse
                most_impactful_component = name

    print(f"\nConclusion: The part that contributes the most to the overall performance (i.e., resulted in the lowest RMSE) is: {most_impactful_component} with RMSE = {best_rmse_value:.4f}")

if __name__ == "__main__":
    main_ablation_study()
