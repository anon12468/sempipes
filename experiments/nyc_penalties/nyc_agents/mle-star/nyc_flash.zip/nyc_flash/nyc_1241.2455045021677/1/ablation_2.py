
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv' # Not used in ablation study output but part of original

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> (pd.DataFrame, dict):
    """
    Performs feature engineering on the input DataFrame.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Handle missing values
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Label Encoding for categorical features
    categorical_cols = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col] = le
            else:
                if col in encoder_dict:
                    # Use transform for existing categories, map unknown to -1
                    # Ensure df[col] is str to match encoder.classes_ type
                    df[col + '_encoded'] = df[col].astype(str).map(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else -1)
                else:
                    df[col + '_encoded'] = -1 # Assign a default for entirely new categories if no encoder

    # Example: Simple interaction feature
    if (STREET_NAME_COL.replace(' ', '_').lower() + '_encoded' in df.columns) and \
       (VIOLATION_DESC_COL.replace(' ', '_').lower() + '_encoded' in df.columns):
        df['street_violation_interaction'] = df[STREET_NAME_COL.replace(' ', '_').lower() + '_encoded'] * df[VIOLATION_DESC_COL.replace(' ', '_').lower() + '_encoded']

    # Log transform target if present, good for count data
    if TARGET_COLUMN in df.columns and is_training:
        df[TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None) -> (pd.DataFrame, dict):
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series,
                objective: str = 'regression_l1', boosting_type: str = 'gbdt') -> lgb.Booster:
    """
    Trains a LightGBM model with configurable objective and boosting_type.
    """
    # LightGBM expects feature names as strings
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': objective,
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 31,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': boosting_type,
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)])

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_ablation_experiment(train_path: str,
                            objective: str,
                            boosting_type: str,
                            clip_neg_predictions: bool,
                            description: str) -> float:
    """
    Runs a single ablation experiment and returns the validation RMSE.
    """
    print(f"\n--- Running Experiment: {description} ---")

    df_2022_raw, encoder_dict = load_and_preprocess_data(train_path, is_training=True)

    # Split 2022 data for training and validation using grouped holdout
    df_2022_raw['group_id'] = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    features = [col for col in df_train_raw.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]]

    X_train = df_train_raw[features]
    y_train = df_train_raw[TARGET_COLUMN]

    X_val = df_val_raw[features]
    y_val = df_val_raw[TARGET_COLUMN]

    print("Training model...")
    model = train_model(X_train, y_train, X_val, y_val, objective=objective, boosting_type=boosting_type)

    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log) # Inverse transform

    if clip_neg_predictions:
        val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(np.expm1(y_val), val_predictions) # Calculate RMSE on original scale
    print(f"Validation RMSE: {final_validation_rmse:.4f}")
    
    del df_2022_raw, df_train_raw, df_val_raw, X_train, y_train, X_val, y_val, model
    gc.collect()

    return final_validation_rmse

def main():
    parser = argparse.ArgumentParser(description="Ablation study for NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()

    results = {}

    print("----- Starting Ablation Study -----")
    # --- Baseline Experiment ---
    # This baseline matches the provided solution's original configuration.
    results['Baseline (Original solution settings)'] = run_ablation_experiment(
        args.train_path,
        objective='regression_l1',
        boosting_type='gbdt',
        clip_neg_predictions=True,
        description="Baseline (Original solution settings)"
    )

    # --- Ablation 1: Change LightGBM Objective ---
    results['Ablation: Change LGBM Objective to MSE'] = run_ablation_experiment(
        args.train_path,
        objective='regression', # Change from 'regression_l1' (MAE) to 'regression' (MSE)
        boosting_type='gbdt',
        clip_neg_predictions=True,
        description="Ablation: Change LGBM Objective to MSE"
    )

    # --- Ablation 2: Change LightGBM Boosting Type ---
    results['Ablation: Change LGBM Boosting Type to DART'] = run_ablation_experiment(
        args.train_path,
        objective='regression_l1',
        boosting_type='dart', # Change from 'gbdt' to 'dart'
        clip_neg_predictions=True,
        description="Ablation: Change LGBM Boosting Type to DART"
    )

    # --- Ablation 3: Remove Clipping Negative Predictions ---
    results['Ablation: Remove Clipping Negative Predictions'] = run_ablation_experiment(
        args.train_path,
        objective='regression_l1',
        boosting_type='gbdt',
        clip_neg_predictions=False, # Remove clipping
        description="Ablation: Remove Clipping Negative Predictions"
    )

    print("\n----- Ablation Study Results -----")
    baseline_rmse = results['Baseline (Original solution settings)']
    most_impactful_change = ""
    max_impact = 0.0

    for experiment, rmse in results.items():
        if experiment == 'Baseline (Original solution settings)':
            print(f"{experiment}: RMSE = {rmse:.4f}")
        else:
            diff = rmse - baseline_rmse
            print(f"{experiment}: RMSE = {rmse:.4f} (Difference from Baseline: {diff:+.4f})")
            abs_diff = abs(diff)
            if abs_diff > max_impact:
                max_impact = abs_diff
                most_impactful_change = experiment

    if most_impactful_change:
        print(f"\nThe part that contributes the most to the overall performance (largest absolute change in RMSE) is: {most_impactful_change}")
    else:
        print("Could not determine the most impactful part based on the conducted ablations.")

if __name__ == "__main__":
    main()
