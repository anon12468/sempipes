
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import argparse
import os
import logging
from tqdm import tqdm

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def calculate_rmse(y_true, y_pred):
    """Calculates the Root Mean Squared Error."""
    return np.sqrt(mean_squared_error(y_true, y_pred))

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame."""
    if not os.path.exists(file_path):
        logging.error(f"File not found: {file_path}")
        raise FileNotFoundError(f"File not found: {file_path}")
    logging.info(f"Loading data from {file_path}")
    df = pd.read_csv(file_path)
    # Standardize column names for easier access
    df.columns = [col.strip().replace(' ', '_').lower() for col in df.columns]
    return df

def feature_engineer(df, mode='train', street_violation_counts=None):
    """
    Performs feature engineering on the input DataFrame.
    'mode' can be 'train' or 'predict'.
    'street_violation_counts' is a Series of counts for (street, violation) pairs
    from training data, used to identify unseen pairs in prediction mode.
    """
    logging.info(f"Starting feature engineering for mode: {mode}")

    # Ensure required columns exist and standardize their names
    if 'street_name' not in df.columns and 'street' in df.columns:
        df = df.rename(columns={'street': 'street_name'})
    if 'violation_description' not in df.columns and 'violation_type' in df.columns:
        df = df.rename(columns={'violation_type': 'violation_description'})
    
    # Fill missing essential columns to prevent errors
    df['street_name'] = df['street_name'].fillna('UNKNOWN_STREET').astype(str).str.upper()
    df['violation_description'] = df['violation_description'].fillna('UNKNOWN_VIOLATION').astype(str).str.upper()

    # Create interaction feature
    df['street_violation_pair'] = df['street_name'] + "_" + df['violation_description']

    # Load augmentation tables (assuming they are in the 'input' directory)
    input_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'input')

    # Store initial categorical columns for later filtering
    initial_categorical_cols = set()
    for col in df.columns:
        if df[col].dtype == 'object' or df[col].dtype == 'category':
            initial_categorical_cols.add(col)

    try:
        # Augment with NYC street data
        nyc_streets_df = load_data(os.path.join(input_dir, 'nyc_streets.csv'))
        
        street_name_col_aug = None
        for col_option in ['street_name', 'street']:
            if col_option in nyc_streets_df.columns:
                street_name_col_aug = col_option
                break
        
        if street_name_col_aug:
            # Create a clean street name for merging in the augmentation table
            nyc_streets_df['street_name_merged_key'] = nyc_streets_df[street_name_col_aug].astype(str).str.upper()
            
            # Prepare numeric features for merging
            numeric_street_cols = [col for col in nyc_streets_df.columns if col not in [street_name_col_aug, 'borough', 'zip_code', 'street_name_merged_key'] and pd.api.types.is_numeric_dtype(nyc_streets_df[col])]
            
            street_features_to_merge = nyc_streets_df[['street_name_merged_key', 'borough', 'zip_code']].drop_duplicates(subset='street_name_merged_key').copy()
            
            if numeric_street_cols:
                numeric_agg_df = nyc_streets_df.groupby('street_name_merged_key')[numeric_street_cols].agg(['mean', 'median', 'std', 'count'])
                numeric_agg_df.columns = ['_'.join(col).strip() for col in numeric_agg_df.columns.values]
                numeric_agg_df = numeric_agg_df.reset_index()
                street_features_to_merge = pd.merge(street_features_to_merge, numeric_agg_df, on='street_name_merged_key', how='left')

            # Merge all street features with the main DataFrame
            df = pd.merge(df, street_features_to_merge,
                          left_on='street_name', right_on='street_name_merged_key', how='left')
            df = df.drop(columns=['street_name_merged_key'], errors='ignore') # Drop the merge key from augmentation table

            df['borough'] = df['borough'].fillna('UNKNOWN_BOROUGH').astype('category')
            # Fix: Convert zip_code to string before making it a category to avoid CatBoost numeric category error
            df['zip_code'] = df['zip_code'].fillna(-1).astype(str).astype('category') 
            
            logging.info("Augmented with nyc_streets.csv")
        else:
            logging.warning("No 'street_name' or 'street' column found in nyc_streets.csv for merging.")

    except FileNotFoundError:
        logging.warning("nyc_streets.csv not found, skipping street augmentation.")
    except Exception as e:
        logging.error(f"Error during nyc_streets.csv augmentation: {e}")

    try:
        # Augment with NYC violation codes data
        nyc_violation_codes_df = load_data(os.path.join(input_dir, 'nyc_violation_codes.csv'))
        
        violation_desc_col_aug = None
        for col_option in ['violation_description', 'description']:
            if col_option in nyc_violation_codes_df.columns:
                violation_desc_col_aug = col_option
                break
        
        if violation_desc_col_aug:
            nyc_violation_codes_df['violation_desc_merged_key'] = nyc_violation_codes_df[violation_desc_col_aug].astype(str).str.upper()
            
            # Prepare numeric features for merging
            numeric_violation_cols = [col for col in nyc_violation_codes_df.columns if col not in [violation_desc_col_aug, 'fine_amount', 'penalty_points', 'violation_desc_merged_key'] and pd.api.types.is_numeric_dtype(nyc_violation_codes_df[col])]
            
            violation_features_to_merge = nyc_violation_codes_df[['violation_desc_merged_key', 'fine_amount', 'penalty_points']].drop_duplicates(subset='violation_desc_merged_key').copy()

            if numeric_violation_cols:
                numeric_agg_df = nyc_violation_codes_df.groupby('violation_desc_merged_key')[numeric_violation_cols].agg(['mean', 'median', 'std', 'count'])
                numeric_agg_df.columns = ['_'.join(col).strip() for col in numeric_agg_df.columns.values]
                numeric_agg_df = numeric_agg_df.reset_index()
                violation_features_to_merge = pd.merge(violation_features_to_merge, numeric_agg_df, on='violation_desc_merged_key', how='left')

            # Merge all violation features with the main DataFrame
            df = pd.merge(df, violation_features_to_merge,
                          left_on='violation_description', right_on='violation_desc_merged_key', how='left')
            df = df.drop(columns=['violation_desc_merged_key'], errors='ignore') # Drop the merge key from augmentation table

            # Fill missing fine_amount/penalty_points with reasonable defaults (e.g., median or 0)
            if 'fine_amount' in df.columns:
                df['fine_amount'] = df['fine_amount'].fillna(df['fine_amount'].median() if mode == 'train' else 0)
            else:
                df['fine_amount'] = 0
            if 'penalty_points' in df.columns:
                df['penalty_points'] = df['penalty_points'].fillna(df['penalty_points'].median() if mode == 'train' else 0)
            else:
                df['penalty_points'] = 0
            
            logging.info("Augmented with nyc_violation_codes.csv")
        else:
            logging.warning("No 'violation_description' or 'description' column found in nyc_violation_codes.csv for merging.")

    except FileNotFoundError:
        logging.warning("nyc_violation_codes.csv not found, skipping violation augmentation.")
    except Exception as e:
        logging.error(f"Error during nyc_violation_codes.csv augmentation: {e}")

    # Feature for "newness" if a (street, violation) pair is not seen in training
    if mode == 'train':
        df['seen_pair'] = True
    elif mode == 'predict':
        # Create a set of unique (street_name, violation_description) pairs from the training data
        if street_violation_counts is not None:
            training_pairs_set = set(street_violation_counts.index.map(lambda x: f"{x[0]}_{x[1]}"))
            df['seen_pair'] = df['street_violation_pair'].isin(training_pairs_set)
        else:
            df['seen_pair'] = False # Default to false if no training data context provided

    # Handle numeric NaNs and infinities which might arise from merges or calculations
    for col in df.select_dtypes(include=np.number).columns:
        if np.isinf(df[col]).any():
            logging.warning(f"Column '{col}' contains infinities. Replacing with NaN then imputing.")
            df[col] = df[col].replace([np.inf, -np.inf], np.nan)
        if df[col].isnull().any():
            if mode == 'train':
                df[col] = df[col].fillna(df[col].median() if df[col].median() is not None else 0) # Handle case where median might be NaN
            else:
                df[col] = df[col].fillna(0) # For prediction, fill with 0 or a sensible default

    # Identify categorical features for CatBoost
    categorical_features_names = []
    for col in df.columns:
        if df[col].dtype == 'object' or df[col].dtype == 'category':
            # Ensure categorical columns are actually treated as categories by pandas
            df[col] = df[col].astype('category')
            categorical_features_names.append(col)
        elif df[col].dtype == bool:
            # Convert boolean to int for CatBoost
            df[col] = df[col].astype(int)

    logging.info(f"Finished feature engineering. DataFrame shape: {df.shape}")
    return df, categorical_features_names


def train_and_predict(args):
    """
    Main function to train the model and make predictions.
    """
    # Load training data
    train_df = load_data(args.train_path)

    # --- Initial Data Preprocessing for Training ---
    # Rename columns to match expected schema if needed
    if 'violation_count' not in train_df.columns:
        if 'violation_count_2022' in train_df.columns:
            train_df = train_df.rename(columns={'violation_count_2022': 'violation_count'})
        elif 'count' in train_df.columns:
            train_df = train_df.rename(columns={'count': 'violation_count'})
        else:
            logging.error("Training data must contain 'violation_count' column.")
            raise ValueError("Missing 'violation_count' in training data.")

    # Ensure target variable is non-negative
    train_df['violation_count'] = train_df['violation_count'].apply(lambda x: max(0, x))

    # Log transform target for better RMSE performance (often helps with count data)
    train_df['log_violation_count'] = np.log1p(train_df['violation_count'])

    # Keep track of all street_violation_pairs seen in training for unseen handling
    train_df['street_name'] = train_df['street_name'].fillna('UNKNOWN_STREET').astype(str).str.upper()
    train_df['violation_description'] = train_df['violation_description'].fillna('UNKNOWN_VIOLATION').astype(str).str.upper()
    street_violation_counts = train_df.groupby(['street_name', 'violation_description'])['violation_count'].sum()


    # --- Feature Engineering for Training Data ---
    train_df_fe, cat_features_names = feature_engineer(train_df.copy(), mode='train', street_violation_counts=street_violation_counts)

    # Define features (X) and target (y)
    features_to_drop = ['violation_count', 'log_violation_count', 'street_violation_pair']
    # Ensure we only drop columns that actually exist
    features_to_drop_existing = [col for col in features_to_drop if col in train_df_fe.columns]
    
    X = train_df_fe.drop(columns=features_to_drop_existing)
    y = train_df_fe['log_violation_count']

    # Filter `cat_features_names` to only include columns actually present in `X`
    cat_features_names_filtered = [col for col in cat_features_names if col in X.columns]
    logging.info(f"Identified {len(cat_features_names_filtered)} categorical features for CatBoost: {cat_features_names_filtered}")


    # --- Split data for validation ---
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    # Convert to CatBoost Pool format
    train_pool = Pool(X_train, y_train, cat_features=cat_features_names_filtered)
    val_pool = Pool(X_val, y_val, cat_features=cat_features_names_filtered)

    logging.info(f"Training data shape: {X_train.shape}, Validation data shape: {X_val.shape}")

    # --- CatBoost Model Training ---
    model = CatBoostRegressor(
        iterations=1500, # Increased iterations for potentially better performance
        learning_rate=0.03, # Slightly reduced learning rate
        depth=8,
        eval_metric='RMSE',
        random_seed=42,
        verbose=200, # Log every 200 iterations
        early_stopping_rounds=150, # Stop if validation RMSE doesn't improve for 150 rounds
        task_type='CPU', # Explicitly use CPU to avoid GPU-related OOM/crashes
        nan_mode='Min', # Handle NaNs by treating them as minimum values
        loss_function='RMSE', # Direct RMSE optimization
        # subsample=0.8, # Can be uncommented and adjusted if OOM is an issue on very large datasets
        # l2_leaf_reg=1, # L2 regularization
        allow_writing_files=False # Prevents CatBoost from writing auxiliary files
    )

    logging.info("Starting CatBoost training...")
    model.fit(train_pool, eval_set=val_pool, plot=False)

    # --- Validation Performance ---
    val_preds_log = model.predict(X_val)
    val_preds = np.expm1(val_preds_log) # Inverse log1p
    val_preds[val_preds < 0] = 0 # Clip negative predictions

    val_rmse = calculate_rmse(np.expm1(y_val), val_preds) # Calculate RMSE on original scale
    logging.info(f"Final Validation Performance: {val_rmse}")
    print(f"Final Validation Performance: {val_rmse}") # Required output format

    # --- Prediction Phase (if test_path is provided) ---
    if args.test_path:
        logging.info(f"Processing test file: {args.test_path}")
        test_df = load_data(args.test_path)

        # Create unique identifier before feature engineering and ensure names are standardized
        test_df_original_keys = test_df.copy() # Make a copy to preserve original values
        if 'street_name' not in test_df_original_keys.columns and 'street' in test_df_original_keys.columns:
            test_df_original_keys = test_df_original_keys.rename(columns={'street': 'street_name'})
        if 'violation_description' not in test_df_original_keys.columns and 'violation_type' in test_df_original_keys.columns:
            test_df_original_keys = test_df_original_keys.rename(columns={'violation_type': 'violation_description'})

        # Handle 'violation_count' column in test data - it's ground truth if present, not a feature
        if 'violation_count' in test_df.columns:
            y_test_true = test_df['violation_count']
            test_df = test_df.drop(columns=['violation_count'])
            has_ground_truth = True
            logging.info("Test file contains 'violation_count' for scoring.")
        else:
            has_ground_truth = False
            logging.info("Test file does not contain 'violation_count', generating pure predictions.")

        # --- Feature Engineering for Test Data ---
        test_df_fe, _ = feature_engineer(test_df.copy(), mode='predict', street_violation_counts=street_violation_counts)
        
        # Ensure test features match training features (order and existence)
        # It's crucial that `X_test` has the exact same columns in the exact same order as `X_train`
        
        missing_cols_in_test = set(X.columns) - set(test_df_fe.columns)
        for col in missing_cols_in_test:
            if col in cat_features_names_filtered: # If it was a categorical feature in training
                # Assign a placeholder value and ensure it's a categorical type (string for CatBoost)
                # CatBoost can handle unseen categories during prediction if they are strings.
                test_df_fe[col] = pd.Series(['UNKNOWN'] * len(test_df_fe), dtype='category', index=test_df_fe.index)
            elif pd.api.types.is_numeric_dtype(X[col]):
                test_df_fe[col] = 0 # Fill with 0 for numeric
            else:
                # Fallback for other non-numeric, non-cat types, treat as string
                test_df_fe[col] = 'UNKNOWN'
            logging.debug(f"Added missing column '{col}' to test_df_fe.")

        extra_cols_in_test = set(test_df_fe.columns) - set(X.columns)
        if extra_cols_in_test:
            test_df_fe = test_df_fe.drop(columns=list(extra_cols_in_test))
            logging.debug(f"Dropped extra columns from test_df_fe: {extra_cols_in_test}")

        X_test = test_df_fe[X.columns] # Reorder columns to match training set

        # Identify unseen pairs in the test set compared to training
        # Ensure `train_df_fe['street_violation_pair']` exists before comparison
        if 'street_violation_pair' in train_df_fe.columns:
            unseen_pairs_count = (~test_df_fe['street_violation_pair'].isin(train_df_fe['street_violation_pair'])).sum()
        else:
            unseen_pairs_count = 0 # No training pairs to compare against if column doesn't exist
        logging.info(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_pairs_count} out of {len(test_df_fe)}")


        logging.info("Generating predictions for test data...")
        test_preds_log = model.predict(X_test)
        test_preds = np.expm1(test_preds_log) # Inverse log1p
        test_preds[test_preds < 0] = 0 # Clip negative predictions

        # Create submission file
        submission_df = pd.DataFrame({
            'street_name': test_df_original_keys['street_name'],
            'violation_type': test_df_original_keys['violation_description'],
            'predicted_count': test_preds.round().astype(int) # Round and convert to int for count data
        })
        submission_df.to_csv('submission.csv', index=False)
        logging.info("Submission file 'submission.csv' created.")

        # Report RMSE for test data if ground truth is available
        if has_ground_truth:
            test_rmse = calculate_rmse(y_test_true, test_preds)
            logging.info(f"RMSE on test data: {test_rmse}")
            print(f"Test Set RMSE: {test_rmse}")
        else:
            logging.info("No ground truth 'violation_count' in test file to calculate RMSE.")
    else:
        logging.info("No test path provided. Skipping prediction phase.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help="Path to the 2022 training data CSV.")
    parser.add_argument('--test-path', type=str, default=None,
                        help="Optional: Path to the test data CSV for prediction.")
    args = parser.parse_args()

    # Create input directory if it doesn't exist for default paths
    os.makedirs('./input', exist_ok=True)

    # Create dummy augmentation files if they don't exist, for script to run without error
    # In a real scenario, these would be provided.
    dummy_nyc_streets_path = './input/nyc_streets.csv'
    if not os.path.exists(dummy_nyc_streets_path):
        logging.warning(f"Creating dummy {dummy_nyc_streets_path}. Please replace with real data for better performance.")
        pd.DataFrame({
            'street_name': ['1 AVENUE', 'MAIN STREET', 'BROADWAY', 'DUMMY STREET'],
            'borough': ['MANHATTAN', 'QUEENS', 'MANHATTAN', 'BRONX'],
            'zip_code': [10003, 11101, 10007, 10451],
            'street_length_miles': [5.0, 3.2, 13.0, 2.5],
            'number_of_intersections': [50, 30, 100, 20]
        }).to_csv(dummy_nyc_streets_path, index=False)

    dummy_nyc_violation_codes_path = './input/nyc_violation_codes.csv'
    if not os.path.exists(dummy_nyc_violation_codes_path):
        logging.warning(f"Creating dummy {dummy_nyc_violation_codes_path}. Please replace with real data for better performance.")
        pd.DataFrame({
            'violation_description': ['PHTO ENF CAM - RED LIGHT', 'NO PARKING-STREET CLEANING', 'OVERTIME PARKING', 'DOUBLE PARKING'],
            'fine_amount': [50, 65, 35, 80],
            'penalty_points': [0, 0, 0, 0]
        }).to_csv(dummy_nyc_violation_codes_path, index=False)

    try:
        train_and_predict(args)
    except Exception as e:
        logging.exception("An unhandled error occurred during script execution.")
        raise
