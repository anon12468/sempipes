
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.linear_model import PoissonRegressor
import lightgbm as lgb
import gc
from scipy.sparse import hstack, csr_matrix
import os

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv'

# Reference solution specific constants
AUX_VIOLATION_CODES_PATH = './input/nyc_parking_violation_codes.csv'
AUX_STREET_INFO_PATH = './input/nyc_street_names_info.csv'
AUX_BOROUGH_ZIP_VIOLATIONS_PATH = './input/violations_by_borough_and_zipcode_2022.csv'

# Column names standardized to match base solution's lower_snake_case convention
KEY_COLUMNS_SNAKE = ['street_name', 'violation_description']

def standardize_column_names(df: pd.DataFrame) -> pd.DataFrame:
    """Standardizes column names to lower_snake_case for consistency."""
    df.columns = df.columns.str.strip().str.replace(' ', '_').str.lower()
    return df

def load_csv_data(file_path: str) -> pd.DataFrame:
    """Loads CSV data from the given path."""
    try:
        df = pd.read_csv(file_path)
        return standardize_column_names(df)
    except FileNotFoundError:
        # Return an empty DataFrame with expected columns if a file is not found
        # This prevents downstream errors when merging or processing
        if file_path == AUX_VIOLATION_CODES_PATH:
            return pd.DataFrame(columns=['violation_description', 'violation_type'])
        elif file_path == AUX_STREET_INFO_PATH:
            return pd.DataFrame(columns=['street_name', 'borough', 'zip_code'])
        elif file_path == AUX_BOROUGH_ZIP_VIOLATIONS_PATH:
            return pd.DataFrame(columns=['borough', 'zip_code', 'violation_count'])
        else:
            print(f"Warning: File not found at {file_path}. Returning empty DataFrame.")
            return pd.DataFrame()
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return pd.DataFrame()

def _engineer_features_base(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> (pd.DataFrame, dict):
    """
    Performs base feature engineering on the input DataFrame, including base solution's LE
    for street name and violation description.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names if not already

    # Handle missing values for key columns
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Label Encoding for categorical features (base solution)
    categorical_cols_le = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]
    for col in categorical_cols_le:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col] = le
            else:
                if col in encoder_dict:
                    # Map unknown to -1. Transform known categories.
                    known_classes = list(encoder_dict[col].classes_)
                    # Use a lambda function to handle unseen labels
                    df[col + '_encoded'] = df[col].apply(lambda s: encoder_dict[col].transform([s])[0] if s in known_classes else -1)
                else:
                    df[col + '_encoded'] = -1 # Assign -1 if encoder for a column is completely missing

    # Example: Simple interaction feature (base solution)
    if (STREET_NAME_COL.replace(' ', '_').lower() + '_encoded' in df.columns) and \
       (VIOLATION_DESC_COL.replace(' ', '_').lower() + '_encoded' in df.columns):
        df['street_violation_interaction'] = df[STREET_NAME_COL.replace(' ', '_').lower() + '_encoded'] * df[VIOLATION_DESC_COL.replace(' ', '_').lower() + '_encoded']

    return df, encoder_dict

def merge_auxiliary_data(df: pd.DataFrame, violation_codes_df: pd.DataFrame, street_info_df: pd.DataFrame, borough_zip_violations_df: pd.DataFrame) -> pd.DataFrame:
    """
    Merges auxiliary data into the main DataFrame as per reference solution.
    Assumes all input DFs have standardized column names.
    """
    # Ensure relevant columns exist before merging and filter auxiliary dataframes
    violation_codes_df_filtered = violation_codes_df[['violation_description', 'violation_type']].copy() if all(col in violation_codes_df.columns for col in ['violation_description', 'violation_type']) else pd.DataFrame(columns=['violation_description', 'violation_type'])
    street_info_df_filtered = street_info_df[['street_name', 'borough', 'zip_code']].copy() if all(col in street_info_df.columns for col in ['street_name', 'borough', 'zip_code']) else pd.DataFrame(columns=['street_name', 'borough', 'zip_code'])
    borough_zip_violations_df_filtered = borough_zip_violations_df[['borough', 'zip_code', 'violation_count']].copy() if all(col in borough_zip_violations_df.columns for col in ['borough', 'zip_code', 'violation_count']) else pd.DataFrame(columns=['borough', 'zip_code', 'violation_count'])

    # --- Merge with Violation Codes ---
    if 'violation_description' in df.columns and 'violation_description' in violation_codes_df_filtered.columns:
        df = pd.merge(df, violation_codes_df_filtered, on='violation_description', how='left')
    
    # --- Merge with Street Info (Borough, Zip Code) ---
    if 'street_name' in df.columns and 'street_name' in street_info_df_filtered.columns:
        df = pd.merge(df, street_info_df_filtered, on='street_name', how='left')

    # --- Merge with Borough and Zip Code Violations ---
    if 'violation_count' in borough_zip_violations_df_filtered.columns:
        borough_zip_violations_df_filtered = borough_zip_violations_df_filtered.rename(columns={'violation_count': 'borough_zip_2022_violation_count'})
    
    if 'borough' in df.columns and 'zip_code' in df.columns and \
       'borough_zip_2022_violation_count' in borough_zip_violations_df_filtered.columns:
        # Ensure 'borough_zip_violations_df_filtered' only has the columns needed for merge and the new feature
        df = pd.merge(df, borough_zip_violations_df_filtered[['borough', 'zip_code', 'borough_zip_2022_violation_count']],
                      on=['borough', 'zip_code'], how='left')

    # --- Handle Missing Values for newly merged features ---
    # Categorical NaNs: 'UNKNOWN_CATEGORY'
    for col in ['violation_type', 'borough']:
        if col not in df.columns: # Add column if it doesn't exist
            df[col] = 'UNKNOWN_CATEGORY'
        df[col] = df[col].fillna('UNKNOWN_CATEGORY').astype(str)

    # Numerical NaNs: -1 for Zip_Code, 0 for aggregate counts
    if 'zip_code' not in df.columns:
        df['zip_code'] = -1
    df['zip_code'] = df['zip_code'].fillna(-1).astype(int)
    
    if 'borough_zip_2022_violation_count' not in df.columns:
        df['borough_zip_2022_violation_count'] = 0
    df['borough_zip_2022_violation_count'] = df['borough_zip_2022_violation_count'].fillna(0)

    return df

def _prepare_lgbm_features(df: pd.DataFrame, original_target_col: str) -> pd.DataFrame:
    """
    Prepares features specific for LightGBM model.
    """
    # Columns that should NOT be features for LGBM directly
    non_feature_cols = [original_target_col, 'street_name', 'violation_description', 'violation_type', 'borough', 'original_violation_count']
    
    # Select all columns that are not in non_feature_cols
    lgbm_feature_cols = [col for col in df.columns if col not in non_feature_cols]
    
    # Ensure selected features are numeric for LGBM.
    # LabelEncoded features are already numeric, as are merged numerical features.
    for col in lgbm_feature_cols:
        if not pd.api.types.is_numeric_dtype(df[col]):
            # Attempt to convert to numeric, coerce errors to NaN and fill
            df[col] = pd.to_numeric(df[col], errors='coerce').fillna(-1) # Use -1 as a default for non-numeric issues
            
    return df[lgbm_feature_cols]

def _prepare_glm_features(df: pd.DataFrame, is_training: bool, glm_preprocessors: dict) -> (csr_matrix, dict):
    """
    Prepares features for GLM, including One-Hot Encoding and numerical features.
    """
    # Define categorical and numerical features for the GLM
    categorical_features_for_ohe = ['violation_description', 'violation_type', 'borough']
    numerical_features = ['zip_code', 'borough_zip_2022_violation_count']

    # Filter to only include columns that are actually present in the dataframe
    categorical_features_for_ohe = [col for col in categorical_features_for_ohe if col in df.columns]
    numerical_features = [col for col in numerical_features if col in df.columns]

    ohe_features = None
    if categorical_features_for_ohe:
        # Ensure categorical columns are strings
        df[categorical_features_for_ohe] = df[categorical_features_for_ohe].astype(str)
        if is_training:
            # handle_unknown='ignore' allows the transformer to ignore unseen categories during transform,
            # which aligns with how LabelEncoder handles them by assigning -1 or similar.
            ohe = OneHotEncoder(handle_unknown='ignore', sparse_output=True)
            ohe.fit(df[categorical_features_for_ohe])
            glm_preprocessors['ohe'] = ohe
        else:
            ohe = glm_preprocessors.get('ohe')
            if ohe is None:
                # If OHE is not fitted in training, cannot transform test data.
                # Create an empty sparse matrix with 0 columns.
                return csr_matrix(np.empty((len(df), 0))), glm_preprocessors
        ohe_features = ohe.transform(df[categorical_features_for_ohe])

    num_features_to_concat = []
    for col in numerical_features:
        if col in df.columns:
            num_features_to_concat.append(df[col].values.reshape(-1, 1))
        else: # If numerical column is missing, add a column of zeros
            num_features_to_concat.append(np.zeros(len(df)).reshape(-1, 1))

    if ohe_features is not None and num_features_to_concat:
        X = hstack([ohe_features] + [csr_matrix(arr) for arr in num_features_to_concat])
    elif ohe_features is not None:
        X = ohe_features
    elif num_features_to_concat:
        X = hstack([csr_matrix(arr) for arr in num_features_to_concat])
    else:
        X = csr_matrix(np.empty((len(df), 0))) # Return empty sparse matrix if no features

    return X, glm_preprocessors

def train_lgbm_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series) -> lgb.Booster:
    """
    Trains a LightGBM model.
    """
    # LightGBM expects feature names as strings
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'regression_l1',  # MAE objective
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 31,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)])

    return model

def train_poisson_model(X_train_glm: csr_matrix, y_train_glm: pd.Series) -> PoissonRegressor:
    """
    Trains a PoissonRegressor model.
    """
    # PoissonRegressor expects non-negative targets
    y_train_glm_clipped = y_train_glm.copy().clip(lower=0)

    # Removed random_state as PoissonRegressor does not accept it
    poisson_glm_model = PoissonRegressor(alpha=1.0, fit_intercept=True, max_iter=1000)
    poisson_glm_model.fit(X_train_glm, y_train_glm_clipped)
    return poisson_glm_model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional: Path to the 2023 test/evaluation data CSV.')
    args = parser.parse_args()

    # Load auxiliary data once
    violation_codes_df = load_csv_data(AUX_VIOLATION_CODES_PATH)
    street_info_df = load_csv_data(AUX_STREET_INFO_PATH)
    borough_zip_violations_df = load_csv_data(AUX_BOROUGH_ZIP_VIOLATIONS_PATH)

    print(f"Loading training data from: {args.train_path}")
    df_2022_raw_original = load_csv_data(args.train_path)

    # Ensure the target column exists in the training data
    if TARGET_COLUMN.lower() not in df_2022_raw_original.columns:
        raise ValueError(f"Training data must contain '{TARGET_COLUMN}' column.")

    # --- Initial Feature Engineering & Auxiliary Data Merging for all data ---
    # Apply base LE and interaction features
    df_2022_processed_base, encoder_dict = _engineer_features_base(df_2022_raw_original.copy(), is_training=True)
    # Merge auxiliary data
    df_2022_processed = merge_auxiliary_data(df_2022_processed_base.copy(), violation_codes_df, street_info_df, borough_zip_violations_df)
    
    # Store the original (non-log-transformed) target values for Poisson model training and final RMSE calculation
    # Make sure to use the standardized column name for TARGET_COLUMN
    standardized_target_column = TARGET_COLUMN.lower().replace(' ', '_')
    df_2022_processed['original_violation_count'] = df_2022_processed[standardized_target_column].copy()

    # Log transform target for LGBM (after saving original target for GLM)
    df_2022_processed[standardized_target_column] = np.log1p(df_2022_processed[standardized_target_column])

    # Split 2022 data for training and validation (grouped holdout)
    df_2022_processed['group_id'] = df_2022_processed[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                                     df_2022_processed[VIOLATION_DESC_COL.replace(' ', '_').lower()]

    unique_groups = df_2022_processed['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_processed[df_2022_processed['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_processed[df_2022_processed['group_id'].isin(val_groups)].copy()

    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    # --- Prepare features for LGBM model ---
    X_train_lgbm = _prepare_lgbm_features(df_train_raw.copy(), standardized_target_column)
    y_train_lgbm = df_train_raw[standardized_target_column] # This is log1p transformed

    X_val_lgbm = _prepare_lgbm_features(df_val_raw.copy(), standardized_target_column)
    y_val_lgbm = df_val_raw[standardized_target_column] # This is log1p transformed

    # --- Prepare features for Poisson GLM model ---
    glm_preprocessors = {}
    X_train_glm, glm_preprocessors = _prepare_glm_features(df_train_raw.copy(), is_training=True, glm_preprocessors=glm_preprocessors)
    y_train_glm_original = df_train_raw['original_violation_count'] # Use original, non-log-transformed target for GLM

    X_val_glm, glm_preprocessors = _prepare_glm_features(df_val_raw.copy(), is_training=False, glm_preprocessors=glm_preprocessors)
    y_val_glm_original = df_val_raw['original_violation_count'] # Use original target for GLM evaluation

    print("Training LightGBM model...")
    lgbm_model = train_lgbm_model(X_train_lgbm, y_train_lgbm, X_val_lgbm, y_val_lgbm)

    print("Training Poisson GLM model...")
    poisson_model = train_poisson_model(X_train_glm, y_train_glm_original)

    # --- Predict on validation set ---
    val_predictions_lgbm_log = lgbm_model.predict(X_val_lgbm)
    val_predictions_lgbm = np.expm1(val_predictions_lgbm_log)
    val_predictions_lgbm[val_predictions_lgbm < 0] = 0

    val_predictions_poisson = poisson_model.predict(X_val_glm)
    val_predictions_poisson[val_predictions_poisson < 0] = 0

    # Ensemble predictions on validation set
    # Simple average, ensuring non-negative and integer
    val_predictions_ensemble = (val_predictions_lgbm + val_predictions_poisson) / 2
    val_predictions_ensemble = np.round(val_predictions_ensemble).astype(int)
    val_predictions_ensemble[val_predictions_ensemble < 0] = 0 # Final clipping just in case

    final_validation_rmse = calculate_rmse(y_val_glm_original, val_predictions_ensemble) # Calculate RMSE on original scale
    print(f"Final Validation Performance: {final_validation_rmse}")

    # If a test path is provided, generate predictions
    if args.test_path:
        print(f"Loading test data from: {args.test_path}")
        df_test_raw_original = load_csv_data(args.test_path)
        
        # Initial Feature Engineering & Auxiliary Data Merging for test data
        df_test_processed_base, _ = _engineer_features_base(df_test_raw_original.copy(), is_training=False, encoder_dict=encoder_dict)
        df_test_processed = merge_auxiliary_data(df_test_processed_base.copy(), violation_codes_df, street_info_df, borough_zip_violations_df)

        # Prepare features for LGBM
        X_test_lgbm = _prepare_lgbm_features(df_test_processed.copy(), standardized_target_column)
        
        # Align columns for LGBM.
        # Add missing columns with 0.
        missing_lgbm_cols = set(X_train_lgbm.columns) - set(X_test_lgbm.columns)
        for c in missing_lgbm_cols:
            X_test_lgbm[c] = 0
        # Drop extra columns.
        extra_lgbm_cols = set(X_test_lgbm.columns) - set(X_train_lgbm.columns)
        X_test_lgbm = X_test_lgbm.drop(columns=list(extra_lgbm_cols))
        # Ensure the order of columns is the same as in training data.
        X_test_lgbm = X_test_lgbm[X_train_lgbm.columns]

        # Prepare features for GLM
        X_test_glm, _ = _prepare_glm_features(df_test_processed.copy(), is_training=False, glm_preprocessors=glm_preprocessors)
        
        # Handle potential mismatch in GLM features (if _prepare_glm_features returned empty or mismatching features)
        if X_test_glm.shape[1] != X_train_glm.shape[1]:
            print(f"Warning: Test GLM features ({X_test_glm.shape[1]} columns) mismatch training GLM features ({X_train_glm.shape[1]} columns). "
                  "This usually indicates unseen categories were ignored. "
                  "Defaulting Poisson prediction for test to zeros where features are inconsistent.")
            # If shapes don't match, we cannot safely predict with the GLM.
            # A more robust approach might involve re-fitting OHE on combined train+test or ensuring all possible categories are known.
            # For this context, assigning zeros is a fallback to avoid errors.
            test_predictions_poisson = np.zeros(len(df_test_raw_original))
        else:
            print("Generating predictions for test data with Poisson GLM...")
            test_predictions_poisson = poisson_model.predict(X_test_glm)
            test_predictions_poisson[test_predictions_poisson < 0] = 0

        print("Generating predictions for test data with LightGBM...")
        test_predictions_lgbm_log = lgbm_model.predict(X_test_lgbm)
        test_predictions_lgbm = np.expm1(test_predictions_lgbm_log)
        test_predictions_lgbm[test_predictions_lgbm < 0] = 0

        # Ensemble test predictions
        test_predictions_ensemble = (test_predictions_lgbm + test_predictions_poisson) / 2
        test_predictions_ensemble = np.round(test_predictions_ensemble).astype(int)
        test_predictions_ensemble[test_predictions_ensemble < 0] = 0

        # Create submission file
        submission_df = pd.DataFrame({
            STREET_NAME_COL: df_test_raw_original[STREET_NAME_COL.replace(' ', '_').lower()], # Use original test data for keys
            VIOLATION_DESC_COL: df_test_raw_original[VIOLATION_DESC_COL.replace(' ', '_').lower()],
            PREDICTED_COUNT_COL: test_predictions_ensemble
        })
        # Original column names for submission
        submission_df.columns = [STREET_NAME_COL, VIOLATION_DESC_COL, PREDICTED_COUNT_COL]

        submission_df.to_csv(OUTPUT_SUBMISSION_FILE, index=False)
        print(f"Submission file '{OUTPUT_SUBMISSION_FILE}' created successfully.")

        # If test_path contains 'violation_count', calculate RMSE
        if standardized_target_column in df_test_raw_original.columns:
            y_test_true = df_test_raw_original[standardized_target_column] # Use actual values for RMSE
            test_rmse = calculate_rmse(y_test_true, test_predictions_ensemble)
            print(f"RMSE on provided test/evaluation data: {test_rmse}")

            # Report unseen key pairs (using original column names)
            # Ensure 'street_name' and 'violation_description' are standardized in train_keys_df_original
            train_keys_df_original = df_2022_raw_original[[col.replace(' ', '_').lower() for col in [STREET_NAME_COL, VIOLATION_DESC_COL]]]
            test_keys_df_original = df_test_raw_original[[col.replace(' ', '_').lower() for col in [STREET_NAME_COL, VIOLATION_DESC_COL]]]

            train_key_set = set(train_keys_df_original.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
            test_key_set = set(test_keys_df_original.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))

            unseen_in_test = test_key_set - train_key_set
            total_test_keys = len(test_key_set)
            print(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {len(unseen_in_test)} out of {total_test_keys}")
            print("Unseen pairs are handled by the model's ability to generalize based on encoded features and numerical interaction features, "
                  "and by assigning -1 for unknown categories during Label Encoding transform, and 'UNKNOWN_CATEGORY' for OHE.")

    gc.collect()

if __name__ == "__main__":
    main()
