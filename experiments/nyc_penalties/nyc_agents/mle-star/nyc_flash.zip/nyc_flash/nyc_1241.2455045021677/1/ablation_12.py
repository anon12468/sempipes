
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import catboost as cb # Not directly used in the provided solution's flow, but keeping imports consistent
import os
import lightgbm as lgb
import gc

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv' # Not used in the ablation study itself

# Modified _engineer_features to support ablations
def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None,
                       use_log_transform_target: bool = True, use_m_estimate_encoding: bool = True) -> pd.DataFrame:
    """
    Performs feature engineering on the input DataFrame with ablation flags.
    - use_log_transform_target: If True, applies log1p transformation to the target.
    - use_m_estimate_encoding: If True, uses M-estimate encoding; otherwise, uses Label Encoding.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Handle missing values
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    categorical_cols = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]

    if use_m_estimate_encoding:
        M_SMOOTHING_PARAM = 100 
        if is_training:
            # Determine the target values to use for M-estimate calculation
            if use_log_transform_target and TARGET_COLUMN in df.columns:
                temp_target_for_encoding = np.log1p(df[TARGET_COLUMN])
            elif TARGET_COLUMN in df.columns:
                temp_target_for_encoding = df[TARGET_COLUMN]
            else:
                temp_target_for_encoding = pd.Series([0.0] * len(df)) # Fallback, though TARGET_COLUMN should exist in training

            global_target_mean = temp_target_for_encoding.mean()
            encoder_dict['global_target_mean'] = global_target_mean
            encoder_dict['m_smoothing_param'] = M_SMOOTHING_PARAM

            for col in categorical_cols:
                if col in df.columns:
                    agg_df_temp = df.copy()
                    agg_df_temp['temp_target'] = temp_target_for_encoding
                    
                    agg_df = agg_df_temp.groupby(col)['temp_target'].agg(
                        count='count',
                        target_mean='mean'
                    ).reset_index()

                    agg_df['m_estimate'] = (
                        agg_df['count'] * agg_df['target_mean'] + 
                        encoder_dict['m_smoothing_param'] * encoder_dict['global_target_mean']
                    ) / (agg_df['count'] + encoder_dict['m_smoothing_param'])

                    m_estimate_map = agg_df.set_index(col)['m_estimate'].to_dict()
                    encoder_dict[col + '_m_estimate_map'] = m_estimate_map 
                    df[col + '_m_estimate'] = df[col].map(m_estimate_map).fillna(encoder_dict['global_target_mean'])
        else: # Inference mode
            global_mean_for_inference = encoder_dict.get('global_target_mean', 0.0) 
            for col in categorical_cols:
                if col in df.columns:
                    m_estimate_map_key = col + '_m_estimate_map'
                    if m_estimate_map_key in encoder_dict:
                        m_estimate_map = encoder_dict[m_estimate_map_key]
                        df[col + '_m_estimate'] = df[col].map(m_estimate_map).fillna(global_mean_for_inference)
                    else:
                        df[col + '_m_estimate'] = global_mean_for_inference
    else: # Use Label Encoding
        for col in categorical_cols:
            if col in df.columns:
                if is_training:
                    le = LabelEncoder()
                    df[col + '_encoded'] = le.fit_transform(df[col])
                    encoder_dict[col] = le
                else:
                    if col in encoder_dict:
                        # Use transform for existing categories, map unknown to -1
                        df[col + '_encoded'] = df[col].map(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else -1)
                    else:
                        df[col + '_encoded'] = -1 # Assign a default for entirely new categories

    # Apply log transform to the actual TARGET_COLUMN if enabled for training
    if TARGET_COLUMN in df.columns and is_training and use_log_transform_target:
        df[TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

# load_and_preprocess_data needs to be adapted to pass the new flags
def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None,
                             use_log_transform_target: bool = True, use_m_estimate_encoding: bool = True) -> (pd.DataFrame, dict):
    """
    Loads data from a CSV file and applies initial preprocessing with ablation flags.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict,
                                         use_log_transform_target=use_log_transform_target,
                                         use_m_estimate_encoding=use_m_estimate_encoding)
    return df, encoder_dict

# train_model needs to be adapted to pass n_estimators
def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series,
                n_estimators_param: int = 2000) -> lgb.Booster:
    """
    Trains a LightGBM model with n_estimators_param.
    """
    # LightGBM expects feature names as strings
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'regression_l1',  # MAE objective
        'metric': 'rmse',
        'n_estimators': n_estimators_param, # Ablation parameter
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 31,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)])

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_ablation_study():
    results = {}
    best_rmse = float('inf')
    best_config_name = "None"
    
    train_path = './input/violations_per_street_2022.csv'

    # --- Baseline Run (Current Solution) ---
    # This configuration represents the "current Python solution" provided
    df_2022_raw_base, encoder_dict_base = load_and_preprocess_data(train_path, 
                                                                    is_training=True, 
                                                                    use_log_transform_target=True,
                                                                    use_m_estimate_encoding=True)
    
    df_2022_raw_base['group_id'] = df_2022_raw_base[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                                    df_2022_raw_base[VIOLATION_DESC_COL.replace(' ', '_').lower()]
    unique_groups_base = df_2022_raw_base['group_id'].unique()
    train_groups_base, val_groups_base = train_test_split(unique_groups_base, test_size=0.2, random_state=42)
    df_train_base = df_2022_raw_base[df_2022_raw_base['group_id'].isin(train_groups_base)].copy()
    df_val_base = df_2022_raw_base[df_2022_raw_base['group_id'].isin(val_groups_base)].copy()

    features_base = [col for col in df_train_base.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower(), 'group_id']]
    X_train_base = df_train_base[features_base]
    y_train_base = df_train_base[TARGET_COLUMN] # Is log transformed
    X_val_base = df_val_base[features_base]
    y_val_base = df_val_base[TARGET_COLUMN] # Is log transformed

    model_base = train_model(X_train_base, y_train_base, X_val_base, y_val_base, n_estimators_param=2000)
    val_predictions_log_base = model_base.predict(X_val_base)
    val_predictions_base = np.expm1(val_predictions_log_base) # Inverse transform
    val_predictions_base[val_predictions_base < 0] = 0
    rmse_base = calculate_rmse(np.expm1(y_val_base), val_predictions_base) # Calculate RMSE on original scale
    
    results["Baseline (Current Solution)"] = rmse_base
    print(f"Baseline (Current Solution) Validation RMSE: {rmse_base:.4f}")
    
    best_rmse = rmse_base
    best_config_name = "Baseline (Current Solution)"
    
    del df_2022_raw_base, df_train_base, df_val_base, X_train_base, y_train_base, X_val_base, y_val_base, model_base
    gc.collect()

    # --- Ablation 1: Remove Log Transform on Target ---
    # Previous studies (1, 7, 9) indicated log transform might be detrimental.
    df_2022_raw_abl1, encoder_dict_abl1 = load_and_preprocess_data(train_path, 
                                                                    is_training=True, 
                                                                    use_log_transform_target=False,
                                                                    use_m_estimate_encoding=True)

    df_2022_raw_abl1['group_id'] = df_2022_raw_abl1[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                                    df_2022_raw_abl1[VIOLATION_DESC_COL.replace(' ', '_').lower()]
    unique_groups_abl1 = df_2022_raw_abl1['group_id'].unique()
    train_groups_abl1, val_groups_abl1 = train_test_split(unique_groups_abl1, test_size=0.2, random_state=42)
    df_train_abl1 = df_2022_raw_abl1[df_2022_raw_abl1['group_id'].isin(train_groups_abl1)].copy()
    df_val_abl1 = df_2022_raw_abl1[df_2022_raw_abl1['group_id'].isin(val_groups_abl1)].copy()

    features_abl1 = [col for col in df_train_abl1.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower(), 'group_id']]
    X_train_abl1 = df_train_abl1[features_abl1]
    y_train_abl1 = df_train_abl1[TARGET_COLUMN] # NOT log transformed
    X_val_abl1 = df_val_abl1[features_abl1]
    y_val_abl1 = df_val_abl1[TARGET_COLUMN] # NOT log transformed

    model_abl1 = train_model(X_train_abl1, y_train_abl1, X_val_abl1, y_val_abl1, n_estimators_param=2000)
    val_predictions_abl1 = model_abl1.predict(X_val_abl1) # Predictions are on original scale
    val_predictions_abl1[val_predictions_abl1 < 0] = 0
    rmse_abl1 = calculate_rmse(y_val_abl1, val_predictions_abl1) # y_val_abl1 is NOT log transformed
    
    results["No Log Transform on Target"] = rmse_abl1
    print(f"Ablation (No Log Transform on Target) Validation RMSE: {rmse_abl1:.4f}")
    if rmse_abl1 < best_rmse:
        best_rmse = rmse_abl1
        best_config_name = "No Log Transform on Target"
    
    del df_2022_raw_abl1, df_train_abl1, df_val_abl1, X_train_abl1, y_train_abl1, X_val_abl1, y_val_abl1, model_abl1
    gc.collect()

    # --- Ablation 2: Revert M-estimate Encoding to Label Encoding ---
    # The current solution uses M-estimate encoding; testing Label Encoding as a fallback.
    # Study 8 suggested "Smoothed Target Encoding" (a type of target encoding) was detrimental.
    df_2022_raw_abl2, encoder_dict_abl2 = load_and_preprocess_data(train_path, 
                                                                    is_training=True, 
                                                                    use_log_transform_target=True, # Revert to baseline log transform
                                                                    use_m_estimate_encoding=False) # Use Label Encoding

    df_2022_raw_abl2['group_id'] = df_2022_raw_abl2[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                                    df_2022_raw_abl2[VIOLATION_DESC_COL.replace(' ', '_').lower()]
    unique_groups_abl2 = df_2022_raw_abl2['group_id'].unique()
    train_groups_abl2, val_groups_abl2 = train_test_split(unique_groups_abl2, test_size=0.2, random_state=42)
    df_train_abl2 = df_2022_raw_abl2[df_2022_raw_abl2['group_id'].isin(train_groups_abl2)].copy()
    df_val_abl2 = df_2022_raw_abl2[df_2022_raw_abl2['group_id'].isin(val_groups_abl2)].copy()
    
    features_abl2 = [col for col in df_train_abl2.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower(), 'group_id']]
    X_train_abl2 = df_train_abl2[features_abl2]
    y_train_abl2 = df_train_abl2[TARGET_COLUMN] # Is log transformed
    X_val_abl2 = df_val_abl2[features_abl2]
    y_val_abl2 = df_val_abl2[TARGET_COLUMN] # Is log transformed

    model_abl2 = train_model(X_train_abl2, y_train_abl2, X_val_abl2, y_val_abl2, n_estimators_param=2000)
    val_predictions_log_abl2 = model_abl2.predict(X_val_abl2)
    val_predictions_abl2 = np.expm1(val_predictions_log_abl2) # Inverse transform
    val_predictions_abl2[val_predictions_abl2 < 0] = 0
    rmse_abl2 = calculate_rmse(np.expm1(y_val_abl2), val_predictions_abl2) # Calculate RMSE on original scale
    
    results["Label Encoding instead of M-estimate"] = rmse_abl2
    print(f"Ablation (Label Encoding instead of M-estimate) Validation RMSE: {rmse_abl2:.4f}")
    if rmse_abl2 < best_rmse:
        best_rmse = rmse_abl2
        best_config_name = "Label Encoding instead of M-estimate"
    
    del df_2022_raw_abl2, df_train_abl2, df_val_abl2, X_train_abl2, y_train_abl2, X_val_abl2, y_val_abl2, model_abl2
    gc.collect()

    # --- Ablation 3: Reduce n_estimators to 500 ---
    # Testing the impact of maximum boosting rounds, which wasn't directly ablated before.
    df_2022_raw_abl3, encoder_dict_abl3 = load_and_preprocess_data(train_path, 
                                                                    is_training=True, 
                                                                    use_log_transform_target=True,
                                                                    use_m_estimate_encoding=True)

    df_2022_raw_abl3['group_id'] = df_2022_raw_abl3[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                                    df_2022_raw_abl3[VIOLATION_DESC_COL.replace(' ', '_').lower()]
    unique_groups_abl3 = df_2022_raw_abl3['group_id'].unique()
    train_groups_abl3, val_groups_abl3 = train_test_split(unique_groups_abl3, test_size=0.2, random_state=42)
    df_train_abl3 = df_2022_raw_abl3[df_2022_raw_abl3['group_id'].isin(train_groups_abl3)].copy()
    df_val_abl3 = df_2022_raw_abl3[df_2022_raw_abl3['group_id'].isin(val_groups_abl3)].copy()

    features_abl3 = [col for col in df_train_abl3.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower(), 'group_id']]
    X_train_abl3 = df_train_abl3[features_abl3]
    y_train_abl3 = df_train_abl3[TARGET_COLUMN] # Is log transformed
    X_val_abl3 = df_val_abl3[features_abl3]
    y_val_abl3 = df_val_abl3[TARGET_COLUMN] # Is log transformed

    model_abl3 = train_model(X_train_abl3, y_train_abl3, X_val_abl3, y_val_abl3, n_estimators_param=500) # Reduced n_estimators
    val_predictions_log_abl3 = model_abl3.predict(X_val_abl3)
    val_predictions_abl3 = np.expm1(val_predictions_log_abl3) # Inverse transform
    val_predictions_abl3[val_predictions_abl3 < 0] = 0
    rmse_abl3 = calculate_rmse(np.expm1(y_val_abl3), val_predictions_abl3) # Calculate RMSE on original scale
    
    results["Reduce n_estimators to 500"] = rmse_abl3
    print(f"Ablation (Reduce n_estimators to 500) Validation RMSE: {rmse_abl3:.4f}")
    if rmse_abl3 < best_rmse:
        best_rmse = rmse_abl3
        best_config_name = "Reduce n_estimators to 500"
    
    del df_2022_raw_abl3, df_train_abl3, df_val_abl3, X_train_abl3, y_train_abl3, X_val_abl3, y_val_abl3, model_abl3
    gc.collect()

    print("\n--- Ablation Study Results ---")
    for name, rmse in results.items():
        print(f"{name}: RMSE = {rmse:.4f}")

    print(f"\nConclusion: The component change that led to the best performance (lowest RMSE) was: {best_config_name} with an RMSE of {best_rmse:.4f}")


if __name__ == "__main__":
    run_ablation_study()

