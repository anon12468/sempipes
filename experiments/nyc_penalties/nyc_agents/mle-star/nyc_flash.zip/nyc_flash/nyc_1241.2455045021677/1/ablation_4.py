
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv' # Not used in ablation, but kept for completeness

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None,
                      disable_text_features: bool = False, disable_label_encoding: bool = False) -> (pd.DataFrame, dict):
    """
    Performs feature engineering on the input DataFrame, including frequency encoding
    and text-based features for 'Violation Description'.
    Ablation flags allow disabling specific feature groups.
    """
    if encoder_dict is None:
        encoder_dict = {}

    # Initialize container for frequency maps if not already present
    if 'frequency_maps' not in encoder_dict:
        encoder_dict['frequency_maps'] = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Get standardized column names for consistent referencing
    street_name_col_std = STREET_NAME_COL.replace(' ', '_').lower()
    violation_desc_col_std = VIOLATION_DESC_COL.replace(' ', '_').lower()

    # Handle missing values for key categorical columns first
    for col_std in [street_name_col_std, violation_desc_col_std]:
        if col_std in df.columns:
            df[col_std] = df[col_std].fillna('unknown').astype(str)

    # Frequency Encoding for Street Name and Violation Description (retained as per previous study)
    cols_for_freq_encoding = [street_name_col_std, violation_desc_col_std]
    for col_std in cols_for_freq_encoding:
        if col_std in df.columns:
            new_freq_col_name = f"{col_std}_freq_encoded"
            if is_training:
                freq_map = df[col_std].value_counts(normalize=True).to_dict()
                encoder_dict['frequency_maps'][col_std] = freq_map
                df[new_freq_col_name] = df[col_std].map(freq_map)
            else:
                if col_std in encoder_dict['frequency_maps']:
                    freq_map = encoder_dict['frequency_maps'][col_std]
                    df[new_freq_col_name] = df[col_std].map(freq_map).fillna(0.0)
                else:
                    df[new_freq_col_name] = 0.0

    # Text-based features for Violation Description (Ablation Target 1)
    if not disable_text_features and violation_desc_col_std in df.columns:
        df[f"{violation_desc_col_std}_char_len"] = df[violation_desc_col_std].astype(str).apply(len)
        df[f"{violation_desc_col_std}_word_count"] = df[violation_desc_col_std].astype(str).apply(lambda x: len(str(x).split()))

    # Label Encoding for categorical features (Ablation Target 2)
    if not disable_label_encoding:
        categorical_cols_for_le = [street_name_col_std, violation_desc_col_std]
        for col_std in categorical_cols_for_le:
            if col_std in df.columns:
                new_le_col_name = f"{col_std}_encoded"
                if is_training:
                    le = LabelEncoder()
                    df[new_le_col_name] = le.fit_transform(df[col_std])
                    encoder_dict[col_std] = le
                else:
                    if col_std in encoder_dict:
                        le = encoder_dict[col_std]
                        le_classes_map = {cls: idx for idx, cls in enumerate(le.classes_)}
                        df[new_le_col_name] = df[col_std].map(le_classes_map).fillna(-1).astype(int)
                    else:
                        df[new_le_col_name] = -1

    # Simple interaction feature (depends on Label Encoding, also found detrimental in previous study 1)
    if not disable_label_encoding and \
       (f"{street_name_col_std}_encoded" in df.columns) and \
       (f"{violation_desc_col_std}_encoded" in df.columns):
        df['street_violation_interaction'] = \
            df[f"{street_name_col_std}_encoded"] * df[f"{violation_desc_col_std}_encoded"]

    # Log transform target if present and in training mode (found detrimental in previous study 1)
    if TARGET_COLUMN in df.columns and is_training:
        df[TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None,
                             disable_text_features: bool = False, disable_label_encoding: bool = False) -> (pd.DataFrame, dict):
    """
    Loads data from a CSV file and applies initial preprocessing, passing ablation flags.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict,
                                          disable_text_features=disable_text_features,
                                          disable_label_encoding=disable_label_encoding)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series, learning_rate_override: float = 0.01) -> lgb.Booster:
    """
    Trains a LightGBM model with a potentially overridden learning rate.
    """
    # LightGBM expects feature names as strings
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'regression_l1',
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': learning_rate_override, # Ablation Target 3
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 31,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)])

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_ablation_scenario(
    scenario_name: str,
    train_path: str,
    disable_text_features: bool = False,
    disable_label_encoding: bool = False,
    learning_rate_override: float = 0.01
) -> float:
    """
    Executes a single ablation scenario and returns its validation RMSE.
    """
    print(f"\n--- Running Scenario: {scenario_name} ---")

    df_2022_raw, encoder_dict = load_and_preprocess_data(
        train_path,
        is_training=True,
        disable_text_features=disable_text_features,
        disable_label_encoding=disable_label_encoding
    )

    # Split 2022 data for training and validation using grouped holdout
    df_2022_raw['group_id'] = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    # Define features and target
    features = [col for col in df_train_raw.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]]

    X_train = df_train_raw[features]
    y_train = df_train_raw[TARGET_COLUMN]

    X_val = df_val_raw[features]
    y_val = df_val_raw[TARGET_COLUMN]

    print("Training model...")
    model = train_model(X_train, y_train, X_val, y_val, learning_rate_override=learning_rate_override)

    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log) # Inverse transform
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(np.expm1(y_val), val_predictions) # Calculate RMSE on original scale
    print(f"Validation RMSE for {scenario_name}: {final_validation_rmse:.4f}")

    gc.collect()
    return final_validation_rmse

def main():
    parser = argparse.ArgumentParser(description="Ablation study for NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()

    results = {}

    # Baseline Scenario: The current solution with all new features and default parameters
    results['Baseline (All new features, default LR 0.01)'] = run_ablation_scenario(
        "Baseline (All new features, default LR 0.01)",
        args.train_path
    )

    # Ablation 1: Remove Text-based features
    results['Ablation: No Text-based features (char_len, word_count)'] = run_ablation_scenario(
        "Ablation: No Text-based features",
        args.train_path,
        disable_text_features=True
    )

    # Ablation 2: Remove Label Encoding (keeping Frequency Encoding)
    results['Ablation: No Label Encoding (keeping Freq Encoding)'] = run_ablation_scenario(
        "Ablation: No Label Encoding",
        args.train_path,
        disable_label_encoding=True
    )

    # Ablation 3: Increase learning_rate to 0.05
    results['Ablation: Increased Learning Rate (0.05)'] = run_ablation_scenario(
        "Ablation: Increased Learning Rate (0.05)",
        args.train_path,
        learning_rate_override=0.05
    )

    print("\n--- Ablation Study Results Summary ---")
    baseline_rmse = results['Baseline (All new features, default LR 0.01)']
    print(f"Baseline RMSE (All features, LR=0.01): {baseline_rmse:.4f}")

    most_impactful_component_description = ""
    largest_abs_impact_magnitude = 0.0 # Tracks absolute change in RMSE

    for scenario, rmse in results.items():
        if scenario == 'Baseline (All new features, default LR 0.01)':
            continue
        diff = rmse - baseline_rmse
        print(f"{scenario}: RMSE = {rmse:.4f} (Difference from Baseline: {diff:+.4f})")

        # Identify the scenario that caused the largest absolute change
        if abs(diff) > largest_abs_impact_magnitude:
            largest_abs_impact_magnitude = abs(diff)
            # Describe the impact based on whether the change improved or degraded performance
            if diff > 0:
                # Removing or changing this component degraded performance
                # Implies the *original* component/setting was beneficial
                if "No Text-based features" in scenario:
                    most_impactful_component_description = f"The 'Text-based features' (character length, word count) contributed positively, as their removal degraded performance by {diff:.4f} RMSE."
                elif "No Label Encoding" in scenario:
                    most_impactful_component_description = f"The 'Label Encoding' contributed positively, as its removal degraded performance by {diff:.4f} RMSE."
                elif "Increased Learning Rate" in scenario: # This specific ablation was designed to change LR, not remove a feature
                    most_impactful_component_description = f"The default 'Learning Rate of 0.01' was better than 0.05, as increasing it degraded performance by {diff:.4f} RMSE."
            else:
                # Removing or changing this component improved performance
                # Implies the *original* component/setting was detrimental, or the *new* setting is beneficial
                if "No Text-based features" in scenario:
                    most_impactful_component_description = f"The 'Text-based features' (character length, word count) were detrimental, as their removal improved performance by {-diff:.4f} RMSE."
                elif "No Label Encoding" in scenario:
                    most_impactful_component_description = f"The 'Label Encoding' was detrimental, as its removal improved performance by {-diff:.4f} RMSE."
                elif "Increased Learning Rate" in scenario:
                    most_impactful_component_description = f"Increasing 'Learning Rate to 0.05' was beneficial, improving performance by {-diff:.4f} RMSE compared to 0.01."

    print("\n--- Conclusion: Most Impactful Component ---")
    if most_impactful_component_description:
        print(most_impactful_component_description)
    else:
        print("No significant change in performance observed across the ablated components or unable to determine the most impactful one.")

if __name__ == "__main__":
    main()
