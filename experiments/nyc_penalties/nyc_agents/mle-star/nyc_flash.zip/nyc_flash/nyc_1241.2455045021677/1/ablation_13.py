
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc
import copy

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'

# --- Modified functions to support ablation parameters ---

def _engineer_features_ablated(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None, unknown_cat_val: int = -1) -> tuple[pd.DataFrame, dict]:
    """
    Performs feature engineering on the input DataFrame.
    Ablation: `unknown_cat_val` parameter controls mapping for unknown categories during transformation.
    """
    if encoder_dict is None:
        encoder_dict = {}

    # Column names are standardized before this function is called in run_ablation_experiment
    # df.columns = df.columns.str.replace(' ', '_').str.lower() 

    # Handle missing values
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Label Encoding for categorical features
    categorical_cols = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col] = le
            else:
                if col in encoder_dict:
                    # Use transform for existing categories, map unknown to `unknown_cat_val`
                    df[col + '_encoded'] = df[col].apply(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else unknown_cat_val)
                else:
                    # Fallback for entirely new categories if no encoder, assign `unknown_cat_val`
                    df[col + '_encoded'] = unknown_cat_val

    return df, encoder_dict

def train_model_ablated(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series, lgbm_objective: str = 'regression_l1') -> lgb.Booster:
    """
    Trains a LightGBM model.
    Ablation: `lgbm_objective` parameter controls the model's objective function.
    """
    # LightGBM expects feature names as strings
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': lgbm_objective,
        'metric': 'rmse', # Keeping RMSE as evaluation metric for consistent comparison
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 31,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)])

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_ablation_experiment(train_path: str, lgbm_objective: str = 'regression_l1', val_split_size: float = 0.2, unknown_cat_val: int = -1):
    """
    Runs a single experiment with specified ablation parameters and returns validation RMSE.
    """
    df_full_raw = pd.read_csv(train_path)
    
    # Standardize column names early for consistency with _engineer_features_ablated
    df_full_raw.columns = df_full_raw.columns.str.replace(' ', '_').str.lower()

    # Create group_id for grouped splitting
    df_full_raw['group_id'] = df_full_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_full_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

    unique_groups = df_full_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=val_split_size, random_state=42)

    df_train_part_raw = df_full_raw[df_full_raw['group_id'].isin(train_groups)].copy()
    df_val_part_raw = df_full_raw[df_full_raw['group_id'].isin(val_groups)].copy()

    df_train_part_raw = df_train_part_raw.drop(columns=['group_id'])
    df_val_part_raw = df_val_part_raw.drop(columns=['group_id'])

    # Engineer features for training data: fit encoders
    # `unknown_cat_val` does not affect the `fit_transform` part but is carried for consistency
    df_train_processed, encoder_dict = _engineer_features_ablated(df_train_part_raw, is_training=True, encoder_dict={}, unknown_cat_val=unknown_cat_val)
    
    # Engineer features for validation data: use fitted encoders, applying `unknown_cat_val` for unseen categories
    df_val_processed, _ = _engineer_features_ablated(df_val_part_raw, is_training=False, encoder_dict=encoder_dict, unknown_cat_val=unknown_cat_val)

    # Define features and target
    features = [col for col in df_train_processed.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]]

    X_train = df_train_processed[features]
    y_train = df_train_processed[TARGET_COLUMN]

    X_val = df_val_processed[features]
    y_val = df_val_processed[TARGET_COLUMN]

    model = train_model_ablated(X_train, y_train, X_val, y_val, lgbm_objective=lgbm_objective)

    val_predictions = model.predict(X_val)
    val_predictions[val_predictions < 0] = 0

    final_validation_rmse = calculate_rmse(y_val, val_predictions)
    
    gc.collect()
    return final_validation_rmse

if __name__ == "__main__":
    train_file_path = './input/violations_per_street_2022.csv'

    print("Running Baseline Experiment...")
    baseline_rmse = run_ablation_experiment(train_file_path)
    print(f"Baseline RMSE: {baseline_rmse:.4f}\n")

    results = {'Baseline': baseline_rmse}

    # Ablation 1: Change LightGBM Objective from 'regression_l1' to 'poisson'
    print("Running Ablation 1: Change LightGBM Objective to 'poisson'")
    ablation1_rmse = run_ablation_experiment(train_file_path, lgbm_objective='poisson')
    print(f"Ablation 1 RMSE (objective='poisson'): {ablation1_rmse:.4f}")
    print(f"Difference from Baseline: {ablation1_rmse - baseline_rmse:.4f}\n")
    results['LGBM Objective to Poisson'] = ablation1_rmse

    # Ablation 2: Change Validation Split `test_size` from 0.2 to 0.3
    print("Running Ablation 2: Change Validation Split `test_size` to 0.3")
    ablation2_rmse = run_ablation_experiment(train_file_path, val_split_size=0.3)
    print(f"Ablation 2 RMSE (val_split_size=0.3): {ablation2_rmse:.4f}")
    print(f"Difference from Baseline: {ablation2_rmse - baseline_rmse:.4f}\n")
    results['Validation Split test_size to 0.3'] = ablation2_rmse

    # Ablation 3: Map Unknown Label Encoded Categories to 0 (instead of -1)
    print("Running Ablation 3: Map Unknown Label Encoded Categories to 0")
    ablation3_rmse = run_ablation_experiment(train_file_path, unknown_cat_val=0)
    print(f"Ablation 3 RMSE (unknown_cat_val=0): {ablation3_rmse:.4f}")
    print(f"Difference from Baseline: {ablation3_rmse - baseline_rmse:.4f}\n")
    results['Unknown Categories mapped to 0'] = ablation3_rmse

    # Determine most impactful component
    impacts = {k: baseline_rmse - v for k, v in results.items() if k != 'Baseline'}
    
    print("\n--- Ablation Study Summary ---")
    for name, rmse_val in results.items():
        print(f"{name}: RMSE = {rmse_val:.4f}")

    print(f"\nBaseline RMSE: {baseline_rmse:.4f}")
    
    if impacts:
        most_beneficial_change = max(impacts, key=impacts.get)
        largest_benefit = impacts[most_beneficial_change]

        most_detrimental_change = min(impacts, key=impacts.get)
        largest_detriment = impacts[most_detrimental_change]

        if largest_benefit > 0:
            print(f"The part that contributes the most positively to the overall performance is '{most_beneficial_change}', which improved RMSE by {largest_benefit:.4f}.")
        elif largest_detriment < 0:
            print(f"The part that contributed most negatively to the overall performance is '{most_detrimental_change}', increasing RMSE by {-largest_detriment:.4f}.")
        else:
            print("No ablation significantly changed the RMSE or all changes had a similar small effect.")
    else:
        print("No ablation experiments were performed to compare against the baseline.")
