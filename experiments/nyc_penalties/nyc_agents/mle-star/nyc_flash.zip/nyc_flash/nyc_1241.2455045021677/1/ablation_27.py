

import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv' # Not used in ablation, but kept for context

# --- Baseline _engineer_features function ---
def _engineer_features_baseline(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> tuple[pd.DataFrame, dict]:
    """
    Performs feature engineering on the input DataFrame. (Baseline version)
    Includes Label Encoding and Log Transform on Target.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Handle missing values
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Label Encoding for categorical features
    categorical_cols = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col] = le
            else:
                if col in encoder_dict:
                    # Use transform for existing categories, map unknown to -1
                    df[col + '_encoded'] = df[col].apply(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else -1)
                else:
                    df[col + '_encoded'] = -1 # Assign a default for entirely new categories if no encoder

    # Log transform target if present, good for count data
    if TARGET_COLUMN in df.columns and is_training:
        df[TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

# --- Ablation 1: _engineer_features function without log transform ---
def _engineer_features_no_log_transform(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> tuple[pd.DataFrame, dict]:
    """
    Performs feature engineering on the input DataFrame, WITHOUT log transforming the target.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Handle missing values
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Label Encoding for categorical features
    categorical_cols = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col] = le
            else:
                if col in encoder_dict:
                    df[col + '_encoded'] = df[col].apply(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else -1)
                else:
                    df[col + '_encoded'] = -1 # Assign a default for entirely new categories if no encoder

    # Log transform target is SKIPPED in this version
    # if TARGET_COLUMN in df.columns and is_training:
    #     df[TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

# --- Helper function for data loading and preprocessing (dynamic feature engineering) ---
def load_and_preprocess_data_dynamic(file_path: str, is_training: bool = True, engineer_func=None) -> tuple[pd.DataFrame, dict]:
    """
    Loads data from a CSV file and applies initial preprocessing using a dynamic engineer_func.
    """
    df = pd.read_csv(file_path)
    # The encoder_dict will be managed within the engineer_func for training
    df_processed, encoder_dict = engineer_func(df.copy(), is_training=is_training, encoder_dict={})
    return df_processed, encoder_dict

# --- Train model function (conditional categorical feature declaration) ---
def train_model_conditional_cat(X_train_orig: pd.DataFrame, y_train: pd.Series, X_val_orig: pd.DataFrame, y_val: pd.Series, use_categorical_feature_param: bool) -> lgb.Booster:
    """
    Trains a LightGBM model, conditionally declaring categorical features.
    """
    # Make copies to avoid modifying original DFs passed to the function
    X_train = X_train_orig.copy()
    X_val = X_val_orig.copy()

    # Identify categorical features based on original column names before sanitization
    categorical_features_names = []
    if 'street_name_encoded' in X_train.columns:
        categorical_features_names.append("street_name_encoded")
    if 'violation_description_encoded' in X_train.columns:
        categorical_features_names.append("violation_description_encoded")

    # Sanitize column names for LightGBM after identifying categorical feature names
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    # LightGBM parameters
    params = {
        'objective': 'poisson',
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 63,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    fit_kwargs = {
        'eval_set': [(X_val, y_val)], # Use the sanitized X_val
        'eval_metric': 'rmse',
        'callbacks': [lgb.early_stopping(100, verbose=False)]
    }

    if use_categorical_feature_param:
        # Pass the original names to LightGBM, it will match them with the sanitized names internally
        fit_kwargs['categorical_feature'] = categorical_features_names

    model.fit(X_train, y_train, **fit_kwargs) # Use the sanitized X_train

    return model

# --- Calculate RMSE function ---
def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

# --- Experiment Runner function ---
def run_experiment(
    train_file_path: str,
    engineer_features_func,
    train_model_func,
    test_size: float,
    use_categorical_feature_param: bool
) -> float:
    """
    Runs a single experiment with specified configurations and returns the validation RMSE.
    """
    # Load and preprocess data using the specified feature engineering function
    df_2022_raw, _ = load_and_preprocess_data_dynamic( # encoder_dict is not needed beyond this scope for ablation
        train_file_path, is_training=True, engineer_func=engineer_features_func
    )

    # Split 2022 data for training and validation using grouped holdout
    df_2022_raw['group_id'] = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=test_size, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    # Define features and target
    features = [col for col in df_train_raw.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]]

    X_train = df_train_raw[features]
    y_train = df_train_raw[TARGET_COLUMN]
    X_val = df_val_raw[features]
    y_val = df_val_raw[TARGET_COLUMN]

    # Train model using the specified training function and categorical feature parameter
    model = train_model_func(X_train, y_train, X_val, y_val, use_categorical_feature_param)

    # Predict on validation set
    val_predictions_log = model.predict(X_val)

    # Inverse transform if log transform was applied, otherwise use predictions directly
    # Assumes engineer_features_baseline applies log transform and others do not
    if engineer_features_func == _engineer_features_baseline:
        val_predictions = np.expm1(val_predictions_log)
        y_val_original_scale = np.expm1(y_val)
    else: # For no log transform ablation, predictions are already on original scale
        val_predictions = val_predictions_log
        y_val_original_scale = y_val # y_val was not log-transformed in this path

    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(y_val_original_scale, val_predictions)
    
    gc.collect() # Clean up memory
    return final_validation_rmse


# --- Main ablation study function ---
def ablation_study_main():
    train_file_path = './input/violations_per_street_2022.csv'
    
    print("Starting Ablation Study...")

    results = {}

    # --- Baseline ---
    print("\n--- Running Baseline (Log Transform, test_size=0.2, Explicit Cat Feature Decl) ---")
    baseline_rmse = run_experiment(
        train_file_path,
        engineer_features_func=_engineer_features_baseline,
        train_model_func=train_model_conditional_cat,
        test_size=0.2,
        use_categorical_feature_param=True
    )
    print(f"Baseline Validation RMSE: {baseline_rmse:.4f}")
    results["Baseline"] = baseline_rmse

    # --- Ablation 1: No Log Transform on Target ---
    print("\n--- Running Ablation 1: No Log Transform on Target ---")
    ablation1_rmse = run_experiment(
        train_file_path,
        engineer_features_func=_engineer_features_no_log_transform,
        train_model_func=train_model_conditional_cat,
        test_size=0.2,
        use_categorical_feature_param=True
    )
    print(f"Ablation 1 (No Log Transform) Validation RMSE: {ablation1_rmse:.4f}")
    results["No Log Transform on Target"] = ablation1_rmse

    # --- Ablation 2: Increase Validation Split test_size to 0.3 ---
    print("\n--- Running Ablation 2: Validation Split test_size=0.3 ---")
    ablation2_rmse = run_experiment(
        train_file_path,
        engineer_features_func=_engineer_features_baseline,
        train_model_func=train_model_conditional_cat,
        test_size=0.3,
        use_categorical_feature_param=True
    )
    print(f"Ablation 2 (test_size=0.3) Validation RMSE: {ablation2_rmse:.4f}")
    results["Validation Split test_size=0.3"] = ablation2_rmse

    # --- Ablation 3: Remove Explicit Categorical Feature Declaration ---
    print("\n--- Running Ablation 3: No Explicit Categorical Feature Declaration ---")
    ablation3_rmse = run_experiment(
        train_file_path,
        engineer_features_func=_engineer_features_baseline,
        train_model_func=train_model_conditional_cat,
        test_size=0.2,
        use_categorical_feature_param=False
    )
    print(f"Ablation 3 (No Explicit Cat Feature Decl) Validation RMSE: {ablation3_rmse:.4f}")
    results["No Explicit Categorical Feature Declaration"] = ablation3_rmse

    # --- Summary and Most Impactful Component ---
    print("\n--- Ablation Study Results Summary ---")
    for name, rmse in results.items():
        print(f"{name}: RMSE = {rmse:.4f}")
    
    # Analyze impact relative to baseline
    impacts = {}
    for name, rmse in results.items():
        if name != "Baseline":
            diff = baseline_rmse - rmse # Positive diff means improvement, negative means degradation
            impacts[name] = diff
    
    if impacts:
        # Find the component with the largest absolute change from baseline
        most_impactful_name = max(impacts, key=lambda k: abs(impacts[k]))
        most_impactful_diff = impacts[most_impactful_name]

        print("\n--- Most Impactful Component Analysis ---")
        if abs(most_impactful_diff) < 0.001: # Threshold for considering it "no significant impact"
            print("No single component had a significant impact on performance.")
        elif most_impactful_diff > 0:
            print(f"The part that contributes most positively to the overall performance is '{most_impactful_name}', which improved RMSE by {most_impactful_diff:.4f}.")
        else: # most_impactful_diff < 0
            print(f"The part that contributes most negatively to the overall performance is '{most_impactful_name}', which degraded RMSE by {abs(most_impactful_diff):.4f}.")
    else:
        print("\nNo ablations were performed to compare against the baseline.")

if __name__ == "__main__":
    ablation_study_main()

