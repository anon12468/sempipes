
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
# PREDICTED_COUNT_COL = 'predicted_count' # Not used in ablation
# OUTPUT_SUBMISSION_FILE = 'submission.csv' # Not used in ablation

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Performs feature engineering on the input DataFrame.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Handle missing values
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Label Encoding for categorical features
    categorical_cols = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col] = le
            else:
                if col in encoder_dict:
                    # Use transform for existing categories, map unknown to -1
                    df[col + '_encoded'] = df[col].map(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else -1)
                else:
                    df[col + '_encoded'] = -1 # Assign a default for entirely new categories if no encoder

    # Log transform target if present, good for count data
    if TARGET_COLUMN in df.columns and is_training:
        df[TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df_processed, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    return df_processed, encoder_dict

def train_and_evaluate_model(X_train_df: pd.DataFrame, y_train_series: pd.Series, X_val_df: pd.DataFrame, y_val_series: pd.Series, 
                             params_override: dict = None,
                             disable_categorical_feature_declaration: bool = False,
                             baseline_categorical_features: list = None) -> float:
    """
    Trains a LightGBM model and evaluates its RMSE.
    """
    X_train = X_train_df.copy()
    X_val = X_val_df.copy()
    y_train = y_train_series.copy()
    y_val = y_val_series.copy()

    # LightGBM expects feature names as strings and sanitized names
    original_train_cols = X_train.columns
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    # Identify categorical features for LightGBM if not disabled
    categorical_features_names = []
    if not disable_categorical_feature_declaration:
        # Use the provided list if available, otherwise default to encoded features
        categorical_features_names = baseline_categorical_features if baseline_categorical_features else [
            col for col in ["street_name_encoded", "violation_description_encoded"] if col in original_train_cols
        ]
    
    # LightGBM parameters - Baseline from plan_implement_agent_1
    params = {
        'objective': 'poisson',
        'metric': 'rmse',
        'n_estimators': 4000,
        'learning_rate': 0.005,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 63,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    if params_override:
        params.update(params_override)

    model = lgb.LGBMRegressor(**params)

    fit_kwargs = {
        'eval_set': [(X_val, y_val)],
        'eval_metric': 'rmse',
        'callbacks': [lgb.early_stopping(100, verbose=False)],
    }
    if not disable_categorical_feature_declaration and categorical_features_names:
        fit_kwargs['categorical_feature'] = categorical_features_names

    model.fit(X_train, y_train, **fit_kwargs)

    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log) # Inverse transform
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(np.expm1(y_val), val_predictions) # Calculate RMSE on original scale
    return final_validation_rmse

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()

    # Load and preprocess data
    df_2022_raw, encoder_dict = load_and_preprocess_data(args.train_path, is_training=True)

    # Split 2022 data for training and validation (grouped holdout)
    df_2022_raw['group_id'] = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    features = [col for col in df_train_raw.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]]

    X_train = df_train_raw[features]
    y_train = df_train_raw[TARGET_COLUMN]
    X_val = df_val_raw[features]
    y_val = df_val_raw[TARGET_COLUMN]

    # Define baseline categorical features for consistent handling
    baseline_categorical_features = []
    if 'street_name_encoded' in X_train.columns:
        baseline_categorical_features.append("street_name_encoded")
    if 'violation_description_encoded' in X_train.columns:
        baseline_categorical_features.append("violation_description_encoded")

    # --- Baseline ---
    baseline_rmse = train_and_evaluate_model(X_train, y_train, X_val, y_val, 
                                             baseline_categorical_features=baseline_categorical_features)
    
    # --- Ablation 1: Change objective from 'poisson' to 'regression_l1' (MAE) ---
    ablation1_params = {'objective': 'regression_l1'}
    ablation1_rmse = train_and_evaluate_model(X_train, y_train, X_val, y_val, 
                                              params_override=ablation1_params,
                                              baseline_categorical_features=baseline_categorical_features)

    # --- Ablation 2: Remove categorical_feature declaration ---
    ablation2_rmse = train_and_evaluate_model(X_train, y_train, X_val, y_val, 
                                              disable_categorical_feature_declaration=True,
                                              baseline_categorical_features=baseline_categorical_features)

    # --- Ablation 3: Disable Bagging and Feature Fraction ---
    ablation3_params = {
        'bagging_freq': 0,
        'bagging_fraction': 1.0, # Ignored if bagging_freq=0, but set for clarity
        'feature_fraction': 1.0  # Ignored if bagging_freq=0, but set for clarity
    }
    ablation3_rmse = train_and_evaluate_model(X_train, y_train, X_val, y_val, 
                                              params_override=ablation3_params,
                                              baseline_categorical_features=baseline_categorical_features)

    # --- Print Results ---
    results = {
        'Baseline': baseline_rmse,
        'Ablation 1 (Objective regression_l1)': ablation1_rmse,
        'Ablation 2 (No categorical_feature declaration)': ablation2_rmse,
        'Ablation 3 (Disable Bagging/Feature Fraction)': ablation3_rmse,
    }

    print(f"Baseline RMSE: {results['Baseline']:.4f}")
    for name, rmse in results.items():
        if name != 'Baseline':
            diff = results['Baseline'] - rmse
            impact_desc = "improved" if diff > 0 else ("degraded" if diff < 0 else "had no measurable impact on")
            print(f"{name}: RMSE {rmse:.4f} (Compared to Baseline: {impact_desc} by {abs(diff):.4f})")
            
    # --- Most Impactful Component ---
    
    impacts = {name: abs(results['Baseline'] - rmse) for name, rmse in results.items() if name != 'Baseline'}

    if impacts:
        most_impactful_ablation_name = max(impacts, key=impacts.get)
        most_impactful_ablation_value = results[most_impactful_ablation_name]
        
        diff_from_baseline = results['Baseline'] - most_impactful_ablation_value
        impact_type = "beneficial (lower RMSE)" if diff_from_baseline > 0 else "detrimental (higher RMSE)" if diff_from_baseline < 0 else "neutral"

        print(f"\nThe most impactful change was '{most_impactful_ablation_name}'.")
        print(f"It resulted in an RMSE of {most_impactful_ablation_value:.4f}, which is {impact_type} by {abs(diff_from_baseline):.4f} compared to the Baseline RMSE of {results['Baseline']:.4f}.")
    else:
        print("\nNo ablations were run.")

    gc.collect()

if __name__ == "__main__":
    main()
