

import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import os
import logging
from catboost import CatBoostRegressor, Pool
import gc

# Configure logging to suppress INFO messages during ablation runs
logging.basicConfig(level=logging.WARNING, format='%(asctime)s - %(levelname)s - %(message)s')

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_map: dict = None, global_mean: float = None,
                       enable_target_encoding: bool = True, enable_target_interaction: bool = True, enable_length_features: bool = True) -> (pd.DataFrame, dict, float):
    """
    Engineers features for the parking violation data.
    Ablation parameters:
    - enable_target_encoding: if False, skips target encoding for street_name and violation_type.
    - enable_target_interaction: if False, skips 'interaction_target_encoded' feature.
    - enable_length_features: if False, skips 'street_name_len' and 'violation_type_len' features.
    """
    df_copy = df.copy()

    # Rename columns for easier access
    df_copy.rename(columns={STREET_NAME_COL: 'street_name', VIOLATION_DESC_COL: 'violation_type'}, inplace=True)

    # Feature: Combine street_name and violation_type (always included as a categorical feature)
    df_copy['street_violation_pair'] = df_copy['street_name'] + '_' + df_copy['violation_type']

    alpha = 50 # Smoothing factor for target encoding

    # Smoothed Target Encoding
    if enable_target_encoding:
        if is_training:
            encoder_map = {}
            global_mean_calc = df_copy[TARGET_COLUMN].mean() if TARGET_COLUMN in df_copy.columns else 0
            
            for col in ['street_name', 'violation_type']:
                temp_df = df_copy[[col, TARGET_COLUMN]].copy()
                group_means = temp_df.groupby(col)[TARGET_COLUMN].mean()
                group_counts = temp_df.groupby(col)[TARGET_COLUMN].count()
                smoothed_means = (group_counts * group_means + alpha * global_mean_calc) / (group_counts + alpha)
                encoder_map[col] = smoothed_means.to_dict()
                df_copy[f'{col}_target_encoded'] = df_copy[col].map(encoder_map[col]).fillna(global_mean_calc)
            global_mean = global_mean_calc # Store the calculated global mean
        else:
            if encoder_map is None or global_mean is None:
                raise ValueError("encoder_map and global_mean must be provided for inference if target encoding is enabled.")
            for col in ['street_name', 'violation_type']:
                df_copy[f'{col}_target_encoded'] = df_copy[col].map(encoder_map[col]).fillna(global_mean)
    else:
        # If target encoding is disabled, ensure no target_encoded columns are present
        encoder_map = {}
        global_mean = 0
        df_copy.drop(columns=[col for col in df_copy.columns if '_target_encoded' in col], errors='ignore', inplace=True)

    # Interaction feature: product of target encodings (only if target encoding and interaction are enabled)
    if enable_target_encoding and enable_target_interaction:
        if 'street_name_target_encoded' in df_copy.columns and 'violation_type_target_encoded' in df_copy.columns:
            df_copy['interaction_target_encoded'] = df_copy['street_name_target_encoded'] * df_copy['violation_type_target_encoded']
        else:
            logging.warning("Cannot create interaction_target_encoded: required target encoded features are missing or target encoding is disabled.")
    elif 'interaction_target_encoded' in df_copy.columns: # Ensure it's not present if disabled
        df_copy.drop(columns=['interaction_target_encoded'], errors='ignore', inplace=True)

    # Simple length features
    if enable_length_features:
        df_copy['street_name_len'] = df_copy['street_name'].apply(len)
        df_copy['violation_type_len'] = df_copy['violation_type'].apply(len)
    else:
        df_copy.drop(columns=['street_name_len', 'violation_type_len'], errors='ignore', inplace=True)

    # Convert categorical features to 'category' dtype for CatBoost
    categorical_cols_to_convert = ['street_name', 'violation_type', 'street_violation_pair']
    for col in categorical_cols_to_convert:
        if col in df_copy.columns:
            df_copy[col] = df_copy[col].astype('category')

    return df_copy, encoder_map, global_mean

def run_experiment(train_path: str, random_seed: int,
                   enable_target_encoding: bool,
                   enable_target_interaction: bool,
                   enable_length_features: bool) -> float:
    """
    Runs the full training and validation pipeline with specified feature engineering settings.
    Returns the validation RMSE.
    """
    np.random.seed(random_seed)

    # --- Load Training Data ---
    df_train_raw = pd.read_csv(train_path)

    required_cols = [STREET_NAME_COL, VIOLATION_DESC_COL, TARGET_COLUMN]
    if not all(col in df_train_raw.columns for col in required_cols):
        missing_cols = [col for col in required_cols if col not in df_train_raw.columns]
        raise ValueError(f"Training data missing required columns. Missing: {missing_cols}")

    # --- Prepare Training and Validation Sets ---
    df_train_raw['key_pair_for_split'] = df_train_raw[STREET_NAME_COL] + '_' + df_train_raw[VIOLATION_DESC_COL]
    unique_key_pairs = df_train_raw['key_pair_for_split'].unique()

    train_keys, val_keys = train_test_split(unique_key_pairs, test_size=0.2, random_state=random_seed)

    df_train_split = df_train_raw[df_train_raw['key_pair_for_split'].isin(train_keys)].drop(columns=['key_pair_for_split']).reset_index(drop=True)
    df_val_split = df_train_raw[df_train_raw['key_pair_for_split'].isin(val_keys)].drop(columns=['key_pair_for_split']).reset_index(drop=True)

    # --- Feature Engineering ---
    df_train_fe, encoder_map, global_mean = _engineer_features(
        df_train_split, is_training=True,
        enable_target_encoding=enable_target_encoding,
        enable_target_interaction=enable_target_interaction,
        enable_length_features=enable_length_features
    )
    df_val_fe, _, _ = _engineer_features(
        df_val_split, is_training=False, encoder_map=encoder_map, global_mean=global_mean,
        enable_target_encoding=enable_target_encoding,
        enable_target_interaction=enable_target_interaction,
        enable_length_features=enable_length_features
    )

    # Define features and target
    features = [col for col in df_train_fe.columns if col not in ['street_name', 'violation_type', TARGET_COLUMN]]

    # Identify categorical features for CatBoost
    categorical_features_names = [f for f in features if df_train_fe[f].dtype == 'category']
    
    # Ensure numerical columns used for features have consistent types
    numerical_features = [f for f in features if f not in categorical_features_names]
    for col in numerical_features:
        if col in df_train_fe.columns:
            df_train_fe[col] = pd.to_numeric(df_train_fe[col], errors='coerce')
        if col in df_val_fe.columns:
            df_val_fe[col] = pd.to_numeric(df_val_fe[col], errors='coerce')

    X_train = df_train_fe[features]
    y_train = df_train_fe[TARGET_COLUMN]
    X_val = df_val_fe[features]
    y_val = df_val_fe[TARGET_COLUMN]

    # Handle potential NaNs in engineered numerical features (CatBoost can handle NaNs in categorical, but numerical often prefer imputation)
    for col in X_train.select_dtypes(include=np.number).columns:
        if X_train[col].isnull().any():
            X_train[col] = X_train[col].fillna(-1) # Use -1 as a distinct indicator for NaNs
            X_val[col] = X_val[col].fillna(-1)

    # --- CatBoost Model Training ---
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=random_seed,
        verbose=0, # Suppress verbose output for ablation runs
        early_stopping_rounds=50,
        cat_features=categorical_features_names,
        subsample=0.8,
        l2_leaf_reg=3,
        thread_count=-1
    )

    model.fit(
        X_train, y_train,
        eval_set=(X_val, y_val),
        early_stopping_rounds=50,
        verbose=False
    )

    # --- Evaluate on Validation Set ---
    val_predictions = model.predict(X_val)
    val_predictions[val_predictions < 0] = 0
    validation_rmse = np.sqrt(mean_squared_error(y_val, val_predictions))
    
    # Clean up memory
    del df_train_raw, df_train_split, df_val_split, df_train_fe, df_val_fe, X_train, y_train, X_val, y_val, model
    gc.collect()

    return validation_rmse


def main_ablation():
    parser = argparse.ArgumentParser(description="Ablation study for NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--random-seed', type=int, default=42,
                        help='Random seed for reproducibility.')
    args = parser.parse_args()

    results = {}

    # --- Baseline Run ---
    print("\n--- Running Baseline Experiment (All features enabled) ---")
    baseline_rmse = run_experiment(
        args.train_path, args.random_seed,
        enable_target_encoding=True,
        enable_target_interaction=True,
        enable_length_features=True
    )
    results['Baseline'] = baseline_rmse
    print(f"Baseline RMSE: {baseline_rmse:.4f}")

    # --- Ablation 1: No Smoothed Target Encoding ---
    # If target encoding is disabled, the interaction feature dependent on it will also not be created.
    print("\n--- Running Ablation: No Smoothed Target Encoding ---")
    ablation_no_te_rmse = run_experiment(
        args.train_path, args.random_seed,
        enable_target_encoding=False,
        enable_target_interaction=False, 
        enable_length_features=True
    )
    results['No Smoothed Target Encoding'] = ablation_no_te_rmse
    print(f"RMSE (No Smoothed Target Encoding): {ablation_no_te_rmse:.4f}")

    # --- Ablation 2: No Target Encoded Interaction Feature ---
    # Target Encoding is ON, but the numerical interaction derived from them is OFF.
    print("\n--- Running Ablation: No Target Encoded Interaction Feature ---")
    ablation_no_te_interaction_rmse = run_experiment(
        args.train_path, args.random_seed,
        enable_target_encoding=True, 
        enable_target_interaction=False,
        enable_length_features=True
    )
    results['No Target Encoded Interaction Feature'] = ablation_no_te_interaction_rmse
    print(f"RMSE (No Target Encoded Interaction Feature): {ablation_no_te_interaction_rmse:.4f}")

    # --- Ablation 3: No Simple Length Features ---
    print("\n--- Running Ablation: No Simple Length Features ---")
    ablation_no_length_features_rmse = run_experiment(
        args.train_path, args.random_seed,
        enable_target_encoding=True,
        enable_target_interaction=True,
        enable_length_features=False
    )
    results['No Simple Length Features'] = ablation_no_length_features_rmse
    print(f"RMSE (No Simple Length Features): {ablation_no_length_features_rmse:.4f}")

    print("\n--- Ablation Study Summary ---")
    for name, rmse in results.items():
        print(f"{name}: {rmse:.4f}")

    # Determine the most impactful part
    impacts = {}
    for name, rmse in results.items():
        if name != 'Baseline':
            diff = rmse - baseline_rmse
            impacts[name] = diff
            print(f"Effect of removing '{name}': {diff:.4f} RMSE change.")
    
    if impacts:
        # Find the component whose removal caused the largest absolute change (either positive or negative)
        most_impactful_removal = max(impacts, key=lambda k: abs(impacts[k]))
        impact_value = impacts[most_impactful_removal]

        if impact_value > 0:
            print(f"\nThe most impactful part contributing positively to performance is '{most_impactful_removal}'. Its removal caused a degradation (increase) of {impact_value:.4f} in RMSE.")
        else: # impact_value is negative, meaning removal *improved* performance
            print(f"\nThe most impactful part that was detrimental to performance is '{most_impactful_removal}'. Its removal caused an improvement (decrease) of {-impact_value:.4f} in RMSE.")
    else:
        print("\nNo ablation impacts to compare.")


if __name__ == "__main__":
    main_ablation()

