

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import catboost as cb
import os
import lightgbm as lgb
import gc
import re

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv'

# Base _engineer_features function, adapted to accept ablation flags
def _engineer_features_base(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None,
                            use_loo_noise: bool = True,
                            use_new_text_features: bool = True,
                            use_complex_loo_interaction_features: bool = True) -> pd.DataFrame:
    """
    Performs feature engineering on the input DataFrame with ablation flags.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Standardize column names for constants as well
    _street_name_col = STREET_NAME_COL.replace(' ', '_').lower()
    _violation_desc_col = VIOLATION_DESC_COL.replace(' ', '_').lower()
    _target_column = TARGET_COLUMN.lower() if TARGET_COLUMN else None

    # Handle missing values
    for col in [_street_name_col, _violation_desc_col]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown_category_imputed').astype(str)

    # --- Leave-One-Out (LOO) Encoding for specified categorical features ---
    loo_cols = [_street_name_col, _violation_desc_col]
    LOO_NOISE_STD = 0.01 if use_loo_noise else 0.0 # Ablation flag applied here

    if _target_column and _target_column in df.columns: # LOO encoding requires the target column
        global_target_mean = df[_target_column].mean() if is_training else encoder_dict.get('global_target_mean_loo', 0.0)
        if is_training:
            encoder_dict['global_target_mean_loo'] = global_target_mean

        for col in loo_cols:
            if col in df.columns:
                loo_encoded_col_name = col + '_loo_encoded'

                if is_training:
                    category_stats = df.groupby(col)[_target_column].agg(['sum', 'count']).reset_index()
                    category_stats.rename(columns={'sum': 'target_sum', 'count': 'category_count'}, inplace=True)
                    category_stats_map = category_stats.set_index(col).to_dict('index')

                    encoder_dict[col + '_loo'] = {
                        'category_stats_map': category_stats_map,
                        'global_target_mean': global_target_mean,
                    }

                    def calculate_loo_mean(row, cat_map):
                        cat = row[col]
                        target_val = row[_target_column]
                        stats = cat_map.get(cat)
                        if stats:
                            cat_sum = stats['target_sum']
                            cat_count = stats['category_count']
                            if cat_count > 1:
                                return (cat_sum - target_val) / (cat_count - 1)
                            else:
                                return global_target_mean
                        return global_target_mean

                    df[loo_encoded_col_name] = df.apply(lambda row: calculate_loo_mean(row, category_stats_map), axis=1)
                    if use_loo_noise and LOO_NOISE_STD > 0: # Only add noise if enabled and non-zero
                        df[loo_encoded_col_name] = df[loo_encoded_col_name] + np.random.normal(0, LOO_NOISE_STD, df.shape[0])

                else: # is_training is False (inference)
                    if col + '_loo' in encoder_dict:
                        stored_info = encoder_dict[col + '_loo']
                        category_stats_map = stored_info['category_stats_map']
                        stored_global_target_mean = stored_info['global_target_mean']

                        def transform_loo_mean(cat):
                            stats = category_stats_map.get(cat)
                            if stats:
                                cat_sum = stats['target_sum']
                                cat_count = stats['category_count']
                                if cat_count > 0:
                                    return cat_sum / cat_count
                                else:
                                    return stored_global_target_mean # No noise at inference
                            else:
                                return stored_global_target_mean # No noise at inference

                        df[loo_encoded_col_name] = df[col].apply(transform_loo_mean)
                    else:
                        df[loo_encoded_col_name] = global_target_mean # No noise at inference
    # --- End of LOO Encoding ---


    # --- Feature Engineering from violation_description ---
    if use_new_text_features and _violation_desc_col in df.columns: # Ablation flag applied here
        df['violation_desc_word_count'] = df[_violation_desc_col].apply(lambda x: len(str(x).split()))

        keywords = ['parking', 'expired', 'permit', 'zone', 'fire', 'handicapped', 'commercial', 'residential', 'no standing', 'street cleaning']
        for keyword in keywords:
            df[f'violation_desc_has_{keyword.replace(" ", "_")}'] = df[_violation_desc_col].str.contains(r'\b' + re.escape(keyword) + r'\b', case=False, na=False).astype(int)

    # --- Complex Interaction Features ---
    street_loo_col = _street_name_col + '_loo_encoded'
    violation_loo_col = _violation_desc_col + '_loo_encoded'

    if use_complex_loo_interaction_features and street_loo_col in df.columns and violation_loo_col in df.columns: # Ablation flag applied here
        df['street_violation_loo_sum'] = df[street_loo_col] + df[violation_loo_col]
        df['street_violation_loo_product'] = df[street_loo_col] * df[violation_loo_col]
        df['street_loo_squared'] = df[street_loo_col] ** 2
        df['violation_loo_squared'] = df[violation_loo_col] ** 2
        df['street_x_violation_loo_cubed'] = df[street_loo_col] * (df[violation_loo_col] ** 3)
        df['street_squared_x_violation_loo_squared'] = (df[street_loo_col] ** 2) * (df[violation_loo_col] ** 2)

    # Log transform target if present and training
    # This should be the last step for target transformation if the LOO encoding used the raw target values.
    if TARGET_COLUMN and TARGET_COLUMN.lower() in df.columns and is_training:
        df[TARGET_COLUMN.lower()] = np.log1p(df[TARGET_COLUMN.lower()])

    return df, encoder_dict


def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None,
                             use_loo_noise: bool = True,
                             use_new_text_features: bool = True,
                             use_complex_loo_interaction_features: bool = True) -> pd.DataFrame:
    """
    Loads data from a CSV file and applies initial preprocessing.
    Uses the _engineer_features_base with ablation flags.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features_base(df.copy(), is_training=is_training, encoder_dict=encoder_dict,
                                               use_loo_noise=use_loo_noise,
                                               use_new_text_features=use_new_text_features,
                                               use_complex_loo_interaction_features=use_complex_loo_interaction_features)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series) -> lgb.Booster:
    """
    Trains a LightGBM model.
    """
    # LightGBM expects feature names as strings
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'regression_l1',  # MAE objective
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 31,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)]) # Use callbacks for early stopping

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_ablation_scenario(scenario_name: str, train_path: str,
                          use_loo_noise: bool,
                          use_new_text_features: bool,
                          use_complex_loo_interaction_features: bool):
    """
    Runs a single ablation scenario and reports its performance.
    """
    print(f"\n--- Running Scenario: {scenario_name} ---")

    df_2022_raw, encoder_dict = load_and_preprocess_data(train_path, is_training=True,
                                                       use_loo_noise=use_loo_noise,
                                                       use_new_text_features=use_new_text_features,
                                                       use_complex_loo_interaction_features=use_complex_loo_interaction_features)

    # Split 2022 data for training and validation
    df_2022_raw['group_id'] = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    # Define features and target
    features = [col for col in df_train_raw.columns if col not in [TARGET_COLUMN.lower(), STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]]

    X_train = df_train_raw[features]
    y_train = df_train_raw[TARGET_COLUMN.lower()]

    X_val = df_val_raw[features]
    y_val = df_val_raw[TARGET_COLUMN.lower()]

    print("Training model...")
    model = train_model(X_train, y_train, X_val, y_val)

    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log)
    val_predictions[val_predictions < 0] = 0

    final_validation_rmse = calculate_rmse(np.expm1(y_val), val_predictions)
    print(f"Validation Performance for {scenario_name}: {final_validation_rmse}")
    
    del df_2022_raw, df_train_raw, df_val_raw, X_train, y_train, X_val, y_val, model
    gc.collect()

    return final_validation_rmse

def main_ablation_study():
    train_path = './input/violations_per_street_2022.csv'
    
    results = {}

    # 1. Baseline Scenario (all new features/settings enabled)
    results['Baseline (All new features enabled)'] = run_ablation_scenario(
        'Baseline (All new features enabled)', train_path,
        use_loo_noise=True, use_new_text_features=True, use_complex_loo_interaction_features=True
    )

    # 2. Ablation: No LOO Noise
    results['Ablation: No LOO Noise'] = run_ablation_scenario(
        'Ablation: No LOO Noise', train_path,
        use_loo_noise=False, use_new_text_features=True, use_complex_loo_interaction_features=True
    )

    # 3. Ablation: No New Text Features (word count, keyword presence)
    results['Ablation: No New Text Features'] = run_ablation_scenario(
        'Ablation: No New Text Features', train_path,
        use_loo_noise=True, use_new_text_features=False, use_complex_loo_interaction_features=True
    )

    # 4. Ablation: No Complex LOO Interaction Features (sum, product, squared, cubed terms)
    results['Ablation: No Complex LOO Interaction Features'] = run_ablation_scenario(
        'Ablation: No Complex LOO Interaction Features', train_path,
        use_loo_noise=True, use_new_text_features=True, use_complex_loo_interaction_features=False
    )

    print("\n--- Ablation Study Results ---")
    baseline_rmse = results['Baseline (All new features enabled)']
    for scenario, rmse in results.items():
        print(f"{scenario}: RMSE = {rmse:.4f}")
        if scenario != 'Baseline (All new features enabled)':
            diff = rmse - baseline_rmse
            impact_str = "degraded" if diff > 0 else "improved"
            print(f"  -> Impact vs Baseline: {impact_str} performance by {abs(diff):.4f} RMSE")

    # Determine most impactful component
    # We are looking for the component whose *removal* causes the largest degradation (increase in RMSE).
    # Or, if removal improves, which one improves the most (largest decrease in RMSE).
    
    max_degradation = 0
    most_degrading_component_on_removal = "N/A"
    max_improvement = 0
    most_improving_component_on_removal = "N/A"

    for scenario, rmse in results.items():
        if scenario != 'Baseline (All new features enabled)':
            diff = rmse - baseline_rmse # If diff > 0, removal degraded performance. If diff < 0, removal improved performance.
            
            if diff > max_degradation:
                max_degradation = diff
                most_degrading_component_on_removal = scenario.replace("Ablation: ", "")
            
            if diff < max_improvement: # diff is negative here, so smaller negative is larger improvement (i.e., less negative)
                max_improvement = diff
                most_improving_component_on_removal = scenario.replace("Ablation: ", "")

    print("\n--- Conclusion on Most Impactful Component ---")
    if max_degradation > 0 and max_degradation > abs(max_improvement):
        print(f"The part that contributes most positively to the overall performance is '{most_degrading_component_on_removal}'. "
              f"Its removal degraded performance by {max_degradation:.4f} RMSE.")
    elif max_improvement < 0 and abs(max_improvement) > max_degradation:
        print(f"The part that contributes most negatively to the overall performance is '{most_improving_component_on_removal}'. "
              f"Its removal improved performance by {abs(max_improvement):.4f} RMSE.")
    else:
        print("No single component had a significantly positive or negative impact based on this ablation study.")

if __name__ == "__main__":
    main_ablation_study()
