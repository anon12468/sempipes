
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import argparse
import os
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Configuration and Constants ---
DEFAULT_TRAIN_PATH = './input/violations_per_street_2022.csv'
SUBMISSION_FILE_NAME = 'submission.csv'
AUGMENTATION_TABLES_DIR = './input/'

# --- Helper Functions ---
def rmse(y_true, y_pred):
    """Calculates the Root Mean Squared Error."""
    return np.sqrt(mean_squared_error(y_true, y_pred))

def load_data(filepath):
    """Loads a CSV file into a pandas DataFrame."""
    if not os.path.exists(filepath):
        logging.error(f"File not found: {filepath}")
        return None
    try:
        df = pd.read_csv(filepath)
        df.columns = [col.strip() for col in df.columns] # Clean column names
        return df
    except Exception as e:
        logging.error(f"Error loading {filepath}: {e}")
        return None

def create_dummy_data(directory="./input"):
    """Creates dummy CSV files for demonstration if they don't exist."""
    os.makedirs(directory, exist_ok=True)

    # violations_per_street_2022.csv
    if not os.path.exists(os.path.join(directory, 'violations_per_street_2022.csv')):
        dummy_violations_2022 = pd.DataFrame({
            'Street Name': ['MAIN ST', 'ELM AVE', 'OAK BLVD', 'MAIN ST', 'ELM AVE', 'PINE LN', 'OAK BLVD', 'MAIN ST', 'ELM AVE', 'CEDAR ST', 'MAIN ST', 'ELM AVE', 'BROADWAY'],
            'Violation Description': ['NO PARKING', 'DOUBLE PARKING', 'FIRE HYDRANT', 'METER EXPIRED', 'NO PARKING', 'BUS LANE', 'DOUBLE PARKING', 'FIRE HYDRANT', 'METER EXPIRED', 'NO PARKING', 'NO STANDING', 'LOADING ZONE', 'NO PARKING'],
            'violation_count': [100, 50, 20, 120, 60, 15, 30, 25, 70, 40, 80, 45, 150]
        })
        dummy_violations_2022.to_csv(os.path.join(directory, 'violations_per_street_2022.csv'), index=False)
        logging.info("Created dummy violations_per_street_2022.csv")

    # violation_codes_info.csv
    if not os.path.exists(os.path.join(directory, 'violation_codes_info.csv')):
        dummy_violation_codes = pd.DataFrame({
            'Violation Description': ['NO PARKING', 'DOUBLE PARKING', 'FIRE HYDRANT', 'METER EXPIRED', 'BUS LANE', 'NO STANDING', 'LOADING ZONE', 'PARKING VIOLATION'],
            'Fine Amount': [65, 115, 180, 45, 115, 90, 75, 65],
            'Violation Category': ['Parking', 'Standing', 'Safety', 'Parking', 'Bus Lane', 'Standing', 'Parking', 'Parking']
        })
        dummy_violation_codes.to_csv(os.path.join(directory, 'violation_codes_info.csv'), index=False)
        logging.info("Created dummy violation_codes_info.csv")

    # street_attributes.csv
    if not os.path.exists(os.path.join(directory, 'street_attributes.csv')):
        dummy_street_attributes = pd.DataFrame({
            'Street Name': ['MAIN ST', 'ELM AVE', 'OAK BLVD', 'PINE LN', 'CEDAR ST', 'BROADWAY'],
            'Borough': ['Manhattan', 'Brooklyn', 'Queens', 'Bronx', 'Manhattan', 'Manhattan'],
            'Street Length (miles)': [5.2, 3.1, 4.5, 1.8, 2.7, 13.0],
            'Residential Density': [0.8, 0.6, 0.4, 0.7, 0.9, 0.95]
        })
        dummy_street_attributes.to_csv(os.path.join(directory, 'street_attributes.csv'), index=False)
        logging.info("Created dummy street_attributes.csv")

# --- Main Script ---
def main(train_path, test_path=None):
    logging.info("Starting parking violation prediction pipeline.")

    # Create dummy data if files don't exist
    create_dummy_data(AUGMENTATION_TABLES_DIR)

    # 1. Load training data
    train_df = load_data(train_path)
    if train_df is None:
        logging.error("Training data could not be loaded. Exiting.")
        return

    logging.info(f"Loaded training data from {train_path}. Shape: {train_df.shape}")

    # 2. Load augmentation tables
    violation_codes_info = load_data(os.path.join(AUGMENTATION_TABLES_DIR, 'violation_codes_info.csv'))
    street_attributes = load_data(os.path.join(AUGMENTATION_TABLES_DIR, 'street_attributes.csv'))

    # 3. Feature Engineering and Augmentation
    def preprocess(df, augmentation_codes=None, augmentation_streets=None, training_medians=None):
        df_processed = df.copy()

        # Merge with augmentation tables
        if augmentation_codes is not None:
            df_processed = pd.merge(df_processed, augmentation_codes, on='Violation Description', how='left')
        if augmentation_streets is not None:
            df_processed = pd.merge(df_processed, augmentation_streets, on='Street Name', how='left')

        # Handle NaNs from merges for numerical features
        numerical_cols_to_impute = ['Fine Amount', 'Residential Density', 'Street Length (miles)']
        for col in numerical_cols_to_impute:
            if col in df_processed.columns:
                if training_medians and col in training_medians:
                    # Use median from training data for consistency
                    df_processed[col] = df_processed[col].fillna(training_medians[col])
                else:
                    # Fallback to current dataframe's median or 0 if all are NaN
                    if not df_processed[col].isnull().all():
                        df_processed[col] = df_processed[col].fillna(df_processed[col].median())
                    else:
                        df_processed[col] = df_processed[col].fillna(0) # Default if no data
        
        # Handle NaNs from merges for categorical features
        categorical_cols_to_impute = ['Violation Category', 'Borough']
        for col in categorical_cols_to_impute:
            if col in df_processed.columns:
                df_processed[col] = df_processed[col].fillna('Unknown_Category') # Fill with a placeholder string

        return df_processed

    # Store training medians for numerical features to use in test data preprocessing
    training_medians = {}
    numerical_features_for_median = ['Fine Amount', 'Residential Density', 'Street Length (miles)']
    for col in numerical_features_for_median:
        if violation_codes_info is not None and col in violation_codes_info.columns:
            training_medians[col] = violation_codes_info[col].median()
        elif street_attributes is not None and col in street_attributes.columns:
            training_medians[col] = street_attributes[col].median()
            
    train_df_processed = preprocess(train_df, violation_codes_info, street_attributes, training_medians)

    # Identify features and categorical features for CatBoost
    target_column = 'violation_count'
    original_id_columns = ['Street Name', 'Violation Description']
    
    # All columns that are not the target should be considered features initially
    all_features = [col for col in train_df_processed.columns if col != target_column and col != 'log_violation_count']

    # Identify categorical features for CatBoost (string type columns)
    catboost_categorical_features = [
        col for col in all_features if train_df_processed[col].dtype == 'object'
    ]
    # Numerical features
    numerical_features = [
        col for col in all_features if train_df_processed[col].dtype != 'object'
    ]

    # Combine for final feature set for the model
    final_features_for_model = numerical_features + catboost_categorical_features
    
    logging.info(f"Features used in model: {final_features_for_model}")
    logging.info(f"Categorical features for CatBoost: {catboost_categorical_features}")

    # Target transformation: log1p
    train_df_processed['log_violation_count'] = np.log1p(train_df_processed['violation_count'])

    X = train_df_processed[final_features_for_model]
    y = train_df_processed['log_violation_count']

    # 4. Split training data for validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42, shuffle=True)

    # 5. Model Training (CatBoost Regressor)
    logging.info("Training CatBoostRegressor model...")
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=8,
        eval_metric='RMSE',
        random_seed=42,
        verbose=0,
        early_stopping_rounds=50,
        cat_features=catboost_categorical_features,
        thread_count=-1 # Use all available CPU cores
    )

    # Create CatBoost Pool for validation
    train_pool = Pool(X_train, y_train, cat_features=catboost_categorical_features)
    val_pool = Pool(X_val, y_val, cat_features=catboost_categorical_features)

    model.fit(train_pool, eval_set=val_pool, plot=False)

    # 6. Evaluate on validation set
    val_predictions_log = model.predict(X_val)
    # Inverse transform predictions and ensure non-negativity
    val_predictions = np.expm1(val_predictions_log)
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    val_rmse = rmse(np.expm1(y_val), val_predictions) # Compare against original scale (expm1(y_val) to get original counts)
    logging.info(f"Validation RMSE: {val_rmse:.4f}")
    print(f'Final Validation Performance: {val_rmse:.4f}')

    # 7. Make predictions on test data if provided
    if test_path:
        logging.info(f"Loading test data from {test_path} for prediction.")
        test_df = load_data(test_path)
        if test_df is None:
            logging.error("Test data could not be loaded. Skipping predictions for test set.")
            return

        original_test_keys = test_df[original_id_columns].copy()
        
        # Preprocess test data using medians derived from training data
        test_df_processed = preprocess(test_df, violation_codes_info, street_attributes, training_medians)
        
        # Identify unseen key pairs
        train_key_pairs = set(train_df.set_index(original_id_columns).index)
        test_key_pairs = set(test_df.set_index(original_id_columns).index)
        
        unseen_key_pairs = test_key_pairs - train_key_pairs
        num_unseen = len(unseen_key_pairs)
        logging.info(f"Number of unseen (street_name, violation_type) pairs in test set: {num_unseen}")

        # Ensure all required features are present in test_df_processed.
        for feature in final_features_for_model:
            if feature not in test_df_processed.columns:
                if feature in numerical_features:
                    test_df_processed[feature] = training_medians.get(feature, 0) # Use training median or 0
                else: # Must be a categorical feature
                    test_df_processed[feature] = 'Unknown_Feature_Placeholder' # Placeholder for missing categorical feature
        
        # Predict on test data
        X_test = test_df_processed[final_features_for_model]
        test_predictions_log = model.predict(X_test)
        
        # Inverse transform and clip predictions
        test_predictions = np.expm1(test_predictions_log)
        test_predictions[test_predictions < 0] = 0
        test_predictions = np.round(test_predictions).astype(int) # Round to nearest integer count

        # Create submission DataFrame
        submission_df = original_test_keys
        submission_df['predicted_count'] = test_predictions

        # Save submission file
        submission_df.to_csv(SUBMISSION_FILE_NAME, index=False)
        logging.info(f"Predictions saved to {SUBMISSION_FILE_NAME}")

        # If test_df contains 'violation_count', calculate and report RMSE
        if 'violation_count' in test_df.columns:
            true_counts = test_df['violation_count'].values
            test_rmse = rmse(true_counts, test_predictions)
            logging.info(f"Test Set RMSE: {test_rmse:.4f}")
            
            # Handle unseen for separate RMSE reporting
            test_df_indexed = test_df.set_index(original_id_columns)
            unseen_indices_bool = test_df_indexed.index.isin(unseen_key_pairs).values
            
            if np.any(unseen_indices_bool):
                unseen_rmse = rmse(true_counts[unseen_indices_bool], test_predictions[unseen_indices_bool])
                logging.info(f"Test Set RMSE for unseen key pairs: {unseen_rmse:.4f} ({num_unseen} pairs)")
                seen_rmse = rmse(true_counts[~unseen_indices_bool], test_predictions[~unseen_indices_bool])
                logging.info(f"Test Set RMSE for seen key pairs: {seen_rmse:.4f} ({len(test_df) - num_unseen} pairs)")

    else:
        logging.info("No test-path provided. Skipping test set prediction.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Predict NYC parking violations for 2023.")
    parser.add_argument('--train-path', type=str, default=DEFAULT_TRAIN_PATH,
                        help=f"Path to the 2022 training data. Default: {DEFAULT_TRAIN_PATH}")
    parser.add_argument('--test-path', type=str, default=None,
                        help="Optional: Path to the 2023 test/evaluation data. If provided, predictions will be generated and RMSE calculated if 'violation_count' is present.")

    args = parser.parse_args()

    # Ensure the input directory exists for dummy data creation
    os.makedirs('./input', exist_ok=True)

    main(args.train_path, args.test_path)
