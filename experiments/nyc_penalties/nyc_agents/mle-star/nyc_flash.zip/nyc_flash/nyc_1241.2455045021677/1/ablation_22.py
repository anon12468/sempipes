
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
# OUTPUT_SUBMISSION_FILE is not used in this ablation script, but kept for context

# --- Baseline functions with ablation parameters ---

def _engineer_features_ablated(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None,
                           skip_initial_column_standardization: bool = False, missing_value_placeholder: str = 'unknown') -> tuple[pd.DataFrame, dict]:
    """
    Performs feature engineering on the input DataFrame with ablation options.
    """
    if encoder_dict is None:
        encoder_dict = {}

    # Determine which column names to use for processing
    # This dictates how columns are referenced within this function and how `group_id` is later formed.
    if not skip_initial_column_standardization:
        # Standardize DF columns and use the standardized names for processing
        df.columns = df.columns.str.replace(' ', '_').str.lower()
        active_street_col_name = STREET_NAME_COL.replace(' ', '_').lower()
        active_violation_col_name = VIOLATION_DESC_COL.replace(' ', '_').lower()
    else:
        # Keep original DF columns, use original names for processing
        active_street_col_name = STREET_NAME_COL
        active_violation_col_name = VIOLATION_DESC_COL
        # Assuming TARGET_COLUMN 'violation_count' is already consistent (lowercase, no spaces)
        # or doesn't need transformation, as per typical CSV header naming for targets.

    # Handle missing values
    for col in [active_street_col_name, active_violation_col_name]:
        if col in df.columns: # Check if column exists, as some might be missing in test
            df[col] = df[col].fillna(missing_value_placeholder).astype(str)

    # Label Encoding for categorical features
    categorical_cols_to_encode = [active_street_col_name, active_violation_col_name]
    for col in categorical_cols_to_encode:
        if col in df.columns:
            # Encoded features always get a standardized name suffix, regardless of
            # `skip_initial_column_standardization` for consistency in feature lists.
            encoded_feature_name = col.replace(' ', '_').lower() + '_encoded'
            if is_training:
                le = LabelEncoder()
                df[encoded_feature_name] = le.fit_transform(df[col])
                encoder_dict[col] = le # Store encoder using the column name it was trained on (e.g., 'Street Name' or 'street_name')
            else:
                if col in encoder_dict:
                    df[encoded_feature_name] = df[col].map(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else -1)
                else:
                    df[encoded_feature_name] = -1 # Assign default for entirely new categories or if no encoder for this col

    # Log transform target if present, good for count data
    if TARGET_COLUMN in df.columns and is_training:
        df[TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

def load_and_preprocess_data_ablated(file_path: str, is_training: bool = True, encoder_dict: dict = None,
                                  skip_initial_column_standardization: bool = False, missing_value_placeholder: str = 'unknown') -> tuple[pd.DataFrame, dict]:
    """
    Loads data from a CSV file and applies initial preprocessing with ablation options.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features_ablated(df.copy(), is_training=is_training, encoder_dict=encoder_dict,
                                              skip_initial_column_standardization=skip_initial_column_standardization,
                                              missing_value_placeholder=missing_value_placeholder)
    return df, encoder_dict

def train_model_ablated(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series,
                     early_stopping_patience: int = 100) -> lgb.Booster:
    """
    Trains a LightGBM model with ablation options.
    """
    # LightGBM expects feature names as strings, so this sanitization is always performed for LGBM.
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'poisson',
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 63,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(early_stopping_patience, verbose=False)])

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_ablation_experiment(
    train_path: str,
    ablation_name: str,
    skip_initial_column_standardization: bool = False,
    missing_value_placeholder: str = 'unknown',
    early_stopping_patience: int = 100
) -> float:
    """
    Runs a single ablation experiment and returns the validation RMSE.
    """
    print(f"\n--- Running Ablation: {ablation_name} ---")

    df_2022_raw, encoder_dict = load_and_preprocess_data_ablated(
        train_path,
        is_training=True,
        skip_initial_column_standardization=skip_initial_column_standardization,
        missing_value_placeholder=missing_value_placeholder
    )

    # Determine which column names (raw categorical) are currently in df_2022_raw
    # to correctly form the `group_id` and `features` list.
    if not skip_initial_column_standardization:
        current_street_col_in_df = STREET_NAME_COL.replace(' ', '_').lower()
        current_violation_col_in_df = VIOLATION_DESC_COL.replace(' ', '_').lower()
    else:
        current_street_col_in_df = STREET_NAME_COL
        current_violation_col_in_df = VIOLATION_DESC_COL

    # Create a unique identifier for grouped splitting
    df_2022_raw['group_id'] = df_2022_raw[current_street_col_in_df] + '_' + \
                               df_2022_raw[current_violation_col_in_df]

    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])

    # Define features: all columns except target and the original categorical columns (encoded versions are implicitly included).
    features = [col for col in df_train_raw.columns if col not in [TARGET_COLUMN, current_street_col_in_df, current_violation_col_in_df]]

    X_train = df_train_raw[features]
    y_train = df_train_raw[TARGET_COLUMN]
    X_val = df_val_raw[features]
    y_val = df_val_raw[TARGET_COLUMN]

    print("Training model...")
    model = train_model_ablated(X_train, y_train, X_val, y_val, early_stopping_patience=early_stopping_patience)

    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log) # Inverse transform
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(np.expm1(y_val), val_predictions) # Calculate RMSE on original scale
    print(f"Validation RMSE for {ablation_name}: {final_validation_rmse:.4f}")

    gc.collect()
    return final_validation_rmse

def ablation_main():
    parser = argparse.ArgumentParser(description="Ablation study for NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()

    results = {}

    # --- Baseline Run ---
    print("--- Running Baseline ---")
    
    # Define active column names for baseline (standardized)
    baseline_active_street_col = STREET_NAME_COL.replace(' ', '_').lower()
    baseline_active_violation_col = VIOLATION_DESC_COL.replace(' ', '_').lower()

    df_2022_raw_baseline, encoder_dict_baseline = load_and_preprocess_data_ablated(
        args.train_path,
        is_training=True,
        skip_initial_column_standardization=False, # Original: standardize columns
        missing_value_placeholder='unknown' # Original
    )
    
    # Create group_id using standardized column names
    df_2022_raw_baseline['group_id'] = df_2022_raw_baseline[baseline_active_street_col] + '_' + \
                                      df_2022_raw_baseline[baseline_active_violation_col]

    unique_groups_baseline = df_2022_raw_baseline['group_id'].unique()
    train_groups_baseline, val_groups_baseline = train_test_split(unique_groups_baseline, test_size=0.2, random_state=42)

    df_train_raw_baseline = df_2022_raw_baseline[df_2022_raw_baseline['group_id'].isin(train_groups_baseline)].copy()
    df_val_raw_baseline = df_2022_raw_baseline[df_2022_raw_baseline['group_id'].isin(val_groups_baseline)].copy()

    df_train_raw_baseline = df_train_raw_baseline.drop(columns=['group_id'])
    df_val_raw_baseline = df_val_raw_baseline.drop(columns=['group_id'])

    # Define features for baseline
    features_baseline = [col for col in df_train_raw_baseline.columns if col not in [TARGET_COLUMN, baseline_active_street_col, baseline_active_violation_col]]

    X_train_baseline = df_train_raw_baseline[features_baseline]
    y_train_baseline = df_train_raw_baseline[TARGET_COLUMN]
    X_val_baseline = df_val_raw_baseline[features_baseline]
    y_val_baseline = df_val_raw_baseline[TARGET_COLUMN]

    print("Training Baseline model...")
    model_baseline = train_model_ablated(X_train_baseline, y_train_baseline, X_val_baseline, y_val_baseline, early_stopping_patience=100) # Original patience

    val_predictions_log_baseline = model_baseline.predict(X_val_baseline)
    val_predictions_baseline = np.expm1(val_predictions_log_baseline)
    val_predictions_baseline[val_predictions_baseline < 0] = 0

    baseline_rmse = calculate_rmse(np.expm1(y_val_baseline), val_predictions_baseline)
    print(f"Baseline Validation RMSE: {baseline_rmse:.4f}")
    results['Baseline'] = baseline_rmse
    gc.collect()

    # --- Ablation 1: Skip initial DataFrame column standardization ---
    results['No Initial Column Standardization'] = run_ablation_experiment(
        args.train_path,
        "No Initial Column Standardization",
        skip_initial_column_standardization=True, # Ablation: Do NOT standardize initial column names
        missing_value_placeholder='unknown', # Baseline
        early_stopping_patience=100 # Baseline
    )

    # --- Ablation 2: Change missing value placeholder to empty string '' ---
    results['Missing Value Placeholder: Empty String'] = run_ablation_experiment(
        args.train_path,
        "Missing Value Placeholder: Empty String",
        skip_initial_column_standardization=False, # Baseline
        missing_value_placeholder='', # Ablation: Use empty string for missing values
        early_stopping_patience=100 # Baseline
    )

    # --- Ablation 3: Reduce early stopping patience to 50 ---
    results['Early Stopping Patience: 50'] = run_ablation_experiment(
        args.train_path,
        "Early Stopping Patience: 50",
        skip_initial_column_standardization=False, # Baseline
        missing_value_placeholder='unknown', # Baseline
        early_stopping_patience=50 # Ablation: Reduce patience
    )

    print("\n--- Ablation Study Results Summary ---")
    for name, rmse in results.items():
        print(f"{name}: {rmse:.4f}")

    most_impactful_change = "Baseline"
    largest_impact = 0.0

    # Find the ablation with the largest absolute impact on RMSE
    for name, rmse in results.items():
        if name == "Baseline":
            continue
        impact = abs(baseline_rmse - rmse)
        if impact > largest_impact:
            largest_impact = impact
            most_impactful_change = name

    print(f"\nConclusion: The part that contributes the most to the overall performance (or whose change had the largest impact on RMSE) is: {most_impactful_change}")
    if most_impactful_change != "Baseline":
        if results[most_impactful_change] < baseline_rmse:
            print(f"This change led to an improvement in RMSE of {largest_impact:.4f}.")
        else:
            print(f"This change led to a degradation in RMSE of {largest_impact:.4f}.")

if __name__ == "__main__":
    ablation_main()
