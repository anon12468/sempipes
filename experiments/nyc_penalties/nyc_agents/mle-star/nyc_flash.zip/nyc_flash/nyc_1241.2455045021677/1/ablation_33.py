
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import catboost as cb # Not used in the provided code, but kept for consistency
import os
import lightgbm as lgb
import gc

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv'

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Performs feature engineering on the input DataFrame.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Handle missing values
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Label Encoding for categorical features
    categorical_cols = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col] = le
            else:
                if col in encoder_dict:
                    # Use transform for existing categories, map unknown to -1
                    df[col + '_encoded'] = df[col].map(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else -1)
                else:
                    df[col + '_encoded'] = -1 # Assign a default for entirely new categories if no encoder

    # Log transform target if present, good for count data
    if TARGET_COLUMN in df.columns and is_training:
        df[TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series, params: dict) -> lgb.Booster:
    """
    Trains a LightGBM model with given parameters.
    """
    original_train_cols = X_train.columns
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    categorical_features_names = []
    if 'street_name_encoded' in original_train_cols:
        categorical_features_names.append("street_name_encoded")
    if 'violation_description_encoded' in original_train_cols:
        categorical_features_names.append("violation_description_encoded")
    
    # Remove bagging/feature fraction parameters if boosting_type is 'goss'
    # These parameters are incompatible with GOSS
    modified_params = params.copy() # Use a copy to avoid modifying the original dict
    if modified_params.get('boosting_type') == 'goss':
        modified_params.pop('bagging_fraction', None)
        modified_params.pop('bagging_freq', None)
        modified_params.pop('feature_fraction', None)

    model = lgb.LGBMRegressor(**modified_params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)], # Use callbacks for early stopping
              categorical_feature=categorical_features_names) # Explicitly declare categorical features

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_experiment(df_2022_raw: pd.DataFrame, encoder_dict: dict, model_params: dict, experiment_name: str):
    """
    Runs a single training and validation experiment with given model parameters.
    """
    # Split 2022 data for training and validation
    # Create a unique identifier for splitting
    df_temp = df_2022_raw.copy()
    df_temp['group_id'] = df_temp[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                           df_temp[VIOLATION_DESC_COL.replace(' ', '_').lower()]

    # Get unique groups
    unique_groups = df_temp['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_temp[df_temp['group_id'].isin(train_groups)].copy()
    df_val_raw = df_temp[df_temp['group_id'].isin(val_groups)].copy()

    # Drop the temporary group_id
    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    # Define features and target
    features = [col for col in df_train_raw.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]]

    # Prepare training data
    X_train = df_train_raw[features]
    y_train = df_train_raw[TARGET_COLUMN]

    # Prepare validation data
    X_val = df_val_raw[features]
    y_val = df_val_raw[TARGET_COLUMN]

    # Train model
    model = train_model(X_train, y_train, X_val, y_val, model_params)

    # Predict on validation set for performance reporting
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log) # Inverse transform
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(np.expm1(y_val), val_predictions) # Calculate RMSE on original scale
    print(f"[{experiment_name}] Validation RMSE: {final_validation_rmse:.4f}")
    return final_validation_rmse

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()

    print(f"Loading training data from: {args.train_path}")
    df_2022_raw, encoder_dict = load_and_preprocess_data(args.train_path, is_training=True)

    results = {}

    # Baseline Parameters (from current solution)
    baseline_params = {
        'objective': 'poisson',
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 63,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    # Run Baseline
    print("Running Baseline experiment...")
    results['Baseline'] = run_experiment(df_2022_raw.copy(), encoder_dict, baseline_params, 'Baseline')

    # Ablation 1: Reduce num_leaves from 63 to 31
    ablation1_params = baseline_params.copy()
    ablation1_params['num_leaves'] = 31
    print("\nRunning Ablation 1: Reduce num_leaves to 31...")
    results['Ablation 1 (num_leaves=31)'] = run_experiment(df_2022_raw.copy(), encoder_dict, ablation1_params, 'Ablation 1')

    # Ablation 2: Change boosting_type from 'gbdt' to 'goss'
    # Note: 'goss' boosting type is incompatible with bagging_fraction, bagging_freq, and feature_fraction.
    # The train_model function handles popping these parameters.
    ablation2_params = baseline_params.copy()
    ablation2_params['boosting_type'] = 'goss'
    print("\nRunning Ablation 2: Change boosting_type to 'goss'...")
    results['Ablation 2 (boosting_type=goss)'] = run_experiment(df_2022_raw.copy(), encoder_dict, ablation2_params, 'Ablation 2')
    
    # Ablation 3: Adjust L1/L2 Regularization from 0.1 to 0.001
    ablation3_params = baseline_params.copy()
    ablation3_params['lambda_l1'] = 0.001
    ablation3_params['lambda_l2'] = 0.001
    print("\nRunning Ablation 3: Reduce L1/L2 Regularization to 0.001...")
    results['Ablation 3 (L1/L2=0.001)'] = run_experiment(df_2022_raw.copy(), encoder_dict, ablation3_params, 'Ablation 3')

    print("\n--- Ablation Study Summary ---")
    
    best_rmse = float('inf')
    best_config = ""

    for config, rmse in results.items():
        print(f"  {config}: {rmse:.4f}")
        if rmse < best_rmse:
            best_rmse = rmse
            best_config = config
    
    print("\n--- Conclusion ---")
    if best_config == "Baseline":
        print(f"The Baseline configuration contributed the most to the overall performance with an RMSE of {best_rmse:.4f}.")
        print("None of the tested ablations improved upon the baseline performance.")
    else:
        print(f"The part of the code that contributes the most to the overall performance is: {best_config}")
        print(f"This configuration achieved the lowest RMSE of {best_rmse:.4f}, which is an improvement of {(results['Baseline'] - best_rmse):.4f} over the Baseline.")

    gc.collect()

if __name__ == "__main__":
    main()
