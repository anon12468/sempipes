
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import OneHotEncoder
from sklearn.linear_model import PoissonRegressor
import os
import argparse
import logging
from scipy.sparse import hstack

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Configuration ---
DEFAULT_TRAIN_PATH = './input/violations_per_street_2022.csv'
AUX_VIOLATION_CODES_PATH = './input/nyc_parking_violation_codes.csv'
AUX_STREET_INFO_PATH = './input/nyc_street_names_info.csv'
AUX_BOROUGH_ZIP_VIOLATIONS_PATH = './input/violations_by_borough_and_zipcode_2022.csv'
OUTPUT_DIR = './predictions'
SUBMISSION_FILENAME = 'submission.csv'

TARGET_COLUMN = 'violation_count'
# Standardized key columns for consistent handling across dataframes
KEY_COLUMNS = ['Street_Name', 'Violation_Description'] 

def parse_args():
    """Parses command line arguments."""
    parser = argparse.ArgumentParser(description="Predict NYC parking violations using Scikit-learn PoissonRegressor.")
    parser.add_argument('--train-path', type=str, default=DEFAULT_TRAIN_PATH,
                        help='Path to the 2022 violations training data.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional path to the 2023 violations test data for prediction/evaluation.')
    return parser.parse_args()

def standardize_column_names(df):
    """Standardizes column names for consistency."""
    df.columns = df.columns.str.strip().str.replace(' ', '_')
    return df

def load_data(file_path):
    """Loads CSV data from the given path."""
    logging.info(f"Loading data from {file_path}")
    try:
        df = pd.read_csv(file_path)
        return standardize_column_names(df)
    except FileNotFoundError:
        logging.error(f"File not found: {file_path}")
        return None
    except Exception as e:
        logging.error(f"Error loading {file_path}: {e}")
        return None

def feature_engineer_base(df, violation_codes_df, street_info_df, borough_zip_violations_df):
    """
    Performs base feature engineering by merging auxiliary data and handling NaNs.
    Categorical features are left as strings for subsequent OneHotEncoding.
    """
    logging.info("Starting base feature engineering...")
    
    # Ensure all auxiliary dataframes have standardized column names
    violation_codes_df = standardize_column_names(violation_codes_df.copy())
    street_info_df = standardize_column_names(street_info_df.copy())
    borough_zip_violations_df = standardize_column_names(borough_zip_violations_df.copy())

    # --- Merge with Violation Codes ---
    df = pd.merge(df, violation_codes_df[['Violation_Description', 'Violation_Type']],
                  on='Violation_Description', how='left')
    logging.debug(f"Merged with violation codes. Shape: {df.shape}")

    # --- Merge with Street Info (Borough, Zip Code) ---
    df = pd.merge(df, street_info_df[['Street_Name', 'Borough', 'Zip_Code']],
                  on='Street_Name', how='left')
    logging.debug(f"Merged with street info. Shape: {df.shape}")

    # --- Merge with Borough and Zip Code Violations ---
    # Rename 'violation_count' in the auxiliary table to avoid conflict and make it a feature
    borough_zip_violations_df = borough_zip_violations_df.rename(columns={'violation_count': 'borough_zip_2022_violation_count'})
    df = pd.merge(df, borough_zip_violations_df[['Borough', 'Zip_Code', 'borough_zip_2022_violation_count']],
                  on=['Borough', 'Zip_Code'], how='left')
    logging.debug(f"Merged with borough_zip_violations_2022. Shape: {df.shape}")

    # --- Handle Missing Values (before encoding) ---
    # For new streets/violations/boroughs/zips, the merged features might be NaN.
    # Fill categorical NaNs with a placeholder string, numerical NaNs with 0 or -1.
    for col in ['Violation_Type', 'Borough']:
        df[col] = df[col].fillna('UNKNOWN_CATEGORY').astype(str) # Ensure string type
    df['Zip_Code'] = df['Zip_Code'].fillna(-1).astype(int) # Use -1 for unknown zip
    df['borough_zip_2022_violation_count'] = df['borough_zip_2022_violation_count'].fillna(0) # Fill aggregate counts with 0 for unseen combos
    
    logging.info("Base feature engineering complete.")
    return df

def prepare_glm_features(df, is_training, preprocessors=None):
    """
    Prepares features for GLM, including One-Hot Encoding and feature selection.
    
    Args:
        df (pd.DataFrame): Dataframe with base engineered features.
        is_training (bool): True if processing training data, False otherwise.
        preprocessors (dict): Dictionary to store/retrieve fitted preprocessors (e.g., OneHotEncoder).

    Returns:
        tuple: (X (sparse matrix), updated_preprocessors)
    """
    if preprocessors is None:
        preprocessors = {}

    logging.info(f"Preparing GLM features for {'training' if is_training else 'evaluation/test'} data...")

    # Define categorical and numerical features for the GLM
    # Street_Name is omitted as a direct feature due to high cardinality for OHE,
    # and its effects are hopefully captured by Borough/Zip_Code.
    categorical_features_for_ohe = ['Violation_Description', 'Violation_Type', 'Borough']
    numerical_features = ['Zip_Code', 'borough_zip_2022_violation_count']

    # Filter to only include columns that are actually present in the dataframe
    categorical_features_for_ohe = [col for col in categorical_features_for_ohe if col in df.columns]
    numerical_features = [col for col in numerical_features if col in df.columns]

    # One-Hot Encoding for categorical features
    ohe_features = None
    if categorical_features_for_ohe:
        if is_training:
            # handle_unknown='ignore' allows unseen categories in test data without error, outputs zeros
            ohe = OneHotEncoder(handle_unknown='ignore', sparse_output=True) 
            ohe.fit(df[categorical_features_for_ohe])
            preprocessors['ohe'] = ohe
        else:
            ohe = preprocessors.get('ohe')
            if ohe is None:
                logging.error("OneHotEncoder not fitted during training. Cannot process test data.")
                return None, preprocessors # Indicate failure

        ohe_features = ohe.transform(df[categorical_features_for_ohe])
        logging.debug(f"Shape after OHE: {ohe_features.shape}")

    # Numerical features
    num_features_df = df[numerical_features].astype(float) # Ensure float type for consistency

    # Combine OHE features and numerical features
    if ohe_features is not None:
        X = hstack([ohe_features, num_features_df.values])
    else:
        X = num_features_df.values # No categorical features were present
    
    logging.info(f"GLM feature preparation complete. Total features: {X.shape[1]}")
    return X, preprocessors


def train_and_predict_glm(X_train, y_train, X_eval, y_eval, X_test=None):
    """
    Trains the PoissonRegressor model and makes predictions.

    Args:
        X_train (sparse matrix): Training features.
        y_train (pd.Series): Training target.
        X_eval (sparse matrix): Validation features.
        y_eval (pd.Series): Validation target.
        X_test (sparse matrix, optional): Test features.

    Returns:
        tuple: (validation_predictions, validation_rmse, test_predictions)
    """
    
    # PoissonRegressor expects non-negative targets
    y_train_glm = y_train.copy().clip(lower=0)
    
    logging.info("Training PoissonRegressor model...")
    poisson_glm_model = PoissonRegressor(alpha=1.0, fit_intercept=True, max_iter=1000, random_state=42)
    poisson_glm_model.fit(X_train, y_train_glm)
    logging.info("PoissonRegressor training complete.")

    # Evaluate on validation set
    val_predictions = poisson_glm_model.predict(X_eval)
    val_predictions = np.maximum(0, np.round(val_predictions)).astype(int) # Ensure non-negative integer predictions
    rmse_val = np.sqrt(mean_squared_error(y_eval, val_predictions))
    logging.info(f"Validation RMSE: {rmse_val:.4f}")

    # Predictions for the test set if provided
    test_predictions = None
    if X_test is not None:
        logging.info("Generating predictions for test set...")
        test_predictions = poisson_glm_model.predict(X_test)
        test_predictions = np.maximum(0, np.round(test_predictions)).astype(int) # Ensure non-negative integer predictions
        logging.info("Predictions generated for test set.")
    
    return val_predictions, rmse_val, test_predictions

def report_unseen_keys(train_keys_df, eval_keys_df, test_keys_df=None):
    """
    Reports the number of unseen (street_name, violation_description) pairs.
    """
    train_key_set = set(train_keys_df.apply(lambda row: (row['Street_Name'], row['Violation_Description']), axis=1))
    
    # For validation set
    eval_key_set = set(eval_keys_df.apply(lambda row: (row['Street_Name'], row['Violation_Description']), axis=1))
    unseen_in_eval = eval_key_set - train_key_set
    logging.info(f"{len(unseen_in_eval)} out of {len(eval_key_set)} validation (Street_Name, Violation_Description) pairs were unseen in training data.")

    # For test set
    unseen_in_test = None
    if test_keys_df is not None:
        test_key_set = set(test_keys_df.apply(lambda row: (row['Street_Name'], row['Violation_Description']), axis=1))
        unseen_in_test = test_key_set - train_key_set
        logging.info(f"{len(unseen_in_test)} out of {len(test_key_set)} test (Street_Name, Violation_Description) pairs were unseen in training data.")
    return unseen_in_eval, unseen_in_test

def main():
    args = parse_args()

    # Create output directory
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # --- Load Data ---
    train_full_df = load_data(args.train_path)
    if train_full_df is None:
        return

    # Load auxiliary data
    violation_codes_df = load_data(AUX_VIOLATION_CODES_PATH)
    street_info_df = load_data(AUX_STREET_INFO_PATH)
    borough_zip_violations_df = load_data(AUX_BOROUGH_ZIP_VIOLATIONS_PATH)

    if any(df is None for df in [violation_codes_df, street_info_df, borough_zip_violations_df]):
        logging.error("Failed to load auxiliary data. Exiting.")
        return

    # --- Split 2022 data into training and validation ---
    # Using 'Violation_Description' for stratification to ensure representative distribution.
    # Fallback to simple random split if stratification fails (e.g., due to rare categories).
    try:
        train_data_2022, eval_data_2022 = train_test_split(
            train_full_df, test_size=0.2, random_state=42, stratify=train_full_df['Violation_Description']
        )
    except ValueError as e:
        logging.warning(f"Stratification failed: {e}. Falling back to simple random split.")
        train_data_2022, eval_data_2022 = train_test_split(
            train_full_df, test_size=0.2, random_state=42
        )
    logging.info(f"Split 2022 data: Train {train_data_2022.shape}, Validation {eval_data_2022.shape}")

    # --- Base Feature Engineering ---
    # Apply base engineering to all datasets first
    base_train_df = feature_engineer_base(train_data_2022.copy(), violation_codes_df, street_info_df, borough_zip_violations_df)
    base_eval_df = feature_engineer_base(eval_data_2022.copy(), violation_codes_df, street_info_df, borough_zip_violations_df)

    # --- Prepare GLM Features ---
    # This step involves OneHotEncoding and feature selection specific to GLM
    glm_preprocessors = {} # Dictionary to hold OHE and potentially other preprocessors
    X_train, glm_preprocessors = prepare_glm_features(base_train_df, is_training=True, preprocessors=glm_preprocessors)
    X_eval, glm_preprocessors = prepare_glm_features(base_eval_df, is_training=False, preprocessors=glm_preprocessors)
    
    y_train = base_train_df[TARGET_COLUMN]
    y_eval = base_eval_df[TARGET_COLUMN]

    # --- Load and Process Test Data if provided ---
    test_df_original = None
    X_test = None
    if args.test_path:
        test_df_original = load_data(args.test_path)
        if test_df_original is None:
            logging.error("Could not load test data. Skipping test prediction.")
        else:
            # Check if 'violation_count' exists in test_df_original for evaluation
            has_ground_truth = TARGET_COLUMN in test_df_original.columns
            if has_ground_truth:
                logging.info(f"Test file '{args.test_path}' contains '{TARGET_COLUMN}'. Will report RMSE on it.")
            else:
                logging.info(f"Test file '{args.test_path}' does NOT contain '{TARGET_COLUMN}'. Will only generate predictions.")
            
            # Apply base engineering to test data
            base_test_df = feature_engineer_base(test_df_original.copy(), violation_codes_df, street_info_df, borough_zip_violations_df)
            
            # Prepare GLM features for test data
            X_test, glm_preprocessors = prepare_glm_features(base_test_df, is_training=False, preprocessors=glm_preprocessors)
            if X_test is None: # Check if prepare_glm_features failed
                logging.error("Failed to prepare GLM features for test data. Skipping test prediction.")

    # --- Report Unseen Keys ---
    # Pass original DFs to report_unseen_keys as encoding is irrelevant for key comparison
    unseen_eval_pairs, unseen_test_pairs = report_unseen_keys(
        train_data_2022[KEY_COLUMNS], eval_data_2022[KEY_COLUMNS], 
        test_df_original[KEY_COLUMNS] if test_df_original is not None else None
    )

    # --- Train Model and Predict ---
    val_predictions, final_validation_rmse, test_predictions = train_and_predict_glm(
        X_train, y_train, X_eval, y_eval, X_test
    )

    print(f"Final Validation Performance: {final_validation_rmse:.4f}")

    # --- Generate Submission File ---
    if X_test is not None and test_predictions is not None:
        submission_df = test_df_original[KEY_COLUMNS].copy() # Use original keys for submission
        submission_df['predicted_count'] = test_predictions

        submission_path = os.path.join(OUTPUT_DIR, SUBMISSION_FILENAME)
        submission_df.to_csv(submission_path, index=False)
        logging.info(f"Submission file generated at: {submission_path}")

        # If test set has ground truth, report RMSE for context
        if TARGET_COLUMN in test_df_original.columns:
            test_ground_truth = test_df_original[TARGET_COLUMN]
            rmse_test = np.sqrt(mean_squared_error(test_ground_truth, test_predictions))
            logging.info(f"Test Set RMSE (against provided ground truth): {rmse_test:.4f}")
    elif args.test_path: # Test path was provided but processing failed or predictions weren't made
        logging.warning("No submission file generated due to issues with test data processing or prediction.")

if __name__ == "__main__":
    main()
