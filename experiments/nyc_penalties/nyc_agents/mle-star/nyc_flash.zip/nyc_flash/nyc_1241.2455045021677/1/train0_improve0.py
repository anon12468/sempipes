
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc
import os

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv'

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> (pd.DataFrame, dict):
    """
    Performs feature engineering on the input DataFrame.
    """
    if encoder_dict is None:
        encoder_dict = {}

    # Standardize column names
    df.columns = df.columns.str.replace(' ', '_').str.lower()

    # Handle missing values
    street_col_standardized = STREET_NAME_COL.replace(' ', '_').lower()
    violation_col_standardized = VIOLATION_DESC_COL.replace(' ', '_').lower()

    for col in [street_col_standardized, violation_col_standardized]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Label Encoding for categorical features
    categorical_cols = [street_col_standardized, violation_col_standardized]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col] = le
            else:
                if col in encoder_dict:
                    # Use transform for existing categories, map unknown to -1
                    # Handle cases where `s` might not be in `encoder_dict[col].classes_`
                    df[col + '_encoded'] = df[col].apply(
                        lambda s: encoder_dict[col].transform([s])[0]
                        if s in encoder_dict[col].classes_ else -1
                    )
                else:
                    # Assign a default for entirely new categories if no encoder was fitted for this column
                    df[col + '_encoded'] = -1

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None) -> (pd.DataFrame, dict):
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    # Ensure target column is handled if present in the data for training, but not for feature engineering
    df_processed, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    return df_processed, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series) -> lgb.Booster:
    """
    Trains a LightGBM model.
    """
    # LightGBM expects feature names as strings
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'regression_l1',  # MAE objective - as per original code
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 31,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)])

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    Clips predictions to be non-negative before calculating RMSE.
    """
    y_pred_clipped = np.maximum(0, y_pred) # Ensure predictions are non-negative
    return np.sqrt(mean_squared_error(y_true, y_pred_clipped))

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional: Path to the 2023 test/evaluation data CSV.')
    args = parser.parse_args()

    print(f"Loading training data from: {args.train_path}")
    df_2022_raw, encoder_dict = load_and_preprocess_data(args.train_path, is_training=True)

    # Split 2022 data for training and validation
    # Use grouped holdout for (street_name, violation_type) pairs
    # Create a unique identifier for splitting
    street_col_standardized = STREET_NAME_COL.replace(' ', '_').lower()
    violation_col_standardized = VIOLATION_DESC_COL.replace(' ', '_').lower()

    df_2022_raw['group_id'] = df_2022_raw[street_col_standardized] + '_' + df_2022_raw[violation_col_standardized]

    # Get unique groups
    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    # Drop the temporary group_id
    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    # Define features and target
    # Ensure target column is standardized
    target_col_standardized = TARGET_COLUMN.lower() # No need to replace space as it's 'violation_count'

    features = [col for col in df_train_raw.columns if col not in [target_col_standardized, street_col_standardized, violation_col_standardized]]

    # Prepare training data
    X_train = df_train_raw[features]
    y_train = df_train_raw[target_col_standardized]

    # Prepare validation data
    X_val = df_val_raw[features]
    y_val = df_val_raw[target_col_standardized]

    print("Training model...")
    model = train_model(X_train, y_train, X_val, y_val)

    # Predict on validation set for performance reporting
    # Removed np.expm1 as the target was not log-transformed
    val_predictions = model.predict(X_val)
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    # Calculate RMSE on original scale
    # Removed np.expm1 on y_val as the target was not log-transformed
    final_validation_rmse = calculate_rmse(y_val, val_predictions) 
    print(f"Final Validation Performance: {final_validation_rmse}")

    # If a test path is provided, generate predictions
    if args.test_path:
        print(f"Loading test data from: {args.test_path}")
        df_test_raw, _ = load_and_preprocess_data(args.test_path, is_training=False, encoder_dict=encoder_dict)

        # Ensure test data has the same features as training data
        test_features = [col for col in features if col in df_test_raw.columns]
        X_test = df_test_raw[test_features]

        # Align columns - crucial for consistent predictions
        # Add missing columns to X_test with 0, remove extra columns
        missing_cols = set(X_train.columns) - set(X_test.columns)
        for c in missing_cols:
            X_test[c] = 0
        extra_cols = set(X_test.columns) - set(X_train.columns)
        X_test = X_test.drop(columns=list(extra_cols))
        X_test = X_test[X_train.columns] # Ensure column order is the same

        print("Generating predictions for test data...")
        # Removed np.expm1 as the target was not log-transformed
        test_predictions = model.predict(X_test)
        test_predictions[test_predictions < 0] = 0 # Clip negative predictions
        test_predictions = np.round(test_predictions).astype(int) # Round to nearest integer

        # Create submission file
        submission_df = pd.DataFrame({
            STREET_NAME_COL: df_test_raw[street_col_standardized],
            VIOLATION_DESC_COL: df_test_raw[violation_col_standardized],
            PREDICTED_COUNT_COL: test_predictions
        })
        # Restore original column names for submission if they were modified
        submission_df.columns = [STREET_NAME_COL, VIOLATION_DESC_COL, PREDICTED_COUNT_COL]

        submission_df.to_csv(OUTPUT_SUBMISSION_FILE, index=False)
        print(f"Submission file '{OUTPUT_SUBMISSION_FILE}' created successfully.")

        # If test_path contains 'violation_count', calculate RMSE
        if target_col_standardized in df_test_raw.columns:
            # Removed np.expm1 on actual values as the target was not log-transformed
            y_test_true = df_test_raw[target_col_standardized] 
            test_rmse = calculate_rmse(y_test_true, test_predictions)
            print(f"RMSE on provided test/evaluation data: {test_rmse}")

            # Report unseen key pairs
            train_keys = df_2022_raw[street_col_standardized] + '_' + df_2022_raw[violation_col_standardized]
            test_keys = df_test_raw[street_col_standardized] + '_' + df_test_raw[violation_col_standardized]

            unseen_keys_count = test_keys.isin(train_keys).value_counts().get(False, 0)
            total_test_keys = len(test_keys)
            print(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {unseen_keys_count} out of {total_test_keys}")
            print("Unseen pairs are handled by the model's ability to generalize based on encoded features and numerical interaction features, "
                  "and by assigning -1 for unknown categories during Label Encoding transform.")

    gc.collect()

if __name__ == "__main__":
    main()
