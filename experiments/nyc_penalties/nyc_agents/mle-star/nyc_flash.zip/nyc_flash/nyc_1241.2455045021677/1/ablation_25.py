
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import os
import lightgbm as lgb
import gc

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv'

def _engineer_features_internal(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None,
                                unseen_category_strategy: str = '-1', apply_log_transform: bool = True) -> pd.DataFrame:
    """
    Performs feature engineering on the input DataFrame. This internal function is designed
    to be called carefully for train and validation splits.
    """
    if encoder_dict is None:
        encoder_dict = {}

    # Standardize column names (already done at load_and_preprocess_data level but safe to repeat for consistency)
    df.columns = df.columns.str.replace(' ', '_').str.lower() 

    # Handle missing values
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Label Encoding for categorical features
    categorical_cols = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col] = le
            else: # is_training is False, so apply transform
                if col in encoder_dict:
                    # Use transform for existing categories, map unknown according to strategy
                    if unseen_category_strategy == '-1':
                        df[col + '_encoded'] = df[col].map(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else -1)
                    elif unseen_category_strategy == 'max_label':
                        max_label_value = len(encoder_dict[col].classes_) # New category index (max_label + 1)
                        df[col + '_encoded'] = df[col].map(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else max_label_value)
                    else: # Fallback
                        df[col + '_encoded'] = df[col].map(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else -1)
                else:
                    df[col + '_encoded'] = -1 # Assign a default for entirely new categories if no encoder

    # Log transform target if present and apply_log_transform is True
    if TARGET_COLUMN in df.columns and apply_log_transform:
        df[TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict


def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series,
                lgbm_params_override: dict = None) -> lgb.Booster:
    """
    Trains a LightGBM model.
    """
    # LightGBM expects feature names as strings and sanitized names
    original_train_cols = X_train.columns
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    # Identify categorical features based on the plan
    categorical_features_names = []
    if 'street_name_encoded' in original_train_cols:
        categorical_features_names.append("street_name_encoded")
    if 'violation_description_encoded' in original_train_cols:
        categorical_features_names.append("violation_description_encoded")

    # LightGBM parameters
    params = {
        'objective': 'poisson',
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 63,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }
    
    if lgbm_params_override:
        params.update(lgbm_params_override)

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)],
              categorical_feature=categorical_features_names)

    return model

def run_ablation(train_path: str,
                 unseen_category_strategy: str = '-1',
                 lgbm_params_override: dict = None,
                 description: str = "Baseline") -> float:
    
    print(f"\n--- Running Ablation: {description} ---")

    # Load original data once for consistent splitting
    df_full_original = pd.read_csv(train_path)
    df_full_original.columns = df_full_original.columns.str.replace(' ', '_').str.lower()
    
    # Create group_id for splitting
    df_full_original['group_id'] = df_full_original[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                                   df_full_original[VIOLATION_DESC_COL.replace(' ', '_').lower()]

    # Split groups
    unique_groups = df_full_original['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    # Separate original data into train and validation sets based on groups
    df_train_original_split = df_full_original[df_full_original['group_id'].isin(train_groups)].copy()
    df_val_original_split = df_full_original[df_full_original['group_id'].isin(val_groups)].copy()

    # Store actual target values for validation RMSE calculation (original scale)
    y_val_original_scale = df_val_original_split[TARGET_COLUMN.replace(' ', '_').lower()].copy()

    # Apply feature engineering and transformations for training set
    df_train_processed, encoder_dict = _engineer_features_internal(
        df_train_original_split.drop(columns=['group_id']),
        is_training=True, 
        unseen_category_strategy=unseen_category_strategy,
        apply_log_transform=True # Always apply log transform for training data as per base model
    )

    # Apply feature engineering and transformations for validation set
    # The validation set's target will also be log-transformed for consistency when passed to eval_set
    df_val_processed, _ = _engineer_features_internal(
        df_val_original_split.drop(columns=['group_id']),
        is_training=False, # Use existing encoder
        encoder_dict=encoder_dict,
        unseen_category_strategy=unseen_category_strategy,
        apply_log_transform=True # Apply log transform for y_val passed to eval_set for consistency with y_train
    )
    
    # Define features and target column names (after standardization)
    features_cols = [col for col in df_train_processed.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]]

    # Prepare training data
    X_train = df_train_processed[features_cols]
    y_train = df_train_processed[TARGET_COLUMN]

    # Prepare validation data for LightGBM's eval_set
    X_val = df_val_processed[features_cols]
    y_val_for_lgbm = df_val_processed[TARGET_COLUMN] # This is log1p transformed, for LightGBM's eval_set

    print("Training model...")
    model = train_model(X_train, y_train, X_val, y_val_for_lgbm, lgbm_params_override)

    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log) # Inverse transform
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(y_val_original_scale, val_predictions) # Calculate RMSE on original scale
    print(f"Validation Performance ({description}): {final_validation_rmse}")
    
    gc.collect()
    return final_validation_rmse

# Main ablation study execution
def main():
    parser = argparse.ArgumentParser(description="Ablation study for NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()

    results = {}

    # --- Baseline ---
    baseline_rmse = run_ablation(args.train_path, description="Baseline Model")
    results["Baseline Model"] = baseline_rmse

    # --- Ablation 1: Map unknown categories to max_label+1 ---
    # This changes the placeholder for unseen categories in LabelEncoder from -1 to max_label + 1.
    ablation1_rmse = run_ablation(args.train_path,
                                  unseen_category_strategy='max_label',
                                  description="Ablation 1: Map unknown categories to max_label+1")
    results["Ablation 1: Map unknown categories to max_label+1"] = ablation1_rmse

    # --- Ablation 2: Increase min_child_samples to 50 ---
    # `min_child_samples` (or `min_data_in_leaf`) controls the minimum number of data a leaf must have.
    # Increasing it acts as a regularization to prevent overfitting. Default is 20 for regression.
    ablation2_params = {'min_child_samples': 50}
    ablation2_rmse = run_ablation(args.train_path,
                                  lgbm_params_override=ablation2_params,
                                  description="Ablation 2: Increase min_child_samples to 50")
    results["Ablation 2: Increase min_child_samples to 50"] = ablation2_rmse

    # --- Ablation 3: Add path_smooth=1.0 ---
    # `path_smooth` is a regularization parameter in LightGBM that helps to reduce overfitting
    # by smoothing the output of trees. Default is 0 (disabled).
    ablation3_params = {'path_smooth': 1.0}
    ablation3_rmse = run_ablation(args.train_path,
                                  lgbm_params_override=ablation3_params,
                                  description="Ablation 3: Add path_smooth=1.0")
    results["Ablation 3: Add path_smooth=1.0"] = ablation3_rmse

    print("\n--- Ablation Study Results ---")
    for name, rmse in results.items():
        print(f"{name}: RMSE = {rmse:.4f}")

    # Determine most impactful component
    best_rmse = min(results.values())
    
    most_impactful_change_summary = ""
    
    if best_rmse == baseline_rmse:
        most_impactful_change_summary = f"The Baseline Model (RMSE: {baseline_rmse:.4f}) achieved the best performance. No ablation improved upon it."
    else:
        best_ablation_name = ""
        for name, rmse in results.items():
            if rmse == best_rmse and name != "Baseline Model": 
                best_ablation_name = name
                break
        
        improvement = baseline_rmse - best_rmse
        most_impactful_change_summary = (
            f"The most impactful change, leading to the best performance, was '{best_ablation_name}'. "
            f"It improved the RMSE by {improvement:.4f} compared to the Baseline Model (RMSE: {baseline_rmse:.4f})."
        )
    
    worst_rmse = max(results.values())
    if worst_rmse > baseline_rmse:
        worst_ablation_name = ""
        for name, rmse in results.items():
            if rmse == worst_rmse and name != "Baseline Model":
                worst_ablation_name = name
                break
        if worst_ablation_name:
            detriment = worst_rmse - baseline_rmse
            if not most_impactful_change_summary: # If no positive impact was found
                most_impactful_change_summary = f"The most impactful change, leading to the worst performance, was '{worst_ablation_name}'. It degraded the RMSE by {detriment:.4f}."
            else:
                most_impactful_change_summary += (
                    f"\nConversely, '{worst_ablation_name}' was the most detrimental, degrading the RMSE by {detriment:.4f}."
                )

    print(f"\nMost impactful component: {most_impactful_change_summary}")

if __name__ == "__main__":
    main()
