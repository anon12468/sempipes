
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import catboost as cb 
import os
import lightgbm as lgb
import gc

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv'

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None,
                       apply_log_transform_target: bool = True) -> pd.DataFrame:
    """
    Performs feature engineering on the input DataFrame.
    Ablation point: apply_log_transform_target
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Handle missing values
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Label Encoding for categorical features
    categorical_cols = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col] = le
            else:
                if col in encoder_dict:
                    # Use transform for existing categories, map unknown to -1
                    df[col + '_encoded'] = df[col].map(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else -1)
                else:
                    df[col + '_encoded'] = -1 # Assign a default for entirely new categories if no encoder

    # Log transform target if present, good for count data
    if TARGET_COLUMN in df.columns and is_training and apply_log_transform_target:
        df[TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None,
                             apply_log_transform_target: bool = True) -> pd.DataFrame:
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict,
                                          apply_log_transform_target=apply_log_transform_target)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series,
                lgbm_eval_metric: str = 'rmse') -> lgb.Booster:
    """
    Trains a LightGBM model.
    Ablation point: lgbm_eval_metric
    """
    # LightGBM expects feature names as strings
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'poisson',
        'metric': lgbm_eval_metric, 
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 63,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric=lgbm_eval_metric,
              callbacks=[lgb.early_stopping(100, verbose=False)])

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_experiment(train_path: str,
                   apply_log_transform_target: bool,
                   lgbm_eval_metric: str,
                   validation_test_size: float,
                   experiment_name: str) -> float:
    """
    Runs a single experiment with specified modifications and returns the validation RMSE.
    Ablation point: validation_test_size
    """
    
    print(f"\n--- Running Experiment: {experiment_name} ---")
    
    print(f"Loading training data from: {train_path}")
    df_2022_raw, encoder_dict = load_and_preprocess_data(train_path, is_training=True,
                                                        apply_log_transform_target=apply_log_transform_target)

    # Split 2022 data for training and validation
    df_2022_raw['group_id'] = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=validation_test_size, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    features = [col for col in df_train_raw.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]]

    X_train = df_train_raw[features]
    y_train = df_train_raw[TARGET_COLUMN]

    X_val = df_val_raw[features]
    y_val = df_val_raw[TARGET_COLUMN]

    print("Training model...")
    model = train_model(X_train, y_train, X_val, y_val, lgbm_eval_metric=lgbm_eval_metric)

    val_predictions_transformed_scale = model.predict(X_val)
    
    # Adjust inverse transform based on whether log transform was applied during feature engineering
    if apply_log_transform_target:
        val_predictions_original_scale = np.expm1(val_predictions_transformed_scale)
        y_val_original_scale = np.expm1(y_val)
    else:
        val_predictions_original_scale = val_predictions_transformed_scale
        y_val_original_scale = y_val
    
    val_predictions_original_scale[val_predictions_original_scale < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(y_val_original_scale, val_predictions_original_scale)
    print(f"Validation RMSE for {experiment_name}: {final_validation_rmse:.4f}")
    
    # Clean up memory
    del df_2022_raw, df_train_raw, df_val_raw, X_train, y_train, X_val, y_val, model
    gc.collect()

    return final_validation_rmse

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()

    results = {}

    # --- Baseline ---
    # Represents the current Python solution: Log transform on target, LGBM eval metric 'rmse', validation test size 0.2
    baseline_rmse = run_experiment(
        train_path=args.train_path,
        apply_log_transform_target=True,
        lgbm_eval_metric='rmse',
        validation_test_size=0.2,
        experiment_name="Baseline Model (Current Solution)"
    )
    results["Baseline Model (Current Solution)"] = baseline_rmse

    # --- Ablation 1: No Log Transform on Target ---
    # This feature engineering step has been consistently found detrimental in multiple previous ablation studies
    # (e.g., studies 1, 7, 9, 13, 15, 17, 20, 21), yet it's present in the current solution.
    ablation1_rmse = run_experiment(
        train_path=args.train_path,
        apply_log_transform_target=False,
        lgbm_eval_metric='rmse',
        validation_test_size=0.2,
        experiment_name="Ablation 1: No Log Transform on Target"
    )
    results["Ablation 1: No Log Transform on Target"] = ablation1_rmse

    # --- Ablation 2: Change LGBM eval_metric to 'poisson' ---
    # The model's objective is 'poisson', but the evaluation metric is 'rmse'. Aligning eval_metric with
    # the objective function ('poisson' deviance) might offer more consistent optimization. Study 21 showed a slight improvement.
    ablation2_rmse = run_experiment(
        train_path=args.train_path,
        apply_log_transform_target=True, # Revert log transform to baseline for this ablation
        lgbm_eval_metric='poisson',
        validation_test_size=0.2,
        experiment_name="Ablation 2: Change LGBM eval_metric to 'poisson'"
    )
    results["Ablation 2: Change LGBM eval_metric to 'poisson'"] = ablation2_rmse

    # --- Ablation 3: Increase Validation Split test_size to 0.3 ---
    # Several previous studies (e.g., 14, 17, 20) indicated that increasing the validation split size
    # for the grouped holdout from 0.2 to 0.3 could lead to better overall performance or more robust evaluation.
    ablation3_rmse = run_experiment(
        train_path=args.train_path,
        apply_log_transform_target=True, # Revert log transform to baseline for this ablation
        lgbm_eval_metric='rmse', # Revert eval_metric to baseline for this ablation
        validation_test_size=0.3,
        experiment_name="Ablation 3: Increase Validation Split test_size to 0.3"
    )
    results["Ablation 3: Increase Validation Split test_size to 0.3"] = ablation3_rmse


    # --- Print Summary of Results ---
    print("\n--- Ablation Study Summary ---")
    for name, rmse in results.items():
        print(f"{name}: RMSE = {rmse:.4f}")

    # Determine the most impactful change based on absolute RMSE difference from baseline
    print("\n--- Contribution Analysis ---")

    baseline_rmse = results["Baseline Model (Current Solution)"]
    max_impact_diff = 0
    most_impactful_component = "Baseline (no specific ablation had a larger impact)"
    impact_type_final = "no change" # Default to 'no change' if max_impact_diff remains 0

    # List of ablations to analyze for impact
    ablation_scenarios = [
        ("Ablation 1: No Log Transform on Target", results["Ablation 1: No Log Transform on Target"]),
        ("Ablation 2: Change LGBM eval_metric to 'poisson'", results["Ablation 2: Change LGBM eval_metric to 'poisson'"]),
        ("Ablation 3: Increase Validation Split test_size to 0.3", results["Ablation 3: Increase Validation Split test_size to 0.3"])
    ]

    for name, rmse in ablation_scenarios:
        diff = baseline_rmse - rmse # Positive diff means improvement (lower RMSE), negative means degradation (higher RMSE)
        abs_diff = abs(diff)
        impact_description = "improved" if diff > 0 else ("degraded" if diff < 0 else "had no change on")
        
        print(f"{name}: {impact_description} performance by {abs_diff:.4f} RMSE compared to Baseline.")

        if abs_diff > max_impact_diff:
            max_impact_diff = abs_diff
            most_impactful_component = name
            impact_type_final = "improved" if diff > 0 else "degraded"

    print(f"\nBased on absolute RMSE change from the Baseline, the part of the code that contributes the most to the overall performance (positively or negatively) is: '{most_impactful_component}'. This modification {impact_type_final} the RMSE by {max_impact_diff:.4f}.")
