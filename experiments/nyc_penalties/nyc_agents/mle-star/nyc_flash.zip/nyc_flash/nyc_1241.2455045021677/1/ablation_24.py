

import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc
import copy

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv' # Not used in ablation study

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None,
                       apply_log_transform: bool = True, apply_column_standardization: bool = True) -> tuple[pd.DataFrame, dict]:
    """
    Performs feature engineering on the input DataFrame.
    Includes flags for ablation study.
    """
    if encoder_dict is None:
        encoder_dict = {}

    # Ablation point 3: Remove initial column name standardization
    # We will internally standardize for feature encoding steps to avoid breaking subsequent logic,
    # but the external impact of this initial standardization on the entire DF will be measured.
    df_processed = df.copy() # Work on a copy to preserve original column names if standardization is off

    if apply_column_standardization:
        df_processed.columns = df_processed.columns.str.replace(' ', '_').str.lower()
        street_name_col_for_encoding = STREET_NAME_COL.replace(' ', '_').lower()
        violation_desc_col_for_encoding = VIOLATION_DESC_COL.replace(' ', '_').lower()
        target_col_for_processing = TARGET_COLUMN.replace(' ', '_').lower()
    else:
        # If no global standardization, we still need standardized names for generated features
        # and for consistent internal processing.
        # Ensure 'street_name' and 'violation_description' columns exist for encoding.
        if STREET_NAME_COL in df_processed.columns:
            df_processed[STREET_NAME_COL.replace(' ', '_').lower()] = df_processed[STREET_NAME_COL]
        if VIOLATION_DESC_COL in df_processed.columns:
            df_processed[VIOLATION_DESC_COL.replace(' ', '_').lower()] = df_processed[VIOLATION_DESC_COL]
        # Target column too
        if TARGET_COLUMN in df_processed.columns:
            df_processed[TARGET_COLUMN.replace(' ', '_').lower()] = df_processed[TARGET_COLUMN]

        street_name_col_for_encoding = STREET_NAME_COL.replace(' ', '_').lower()
        violation_desc_col_for_encoding = VIOLATION_DESC_COL.replace(' ', '_').lower()
        target_col_for_processing = TARGET_COLUMN.replace(' ', '_').lower()

    # Handle missing values using the (potentially newly created) standardized internal names
    for col_processed_name in [street_name_col_for_encoding, violation_desc_col_for_encoding]:
        if col_processed_name in df_processed.columns:
            df_processed[col_processed_name] = df_processed[col_processed_name].fillna('unknown').astype(str)

    # Label Encoding for categorical features
    categorical_cols_to_encode = [col for col in [street_name_col_for_encoding, violation_desc_col_for_encoding]
                                  if col in df_processed.columns]
    
    for col in categorical_cols_to_encode:
        if is_training:
            le = LabelEncoder()
            df_processed[col + '_encoded'] = le.fit_transform(df_processed[col])
            encoder_dict[col] = le
        else:
            if col in encoder_dict:
                df_processed[col + '_encoded'] = df_processed[col].map(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else -1)
            else:
                df_processed[col + '_encoded'] = -1

    # Ablation point 1: Log transform target if present
    if target_col_for_processing in df_processed.columns and is_training and apply_log_transform:
        df_processed[target_col_for_processing] = np.log1p(df_processed[target_col_for_processing])

    return df_processed, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None,
                             apply_log_transform: bool = True, apply_column_standardization: bool = True) -> tuple[pd.DataFrame, dict]:
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict,
                                          apply_log_transform=apply_log_transform,
                                          apply_column_standardization=apply_column_standardization)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series,
                use_explicit_categorical_features: bool = True) -> lgb.Booster:
    """
    Trains a LightGBM model.
    """
    # LightGBM expects feature names as strings and sanitized names
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    # Ablation point 2: Remove explicit categorical feature declaration
    categorical_features_names = []
    if use_explicit_categorical_features:
        if 'street_name_encoded' in X_train.columns:
            categorical_features_names.append("street_name_encoded")
        if 'violation_description_encoded' in X_train.columns:
            categorical_features_names.append("violation_description_encoded")

    # LightGBM parameters
    params = {
        'objective': 'poisson',
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 63,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    fit_params = {
        'eval_set': [(X_val, y_val)],
        'eval_metric': 'rmse',
        'callbacks': [lgb.early_stopping(100, verbose=False)],
    }
    if use_explicit_categorical_features and categorical_features_names:
        fit_params['categorical_feature'] = categorical_features_names

    model.fit(X_train, y_train, **fit_params)

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_experiment(name: str,
                   apply_log_transform: bool,
                   use_explicit_categorical_features: bool,
                   apply_column_standardization: bool,
                   train_path: str) -> float:
    """
    Runs a single experiment with specified ablation settings and returns validation RMSE.
    """
    print(f"\n--- Running Experiment: {name} ---")

    df_2022_raw, encoder_dict = load_and_preprocess_data(train_path, is_training=True,
                                                      apply_log_transform=apply_log_transform,
                                                      apply_column_standardization=apply_column_standardization)
    
    # Standardize target column name for consistent access after _engineer_features
    target_col_processed = TARGET_COLUMN.replace(' ', '_').lower()
    street_name_col_internal = STREET_NAME_COL.replace(' ', '_').lower()
    violation_desc_col_internal = VIOLATION_DESC_COL.replace(' ', '_').lower()


    # Split 2022 data for training and validation using the internally consistent column names
    # Group_id relies on these internal names which are either original (if no global standardization)
    # or globally standardized (if global standardization is on).
    df_2022_raw['group_id'] = df_2022_raw[street_name_col_internal] + '_' + \
                               df_2022_raw[violation_desc_col_internal]
    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    # Feature selection: ensure only encoded features are passed to the model
    final_features = []
    if 'street_name_encoded' in df_train_raw.columns:
        final_features.append('street_name_encoded')
    if 'violation_description_encoded' in df_train_raw.columns:
        final_features.append('violation_description_encoded')

    X_train = df_train_raw[final_features]
    y_train = df_train_raw[target_col_processed]

    X_val = df_val_raw[final_features]
    y_val = df_val_raw[target_col_processed]

    print("Training model...")
    model = train_model(X_train, y_train, X_val, y_val,
                        use_explicit_categorical_features=use_explicit_categorical_features)

    val_predictions_log = model.predict(X_val)
    
    # Inverse transform if log transform was applied, otherwise use predictions directly
    if apply_log_transform:
        val_predictions = np.expm1(val_predictions_log)
        y_val_original_scale = np.expm1(y_val) # Inverse transform y_val for RMSE calculation
    else:
        val_predictions = val_predictions_log
        y_val_original_scale = y_val # y_val is already on original scale

    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(y_val_original_scale, val_predictions)
    print(f"Validation RMSE for {name}: {final_validation_rmse:.4f}")
    return final_validation_rmse


def main():
    parser = argparse.ArgumentParser(description="Ablation study for NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()

    results = {}

    # --- Baseline Experiment ---
    results['Baseline'] = run_experiment(
        name="Baseline",
        apply_log_transform=True,
        use_explicit_categorical_features=True,
        apply_column_standardization=True,
        train_path=args.train_path
    )

    # --- Ablation 1: No Log Transform on Target ---
    results['No Log Transform on Target'] = run_experiment(
        name="No Log Transform on Target",
        apply_log_transform=False,
        use_explicit_categorical_features=True,
        apply_column_standardization=True,
        train_path=args.train_path
    )

    # --- Ablation 2: No Explicit Categorical Feature Declaration ---
    results['No Explicit Categorical Feature Declaration'] = run_experiment(
        name="No Explicit Categorical Feature Declaration",
        apply_log_transform=True,
        use_explicit_categorical_features=False,
        apply_column_standardization=True,
        train_path=args.train_path
    )
    
    # --- Ablation 3: No Initial Column Name Standardization ---
    results['No Initial Column Name Standardization'] = run_experiment(
        name="No Initial Column Name Standardization",
        apply_log_transform=True,
        use_explicit_categorical_features=True,
        apply_column_standardization=False,
        train_path=args.train_path
    )

    print("\n--- Ablation Study Results Summary ---")
    for name, rmse in results.items():
        print(f"{name}: Validation RMSE = {rmse:.4f}")

    # Determine most impactful component
    baseline_rmse = results['Baseline']
    impacts = {}
    for name, rmse in results.items():
        if name != 'Baseline':
            diff = rmse - baseline_rmse
            impacts[name] = diff
            print(f"  {name} (vs Baseline): Change in RMSE = {diff:.4f}")
    
    most_impactful_change = None
    max_abs_impact = 0

    if impacts:
        for name, diff in impacts.items():
            if abs(diff) > max_abs_impact:
                max_abs_impact = abs(diff)
                most_impactful_change = name
        
        if most_impactful_change:
            impact_value = impacts[most_impactful_change]
            if impact_value < 0:
                print(f"\nThe part that contributes most positively to the overall performance is the modification: '{most_impactful_change}' (Improved RMSE by {-impact_value:.4f}).")
            else:
                print(f"\nThe part that contributes most negatively to the overall performance is the modification: '{most_impactful_change}' (Degraded RMSE by {impact_value:.4f}).")
        else:
            print("\nNo significant impact observed from any ablation.")
    else:
        print("\nNo ablation experiments were run.")

    gc.collect()

if __name__ == "__main__":
    main()

