
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import catboost as cb
import os
import lightgbm as lgb
import gc

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv'

import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder # Although not used for LOO, kept for potential other uses
import re

# Assume STREET_NAME_COL, VIOLATION_DESC_COL, and TARGET_COLUMN are defined in the global scope
# For example:
# STREET_NAME_COL = "Street Name"
# VIOLATION_DESC_COL = "Violation Description"
# TARGET_COLUMN = "fine_amount" # Assuming a numerical target column exists for LOO encoding


def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Performs feature engineering on the input DataFrame.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Standardize column names for constants as well
    _street_name_col = STREET_NAME_COL.replace(' ', '_').lower()
    _violation_desc_col = VIOLATION_DESC_COL.replace(' ', '_').lower()
    _target_column = TARGET_COLUMN.lower() if TARGET_COLUMN else None # Ensure target is also lowercased if it exists

    # Handle missing values
    for col in [_street_name_col, _violation_desc_col]:
        if col in df.columns:
            # Use a specific string for unknown categories to distinguish from actual 'unknown' values
            df[col] = df[col].fillna('unknown_category_imputed').astype(str)

    # --- Leave-One-Out (LOO) Encoding for specified categorical features ---
    loo_cols = [_street_name_col, _violation_desc_col]
    LOO_NOISE_STD = 0.01 # Small noise to add to imputed values/LOO features for regularization

    if _target_column and _target_column in df.columns: # LOO encoding requires the target column
        global_target_mean = df[_target_column].mean() if is_training else encoder_dict.get('global_target_mean_loo', 0.0)
        if is_training:
            encoder_dict['global_target_mean_loo'] = global_target_mean

        for col in loo_cols:
            if col in df.columns:
                loo_encoded_col_name = col + '_loo_encoded'

                if is_training:
                    # Calculate category statistics (sum of target, count)
                    category_stats = df.groupby(col)[_target_column].agg(['sum', 'count']).reset_index()
                    category_stats.rename(columns={'sum': 'target_sum', 'count': 'category_count'}, inplace=True)
                    category_stats_map = category_stats.set_index(col).to_dict('index')

                    # Store for inference
                    encoder_dict[col + '_loo'] = {
                        'category_stats_map': category_stats_map,
                        'global_target_mean': global_target_mean,
                    }

                    # Apply LOO encoding: (sum_of_targets_in_category - current_target) / (count_in_category - 1)
                    def calculate_loo_mean(row, cat_map):
                        cat = row[col]
                        target_val = row[_target_column]
                        stats = cat_map.get(cat)
                        if stats:
                            cat_sum = stats['target_sum']
                            cat_count = stats['category_count']
                            if cat_count > 1: # Standard LOO calculation
                                return (cat_sum - target_val) / (cat_count - 1)
                            else: # Only one instance, fall back to global mean
                                return global_target_mean
                        return global_target_mean # Fallback for categories not in map (should be handled by fillna)

                    df[loo_encoded_col_name] = df.apply(lambda row: calculate_loo_mean(row, category_stats_map), axis=1)
                    # Add noise for regularization during training
                    df[loo_encoded_col_name] = df[loo_encoded_col_name] + np.random.normal(0, LOO_NOISE_STD, df.shape[0])

                else: # is_training is False (inference)
                    if col + '_loo' in encoder_dict:
                        stored_info = encoder_dict[col + '_loo']
                        category_stats_map = stored_info['category_stats_map']
                        stored_global_target_mean = stored_info['global_target_mean']

                        def transform_loo_mean(cat):
                            stats = category_stats_map.get(cat)
                            if stats:
                                cat_sum = stats['target_sum']
                                cat_count = stats['category_count']
                                if cat_count > 0: # For inference, use the simple category mean
                                    return cat_sum / cat_count
                                else: # Fallback if stats exist but count is zero (edge case)
                                    return stored_global_target_mean + np.random.normal(0, LOO_NOISE_STD)
                            else: # Unknown category in test set (not seen in training)
                                # Impute with global mean + small noise as per plan
                                return stored_global_target_mean + np.random.normal(0, LOO_NOISE_STD)

                        df[loo_encoded_col_name] = df[col].apply(transform_loo_mean)
                    else:
                        # If no encoder is found for the column (e.g., column not present in training data)
                        df[loo_encoded_col_name] = global_target_mean + np.random.normal(0, LOO_NOISE_STD, df.shape[0])
    # --- End of LOO Encoding ---


    # --- Feature Engineering from violation_description ---
    if _violation_desc_col in df.columns:
        # Word count
        df['violation_desc_word_count'] = df[_violation_desc_col].apply(lambda x: len(str(x).split()))

        # Keyword presence (example keywords, this list can be expanded based on data insights)
        keywords = ['parking', 'expired', 'permit', 'zone', 'fire', 'handicapped', 'commercial', 'residential', 'no standing', 'street cleaning']
        for keyword in keywords:
            # Using a regex word boundary to match whole words and prevent partial matches (e.g., 'car' in 'card')
            # and converting to lower case for case-insensitive search
            df[f'violation_desc_has_{keyword.replace(" ", "_")}'] = df[_violation_desc_col].str.contains(r'\b' + re.escape(keyword) + r'\b', case=False, na=False).astype(int)

    # --- Complex Interaction Features ---
    # Using the new LOO encoded features if they exist.
    street_loo_col = _street_name_col + '_loo_encoded'
    violation_loo_col = _violation_desc_col + '_loo_encoded'

    if street_loo_col in df.columns and violation_loo_col in df.columns:
        # Sum interaction
        df['street_violation_loo_sum'] = df[street_loo_col] + df[violation_loo_col]

        # Product interaction (from original plan, but now using LOO encoded features)
        df['street_violation_loo_product'] = df[street_loo_col] * df[violation_loo_col]

        # Polynomial combinations
        df['street_loo_squared'] = df[street_loo_col] ** 2
        df['violation_loo_squared'] = df[violation_loo_col] ** 2
        df['street_x_violation_loo_cubed'] = df[street_loo_col] * (df[violation_loo_col] ** 3)
        df['street_squared_x_violation_loo_squared'] = (df[street_loo_col] ** 2) * (df[violation_loo_col] ** 2)

    # Log transform target if present and training
    # This should be the last step for target transformation if the LOO encoding used the raw target values.
    if TARGET_COLUMN and TARGET_COLUMN.lower() in df.columns and is_training:
        df[TARGET_COLUMN.lower()] = np.log1p(df[TARGET_COLUMN.lower()])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series) -> lgb.Booster:
    """
    Trains a LightGBM model.
    """
    # LightGBM expects feature names as strings
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'regression_l1',  # MAE objective
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 31,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)]) # Use callbacks for early stopping

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional: Path to the 2023 test/evaluation data CSV.')
    args = parser.parse_args()

    print(f"Loading training data from: {args.train_path}")
    df_2022_raw, encoder_dict = load_and_preprocess_data(args.train_path, is_training=True)

    # Split 2022 data for training and validation
    # Use grouped holdout for (street_name, violation_type) pairs
    # Create a unique identifier for splitting
    df_2022_raw['group_id'] = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

    # Get unique groups
    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    # Drop the temporary group_id
    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    # Define features and target
    features = [col for col in df_train_raw.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]]

    # Prepare training data
    X_train = df_train_raw[features]
    y_train = df_train_raw[TARGET_COLUMN]

    # Prepare validation data - CRITICAL FIX HERE: Extract y_val *before* any potential dropping or mismatch
    X_val = df_val_raw[features]
    y_val = df_val_raw[TARGET_COLUMN] # This ensures y_val is correctly assigned from the raw df_val_raw

    print("Training model...")
    model = train_model(X_train, y_train, X_val, y_val)

    # Predict on validation set for performance reporting
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log) # Inverse transform
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(np.expm1(y_val), val_predictions) # Calculate RMSE on original scale
    print(f"Final Validation Performance: {final_validation_rmse}")

    # If a test path is provided, generate predictions
    if args.test_path:
        print(f"Loading test data from: {args.test_path}")
        df_test_raw, _ = load_and_preprocess_data(args.test_path, is_training=False, encoder_dict=encoder_dict)

        # Ensure test data has the same features as training data
        test_features = [col for col in features if col in df_test_raw.columns]
        X_test = df_test_raw[test_features]

        # Align columns - crucial for consistent predictions
        # Add missing columns to X_test with 0, remove extra columns
        missing_cols = set(X_train.columns) - set(X_test.columns)
        for c in missing_cols:
            X_test[c] = 0
        extra_cols = set(X_test.columns) - set(X_train.columns)
        X_test = X_test.drop(columns=list(extra_cols))
        X_test = X_test[X_train.columns] # Ensure column order is the same

        print("Generating predictions for test data...")
        test_predictions_log = model.predict(X_test)
        test_predictions = np.expm1(test_predictions_log) # Inverse transform
        test_predictions[test_predictions < 0] = 0 # Clip negative predictions
        test_predictions = np.round(test_predictions).astype(int) # Round to nearest integer

        # Create submission file
        submission_df = pd.DataFrame({
            STREET_NAME_COL: df_test_raw[STREET_NAME_COL.replace(' ', '_').lower()],
            VIOLATION_DESC_COL: df_test_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()],
            PREDICTED_COUNT_COL: test_predictions
        })
        # Original column names for submission
        submission_df.columns = [STREET_NAME_COL, VIOLATION_DESC_COL, PREDICTED_COUNT_COL]

        submission_df.to_csv(OUTPUT_SUBMISSION_FILE, index=False)
        print(f"Submission file '{OUTPUT_SUBMISSION_FILE}' created successfully.")

        # If test_path contains 'violation_count', calculate RMSE
        if TARGET_COLUMN in df_test_raw.columns:
            y_test_true = np.expm1(df_test_raw[TARGET_COLUMN]) # Inverse log transform for actual values
            test_rmse = calculate_rmse(y_test_true, test_predictions)
            print(f"RMSE on provided test/evaluation data: {test_rmse}")

            # Report unseen key pairs
            train_keys = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]
            test_keys = df_test_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + df_test_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

            unseen_keys_count = test_keys.isin(train_keys).value_counts().get(False, 0)
            total_test_keys = len(test_keys)
            print(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {unseen_keys_count} out of {total_test_keys}")
            print("Unseen pairs are handled by the model's ability to generalize based on encoded features and numerical interaction features, "
                  "and by assigning -1 for unknown categories during Label Encoding transform.")

    gc.collect()

if __name__ == "__main__":
    main()
