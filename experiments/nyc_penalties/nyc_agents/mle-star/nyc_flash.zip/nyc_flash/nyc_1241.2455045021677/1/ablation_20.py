
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv' # Not directly used in ablation, but defined for consistency

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None,
                       apply_log_transform_target: bool = True) -> pd.DataFrame:
    """
    Performs feature engineering on the input DataFrame.
    Added apply_log_transform_target parameter for ablation.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Handle missing values
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Label Encoding for categorical features
    categorical_cols = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col] = le
            else:
                if col in encoder_dict:
                    # Use transform for existing categories, map unknown to -1
                    df[col + '_encoded'] = df[col].map(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else -1)
                else:
                    df[col + '_encoded'] = -1 # Assign a default for entirely new categories if no encoder

    # Log transform target if present, good for count data, and if enabled for the experiment
    if TARGET_COLUMN in df.columns and is_training and apply_log_transform_target:
        df[TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None,
                           apply_log_transform_target: bool = True) -> pd.DataFrame:
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict,
                                          apply_log_transform_target=apply_log_transform_target)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series,
                lgbm_metric: str = 'rmse') -> lgb.Booster:
    """
    Trains a LightGBM model.
    Added lgbm_metric parameter for ablation.
    """
    # LightGBM expects feature names as strings
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'poisson',  # Current solution uses 'poisson'
        'metric': lgbm_metric,   # Ablation point: 'rmse' vs 'poisson'
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 63,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric=lgbm_metric, # Ablation point
              callbacks=[lgb.early_stopping(100, verbose=False)])

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_experiment(description: str,
                   train_path: str,
                   apply_log_transform_target: bool,
                   lgbm_metric: str,
                   stratified_grouped_split: bool) -> float:
    """
    Runs a single experiment with specified configurations and returns validation RMSE.
    """
    df_2022_raw, encoder_dict = load_and_preprocess_data(train_path, is_training=True,
                                                       apply_log_transform_target=apply_log_transform_target)

    # Create a unique identifier for splitting for grouped holdout
    df_2022_raw['group_id'] = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

    # Splitting logic based on ablation parameter
    if stratified_grouped_split:
        # Implement stratified grouped holdout logic based on group frequencies
        group_frequencies = df_2022_raw['group_id'].value_counts()
        unique_groups = group_frequencies.index.tolist()
        stratify_on_frequencies = group_frequencies.loc[unique_groups].values

        # Bin frequencies for stratification
        if len(group_frequencies.unique()) == 1:
            stratify_bins = [0] * len(unique_groups)
        else:
            stratify_bins = pd.qcut(stratify_on_frequencies, q=5, labels=False, duplicates='drop')

        train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42, stratify=stratify_bins)
    else:
        # Original simple grouped holdout
        unique_groups = df_2022_raw['group_id'].unique()
        train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])

    features = [col for col in df_train_raw.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]]

    X_train = df_train_raw[features]
    y_train = df_train_raw[TARGET_COLUMN]
    X_val = df_val_raw[features]
    y_val = df_val_raw[TARGET_COLUMN]

    model = train_model(X_train, y_train, X_val, y_val, lgbm_metric=lgbm_metric)

    val_predictions_log = model.predict(X_val)
    # Inverse transform predictions only if log transform was applied to the target
    val_predictions = np.expm1(val_predictions_log) if apply_log_transform_target else val_predictions_log
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    # Calculate RMSE on original scale. y_val needs inverse transform if it was logged.
    final_validation_rmse = calculate_rmse(np.expm1(y_val) if apply_log_transform_target else y_val, val_predictions)
    gc.collect() # Clean up memory
    return final_validation_rmse

def main_ablation():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()

    results = {}

    # --- Baseline: Original settings from the provided solution ---
    baseline_rmse = run_experiment(
        description="Baseline (Original settings)",
        train_path=args.train_path,
        apply_log_transform_target=True, # Original code applies log transform
        lgbm_metric='rmse',             # Original code uses 'rmse' as eval metric
        stratified_grouped_split=False  # Original code uses simple grouped split
    )
    results["Baseline (Original settings)"] = baseline_rmse

    # --- Ablation 1: Change LGBM Metric to Poisson Deviance ---
    # Aligns the evaluation metric with the 'poisson' objective
    ablation1_rmse = run_experiment(
        description="Ablation 1: LGBM Metric 'poisson'",
        train_path=args.train_path,
        apply_log_transform_target=True,
        lgbm_metric='poisson', # Modified: Use 'poisson' deviance as metric
        stratified_grouped_split=False
    )
    results["Ablation 1: LGBM Metric 'poisson'"] = ablation1_rmse

    # --- Ablation 2: No Log Transform on Target ---
    # Previous studies consistently found log transform to be detrimental. Re-evaluating.
    ablation2_rmse = run_experiment(
        description="Ablation 2: No Log Transform on Target",
        train_path=args.train_path,
        apply_log_transform_target=False, # Modified: Do not apply log transform to target
        lgbm_metric='rmse',
        stratified_grouped_split=False
    )
    results["Ablation 2: No Log Transform on Target"] = ablation2_rmse

    # --- Ablation 3: Stratified Grouped Holdout Split ---
    # This strategy (stratified by group frequency) was planned but not implemented in the baseline.
    ablation3_rmse = run_experiment(
        description="Ablation 3: Stratified Grouped Holdout Split",
        train_path=args.train_path,
        apply_log_transform_target=True,
        lgbm_metric='rmse',
        stratified_grouped_split=True # Modified: Use stratified grouped holdout
    )
    results["Ablation 3: Stratified Grouped Holdout Split"] = ablation3_rmse

    print("--- Ablation Study Results ---")
    
    # Track the best performing configuration among all (including baseline)
    best_overall_rmse = baseline_rmse
    best_overall_config_name = "Baseline (Original settings)"

    for desc, rmse in results.items():
        print(f"  {desc}: Validation RMSE = {rmse:.4f}")
        if rmse < best_overall_rmse:
            best_overall_rmse = rmse
            best_overall_config_name = desc

    print("\n--- Contribution Analysis ---")
    
    # Calculate and print changes relative to baseline
    contributions = {}
    for desc, rmse in results.items():
        if desc == "Baseline (Original settings)":
            continue
        change = baseline_rmse - rmse # Positive value indicates improvement, negative indicates degradation
        contributions[desc] = change
        impact_str = f"improved RMSE by {change:.4f}" if change > 0 else f"degraded RMSE by {-change:.4f}"
        print(f"  {desc} {impact_str}.")

    # Identify the most impactful part based on the largest absolute change
    if contributions:
        most_impactful_part_name = max(contributions, key=lambda k: abs(contributions[k]))
        most_impactful_value = contributions[most_impactful_part_name]

        if most_impactful_value > 0:
            print(f"\nThe part that contributes the most to the overall performance is: {most_impactful_part_name}, which improved RMSE by {most_impactful_value:.4f}.")
        elif most_impactful_value < 0:
            print(f"\nThe part that contributes the most negatively to the overall performance is: {most_impactful_part_name}, which degraded RMSE by {-most_impactful_value:.4f}.")
        else: # Change is zero or negligible
            print("\nNo single part had a significantly measurable impact on performance.")
    else:
        print("\nNo ablations were performed to compare against the baseline.")

if __name__ == "__main__":
    main_ablation()
