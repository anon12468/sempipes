
import pandas as pd
import numpy as np
import argparse
from catboost import CatBoostRegressor, Pool
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import os
import logging
import sys

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def _engineer_features(df, is_training=True, encoder_map=None, global_mean=None):
    """
    Engineers features for the parking violation data.
    Applies smoothed target encoding for 'Street Name' and 'Violation Description'.
    Handles unseen categories for target encoding using a global mean.
    """
    df_copy = df.copy()

    # Rename columns for easier access
    df_copy.rename(columns={'Street Name': 'street_name', 'Violation Description': 'violation_type'}, inplace=True)

    # Feature: Combine street_name and violation_type
    df_copy['street_violation_pair'] = df_copy['street_name'] + '_' + df_copy['violation_type']

    # Smoothed Target Encoding for 'street_name' and 'violation_type'
    # Use a global mean as a fallback for unseen categories during inference
    alpha = 50 # Smoothing factor, adjust as needed

    if is_training:
        encoder_map = {}
        global_mean = df_copy['violation_count'].mean() if 'violation_count' in df_copy.columns else 0
        
        for col in ['street_name', 'violation_type']:
            temp_df = df_copy[[col, 'violation_count']].copy()
            
            # Calculate counts and means for smoothing
            group_means = temp_df.groupby(col)['violation_count'].mean()
            group_counts = temp_df.groupby(col)['violation_count'].count()
            
            # Smoothed mean: (count * mean + alpha * global_mean) / (count + alpha)
            smoothed_means = (group_counts * group_means + alpha * global_mean) / (group_counts + alpha)
            
            encoder_map[col] = smoothed_means.to_dict()
            df_copy[f'{col}_target_encoded'] = df_copy[col].map(encoder_map[col]).fillna(global_mean) # Fillna with global mean for safety
    else:
        if encoder_map is None or global_mean is None:
            raise ValueError("encoder_map and global_mean must be provided for inference.")
        for col in ['street_name', 'violation_type']:
            df_copy[f'{col}_target_encoded'] = df_copy[col].map(encoder_map[col]).fillna(global_mean) # Use global_mean for unseen test categories

    # Interaction feature: product of target encodings
    df_copy['interaction_target_encoded'] = df_copy['street_name_target_encoded'] * df_copy['violation_type_target_encoded']

    # Simple length features
    df_copy['street_name_len'] = df_copy['street_name'].apply(len)
    df_copy['violation_type_len'] = df_copy['violation_type'].apply(len)

    # Convert categorical features to 'category' dtype for CatBoost
    for col in ['street_name', 'violation_type', 'street_violation_pair']:
        if col in df_copy.columns:
            df_copy[col] = df_copy[col].astype('category')

    return df_copy, encoder_map, global_mean

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations for 2023.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional path to the 2023 test/evaluation data CSV.')
    parser.add_argument('--random-seed', type=int, default=42,
                        help='Random seed for reproducibility.')

    args = parser.parse_args()

    np.random.seed(args.random_seed)

    # --- Load Training Data ---
    try:
        logging.info(f"Loading training data from {args.train_path}")
        train_df_raw = pd.read_csv(args.train_path)
        logging.info(f"Training data loaded. Shape: {train_df_raw.shape}")
        logging.info(f"Training data columns: {train_df_raw.columns.tolist()}")
    except FileNotFoundError:
        logging.error(f"Error: Training data file not found at {args.train_path}")
        raise # Re-raise the error to stop execution
    except Exception as e:
        logging.error(f"Error loading training data: {e}")
        raise

    # Ensure required columns are present
    required_cols = ['Street Name', 'Violation Description', 'violation_count']
    if not all(col in train_df_raw.columns for col in required_cols):
        missing_cols = [col for col in required_cols if col not in train_df_raw.columns]
        logging.error(f"Training data missing required columns. Missing: {missing_cols}, Found: {train_df_raw.columns.tolist()}")
        raise ValueError("Training data missing required columns.")

    # --- Prepare Training and Validation Sets ---
    # Use a grouped holdout split to prevent data leakage of key pairs
    train_df_raw['key_pair_for_split'] = train_df_raw['Street Name'] + '_' + train_df_raw['Violation Description']
    unique_key_pairs = train_df_raw['key_pair_for_split'].unique()

    train_keys, val_keys = train_test_split(unique_key_pairs, test_size=0.2, random_state=args.random_seed)

    train_df_split = train_df_raw[train_df_raw['key_pair_for_split'].isin(train_keys)].drop(columns=['key_pair_for_split']).reset_index(drop=True)
    val_df_split = train_df_raw[train_df_raw['key_pair_for_split'].isin(val_keys)].drop(columns=['key_pair_for_split']).reset_index(drop=True)

    logging.info(f"Train split shape: {train_df_split.shape}, Validation split shape: {val_df_split.shape}")

    # --- Feature Engineering for Training ---
    logging.info("Engineering features for training data...")
    train_df_fe, encoder_map, global_mean = _engineer_features(train_df_split, is_training=True)
    logging.info("Engineering features for validation data...")
    val_df_fe, _, _ = _engineer_features(val_df_split, is_training=False, encoder_map=encoder_map, global_mean=global_mean)

    # Define features and target
    target = 'violation_count'
    # Drop original 'Street Name' and 'Violation Description' and temporary 'key_pair_for_split'
    features = [col for col in train_df_fe.columns if col not in ['street_name', 'violation_type', target]]

    # Identify categorical features for CatBoost
    categorical_features_names = [f for f in features if train_df_fe[f].dtype == 'category']
    logging.info(f"Categorical features for CatBoost: {categorical_features_names}")

    X_train = train_df_fe[features]
    y_train = train_df_fe[target]
    X_val = val_df_fe[features]
    y_val = val_df_fe[target]

    # Handle potential NaNs in engineered features (CatBoost can handle NaNs, but explicit imputation can be safer)
    # Filling with a specific value like -1 (if not a valid value in the feature's range) or mean/median
    for col in X_train.select_dtypes(include=np.number).columns:
        if X_train[col].isnull().any():
            X_train[col] = X_train[col].fillna(-1) # Use -1 as a distinct indicator for NaNs
            X_val[col] = X_val[col].fillna(-1)

    # --- CatBoost Model Training ---
    logging.info("Starting CatBoost model training...")
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=args.random_seed,
        verbose=100,
        early_stopping_rounds=50,
        cat_features=categorical_features_names,
        subsample=0.8, # Subsampling to help prevent OOM
        l2_leaf_reg=3, # Default is 3, can be tuned
        thread_count=-1, # Use all available CPU cores
        # Other potential parameters for OOM:
        # grow_policy='Lossguide', # Can be 'SymmetricTree', 'Depthwise', 'Lossguide'
        # max_leaves=64 # For Lossguide, controls number of leaves
    )

    try:
        model.fit(
            X_train, y_train,
            eval_set=(X_val, y_val),
            early_stopping_rounds=50,
            verbose=False # Set to True to see iteration info, otherwise it can be noisy
        )
        logging.info("CatBoost model training complete.")
    except Exception as e:
        logging.error(f"Error during CatBoost model training: {e}")
        raise

    # --- Evaluate on Validation Set ---
    val_predictions = model.predict(X_val)
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions
    validation_rmse = np.sqrt(mean_squared_error(y_val, val_predictions))
    logging.info(f"Validation RMSE: {validation_rmse}")
    print(f'Final Validation Performance: {validation_rmse}')

    # --- Generate Predictions for Test Path (if provided) ---
    if args.test_path:
        logging.info(f"Loading test data from {args.test_path}")
        try:
            test_df_raw = pd.read_csv(args.test_path)
            logging.info(f"Test data loaded. Shape: {test_df_raw.shape}")
        except FileNotFoundError:
            logging.error(f"Error: Test data file not found at {args.test_path}")
            raise # Re-raise the error
        except Exception as e:
            logging.error(f"Error loading test data: {e}")
            raise

        test_df_copy = test_df_raw.copy()
        test_df_copy.rename(columns={'Street Name': 'street_name', 'Violation Description': 'violation_type'}, inplace=True)

        # Check if 'violation_count' exists in test_df_raw (for scoring)
        has_ground_truth = 'violation_count' in test_df_raw.columns
        if has_ground_truth:
            y_test_true = test_df_copy['violation_count'].copy()
            logging.info("Test file contains 'violation_count' column. Will report RMSE for the test set.")
            # Remove violation_count from test_df for feature engineering, it must never be read as a feature.
            test_df_for_fe = test_df_copy.drop(columns=['violation_count'])
        else:
            y_test_true = None
            test_df_for_fe = test_df_copy

        # Feature Engineering for Test Data
        logging.info("Engineering features for test data...")
        test_df_fe, _, _ = _engineer_features(test_df_for_fe, is_training=False, encoder_map=encoder_map, global_mean=global_mean)

        # Ensure consistent feature columns and order with training data
        X_test = test_df_fe[features]
        for col in X_test.select_dtypes(include=np.number).columns:
            if X_test[col].isnull().any():
                X_test[col] = X_test[col].fillna(-1) # Apply same NaN handling as training

        # Ensure categorical features are of 'category' dtype
        for col in categorical_features_names:
            if col in X_test.columns and X_test[col].dtype != 'category':
                X_test[col] = X_test[col].astype('category')
        
        # Identify unseen key pairs in test set
        train_key_pairs = set(train_df_split['Street Name'] + '_' + train_df_split['Violation Description'])
        test_key_pairs = set(test_df_copy['street_name'] + '_' + test_df_copy['violation_type'])
        unseen_key_pairs_count = len(test_key_pairs - train_key_pairs)
        logging.info(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_key_pairs_count}. "
                     "These are handled by target encoding's global mean fallback and CatBoost's internal handling of unseen categories.")

        # Predict
        logging.info("Generating predictions for test data...")
        test_predictions = model.predict(X_test)
        test_predictions[test_predictions < 0] = 0 # Clip negative predictions
        test_predictions = np.round(test_predictions).astype(int) # Round and convert to int for counts

        # Create submission file
        submission_df = pd.DataFrame({
            'street_name': test_df_copy['street_name'],
            'violation_type': test_df_copy['violation_type'],
            'predicted_count': test_predictions
        })
        submission_df.to_csv('submission.csv', index=False)
        logging.info("Submission file 'submission.csv' created.")

        # Report RMSE if ground truth is available
        if has_ground_truth:
            test_rmse = np.sqrt(mean_squared_error(y_test_true, test_predictions))
            logging.info(f"RMSE on test file: {test_rmse}")

    else:
        logging.info("No test-path provided. Skipping test prediction and submission file generation.")

if __name__ == "__main__":
    main()
