
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc
import os

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv'

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> tuple[pd.DataFrame, dict]:
    """
    Performs feature engineering on the input DataFrame.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Handle missing values
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Label Encoding for categorical features
    categorical_cols = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col] = le
            else:
                if col in encoder_dict:
                    # Use transform for existing categories, map unknown to -1
                    # Ensure all new values are handled. Using pd.Series.map can be more robust here.
                    df[col + '_encoded'] = df[col].map(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else -1)
                else:
                    df[col + '_encoded'] = -1 # Assign a default for entirely new categories if no encoder

    # Log transform target if present, good for count data
    if TARGET_COLUMN in df.columns and is_training:
        df[TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None) -> tuple[pd.DataFrame, dict]:
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series, model_params: dict) -> lgb.Booster:
    """
    Trains a LightGBM model with given parameters.
    """
    # LightGBM expects feature names as strings
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    model = lgb.LGBMRegressor(**model_params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)])

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray, round_preds: bool = False) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    if round_preds:
        y_pred = np.round(y_pred)
    # Ensure y_pred does not have negative values, as actual counts are non-negative
    y_pred[y_pred < 0] = 0
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_experiment(train_path: str,
                   bagging_freq_val: int = 1,
                   exclude_violation_desc_encoded: bool = False,
                   round_val_preds_for_rmse: bool = False,
                   test_path: str = None) -> float:

    df_2022_raw, encoder_dict = load_and_preprocess_data(train_path, is_training=True)

    # Split 2022 data for training and validation using grouped holdout
    df_2022_raw['group_id'] = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])

    # Define features based on ablation configuration
    # Exclude target, original string columns
    features = [col for col in df_train_raw.columns if col not in [
        TARGET_COLUMN.lower(), # Target column name needs to be lowercased as well
        STREET_NAME_COL.replace(' ', '_').lower(),
        VIOLATION_DESC_COL.replace(' ', '_').lower(),
        'group_id' # Exclude group_id if it wasn't dropped
    ]]

    # Ablation point 2: Remove 'violation_description_encoded' feature
    if exclude_violation_desc_encoded and 'violation_description_encoded' in features:
        features.remove('violation_description_encoded')

    X_train = df_train_raw[features]
    y_train = df_train_raw[TARGET_COLUMN.lower()] # Target column name needs to be lowercased as well

    X_val = df_val_raw[features]
    y_val = df_val_raw[TARGET_COLUMN.lower()] # Target column name needs to be lowercased as well

    # Model parameters for this run, incorporating ablation changes
    model_params = {
        'objective': 'poisson',
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': bagging_freq_val, # Ablation point 1
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 63,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = train_model(X_train, y_train, X_val, y_val, model_params)

    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log)

    # Calculate RMSE on original scale
    # Ablation point 3: Round validation predictions before RMSE calculation
    final_validation_rmse = calculate_rmse(np.expm1(y_val), val_predictions, round_preds=round_val_preds_for_rmse)

    print(f"Final Validation Performance: {final_validation_rmse}")

    # If test_path is provided, generate predictions
    if test_path:
        df_test_raw, _ = load_and_preprocess_data(test_path, is_training=False, encoder_dict=encoder_dict)
        
        # Store original keys for submission
        submission_keys = df_test_raw[[STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]].copy()

        # Count unseen pairs
        train_keys = set(df_2022_raw['group_id'].unique())
        test_keys_raw = df_test_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                        df_test_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]
        unseen_pairs_count = len(set(test_keys_raw) - train_keys)
        print(f"Number of unseen (street_name, violation_type) pairs in the test set: {unseen_pairs_count}")

        # Align test features with training features
        X_test = df_test_raw[features]
        X_test.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_test.columns]

        test_predictions_log = model.predict(X_test)
        test_predictions = np.expm1(test_predictions_log)
        test_predictions[test_predictions < 0] = 0 # Ensure non-negative predictions
        test_predictions = np.round(test_predictions).astype(int) # Round and convert to int for count data

        submission_df = pd.DataFrame({
            'street_name': submission_keys[STREET_NAME_COL.replace(' ', '_').lower()],
            'violation_type': submission_keys[VIOLATION_DESC_COL.replace(' ', '_').lower()],
            PREDICTED_COUNT_COL: test_predictions
        })
        submission_df.to_csv(OUTPUT_SUBMISSION_FILE, index=False)
        print(f"Predictions saved to {OUTPUT_SUBMISSION_FILE}")

        # If violation_count is present in test_path, calculate and report RMSE
        if TARGET_COLUMN.lower() in df_test_raw.columns:
            y_test_true = np.expm1(df_test_raw[TARGET_COLUMN.lower()]) # Inverse log transform true values
            test_rmse = calculate_rmse(y_test_true, test_predictions, round_preds=False) # Predictions are already rounded
            print(f"RMSE on provided test/eval dataset: {test_rmse:.4f}")

    gc.collect()
    return final_validation_rmse

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Perform ablation study on NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional path to a test/evaluation data CSV for generating predictions.')
    args = parser.parse_args()

    # --- Baseline Run ---
    baseline_description = "Baseline model (original configuration)"
    baseline_rmse = run_experiment(args.train_path)
    print(f"{baseline_description}: {baseline_rmse:.4f}")

    # --- Ablation 1: Disable Bagging (bagging_freq = 0) ---
    ablation1_description = "Ablation: Disable Bagging (bagging_freq=0)"
    ablation1_rmse = run_experiment(args.train_path, bagging_freq_val=0)
    print(f"{ablation1_description}: {ablation1_rmse:.4f} (Change vs. Baseline: {ablation1_rmse - baseline_rmse:.4f})")

    # --- Ablation 2: Remove 'violation_description_encoded' feature ---
    ablation2_description = "Ablation: Remove 'violation_description_encoded' feature"
    ablation2_rmse = run_experiment(args.train_path, exclude_violation_desc_encoded=True)
    print(f"{ablation2_description}: {ablation2_rmse:.4f} (Change vs. Baseline: {ablation2_rmse - baseline_rmse:.4f})")

    # --- Ablation 3: Round validation predictions before RMSE calculation ---
    ablation3_description = "Ablation: Round validation predictions for RMSE"
    ablation3_rmse = run_experiment(args.train_path, round_val_preds_for_rmse=True)
    # Fixed typo: abblation3_rmse -> ablation3_rmse
    print(f"{ablation3_description}: {ablation3_rmse:.4f} (Change vs. Baseline: {ablation3_rmse - baseline_rmse:.4f})")

    # --- Determine most impactful component ---
    impacts = {
        ablation1_description: ablation1_rmse - baseline_rmse,
        ablation2_description: ablation2_rmse - baseline_rmse,
        ablation3_description: ablation3_rmse - baseline_rmse
    }

    if impacts:
        # Find the component with the largest absolute change (positive or negative)
        most_impactful_component_name = max(impacts, key=lambda k: abs(impacts[k]))
        most_impactful_change_value = impacts[most_impactful_component_name]

        impact_type = "improved" if most_impactful_change_value < 0 else "degraded"

        print(f"The part that contributes the most to the overall performance is related to '{most_impactful_component_name}'. "
              f"Its modification {impact_type} RMSE by {abs(most_impactful_change_value):.4f}.")
    else:
        print("No impactful changes were observed in this ablation study.")

    # Run with the provided test-path if available
    if args.test_path:
        print(f"\n--- Generating predictions for {args.test_path} ---")
        # Use the baseline configuration for final predictions
        run_experiment(args.train_path, test_path=args.test_path)
