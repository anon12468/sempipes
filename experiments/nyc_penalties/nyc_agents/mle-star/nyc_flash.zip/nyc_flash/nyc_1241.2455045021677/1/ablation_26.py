
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc
import argparse
import os

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None,
                       log_transform_target_flag: bool = True,
                       categorical_as_category_dtype: bool = False) -> (pd.DataFrame, dict):
    """
    Performs feature engineering on the input DataFrame.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Handle missing values
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Categorical feature handling
    categorical_cols_original = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]

    if categorical_as_category_dtype:
        for col in categorical_cols_original:
            if col in df.columns:
                df[col] = df[col].astype('category')
        # No explicit _encoded columns are created. The original category columns will be used directly.
    else:
        # Label Encoding for categorical features (original behavior)
        for col in categorical_cols_original:
            if col in df.columns:
                if is_training:
                    le = LabelEncoder()
                    df[col + '_encoded'] = le.fit_transform(df[col])
                    encoder_dict[col] = le
                else:
                    if col in encoder_dict:
                        # Use transform for existing categories, map unknown to -1
                        # Handle cases where the test set might have categories not seen in training
                        df[col + '_encoded'] = df[col].map(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else -1)
                    else:
                        df[col + '_encoded'] = -1 # Assign a default for entirely new categories if no encoder

    # Log transform target if present, good for count data
    if TARGET_COLUMN.lower() in df.columns and is_training and log_transform_target_flag:
        df[TARGET_COLUMN.lower()] = np.log1p(df[TARGET_COLUMN.lower()])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None,
                             log_transform_target_flag: bool = True,
                             categorical_as_category_dtype: bool = False) -> (pd.DataFrame, dict):
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict,
                                          log_transform_target_flag=log_transform_target_flag,
                                          categorical_as_category_dtype=categorical_as_category_dtype)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series,
                l1_reg: float, l2_reg: float,
                categorical_as_category_dtype: bool) -> lgb.Booster:
    """
    Trains a LightGBM model.
    """
    # LightGBM expects feature names as strings and sanitized names
    # Create a copy to avoid modifying the original DataFrame columns directly if they are used elsewhere
    X_train_sanitized = X_train.copy()
    X_val_sanitized = X_val.copy()

    original_train_cols_before_sanitization = X_train_sanitized.columns # Store original column names for categorical feature mapping
    X_train_sanitized.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train_sanitized.columns]
    X_val_sanitized.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val_sanitized.columns]

    categorical_features_names = []
    street_name_col_sanitized = "".join (c if c.isalnum() else "_" for c in STREET_NAME_COL.replace(' ', '_').lower())
    violation_desc_col_sanitized = "".join (c if c.isalnum() else "_" for c in VIOLATION_DESC_COL.replace(' ', '_').lower())

    if categorical_as_category_dtype:
        # If using pd.Categorical, LightGBM can auto-detect from dtype, but explicit declaration can be safer.
        # Use sanitized original column names for explicit declaration.
        if street_name_col_sanitized in X_train_sanitized.columns:
            categorical_features_names.append(street_name_col_sanitized)
        if violation_desc_col_sanitized in X_train_sanitized.columns:
            categorical_features_names.append(violation_desc_col_sanitized)
    else:
        # If using LabelEncoder, declare the _encoded column names.
        if 'street_name_encoded' in original_train_cols_before_sanitization.values:
            categorical_features_names.append("street_name_encoded")
        if 'violation_description_encoded' in original_train_cols_before_sanitization.values:
            categorical_features_names.append("violation_description_encoded")

    # LightGBM parameters
    params = {
        'objective': 'poisson', # Suitable for count data
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': l1_reg,
        'lambda_l2': l2_reg,
        'num_leaves': 63,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train_sanitized, y_train,
              eval_set=[(X_val_sanitized, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)], # Use callbacks for early stopping
              categorical_feature=categorical_features_names) # Explicitly declare categorical features

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    # Ensure y_pred is not negative before calculation
    y_pred[y_pred < 0] = 0
    return np.sqrt(mean_squared_error(y_true, y_pred))

# Helper to encapsulate a scenario run
def run_scenario(scenario_name: str,
                 log_transform_target_flag: bool,
                 categorical_as_category_dtype: bool,
                 l1_reg: float, l2_reg: float,
                 train_path: str,
                 test_path: str = None) -> float:
    print(f"\n--- Running Scenario: {scenario_name} ---")

    df_2022_raw, encoder_dict = load_and_preprocess_data(
        train_path,
        is_training=True,
        log_transform_target_flag=log_transform_target_flag,
        categorical_as_category_dtype=categorical_as_category_dtype
    )

    # Split 2022 data for training and validation (grouped holdout)
    street_name_col_lower = STREET_NAME_COL.replace(' ', '_').lower()
    violation_desc_col_lower = VIOLATION_DESC_COL.replace(' ', '_').lower()
    target_col_lower = TARGET_COLUMN.lower()

    # FIX: Convert categorical columns to string type before concatenation for 'group_id'
    df_2022_raw['group_id'] = df_2022_raw[street_name_col_lower].astype(str) + '_' + \
                               df_2022_raw[violation_desc_col_lower].astype(str)

    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])

    # Define features and target
    features_to_exclude_from_base = [target_col_lower, 'group_id'] # Always exclude target and temp group_id
    if not categorical_as_category_dtype:
        # If using LabelEncoder, also exclude the original string columns as they are replaced by _encoded
        features_to_exclude_from_base.extend([street_name_col_lower, violation_desc_col_lower])
    
    features = [col for col in df_train_raw.columns if col not in features_to_exclude_from_base]

    X_train = df_train_raw[features]
    X_val = df_val_raw[features]

    # Separate target variable
    y_train = df_train_raw[target_col_lower]
    # y_val for final RMSE calculation must be on original scale.
    # y_val for LightGBM eval_set should match the scale of y_train.
    y_val_original_scale = df_val_raw[target_col_lower].copy() # Original scale before any log transform
    if log_transform_target_flag:
        y_val_for_eval = np.log1p(y_val_original_scale.copy()) # Log transform for eval_set if training with log transform
    else:
        y_val_for_eval = y_val_original_scale.copy() # Use original scale for eval_set if training without log transform

    print("Training model...")
    model = train_model(X_train, y_train, X_val, y_val_for_eval,
                        l1_reg=l1_reg, l2_reg=l2_reg,
                        categorical_as_category_dtype=categorical_as_category_dtype)

    val_predictions_raw = model.predict(X_val)
    # Inverse transform predictions if target was log transformed
    val_predictions = np.expm1(val_predictions_raw) if log_transform_target_flag else val_predictions_raw
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions
    val_predictions = np.round(val_predictions).astype(int) # Round to nearest integer

    final_validation_rmse = calculate_rmse(y_val_original_scale, val_predictions)
    print(f"Validation RMSE for {scenario_name}: {final_validation_rmse}")
    print(f"Final Validation Performance: {final_validation_rmse}") # Required output line
    gc.collect() # Clean up memory

    if test_path:
        print(f"Generating predictions for test file: {test_path}")
        df_test_raw, _ = load_and_preprocess_data(
            test_path,
            is_training=False,
            encoder_dict=encoder_dict, # Use encoders from training
            log_transform_target_flag=False, # Test data target is not transformed for prediction
            categorical_as_category_dtype=categorical_as_category_dtype
        )

        # Ensure test features match training features
        # Filter out columns that are not in the training set and vice-versa
        test_features_to_predict = [col for col in features if col in df_test_raw.columns]
        X_test = df_test_raw[test_features_to_predict]

        # Handle columns present in training but not in test by adding them with default values
        for col in features:
            if col not in X_test.columns:
                print(f"Warning: Feature '{col}' from training data not found in test data. Adding with default 0.")
                X_test[col] = 0 # Or other suitable default/imputation

        # Ensure order of columns is same as training
        X_test = X_test[features]

        # Sanitize test column names for prediction
        X_test.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_test.columns]

        test_predictions_raw = model.predict(X_test)
        test_predictions = np.expm1(test_predictions_raw) if log_transform_target_flag else test_predictions_raw
        test_predictions[test_predictions < 0] = 0
        test_predictions = np.round(test_predictions).astype(int)

        # Create submission file
        submission_df = pd.DataFrame({
            STREET_NAME_COL: df_test_raw[street_name_col_lower],
            VIOLATION_DESC_COL: df_test_raw[violation_desc_col_lower],
            'predicted_count': test_predictions
        })
        submission_df.to_csv('submission.csv', index=False)
        print("Submission file 'submission.csv' created.")

        # If violation_count is present in the test file, calculate test RMSE
        if target_col_lower in df_test_raw.columns:
            y_test_true = df_test_raw[target_col_lower]
            test_rmse = calculate_rmse(y_test_true, test_predictions)
            print(f"Test RMSE (on provided ground truth): {test_rmse}")
            return final_validation_rmse, test_rmse # Return both validation and test RMSE
        return final_validation_rmse, None # Return validation RMSE and None for test if no ground truth
    
    return final_validation_rmse, None


def ablation_runner(train_path: str, test_path: str = None):
    results = {}
    test_rmses = {}

    # Scenario 1: Baseline (Original Solution)
    val_rmse_baseline, test_rmse_baseline = run_scenario(
        "Baseline (Original)",
        log_transform_target_flag=True,
        categorical_as_category_dtype=False,
        l1_reg=0.1, l2_reg=0.1,
        train_path=train_path,
        test_path=test_path
    )
    results['Baseline (Original)'] = val_rmse_baseline
    if test_rmse_baseline is not None:
        test_rmses['Baseline (Original)'] = test_rmse_baseline

    # Scenario 2: Ablation - No Log Transform on Target
    val_rmse_no_log, test_rmse_no_log = run_scenario(
        "Ablation 1: No Log Transform on Target",
        log_transform_target_flag=False,
        categorical_as_category_dtype=False,
        l1_reg=0.1, l2_reg=0.1,
        train_path=train_path,
        test_path=test_path
    )
    results['Ablation 1: No Log Transform on Target'] = val_rmse_no_log
    if test_rmse_no_log is not None:
        test_rmses['Ablation 1: No Log Transform on Target'] = test_rmse_no_log


    # Scenario 3: Ablation - Categorical Features as pd.Categorical type
    val_rmse_categorical_dtype, test_rmse_categorical_dtype = run_scenario(
        "Ablation 2: Categorical as pd.Categorical",
        log_transform_target_flag=True, # Keep other parameters as baseline for this ablation
        categorical_as_category_dtype=True,
        l1_reg=0.1, l2_reg=0.1,
        train_path=train_path,
        test_path=test_path
    )
    results['Ablation 2: Categorical as pd.Categorical'] = val_rmse_categorical_dtype
    if test_rmse_categorical_dtype is not None:
        test_rmses['Ablation 2: Categorical as pd.Categorical'] = test_rmse_categorical_dtype

    # Scenario 4: Ablation - No L1/L2 Regularization
    val_rmse_no_reg, test_rmse_no_reg = run_scenario(
        "Ablation 3: No L1/L2 Regularization",
        log_transform_target_flag=True, # Keep other parameters as baseline for this ablation
        categorical_as_category_dtype=False,
        l1_reg=0.0, l2_reg=0.0,
        train_path=train_path,
        test_path=test_path
    )
    results['Ablation 3: No L1/L2 Regularization'] = val_rmse_no_reg
    if test_rmse_no_reg is not None:
        test_rmses['Ablation 3: No L1/L2 Regularization'] = test_rmse_no_reg


    print("\n--- Ablation Study Summary (Validation RMSE) ---")
    
    baseline_rmse = results['Baseline (Original)']
    print(f"Baseline (Original) RMSE: {baseline_rmse:.4f}")

    best_improvement_magnitude = 0.0
    most_impactful_component = "N/A"
    
    for scenario_name, rmse in results.items():
        if scenario_name == 'Baseline (Original)':
            continue
        
        diff = baseline_rmse - rmse # Positive means improvement, negative means degradation
        print(f"{scenario_name} RMSE: {rmse:.4f} (Change vs Baseline: {diff:+.4f})")
        
        # We are looking for the component that had the largest absolute impact on RMSE.
        if abs(diff) > best_improvement_magnitude:
            best_improvement_magnitude = abs(diff)
            most_impactful_component = scenario_name

    print("\n--- Conclusion on Most Impactful Component (Validation) ---")
    if most_impactful_component == "N/A" or best_improvement_magnitude == 0.0:
        print("No significant impact observed from any ablation.")
    else:
        # Determine if the most impactful change was an improvement or degradation
        diff_of_most_impactful = baseline_rmse - results[most_impactful_component]
        if diff_of_most_impactful > 0:
            print(f"The modification '{most_impactful_component}' provided the largest improvement in performance (RMSE reduced by {diff_of_most_impactful:.4f}).")
            print("This suggests that the original component or setting being modified was detrimental to the model's performance.")
        else: # diff_of_most_impactful < 0
            print(f"The modification '{most_impactful_component}' caused the largest degradation in performance (RMSE increased by {-diff_of_most_impactful:.4f}).")
            print("This suggests that the original component or setting being modified was highly beneficial to the model's performance.")

    if test_rmses:
        print("\n--- Ablation Study Summary (Test RMSE) ---")
        baseline_test_rmse = test_rmses['Baseline (Original)']
        print(f"Baseline (Original) Test RMSE: {baseline_test_rmse:.4f}")
        for scenario_name, rmse in test_rmses.items():
            if scenario_name == 'Baseline (Original)':
                continue
            diff = baseline_test_rmse - rmse
            print(f"{scenario_name} Test RMSE: {rmse:.4f} (Change vs Baseline: {diff:+.4f})")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="NYC Parking Violation Prediction Model")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the training data CSV file.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional: Path to the test data CSV file for predictions and evaluation.')
    
    args = parser.parse_args()

    # Create the input directory if it doesn't exist (for local testing without actual files)
    if not os.path.exists('./input') and not os.path.exists(args.train_path):
        print("Creating dummy input file for demonstration purposes.")
        os.makedirs('./input', exist_ok=True)
        dummy_data = {
            'Street Name': ['100 MAIN ST', '100 MAIN ST', '200 BROADWAY', '200 BROADWAY', '300 OAK AVE', '100 MAIN ST'],
            'Violation Description': ['NO PARKING', 'DOUBLE PARKING', 'NO STANDING', 'OVERTIME PARKING', 'NO PARKING', 'METER EXPIRED'],
            'Violation Count': [100, 50, 75, 20, 120, 30]
        }
        pd.DataFrame(dummy_data).to_csv(args.train_path, index=False)
        if args.test_path:
            # Create a dummy test file as well if test_path is provided but no file exists
            dummy_test_data = {
                'Street Name': ['100 MAIN ST', '200 BROADWAY', '400 PINE RD', '100 MAIN ST'],
                'Violation Description': ['NO PARKING', 'NO STANDING', 'NO PARKING', 'TRUCK LOADING ZONE'],
                'Violation Count': [110, 80, 50, 40] # Optional ground truth for test
            }
            pd.DataFrame(dummy_test_data).to_csv(args.test_path, index=False)
            print(f"Dummy test file created at {args.test_path}")

    ablation_runner(args.train_path, args.test_path)
