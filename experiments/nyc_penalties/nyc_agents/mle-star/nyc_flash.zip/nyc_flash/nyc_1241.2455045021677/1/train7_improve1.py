
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, KFold
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc
import os

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv'
N_SPLITS = 5 # Number of folds for K-Fold Target Encoding

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> (pd.DataFrame, dict):
    """
    Performs feature engineering on the input DataFrame.
    """
    if encoder_dict is None:
        encoder_dict = {}
    if 'label_encoders' not in encoder_dict:
        encoder_dict['label_encoders'] = {}
    if 'freq_maps' not in encoder_dict:
        encoder_dict['freq_maps'] = {}
    if 'target_encode_maps' not in encoder_dict:
        encoder_dict['target_encode_maps'] = {}
    if 'global_target_mean' not in encoder_dict:
        encoder_dict['global_target_mean'] = None

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Standardized column names for convenience
    street_name_col_std = STREET_NAME_COL.replace(' ', '_').lower()
    violation_desc_col_std = VIOLATION_DESC_COL.replace(' ', '_').lower()
    # Check if TARGET_COLUMN exists in df.columns before standardizing it
    # It might not be present in a test set without violation_count
    target_column_std = None
    if TARGET_COLUMN.replace(' ', '_').lower() in df.columns:
        target_column_std = TARGET_COLUMN.replace(' ', '_').lower()

    # Handle missing values
    for col in [street_name_col_std, violation_desc_col_std]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # --- Frequency Encoding ---
    freq_cols = [street_name_col_std, violation_desc_col_std]
    for col in freq_cols:
        if col in df.columns:
            freq_col_name = col + '_freq_encoded'
            if is_training:
                freq_map = df[col].value_counts(normalize=True).to_dict()
                df[freq_col_name] = df[col].map(freq_map).fillna(0.0) # Fill unseen in training with 0.0
                encoder_dict['freq_maps'][col] = freq_map
            else:
                if col in encoder_dict['freq_maps']:
                    freq_map = encoder_dict['freq_maps'][col]
                    df[freq_col_name] = df[col].map(freq_map).fillna(0.0) # Fill unseen in test with 0.0
                else:
                    df[freq_col_name] = 0.0 # Default to 0.0 if no freq map was trained

    # --- Label Encoding for categorical features ---
    categorical_cols = [street_name_col_std, violation_desc_col_std]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict['label_encoders'][col] = le
            else:
                if col in encoder_dict['label_encoders']:
                    le = encoder_dict['label_encoders'][col]
                    # Map unseen categories to -1
                    # Ensure all classes are strings for consistency
                    known_classes = set(le.classes_)
                    df[col + '_encoded'] = df[col].apply(lambda s: le.transform([s])[0] if str(s) in known_classes else -1)
                else:
                    df[col + '_encoded'] = -1 # Assign default if no encoder was trained

    # --- K-Fold Target Encoding for street_violation_pair ---
    pair_col_name = 'street_violation_pair'
    target_encoded_col_name = 'street_violation_pair_target_encoded'

    if street_name_col_std in df.columns and violation_desc_col_std in df.columns:
        df[pair_col_name] = df[street_name_col_std].astype(str) + '_' + df[violation_desc_col_std].astype(str)

        if is_training and target_column_std and target_column_std in df.columns:
            kf = KFold(n_splits=N_SPLITS, shuffle=True, random_state=42)
            df[target_encoded_col_name] = np.nan # Initialize with NaN

            global_target_mean = df[target_column_std].mean()
            encoder_dict['global_target_mean'] = global_target_mean

            for fold, (train_idx, val_idx) in enumerate(kf.split(df)):
                X_train_fold = df.loc[train_idx]
                X_val_fold_pairs = df.loc[val_idx, pair_col_name]

                # Calculate target mean on out-of-fold data (X_train_fold)
                mean_map = X_train_fold.groupby(pair_col_name)[target_column_std].mean()

                # Apply to in-fold data (val_idx), filling NaNs with the global mean
                df.loc[val_idx, target_encoded_col_name] = X_val_fold_pairs.map(mean_map).fillna(global_target_mean)

            # Store the overall target mean for each pair from the full training set
            # This is used for the test set
            encoder_dict['target_encode_maps'][pair_col_name] = df.groupby(pair_col_name)[target_column_std].mean().to_dict()

        elif not is_training:
            if pair_col_name in encoder_dict['target_encode_maps'] and encoder_dict['global_target_mean'] is not None:
                mean_map = encoder_dict['target_encode_maps'][pair_col_name]
                global_target_mean = encoder_dict['global_target_mean']
                df[target_encoded_col_name] = df[pair_col_name].map(mean_map).fillna(global_target_mean)
            else:
                # Fallback if no target encoding was trained or global mean is missing
                df[target_encoded_col_name] = encoder_dict['global_target_mean'] if encoder_dict['global_target_mean'] is not None else 0.0

    # Log transform target if present, good for count data
    if target_column_std and target_column_std in df.columns and is_training:
        df[target_column_std] = np.log1p(df[target_column_std])

    # Optionally drop the temporary 'street_violation_pair' column
    if pair_col_name in df.columns:
        df = df.drop(columns=[pair_col_name])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None) -> (pd.DataFrame, dict):
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series) -> lgb.Booster:
    """
    Trains a LightGBM model.
    """
    # LightGBM expects feature names as strings
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'regression_l1',  # MAE objective
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 31,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)]) # Use callbacks for early stopping

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional: Path to the 2023 test/evaluation data CSV.')
    args = parser.parse_args()

    print(f"Loading training data from: {args.train_path}")
    df_2022_raw, encoder_dict = load_and_preprocess_data(args.train_path, is_training=True)

    # Split 2022 data for training and validation
    # Use grouped holdout for (street_name, violation_type) pairs
    # Create a unique identifier for splitting
    street_name_col_std = STREET_NAME_COL.replace(' ', '_').lower()
    violation_desc_col_std = VIOLATION_DESC_COL.replace(' ', '_').lower()
    target_column_std = TARGET_COLUMN.replace(' ', '_').lower()

    df_2022_raw['group_id'] = df_2022_raw[street_name_col_std].astype(str) + '_' + \
                               df_2022_raw[violation_desc_col_std].astype(str)

    # Get unique groups
    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    # Drop the temporary group_id
    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])

    # Define features and target
    # Ensure TARGET_COLUMN is correctly referenced as its standardized name
    features = [col for col in df_train_raw.columns if col not in [target_column_std, street_name_col_std, violation_desc_col_std]]

    # Prepare training data
    X_train = df_train_raw[features]
    y_train = df_train_raw[target_column_std]

    # Prepare validation data
    X_val = df_val_raw[features]
    y_val = df_val_raw[target_column_std] # This ensures y_val is correctly assigned from the raw df_val_raw

    print("Training model...")
    model = train_model(X_train, y_train, X_val, y_val)

    # Predict on validation set for performance reporting
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log) # Inverse transform
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(np.expm1(y_val), val_predictions) # Calculate RMSE on original scale
    print(f"Final Validation Performance: {final_validation_rmse}")

    # If a test path is provided, generate predictions
    if args.test_path:
        print(f"Loading test data from: {args.test_path}")
        df_test_raw, _ = load_and_preprocess_data(args.test_path, is_training=False, encoder_dict=encoder_dict)

        # Ensure test data has the same features as training data
        test_features = [col for col in features if col in df_test_raw.columns]
        X_test = df_test_raw[test_features]

        # Align columns - crucial for consistent predictions
        # Add missing columns to X_test with 0, remove extra columns
        missing_cols = set(X_train.columns) - set(X_test.columns)
        for c in missing_cols:
            X_test[c] = 0
        extra_cols = set(X_test.columns) - set(X_train.columns)
        X_test = X_test.drop(columns=list(extra_cols))
        X_test = X_test[X_train.columns] # Ensure column order is the same

        print("Generating predictions for test data...")
        test_predictions_log = model.predict(X_test)
        test_predictions = np.expm1(test_predictions_log) # Inverse transform
        test_predictions[test_predictions < 0] = 0 # Clip negative predictions
        test_predictions = np.round(test_predictions).astype(int) # Round to nearest integer

        # Create submission file
        submission_df = pd.DataFrame({
            STREET_NAME_COL: df_test_raw[street_name_col_std],
            VIOLATION_DESC_COL: df_test_raw[violation_desc_col_std],
            PREDICTED_COUNT_COL: test_predictions
        })
        # Original column names for submission
        submission_df.columns = [STREET_NAME_COL, VIOLATION_DESC_COL, PREDICTED_COUNT_COL]

        submission_df.to_csv(OUTPUT_SUBMISSION_FILE, index=False)
        print(f"Submission file '{OUTPUT_SUBMISSION_FILE}' created successfully.")

        # If test_path contains 'violation_count', calculate RMSE
        if target_column_std in df_test_raw.columns:
            y_test_true = np.expm1(df_test_raw[target_column_std]) # Inverse log transform for actual values
            test_rmse = calculate_rmse(y_test_true, test_predictions)
            print(f"RMSE on provided test/evaluation data: {test_rmse}")

            # Report unseen key pairs
            train_keys = df_2022_raw[street_name_col_std].astype(str) + '_' + df_2022_raw[violation_desc_col_std].astype(str)
            test_keys = df_test_raw[street_name_col_std].astype(str) + '_' + df_test_raw[violation_desc_col_std].astype(str)

            unseen_keys_count = (~test_keys.isin(train_keys)).sum()
            total_test_keys = len(test_keys)
            print(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {unseen_keys_count} out of {total_test_keys}")
            print("Unseen pairs are handled by the model's ability to generalize based on encoded features and numerical interaction features, "
                  "and by assigning -1 for unknown categories during Label Encoding transform, and by using global mean for unseen pairs in target encoding.")

    gc.collect()

if __name__ == "__main__":
    main()
