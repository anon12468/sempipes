
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import lightgbm as lgb
import gc
import re

# Define constants
# FIX: The target column in the provided data is 'violation_count', not 'fine_amount'.
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv'

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Performs feature engineering on the input DataFrame, incorporating smoothed target encoding
    and frequency encoding.
    """
    if encoder_dict is None:
        encoder_dict = {}

    original_cols = df.columns.tolist()
    df.columns = [re.sub(r'[^a-z0-9_]', '', col.replace(' ', '_').lower()) for col in original_cols] # Standardize column names

    # Standardize column names for lookup using the same logic
    standardized_street_col = re.sub(r'[^a-z0-9_]', '', STREET_NAME_COL.replace(' ', '_').lower())
    standardized_violation_col = re.sub(r'[^a-z0-9_]', '', VIOLATION_DESC_COL.replace(' ', '_').lower())
    
    # Standardize TARGET_COLUMN name for internal use in this function
    standardized_target_column = re.sub(r'[^a-z0-9_]', '', TARGET_COLUMN.replace(' ', '_').lower())


    # Handle missing values for key categorical features
    for col in [standardized_street_col, standardized_violation_col]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # --- Frequency Encoding ---
    categorical_cols_to_encode = [standardized_street_col, standardized_violation_col]

    for col in categorical_cols_to_encode:
        if col in df.columns:
            if is_training:
                # Calculate frequency and store it
                freq_map = df[col].value_counts(normalize=True).to_dict()
                encoder_dict[col + '_freq_map'] = freq_map
                df[col + '_freq_encoded'] = df[col].map(freq_map)
            else:
                # Apply stored frequency map, fill unseen categories with 0
                if col + '_freq_map' in encoder_dict:
                    df[col + '_freq_encoded'] = df[col].map(encoder_dict[col + '_freq_map']).fillna(0)
                else:
                    # If map doesn't exist (e.g., new column or error), assign 0
                    df[col + '_freq_encoded'] = 0

    # --- Smoothed Target Encoding ---
    # Hyperparameters for smoothed target encoding
    # These can be tuned, but fixed for this implementation
    smoothing_value = 100

    for col in categorical_cols_to_encode:
        if col in df.columns:
            if is_training:
                # Target encoding requires the target column and is only done during training
                if standardized_target_column in df.columns:
                    global_mean = df[standardized_target_column].mean()
                    agg = df.groupby(col)[standardized_target_column].agg(['count', 'mean'])

                    # Smoothed mean calculation: (count * category_mean + smoothing * global_mean) / (count + smoothing)
                    smoo_mean = (agg['count'] * agg['mean'] + smoothing_value * global_mean) / (agg['count'] + smoothing_value)

                    encoder_dict[col + '_target_map'] = smoo_mean.to_dict()
                    encoder_dict[col + '_global_mean'] = global_mean # Store global mean for inference

                    df[col + '_target_encoded'] = df[col].map(smoo_mean)
                else:
                    # If TARGET_COLUMN is not present during training, cannot compute target encoding
                    df[col + '_target_encoded'] = 0 # Assign a default, e.g., 0 or NaN
            else:
                # During inference, apply stored maps
                if col + '_target_map' in encoder_dict and col + '_global_mean' in encoder_dict:
                    target_map = encoder_dict[col + '_target_map']
                    global_mean = encoder_dict[col + '_global_mean']
                    # Fill unseen categories with the global mean from training
                    df[col + '_target_encoded'] = df[col].map(target_map).fillna(global_mean)
                else:
                    # If no map exists (e.g., encoder_dict wasn't populated correctly), assign 0
                    df[col + '_target_encoded'] = 0

    # Example: Interaction feature using the new target-encoded features (preferred)
    # Fallback to frequency encoded if target encoded features are not available
    street_target_col_name = standardized_street_col + '_target_encoded'
    violation_target_col_name = standardized_violation_col + '_target_encoded'
    street_freq_col_name = standardized_street_col + '_freq_encoded'
    violation_freq_col_name = standardized_violation_col + '_freq_encoded'

    if (street_target_col_name in df.columns) and (violation_target_col_name in df.columns):
        df['street_violation_interaction'] = df[street_target_col_name] * df[violation_target_col_name]
    elif (street_freq_col_name in df.columns) and (violation_freq_col_name in df.columns):
        # Fallback interaction if target encoding wasn't possible
        df['street_violation_interaction'] = df[street_freq_col_name] * df[violation_freq_col_name]
    else:
        # If neither is available, the interaction feature is skipped or can be set to a default
        pass # Or df['street_violation_interaction'] = 0

    # Log transform target if present and in training phase
    if standardized_target_column in df.columns and is_training:
        df[standardized_target_column] = np.log1p(df[standardized_target_column])

    # Rename standardized target column back to original TARGET_COLUMN for consistency if needed later,
    # or ensure all further operations use the standardized name.
    # For now, let's keep it standardized within this function to avoid repeated standardization.
    # The caller `load_and_preprocess_data` should handle how the target is extracted.
    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    # Store original column names before standardization for later reconstruction
    df.columns = [re.sub(r'[^a-z0-9_]', '', col.replace(' ', '_').lower()) for col in df.columns]
    
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series) -> lgb.Booster:
    """
    Trains a LightGBM model.
    """
    # LightGBM expects feature names as strings
    # The column names have already been standardized to be alphanumeric and underscores in _engineer_features
    # This step ensures they are valid for LightGBM, although the previous standardization step should have largely taken care of it.
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'regression_l1',  # MAE objective
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 31,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)]) # Use callbacks for early stopping

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional: Path to the 2023 test/evaluation data CSV.')
    args = parser.parse_args()

    # Standardize column names for constants once, to use consistently
    standardized_street_col = re.sub(r'[^a-z0-9_]', '', STREET_NAME_COL.replace(' ', '_').lower())
    standardized_violation_col = re.sub(r'[^a-z0-9_]', '', VIOLATION_DESC_COL.replace(' ', '_').lower())
    standardized_target_column = re.sub(r'[^a-z0-9_]', '', TARGET_COLUMN.replace(' ', '_').lower())

    print(f"Loading training data from: {args.train_path}")
    df_2022_raw, encoder_dict = load_and_preprocess_data(args.train_path, is_training=True)

    # Split 2022 data for training and validation
    # Use grouped holdout for (street_name, violation_type) pairs
    # Create a unique identifier for splitting
    df_2022_raw['group_id'] = df_2022_raw[standardized_street_col] + '_' + \
                               df_2022_raw[standardized_violation_col]

    # Get unique groups
    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    # Drop the temporary group_id
    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    # Define features and target
    # Ensure to use the standardized target column name here
    features = [col for col in df_train_raw.columns if col not in [standardized_target_column, standardized_street_col, standardized_violation_col]]

    # Prepare training data
    X_train = df_train_raw[features]
    y_train = df_train_raw[standardized_target_column] # Use standardized target column

    # Prepare validation data - CRITICAL FIX HERE: Extract y_val *before* any potential dropping or mismatch
    X_val = df_val_raw[features]
    y_val = df_val_raw[standardized_target_column] # Use standardized target column

    print("Training model...")
    model = train_model(X_train, y_train, X_val, y_val)

    # Predict on validation set for performance reporting
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log) # Inverse transform
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(np.expm1(y_val), val_predictions) # Calculate RMSE on original scale
    print(f"Final Validation Performance: {final_validation_rmse}")

    # If a test path is provided, generate predictions
    if args.test_path:
        print(f"Loading test data from: {args.test_path}")
        df_test_raw, _ = load_and_preprocess_data(args.test_path, is_training=False, encoder_dict=encoder_dict)

        # Ensure test data has the same features as training data
        test_features = [col for col in features if col in df_test_raw.columns]
        X_test = df_test_raw[test_features]

        # Align columns - crucial for consistent predictions
        # Add missing columns to X_test with 0, remove extra columns
        missing_cols = set(X_train.columns) - set(X_test.columns)
        for c in missing_cols:
            X_test[c] = 0
        extra_cols = set(X_test.columns) - set(X_train.columns)
        X_test = X_test.drop(columns=list(extra_cols))
        X_test = X_test[X_train.columns] # Ensure column order is the same

        print("Generating predictions for test data...")
        test_predictions_log = model.predict(X_test)
        test_predictions = np.expm1(test_predictions_log) # Inverse transform
        test_predictions[test_predictions < 0] = 0 # Clip negative predictions
        test_predictions = np.round(test_predictions).astype(int) # Round to nearest integer

        # Create submission file
        submission_df = pd.DataFrame({
            STREET_NAME_COL: df_test_raw[standardized_street_col], # Use original column names for submission output
            VIOLATION_DESC_COL: df_test_raw[standardized_violation_col],
            PREDICTED_COUNT_COL: test_predictions
        })
        # Original column names for submission
        submission_df.columns = [STREET_NAME_COL, VIOLATION_DESC_COL, PREDICTED_COUNT_COL]

        submission_df.to_csv(OUTPUT_SUBMISSION_FILE, index=False)
        print(f"Submission file '{OUTPUT_SUBMISSION_FILE}' created successfully.")

        # If test_path contains 'violation_count', calculate RMSE
        if standardized_target_column in df_test_raw.columns:
            y_test_true = np.expm1(df_test_raw[standardized_target_column]) # Inverse log transform for actual values
            test_rmse = calculate_rmse(y_test_true, test_predictions)
            print(f"RMSE on provided test/evaluation data: {test_rmse}")

            # Report unseen key pairs
            train_keys = df_2022_raw[standardized_street_col] + '_' + df_2022_raw[standardized_violation_col]
            test_keys = df_test_raw[standardized_street_col] + '_' + df_test_raw[standardized_violation_col]

            unseen_keys_count = (~test_keys.isin(train_keys)).sum() # Corrected count of unseen keys
            total_test_keys = len(test_keys)
            print(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {unseen_keys_count} out of {total_test_keys}")
            print("Unseen pairs are handled by the model's ability to generalize based on encoded features and numerical interaction features, "
                  "and by assigning a default value (e.g., global mean for target encoding, 0 for frequency encoding) for unseen categories during inference.")

    gc.collect()

if __name__ == "__main__":
    main()
