
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc
import copy

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
# OUTPUT_SUBMISSION_FILE is not needed for ablation study as we don't generate submissions.

def _engineer_features_core(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> (pd.DataFrame, dict):
    """
    Performs core feature engineering steps: standardizing column names, handling missing values,
    and label encoding. This function is designed to be agnostic to specific ablation features.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Handle missing values
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Label Encoding for categorical features
    categorical_cols = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col] = le
            else:
                if col in encoder_dict:
                    # Use transform for existing categories, map unknown to -1
                    def transform_with_unknown(s, encoder):
                        try:
                            # If `s` is not in `classes_`, `transform` raises ValueError
                            return encoder.transform([s])[0]
                        except ValueError:
                            return -1 # Assign -1 for unseen categories in test/validation
                    df[col + '_encoded'] = df[col].apply(lambda s: transform_with_unknown(s, encoder_dict[col]))
                else:
                    df[col + '_encoded'] = -1 # Assign a default for entirely new categories if no encoder

    return df, encoder_dict

def train_model_base(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series) -> lgb.Booster:
    """
    Trains a LightGBM model using the provided data.
    """
    # LightGBM expects feature names as strings, and cleans them internally.
    # Manual cleaning to avoid issues with special characters in column names
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'regression_l1',  # MAE objective
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 31,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)])

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_experiment(train_path: str, experiment_name: str,
                   enable_interaction_feature: bool, enable_log_transform: bool):
    """
    Runs a single training and validation experiment with specified ablation settings.
    """
    print(f"\n--- Running Experiment: {experiment_name} ---")

    # 1. Load initial raw data
    df_full_raw = pd.read_csv(train_path)
    
    # Standardize column names early for group_id creation, consistent with _engineer_features_core
    df_full_raw.columns = df_full_raw.columns.str.replace(' ', '_').str.lower()
    
    # 2. Create group_id for splitting BEFORE any other preprocessing to avoid data leakage
    df_full_raw['group_id'] = df_full_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_full_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

    unique_groups = df_full_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_initial = df_full_raw[df_full_raw['group_id'].isin(train_groups)].copy()
    df_val_initial = df_full_raw[df_full_raw['group_id'].isin(val_groups)].copy()

    # Drop the temporary group_id
    df_train_initial = df_train_initial.drop(columns=['group_id'])
    df_val_initial = df_val_initial.drop(columns=['group_id'])

    # 3. Feature Engineering for Training Data
    df_train_processed, encoder_dict = _engineer_features_core(df_train_initial.copy(), is_training=True, encoder_dict={})
    
    # Ablation point 1: Add/Remove Interaction feature
    if enable_interaction_feature:
        if (STREET_NAME_COL.replace(' ', '_').lower() + '_encoded' in df_train_processed.columns) and \
           (VIOLATION_DESC_COL.replace(' ', '_').lower() + '_encoded' in df_train_processed.columns):
            df_train_processed['street_violation_interaction'] = df_train_processed[STREET_NAME_COL.replace(' ', '_').lower() + '_encoded'] * \
                                                               df_train_processed[VIOLATION_DESC_COL.replace(' ', '_').lower() + '_encoded']
            
    # Ablation point 2: Apply Log Transform on target
    if TARGET_COLUMN in df_train_processed.columns:
        if enable_log_transform:
            df_train_processed[TARGET_COLUMN] = np.log1p(df_train_processed[TARGET_COLUMN])

    # Define features for training
    features = [col for col in df_train_processed.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]]

    X_train = df_train_processed[features]
    y_train = df_train_processed[TARGET_COLUMN]

    # 4. Feature Engineering for Validation Data (using encoder_dict from training to prevent leakage)
    df_val_processed, _ = _engineer_features_core(df_val_initial.copy(), is_training=False, encoder_dict=encoder_dict)
    
    # Apply ablation for interaction feature (consistent with training)
    if enable_interaction_feature:
        if (STREET_NAME_COL.replace(' ', '_').lower() + '_encoded' in df_val_processed.columns) and \
           (VIOLATION_DESC_COL.replace(' ', '_').lower() + '_encoded' in df_val_processed.columns):
            df_val_processed['street_violation_interaction'] = df_val_processed[STREET_NAME_COL.replace(' ', '_').lower() + '_encoded'] * \
                                                               df_val_processed[VIOLATION_DESC_COL.replace(' ', '_').lower() + '_encoded']

    # Ensure X_val has the same features and order as X_train
    # Add missing columns to X_val with 0, remove extra columns
    val_features_present = [f for f in features if f in df_val_processed.columns]
    X_val = df_val_processed[val_features_present]

    missing_cols_val = set(X_train.columns) - set(X_val.columns)
    for c in missing_cols_val:
        X_val[c] = 0 # Add missing features with default 0
    extra_cols_val = set(X_val.columns) - set(X_train.columns)
    X_val = X_val.drop(columns=list(extra_cols_val))
    X_val = X_val[X_train.columns] # Ensure column order is the same

    # Prepare y_val for model evaluation (log-transformed if needed)
    y_val_original_scale_for_rmse = df_val_initial[TARGET_COLUMN].copy() # Keep original for final RMSE
    y_val_model_input = df_val_initial[TARGET_COLUMN].copy()
    if enable_log_transform:
        y_val_model_input = np.log1p(y_val_model_input)

    # 5. Train model
    model = train_model_base(X_train, y_train, X_val, y_val_model_input)

    # 6. Predict on validation set
    val_predictions_model_output = model.predict(X_val)

    # Inverse transform if log transform was applied to the target
    if enable_log_transform:
        val_predictions_raw_scale = np.expm1(val_predictions_model_output)
    else:
        val_predictions_raw_scale = val_predictions_model_output # Predictions are already on original scale

    # Clip negative predictions and round to nearest integer
    val_predictions_raw_scale[val_predictions_raw_scale < 0] = 0
    val_predictions_raw_scale = np.round(val_predictions_raw_scale).astype(int)

    # 7. Calculate RMSE on original scale using the true original scale y_val
    final_validation_rmse = calculate_rmse(y_val_original_scale_for_rmse, val_predictions_raw_scale)
    print(f"Validation RMSE: {final_validation_rmse:.4f}")

    gc.collect() # Clean up memory
    return final_validation_rmse

def main():
    parser = argparse.ArgumentParser(description="Perform ablation study on NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()

    results = {}

    # 1. Baseline: Original model configuration
    results['Baseline'] = run_experiment(args.train_path,
                                         "Baseline (Interaction Feature + Log Transform)",
                                         enable_interaction_feature=True,
                                         enable_log_transform=True)

    # 2. Ablation: Remove Street-Violation Interaction Feature
    results['Ablation: No Interaction Feature'] = run_experiment(args.train_path,
                                                      "Ablation: No Street-Violation Interaction Feature",
                                                      enable_interaction_feature=False,
                                                      enable_log_transform=True)

    # 3. Ablation: Remove Log Transform on Target
    results['Ablation: No Log Transform'] = run_experiment(args.train_path,
                                                  "Ablation: No Log Transform on Target",
                                                  enable_interaction_feature=True,
                                                  enable_log_transform=False)

    print("\n--- Ablation Study Results ---")
    for name, rmse in results.items():
        print(f"{name}: Validation RMSE = {rmse:.4f}")

    print("\n--- Contribution Analysis ---")
    baseline_rmse = results['Baseline']
    
    # Calculate performance difference: (Ablated RMSE - Baseline RMSE)
    # A positive difference means removing the component increased RMSE (degraded performance),
    # implying the component was beneficial.
    # A negative difference means removing the component decreased RMSE (improved performance),
    # implying the component was detrimental or unnecessary.
    
    contribution_impacts = {
        "Street-Violation Interaction Feature": results['Ablation: No Interaction Feature'] - baseline_rmse,
        "Log Transform on Target": results['Ablation: No Log Transform'] - baseline_rmse
    }

    beneficial_contributions = {}
    for part, impact in contribution_impacts.items():
        if impact > 0:
            beneficial_contributions[part] = impact
            print(f"- '{part}' (was beneficial): Removing it increased RMSE by {impact:.4f}.")
        elif impact < 0:
            print(f"- '{part}' (was detrimental/unnecessary): Removing it *decreased* RMSE by {-impact:.4f}.")
        else:
            print(f"- '{part}' (had no measurable impact): Removing it resulted in no change in RMSE.")

    if beneficial_contributions:
        most_contributing_part = max(beneficial_contributions, key=beneficial_contributions.get)
        print(f"\nBased on this ablation study, the part contributing most positively to the overall performance is: "
              f"'{most_contributing_part}' (removing it caused the largest increase in RMSE).")
    else:
        print("\nNo single ablated part showed a clear positive contribution in isolation, or removing parts improved performance.")

if __name__ == "__main__":
    main()
