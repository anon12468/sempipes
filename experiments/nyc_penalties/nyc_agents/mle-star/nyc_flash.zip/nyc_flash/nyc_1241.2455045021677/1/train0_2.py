
import pandas as pd
import numpy as np
import argparse
import os
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

# Install necessary modules if not found
try:
    from catboost import CatBoostRegressor, Pool
except ImportError as e:
    module_name = "catboost" # CatBoost is the likely missing module if it fails here
    print(f"Attempting to install missing module: {module_name}")
    try:
        import subprocess
        subprocess.check_call([sys.executable, "-m", "pip", "install", module_name])
        from catboost import CatBoostRegressor, Pool
    except Exception as install_e:
        print(f"Failed to install {module_name}. Please install it manually: pip install {module_name}")
        raise install_e # Re-raise if installation didn't help.

import sys # Needed for sys.executable in the install block


# --- Configuration and Argument Parsing ---
def parse_args():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument(
        "--train-path",
        type=str,
        default="./input/violations_per_street_2022.csv",
        help="Path to the 2022 training data file.",
    )
    parser.add_argument(
        "--test-path",
        type=str,
        default=None,
        help="Path to the test/evaluation data file (optional).",
    )
    return parser.parse_args()

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame."""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")
    df = pd.read_csv(file_path)
    return df

def feature_engineer(df, street_attributes_df, violation_attributes_df, street_freq_map=None, violation_freq_map=None):
    """Applies feature engineering to the DataFrame.
    Returns the engineered DataFrame and the frequency maps (if created/passed).
    """
    df_fe = df.copy()

    df_fe.rename(columns={"Street Name": "street_name", "Violation Description": "violation_type"}, inplace=True)

    # Merge street attributes
    if street_attributes_df is not None and not street_attributes_df.empty:
        # Get columns that are not already in df_fe before merge to only fill NaNs for new columns
        original_df_cols = set(df_fe.columns)
        df_fe = pd.merge(df_fe, street_attributes_df, on="street_name", how="left")
        for col in street_attributes_df.columns:
            if col != 'street_name' and col not in original_df_cols: # Only process newly added columns
                if df_fe[col].dtype == 'object':
                    df_fe[col].fillna('Unknown_Street_Attr', inplace=True)
                elif df_fe[col].dtype in ['float64', 'int64']:
                    df_fe[col].fillna(0, inplace=True) # Use 0 for numerical attributes for unseen streets

    # Merge violation type attributes
    if violation_attributes_df is not None and not violation_attributes_df.empty:
        original_df_cols = set(df_fe.columns)
        df_fe = pd.merge(df_fe, violation_attributes_df, on="violation_type", how="left")
        for col in violation_attributes_df.columns:
            if col != 'violation_type' and col not in original_df_cols: # Only process newly added columns
                if df_fe[col].dtype == 'object':
                    df_fe[col].fillna('Unknown_Violation_Attr', inplace=True)
                elif df_fe[col].dtype in ['float64', 'int64']:
                    df_fe[col].fillna(0, inplace=True) # Use 0 for numerical attributes for unseen violations

    # Frequency encoding
    if street_freq_map is None or violation_freq_map is None: # This implies it's training data processing
        street_freq_map = df_fe['street_name'].value_counts().to_dict()
        violation_freq_map = df_fe['violation_type'].value_counts().to_dict()

    df_fe['street_freq'] = df_fe['street_name'].map(street_freq_map).fillna(0)
    df_fe['violation_freq'] = df_fe['violation_type'].map(violation_freq_map).fillna(0)

    # Interaction feature
    df_fe['street_violation_pair'] = df_fe['street_name'].astype(str) + '_' + df_fe['violation_type'].astype(str)

    return df_fe, street_freq_map, violation_freq_map

def main():
    args = parse_args()

    # --- Load Core Training Data ---
    train_df_2022 = load_data(args.train_path)
    print(f"Loaded training data from {args.train_path}. Shape: {train_df_2022.shape}")

    # --- Load Augmentation Data ---
    # In a real scenario, we'd discover these files. Here, we'll assume their existence or create empty DFs.
    street_attributes_path = "./input/street_attributes.csv"
    violation_attributes_path = "./input/violation_type_attributes.csv"

    street_attributes_df = pd.DataFrame(columns=["street_name"]) # Default empty dataframe
    if os.path.exists(street_attributes_path):
        street_attributes_df = load_data(street_attributes_path)
        street_attributes_df.rename(columns={"Street Name": "street_name"}, inplace=True)
        # Ensure 'street_name' is unique to avoid merge issues (if not, aggregate or drop duplicates)
        street_attributes_df.drop_duplicates(subset=['street_name'], inplace=True)
        print(f"Loaded street attributes from {street_attributes_path}. Shape: {street_attributes_df.shape}")
    else:
        print(f"Street attributes file not found at {street_attributes_path}. Skipping.")

    violation_attributes_df = pd.DataFrame(columns=["violation_type"]) # Default empty dataframe
    if os.path.exists(violation_attributes_path):
        violation_attributes_df = load_data(violation_attributes_path)
        violation_attributes_df.rename(columns={"Violation Description": "violation_type"}, inplace=True)
        # Ensure 'violation_type' is unique
        violation_attributes_df.drop_duplicates(subset=['violation_type'], inplace=True)
        print(f"Loaded violation attributes from {violation_attributes_path}. Shape: {violation_attributes_df.shape}")
    else:
        print(f"Violation attributes file not found at {violation_attributes_path}. Skipping.")


    # --- Feature Engineering for Training Data ---
    train_df_fe, street_freq_map, violation_freq_map = feature_engineer(train_df_2022, street_attributes_df, violation_attributes_df)
    print(f"After feature engineering, training data shape: {train_df_fe.shape}")

    # --- Prepare Data for CatBoost ---
    X = train_df_fe.drop(columns=["violation_count"])
    y = train_df_fe["violation_count"]

    # Identify categorical features
    # Use explicit list for robustness, assuming attribute columns are known or can be inferred
    categorical_features_names = [col for col in X.columns if X[col].dtype == 'object']
    # Add any specific columns that should always be treated as categorical if not object (e.g., from numerical attribute files)
    specific_categorical_cols = ["street_name", "violation_type", "street_violation_pair", "Borough", "Severity"]
    for col in specific_categorical_cols:
        if col in X.columns and col not in categorical_features_names:
            categorical_features_names.append(col)

    # Convert all identified categorical features to string type
    for col in categorical_features_names:
        if col in X.columns: # Ensure column exists before conversion
            X[col] = X[col].astype(str)
    
    # Ensure numerical columns are truly numeric (e.g., after initial merges/fills)
    for col in X.columns:
        if col not in categorical_features_names:
            X[col] = pd.to_numeric(X[col], errors='coerce').fillna(0) # Fill NaNs created by coercion with 0


    print(f"Categorical features identified for CatBoost: {categorical_features_names}")

    # --- Train/Validation Split (from 2022 data) ---
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    # CatBoost Pool objects
    train_pool = Pool(X_train, y_train, cat_features=categorical_features_names)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_names)

    # --- CatBoost Model Training ---
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=8,
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Suppress verbose output during training
        early_stopping_rounds=50,
        allow_writing_files=False, # Prevent CatBoost from writing temporary files
        loss_function='RMSE'
    )

    print("Starting CatBoost training...")
    model.fit(train_pool, eval_set=val_pool, use_best_model=True)
    print("CatBoost training complete.")

    # --- Evaluate on Validation Set ---
    val_predictions = model.predict(X_val)
    # Ensure predictions are non-negative
    val_predictions[val_predictions < 0] = 0
    final_validation_score = np.sqrt(mean_squared_error(y_val, val_predictions))
    print(f"Final Validation Performance: {final_validation_score}")

    # --- Handle Test/Evaluation Data if provided ---
    if args.test_path:
        test_df_raw = load_data(args.test_path)
        print(f"Loaded test/evaluation data from {args.test_path}. Shape: {test_df_raw.shape}")

        # Store original keys for submission
        submission_keys = test_df_raw[['Street Name', 'Violation Description']].copy()

        # Check if 'violation_count' is present in test data
        has_ground_truth = 'violation_count' in test_df_raw.columns and test_df_raw['violation_count'].notna().any()

        # Feature Engineering for Test Data using maps from training
        test_df_fe, _, _ = feature_engineer(test_df_raw, street_attributes_df, violation_attributes_df, street_freq_map, violation_freq_map)
        print(f"After feature engineering, test data shape: {test_df_fe.shape}")

        test_X = test_df_fe.drop(columns=["violation_count"], errors='ignore')

        # Align columns with training data before prediction
        # Add missing columns that were in training data but not in test data
        missing_cols_in_test = set(X_train.columns) - set(test_X.columns)
        for col in missing_cols_in_test:
            # For categorical features, add with 'Unknown_Category' or other placeholder
            if col in categorical_features_names:
                test_X[col] = 'Unknown_Category_Test'
            else: # For numerical features, add with 0
                test_X[col] = 0 

        # Ensure column order is the same as training data
        test_X = test_X[X_train.columns]

        # Convert categorical features to string type for consistency with training
        for col in categorical_features_names:
            if col in test_X.columns: # Ensure column exists before conversion
                test_X[col] = test_X[col].astype(str)
            
        # Ensure numerical columns are truly numeric
        for col in test_X.columns:
            if col not in categorical_features_names:
                test_X[col] = pd.to_numeric(test_X[col], errors='coerce').fillna(0)


        # Predict on Test Data
        print("Generating predictions for test data...")
        test_predictions = model.predict(test_X)
        test_predictions[test_predictions < 0] = 0 # Ensure non-negative predictions

        # Create submission file
        submission_df = submission_keys
        submission_df['predicted_count'] = test_predictions
        submission_df.rename(columns={'Street Name': 'street_name', 'Violation Description': 'violation_type'}, inplace=True)
        submission_df.to_csv("submission.csv", index=False)
        print("Submission file 'submission.csv' generated.")

        # Report RMSE if ground truth is available in test file
        if has_ground_truth:
            test_ground_truth = test_df_raw['violation_count']
            test_rmse = np.sqrt(mean_squared_error(test_ground_truth, test_predictions))
            print(f"RMSE on provided test/evaluation data: {test_rmse}")

        # Report unseen key pairs
        train_key_pairs = set(zip(train_df_2022['Street Name'], train_df_2022['Violation Description']))
        test_key_pairs = set(zip(test_df_raw['Street Name'], test_df_raw['Violation Description']))
        unseen_pairs = test_key_pairs - train_key_pairs
        print(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {len(unseen_pairs)}")
        print("Handling for unseen pairs: CatBoost handles unseen categorical features by treating them as a new category. For unseen combinations, it uses learned patterns from individual components and existing combinations.")

if __name__ == "__main__":
    main()
