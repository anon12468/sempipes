
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc
import copy
import os

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv'

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> (pd.DataFrame, dict):
    """
    Performs feature engineering on the input DataFrame.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Handle missing values
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Label Encoding for categorical features
    categorical_cols = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col] = le
            else:
                if col in encoder_dict:
                    # Use transform for existing categories, map unknown to -1
                    # LightGBM can handle -1 as another category, or it can be treated as NaN.
                    # For consistency with LabelEncoder, it's often best to map to an unseen value.
                    # Here, -1 is chosen as it's outside the non-negative range of fit_transform.
                    df[col + '_encoded'] = df[col].apply(
                        lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else -1
                    ).astype(int) # Ensure type consistency
                else:
                    df[col + '_encoded'] = -1 # Assign a default for entirely new categories if no encoder was fitted

    # Log transform target if present, good for count data
    if TARGET_COLUMN.replace(' ', '_').lower() in df.columns and is_training:
        df[TARGET_COLUMN.replace(' ', '_').lower()] = np.log1p(df[TARGET_COLUMN.replace(' ', '_').lower()])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None) -> (pd.DataFrame, dict):
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series, model_params: dict, use_early_stopping: bool = True, categorical_feature_declaration: bool = True) -> lgb.Booster:
    """
    Trains a LightGBM model with customizable parameters and options for ablation.
    """
    # LightGBM expects feature names as strings and sanitized names
    original_train_cols = X_train.columns
    X_train_sanitized = X_train.copy()
    X_val_sanitized = X_val.copy()

    # Sanitize column names for LightGBM
    X_train_sanitized.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val_sanitized.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    categorical_features_names = []
    if categorical_feature_declaration:
        # Identify categorical features based on the plan
        target_cat_cols = ['street_name_encoded', 'violation_description_encoded']
        for col in target_cat_cols:
            sanitized_col_name = "".join (c if c.isalnum() else "_" for c in str(col))
            if sanitized_col_name in X_train_sanitized.columns: # Check if the sanitized column exists
                # FIX: Removed astype('category') here. LightGBM can handle integer-encoded
                # categorical features directly by passing their names to `categorical_feature`.
                # Explicitly converting to pandas 'category' dtype can cause mismatches if
                # the categories in train and val are not identical (even if integer encodings are).
                categorical_features_names.append(sanitized_col_name)

    model = lgb.LGBMRegressor(**model_params)

    callbacks = [lgb.early_stopping(100, verbose=False)] if use_early_stopping else []

    fit_params = {
        'eval_set': [(X_val_sanitized, y_val)],
        'eval_metric': 'rmse',
        'callbacks': callbacks
    }
    if categorical_feature_declaration and categorical_features_names:
        fit_params['categorical_feature'] = categorical_features_names

    model.fit(X_train_sanitized, y_train, **fit_params)

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_ablation_study():
    parser = argparse.ArgumentParser(description="Ablation study for NYC parking violations model.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional path to a test/evaluation data CSV for prediction/scoring.')
    args = parser.parse_args()

    print(f"Loading training data from: {args.train_path}")
    df_2022_raw, encoder_dict = load_and_preprocess_data(args.train_path, is_training=True)

    # Use lowercase and snake_case for internal column names for consistency
    street_name_col_processed = STREET_NAME_COL.replace(' ', '_').lower()
    violation_desc_col_processed = VIOLATION_DESC_COL.replace(' ', '_').lower()
    target_col_processed = TARGET_COLUMN.replace(' ', '_').lower()

    # Split 2022 data for training and validation using grouped holdout
    df_2022_raw['group_id'] = df_2022_raw[street_name_col_processed] + '_' + \
                               df_2022_raw[violation_desc_col_processed]

    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    # Identify features for the model
    features = [col for col in df_train_raw.columns if col not in [target_col_processed, street_name_col_processed, violation_desc_col_processed]]

    X_train = df_train_raw[features]
    y_train = df_train_raw[target_col_processed]
    X_val = df_val_raw[features]
    y_val = df_val_raw[target_col_processed]

    base_params = {
        'objective': 'poisson',
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 63,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    results = {}
    best_overall_rmse = float('inf')
    best_overall_config = ""

    # --- Baseline Run ---
    print("\n--- Running Baseline Model ---")
    baseline_model = train_model(X_train, y_train, X_val, y_val, base_params, use_early_stopping=True, categorical_feature_declaration=True)
    
    # Sanitize X_val column names for prediction
    X_val_sanitized_for_pred = X_val.copy()
    X_val_sanitized_for_pred.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    val_predictions_log = baseline_model.predict(X_val_sanitized_for_pred)
    val_predictions = np.expm1(val_predictions_log)
    val_predictions[val_predictions < 0] = 0 # Ensure non-negative counts
    baseline_rmse = calculate_rmse(np.expm1(y_val), val_predictions)
    results['Baseline'] = baseline_rmse
    print(f"Baseline Validation RMSE: {baseline_rmse:.4f}")
    if baseline_rmse < best_overall_rmse:
        best_overall_rmse = baseline_rmse
        best_overall_config = "Baseline"

    # --- Ablation 1: Introduce max_depth=7 ---
    print("\n--- Running Ablation 1: Introduce max_depth=7 ---")
    abl_1_params = copy.deepcopy(base_params)
    abl_1_params['max_depth'] = 7 # Add max_depth
    abl_1_model = train_model(X_train, y_train, X_val, y_val, abl_1_params, use_early_stopping=True, categorical_feature_declaration=True)
    val_predictions_log = abl_1_model.predict(X_val_sanitized_for_pred) # Use sanitized X_val for prediction
    val_predictions = np.expm1(val_predictions_log)
    val_predictions[val_predictions < 0] = 0
    abl_1_rmse = calculate_rmse(np.expm1(y_val), val_predictions)
    results['Ablation 1 (max_depth=7)'] = abl_1_rmse
    print(f"Ablation 1 (max_depth=7) Validation RMSE: {abl_1_rmse:.4f}")
    print(f"Impact: {abl_1_rmse - baseline_rmse:.4f} (vs Baseline)")
    if abl_1_rmse < best_overall_rmse:
        best_overall_rmse = abl_1_rmse
        best_overall_config = "Ablation 1 (max_depth=7)"


    # --- Ablation 2: Increase min_child_samples=100 ---
    print("\n--- Running Ablation 2: Increase min_child_samples=100 ---")
    abl_2_params = copy.deepcopy(base_params)
    abl_2_params['min_child_samples'] = 100 # Increase min_child_samples (default is 20 for regression)
    abl_2_model = train_model(X_train, y_train, X_val, y_val, abl_2_params, use_early_stopping=True, categorical_feature_declaration=True)
    val_predictions_log = abl_2_model.predict(X_val_sanitized_for_pred) # Use sanitized X_val for prediction
    val_predictions = np.expm1(val_predictions_log)
    val_predictions[val_predictions < 0] = 0
    abl_2_rmse = calculate_rmse(np.expm1(y_val), val_predictions)
    results['Ablation 2 (min_child_samples=100)'] = abl_2_rmse
    print(f"Ablation 2 (min_child_samples=100) Validation RMSE: {abl_2_rmse:.4f}")
    print(f"Impact: {abl_2_rmse - baseline_rmse:.4f} (vs Baseline)")
    if abl_2_rmse < best_overall_rmse:
        best_overall_rmse = abl_2_rmse
        best_overall_config = "Ablation 2 (min_child_samples=100)"


    # --- Ablation 3: Disable bagging_freq ---
    print("\n--- Running Ablation 3: Disable bagging_freq ---")
    abl_3_params = copy.deepcopy(base_params)
    abl_3_params['bagging_freq'] = 0 # Disable bagging
    abl_3_model = train_model(X_train, y_train, X_val, y_val, abl_3_params, use_early_stopping=True, categorical_feature_declaration=True)
    val_predictions_log = abl_3_model.predict(X_val_sanitized_for_pred) # Use sanitized X_val for prediction
    val_predictions = np.expm1(val_predictions_log)
    val_predictions[val_predictions < 0] = 0
    abl_3_rmse = calculate_rmse(np.expm1(y_val), val_predictions)
    results['Ablation 3 (bagging_freq=0)'] = abl_3_rmse
    print(f"Ablation 3 (bagging_freq=0) Validation RMSE: {abl_3_rmse:.4f}")
    print(f"Impact: {abl_3_rmse - baseline_rmse:.4f} (vs Baseline)")
    if abl_3_rmse < best_overall_rmse:
        best_overall_rmse = abl_3_rmse
        best_overall_config = "Ablation 3 (bagging_freq=0)"


    print("\n--- Ablation Study Summary ---")
    for config, rmse in results.items():
        print(f"{config}: {rmse:.4f}")
    
    print(f"\nConclusion: The '{best_overall_config}' configuration resulted in the best performance (lowest RMSE) of {best_overall_rmse:.4f}.")
    if best_overall_config != 'Baseline':
        impact_from_baseline = results[best_overall_config] - results['Baseline']
        print(f"This represents an improvement of {-impact_from_baseline:.4f} RMSE compared to the Baseline.")
    else:
        worst_rmse = float('-inf')
        worst_config = ""
        for config, rmse in results.items():
            if rmse > worst_rmse:
                worst_rmse = rmse
                worst_config = config
        if worst_config != 'Baseline':
            impact_from_baseline = results[worst_config] - results['Baseline']
            print(f"The Baseline performed the best, suggesting that changes like '{worst_config.split('(')[0].strip()}' were detrimental, increasing RMSE by {impact_from_baseline:.4f}.")
    
    print(f"Final Validation Performance: {best_overall_rmse}")

    # --- Handle optional test-path for prediction ---
    if args.test_path:
        print(f"\n--- Generating predictions for test data: {args.test_path} ---")
        # For simplicity, we use the best model found during ablation for final predictions.
        # In a real scenario, you might retrain a model on the full 2022 dataset with the best params.
        best_model_params = None
        if best_overall_config == "Baseline":
            best_model_params = base_params
            final_model = baseline_model
        elif best_overall_config == "Ablation 1 (max_depth=7)":
            best_model_params = abl_1_params
            final_model = abl_1_model
        elif best_overall_config == "Ablation 2 (min_child_samples=100)":
            best_model_params = abl_2_params
            final_model = abl_2_model
        elif best_overall_config == "Ablation 3 (bagging_freq=0)":
            best_model_params = abl_3_params
            final_model = abl_3_model
        else: # Fallback if for some reason best_overall_config is not one of the above
            best_model_params = base_params
            final_model = baseline_model
        
        # Load and preprocess test data using the encoder fitted on training data
        df_test_raw, _ = load_and_preprocess_data(args.test_path, is_training=False, encoder_dict=encoder_dict)

        # Keep original street name and violation description for output
        df_test_output = df_test_raw[[street_name_col_processed, violation_desc_col_processed]].copy()
        
        # Prepare features for prediction
        X_test = df_test_raw[features]
        X_test_sanitized = X_test.copy()
        X_test_sanitized.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_test.columns]

        test_predictions_log = final_model.predict(X_test_sanitized)
        test_predictions = np.expm1(test_predictions_log)
        test_predictions[test_predictions < 0] = 0 # Ensure non-negative counts
        test_predictions = np.round(test_predictions).astype(int) # Round to nearest integer

        # Create submission file
        submission_df = pd.DataFrame({
            STREET_NAME_COL: df_test_output[street_name_col_processed],
            VIOLATION_DESC_COL: df_test_output[violation_desc_col_processed],
            PREDICTED_COUNT_COL: test_predictions
        })
        
        submission_df.to_csv(OUTPUT_SUBMISSION_FILE, index=False)
        print(f"Predictions saved to {OUTPUT_SUBMISSION_FILE}")

        # If violation_count is present in the test file, calculate RMSE
        if target_col_processed in df_test_raw.columns:
            y_test_true = np.expm1(df_test_raw[target_col_processed])
            test_rmse = calculate_rmse(y_test_true, test_predictions)
            print(f"Test Set RMSE: {test_rmse:.4f}")
            
            # Report unseen key pairs
            test_keys = df_test_raw[[street_name_col_processed, violation_desc_col_processed]].drop_duplicates()
            train_keys = df_2022_raw[[street_name_col_processed, violation_desc_col_processed]].drop_duplicates()

            # Merge to find common and unseen keys
            merged_keys = pd.merge(test_keys, train_keys, on=[street_name_col_processed, violation_desc_col_processed], how='left', indicator=True)
            unseen_keys_count = (merged_keys['_merge'] == 'left_only').sum()
            total_test_keys = len(test_keys)

            print(f"Number of unique (street_name, violation_type) pairs in test set: {total_test_keys}")
            print(f"Number of unseen (street_name, violation_type) pairs in test set (not in 2022 training data): {unseen_keys_count}")
            print(f"Handling of unseen keys: These were encoded to -1 by LabelEncoder and treated as a distinct category by LightGBM.")

    gc.collect()

if __name__ == "__main__":
    run_ablation_study()
