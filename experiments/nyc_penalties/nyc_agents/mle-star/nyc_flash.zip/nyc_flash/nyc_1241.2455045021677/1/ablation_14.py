

import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv' # Not used in ablation, but part of original

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None, apply_log_transform: bool = True) -> pd.DataFrame:
    """
    Performs feature engineering on the input DataFrame.
    Added apply_log_transform parameter for ablation.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Handle missing values
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Label Encoding for categorical features
    categorical_cols = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col] = le
            else:
                if col in encoder_dict:
                    # Use transform for existing categories, map unknown to -1
                    df[col + '_encoded'] = df[col].map(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else -1)
                else:
                    df[col + '_encoded'] = -1 # Assign a default for entirely new categories if no encoder

    # Log transform target if present, good for count data
    if TARGET_COLUMN in df.columns and is_training and apply_log_transform:
        df[TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None, apply_log_transform: bool = True) -> pd.DataFrame:
    """
    Loads data from a CSV file and applies initial preprocessing.
    Added apply_log_transform parameter for ablation.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict, apply_log_transform=apply_log_transform)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series,
                learning_rate: float, num_leaves: int) -> lgb.Booster:
    """
    Trains a LightGBM model.
    Added learning_rate and num_leaves parameters for ablation.
    """
    # LightGBM expects feature names as strings
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'poisson',
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': learning_rate, # Ablation parameter
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': num_leaves, # Ablation parameter
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)])

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_ablation_experiment(
    train_path: str,
    exp_name: str,
    apply_log_transform: bool,
    learning_rate: float,
    num_leaves: int
) -> float:
    """
    Runs a single ablation experiment and returns the validation RMSE.
    """
    print(f"--- Running Experiment: {exp_name} ---")
    df_2022_raw, encoder_dict = load_and_preprocess_data(train_path, is_training=True, apply_log_transform=apply_log_transform)

    # Split 2022 data for training and validation
    df_2022_raw['group_id'] = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]
    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])

    features = [col for col in df_train_raw.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]]

    X_train = df_train_raw[features]
    y_train = df_train_raw[TARGET_COLUMN]
    X_val = df_val_raw[features]
    y_val = df_val_raw[TARGET_COLUMN]

    model = train_model(X_train, y_train, X_val, y_val, learning_rate=learning_rate, num_leaves=num_leaves)

    val_predictions_log = model.predict(X_val)
    
    # Apply inverse log transform if the target was log-transformed for training
    if apply_log_transform:
        val_predictions = np.expm1(val_predictions_log)
        y_val_original_scale = np.expm1(y_val)
    else: # If target was not log-transformed, predictions are already on original scale
        val_predictions = val_predictions_log
        y_val_original_scale = y_val

    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(y_val_original_scale, val_predictions)
    print(f"Validation RMSE for {exp_name}: {final_validation_rmse}")
    gc.collect()
    return final_validation_rmse

if __name__ == "__main__":
    train_data_path = './input/violations_per_street_2022.csv' # Assume this path exists

    # Baseline Configuration (as per the provided Python solution)
    baseline_apply_log_transform = True
    baseline_learning_rate = 0.01
    baseline_num_leaves = 63

    print("Starting Ablation Study...")

    # Run Baseline
    baseline_rmse = run_ablation_experiment(
        train_data_path,
        "Baseline (Original Configuration)",
        apply_log_transform=baseline_apply_log_transform,
        learning_rate=baseline_learning_rate,
        num_leaves=baseline_num_leaves
    )

    # Ablation 1: No Log Transform on Target
    ablation1_rmse = run_ablation_experiment(
        train_data_path,
        "Ablation 1: No Log Transform on Target",
        apply_log_transform=False, # Disable log transform
        learning_rate=baseline_learning_rate,
        num_leaves=baseline_num_leaves
    )

    # Ablation 2: num_leaves = 31 (from 63)
    ablation2_rmse = run_ablation_experiment(
        train_data_path,
        "Ablation 2: num_leaves = 31 (from 63)",
        apply_log_transform=baseline_apply_log_transform,
        learning_rate=baseline_learning_rate,
        num_leaves=31 # Change num_leaves
    )

    # Ablation 3: learning_rate = 0.05 (from 0.01)
    ablation3_rmse = run_ablation_experiment(
        train_data_path,
        "Ablation 3: learning_rate = 0.05 (from 0.01)",
        apply_log_transform=baseline_apply_log_transform,
        learning_rate=0.05, # Change learning_rate
        num_leaves=baseline_num_leaves
    )

    print("\n--- Ablation Study Results Summary ---")
    print(f"Baseline RMSE: {baseline_rmse:.4f}")
    print(f"Ablation 1 (No Log Transform on Target) RMSE: {ablation1_rmse:.4f} (Change from Baseline: {ablation1_rmse - baseline_rmse:.4f})")
    print(f"Ablation 2 (num_leaves = 31) RMSE: {ablation2_rmse:.4f} (Change from Baseline: {ablation2_rmse - baseline_rmse:.4f})")
    print(f"Ablation 3 (learning_rate = 0.05) RMSE: {ablation3_rmse:.4f} (Change from Baseline: {ablation3_rmse - baseline_rmse:.4f})")

    # Determine most impactful component (largest absolute change from baseline)
    impacts = {
        "No Log Transform on Target": ablation1_rmse - baseline_rmse,
        "num_leaves = 31": ablation2_rmse - baseline_rmse,
        "learning_rate = 0.05": ablation3_rmse - baseline_rmse
    }

    if not impacts:
        print("No ablation experiments were run to determine impact.")
    else:
        most_impactful_ablation_name = max(impacts, key=lambda k: abs(impacts[k]))
        most_impactful_change = impacts[most_impactful_ablation_name]

        if most_impactful_change < 0:
            impact_type = "beneficial (RMSE decreased)"
        elif most_impactful_change > 0:
            impact_type = "detrimental (RMSE increased)"
        else:
            impact_type = "neutral (no change in RMSE)"

        print(f"\nThe part that contributes the most to the overall performance (largest absolute change) is: '{most_impactful_ablation_name}'.")
        print(f"Its modification resulted in a {impact_type} change of {abs(most_impactful_change):.4f} RMSE compared to the baseline.")

