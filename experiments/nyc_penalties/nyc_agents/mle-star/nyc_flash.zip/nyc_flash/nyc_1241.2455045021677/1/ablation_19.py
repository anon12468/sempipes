
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import lightgbm as lgb
import gc
from category_encoders import CatBoostEncoder

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv' # Not used in ablation, but kept for consistency

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None, apply_log_transform: bool = True) -> pd.DataFrame:
    """
    Performs feature engineering on the input DataFrame.
    Includes conditional log transformation of the target.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Handle missing values
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    categorical_cols = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]

    # CatBoost Encoding for categorical features
    for col in categorical_cols:
        if col in df.columns:
            encoded_col_name = col + '_cb_encoded'
            if is_training:
                cbe = CatBoostEncoder(cols=[col], handle_unknown='impute', handle_missing='impute')
                # Fit and transform on training data using the target variable (potentially log-transformed)
                df[encoded_col_name] = cbe.fit_transform(df[col], df[TARGET_COLUMN])
                encoder_dict[col] = cbe
            else:
                if col in encoder_dict:
                    df[encoded_col_name] = encoder_dict[col].transform(df[col])
                else:
                    df[encoded_col_name] = 0.0 # Default for entirely new columns at inference

    # Log transform target if present and enabled
    if TARGET_COLUMN in df.columns and is_training and apply_log_transform:
        df[TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None, apply_log_transform: bool = True) -> pd.DataFrame:
    """
    Loads data from a CSV file and applies initial preprocessing, including conditional log transform.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict, apply_log_transform=apply_log_transform)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series, l1_lambda: float = 0.1, l2_lambda: float = 0.1) -> lgb.Booster:
    """
    Trains a LightGBM model with customizable L1/L2 regularization.
    """
    # LightGBM expects feature names as strings
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'poisson',
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': l1_lambda,  # Customizable L1 regularization
        'lambda_l2': l2_lambda,  # Customizable L2 regularization
        'num_leaves': 63,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)])

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_ablation_scenario(train_path: str, scenario_name: str, 
                          apply_log_transform: bool, 
                          validation_test_size: float,
                          l1_lambda: float, l2_lambda: float) -> float:
    """
    Runs a single ablation scenario with specified parameters and returns its RMSE.
    """
    print(f"\n--- Running scenario: {scenario_name} ---")
    
    # Load data for RMSE calculation (always untransformed target)
    df_2022_raw_untransformed, _ = load_and_preprocess_data(train_path, is_training=True, apply_log_transform=False)
    
    # Load data for model training (target transformed based on scenario setting)
    df_2022_raw, encoder_dict = load_and_preprocess_data(train_path, is_training=True, apply_log_transform=apply_log_transform)

    # Split 2022 data for training and validation using grouped holdout
    df_2022_raw['group_id'] = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]
    df_2022_raw_untransformed['group_id'] = df_2022_raw_untransformed[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_2022_raw_untransformed[VIOLATION_DESC_COL.replace(' ', '_').lower()]

    unique_groups = df_2022_raw['group_id'].unique()
    # Use customizable validation_test_size
    train_groups, val_groups = train_test_split(unique_groups, test_size=validation_test_size, random_state=42) 

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()
    
    # Get the original (untransformed) y_val for final RMSE calculation
    df_val_raw_untransformed = df_2022_raw_untransformed[df_2022_raw_untransformed['group_id'].isin(val_groups)].copy()

    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    df_val_raw_untransformed = df_val_raw_untransformed.drop(columns=['group_id'])
    
    features = [col for col in df_train_raw.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]]

    X_train = df_train_raw[features]
    y_train = df_train_raw[TARGET_COLUMN]

    X_val = df_val_raw[features]
    y_val_transformed = df_val_raw[TARGET_COLUMN] # y_val used for model fitting
    y_val_original = df_val_raw_untransformed[TARGET_COLUMN] # y_val for final RMSE calculation

    print("Training model...")
    # Train model with customizable L1/L2 regularization
    model = train_model(X_train, y_train, X_val, y_val_transformed, l1_lambda=l1_lambda, l2_lambda=l2_lambda)

    val_predictions_log = model.predict(X_val)
    
    # Inverse transform predictions IF log transform was applied during feature engineering
    if apply_log_transform:
        val_predictions = np.expm1(val_predictions_log)
    else:
        val_predictions = val_predictions_log # If no log transform, predictions are already on original scale

    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(y_val_original, val_predictions) # Calculate RMSE on original scale
    print(f"Validation Performance ({scenario_name}): {final_validation_rmse:.4f}")
    gc.collect() # Clean up memory after each scenario
    return final_validation_rmse

def main():
    parser = argparse.ArgumentParser(description="Perform ablation study on NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()

    results = {}
    
    # 1. Baseline Scenario (Current solution's settings)
    # This reflects the state of the provided train.py script with log transform, test_size=0.2, L1/L2=0.1
    baseline_rmse = run_ablation_scenario(
        args.train_path,
        "Baseline (Log Transform, test_size=0.2, L1/L2=0.1)",
        apply_log_transform=True,
        validation_test_size=0.2,
        l1_lambda=0.1,
        l2_lambda=0.1
    )
    results["Baseline"] = baseline_rmse

    # 2. Ablation 1: No Log Transform on Target
    # Previous studies (1, 7, 9, 13, 15, 17) consistently suggest log transform is detrimental.
    no_log_transform_rmse = run_ablation_scenario(
        args.train_path,
        "Ablation 1: No Log Transform on Target",
        apply_log_transform=False,
        validation_test_size=0.2,
        l1_lambda=0.1,
        l2_lambda=0.1
    )
    results["Ablation 1: No Log Transform"] = no_log_transform_rmse

    # 3. Ablation 2: Change Validation Split test_size to 0.3
    # Previous studies (14, 17) found this beneficial.
    validation_split_0_3_rmse = run_ablation_scenario(
        args.train_path,
        "Ablation 2: Validation Split test_size=0.3",
        apply_log_transform=True, # Revert other parameters to baseline for isolated effect
        validation_test_size=0.3,
        l1_lambda=0.1,
        l2_lambda=0.1
    )
    results["Ablation 2: Validation Split 0.3"] = validation_split_0_3_rmse

    # 4. Ablation 3: No L1/L2 Regularization (lambda_l1=0, lambda_l2=0)
    # Previous studies (6, 9, 10, 12, 17) showed inconsistent results (sometimes beneficial, sometimes detrimental).
    # Re-evaluating by completely removing it.
    no_l1_l2_reg_rmse = run_ablation_scenario(
        args.train_path,
        "Ablation 3: No L1/L2 Regularization",
        apply_log_transform=True, # Revert other parameters to baseline for isolated effect
        validation_test_size=0.2,
        l1_lambda=0.0,
        l2_lambda=0.0
    )
    results["Ablation 3: No L1/L2 Regularization"] = no_l1_l2_reg_rmse

    print("\n--- Ablation Study Summary ---")
    for name, rmse in results.items():
        print(f"{name}: RMSE = {rmse:.4f}")

    # Determine most impactful component
    baseline_rmse = results["Baseline"]
    
    best_change_name = None
    max_impact_value = 0.0 # Absolute difference from baseline
    impact_description = "" # "improvement" or "degradation"

    # Evaluate impact of each ablation
    for name, rmse in results.items():
        if name == "Baseline":
            continue
        
        diff = baseline_rmse - rmse # Positive diff means new RMSE is lower (improvement)
        
        print(f"Impact of '{name}': {'improved' if diff > 0 else 'degraded'} by {abs(diff):.4f} RMSE")
        
        if abs(diff) > max_impact_value:
            max_impact_value = abs(diff)
            best_change_name = name
            impact_description = "positive contribution (improvement)" if diff > 0 else "negative contribution (degradation)"

    if best_change_name:
        print(f"\nThe part that contributes the most to the overall performance (largest absolute impact) is: '{best_change_name}'. "
              f"It resulted in a {impact_description} of {max_impact_value:.4f} RMSE compared to the baseline.")
    else:
        print("\nNo ablations were performed or no significant impact was observed.")

if __name__ == "__main__":
    main()
