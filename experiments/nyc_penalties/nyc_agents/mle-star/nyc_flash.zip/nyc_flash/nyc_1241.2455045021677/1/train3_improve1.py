
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import catboost as cb
import os
import lightgbm as lgb
import gc

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv'

import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder

# Assume STREET_NAME_COL, VIOLATION_DESC_COL, and TARGET_COLUMN are defined globally
# For demonstration purposes within this block, let's assume default string values
# if they were not defined in the external context. In a real scenario, these
# would be pre-defined constants.
try:
    STREET_NAME_COL
except NameError:
    STREET_NAME_COL = 'Street Name'
try:
    VIOLATION_DESC_COL
except NameError:
    VIOLATION_DESC_COL = 'Violation Description'
try:
    TARGET_COLUMN
except NameError:
    TARGET_COLUMN = 'target' # Placeholder for a target column name

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> (pd.DataFrame, dict):
    """
    Performs feature engineering on the input DataFrame, including frequency encoding
    and text-based features for 'Violation Description'.
    """
    if encoder_dict is None:
        encoder_dict = {}

    # Initialize container for frequency maps if not already present
    if 'frequency_maps' not in encoder_dict:
        encoder_dict['frequency_maps'] = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Get standardized column names for consistent referencing
    street_name_col_std = STREET_NAME_COL.replace(' ', '_').lower()
    violation_desc_col_std = VIOLATION_DESC_COL.replace(' ', '_').lower()

    # Handle missing values for key categorical columns first
    for col_std in [street_name_col_std, violation_desc_col_std]:
        if col_std in df.columns:
            df[col_std] = df[col_std].fillna('unknown').astype(str)

    # --- New: Frequency Encoding for Street Name and Violation Description ---
    cols_for_freq_encoding = [street_name_col_std, violation_desc_col_std]
    for col_std in cols_for_freq_encoding:
        if col_std in df.columns:
            new_freq_col_name = f"{col_std}_freq_encoded"
            if is_training:
                # Calculate and store frequency map from training data
                freq_map = df[col_std].value_counts(normalize=True).to_dict()
                encoder_dict['frequency_maps'][col_std] = freq_map
                df[new_freq_col_name] = df[col_std].map(freq_map)
            else:
                # Apply stored frequency map for non-training data
                if col_std in encoder_dict['frequency_maps']:
                    freq_map = encoder_dict['frequency_maps'][col_std]
                    # Map values, filling unseen categories with 0
                    df[new_freq_col_name] = df[col_std].map(freq_map).fillna(0.0)
                else:
                    # If no map is found, assign a default frequency (e.g., 0)
                    df[new_freq_col_name] = 0.0

    # --- New: Text-based features for Violation Description ---
    if violation_desc_col_std in df.columns:
        # Character length of the description
        df[f"{violation_desc_col_std}_char_len"] = df[violation_desc_col_std].astype(str).apply(len)
        # Word count of the description
        df[f"{violation_desc_col_std}_word_count"] = df[violation_desc_col_std].astype(str).apply(lambda x: len(str(x).split()))

    # Label Encoding for categorical features (existing logic, with improved unseen handling)
    categorical_cols_for_le = [street_name_col_std, violation_desc_col_std]
    for col_std in categorical_cols_for_le:
        if col_std in df.columns:
            new_le_col_name = f"{col_std}_encoded"
            if is_training:
                le = LabelEncoder()
                df[new_le_col_name] = le.fit_transform(df[col_std])
                encoder_dict[col_std] = le # Store the LabelEncoder instance
            else:
                if col_std in encoder_dict:
                    le = encoder_dict[col_std]
                    # Create a mapping dictionary for efficient transformation
                    le_classes_map = {cls: idx for idx, cls in enumerate(le.classes_)}
                    # Use map and fillna(-1) for unseen categories
                    df[new_le_col_name] = df[col_std].map(le_classes_map).fillna(-1).astype(int)
                else:
                    # Assign a default (-1) if no encoder was fitted for this column
                    df[new_le_col_name] = -1

    # Example: Simple interaction feature (existing logic)
    if (f"{street_name_col_std}_encoded" in df.columns) and \
       (f"{violation_desc_col_std}_encoded" in df.columns):
        df['street_violation_interaction'] = \
            df[f"{street_name_col_std}_encoded"] * df[f"{violation_desc_col_std}_encoded"]

    # Log transform target if present and in training mode (existing logic)
    if TARGET_COLUMN in df.columns and is_training:
        df[TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series) -> lgb.Booster:
    """
    Trains a LightGBM model.
    """
    # LightGBM expects feature names as strings
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'regression_l1',  # MAE objective
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 31,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)]) # Use callbacks for early stopping

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional: Path to the 2023 test/evaluation data CSV.')
    args = parser.parse_args()

    print(f"Loading training data from: {args.train_path}")
    df_2022_raw, encoder_dict = load_and_preprocess_data(args.train_path, is_training=True)

    # Split 2022 data for training and validation
    # Use grouped holdout for (street_name, violation_type) pairs
    # Create a unique identifier for splitting
    df_2022_raw['group_id'] = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

    # Get unique groups
    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    # Drop the temporary group_id
    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    # Define features and target
    features = [col for col in df_train_raw.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]]

    # Prepare training data
    X_train = df_train_raw[features]
    y_train = df_train_raw[TARGET_COLUMN]

    # Prepare validation data - CRITICAL FIX HERE: Extract y_val *before* any potential dropping or mismatch
    X_val = df_val_raw[features]
    y_val = df_val_raw[TARGET_COLUMN] # This ensures y_val is correctly assigned from the raw df_val_raw

    print("Training model...")
    model = train_model(X_train, y_train, X_val, y_val)

    # Predict on validation set for performance reporting
    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log) # Inverse transform
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(np.expm1(y_val), val_predictions) # Calculate RMSE on original scale
    print(f"Final Validation Performance: {final_validation_rmse}")

    # If a test path is provided, generate predictions
    if args.test_path:
        print(f"Loading test data from: {args.test_path}")
        df_test_raw, _ = load_and_preprocess_data(args.test_path, is_training=False, encoder_dict=encoder_dict)

        # Ensure test data has the same features as training data
        test_features = [col for col in features if col in df_test_raw.columns]
        X_test = df_test_raw[test_features]

        # Align columns - crucial for consistent predictions
        # Add missing columns to X_test with 0, remove extra columns
        missing_cols = set(X_train.columns) - set(X_test.columns)
        for c in missing_cols:
            X_test[c] = 0
        extra_cols = set(X_test.columns) - set(X_train.columns)
        X_test = X_test.drop(columns=list(extra_cols))
        X_test = X_test[X_train.columns] # Ensure column order is the same

        print("Generating predictions for test data...")
        test_predictions_log = model.predict(X_test)
        test_predictions = np.expm1(test_predictions_log) # Inverse transform
        test_predictions[test_predictions < 0] = 0 # Clip negative predictions
        test_predictions = np.round(test_predictions).astype(int) # Round to nearest integer

        # Create submission file
        submission_df = pd.DataFrame({
            STREET_NAME_COL: df_test_raw[STREET_NAME_COL.replace(' ', '_').lower()],
            VIOLATION_DESC_COL: df_test_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()],
            PREDICTED_COUNT_COL: test_predictions
        })
        # Original column names for submission
        submission_df.columns = [STREET_NAME_COL, VIOLATION_DESC_COL, PREDICTED_COUNT_COL]

        submission_df.to_csv(OUTPUT_SUBMISSION_FILE, index=False)
        print(f"Submission file '{OUTPUT_SUBMISSION_FILE}' created successfully.")

        # If test_path contains 'violation_count', calculate RMSE
        if TARGET_COLUMN in df_test_raw.columns:
            y_test_true = np.expm1(df_test_raw[TARGET_COLUMN]) # Inverse log transform for actual values
            test_rmse = calculate_rmse(y_test_true, test_predictions)
            print(f"RMSE on provided test/evaluation data: {test_rmse}")

            # Report unseen key pairs
            train_keys = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]
            test_keys = df_test_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + df_test_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

            unseen_keys_count = test_keys.isin(train_keys).value_counts().get(False, 0)
            total_test_keys = len(test_keys)
            print(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {unseen_keys_count} out of {total_test_keys}")
            print("Unseen pairs are handled by the model's ability to generalize based on encoded features and numerical interaction features, "
                  "and by assigning -1 for unknown categories during Label Encoding transform.")

    gc.collect()

if __name__ == "__main__":
    main()
