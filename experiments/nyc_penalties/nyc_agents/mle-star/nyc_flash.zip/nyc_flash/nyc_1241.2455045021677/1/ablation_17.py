
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc
import os
import sys
from io import StringIO

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv'

def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None, map_unknown_to_zero: bool = False) -> pd.DataFrame:
    """
    Performs feature engineering on the input DataFrame.
    Modified to include map_unknown_to_zero flag.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Handle missing values
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Label Encoding for categorical features
    categorical_cols = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col] = le
            else:
                if col in encoder_dict:
                    # Use transform for existing categories, map unknown to specified value
                    default_value = 0 if map_unknown_to_zero else -1
                    df[col + '_encoded'] = df[col].map(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else default_value)
                else:
                    # Assign a default for entirely new categories if no encoder
                    df[col + '_encoded'] = 0 if map_unknown_to_zero else -1 

    # Log transform target if present, good for count data
    if TARGET_COLUMN in df.columns and is_training:
        df[TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None, map_unknown_to_zero: bool = False) -> pd.DataFrame:
    """
    Loads data from a CSV file and applies initial preprocessing.
    Modified to pass map_unknown_to_zero flag.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict, map_unknown_to_zero=map_unknown_to_zero)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series, sanitize_feature_names: bool = True) -> lgb.Booster:
    """
    Trains a LightGBM model.
    Modified to include sanitize_feature_names flag.
    """
    # LightGBM expects feature names as strings, and sometimes has issues with special characters.
    if sanitize_feature_names:
        X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
        X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'poisson',
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 63,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)])

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_main_logic(train_path, test_path,
                   sanitize_feature_names_flag: bool = True,
                   exclude_street_name_encoded: bool = False,
                   map_unknown_to_zero_flag: bool = False):
    """
    Encapsulates the main training and validation logic for ablation study.
    """
    # Use a StringIO object to capture stdout
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()

    try:
        print(f"Loading training data from: {train_path}")
        df_2022_raw, encoder_dict = load_and_preprocess_data(train_path, is_training=True, map_unknown_to_zero=map_unknown_to_zero_flag)

        # Split 2022 data for training and validation
        # Use grouped holdout for (street_name, violation_type) pairs with stratification
        df_2022_raw['group_id'] = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                                df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

        group_id_counts = df_2022_raw['group_id'].value_counts()
        unique_groups = df_2022_raw['group_id'].unique()
        stratify_by_counts = [group_id_counts[group] for group in unique_groups]

        train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42, stratify=stratify_by_counts)

        df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
        df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

        df_train_raw = df_train_raw.drop(columns=['group_id'])
        df_val_raw = df_val_raw.drop(columns=['group_id'])
        
        # Define features and target
        features = [col for col in df_train_raw.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]]

        if exclude_street_name_encoded:
            features = [f for f in features if f != (STREET_NAME_COL.replace(' ', '_').lower() + '_encoded')]

        X_train = df_train_raw[features]
        y_train = df_train_raw[TARGET_COLUMN]

        X_val = df_val_raw[features]
        y_val = df_val_raw[TARGET_COLUMN]

        print("Training model...")
        model = train_model(X_train, y_train, X_val, y_val, sanitize_feature_names=sanitize_feature_names_flag)

        val_predictions_log = model.predict(X_val)
        val_predictions = np.expm1(val_predictions_log)
        val_predictions[val_predictions < 0] = 0

        final_validation_rmse = calculate_rmse(np.expm1(y_val), val_predictions)
        print(f"Final Validation Performance: {final_validation_rmse}")

        # The test path logic is skipped as per instructions
        gc.collect()
        return final_validation_rmse
    finally:
        sys.stdout = old_stdout # Restore stdout
    
def run_main_script_for_ablation(train_path: str, ablation_config: dict) -> float:
    """
    Runs the main logic with specific ablation configurations and returns the final RMSE.
    """
    class DummyArgs:
        def __init__(self, train_path, test_path):
            self.train_path = train_path
            self.test_path = test_path # None as per instruction

    args = DummyArgs(train_path, None)

    rmse = run_main_logic(
        args.train_path,
        args.test_path,
        sanitize_feature_names_flag=ablation_config.get('sanitize_feature_names', True),
        exclude_street_name_encoded=ablation_config.get('exclude_street_name_encoded', False),
        map_unknown_to_zero_flag=ablation_config.get('map_unknown_to_zero', False)
    )
    return rmse

def main_ablation_study():
    train_data_path = './input/violations_per_street_2022.csv'

    # Create dummy data if not exists for local testing
    if not os.path.exists('./input'):
        os.makedirs('./input')
    if not os.path.exists(train_data_path):
        print(f"Creating a dummy CSV for {train_data_path}...")
        dummy_data = {
            'Street Name': ['1ST ST', '2ND ST', '1ST ST', '3RD AVE', '2ND ST', '1ST ST', '4TH BLVD', '3RD AVE', '5TH AVE', '6TH ST'],
            'Violation Description': ['PARKING', 'NO STANDING', 'PARKING', 'SPEEDING', 'PARKING', 'NO STANDING', 'PARKING', 'SPEEDING', 'PARKING', 'NO STANDING'],
            'violation_count': [100, 150, 120, 50, 130, 110, 90, 60, 180, 70]
        }
        pd.DataFrame(dummy_data).to_csv(train_data_path, index=False)
        print("Dummy CSV created. Please replace with actual data for meaningful results.")

    print("Running baseline model...")
    baseline_rmse = run_main_script_for_ablation(train_data_path, {})
    print(f"Baseline Validation RMSE: {baseline_rmse:.4f}\n")

    ablation_results = {}

    # Ablation 1: Disable LGBM Feature Name Sanitization
    print("Running Ablation 1: Disable LGBM Feature Name Sanitization...")
    ablation1_rmse = run_main_script_for_ablation(train_data_path, {'sanitize_feature_names': False})
    ablation_results['Disable LGBM Feature Name Sanitization'] = ablation1_rmse
    print(f"Ablation 1 Validation RMSE: {ablation1_rmse:.4f} (Impact vs Baseline: {ablation1_rmse - baseline_rmse:.4f})\n")

    # Ablation 2: Remove 'street_name_encoded' feature
    print("Running Ablation 2: Remove 'street_name_encoded' feature...")
    ablation2_rmse = run_main_script_for_ablation(train_data_path, {'exclude_street_name_encoded': True})
    ablation_results['Remove street_name_encoded feature'] = ablation2_rmse
    print(f"Ablation 2 Validation RMSE: {ablation2_rmse:.4f} (Impact vs Baseline: {ablation2_rmse - baseline_rmse:.4f})\n")

    # Ablation 3: Change unknown category mapping from -1 to 0 in LabelEncoder
    print("Running Ablation 3: Map unknown categories to 0...")
    ablation3_rmse = run_main_script_for_ablation(train_data_path, {'map_unknown_to_zero': True})
    ablation_results['Map unknown categories to 0'] = ablation3_rmse
    print(f"Ablation 3 Validation RMSE: {ablation3_rmse:.4f} (Impact vs Baseline: {ablation3_rmse - baseline_rmse:.4f})\n")

    print("\n--- Ablation Study Summary ---")
    print(f"Baseline: RMSE = {baseline_rmse:.4f}")

    # Calculate impacts and print for each ablation
    impacts = {}
    for name, rmse_val in ablation_results.items():
        impact = rmse_val - baseline_rmse
        impacts[name] = impact
        print(f"{name}: RMSE = {rmse_val:.4f} (Impact vs Baseline: {impact:.4f})")

    # Determine the most impactful change
    best_ablation_name = None
    min_rmse = baseline_rmse

    for name, rmse_val in ablation_results.items():
        if rmse_val < min_rmse:
            min_rmse = rmse_val
            best_ablation_name = name

    if best_ablation_name:
        print(f"\nThe part of the code that resulted in the best overall performance (lowest RMSE) was: '{best_ablation_name}' (RMSE: {min_rmse:.4f}, an improvement of {min_rmse - baseline_rmse:.4f} compared to baseline).")
    else:
        # If no ablation improved, then baseline was the best.
        # Report that baseline was best, and which ablation was most detrimental.
        if impacts: # Ensure impacts dict is not empty
            max_degradation_name = max(impacts, key=impacts.get)
            max_degradation_impact = impacts[max_degradation_name]
            
            print(f"\nNone of the ablations improved the performance. The baseline was the best (RMSE: {baseline_rmse:.4f}).")
            if max_degradation_impact > 0:
                print(f"The most detrimental change was: '{max_degradation_name}' (RMSE: {ablation_results[max_degradation_name]:.4f}, a degradation of {max_degradation_impact:.4f}).")
            else: # All impacts were zero or negative (but not better than baseline)
                print("All tested ablations had no significant impact or slightly detrimental effects compared to the baseline.")
        else:
            print("\nNo ablations were performed to compare against the baseline.")


if __name__ == "__main__":
    main_ablation_study()
