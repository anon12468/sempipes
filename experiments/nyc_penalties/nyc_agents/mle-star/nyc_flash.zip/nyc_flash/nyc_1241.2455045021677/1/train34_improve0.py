
import pandas as pd
import numpy as np
import argparse
import os
from catboost import CatBoostRegressor, Pool
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

# Helper function for RMSE
def rmse(y_true, y_pred):
    """Calculates the Root Mean Squared Error."""
    return np.sqrt(mean_squared_error(y_true, y_pred))

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument("--train-path", type=str, default="violations_per_street_2022.csv",
                        help="Path to the training data file (2022 violations).")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Path to the test/evaluation data file.")
    args = parser.parse_args()

    # Define paths for input files. Assume auxiliary files are in './input' directory.
    input_dir = "./input"
    train_file = os.path.join(input_dir, args.train_path) if args.train_path == "violations_per_street_2022.csv" else args.train_path

    # --- Data Loading ---
    print(f"Loading training data from {train_file}...")
    try:
        train_df = pd.read_csv(train_file)
    except FileNotFoundError:
        print(f"Error: Training file not found at {train_file}. Please check the path and ensure it exists.")
        return # Exit if the main training file is not found

    # Rename columns for consistency and easier access
    train_df.rename(columns={'Street Name': 'street_name', 'Violation Description': 'violation_type', 'violation_count': 'violation_count'}, inplace=True)

    # Load augmentation tables
    print("Loading augmentation tables...")
    augmentation_dfs = {}
    augmentation_files = {
        # Note: census, weather, and holidays are not used directly due to lack of a time column in train_df
        # or clear, direct join keys at the street/violation level.
        "parking_zones": "nyc_parking_zones.csv",
        "ticket_codes": "parking_ticket_codes.csv",
        "violation_descriptions": "violation_descriptions.csv"
    }

    for key, filename in augmentation_files.items():
        try:
            filepath = os.path.join(input_dir, filename)
            augmentation_dfs[key] = pd.read_csv(filepath)
            print(f"  Loaded {filename}")
        except FileNotFoundError:
            print(f"  Warning: Augmentation file {filename} not found at {filepath}. Skipping this file.")
            augmentation_dfs[key] = pd.DataFrame() # Create empty DF if not found

    # --- Feature Engineering and Merging ---
    print("Performing feature engineering and merging...")

    # Merge parking zone information
    if not augmentation_dfs['parking_zones'].empty:
        parking_zones_df = augmentation_dfs['parking_zones'].copy()
        parking_zones_df.rename(columns={'Street Name': 'street_name', 'Zone ID': 'zone_id', 'Borough': 'borough', 'Zip Code': 'zip_code'}, inplace=True)
        # Select relevant columns and drop duplicates before merging to avoid fan-out issues
        parking_zones_df = parking_zones_df[['street_name', 'zone_id', 'borough', 'zip_code']].drop_duplicates(subset=['street_name'])
        train_df = pd.merge(train_df, parking_zones_df, on='street_name', how='left')
    else:
        print("  Skipping parking zone merge as data is not available.")
        # Add placeholder columns to avoid KeyErrors later if these features are expected
        train_df['zone_id'] = np.nan
        train_df['borough'] = np.nan
        train_df['zip_code'] = np.nan

    # Merge violation descriptions for enrichment
    if not augmentation_dfs['violation_descriptions'].empty:
        violation_descriptions_df = augmentation_dfs['violation_descriptions'].copy()
        violation_descriptions_df.rename(columns={'Violation Description': 'violation_type', 'Category': 'violation_category', 'Severity': 'violation_severity'}, inplace=True)
        # Select relevant columns and drop duplicates
        violation_descriptions_df = violation_descriptions_df[['violation_type', 'violation_category', 'violation_severity']].drop_duplicates(subset=['violation_type'])
        train_df = pd.merge(train_df, violation_descriptions_df, on='violation_type', how='left')
    else:
        print("  Skipping violation descriptions merge as data is not available.")
        train_df['violation_category'] = np.nan
        train_df['violation_severity'] = np.nan

    # Merge parking ticket codes
    if not augmentation_dfs['ticket_codes'].empty:
        ticket_codes_df = augmentation_dfs['ticket_codes'].copy()
        ticket_codes_df.rename(columns={'Violation Description': 'violation_type', 'Violation Code': 'violation_code', 'Fine Amount': 'fine_amount'}, inplace=True)
        # Select relevant columns and drop duplicates
        ticket_codes_df = ticket_codes_df[['violation_type', 'violation_code', 'fine_amount']].drop_duplicates(subset=['violation_type'])
        train_df = pd.merge(train_df, ticket_codes_df, on='violation_type', how='left')
    else:
        print("  Skipping ticket codes merge as data is not available.")
        train_df['violation_code'] = np.nan
        train_df['fine_amount'] = np.nan

    print("  Skipping census, weather, and holidays data merges due to lack of direct join keys or temporal information for accurate feature creation.")

    # Define all potential features after merges
    all_potential_features = ['street_name', 'violation_type', 'zone_id', 'borough', 'zip_code',
                              'violation_category', 'violation_severity', 'violation_code', 'fine_amount']

    # Separate into categorical and numerical
    # Categorical features
    categorical_features = ['street_name', 'violation_type', 'zone_id', 'borough', 'violation_category', 'violation_code']
    # Numerical features. 'zip_code' can sometimes be treated as categorical, but here it's assumed numerical or ordinal.
    numerical_features = ['zip_code', 'fine_amount', 'violation_severity']

    # Filter features to only include those that actually exist in the dataframe after all merges
    features = [f for f in all_potential_features if f in train_df.columns]
    categorical_features = [f for f in categorical_features if f in train_df.columns]
    numerical_features = [f for f in numerical_features if f in train_df.columns]

    # Fill NaN for categorical features with a placeholder 'UNKNOWN_CAT'
    for col in categorical_features:
        train_df[col] = train_df[col].fillna('UNKNOWN_CAT')

    # Fill NaN for numerical features with 0 (a common simple imputation, median/mean could also be used)
    for col in numerical_features:
        train_df[col] = train_df[col].fillna(0)

    # Convert counts to log1p scale for training, which often helps with skewed count data
    train_df['violation_count_log'] = np.log1p(train_df['violation_count'])

    target = 'violation_count_log'

    # --- Training/Validation Split ---
    print("Splitting data for training and validation (80/20 split)...")
    X = train_df[features]
    y = train_df[target]

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    # Create CatBoost Pool objects, explicitly specifying categorical features
    train_pool = Pool(X_train, y_train, cat_features=categorical_features)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features)

    # --- Model Training ---
    print("Training CatBoost Regressor model...")
    # CatBoost parameters. Using CPU by default for broader compatibility.
    # Adjust iterations, learning_rate, depth etc. for optimal performance.
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=8,
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=100, # Print metrics every 100 iterations
        early_stopping_rounds=50, # Stop if validation RMSE doesn't improve for 50 rounds
        # task_type='GPU', # Uncomment and set devices='0' etc. if a GPU is available and desired
        # devices='0'
    )

    model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=50)

    # --- Validation Performance ---
    val_preds_log = model.predict(val_pool)
    val_preds = np.expm1(val_preds_log) # Inverse transform predictions
    val_preds[val_preds < 0] = 0 # Clip any negative predictions to 0

    final_validation_score = rmse(np.expm1(y_val), val_preds) # Calculate RMSE on original scale
    print(f"Final Validation Performance: {final_validation_score}")

    # --- Prediction for Test/Evaluation Path ---
    if args.test_path:
        print(f"Loading test data from {args.test_path} for prediction...")
        test_file = args.test_path
        try:
            test_df = pd.read_csv(test_file)
        except FileNotFoundError:
            print(f"Error: Test file not found at {test_file}. Skipping prediction.")
            return

        test_df_original = test_df.copy() # Keep a copy for output
        test_df.rename(columns={'Street Name': 'street_name', 'Violation Description': 'violation_type', 'violation_count': 'violation_count'}, inplace=True)

        # Apply the same feature engineering steps to the test data
        if not augmentation_dfs['parking_zones'].empty:
            parking_zones_df_test = augmentation_dfs['parking_zones'].copy()
            parking_zones_df_test.rename(columns={'Street Name': 'street_name', 'Zone ID': 'zone_id', 'Borough': 'borough', 'Zip Code': 'zip_code'}, inplace=True)
            parking_zones_df_test = parking_zones_df_test[['street_name', 'zone_id', 'borough', 'zip_code']].drop_duplicates(subset=['street_name'])
            test_df = pd.merge(test_df, parking_zones_df_test, on='street_name', how='left')
        else:
            test_df['zone_id'] = np.nan
            test_df['borough'] = np.nan
            test_df['zip_code'] = np.nan

        if not augmentation_dfs['violation_descriptions'].empty:
            violation_descriptions_df_test = augmentation_dfs['violation_descriptions'].copy()
            violation_descriptions_df_test.rename(columns={'Violation Description': 'violation_type', 'Category': 'violation_category', 'Severity': 'violation_severity'}, inplace=True)
            violation_descriptions_df_test = violation_descriptions_df_test[['violation_type', 'violation_category', 'violation_severity']].drop_duplicates(subset=['violation_type'])
            test_df = pd.merge(test_df, violation_descriptions_df_test, on='violation_type', how='left')
        else:
            test_df['violation_category'] = np.nan
            test_df['violation_severity'] = np.nan

        if not augmentation_dfs['ticket_codes'].empty:
            ticket_codes_df_test = augmentation_dfs['ticket_codes'].copy()
            ticket_codes_df_test.rename(columns={'Violation Description': 'violation_type', 'Violation Code': 'violation_code', 'Fine Amount': 'fine_amount'}, inplace=True)
            ticket_codes_df_test = ticket_codes_df_test[['violation_type', 'violation_code', 'fine_amount']].drop_duplicates(subset=['violation_type'])
            test_df = pd.merge(test_df, ticket_codes_df_test, on='violation_type', how='left')
        else:
            test_df['violation_code'] = np.nan
            test_df['fine_amount'] = np.nan

        # Ensure all features used in training are present in test_df and handle NaNs
        for col in categorical_features:
            if col in test_df.columns:
                test_df[col] = test_df[col].fillna('UNKNOWN_CAT')
            else:
                test_df[col] = 'UNKNOWN_CAT' # Add column if missing from test data

        for col in numerical_features:
            if col in test_df.columns:
                test_df[col] = test_df[col].fillna(0) # Fill numerical NaNs with 0
            else:
                test_df[col] = 0 # Add column if missing from test data

        # Create CatBoost Pool for prediction
        # Ensure the feature order and presence match training data
        test_pool = Pool(test_df[features], cat_features=categorical_features)
        predictions_log = model.predict(test_pool)
        predictions = np.expm1(predictions_log)
        predictions[predictions < 0] = 0 # Clip negative predictions
        predictions = np.round(predictions).astype(int) # Round to nearest integer

        test_df_original['predicted_count'] = predictions

        # Save submission file
        submission_df = test_df_original[['street_name', 'violation_type', 'predicted_count']]
        submission_df.to_csv("submission.csv", index=False)
        print("Predictions saved to submission.csv")

        # Report RMSE if 'violation_count' is present and not all null in the test file
        if 'violation_count' in test_df_original.columns and not test_df_original['violation_count'].isnull().all():
            actual_counts = test_df_original['violation_count']
            test_rmse = rmse(actual_counts, predictions)
            print(f"RMSE on the provided test/evaluation file: {test_rmse}")

            # Report on unseen key pairs
            train_keys = set(train_df.apply(lambda row: (row['street_name'], row['violation_type']), axis=1))
            test_keys = set(test_df_original.apply(lambda row: (row['street_name'], row['violation_type']), axis=1))
            unseen_keys_count = len(test_keys - train_keys)
            print(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {unseen_keys_count} out of {len(test_keys)} total pairs.")
            print("Unseen pairs were handled by CatBoost's internal mechanisms for unknown categories and feature filling strategy (e.g., 'UNKNOWN_CAT' for new categorical values, 0 for new numerical features).")
        else:
            print("Test file does not contain 'violation_count' or it's all null, so RMSE for test data cannot be computed.")


if __name__ == "__main__":
    main()
