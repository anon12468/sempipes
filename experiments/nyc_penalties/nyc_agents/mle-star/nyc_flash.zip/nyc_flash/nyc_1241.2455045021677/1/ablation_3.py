
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc
import copy

# Define constants (as in the provided solution)
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv' # Not directly used in ablation but kept for completeness

# --- Functions from the original script, adapted for ablation ---
def _engineer_features(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None, enable_temporal_features: bool = True) -> (pd.DataFrame, dict):
    """
    Performs feature engineering on the input DataFrame.
    Includes an option to disable temporal features.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Handle missing values
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Label Encoding for categorical features
    categorical_cols = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col] = le
            else:
                if col in encoder_dict:
                    df[col + '_encoded'] = df[col].map(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else -1)
                else:
                    df[col + '_encoded'] = -1

    # Example: Simple interaction feature
    if (STREET_NAME_COL.replace(' ', '_').lower() + '_encoded' in df.columns) and \
       (VIOLATION_DESC_COL.replace(' ', '_').lower() + '_encoded' in df.columns):
        df['street_violation_interaction'] = df[STREET_NAME_COL.replace(' ', '_').lower() + '_encoded'] * df[VIOLATION_DESC_COL.replace(' ', '_').lower() + '_encoded']

    # Temporal feature engineering (controlled by enable_temporal_features)
    if enable_temporal_features:
        ISSUE_DATE_COL = 'issue_date'
        if ISSUE_DATE_COL in df.columns:
            df[ISSUE_DATE_COL] = pd.to_datetime(df[ISSUE_DATE_COL], errors='coerce')
            df['issue_year'] = df[ISSUE_DATE_COL].dt.year
            df['issue_month'] = df[ISSUE_DATE_COL].dt.month
            df['issue_day_of_week'] = df[ISSUE_DATE_COL].dt.dayofweek
            df['issue_hour'] = df[ISSUE_DATE_COL].dt.hour
            df['is_weekend'] = df['issue_day_of_week'].isin([5, 6]).astype(int)

            for temp_col in ['issue_year', 'issue_month', 'issue_day_of_week', 'issue_hour']:
                if temp_col in df.columns:
                    df[temp_col] = df[temp_col].fillna(-1).astype(int)
            if 'is_weekend' in df.columns:
                df['is_weekend'] = df['is_weekend'].fillna(0).astype(int)

    # Log transform target if present, good for count data
    if TARGET_COLUMN in df.columns and is_training:
        df[TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None, enable_temporal_features: bool = True) -> (pd.DataFrame, dict):
    """
    Loads data from a CSV file and applies initial preprocessing.
    """
    df = pd.read_csv(file_path)
    df, encoder_dict = _engineer_features(df.copy(), is_training=is_training, encoder_dict=encoder_dict, enable_temporal_features=enable_temporal_features)
    return df, encoder_dict

def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series, model_params: dict) -> lgb.Booster:
    """
    Trains a LightGBM model with given parameters.
    """
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    model = lgb.LGBMRegressor(**model_params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)])

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_ablation_study():
    parser = argparse.ArgumentParser(description="Perform ablation study on NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args, unknown = parser.parse_known_args() # Use parse_known_args to ignore other args

    train_path = args.train_path

    # --- Baseline Run ---
    print("\n--- Running Baseline Model ---")
    df_2022_raw, encoder_dict_baseline = load_and_preprocess_data(train_path, is_training=True, enable_temporal_features=True)

    df_2022_raw['group_id'] = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]
    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)
    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])

    features_baseline = [col for col in df_train_raw.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower(), 'issue_date']]
    X_train_baseline = df_train_raw[features_baseline]
    y_train_baseline = df_train_raw[TARGET_COLUMN]
    X_val_baseline = df_val_raw[features_baseline]
    y_val_baseline = df_val_raw[TARGET_COLUMN]

    params_baseline = {
        'objective': 'regression_l1',
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 31,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model_baseline = train_model(X_train_baseline, y_train_baseline, X_val_baseline, y_val_baseline, params_baseline)
    val_predictions_log_baseline = model_baseline.predict(X_val_baseline)
    val_predictions_baseline = np.expm1(val_predictions_log_baseline)
    val_predictions_baseline[val_predictions_baseline < 0] = 0
    rmse_baseline = calculate_rmse(np.expm1(y_val_baseline), val_predictions_baseline)
    print(f"Baseline Validation RMSE: {rmse_baseline:.4f}")

    ablation_results = {"Baseline": rmse_baseline}

    del df_2022_raw, df_train_raw, df_val_raw, X_train_baseline, y_train_baseline, X_val_baseline, y_val_baseline, model_baseline
    gc.collect()

    # --- Ablation 1: Remove Temporal Features ---
    print("\n--- Ablation 1: Removing Temporal Features ---")
    df_2022_ablation1, encoder_dict_ablation1 = load_and_preprocess_data(train_path, is_training=True, enable_temporal_features=False)

    df_2022_ablation1['group_id'] = df_2022_ablation1[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                                    df_2022_ablation1[VIOLATION_DESC_COL.replace(' ', '_').lower()]
    unique_groups_ablation1 = df_2022_ablation1['group_id'].unique()
    train_groups_ablation1, val_groups_ablation1 = train_test_split(unique_groups_ablation1, test_size=0.2, random_state=42)
    df_train_ablation1 = df_2022_ablation1[df_2022_ablation1['group_id'].isin(train_groups_ablation1)].copy()
    df_val_ablation1 = df_2022_ablation1[df_2022_ablation1['group_id'].isin(val_groups_ablation1)].copy()

    df_train_ablation1 = df_train_ablation1.drop(columns=['group_id'])
    df_val_ablation1 = df_val_ablation1.drop(columns=['group_id'])

    features_ablation1 = [col for col in df_train_ablation1.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower(), 'issue_date']]
    X_train_ablation1 = df_train_ablation1[features_ablation1]
    y_train_ablation1 = df_train_ablation1[TARGET_COLUMN]
    X_val_ablation1 = df_val_ablation1[features_ablation1]
    y_val_ablation1 = df_val_ablation1[TARGET_COLUMN]

    model_ablation1 = train_model(X_train_ablation1, y_train_ablation1, X_val_ablation1, y_val_ablation1, params_baseline)
    val_predictions_log_ablation1 = model_ablation1.predict(X_val_ablation1)
    val_predictions_ablation1 = np.expm1(val_predictions_log_ablation1)
    val_predictions_ablation1[val_predictions_ablation1 < 0] = 0
    rmse_ablation1 = calculate_rmse(np.expm1(y_val_ablation1), val_predictions_ablation1)
    print(f"Ablation 1 (No Temporal Features) Validation RMSE: {rmse_ablation1:.4f}")
    ablation_results["No Temporal Features"] = rmse_ablation1

    del df_2022_ablation1, df_train_ablation1, df_val_ablation1, X_train_ablation1, y_train_ablation1, X_val_ablation1, y_val_ablation1, model_ablation1
    gc.collect()

    # --- Ablation 2: Modifying LightGBM num_leaves to 10 (from 31) ---
    print("\n--- Ablation 2: Modifying LightGBM num_leaves to 10 ---")
    params_ablation2 = copy.deepcopy(params_baseline)
    params_ablation2['num_leaves'] = 10

    # Reload and preprocess data to ensure clean state
    df_2022_ablation2, encoder_dict_ablation2 = load_and_preprocess_data(train_path, is_training=True, enable_temporal_features=True)
    df_2022_ablation2['group_id'] = df_2022_ablation2[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                                    df_2022_ablation2[VIOLATION_DESC_COL.replace(' ', '_').lower()]
    unique_groups_ablation2 = df_2022_ablation2['group_id'].unique()
    train_groups_ablation2, val_groups_ablation2 = train_test_split(unique_groups_ablation2, test_size=0.2, random_state=42)
    df_train_ablation2 = df_2022_ablation2[df_2022_ablation2['group_id'].isin(train_groups_ablation2)].copy()
    df_val_ablation2 = df_2022_ablation2[df_2022_ablation2['group_id'].isin(val_groups_ablation2)].copy()
    df_train_ablation2 = df_train_ablation2.drop(columns=['group_id'])
    df_val_ablation2 = df_val_ablation2.drop(columns=['group_id'])

    features_ablation2 = [col for col in df_train_ablation2.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower(), 'issue_date']]
    X_train_ablation2 = df_train_ablation2[features_ablation2]
    y_train_ablation2 = df_train_ablation2[TARGET_COLUMN]
    X_val_ablation2 = df_val_ablation2[features_ablation2]
    y_val_ablation2 = df_val_ablation2[TARGET_COLUMN]

    model_ablation2 = train_model(X_train_ablation2, y_train_ablation2, X_val_ablation2, y_val_ablation2, params_ablation2)
    val_predictions_log_ablation2 = model_ablation2.predict(X_val_ablation2)
    val_predictions_ablation2 = np.expm1(val_predictions_log_ablation2)
    val_predictions_ablation2[val_predictions_ablation2 < 0] = 0
    rmse_ablation2 = calculate_rmse(np.expm1(y_val_ablation2), val_predictions_ablation2)
    print(f"Ablation 2 (num_leaves = 10) Validation RMSE: {rmse_ablation2:.4f}")
    ablation_results["num_leaves = 10"] = rmse_ablation2

    del df_2022_ablation2, df_train_ablation2, df_val_ablation2, X_train_ablation2, y_train_ablation2, X_val_ablation2, y_val_ablation2, model_ablation2
    gc.collect()

    # --- Ablation 3: Removing Feature/Bagging Fraction (setting to 1.0) ---
    print("\n--- Ablation 3: Removing Feature/Bagging Fraction (setting to 1.0) ---")
    params_ablation3 = copy.deepcopy(params_baseline)
    params_ablation3['feature_fraction'] = 1.0
    params_ablation3['bagging_fraction'] = 1.0
    params_ablation3['bagging_freq'] = 1 # Keep freq at 1, but with fraction 1.0, it's effectively disabled

    # Reload and preprocess data to ensure clean state
    df_2022_ablation3, encoder_dict_ablation3 = load_and_preprocess_data(train_path, is_training=True, enable_temporal_features=True)
    df_2022_ablation3['group_id'] = df_2022_ablation3[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                                    df_2022_ablation3[VIOLATION_DESC_COL.replace(' ', '_').lower()]
    unique_groups_ablation3 = df_2022_ablation3['group_id'].unique()
    train_groups_ablation3, val_groups_ablation3 = train_test_split(unique_groups_ablation3, test_size=0.2, random_state=42)
    df_train_ablation3 = df_2022_ablation3[df_2022_ablation3['group_id'].isin(train_groups_ablation3)].copy()
    df_val_ablation3 = df_2022_ablation3[df_2022_ablation3['group_id'].isin(val_groups_ablation3)].copy()
    df_train_ablation3 = df_train_ablation3.drop(columns=['group_id'])
    df_val_ablation3 = df_val_ablation3.drop(columns=['group_id'])

    features_ablation3 = [col for col in df_train_ablation3.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower(), 'issue_date']]
    X_train_ablation3 = df_train_ablation3[features_ablation3]
    y_train_ablation3 = df_train_ablation3[TARGET_COLUMN]
    X_val_ablation3 = df_val_ablation3[features_ablation3]
    y_val_ablation3 = df_val_ablation3[TARGET_COLUMN]

    model_ablation3 = train_model(X_train_ablation3, y_train_ablation3, X_val_ablation3, y_val_ablation3, params_ablation3)
    val_predictions_log_ablation3 = model_ablation3.predict(X_val_ablation3)
    val_predictions_ablation3 = np.expm1(val_predictions_log_ablation3)
    val_predictions_ablation3[val_predictions_ablation3 < 0] = 0
    rmse_ablation3 = calculate_rmse(np.expm1(y_val_ablation3), val_predictions_ablation3)
    print(f"Ablation 3 (No Feature/Bagging Fraction) Validation RMSE: {rmse_ablation3:.4f}")
    ablation_results["No Feature/Bagging Fraction"] = rmse_ablation3

    del df_2022_ablation3, df_train_ablation3, df_val_ablation3, X_train_ablation3, y_train_ablation3, X_val_ablation3, y_val_ablation3, model_ablation3
    gc.collect()

    print("\n--- Ablation Study Summary ---")
    for scenario, rmse in ablation_results.items():
        diff = rmse - rmse_baseline
        if scenario == "Baseline":
            print(f"- {scenario}: RMSE = {rmse:.4f}")
        else:
            print(f"- {scenario}: RMSE = {rmse:.4f} (Difference from Baseline: {diff:.4f})")

    impacts = {}
    for scenario, rmse in ablation_results.items():
        if scenario != "Baseline":
            impacts[scenario] = rmse - rmse_baseline

    if not impacts:
        print("\nNo ablations performed to compare against baseline.")
        return

    most_positively_contributing_ablation_name = ""
    largest_rmse_increase = 0.0

    for scenario, diff in impacts.items():
        if diff > largest_rmse_increase:
            largest_rmse_increase = diff
            most_positively_contributing_ablation_name = scenario

    if largest_rmse_increase > 0:
        original_part_name = most_positively_contributing_ablation_name
        if "No Temporal Features" in most_positively_contributing_ablation_name:
            original_part_name = "Temporal Features (from 'issue_date')"
        elif "num_leaves = 10" in most_positively_contributing_ablation_name:
            original_part_name = "num_leaves (original value of 31)"
        elif "No Feature/Bagging Fraction" in most_positively_contributing_ablation_name:
            original_part_name = "Feature and Bagging Fraction (original values 0.8)"

        print(f"\nBased on this study, the part of the code that contributes the most to the overall performance is: '{original_part_name}' (its removal/modification led to an RMSE increase of {largest_rmse_increase:.4f}).")
    else:
        print("\nBased on this study, none of the ablated parts showed a significant positive contribution to the overall performance (or their removal improved performance).")

if __name__ == "__main__":
    run_ablation_study()

