
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc

# Define constants (from original script)
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count'
OUTPUT_SUBMISSION_FILE = 'submission.csv' # Not used in ablation, but defined for consistency

# Original _engineer_features for baseline and other ablations using Label Encoding
def _engineer_features_label_encoding(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Performs feature engineering using Label Encoding on categorical features.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    # Handle missing values for categorical columns
    for col in [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Label Encoding for categorical features
    categorical_cols = [STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]
    for col in categorical_cols:
        if col in df.columns:
            if is_training:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col])
                encoder_dict[col] = le
            else:
                if col in encoder_dict:
                    # Use .loc to avoid SettingWithCopyWarning
                    df.loc[:, col + '_encoded'] = df[col].map(lambda s: encoder_dict[col].transform([s])[0] if s in encoder_dict[col].classes_ else -1)
                else:
                    df.loc[:, col + '_encoded'] = -1

    # Log transform target if present and in training
    if TARGET_COLUMN in df.columns and is_training:
        df.loc[:, TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

# Modified _engineer_features for Target Encoding ablation
def _engineer_features_target_encoding(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> pd.DataFrame:
    """
    Performs feature engineering on the input DataFrame, implementing Target Encoding.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower() # Standardize column names

    street_name_col_norm = STREET_NAME_COL.replace(' ', '_').lower()
    violation_desc_col_norm = VIOLATION_DESC_COL.replace(' ', '_').lower()
    
    categorical_cols_to_encode = []
    if street_name_col_norm in df.columns:
        categorical_cols_to_encode.append(street_name_col_norm)
    if violation_desc_col_norm in df.columns:
        categorical_cols_to_encode.append(violation_desc_col_norm)

    # Handle missing values for the relevant categorical columns
    for col in categorical_cols_to_encode:
        if col in df.columns:
            df.loc[:, col] = df[col].fillna('unknown').astype(str)

    # Make a copy of the target column for calculating global_mean for inference
    # and for validation of target encoding before log transform.
    # We use df[TARGET_COLUMN] directly for groupby means because it's untransformed
    # at this point.
    original_target_series_for_global_mean = None
    if TARGET_COLUMN in df.columns and is_training:
        original_target_series_for_global_mean = df[TARGET_COLUMN].copy()
    
    # Target Encoding for specified categorical features
    for col in categorical_cols_to_encode:
        encoded_col_name = col + '_target_encoded'

        if is_training:
            if TARGET_COLUMN in df.columns:
                # FIX: Correctly calculate target means using the string name of the target column.
                # At this point, df[TARGET_COLUMN] still holds the untransformed values.
                target_means = df.groupby(col)[TARGET_COLUMN].mean()
                
                encoder_dict[col] = {
                    'mapping': target_means.to_dict(),
                    'global_mean': original_target_series_for_global_mean.mean() if original_target_series_for_global_mean is not None else 0
                }
                df.loc[:, encoded_col_name] = df[col].map(encoder_dict[col]['mapping'])
            else:
                df.loc[:, encoded_col_name] = 0 # Fallback for safety, though target should be present in training
        else: # Inference phase
            if col in encoder_dict and 'mapping' in encoder_dict[col]:
                df.loc[:, encoded_col_name] = df[col].map(encoder_dict[col]['mapping'])
                df[encoded_col_name].fillna(encoder_dict[col].get('global_mean', 0), inplace=True)
            else:
                df.loc[:, encoded_col_name] = 0
    
    # Log transform target if present and in training (applied after target encoding calculation)
    if TARGET_COLUMN in df.columns and is_training:
        df.loc[:, TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

# General data loading and preprocessing, now takes _engineer_features function as an argument
def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None, engineer_features_func=None) -> pd.DataFrame:
    df = pd.read_csv(file_path)
    df, encoder_dict = engineer_features_func(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    return df, encoder_dict

# General train_model, now takes params as an argument
def train_model(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series, model_params: dict) -> lgb.Booster:
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    model = lgb.LGBMRegressor(**model_params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)])

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_experiment(train_path: str, engineer_features_func, model_params: dict) -> float:
    print(f"Running experiment with feature engineering: {engineer_features_func.__name__} and model params: {model_params}")
    df_2022_raw, encoder_dict = load_and_preprocess_data(train_path, is_training=True, engineer_features_func=engineer_features_func)

    # Create a unique identifier for grouped splitting
    df_2022_raw['group_id'] = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()] + '_' + \
                               df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]

    # Split 2022 data for training and validation using grouped holdout
    unique_groups = df_2022_raw['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
    df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()

    df_train_raw = df_train_raw.drop(columns=['group_id'])
    df_val_raw = df_val_raw.drop(columns=['group_id'])
    
    # Define features based on the engineering function used
    base_excluded_cols = [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]
    
    if engineer_features_func == _engineer_features_target_encoding:
        # Features should include target encoded ones, and exclude original categorical and label encoded
        features = [col for col in df_train_raw.columns if col not in base_excluded_cols]
        features = [f for f in features if not (f.endswith('_encoded') and not f.endswith('_target_encoded'))] # Exclude label encoded
        # Ensure target-encoded features are explicitly included if they exist
        if (STREET_NAME_COL.replace(' ', '_').lower() + '_target_encoded') not in features and \
           (STREET_NAME_COL.replace(' ', '_').lower() + '_target_encoded') in df_train_raw.columns:
            features.append(STREET_NAME_COL.replace(' ', '_').lower() + '_target_encoded')
        if (VIOLATION_DESC_COL.replace(' ', '_').lower() + '_target_encoded') not in features and \
           (VIOLATION_DESC_COL.replace(' ', '_').lower() + '_target_encoded') in df_train_raw.columns:
            features.append(VIOLATION_DESC_COL.replace(' ', '_').lower() + '_target_encoded')
    else: # Default (Label Encoding)
        # Exclude original categorical columns, but keep label encoded ones
        features = [col for col in df_train_raw.columns if col not in base_excluded_cols]
        # Ensure that only the label-encoded versions are present, not target-encoded if somehow generated
        features = [f for f in features if '_target_encoded' not in f]

    X_train = df_train_raw[features]
    y_train = df_train_raw[TARGET_COLUMN]

    X_val = df_val_raw[features]
    y_val = df_val_raw[TARGET_COLUMN]

    print("Training model...")
    model = train_model(X_train, y_train, X_val, y_val, model_params)

    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log) # Inverse transform
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(np.expm1(y_val), val_predictions) # Calculate RMSE on original scale
    print(f"Validation RMSE: {final_validation_rmse:.4f}")
    print(f"Final Validation Performance: {final_validation_rmse}") # Required print for parsing
    gc.collect()
    return final_validation_rmse


def main_ablation():
    parser = argparse.ArgumentParser(description="Ablation study for NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()

    # --- Baseline Configuration ---
    baseline_model_params = {
        'objective': 'poisson',
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 63,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }
    
    print("--- Running Baseline (Label Encoding, Bagging Freq=1, num_leaves=63) ---")
    baseline_rmse = run_experiment(args.train_path, _engineer_features_label_encoding, baseline_model_params)
    print(f"Baseline RMSE: {baseline_rmse:.4f}\n")

    results = {'Baseline': baseline_rmse}

    # --- Ablation 1: Replace Label Encoding with Target Encoding ---
    # Model parameters remain the same as baseline
    ablation1_model_params = baseline_model_params.copy()
    print("--- Running Ablation 1: Replace Label Encoding with Target Encoding ---")
    ablation1_rmse = run_experiment(args.train_path, _engineer_features_target_encoding, ablation1_model_params)
    results['Ablation 1 (Target Encoding)'] = ablation1_rmse
    print(f"Ablation 1 RMSE: {ablation1_rmse:.4f}\n")

    # --- Ablation 2: Disable Bagging (set bagging_freq to 0) ---
    # Uses original Label Encoding for features
    ablation2_model_params = baseline_model_params.copy()
    ablation2_model_params['bagging_freq'] = 0
    print("--- Running Ablation 2: Disable Bagging (bagging_freq=0) ---")
    ablation2_rmse = run_experiment(args.train_path, _engineer_features_label_encoding, ablation2_model_params)
    results['Ablation 2 (No Bagging)'] = ablation2_rmse
    print(f"Ablation 2 RMSE: {ablation2_rmse:.4f}\n")

    # --- Ablation 3: Increase num_leaves to 127 ---
    # Uses original Label Encoding for features
    ablation3_model_params = baseline_model_params.copy()
    ablation3_model_params['num_leaves'] = 127
    print("--- Running Ablation 3: Increase num_leaves to 127 ---")
    ablation3_rmse = run_experiment(args.train_path, _engineer_features_label_encoding, ablation3_model_params)
    results['Ablation 3 (num_leaves=127)'] = ablation3_rmse
    print(f"Ablation 3 RMSE: {ablation3_rmse:.4f}\n")

    print("\n--- Ablation Study Results ---")
    for name, rmse in results.items():
        print(f"{name}: {rmse:.4f}")

    # Determine most positively and negatively contributing parts
    best_rmse_val = min(results.values())
    best_component = [name for name, rmse in results.items() if rmse == best_rmse_val][0]

    worst_rmse_val = max(results.values())
    worst_component = [name for name, rmse in results.items() if rmse == worst_rmse_val][0]
    
    print(f"\nThe part that contributes most positively to the overall performance (achieved lowest RMSE) is: {best_component} with RMSE: {best_rmse_val:.4f}")
    print(f"The part that contributes most negatively to the overall performance (achieved highest RMSE) is: {worst_component} with RMSE: {worst_rmse_val:.4f}")


if __name__ == "__main__":
    main_ablation()
