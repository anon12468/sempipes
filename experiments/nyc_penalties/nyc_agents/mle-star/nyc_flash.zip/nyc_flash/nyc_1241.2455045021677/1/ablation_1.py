
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import gc

# Define constants
TARGET_COLUMN = 'violation_count'
STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
PREDICTED_COUNT_COL = 'predicted_count' # Not used in ablation context but part of original

# --- Original Feature Engineering Function ---
def _engineer_features_original(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> (pd.DataFrame, dict):
    """
    Performs feature engineering on the input DataFrame.
    Includes frequency encoding, label encoding, and interaction feature.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower()

    street_name_col_std = STREET_NAME_COL.replace(' ', '_').lower()
    violation_desc_col_std = VIOLATION_DESC_COL.replace(' ', '_').lower()
    
    for col in [street_name_col_std, violation_desc_col_std]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Frequency Encoding
    freq_encode_cols = [street_name_col_std, violation_desc_col_std]
    for col in freq_encode_cols:
        if col in df.columns:
            new_col_name = col + '_freq_encoded'
            if is_training:
                freq_map = df[col].value_counts(normalize=True).to_dict()
                encoder_dict[new_col_name] = freq_map
                df[new_col_name] = df[col].map(freq_map).fillna(0)
            else:
                if new_col_name in encoder_dict:
                    freq_map = encoder_dict[new_col_name]
                    df[new_col_name] = df[col].map(freq_map).fillna(0)
                else:
                    df[new_col_name] = 0

    # Label Encoding for categorical features
    categorical_cols_for_le = [street_name_col_std, violation_desc_col_std]
    for col in categorical_cols_for_le:
        if col in df.columns:
            le_encoded_col_name = col + '_encoded'
            if is_training:
                le = LabelEncoder()
                df[le_encoded_col_name] = le.fit_transform(df[col])
                encoder_dict[col + '_le'] = le
            else:
                if col + '_le' in encoder_dict:
                    df[le_encoded_col_name] = df[col].astype(str).map(lambda s: encoder_dict[col + '_le'].transform([s])[0] if s in encoder_dict[col + '_le'].classes_ else -1)
                else:
                    df[le_encoded_col_name] = -1

    # Interaction feature
    if (street_name_col_std + '_encoded' in df.columns) and \
       (violation_desc_col_std + '_encoded' in df.columns):
        df['street_violation_interaction'] = df[street_name_col_std + '_encoded'] * df[violation_desc_col_std + '_encoded']

    # Log transform target
    if TARGET_COLUMN in df.columns and is_training:
        df[TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

# --- Ablated Feature Engineering Function: No Frequency Encoding ---
def _engineer_features_no_freq_encoding(df: pd.DataFrame, is_training: bool = True, encoder_dict: dict = None) -> (pd.DataFrame, dict):
    """
    Performs feature engineering but removes the Frequency Encoding step.
    """
    if encoder_dict is None:
        encoder_dict = {}

    df.columns = df.columns.str.replace(' ', '_').str.lower()

    street_name_col_std = STREET_NAME_COL.replace(' ', '_').lower()
    violation_desc_col_std = VIOLATION_DESC_COL.replace(' ', '_').lower()
    
    for col in [street_name_col_std, violation_desc_col_std]:
        if col in df.columns:
            df[col] = df[col].fillna('unknown').astype(str)

    # Label Encoding for categorical features (Frequency encoding is skipped)
    categorical_cols_for_le = [street_name_col_std, violation_desc_col_std]
    for col in categorical_cols_for_le:
        if col in df.columns:
            le_encoded_col_name = col + '_encoded'
            if is_training:
                le = LabelEncoder()
                df[le_encoded_col_name] = le.fit_transform(df[col])
                encoder_dict[col + '_le'] = le
            else:
                if col + '_le' in encoder_dict:
                    df[le_encoded_col_name] = df[col].astype(str).map(lambda s: encoder_dict[col + '_le'].transform([s])[0] if s in encoder_dict[col + '_le'].classes_ else -1)
                else:
                    df[le_encoded_col_name] = -1

    # Interaction feature
    if (street_name_col_std + '_encoded' in df.columns) and \
       (violation_desc_col_std + '_encoded' in df.columns):
        df['street_violation_interaction'] = df[street_name_col_std + '_encoded'] * df[violation_desc_col_std + '_encoded']

    # Log transform target
    if TARGET_COLUMN in df.columns and is_training:
        df[TARGET_COLUMN] = np.log1p(df[TARGET_COLUMN])

    return df, encoder_dict

def load_and_preprocess_data(file_path: str, is_training: bool = True, encoder_dict: dict = None, feature_engineering_func=None) -> (pd.DataFrame, dict):
    """
    Loads data and applies feature engineering using a specified function.
    """
    df = pd.read_csv(file_path)
    if feature_engineering_func is None: # Default to original if not specified
        feature_engineering_func = _engineer_features_original
    df, encoder_dict = feature_engineering_func(df.copy(), is_training=is_training, encoder_dict=encoder_dict)
    return df, encoder_dict

# --- Original Train Model Function ---
def train_model_original(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series) -> lgb.Booster:
    """
    Trains a LightGBM model with early stopping.
    """
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'regression_l1',
        'metric': 'rmse',
        'n_estimators': 2000,
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 31,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)])

    return model

# --- Ablated Train Model Function: No Early Stopping ---
def train_model_no_early_stopping(X_train: pd.DataFrame, y_train: pd.Series, X_val: pd.DataFrame, y_val: pd.Series) -> lgb.Booster:
    """
    Trains a LightGBM model without early stopping (trains for full n_estimators).
    """
    X_train.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_train.columns]
    X_val.columns = ["".join (c if c.isalnum() else "_" for c in str(x)) for x in X_val.columns]

    params = {
        'objective': 'regression_l1',
        'metric': 'rmse',
        'n_estimators': 2000, # Will train for full 2000 estimators
        'learning_rate': 0.01,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'num_leaves': 31,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
    }

    model = lgb.LGBMRegressor(**params)

    # Removed early stopping callback
    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse') 

    return model

def calculate_rmse(y_true: pd.Series, y_pred: np.ndarray) -> float:
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def run_ablation_experiment(
    train_path: str,
    feature_engineering_func,
    train_model_func,
    split_strategy: str = 'grouped_holdout', # 'grouped_holdout' or 'random_split'
    experiment_name: str = "Baseline"
) -> float:
    """
    Runs a single ablation experiment and returns the validation RMSE.
    """
    print(f"\n--- Running Experiment: {experiment_name} ---")
    df_2022_raw, encoder_dict = load_and_preprocess_data(train_path, is_training=True, feature_engineering_func=feature_engineering_func)

    # Create temporary standardized columns for splitting logic to avoid modifying actual feature columns
    # These are dropped before model training
    df_2022_raw['temp_street_name_lower'] = df_2022_raw[STREET_NAME_COL.replace(' ', '_').lower()]
    df_2022_raw['temp_violation_desc_lower'] = df_2022_raw[VIOLATION_DESC_COL.replace(' ', '_').lower()]
    
    if split_strategy == 'grouped_holdout':
        df_2022_raw['group_id'] = df_2022_raw['temp_street_name_lower'] + '_' + df_2022_raw['temp_violation_desc_lower']
        unique_groups = df_2022_raw['group_id'].unique()
        train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)
        df_train_raw = df_2022_raw[df_2022_raw['group_id'].isin(train_groups)].copy()
        df_val_raw = df_2022_raw[df_2022_raw['group_id'].isin(val_groups)].copy()
        df_train_raw = df_train_raw.drop(columns=['group_id'])
        df_val_raw = df_val_raw.drop(columns=['group_id'])
    elif split_strategy == 'random_split':
        df_train_raw, df_val_raw = train_test_split(df_2022_raw, test_size=0.2, random_state=42)
    else:
        raise ValueError("Invalid split_strategy. Choose 'grouped_holdout' or 'random_split'.")

    # Drop the temporary columns used only for splitting logic
    df_train_raw = df_train_raw.drop(columns=['temp_street_name_lower', 'temp_violation_desc_lower'])
    df_val_raw = df_val_raw.drop(columns=['temp_street_name_lower', 'temp_violation_desc_lower'])

    # Define features, excluding original categorical columns and target
    features = [col for col in df_train_raw.columns if col not in [TARGET_COLUMN, STREET_NAME_COL.replace(' ', '_').lower(), VIOLATION_DESC_COL.replace(' ', '_').lower()]]

    X_train = df_train_raw[features]
    y_train = df_train_raw[TARGET_COLUMN]
    X_val = df_val_raw[features]
    y_val = df_val_raw[TARGET_COLUMN]

    print("Training model...")
    model = train_model_func(X_train, y_train, X_val, y_val)

    val_predictions_log = model.predict(X_val)
    val_predictions = np.expm1(val_predictions_log) # Inverse transform
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    final_validation_rmse = calculate_rmse(np.expm1(y_val), val_predictions) # Calculate RMSE on original scale
    print(f"Validation RMSE for {experiment_name}: {final_validation_rmse:.4f}")
    
    gc.collect()
    return final_validation_rmse

def main_ablation():
    parser = argparse.ArgumentParser(description="Ablation study for NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()

    results = {}

    # 1. Baseline Experiment (Original solution)
    results['Baseline (Original)'] = run_ablation_experiment(
        args.train_path,
        _engineer_features_original,
        train_model_original,
        split_strategy='grouped_holdout',
        experiment_name="Baseline (Original)"
    )

    # 2. Ablation: No Frequency Encoding
    results['Ablation: No Frequency Encoding'] = run_ablation_experiment(
        args.train_path,
        _engineer_features_no_freq_encoding,
        train_model_original,
        split_strategy='grouped_holdout',
        experiment_name="Ablation: No Frequency Encoding"
    )

    # 3. Ablation: No Early Stopping
    results['Ablation: No Early Stopping'] = run_ablation_experiment(
        args.train_path,
        _engineer_features_original,
        train_model_no_early_stopping,
        split_strategy='grouped_holdout',
        experiment_name="Ablation: No Early Stopping"
    )

    # 4. Ablation: Random Split (instead of Grouped Holdout)
    results['Ablation: Random Split'] = run_ablation_experiment(
        args.train_path,
        _engineer_features_original,
        train_model_original,
        split_strategy='random_split',
        experiment_name="Ablation: Random Split"
    )

    print("\n--- Ablation Study Results Summary ---")
    baseline_rmse = results['Baseline (Original)']
    for experiment, rmse in results.items():
        if experiment == 'Baseline (Original)':
            print(f"{experiment}: RMSE = {rmse:.4f}")
        else:
            diff = rmse - baseline_rmse
            print(f"{experiment}: RMSE = {rmse:.4f} (Difference from Baseline: {diff:.4f})")

    # Determine which part contributes the most (largest impact, positive or negative)
    max_impact = 0
    most_impactful_component = "None"
    impact_type = "" # "positive contribution" or "negative contribution"

    for experiment, rmse in results.items():
        if experiment == 'Baseline (Original)':
            continue
        
        diff = rmse - baseline_rmse # Positive if ablation worsened, negative if ablation improved
        abs_diff = abs(diff)

        if abs_diff > max_impact:
            max_impact = abs_diff
            
            if experiment == 'Ablation: No Frequency Encoding':
                most_impactful_component = "Frequency Encoding"
            elif experiment == 'Ablation: No Early Stopping':
                most_impactful_component = "Early Stopping"
            elif experiment == 'Ablation: Random Split':
                most_impactful_component = "Grouped Holdout Split Strategy" # The original strategy
            else:
                most_impactful_component = experiment # Fallback

            impact_type = "positively" if diff > 0 else "negatively"

    if max_impact > 0:
        if impact_type == "positively":
            print(f"\nBased on this ablation study, the part of the code that contributes the most to the overall performance is: '{most_impactful_component}'."
                  f" Its removal/modification led to the largest increase in RMSE ({max_impact:.4f}), indicating a strong positive contribution in the original setup.")
        else: # impact_type == "negatively"
            print(f"\nBased on this ablation study, the part of the code that contributes the most to the overall performance is: '{most_impactful_component}'."
                  f" Its removal/modification led to the largest decrease in RMSE ({max_impact:.4f}), indicating a strong negative contribution (detrimental effect) in the original setup.")
    else:
        print("\nNo significant impact found from any of the ablated components.")

if __name__ == "__main__":
    main_ablation()
