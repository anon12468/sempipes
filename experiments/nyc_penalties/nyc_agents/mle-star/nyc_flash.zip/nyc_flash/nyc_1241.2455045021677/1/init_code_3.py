
import pandas as pd
import numpy as np
from catboost import CatBoostRegressor, Pool
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import os
import argparse
import logging

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Configuration ---
DEFAULT_TRAIN_PATH = './input/violations_per_street_2022.csv'
AUX_VIOLATION_CODES_PATH = './input/nyc_parking_violation_codes.csv'
AUX_STREET_INFO_PATH = './input/nyc_street_names_info.csv'
AUX_BOROUGH_ZIP_VIOLATIONS_PATH = './input/violations_by_borough_and_zipcode_2022.csv'
OUTPUT_DIR = './predictions'
SUBMISSION_FILENAME = 'submission.csv'

TARGET_COLUMN = 'violation_count'
# Standardized key columns for consistent handling across dataframes
KEY_COLUMNS = ['Street_Name', 'Violation_Description'] 

def parse_args():
    """Parses command line arguments."""
    parser = argparse.ArgumentParser(description="Predict NYC parking violations using CatBoost.")
    parser.add_argument('--train-path', type=str, default=DEFAULT_TRAIN_PATH,
                        help='Path to the 2022 violations training data.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional path to the 2023 violations test data for prediction/evaluation.')
    return parser.parse_args()

def standardize_column_names(df):
    """Standardizes column names for consistency."""
    df.columns = df.columns.str.strip().str.replace(' ', '_')
    return df

def load_data(file_path):
    """Loads CSV data from the given path."""
    logging.info(f"Loading data from {file_path}")
    try:
        df = pd.read_csv(file_path)
        return standardize_column_names(df)
    except FileNotFoundError:
        logging.error(f"File not found: {file_path}")
        return None
    except Exception as e:
        logging.error(f"Error loading {file_path}: {e}")
        return None

def feature_engineer(df, violation_codes_df, street_info_df, borough_zip_violations_df, is_training=True, encoders=None):
    """
    Performs feature engineering by merging auxiliary data and encoding categorical features.
    
    Args:
        df (pd.DataFrame): The main dataframe to engineer features for.
        violation_codes_df (pd.DataFrame): Auxiliary dataframe with violation type info.
        street_info_df (pd.DataFrame): Auxiliary dataframe with street info.
        borough_zip_violations_df (pd.DataFrame): Auxiliary dataframe with aggregated violations by borough/zip.
        is_training (bool): True if processing training data, False for test/validation.
        encoders (dict): Dictionary to store/retrieve LabelEncoders for consistent transformation.

    Returns:
        tuple: (processed_df, encoders, categorical_features_names_for_model)
    """
    if encoders is None:
        encoders = {}

    logging.info("Starting feature engineering...")
    
    # Ensure all auxiliary dataframes have standardized column names
    violation_codes_df = standardize_column_names(violation_codes_df.copy())
    street_info_df = standardize_column_names(street_info_df.copy())
    borough_zip_violations_df = standardize_column_names(borough_zip_violations_df.copy())

    # --- Merge with Violation Codes ---
    df = pd.merge(df, violation_codes_df[['Violation_Description', 'Violation_Type']],
                  on='Violation_Description', how='left')
    logging.debug(f"Merged with violation codes. Shape: {df.shape}")

    # --- Merge with Street Info (Borough, Zip Code) ---
    df = pd.merge(df, street_info_df[['Street_Name', 'Borough', 'Zip_Code']],
                  on='Street_Name', how='left')
    logging.debug(f"Merged with street info. Shape: {df.shape}")

    # --- Merge with Borough and Zip Code Violations ---
    # Rename 'violation_count' in the auxiliary table to avoid conflict and make it a feature
    borough_zip_violations_df = borough_zip_violations_df.rename(columns={'violation_count': 'borough_zip_2022_violation_count'})
    df = pd.merge(df, borough_zip_violations_df[['Borough', 'Zip_Code', 'borough_zip_2022_violation_count']],
                  on=['Borough', 'Zip_Code'], how='left')
    logging.debug(f"Merged with borough_zip_violations_2022. Shape: {df.shape}")

    # --- Handle Missing Values (before encoding) ---
    # For new streets/violations/boroughs/zips, the merged features might be NaN.
    # Fill categorical NaNs with a placeholder, numerical NaNs with 0.
    for col in ['Violation_Type', 'Borough']:
        df[col] = df[col].fillna('UNKNOWN_CATEGORY')
    df['Zip_Code'] = df['Zip_Code'].fillna(-1).astype(int) # Use -1 for unknown zip
    df['borough_zip_2022_violation_count'] = df['borough_zip_2022_violation_count'].fillna(0) # Fill aggregate counts with 0 for unseen combos

    # --- Label Encoding for Categorical Features ---
    # These are the features that will be treated as categorical by CatBoost.
    # We will pass their names to cat_features argument after label encoding them.
    categorical_features_for_encoding = ['Street_Name', 'Violation_Description', 'Violation_Type', 'Borough', 'Zip_Code']
    # Filter to only include columns that are actually present in the dataframe
    categorical_features_names_for_model = [col for col in categorical_features_for_encoding if col in df.columns]

    for col in categorical_features_for_encoding:
        if col not in df.columns:
            continue # Skip if column doesn't exist (e.g., if one of KEY_COLUMNS was dropped earlier)
        
        # Convert all to string before encoding to handle mixed types and NaN correctly
        df[col] = df[col].astype(str)
        
        if is_training:
            le = LabelEncoder()
            # Add 'UNKNOWN_CATEGORY' or '-1' to classes for consistent transformation of unseen values in test data
            if col == 'Zip_Code':
                le.fit(list(df[col].unique()) + ['-1'])
            else:
                le.fit(list(df[col].unique()) + ['UNKNOWN_CATEGORY'])
            df[col] = le.transform(df[col])
            encoders[col] = le
        else:
            if col in encoders:
                le_obj = encoders[col]
                # Function to safely transform, assigning an 'UNKNOWN_CATEGORY' or a default if unseen
                def safe_transform(val, encoder, default_val_for_unseen):
                    if str(val) in encoder.classes_:
                        return encoder.transform([str(val)])[0]
                    else:
                        # Use the encoded value of the default placeholder
                        return encoder.transform([default_val_for_unseen])[0]

                if col == 'Zip_Code':
                    df[col] = df[col].apply(lambda x: safe_transform(x, le_obj, '-1'))
                else:
                    df[col] = df[col].apply(lambda x: safe_transform(x, le_obj, 'UNKNOWN_CATEGORY'))
            else:
                logging.warning(f"Encoder for {col} not found for test data. Filling with -1 (arbitrary placeholder).")
                df[col] = -1 # Fallback for columns without a fitted encoder

    logging.info("Feature engineering complete.")
    return df, encoders, categorical_features_names_for_model

def train_and_predict(train_df, eval_df, test_df_processed, categorical_features_names_for_model):
    """
    Trains the CatBoost model and makes predictions.

    Args:
        train_df (pd.DataFrame): Processed training dataframe.
        eval_df (pd.DataFrame): Processed validation dataframe.
        test_df_processed (pd.DataFrame): Processed test dataframe (can be None).
        categorical_features_names_for_model (list): List of column names that are categorical.

    Returns:
        tuple: (validation_predictions, validation_rmse, test_predictions)
    """
    
    # Prepare data for CatBoost
    features = [col for col in train_df.columns if col not in KEY_COLUMNS + [TARGET_COLUMN]]
    X_train = train_df[features]
    y_train = train_df[TARGET_COLUMN]
    X_eval = eval_df[features]
    y_eval = eval_df[TARGET_COLUMN]

    # Filter categorical features to only include those actually present in the feature set X_train
    cat_features_in_X = [col for col in categorical_features_names_for_model if col in X_train.columns]

    logging.info(f"Training CatBoost model with {len(features)} features. Categorical features: {cat_features_in_X}")

    catboost_model = CatBoostRegressor(
        loss_function='Poisson',
        random_seed=42,
        iterations=1000, # Number of boosting iterations
        learning_rate=0.05,
        depth=8, # Depth of the trees
        l2_leaf_reg=3, # L2 regularization coefficient
        early_stopping_rounds=100, # Stop if no improvement for 100 rounds
        verbose=0, # Suppress verbose output during training
        cat_features=cat_features_in_X, # Pass names of categorical features
        # thread_count=-1 # Use all available CPU cores
    )
    
    # Create CatBoost Pool objects for training and validation
    train_pool = Pool(X_train, y_train, cat_features=cat_features_in_X)
    eval_pool = Pool(X_eval, y_eval, cat_features=cat_features_in_X)

    # Train the model with early stopping
    catboost_model.fit(train_pool, eval_set=eval_pool)

    # Evaluate on validation set
    val_predictions = catboost_model.predict(X_eval)
    val_predictions = np.maximum(0, np.round(val_predictions)).astype(int) # Ensure non-negative integer predictions
    rmse_val = np.sqrt(mean_squared_error(y_eval, val_predictions))
    logging.info(f"Validation RMSE: {rmse_val:.4f}")

    # Predictions for the test set if provided
    test_predictions = None
    if test_df_processed is not None:
        X_test = test_df_processed[features]
        # Align columns to ensure consistency with training data features
        X_test = X_test[X_train.columns]
        
        test_predictions = catboost_model.predict(X_test)
        test_predictions = np.maximum(0, np.round(test_predictions)).astype(int) # Ensure non-negative integer predictions
        logging.info("Predictions generated for test set.")
    
    return val_predictions, rmse_val, test_predictions

def report_unseen_keys(train_keys_df, eval_keys_df, test_keys_df=None):
    """
    Reports the number of unseen (street_name, violation_description) pairs.
    """
    train_key_set = set(train_keys_df.apply(lambda row: (row['Street_Name'], row['Violation_Description']), axis=1))
    
    # For validation set
    eval_key_set = set(eval_keys_df.apply(lambda row: (row['Street_Name'], row['Violation_Description']), axis=1))
    unseen_in_eval = eval_key_set - train_key_set
    logging.info(f"{len(unseen_in_eval)} out of {len(eval_key_set)} validation (Street_Name, Violation_Description) pairs were unseen in training data.")

    # For test set
    unseen_in_test = None
    if test_keys_df is not None:
        test_key_set = set(test_keys_df.apply(lambda row: (row['Street_Name'], row['Violation_Description']), axis=1))
        unseen_in_test = test_key_set - train_key_set
        logging.info(f"{len(unseen_in_test)} out of {len(test_key_set)} test (Street_Name, Violation_Description) pairs were unseen in training data.")
    return unseen_in_eval, unseen_in_test

def main():
    args = parse_args()

    # Create output directory
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # --- Load Data ---
    train_full_df = load_data(args.train_path)
    if train_full_df is None:
        return

    # Load auxiliary data
    violation_codes_df = load_data(AUX_VIOLATION_CODES_PATH)
    street_info_df = load_data(AUX_STREET_INFO_PATH)
    borough_zip_violations_df = load_data(AUX_BOROUGH_ZIP_VIOLATIONS_PATH)

    if any(df is None for df in [violation_codes_df, street_info_df, borough_zip_violations_df]):
        logging.error("Failed to load auxiliary data. Exiting.")
        return

    # --- Split 2022 data into training and validation ---
    # Using 'Violation_Description' for stratification to ensure representative distribution.
    # Fallback to simple random split if stratification fails (e.g., due to rare categories).
    try:
        train_data_2022, eval_data_2022 = train_test_split(
            train_full_df, test_size=0.2, random_state=42, stratify=train_full_df['Violation_Description']
        )
    except ValueError as e:
        logging.warning(f"Stratification failed: {e}. Falling back to simple random split.")
        train_data_2022, eval_data_2022 = train_test_split(
            train_full_df, test_size=0.2, random_state=42
        )
    logging.info(f"Split 2022 data: Train {train_data_2022.shape}, Validation {eval_data_2022.shape}")

    # --- Feature Engineering for Training and Validation ---
    processed_train_df, encoders, categorical_features_names_for_model = feature_engineer(
        train_data_2022.copy(), violation_codes_df, street_info_df, borough_zip_violations_df,
        is_training=True
    )
    processed_eval_df, _, _ = feature_engineer(
        eval_data_2022.copy(), violation_codes_df, street_info_df, borough_zip_violations_df,
        is_training=False, encoders=encoders
    )

    # --- Load and Process Test Data if provided ---
    test_df_original = None
    processed_test_df = None
    if args.test_path:
        test_df_original = load_data(args.test_path)
        if test_df_original is None:
            logging.error("Could not load test data. Skipping test prediction.")
        else:
            # Check if 'violation_count' exists in test_df_original for evaluation
            has_ground_truth = TARGET_COLUMN in test_df_original.columns
            if has_ground_truth:
                logging.info(f"Test file '{args.test_path}' contains '{TARGET_COLUMN}'. Will report RMSE on it.")
            else:
                logging.info(f"Test file '{args.test_path}' does NOT contain '{TARGET_COLUMN}'. Will only generate predictions.")
            
            processed_test_df, _, _ = feature_engineer(
                test_df_original.copy(), violation_codes_df, street_info_df, borough_zip_violations_df,
                is_training=False, encoders=encoders
            )
    
    # --- Report Unseen Keys ---
    # Pass original DFs to report_unseen_keys as encoding is irrelevant for key comparison
    unseen_eval_pairs, unseen_test_pairs = report_unseen_keys(
        train_data_2022[KEY_COLUMNS], eval_data_2022[KEY_COLUMNS], 
        test_df_original[KEY_COLUMNS] if test_df_original is not None else None
    )

    # --- Train Model and Predict ---
    val_predictions, final_validation_rmse, test_predictions = train_and_predict(
        processed_train_df, processed_eval_df, processed_test_df, categorical_features_names_for_model
    )

    print(f"Final Validation Performance: {final_validation_rmse:.4f}")

    # --- Generate Submission File ---
    if processed_test_df is not None and test_predictions is not None:
        submission_df = test_df_original[KEY_COLUMNS].copy() # Use original keys for submission
        submission_df['predicted_count'] = test_predictions

        submission_path = os.path.join(OUTPUT_DIR, SUBMISSION_FILENAME)
        submission_df.to_csv(submission_path, index=False)
        logging.info(f"Submission file generated at: {submission_path}")

        # If test set has ground truth, report RMSE for context
        if TARGET_COLUMN in test_df_original.columns:
            test_ground_truth = test_df_original[TARGET_COLUMN]
            rmse_test = np.sqrt(mean_squared_error(test_ground_truth, test_predictions))
            logging.info(f"Test Set RMSE (against provided ground truth): {rmse_test:.4f}")
    elif args.test_path: # Test path was provided but processing failed or predictions weren't made
        logging.warning("No submission file generated due to issues with test data processing or prediction.")

if __name__ == "__main__":
    main()
