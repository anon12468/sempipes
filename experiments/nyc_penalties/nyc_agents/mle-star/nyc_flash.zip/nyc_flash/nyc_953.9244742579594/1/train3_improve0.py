
import pandas as pd
import numpy as np
import argparse
import os
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Argument Parsing ---
def parse_args():
    """
    Parses command-line arguments for training and test file paths.
    """
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument(
        '--train-path',
        type=str,
        default='./input/violations_per_street_2022.csv',
        help='Path to the 2022 training data CSV file.'
    )
    parser.add_argument(
        '--test-path',
        type=str,
        default=None,
        help='Optional: Path to the test/evaluation data CSV file for prediction.'
    )
    return parser.parse_args()

# --- Data Loading and Augmentation ---
def load_and_augment_data(file_path, input_dir='./input'):
    """
    Loads data from the specified CSV file and augments it with additional
    information from other CSV files in the input_dir.
    Handles missing files and columns gracefully by providing default values.
    """
    logging.info(f"Loading data from: {file_path}")
    try:
        df = pd.read_csv(file_path)
    except FileNotFoundError:
        logging.error(f"File not found: {file_path}. Returning empty DataFrame.")
        return pd.DataFrame()
    except Exception as e:
        logging.error(f"Error loading {file_path}: {e}. Returning empty DataFrame.")
        return pd.DataFrame()

    df.rename(columns={
        'Street Name': 'street_name',
        'Violation Description': 'violation_description',
        'violation_count': 'violation_count'
    }, inplace=True)

    # --- Augmentation Tables ---
    augmentation_data = {}

    violation_codes_df_path = os.path.join(input_dir, 'violation_codes.csv')
    if os.path.exists(violation_codes_df_path):
        try:
            violation_codes_df = pd.read_csv(violation_codes_df_path)
            violation_codes_df.rename(columns={'Violation Description': 'violation_description'}, inplace=True)
            augmentation_data['violation_codes'] = violation_codes_df
            logging.info("Loaded violation_codes.csv for augmentation.")
        except Exception as e:
            logging.warning(f"Error loading violation_codes.csv: {e}. Skipping augmentation.")
    else:
        logging.warning(f"violation_codes.csv not found at {violation_codes_df_path}. Skipping augmentation.")

    street_attributes_df_path = os.path.join(input_dir, 'street_attributes.csv')
    if os.path.exists(street_attributes_df_path):
        try:
            street_attributes_df = pd.read_csv(street_attributes_df_path)
            street_attributes_df.rename(columns={'Street Name': 'street_name'}, inplace=True)
            augmentation_data['street_attributes'] = street_attributes_df
            logging.info("Loaded street_attributes.csv for augmentation.")
        except Exception as e:
            logging.warning(f"Error loading street_attributes.csv: {e}. Skipping augmentation.")
    else:
        logging.warning(f"street_attributes.csv not found at {street_attributes_df_path}. Skipping augmentation.")

    # Merge augmentation data
    if 'violation_codes' in augmentation_data:
        df = pd.merge(df, augmentation_data['violation_codes'], on='violation_description', how='left')
    if 'street_attributes' in augmentation_data:
        df = pd.merge(df, augmentation_data['street_attributes'], on='street_name', how='left')

    # Fill NaNs for features potentially introduced by merges or missing files
    expected_aug_cols_map = {
        'fine_amount': {'dtype': float, 'default_val': 0.0},
        'violation_category': {'dtype': object, 'default_val': 'UNKNOWN_VIOL_CAT'},
        'borough': {'dtype': object, 'default_val': 'UNKNOWN_BOROUGH'},
        'street_type': {'dtype': object, 'default_val': 'UNKNOWN_STREET_TYPE'},
        'length_miles': {'dtype': float, 'default_val': 0.0}
    }

    for col_name, col_props in expected_aug_cols_map.items():
        if col_name not in df.columns:
            df[col_name] = col_props['default_val']
        else:
            if col_props['dtype'] == object:
                df[col_name] = df[col_name].fillna(col_props['default_val'])
            else: # numerical
                df[col_name] = df[col_name].fillna(col_props['default_val'])
    
    return df

# --- Feature Engineering ---
def create_features(df):
    """
    Engineers new features from the raw and augmented data.
    """
    if df.empty:
        return df

    # Create a unique pair identifier for tracking unseen combinations
    df['street_violation_pair'] = df['street_name'].astype(str) + '_' + df['violation_description'].astype(str)

    # Ensure 'fine_amount' and 'length_miles' are numeric before division
    # errors='coerce' will turn non-numeric values into NaN, then fillna(0.0) handles them.
    df['fine_amount'] = pd.to_numeric(df['fine_amount'], errors='coerce').fillna(0.0)
    df['length_miles'] = pd.to_numeric(df['length_miles'], errors='coerce').fillna(0.0)

    # Engineered feature: fine per mile (add epsilon to avoid division by zero)
    df['fine_per_mile'] = df['fine_amount'] / (df['length_miles'] + 1e-6)
    df['fine_per_mile'] = df['fine_per_mile'].fillna(0).replace([np.inf, -np.inf], 0)

    return df

# --- Main Script ---
def main():
    args = parse_args()
    input_directory = os.path.dirname(args.train_path)

    # Ensure input directory exists for dummy files
    if not os.path.exists(input_directory):
        os.makedirs(input_directory)
        logging.info(f"Created input directory: {input_directory}")

    # --- Create dummy augmentation files for initial testing if they don't exist ---
    # These are illustrative and would be actual data in a real scenario.
    dummy_violation_codes_path = os.path.join(input_directory, 'violation_codes.csv')
    if not os.path.exists(dummy_violation_codes_path):
        dummy_violation_codes = pd.DataFrame({
            'Violation Description': ['STOPPING-EXCEPT PARKING', 'NO STANDING-DAY/TIME LIMITS', 'PARKING METER EXPIRED', 'NO PARKING-STREET CLEANING', 'OVERTIME PARKING', 'DOUBLE PARKING'],
            'Violation Code': [38, 14, 21, 40, 20, 46],
            'Fine Amount': [115, 115, 65, 65, 65, 200],
            'Violation Category': ['Standing', 'Standing', 'Meter', 'Parking', 'Parking', 'Standing']
        })
        dummy_violation_codes.to_csv(dummy_violation_codes_path, index=False)
        logging.info("Created dummy violation_codes.csv")

    dummy_street_attributes_path = os.path.join(input_directory, 'street_attributes.csv')
    if not os.path.exists(dummy_street_attributes_path):
        dummy_street_attributes = pd.DataFrame({
            'Street Name': ['MAIN ST', 'BROADWAY', '3RD AVE', 'PARK AVE', 'ELM ST', 'HIGH ST'],
            'Borough': ['MANHATTAN', 'MANHATTAN', 'MANHATTAN', 'MANHATTAN', 'QUEENS', 'BROOKLYN'],
            'Street Type': ['Street', 'Avenue', 'Avenue', 'Avenue', 'Street', 'Street'],
            'Length Miles': [2.5, 13.0, 5.0, 7.0, 1.2, 0.8]
        })
        dummy_street_attributes.to_csv(dummy_street_attributes_path, index=False)
        logging.info("Created dummy street_attributes.csv")
    # --- End of dummy file creation ---

    # --- Create dummy violations_per_street_2022.csv if it doesn't exist for a runnable example ---
    if not os.path.exists(args.train_path):
        logging.warning(f"Train data file not found at {args.train_path}. Creating a dummy one.")
        dummy_train_data = pd.DataFrame({
            'Street Name': ['MAIN ST', 'BROADWAY', '3RD AVE', 'PARK AVE', 'MAIN ST', 'BROADWAY', 'ELM ST', 'HIGH ST', 'PARK AVE', '3RD AVE'],
            'Violation Description': ['STOPPING-EXCEPT PARKING', 'PARKING METER EXPIRED', 'NO PARKING-STREET CLEANING', 'OVERTIME PARKING', 'NO STANDING-DAY/TIME LIMITS', 'STOPPING-EXCEPT PARKING', 'PARKING METER EXPIRED', 'DOUBLE PARKING', 'NO PARKING-STREET CLEANING', 'OVERTIME PARKING'],
            'violation_count': [150, 230, 80, 120, 180, 200, 70, 50, 90, 110]
        })
        dummy_train_data.to_csv(args.train_path, index=False)
        logging.info(f"Created dummy train data at {args.train_path}")


    train_df = load_and_augment_data(args.train_path, input_dir=input_directory)
    if train_df.empty:
        logging.error("Training data could not be loaded or is empty. Exiting.")
        return

    train_df = create_features(train_df)

    # Define features and target
    target = 'violation_count'
    # Features include original identifiers and engineered features
    features = [
        'street_name', 'violation_description', 'fine_amount',
        'violation_category', 'borough', 'street_type', 'length_miles',
        'fine_per_mile'
    ]
    # Ensure all features actually exist in the dataframe after loading/augmentation
    features = [f for f in features if f in train_df.columns]

    # Identify categorical features for CatBoost. These must be in the `features` list.
    categorical_features = [
        'street_name', 'violation_description', 'violation_category',
        'borough', 'street_type'
    ]
    categorical_features = [f for f in categorical_features if f in features]
    
    X = train_df[features]
    y = train_df[target]

    # Ensure there's enough data to split
    if len(X) < 2:
        logging.error("Not enough training data to perform train/validation split. Need at least 2 samples.")
        logging.info(f"Number of samples in X: {len(X)}")
        return
    
    # Stratified split is ideal for time series or counts, but simple random split is sufficient for initial development
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    logging.info(f"Training data shape: {X_train.shape}, Validation data shape: {X_val.shape}")

    # CatBoost expects categorical features by their index.
    cat_feature_indices = [X_train.columns.get_loc(col) for col in categorical_features]

    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Set to 0 for less verbose output
        early_stopping_rounds=55, # Stops training if validation metric doesn't improve for 55 iterations.
        cat_features=cat_feature_indices, # Pass indices of categorical features.
        # 'thread_count': -1 can be used for multi-threading but often default uses all cores effectively.
        # For OOM prevention, consider reducing iterations, depth, or increasing min_data_in_leaf
        # but for aggregate data, default parameters are usually fine.
    )

    logging.info("Starting CatBoost model training...")
    model.fit(X_train, y_train, eval_set=(X_val, y_val))
    logging.info("CatBoost model training complete.")

    val_preds = model.predict(X_val)
    val_preds[val_preds < 0] = 0 # Clip negative predictions to zero
    rmse_val = np.sqrt(mean_squared_error(y_val, val_preds))
    logging.info(f"Validation RMSE: {rmse_val}")
    print(f"Final Validation Performance: {rmse_val}")

    # --- Prediction for Test Data (if provided) ---
    if args.test_path:
        logging.info(f"Loading test data from: {args.test_path}")
        test_df_raw = load_and_augment_data(args.test_path, input_dir=input_directory)
        if test_df_raw.empty:
            logging.warning("Test data could not be loaded or is empty. Skipping prediction.")
            return

        # Keep original street_name and violation_description for submission
        submission_keys = test_df_raw[['street_name', 'violation_description']].copy()

        test_df = create_features(test_df_raw.copy()) # Work on a copy of the test data

        # Identify unseen pairs in the test set compared to training
        train_pairs = set(train_df['street_violation_pair'].unique())
        test_pairs = set(test_df['street_violation_pair'].unique())
        unseen_pairs_count = len(test_pairs - train_pairs)
        logging.info(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_pairs_count}")

        # Prepare X_test for prediction: Align columns with X_train
        X_test = test_df[features].copy() # Start with relevant features from test_df

        # Add missing columns to X_test with default values to match X_train's schema
        for col in X_train.columns:
            if col not in X_test.columns:
                if col in categorical_features:
                    X_test[col] = 'UNKNOWN_TEST_CAT'
                else: # Numerical feature
                    X_test[col] = 0.0
        
        # Ensure column order matches X_train to prevent prediction errors
        X_test = X_test[X_train.columns]
        
        test_preds = model.predict(X_test)
        test_preds[test_preds < 0] = 0 # Clip negative predictions to zero

        submission_df = pd.DataFrame({
            'street_name': submission_keys['street_name'],
            'violation_type': submission_keys['violation_description'],
            'predicted_count': test_preds.round().astype(int) # Round to nearest integer and cast
        })

        submission_output_path = 'submission.csv'
        submission_df.to_csv(submission_output_path, index=False)
        logging.info(f"Submission file saved to {submission_output_path}")

        # If test_df_raw has actual violation_count, calculate RMSE for the test set
        if target in test_df_raw.columns and not test_df_raw[target].isnull().all():
            test_rmse = np.sqrt(mean_squared_error(test_df_raw[target], test_preds))
            logging.info(f"RMSE on provided test set: {test_rmse}")
            print(f"Test Set RMSE: {test_rmse}")
        else:
            logging.info("Test set does not contain 'violation_count' for evaluation. Cannot report RMSE.")

if __name__ == '__main__':
    main()

