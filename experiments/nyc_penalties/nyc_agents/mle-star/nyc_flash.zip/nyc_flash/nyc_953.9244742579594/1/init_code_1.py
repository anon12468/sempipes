
import argparse
import pandas as pd
import numpy as np
import os
import sys
import subprocess
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

# Function to install a package
def install_package(package):
    try:
        __import__(package)
    except ImportError:
        print(f"Attempting to install {package}...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", package])
            print(f"{package} installed successfully.")
        except subprocess.CalledProcessError as e:
            print(f"Error installing {package}: {e}")
            sys.exit(1)
        except Exception as e:
            print(f"Unexpected error during {package} installation: {e}")
            sys.exit(1)

# Ensure necessary packages are installed
install_package('pandas')
install_package('numpy')
install_package('sklearn')
install_package('catboost') # CatBoost is a dependency

# Now that we've ensured catboost is installed, we can import it.
from catboost import CatBoostRegressor, Pool

# Argument parsing
parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                    help="Path to the 2022 training data CSV.")
parser.add_argument("--test-path", type=str, default=None,
                    help="Optional path to the 2023 test/evaluation data CSV.")
args = parser.parse_args()

TRAIN_FILE = args.train_path
TEST_FILE = args.test_path
INPUT_DIR = os.path.dirname(TRAIN_FILE) if os.path.dirname(TRAIN_FILE) else "./input"

# Load training data
try:
    df_train_2022 = pd.read_csv(TRAIN_FILE)
    df_train_2022.columns = ['street_name', 'violation_type', 'violation_count']
except FileNotFoundError:
    print(f"Error: Training file not found at {TRAIN_FILE}")
    sys.exit(1)

print(f"Loaded training data from {TRAIN_FILE}. Shape: {df_train_2022.shape}")

# Data Discovery and Feature Augmentation
def load_and_augment_data(df, base_year, input_dir):
    df_augmented = df.copy()

    # Create year feature
    df_augmented['year'] = base_year

    # Add features based on string lengths
    df_augmented['street_name_len'] = df_augmented['street_name'].apply(lambda x: len(str(x)))
    df_augmented['violation_type_len'] = df_augmented['violation_type'].apply(lambda x: len(str(x)))

    # Discover and load other CSV files for augmentation
    print(f"Searching for augmentation files in {input_dir}...")
    # Filter out the main train and test files from augmentation files
    main_files = [os.path.basename(TRAIN_FILE)]
    if TEST_FILE:
        main_files.append(os.path.basename(TEST_FILE))

    augmentation_files = [f for f in os.listdir(input_dir) if f.endswith('.csv') and f not in main_files]

    for aug_file in augmentation_files:
        try:
            aug_df = pd.read_csv(os.path.join(input_dir, aug_file))
            print(f"Attempting to augment with {aug_file}. Shape: {aug_df.shape}")

            # Try to join on common columns. This is a heuristic and might need refinement
            # based on actual file schemas.
            common_cols = list(set(df_augmented.columns) & set(aug_df.columns))
            # Exclude target and redundant ID columns for joining. Keep 'street_name', 'violation_type'.
            join_cols = [col for col in common_cols if col not in ['violation_count', 'year', 'street_name_len', 'violation_type_len']]

            # Prioritize joining on both street_name and violation_type
            if 'street_name' in df_augmented.columns and 'violation_type' in df_augmented.columns and \
               'street_name' in aug_df.columns and 'violation_type' in aug_df.columns:
                print(f"Joining on: ['street_name', 'violation_type']")
                df_augmented = pd.merge(df_augmented, aug_df.drop(columns=join_cols, errors='ignore'),
                                        on=['street_name', 'violation_type'],
                                        how='left', suffixes=('', f'_{os.path.splitext(aug_file)[0]}'))
                print(f"Augmented data shape after {aug_file}: {df_augmented.shape}")
            elif 'street_name' in join_cols:
                print(f"Joining on: ['street_name']")
                df_augmented = pd.merge(df_augmented, aug_df.drop(columns=join_cols, errors='ignore'),
                                        on=['street_name'],
                                        how='left', suffixes=('', f'_{os.path.splitext(aug_file)[0]}'))
                print(f"Augmented data shape after {aug_file}: {df_augmented.shape}")
            elif 'violation_type' in join_cols:
                print(f"Joining on: ['violation_type']")
                df_augmented = pd.merge(df_augmented, aug_df.drop(columns=join_cols, errors='ignore'),
                                        on=['violation_type'],
                                        how='left', suffixes=('', f'_{os.path.splitext(aug_file)[0]}'))
                print(f"Augmented data shape after {aug_file}: {df_augmented.shape}")
            else:
                print(f"No suitable common columns found for joining with {aug_file}. Skipping augmentation with this file.")

        except Exception as e:
            print(f"Could not load or augment with {aug_file}: {e}. Skipping.")
    return df_augmented

df_train_augmented = load_and_augment_data(df_train_2022, 2022, INPUT_DIR)

# Encode categorical features
categorical_features = ['street_name', 'violation_type']

for col in categorical_features:
    # Ensure all string columns are treated as such
    df_train_augmented[col] = df_train_augmented[col].astype(str)

# Handle potential NaN values introduced by joins
# For simplicity, numerical NaNs will be filled with 0, categorical with 'UNKNOWN'
for col in df_train_augmented.columns:
    if df_train_augmented[col].dtype == 'object':
        df_train_augmented[col] = df_train_augmented[col].fillna('UNKNOWN')
    elif pd.api.types.is_numeric_dtype(df_train_augmented[col]):
        df_train_augmented[col] = df_train_augmented[col].fillna(0)

# Prepare data for CatBoost
X = df_train_augmented.drop('violation_count', axis=1)
y = df_train_augmented['violation_count']

# Identify categorical features for CatBoost
cat_features_indices = [X.columns.get_loc(col) for col in categorical_features if col in X.columns]

# Split 2022 data for validation
# Use a grouped split to keep street_name and violation_type pairs together
# If a specific stratify column is used, ensure it does not have too many unique values
# If 'violation_type' has too many unique values, stratify might fail.
# For now, let's use a simple split without stratification if unique values are too high.
if X['violation_type'].nunique() > 1000: # Arbitrary threshold, adjust as needed
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
else:
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42, stratify=X['violation_type'])


# Initialize CatBoost Regressor
# Parameters optimized for speed and to prevent OOM
model = CatBoostRegressor(
    iterations=500, # Reduced iterations for faster execution, can be increased
    learning_rate=0.1,
    depth=8,
    loss_function='RMSE',
    eval_metric='RMSE',
    random_seed=42,
    verbose=False,
    early_stopping_rounds=50,
    cat_features=cat_features_indices,
    thread_count=-1 # Use all available threads
)

# Train the model
print("Training CatBoost model...")
model.fit(X_train, y_train, eval_set=(X_val, y_val), early_stopping_rounds=50)

# Evaluate on validation set
val_preds = model.predict(X_val)
val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
print(f"Final Validation Performance: {val_rmse}")

# Handle test/evaluation file
if TEST_FILE:
    print(f"\nProcessing test/evaluation file: {TEST_FILE}")
    try:
        df_test = pd.read_csv(TEST_FILE)
        original_test_columns = df_test.columns.tolist() # Keep original column names for output
        # Dynamically determine columns based on presence of 'violation_count'
        if 'violation_count' in df_test.columns:
            df_test.columns = ['street_name', 'violation_type', 'violation_count']
        else:
            df_test.columns = ['street_name', 'violation_type']

    except FileNotFoundError:
        print(f"Error: Test file not found at {TEST_FILE}")
        sys.exit(1)

    # Store original keys for submission
    submission_keys = df_test[['street_name', 'violation_type']].copy()

    # Augment test data (same way as training data)
    # Drop violation_count from test data if present, as it's a target
    df_test_to_augment = df_test.drop(columns=['violation_count'], errors='ignore')
    df_test_augmented = load_and_augment_data(df_test_to_augment, 2023, INPUT_DIR)
    df_test_augmented['year'] = 2023 # Assuming test data is for 2023

    # Align columns with training data and fill missing with appropriate defaults
    train_cols_for_prediction = X_train.columns
    missing_cols_in_test = set(train_cols_for_prediction) - set(df_test_augmented.columns)

    for col in missing_cols_in_test:
        if col in categorical_features or df_train_augmented[col].dtype == 'object':
            df_test_augmented[col] = 'UNKNOWN' # Fill new categorical features with 'UNKNOWN'
        elif pd.api.types.is_numeric_dtype(df_train_augmented[col]):
            df_test_augmented[col] = 0 # Fill new numerical features with 0
        else:
            df_test_augmented[col] = 'UNKNOWN' # Default for other types, though unlikely after checking num/cat

    # Ensure all string columns are treated as such
    for col in categorical_features:
        if col in df_test_augmented.columns:
            df_test_augmented[col] = df_test_augmented[col].astype(str)

    # Reorder test columns to match training columns
    X_test_processed = df_test_augmented[train_cols_for_prediction]

    # Predict on test data
    test_preds = model.predict(X_test_processed)
    predicted_counts = np.maximum(0, test_preds).round().astype(int) # Ensure non-negative and integer

    # Generate submission file
    submission_df = submission_keys
    submission_df['predicted_count'] = predicted_counts
    submission_df.to_csv("submission.csv", index=False)
    print("Submission file 'submission.csv' generated successfully.")

    # If 'violation_count' was present in the test file, calculate RMSE
    if 'violation_count' in original_test_columns:
        true_counts = df_test['violation_count']
        test_rmse = np.sqrt(mean_squared_error(true_counts, predicted_counts))
        print(f"RMSE on test/evaluation data: {test_rmse}")

        # Report unseen key pairs
        train_keys = set(df_train_2022.set_index(['street_name', 'violation_type']).index)
        test_keys = set(df_test.set_index(['street_name', 'violation_type']).index)
        unseen_keys = test_keys - train_keys
        num_unseen = len(unseen_keys)
        print(f"Number of unseen (street_name, violation_type) pairs in test/evaluation data: {num_unseen}")
        if num_unseen > 0:
            print("These unseen pairs were handled by using learned features and filling missing values (e.g., 'UNKNOWN' for categorical, 0 for numerical).")

else:
    print("\nNo test-path provided. Skipping prediction and submission file generation.")
