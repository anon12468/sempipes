
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys
import copy

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    # initial_memory = df.memory_usage(deep=True).sum() / (1024**2) # Suppress for clean output
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            # and number of unique values is not 1 (to avoid converting columns with only one value to category)
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    # final_memory = df.memory_usage(deep=True).sum() / (1024**2) # Suppress for clean output
    return df

def load_and_preprocess_data(train_path, test_path=None, include_interaction_features=True):
    """
    Loads, preprocesses, and merges data from various sources.
    Handles memory efficiency by selective column loading, aggregation, and garbage collection.
    Allows control over the creation of interaction features.
    """
    print("Loading and preprocessing data...")

    # --- Load Core Data ---
    # Load training data
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)
    # print(f"Initial train_df loaded. Shape: {train_df_raw.shape}, Memory: {train_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # For ablation study, we only care about unique keys from train
    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_df = combined_keys_train.reset_index(drop=True)
    del combined_keys_train # Free memory
    gc.collect()
    # print(f"Combined unique (street, violation) pairs for feature engineering. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # --- Feature Engineering and Augmentation ---

    # Basic features from core data
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # Augmentation 1: nyc_street_data.csv
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        # print(f"Loading {street_data_path}...")
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name']) # Ensure unique info per street
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            
            if include_interaction_features:
                # Create interaction feature: street_length_per_lane
                if 'street_length' in combined_df.columns and 'num_lanes' in combined_df.columns:
                    combined_df['street_length_per_lane'] = combined_df['street_length'] / combined_df['num_lanes'].replace(0, np.nan) # Avoid division by zero
                    combined_df['street_length_per_lane'] = combined_df['street_length_per_lane'].astype('float32') # Use float32 for efficiency
                    # print("Created 'street_length_per_lane' interaction feature.")

            del street_data
            gc.collect()
            # print(f"Merged with street_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading or merging {street_data_path}: {e}. Skipping street data augmentation.")
    else:
        print(f"Warning: {street_data_path} not found. Skipping street data augmentation.")

    # Augmentation 2: nyc_violation_codes.csv
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        # print(f"Loading {violation_codes_path}...")
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description']) # Ensure unique info per violation
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')

            if include_interaction_features:
                # Create interaction feature: violation_severity
                if 'fine_amount' in combined_df.columns and 'points' in combined_df.columns:
                    combined_df['violation_severity'] = combined_df['fine_amount'] * combined_df['points']
                    combined_df['violation_severity'] = combined_df['violation_severity'].astype('float32') # Use float32 for efficiency
                    # print("Created 'violation_severity' interaction feature.")

            del violation_codes
            gc.collect()
            # print(f"Merged with violation_codes. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading or merging {violation_codes_path}: {e}. Skipping violation codes augmentation.")
    else:
        print(f"Warning: {violation_codes_path} not found. Skipping violation codes augmentation.")

    # Augmentation 3: nyc_census_data.csv (Hypothetical)
    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        # print(f"Loading {census_data_path}...")
        if 'borough' in combined_df.columns: # Only proceed if borough info is available from street_data
            try:
                census_data = pd.read_csv(census_data_path)
                # Standardize column names
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]

                # Assuming 'borough' is the key and 'population_density', 'avg_income' are features
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    # Aggregate census data by borough to reduce size before merging
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')

                    if include_interaction_features:
                        # Create interaction feature: street_population_interaction
                        if 'street_length' in combined_df.columns and 'population_density' in combined_df.columns:
                            combined_df['street_population_interaction'] = combined_df['street_length'] * combined_df['population_density']
                            combined_df['street_population_interaction'] = combined_df['street_population_interaction'].astype('float32') # Use float32 for efficiency
                            # print("Created 'street_population_interaction' interaction feature.")

                    del census_data, census_agg
                    gc.collect()
                    # print(f"Merged with census_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
                else:
                    print(f"Warning: Missing one or more expected columns ({relevant_census_cols}) in {census_data_path}. Skipping census data augmentation.")
            except Exception as e:
                print(f"Error loading or merging {census_data_path}: {e}. Skipping census data augmentation.")
        else:
            print("Warning: Borough information not available in combined_df to merge census data. Skipping.")
    else:
        print(f"Warning: {census_data_path} not found. Skipping census data augmentation.")


    # Split back into train processed dataframes (test_path is None for ablation)
    # Merge the engineered features back to the raw dataframes (which still hold violation_count)
    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    # print(f"Final train_processed_df shape: {train_processed_df.shape}")

    # Identify categorical features for CatBoost
    categorical_features = [col for col in combined_df.columns if combined_df[col].dtype in ['object', 'category']]
    # Ensure all categorical features from the combined_df are present in the final processed DFs
    categorical_features = [col for col in categorical_features if col in train_processed_df.columns]
    # print(f"Categorical features identified for CatBoost: {categorical_features}")

    return train_processed_df, None, categorical_features # Always return None for test_df in ablation context

def train_and_predict(train_df, test_df, categorical_features, catboost_params):
    """
    Trains a CatBoost Regressor model and generates predictions.
    Reports RMSE for validation.
    """
    print("Training CatBoost model...")

    # --- Handle NaNs in Categorical Features ---
    # CatBoost requires categorical features to be strings or integers, not NaNs.
    # Fill NaNs with a placeholder string.
    for col in categorical_features:
        if col in train_df.columns:
            # Convert to string to handle potential NaN values and ensure consistency for CatBoost
            train_df[col] = train_df[col].astype(str).fillna('Missing')
    
    # Ensure all categorical columns are of 'category' dtype after filling NaNs
    # This step is important for memory efficiency and to explicitly signal CatBoost
    # the intended column types.
    for col in categorical_features:
        if col in train_df.columns:
            train_df[col] = train_df[col].astype('category')
    # print("NaNs in categorical features handled and types set to 'category'.")


    # Define features (X) and target (y)
    features = [col for col in train_df.columns if col not in ['violation_count', 'is_pure_prediction']] # Exclude target and flag
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    # Split training data for validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    # print(f"Training data split: X_train={X_train.shape}, X_val={X_val.shape}")

    # Initialize CatBoost Regressor with provided parameters
    model = CatBoostRegressor(**catboost_params)

    # Convert categorical feature names to their indices for CatBoost
    # Ensure only columns present in X_train are considered for cat_features
    cat_features_in_X_train = [col for col in categorical_features if col in X_train.columns]
    cat_features_indices = [X_train.columns.get_loc(col) for col in cat_features_in_X_train]
    # print(f"Categorical feature indices for CatBoost: {cat_features_indices}")

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                  early_stopping_rounds=catboost_params.get('early_stopping_rounds', 50), # Use provided or default
                  verbose=0 # Suppress verbose output for clean ablation
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        print("This might indicate an issue with data format or extreme memory pressure even with optimized parameters.")
        raise

    # Validate on internal validation set
    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    # print(f"Development Validation RMSE: {val_rmse}")

    return None, val_rmse # No submission_df or test_rmse in ablation context

def ablation_main():
    """
    Main function to orchestrate the ablation study.
    """
    parser = argparse.ArgumentParser(description="Ablation study for NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()

    # --- Base Case Configuration ---
    # Parameters for the original solution
    base_catboost_params = {
        'iterations': 1000,
        'learning_rate': 0.05,
        'depth': 6,
        'l2_leaf_reg': 3,
        'loss_function': 'RMSE',
        'eval_metric': 'RMSE',
        'random_seed': 42,
        'verbose': 100, 
        'early_stopping_rounds': 50,
    }
    base_include_interaction_features = True

    print("\n--- Running Base Case ---")
    train_df_base, _, categorical_features_base = load_and_preprocess_data(args.train_path, 
                                                                           include_interaction_features=base_include_interaction_features)
    _, base_rmse = train_and_predict(train_df_base.copy(), None, categorical_features_base, 
                                    catboost_params=base_catboost_params)
    print(f"Base Case Validation RMSE: {base_rmse:.4f}\n")
    results = {'Base Case': base_rmse}

    # --- Ablation 1: Enable CatBoost grow_policy='Lossguide' ---
    # This was identified as beneficial in a previous study but was commented out.
    ablation1_catboost_params = copy.deepcopy(base_catboost_params)
    ablation1_catboost_params['grow_policy'] = 'Lossguide'
    ablation1_catboost_params['max_leaves'] = 31 # Commonly used with Lossguide
    ablation1_catboost_params['verbose'] = 0 # Suppress verbose output for clean ablation
    
    print("\n--- Running Ablation 1: Enable CatBoost grow_policy='Lossguide' ---")
    # Use the same preprocessed data as base case, only change model params
    _, ablation1_rmse = train_and_predict(train_df_base.copy(), None, categorical_features_base, 
                                        catboost_params=ablation1_catboost_params)
    print(f"Ablation 1 (grow_policy='Lossguide') Validation RMSE: {ablation1_rmse:.4f}")
    results['Ablation 1 (grow_policy=Lossguide)'] = ablation1_rmse

    # --- Ablation 2: Enable CatBoost subsample=0.8 ---
    # This was identified as beneficial in a previous study but was default (1.0).
    ablation2_catboost_params = copy.deepcopy(base_catboost_params)
    ablation2_catboost_params['subsample'] = 0.8 # Use 80% of data for each tree
    ablation2_catboost_params['verbose'] = 0 # Suppress verbose output for clean ablation
    
    print("\n--- Running Ablation 2: Enable CatBoost subsample=0.8 ---")
    # Use the same preprocessed data as base case, only change model params
    _, ablation2_rmse = train_and_predict(train_df_base.copy(), None, categorical_features_base, 
                                        catboost_params=ablation2_catboost_params)
    print(f"Ablation 2 (subsample=0.8) Validation RMSE: {ablation2_rmse:.4f}")
    results['Ablation 2 (subsample=0.8)'] = ablation2_rmse

    # --- Ablation 3: Remove Interaction Features ---
    # Evaluate the impact of the newly added specific interaction features derived from external data.
    ablation3_catboost_params = copy.deepcopy(base_catboost_params)
    ablation3_catboost_params['verbose'] = 0 # Suppress verbose output for clean ablation
    
    print("\n--- Running Ablation 3: Remove Interaction Features ---")
    train_df_ablation3, _, categorical_features_ablation3 = load_and_preprocess_data(args.train_path, 
                                                                                    include_interaction_features=False)
    _, ablation3_rmse = train_and_predict(train_df_ablation3.copy(), None, categorical_features_ablation3, 
                                        catboost_params=ablation3_catboost_params)
    print(f"Ablation 3 (No Interaction Features) Validation RMSE: {ablation3_rmse:.4f}")
    results['Ablation 3 (No Interaction Features)'] = ablation3_rmse

    # --- Summarize Results ---
    print("\n--- Ablation Study Summary ---")
    for name, rmse in results.items():
        print(f"{name}: RMSE = {rmse:.4f} (Delta from Base: {(rmse - base_rmse):.4f})")

    # Determine the most contributing part (largest absolute impact)
    max_impact_key = 'Base Case'
    max_impact_abs_delta = 0.0
    max_impact_delta = 0.0

    for name, rmse in results.items():
        if name == 'Base Case':
            continue
        
        delta = rmse - base_rmse
        abs_delta = abs(delta)

        if abs_delta > max_impact_abs_delta:
            max_impact_abs_delta = abs_delta
            max_impact_delta = delta
            max_impact_key = name

    print("\n--- Conclusion ---")
    if max_impact_key == 'Base Case':
        print("No significant change in RMSE observed across ablations.")
    elif max_impact_delta < 0:
        print(f"The most impactful component is '{max_impact_key}', which improved RMSE by {abs(max_impact_delta):.4f}.")
    else: # max_impact_delta > 0
        print(f"The most impactful component is '{max_impact_key}', which worsened RMSE by {max_impact_delta:.4f}.")

if __name__ == "__main__":
    ablation_main()
