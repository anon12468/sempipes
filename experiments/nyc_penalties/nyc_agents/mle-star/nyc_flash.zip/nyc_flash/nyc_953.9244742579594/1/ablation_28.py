
import pandas as pd
import numpy as np
import argparse
import os
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import logging
import sys

# Configure logging to suppress INFO messages, only show WARNING and ERROR
logging.basicConfig(level=logging.WARNING, format='%(asctime)s - %(levelname)s - %(message)s')

def rmse(y_true, y_pred):
    """Calculates the Root Mean Squared Error."""
    return np.sqrt(mean_squared_error(y_true, y_pred))

class TargetEncoder:
    """
    A robust target encoder for categorical features.
    Handles NaN values and prevents data leakage using cross-validation.
    Applies smoothing and uses global mean for unseen categories.
    """
    def __init__(self, cols, smoothing=1.0, min_samples_leaf=1):
        self.cols = cols
        self.smoothing = smoothing
        self.min_samples_leaf = min_samples_leaf
        self.global_mean = None
        self.mapping = {} # Stores mappings for full dataset after fit_transform

    def fit(self, X, y):
        """
        Fits the target encoder on the full dataset to create a mapping for transformation.
        This is typically called after cross-validated fit_transform to prepare for new data.
        """
        self.global_mean = y.mean()
        for col in self.cols:
            temp_df = pd.DataFrame({'col': X[col], 'target': y})
            agg = temp_df.groupby('col')['target'].agg(['count', 'mean'])
            counts = agg['count']
            means = agg['mean']

            # Apply smoothing
            smooth_mean = (counts * means + self.smoothing * self.global_mean) / (counts + self.smoothing)
            
            self.mapping[col] = smooth_mean.to_dict()

    def transform(self, X):
        """
        Transforms the input DataFrame using the learned mappings.
        Handles unseen categories by filling with the global mean.
        """
        X_encoded = X.copy()
        for col in self.cols:
            feature_name = f'{col}_te'
            if col in self.mapping:
                encoded_feature = X_encoded[col].map(self.mapping[col])
                X_encoded[feature_name] = encoded_feature.astype(np.float32).fillna(self.global_mean)
            else:
                logging.warning(f"Column {col} not found in target encoder mapping during transform. Filling with global mean.")
                X_encoded[feature_name] = np.full(len(X_encoded), self.global_mean, dtype=np.float32)
        return X_encoded

    def fit_transform(self, X, y, cv_folds=5):
        """
        Performs cross-validated target encoding to prevent data leakage.
        For each fold, encodes the validation set using statistics from the training set.
        """
        X_encoded = X.copy()
        self.global_mean = y.mean()

        for col in self.cols:
            oof_encoded = np.zeros(len(X_encoded), dtype=np.float32)
            kf = KFold(n_splits=cv_folds, shuffle=True, random_state=42)

            for fold, (train_idx, val_idx) in enumerate(kf.split(X_encoded, y)):
                X_train_fold, X_val_fold = X_encoded.iloc[train_idx], X_encoded.iloc[val_idx]
                y_train_fold = y.iloc[train_idx]

                temp_df = pd.DataFrame({'col': X_train_fold[col], 'target': y_train_fold})
                agg = temp_df.groupby('col')['target'].agg(['count', 'mean'])
                counts = agg['count']
                means = agg['mean']

                # Apply smoothing for this fold's mapping
                smooth_mean = (counts * means + self.smoothing * self.global_mean) / (counts + self.smoothing)
                
                fold_mapping = smooth_mean.to_dict()
                
                encoded_val = X_val_fold[col].map(fold_mapping).astype(np.float32)
                oof_encoded[val_idx] = encoded_val.fillna(self.global_mean).values

            X_encoded[f'{col}_te'] = oof_encoded
            
            # As per the provided original code structure, self.fit(X, y) was called here.
            # This ensures `self.mapping` is populated using the full dataset for future `transform` calls.
            self.fit(X, y) 

        return X_encoded


def frequency_encode(df, cols):
    """Applies frequency encoding to specified categorical columns."""
    df_encoded = df.copy()
    for col in cols:
        freq_map = df_encoded[col].value_counts(normalize=True)
        df_encoded[f'{col}_freq'] = df_encoded[col].map(freq_map).astype(np.float32)
    return df_encoded

# Function to encapsulate the core training and validation logic for ablation study
def run_training_evaluation(train_path, 
                            ablation_target_encoder_smoothing=100.0,
                            ablation_allow_negative_violation_count=False,
                            ablation_catboost_cat_features_as_str=True):

    # Redirect stdout to suppress CatBoost verbose output during training for cleaner ablation output
    original_stdout = sys.stdout
    sys.stdout = open(os.devnull, 'w')

    try:
        # --- Load Training Data ---
        try:
            train_df = pd.read_csv(train_path)
        except FileNotFoundError:
            logging.error(f"Training file not found: {train_path}. Please ensure the file exists.")
            return None
        except Exception as e:
            logging.error(f"Error loading training data from {train_path}: {e}", exc_info=True)
            return None

        # Standardize column names
        train_df.columns = [col.replace(' ', '_').lower() for col in train_df.columns]
        
        # Ensure violation_count is numeric and non-negative
        train_df['violation_count'] = pd.to_numeric(train_df['violation_count'], errors='coerce')
        train_df.dropna(subset=['violation_count'], inplace=True)
        
        # Ablation 1: Allow Negative Violation Count
        if not ablation_allow_negative_violation_count:
            train_df = train_df[train_df['violation_count'] >= 0]

        # Identify categorical features
        categorical_features = ['street_name', 'violation_description']

        # Handle NaNs in categorical features and convert to 'category' type
        for col in categorical_features:
            if col not in train_df.columns:
                logging.error(f"Required categorical column '{col}' not found in training data.")
                return None
            if train_df[col].isnull().any():
                train_df[col] = train_df[col].fillna('UNKNOWN_CATEGORY').astype('category')
            else:
                train_df[col] = train_df[col].astype('category')

        # --- Feature Engineering for Training Data ---
        
        # Ablation 2: Target Encoder Smoothing parameter
        target_encoder = TargetEncoder(cols=categorical_features, smoothing=ablation_target_encoder_smoothing, min_samples_leaf=50) 
        X_train_processed = target_encoder.fit_transform(train_df.drop('violation_count', axis=1), train_df['violation_count'], cv_folds=5)
        
        # Frequency Encoding
        X_train_processed = frequency_encode(X_train_processed, categorical_features)

        y_train = train_df['violation_count']
        
        # Define features to use in the model: original categorical features + engineered features
        model_features = categorical_features + [col for col in X_train_processed.columns if col.endswith(('_te', '_freq'))]
        X_train_final = X_train_processed[model_features].copy() # Use .copy() to avoid SettingWithCopyWarning

        # Ablation 3: CatBoost Categorical Features as 'category' dtype (not forced to 'str')
        if ablation_catboost_cat_features_as_str:
            for col in categorical_features:
                # Ensure these columns are of string type for CatBoost if explicitly desired
                X_train_final[col] = X_train_final[col].astype(str)
        else:
            # Otherwise, ensure they are 'category' type which CatBoost can also handle natively
            for col in categorical_features:
                if X_train_final[col].dtype != 'category': # Ensure it's category if not already
                    X_train_final[col] = X_train_final[col].astype('category')

        # Get indices of categorical features for CatBoost Pool
        cat_features_indices = [X_train_final.columns.get_loc(col) for col in categorical_features]
        
        # --- Model Training (CatBoost with Cross-Validation) ---
        kf = KFold(n_splits=5, shuffle=True, random_state=42)
        val_rmses = []

        for fold, (train_idx, val_idx) in enumerate(kf.split(X_train_final, y_train)):
            X_train_fold, X_val_fold = X_train_final.iloc[train_idx], X_train_final.iloc[val_idx]
            y_train_fold, y_val_fold = y_train.iloc[train_idx], y_train.iloc[val_idx]

            train_pool = Pool(X_train_fold, y_train_fold, cat_features=cat_features_indices)
            val_pool = Pool(X_val_fold, y_val_fold, cat_features=cat_features_indices)

            model = CatBoostRegressor(
                iterations=1000,
                learning_rate=0.05,
                depth=8,
                loss_function='RMSE',
                eval_metric='RMSE',
                random_seed=42,
                verbose=False, # Set to False for cleaner ablation output
                early_stopping_rounds=50,
                allow_writing_files=False,
                thread_count=-1,
            )
            model.fit(train_pool, eval_set=val_pool, use_best_model=True)
            
            val_preds = model.predict(val_pool)
            fold_rmse = rmse(y_val_fold, val_preds)
            val_rmses.append(fold_rmse)

        final_validation_score = np.mean(val_rmses)
        return final_validation_score
    finally:
        sys.stdout = original_stdout # Restore stdout

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Perform ablation study on parking violation prediction.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help="Path to the 2022 training data CSV.")
    args = parser.parse_args()

    results = {}

    # Base Case
    base_rmse = run_training_evaluation(args.train_path)
    if base_rmse is not None:
        results['Base Case'] = base_rmse
    else:
        print("Base Case failed to run. Exiting.")
        sys.exit(1)

    # Ablation 1: Allow Negative Violation Count
    ablation1_rmse = run_training_evaluation(args.train_path, ablation_allow_negative_violation_count=True)
    if ablation1_rmse is not None:
        results['Allow Negative Violation Count'] = ablation1_rmse
    
    # Ablation 2: Target Encoder Smoothing set to 1.0 (less smoothing)
    ablation2_rmse = run_training_evaluation(args.train_path, ablation_target_encoder_smoothing=1.0)
    if ablation2_rmse is not None:
        results['Target Encoder Smoothing set to 1.0'] = ablation2_rmse

    # Ablation 3: CatBoost Categorical Features as 'category' dtype (not forced to 'str')
    ablation3_rmse = run_training_evaluation(args.train_path, ablation_catboost_cat_features_as_str=False)
    if ablation3_rmse is not None:
        results['CatBoost Categorical Features as "category" dtype'] = ablation3_rmse

    # Print results as required
    print(f"Base Case Validation RMSE: {results['Base Case']:.4f}")

    if 'Allow Negative Violation Count' in results:
        print(f"Ablation 1 Validation RMSE: {results['Allow Negative Violation Count']:.4f}")
        print(f"Change from Base: {results['Allow Negative Violation Count'] - results['Base Case']:.4f}")

    if 'Target Encoder Smoothing set to 1.0' in results:
        print(f"Ablation 2 Validation RMSE: {results['Target Encoder Smoothing set to 1.0']:.4f}")
        print(f"Change from Base: {results['Target Encoder Smoothing set to 1.0'] - results['Base Case']:.4f}")
    
    if 'CatBoost Categorical Features as "category" dtype' in results:
        print(f"Ablation 3 Validation RMSE: {results['CatBoost Categorical Features as \"category\" dtype']:.4f}")
        print(f"Change from Base: {results['CatBoost Categorical Features as \"category\" dtype'] - results['Base Case']:.4f}")

    # Determine the most contributing part
    if len(results) > 1:
        valid_results = {k: v for k, v in results.items() if v is not None}
        if 'Base Case' in valid_results:
            base_rmse_val = valid_results['Base Case']
            ablations_deltas = {name: abs(rmse_val - base_rmse_val) for name, rmse_val in valid_results.items() if name != 'Base Case'}

            if ablations_deltas:
                most_impactful_ablation = max(ablations_deltas, key=ablations_deltas.get)
                delta = ablations_deltas[most_impactful_ablation]
                
                impact_type = "improved" if (results[most_impactful_ablation] - base_rmse_val) < 0 else "degraded"
                
                print(f"The most contributing part to the overall performance is: '{most_impactful_ablation}'.")
                print(f"Its modification {impact_type} the RMSE by an absolute delta of {delta:.4f}.")
            else:
                print("No valid ablation scenarios completed to determine the most contributing part.")
        else:
            print("Base Case did not complete successfully. Cannot determine the most contributing part.")
    else:
        print("Not enough ablation scenarios completed to determine the most contributing part.")
