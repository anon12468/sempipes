
import pandas as pd
import numpy as np
import argparse
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os
import sys

# Attempt to install necessary modules if not present
try:
    import catboost
    import pandas
    import numpy
    import sklearn
except ImportError:
    print("One or more required modules not found. Attempting to install them...", file=sys.stderr)
    try:
        import subprocess
        # Using sys.executable to ensure pip corresponds to the current Python interpreter
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'catboost', 'pandas', 'numpy', 'scikit-learn'])
        print("Modules installed successfully.", file=sys.stderr)
        # Re-import after installation
        import catboost
        import pandas
        import numpy
        import sklearn
    except Exception as e:
        print(f"Error installing modules: {e}", file=sys.stderr)
        print("Please install catboost, pandas, numpy, and scikit-learn manually using 'pip install <module_name>'.", file=sys.stderr)
        # Exit would be here in a real script, but not allowed by instructions.
        # The script will likely fail later if crucial modules are indeed missing.


def rmse(y_true, y_pred):
    """Calculates the Root Mean Squared Error."""
    return np.sqrt(mean_squared_error(y_true, y_pred))

def load_and_preprocess_data(file_path):
    """
    Loads and preprocesses the violation data.
    Renames columns, handles missing values (if any), and converts types.
    """
    print(f"Loading data from: {file_path}", file=sys.stderr)
    try:
        df = pd.read_csv(file_path)
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}. Please check the path.", file=sys.stderr)
        sys.exit(1) # Exit the script if the file is not found.

    # Rename columns for easier access and consistency
    df.rename(columns={
        'Street Name': 'street_name',
        'Violation Description': 'violation_type',
        'violation_count': 'violation_count'
    }, inplace=True)

    # Convert to appropriate types to save memory and improve performance
    # Using 'object' for strings before converting to 'category' later for CatBoost,
    # as direct 'category' conversion might be less flexible with unseen values.
    # However, CatBoost's Pool handles this. Keeping as string/object first.
    if 'street_name' in df.columns:
        df['street_name'] = df['street_name'].astype(str)
    if 'violation_type' in df.columns:
        df['violation_type'] = df['violation_type'].astype(str)
    
    # Ensure violation_count is numeric if present, fill NaN with 0 for robustness
    if 'violation_count' in df.columns:
        df['violation_count'] = pd.to_numeric(df['violation_count'], errors='coerce').fillna(0).astype(np.float32)

    print(f"Loaded {len(df)} records from {file_path}", file=sys.stderr)
    return df

def feature_engineer(df, training_df=None):
    """
    Performs feature engineering.
    - Creates frequency encodings for street_name and violation_type.
    - Handles unseen categories in test data by using training data statistics.
    """
    df_fe = df.copy()

    # --- Frequency Encodings ---
    # If training_df is provided, use its statistics for frequency encoding to prevent data leakage.
    # Otherwise, calculate statistics from the current df (for the initial training set).
    if training_df is not None:
        street_counts = training_df['street_name'].value_counts()
        violation_counts = training_df['violation_type'].value_counts()
        
        # For interaction, combine string columns from training_df
        training_interaction_series = training_df['street_name'].astype(str) + '_' + training_df['violation_type'].astype(str)
        interaction_counts = training_interaction_series.value_counts()
    else: # For initial training data processing
        street_counts = df_fe['street_name'].value_counts()
        violation_counts = df_fe['violation_type'].value_counts()
        
        interaction_series = df_fe['street_name'].astype(str) + '_' + df_fe['violation_type'].astype(str)
        interaction_counts = interaction_series.value_counts()

    df_fe['street_name_freq'] = df_fe['street_name'].map(street_counts).fillna(0).astype(np.float32)
    df_fe['violation_type_freq'] = df_fe['violation_type'].map(violation_counts).fillna(0).astype(np.float32)

    # --- Basic String Length Features ---
    df_fe['street_name_len'] = df_fe['street_name'].apply(len).astype(np.int16)
    df_fe['violation_type_len'] = df_fe['violation_type'].apply(len).astype(np.int16)

    # --- Interaction Feature Frequency Encoding ---
    df_fe['street_violation_interaction_key'] = df_fe['street_name'].astype(str) + '_' + df_fe['violation_type'].astype(str)
    df_fe['street_violation_interaction_freq'] = df_fe['street_violation_interaction_key'].map(interaction_counts).fillna(0).astype(np.float32)
    df_fe.drop(columns=['street_violation_interaction_key'], inplace=True) # Drop the temporary string key

    return df_fe

def report_unseen_pairs(train_df, eval_df, name="evaluation"):
    """
    Reports the number of unseen (street_name, violation_type) pairs in the specified dataset.
    """
    train_pairs = set(train_df.apply(lambda row: (row['street_name'], row['violation_type']), axis=1))
    eval_pairs = set(eval_df.apply(lambda row: (row['street_name'], row['violation_type']), axis=1))

    unseen_pairs = eval_pairs - train_pairs
    print(f"\nNumber of (street_name, violation_type) pairs in {name} set: {len(eval_pairs)}", file=sys.stderr)
    print(f"Number of (street_name, violation_type) pairs in training set: {len(train_pairs)}", file=sys.stderr)
    print(f"Number of unseen (street_name, violation_type) pairs in {name} set: {len(unseen_pairs)}", file=sys.stderr)
    if len(eval_pairs) > 0:
        print(f"Unseen pairs constitute {len(unseen_pairs) / len(eval_pairs) * 100:.2f}% of the {name} set.", file=sys.stderr)
    return unseen_pairs


def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help="Path to the 2022 training data CSV.")
    parser.add_argument('--test-path', type=str, default=None,
                        help="Optional: Path to the 2023 test/evaluation data CSV for predictions.")
    
    args = parser.parse_args()

    # --- Load and Preprocess Training Data ---
    train_df_raw = load_and_preprocess_data(args.train_path)

    # Ensure 'violation_count' is present for training
    if 'violation_count' not in train_df_raw.columns:
        print("Error: 'violation_count' column not found in training data. This is required for model training.", file=sys.stderr)
        sys.exit(1)

    # --- Split for Validation ---
    # Using a simple random split for development validation.
    # For a more robust "grouped holdout", one would typically split unique (street_name, violation_type) pairs
    # and then filter the dataframe. For this task, a direct random split suffices.
    X = train_df_raw.drop(columns=['violation_count'])
    y = train_df_raw['violation_count']

    # Using a fixed random state for reproducibility
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42, shuffle=True)

    # Combine back to DataFrames for consistent feature engineering
    train_df = pd.concat([X_train, y_train], axis=1)
    val_df = pd.concat([X_val, y_val], axis=1)

    print(f"\nTraining set size for model: {len(train_df)}", file=sys.stderr)
    print(f"Validation set size for model: {len(val_df)}", file=sys.stderr)
    
    # --- Feature Engineering ---
    train_df_fe = feature_engineer(train_df)
    val_df_fe = feature_engineer(val_df, training_df=train_df) # Use training stats for validation set features

    # Define features and target
    # CatBoost can directly handle 'street_name' and 'violation_type' as categorical features.
    # Other generated features are numerical.
    categorical_features_for_catboost = ['street_name', 'violation_type']
    
    # Filter features to only include those present in train_df_fe and potentially in val_df_fe.
    # Ensure consistency between train and validation/test feature sets.
    features = [col for col in train_df_fe.columns if col not in ['violation_count']]
    
    X_train_fe = train_df_fe[features]
    y_train_fe = train_df_fe['violation_count']
    X_val_fe = val_df_fe[features]
    y_val_fe = val_df_fe['violation_count']

    # --- CatBoost Model Training ---
    print("\nStarting CatBoost model training...", file=sys.stderr)
    model = CatBoostRegressor(
        iterations=1500, # Increased iterations, early stopping will prevent overfitting
        learning_rate=0.03, # Slightly reduced learning rate
        depth=10, # Increased depth for potentially better capture of interactions
        eval_metric='RMSE',
        random_seed=42,
        verbose=100, # Print progress every 100 iterations
        early_stopping_rounds=100, # Stop if validation RMSE doesn't improve for 100 rounds
        # Loss function for regression
        loss_function='RMSE',
        # Set to CPU for broader compatibility; remove for GPU usage if available
        task_type='CPU',
        # CatBoost is memory-efficient by default, but for extremely large datasets,
        # consider `used_ram_limit` (e.g., '6gb') or `thread_count`.
        thread_count=-1 # Use all available CPU cores
    )

    # Create CatBoost Pool objects
    # CatBoost will automatically handle unseen categorical feature values in the eval_set
    # by assigning them to a special "unseen" category or using trained strategy.
    train_pool = Pool(X_train_fe, y_train_fe, cat_features=categorical_features_for_catboost)
    val_pool = Pool(X_val_fe, y_val_fe, cat_features=categorical_features_for_catboost)

    model.fit(train_pool, eval_set=val_pool, plot=False) # plot=False to avoid matplotlib dependency/output

    # --- Validation Performance ---
    val_predictions = model.predict(X_val_fe)
    val_predictions = np.maximum(0, val_predictions) # Predictions must be non-negative

    final_validation_score = rmse(y_val_fe, val_predictions)
    print(f"\nFinal Validation Performance: {final_validation_score}") # Keep this line for parsing

    # Report unseen pairs in validation set (relative to training split)
    report_unseen_pairs(train_df, val_df, name="validation")

    # --- Prediction on Test Data (if provided) ---
    if args.test_path:
        print(f"\nProcessing test data from: {args.test_path}", file=sys.stderr)
        test_df_raw = load_and_preprocess_data(args.test_path)

        # Store original keys for submission
        submission_keys = test_df_raw[['street_name', 'violation_type']].copy()

        # Handle the case where test_df has 'violation_count' (for evaluation) or not (for pure prediction)
        if 'violation_count' in test_df_raw.columns:
            print("Test data contains 'violation_count' column. It will be used for scoring (RMSE) only, not as a feature.", file=sys.stderr)
            X_test_for_pred = test_df_raw.drop(columns=['violation_count'])
            y_test_ground_truth = test_df_raw['violation_count']
        else:
            print("Test data does not contain 'violation_count' column. Generating pure predictions.", file=sys.stderr)
            X_test_for_pred = test_df_raw
            y_test_ground_truth = None # No ground truth for scoring

        # Feature engineer test data using statistics from the full training dataset (train_df_raw)
        test_df_fe = feature_engineer(X_test_for_pred, training_df=train_df_raw)

        # Ensure test features match training features
        # Filter for only the features the model was trained on
        X_test_fe = test_df_fe[features]
        
        # Create CatBoost Pool for prediction
        test_pool = Pool(X_test_fe, cat_features=categorical_features_for_catboost)
        
        test_predictions = model.predict(test_pool)
        test_predictions = np.maximum(0, test_predictions) # Predictions must be non-negative

        # Create submission file
        submission_df = submission_keys
        submission_df['predicted_count'] = test_predictions.round().astype(int) # Round and convert to int for counts
        submission_df.to_csv('submission.csv', index=False)
        print("\nPredictions saved to submission.csv", file=sys.stderr)

        # Report RMSE if ground truth is available in test data
        if y_test_ground_truth is not None:
            test_rmse = rmse(y_test_ground_truth, test_predictions)
            print(f"RMSE on provided test set: {test_rmse}", file=sys.stderr)
            # Report unseen pairs in test set (relative to full training data)
            report_unseen_pairs(train_df_raw, test_df_raw, name="test")
        else:
            print("No 'violation_count' in test file, so RMSE cannot be computed for the test set.", file=sys.stderr)

    print("\nScript finished.", file=sys.stderr)

if __name__ == "__main__":
    main()
