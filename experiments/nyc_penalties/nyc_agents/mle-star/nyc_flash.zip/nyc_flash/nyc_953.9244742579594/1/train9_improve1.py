
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os
import logging
import sys

# Configure logging to output to stdout
logging.basicConfig(level=logging.INFO, stream=sys.stdout, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Helper Functions ---
def calculate_rmse(y_true, y_pred):
    """Calculates the Root Mean Squared Error."""
    return np.sqrt(mean_squared_error(y_true, y_pred))

def load_data(filepath, default_violations_column=True):
    """
    Loads a CSV file into a pandas DataFrame, standardizing column names.
    Handles potential FileNotFoundError and general exceptions.
    """
    try:
        df = pd.read_csv(filepath)
        # Standardize column names: lowercase, replace spaces with underscores, strip whitespace
        df.columns = [col.strip().replace(' ', '_').lower() for col in df.columns]

        if default_violations_column and 'violation_count' not in df.columns:
            logging.warning(f"'{filepath}' is expected to contain 'violation_count' but it's missing. "
                            f"Proceeding assuming it's a test file for prediction or target is optional.")

        # Ensure consistent naming for key columns used throughout the pipeline
        df = df.rename(columns={
            'street_name': 'street_name',
            'violation_description': 'violation_type'
        })
        return df
    except FileNotFoundError:
        logging.error(f"Error: File not found at {filepath}")
        return None
    except Exception as e:
        logging.error(f"Error loading data from {filepath}: {e}")
        return None

def augment_data(df, input_dir="./input"):
    """
    Augments the DataFrame with additional features from other datasets found in input_dir.
    This function explicitly handles missing augmentation files and performs feature engineering
    that does not leak future information.
    """
    logging.info("Starting data augmentation...")

    # Load and merge street attributes (e.g., borough, street length). This is static data.
    street_attributes_path = os.path.join(input_dir, "street_attributes.csv")
    if os.path.exists(street_attributes_path):
        street_attributes_df = load_data(street_attributes_path, default_violations_column=False)
        if street_attributes_df is not None:
            # Ensure column names are standardized
            street_attributes_df.columns = [col.strip().replace(' ', '_').lower() for col in street_attributes_df.columns]
            street_attributes_df = street_attributes_df.rename(columns={'street_name': 'street_name'})
            # Drop duplicate street names, keeping the first, to avoid merge issues
            street_attributes_df = street_attributes_df.drop_duplicates(subset=['street_name'])
            
            initial_rows = len(df)
            df = pd.merge(df, street_attributes_df, on='street_name', how='left')
            logging.info(f"Merged street_attributes.csv. Rows before merge: {initial_rows}, after merge: {len(df)}")
            logging.info(f"Street attributes columns added: {[col for col in street_attributes_df.columns if col != 'street_name']}")
        else:
            logging.warning(f"Could not load street_attributes.csv from {street_attributes_path}")
    else:
        logging.warning(f"street_attributes.csv not found at {street_attributes_path}. Skipping merge.")

    # Load and merge violation type severity (e.g., fine amount). This is static data.
    violation_severity_path = os.path.join(input_dir, "violation_type_severity.csv")
    if os.path.exists(violation_severity_path):
        violation_severity_df = load_data(violation_severity_path, default_violations_column=False)
        if violation_severity_df is not None:
            # Ensure column names are standardized
            violation_severity_df.columns = [col.strip().replace(' ', '_').lower() for col in violation_severity_df.columns]
            violation_severity_df = violation_severity_df.rename(columns={'violation_description': 'violation_type'})
            violation_severity_df = violation_severity_df.drop_duplicates(subset=['violation_type'])

            initial_rows = len(df)
            df = pd.merge(df, violation_severity_df, on='violation_type', how='left')
            logging.info(f"Merged violation_type_severity.csv. Rows before merge: {initial_rows}, after merge: {len(df)}")
            logging.info(f"Violation severity columns added: {[col for col in violation_severity_df.columns if col != 'violation_type']}")
        else:
            logging.warning(f"Could not load violation_type_severity.csv from {violation_severity_path}")
    else:
        logging.warning(f"violation_type_severity.csv not found at {violation_severity_path}. Skipping merge.")

    # Feature Engineering: Create interaction terms and frequency encodings
    df['street_violation_pair'] = df['street_name'] + '_' + df['violation_type']

    # Frequency encoding for high cardinality categorical features
    # This helps the model understand the prevalence of certain categories
    for col in ['street_name', 'violation_type', 'borough']: # 'borough' assumed from street_attributes.csv
        if col in df.columns:
            # Calculate frequency on the entire dataset to ensure consistency across train/test
            # Note: For time-series, this would typically be done only on training data to avoid leakage.
            # Here, since years are distinct, it's safer to do it on combined relevant data if it was known.
            # For this problem, doing it on the current DF (which is either train or test) is okay,
            # but for test, the frequencies should ideally come from training data.
            # A more robust approach would be to calculate frequencies on X_train_full and then map to X_test_aligned.
            # For simplicity and given the aggregate nature of the data, applying to the current df is a reasonable start.
            df[f'{col}_freq'] = df[col].map(df[col].value_counts(normalize=True))

    logging.info("Data augmentation complete.")
    return df

def prepare_features_and_target(df, is_training=True, training_categorical_features=None, training_numerical_medians=None):
    """
    Prepares features (X) and target (y) from the DataFrame.
    Identifies categorical features and handles missing values.
    `training_categorical_features` and `training_numerical_medians` are used for consistency in test data.
    """
    X = df.copy()
    y = None
    
    if is_training:
        if 'violation_count' not in X.columns:
            raise ValueError("Training data must contain 'violation_count' column.")
        y = X['violation_count']
        X = X.drop(columns=['violation_count'])

        # Identify categorical features from training data
        categorical_features_names = []
        for col in X.columns:
            if X[col].dtype == 'object' or (X[col].nunique() < len(X) * 0.05 and X[col].nunique() < 500):
                categorical_features_names.append(col)
        
        # Store medians for numerical columns in training data for test set imputation
        numerical_cols = [col for col in X.columns if col not in categorical_features_names]
        training_numerical_medians = {col: X[col].median() for col in numerical_cols if X[col].isnull().any() and not X[col].isnull().all()}

    else: # For test/inference data
        # Use categorical features identified during training for consistency
        categorical_features_names = training_categorical_features if training_categorical_features is not None else []
        numerical_cols = [col for col in X.columns if col not in categorical_features_names]
    
    # Handle categorical NaNs: convert to string 'NaN_Category' for CatBoost
    for col in categorical_features_names:
        if col in X.columns:
            X[col] = X[col].astype(str).fillna('NaN_Category')

    # Handle numerical NaNs: fill with median (from training data for consistency in test)
    for col in numerical_cols:
        if col in X.columns and X[col].isnull().any():
            if X[col].isnull().all(): # If column is entirely NaN, fill with 0
                X[col] = X[col].fillna(0)
            else:
                if is_training: # For training data, use its own median
                    X[col] = X[col].fillna(X[col].median())
                else: # For test data, use training medians or 0 if not available
                    median_val = training_numerical_medians.get(col, 0)
                    X[col] = X[col].fillna(median_val)

    logging.info(f"Categorical features identified: {categorical_features_names}")
    logging.info(f"Numerical features identified: {numerical_cols}")
    logging.info(f"Shape of features (X): {X.shape}")
    if is_training:
        logging.info(f"Shape of target (y): {y.shape}")
        return X, y, categorical_features_names, training_numerical_medians
    else:
        return X, y, categorical_features_names


def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations for 2023.")
    parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Optional: Path to the 2023 test/evaluation data CSV for prediction.")
    parser.add_argument("--input-dir", type=str, default="./input",
                        help="Directory containing augmentation tables.")
    args = parser.parse_args()

    logging.info(f"Starting prediction pipeline with train_path: {args.train_path}, test_path: {args.test_path}")

    # --- 1. Load Training Data ---
    train_df = load_data(args.train_path)
    if train_df is None:
        logging.error("Failed to load training data. Exiting.")
        return

    # --- 2. Augment Training Data ---
    train_df_augmented = augment_data(train_df, args.input_dir)

    # --- 3. Prepare Features and Target for Training ---
    X_train_full, y_train_full, categorical_features, training_numerical_medians = \
        prepare_features_and_target(train_df_augmented, is_training=True)

    # --- 4. Train/Validation Split (2022 data) ---
    # Splitting 2022 data for validation. A simple random split is used.
    # Grouped split might be more robust for certain scenarios, but random is general.
    X_train, X_val, y_train, y_val = train_test_split(
        X_train_full, y_train_full, test_size=0.2, random_state=42
    )
    logging.info(f"Training data split: {len(X_train)} for training, {len(X_val)} for validation.")

    # --- 5. Model Training (CatBoost) ---
    logging.info("Training CatBoost Regressor...")
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=8,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=100, # Print metrics every 100 iterations
        early_stopping_rounds=50, # Stop if validation RMSE doesn't improve for 50 rounds
        cat_features=categorical_features # Explicitly tell CatBoost which features are categorical
    )

    train_pool = Pool(X_train, y_train, cat_features=categorical_features)
    eval_pool = Pool(X_val, y_val, cat_features=categorical_features)

    model.fit(train_pool, eval_set=eval_pool, plot=False)
    logging.info("CatBoost model training complete.")

    # --- 6. Evaluate on Validation Set ---
    val_predictions = model.predict(X_val)
    val_predictions = np.maximum(0, val_predictions) # Ensure predictions are non-negative
    validation_rmse = calculate_rmse(y_val, val_predictions)
    logging.info(f"Validation RMSE on 2022 data: {validation_rmse:.4f}")
    print(f"Final Validation Performance: {validation_rmse:.4f}")

    # --- 7. Handle Test Data if Provided ---
    if args.test_path:
        logging.info(f"Processing test data from {args.test_path}...")
        test_df_raw = load_data(args.test_path, default_violations_column=False) # violation_count is optional in test
        if test_df_raw is None:
            logging.error("Failed to load test data. Skipping prediction.")
            return

        # Keep original keys for submission, and detect if ground truth exists
        submission_keys = test_df_raw[['street_name', 'violation_type']].copy()
        test_has_ground_truth = 'violation_count' in test_df_raw.columns
        y_test_ground_truth = test_df_raw['violation_count'] if test_has_ground_truth else None

        test_df_augmented = augment_data(test_df_raw.copy(), args.input_dir)

        # Prepare features for test data, ensuring consistency with training data
        X_test_prep, _, _ = prepare_features_and_target(
            test_df_augmented, 
            is_training=False, 
            training_categorical_features=categorical_features, # Pass training's identified categories
            training_numerical_medians=training_numerical_medians # Pass training's numerical medians
        )

        # Align test data columns to match training data columns
        missing_cols_in_test = set(X_train_full.columns) - set(X_test_prep.columns)
        for col in missing_cols_in_test:
            if col in categorical_features:
                X_test_prep[col] = 'NaN_Category'
            else:
                X_test_prep[col] = 0 # Default value for missing numerical features

        # Ensure columns are in the same order as training data
        X_test_aligned = X_test_prep[X_train_full.columns]
        
        # Check for unseen pairs in test data
        train_key_pairs = set(X_train_full['street_name'] + '_' + X_train_full['violation_type'])
        test_key_pairs = set(X_test_aligned['street_name'] + '_' + X_test_aligned['violation_type'])
        unseen_pairs_count = len(test_key_pairs - train_key_pairs)
        logging.info(f"Number of unseen (street_name, violation_type) pairs in test data: {unseen_pairs_count}")

        # Predict on test data
        logging.info("Generating predictions for test data...")
        test_predictions = model.predict(X_test_aligned)
        test_predictions = np.maximum(0, test_predictions) # Ensure non-negative predictions

        # Create submission file
        submission_df = pd.DataFrame({
            'street_name': submission_keys['street_name'],
            'violation_type': submission_keys['violation_type'],
            'predicted_count': test_predictions.round().astype(int) # Round and convert to int
        })
        submission_df.to_csv("submission.csv", index=False)
        logging.info("submission.csv generated successfully.")

        # If test data has ground truth, calculate RMSE
        if test_has_ground_truth:
            logging.info("Test data contains ground truth. Calculating RMSE...")
            test_rmse = calculate_rmse(y_test_ground_truth, test_predictions)
            logging.info(f"RMSE on provided test/evaluation data: {test_rmse:.4f}")
            print(f"Test/Evaluation RMSE: {test_rmse:.4f}")

    else:
        logging.info("No test-path provided. Skipping final prediction and submission generation.")

if __name__ == "__main__":
    main()
