
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys
import warnings

# Suppress warnings for cleaner ablation study output
warnings.filterwarnings('ignore')

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    return df

# Modified load_and_preprocess_data to accept ablation parameters
def load_and_preprocess_data_ablated(train_path, 
                                     ablation_no_basic_length_features=False,
                                     ablation_no_gc_collect=False):
    """
    Loads and preprocesses data from various sources with ablation options.
    - ablation_no_basic_length_features: If True, skips creation of street_name_len and violation_desc_len.
    - ablation_no_gc_collect: If True, skips all explicit gc.collect() calls.
    Note: test_path is explicitly not used as per instruction for ablation study.
    """
    # --- Load Core Data ---
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)

    # For ablation study, test_path is always None, so test_df_raw remains None.
    # We create combined_df only from train_df_raw's unique keys.
    combined_df = train_df_raw[['street_name', 'violation_description']].drop_duplicates().reset_index(drop=True)
    
    if not ablation_no_gc_collect:
        gc.collect()

    # --- Feature Engineering and Augmentation ---

    # Basic features from core data (Ablation point 1)
    if not ablation_no_basic_length_features:
        combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
        combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # Augmentation 1: nyc_street_data.csv
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name']) 
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            if not ablation_no_gc_collect:
                gc.collect()
        except Exception:
            pass # Suppress errors for ablation runs
    
    # Augmentation 2: nyc_violation_codes.csv
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description']) 
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            if not ablation_no_gc_collect:
                gc.collect()
        except Exception:
            pass # Suppress errors for ablation runs

    # Augmentation 3: nyc_census_data.csv (Hypothetical)
    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        if 'borough' in combined_df.columns: 
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    if not ablation_no_gc_collect:
                        gc.collect()
            except Exception:
                pass # Suppress errors for ablation runs

    # Merge engineered features back to the raw dataframe
    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw, combined_df
    if not ablation_no_gc_collect:
        gc.collect()

    # Identify categorical features for CatBoost
    all_possible_cat_features = [col for col in train_processed_df.columns if train_processed_df[col].dtype in ['object', 'category']]
    categorical_features = [col for col in all_possible_cat_features]
    
    for col in categorical_features:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].fillna('Missing_Category').astype('category')
    
    return train_processed_df, None, categorical_features

# Modified train_and_predict to accept ablation parameters
def train_and_predict_ablated(train_df, test_df, categorical_features,
                             ablation_remove_raw_categorical_features=False):
    """
    Trains a CatBoost Regressor model and generates predictions.
    Reports RMSE for validation sets.
    Ablation parameter:
    - ablation_remove_raw_categorical_features: If True, 'street_name' and 'violation_description' are removed from features.
    Note: test_df is explicitly not used as per instruction for ablation study.
    """
    # Define features (X) and target (y)
    feature_cols = [col for col in train_df.columns if col not in ['violation_count']] 
    target = 'violation_count'

    # Ablation point 2: Remove Raw 'street_name' and 'violation_description' as direct features
    if ablation_remove_raw_categorical_features:
        if 'street_name' in feature_cols:
            feature_cols.remove('street_name')
        if 'violation_description' in feature_cols:
            feature_cols.remove('violation_description')

    X = train_df[feature_cols]
    y = train_df[target]

    # Split training data for validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    # Initialize CatBoost Regressor with OOM-conscious parameters
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6, 
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Suppress verbose output for ablation runs
        early_stopping_rounds=50, 
    )

    # Train the model
    # Adjust categorical_features for CatBoost if raw ones are removed
    if ablation_remove_raw_categorical_features:
        categorical_features_for_catboost = [f for f in categorical_features if f not in ['street_name', 'violation_description']]
        cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features_for_catboost if col in X_train.columns]
    else:
        cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        raise

    # Validate on internal validation set
    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))

    return None, val_rmse # Return None for submission_df as per instruction

# Main ablation study function
def run_ablation_study(train_path):
    print("Starting Ablation Study...\n")

    results = {}

    # --- Base Case ---
    print("--- Base Case: All features/optimizations enabled ---")
    train_df_base, _, categorical_features_base = load_and_preprocess_data_ablated(
        train_path=train_path,
        ablation_no_basic_length_features=False,
        ablation_no_gc_collect=False
    )
    _, base_rmse = train_and_predict_ablated(
        train_df=train_df_base,
        test_df=None,
        categorical_features=categorical_features_base,
        ablation_remove_raw_categorical_features=False
    )
    results['Base Case'] = base_rmse
    print(f"Base Case Validation RMSE: {base_rmse:.4f}\n")

    # --- Ablation 1: Remove Basic Length Features ---
    print("--- Ablation 1: No Basic Length Features ('street_name_len', 'violation_desc_len') ---")
    train_df_abl1, _, categorical_features_abl1 = load_and_preprocess_data_ablated(
        train_path=train_path,
        ablation_no_basic_length_features=True,
        ablation_no_gc_collect=False 
    )
    _, abl1_rmse = train_and_predict_ablated(
        train_df=train_df_abl1,
        test_df=None,
        categorical_features=categorical_features_abl1,
        ablation_remove_raw_categorical_features=False 
    )
    results['No Basic Length Features'] = abl1_rmse
    print(f"Ablation 1 Validation RMSE: {abl1_rmse:.4f} (Delta: {abl1_rmse - base_rmse:.4f})\n")

    # --- Ablation 2: Remove Raw 'street_name' and 'violation_description' as direct features ---
    # Reload base data to ensure clean state for this ablation
    train_df_abl2, _, categorical_features_abl2 = load_and_preprocess_data_ablated(
        train_path=train_path,
        ablation_no_basic_length_features=False,
        ablation_no_gc_collect=False 
    )
    print("--- Ablation 2: Remove Raw 'street_name' and 'violation_description' as direct features ---")
    _, abl2_rmse = train_and_predict_ablated(
        train_df=train_df_abl2,
        test_df=None,
        categorical_features=categorical_features_abl2,
        ablation_remove_raw_categorical_features=True 
    )
    results['No Raw Street/Violation Features'] = abl2_rmse
    print(f"Ablation 2 Validation RMSE: {abl2_rmse:.4f} (Delta: {abl2_rmse - base_rmse:.4f})\n")

    # --- Ablation 3: No Explicit Garbage Collection ---
    # Reload base data to ensure clean state for this ablation
    train_df_abl3, _, categorical_features_abl3 = load_and_preprocess_data_ablated(
        train_path=train_path,
        ablation_no_basic_length_features=False, 
        ablation_no_gc_collect=True 
    )
    print("--- Ablation 3: No Explicit gc.collect() Calls ---")
    _, abl3_rmse = train_and_predict_ablated(
        train_df=train_df_abl3,
        test_df=None,
        categorical_features=categorical_features_abl3,
        ablation_remove_raw_categorical_features=False 
    )
    results['No gc.collect()'] = abl3_rmse
    print(f"Ablation 3 Validation RMSE: {abl3_rmse:.4f} (Delta: {abl3_rmse - base_rmse:.4f})\n")

    print("\n--- Ablation Study Summary ---")
    for name, rmse in results.items():
        if name == 'Base Case':
            print(f"{name}: RMSE = {rmse:.4f}")
        else:
            print(f"{name}: RMSE = {rmse:.4f} (Delta from Base: {rmse - base_rmse:.4f})")

    # Determine the most contributing part based on largest absolute RMSE delta
    max_impact = 0
    most_contributing_part_description = "None (no significant impact observed)"

    for name, rmse in results.items():
        if name == 'Base Case':
            continue
        
        delta = rmse - base_rmse

        if abs(delta) > abs(max_impact):
            max_impact = delta
            if delta > 0:
                most_contributing_part_description = f"'{name}' (removal/modification worsened performance by {delta:.4f}, implying it was beneficial)"
            elif delta < 0:
                most_contributing_part_description = f"'{name}' (removal/modification improved performance by {-delta:.4f}, implying it was detrimental)"
            else:
                most_contributing_part_description = f"'{name}' (had no measurable impact on performance)"

    print(f"\nConclusion: The most impactful change identified in this ablation study was: {most_contributing_part_description}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run ablation study on NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()

    run_ablation_study(args.train_path)

