
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types.
    Removed automatic object to category conversion to avoid issues with NaNs
    and ensure explicit handling for CatBoost categorical features.
    """
    initial_memory = df.memory_usage(deep=True).sum() / (1024**2)
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Removed object to category conversion here.
        # This will be handled explicitly later for CatBoost categorical features.
    final_memory = df.memory_usage(deep=True).sum() / (1024**2)
    # print(f"  Memory reduced from {initial_memory:.2f} MB to {final_memory:.2f} MB for dataframe.")
    return df

# Function for smoothed target encoding
def add_smoothed_target_encoding(df_to_enrich, df_for_targets, categorical_col, target_col, alpha=100):
    """
    Calculates smoothed target encoding for a categorical column based on df_for_targets
    and adds it as a new feature to df_to_enrich.
    :param df_to_enrich: The dataframe to which the new feature will be added (e.g., combined_df)
    :param df_for_targets: The dataframe containing the target variable (e.g., train_df_raw)
    :param categorical_col: The categorical column to encode (e.g., 'street_name')
    :param target_col: The target column (e.g., 'violation_count')
    :param alpha: Smoothing parameter. Higher alpha means more smoothing towards global mean.
    :return: A pandas Series with the smoothed target encoding values for df_to_enrich.
    """
    # Calculate global mean of the target from the training data
    global_mean = df_for_targets[target_col].mean()

    # Calculate counts and mean for each category in the training data
    agg_df = df_for_targets.groupby(categorical_col)[target_col].agg(['count', 'mean']).reset_index()
    agg_df.rename(columns={'count': 'cat_count', 'mean': 'cat_mean'}, inplace=True)
    
    # Calculate smoothed mean
    agg_df[f'{categorical_col}_te'] = (agg_df['cat_count'] * agg_df['cat_mean'] + alpha * global_mean) / (agg_df['cat_count'] + alpha)
    
    # Create the mapping dictionary
    te_map = agg_df.set_index(categorical_col)[f'{categorical_col}_te'].to_dict()
    
    # Apply the mapping to df_to_enrich and fill NaNs (for categories not seen in training) with global mean
    encoded_features = df_to_enrich[categorical_col].map(te_map).fillna(global_mean)
    
    return encoded_features


def load_and_preprocess_data(train_path, test_path=None):
    """
    Loads, preprocesses, and merges data from various sources.
    Handles memory efficiency by selective column loading, aggregation, and garbage collection.
    Fixes CatBoost's NaN issue by explicitly filling NaNs in categorical columns.
    """
    print("Loading and preprocessing data...")

    # --- Load Core Data ---
    # Load training data
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)
    print(f"Initial train_df loaded. Shape: {train_df_raw.shape}, Memory: {train_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Load test data if provided
    test_df_raw = None
    if test_path:
        test_df_raw = pd.read_csv(test_path)
        test_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
        # Create a flag for pure prediction rows where violation_count is NaN
        test_df_raw['is_pure_prediction'] = test_df_raw['violation_count'].isna()
        test_df_raw = downcast_dtypes(test_df_raw)
        print(f"Test_df loaded. Shape: {test_df_raw.shape}, Memory: {test_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Combine unique street_name and violation_description pairs from train and test
    # for consistent feature engineering.
    # Exclude 'violation_count' to prevent target leakage and reduce memory.
    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_keys_test = pd.DataFrame()
    if test_df_raw is not None:
        combined_keys_test = test_df_raw[['street_name', 'violation_description']].drop_duplicates()

    combined_df = pd.concat([combined_keys_train, combined_keys_test], ignore_index=True).drop_duplicates().reset_index(drop=True)
    del combined_keys_train, combined_keys_test # Free memory
    gc.collect()
    print(f"Combined unique (street, violation) pairs for feature engineering. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # --- Feature Engineering and Augmentation ---

    # Basic features from core data
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # Augmentation 1: nyc_street_data.csv
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        print(f"Loading {street_data_path}...")
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name']) # Ensure unique info per street
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
            print(f"Merged with street_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading or merging {street_data_path}: {e}. Skipping street data augmentation.")
    else:
        print(f"Warning: {street_data_path} not found. Skipping street data augmentation.")

    # Augmentation 2: nyc_violation_codes.csv
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        print(f"Loading {violation_codes_path}...")
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description']) # Ensure unique info per violation
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
            print(f"Merged with violation_codes. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading or merging {violation_codes_path}: {e}. Skipping violation codes augmentation.")
    else:
        print(f"Warning: {violation_codes_path} not found. Skipping violation codes augmentation.")

    # Augmentation 3: nyc_census_data.csv (Hypothetical)
    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        print(f"Loading {census_data_path}...")
        if 'borough' in combined_df.columns: # Only proceed if borough info is available from street_data
            try:
                census_data = pd.read_csv(census_data_path)
                # Standardize column names
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]

                # Assuming 'borough' is the key and 'population_density', 'avg_income' are features
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    # Aggregate census data by borough to reduce size before merging
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
                    print(f"Merged with census_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
                else:
                    print(f"Warning: Missing one or more expected columns ({relevant_census_cols}) in {census_data_path}. Skipping census data augmentation.")
            except Exception as e:
                print(f"Error loading or merging {census_data_path}: {e}. Skipping census data augmentation.")
        else:
            print("Warning: Borough information not available in combined_df to merge census data. Skipping.")
    else:
        print(f"Warning: {census_data_path} not found. Skipping census data augmentation.")

    # Add smoothed target encoded features to combined_df
    # 'train_df_raw' contains 'violation_count' as the target.
    print("Applying smoothed target encoding to street_name...")
    combined_df['street_name_te'] = add_smoothed_target_encoding(
        combined_df, train_df_raw, 'street_name', 'violation_count', alpha=100
    )
    print("Applying smoothed target encoding to violation_description...")
    combined_df['violation_description_te'] = add_smoothed_target_encoding(
        combined_df, train_df_raw, 'violation_description', 'violation_count', alpha=100
    )

    gc.collect()

    # --- Pre-processing categorical features for CatBoost ---
    # Identify all columns that should be treated as categorical for CatBoost
    cat_cols_for_catboost = [
        'street_name', 'violation_description'
    ]
    if 'borough' in combined_df.columns:
        cat_cols_for_catboost.append('borough')
    # Add any other columns from augmentation tables that are categorical.

    final_catboost_features = []
    print("Pre-processing identified categorical features for CatBoost (handling NaNs and types)...")
    for col in cat_cols_for_catboost:
        if col in combined_df.columns: # Ensure the column exists after all merges
            # Fill NaN values with 'UNKNOWN' and then convert to 'category' dtype.
            # This handles potential NaNs introduced by left merges and ensures consistent type.
            # `astype(str)` before `fillna` ensures that `pd.NA` or `np.nan` are converted to 'nan' string,
            # then 'nan' string is replaced by 'UNKNOWN'.
            combined_df[col] = combined_df[col].astype(str).replace('nan', 'UNKNOWN').astype('category')
            final_catboost_features.append(col)
        else:
            print(f"  Warning: Categorical column '{col}' not found in combined_df.")

    print(f"Final categorical features for CatBoost: {final_catboost_features}")

    # Split back into train and test processed dataframes
    # Merge the engineered features (which now have cleaned categorical columns) back to the raw dataframes
    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw # Free memory
    gc.collect()

    test_processed_df = None
    if test_df_raw is not None:
        test_processed_df = pd.merge(test_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
        del test_df_raw # Free memory
        gc.collect()

    print(f"Final train_processed_df shape: {train_processed_df.shape}")
    if test_processed_df is not None:
        print(f"Final test_processed_df shape: {test_processed_df.shape}")

    # The `categorical_features` list should be `final_catboost_features` from now on.
    return train_processed_df, test_processed_df, final_catboost_features

def train_and_predict(train_df, test_df, categorical_features):
    """
    Trains a CatBoost Regressor model and generates predictions.
    Reports RMSE for validation and test sets (if ground truth available).
    """
    print("Training CatBoost model...")

    # Define features (X) and target (y)
    feature_cols = [col for col in train_df.columns if col not in ['violation_count', 'is_pure_prediction']]

    X = train_df[feature_cols]
    y = train_df['violation_count']

    # Split training data for validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    print(f"Training data split: X_train={X_train.shape}, X_val={X_val.shape}")

    # Initialize CatBoost Regressor with OOM-conscious parameters
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6, # Reduced depth to manage memory
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=100, # Print metrics every 100 iterations
        early_stopping_rounds=50, # Stop if validation RMSE doesn't improve for 50 iterations
        # thread_count=-1, # Use all available cores if not explicitly limited by env
        # grow_policy='Lossguide', # Can be more memory efficient for deep trees
        # max_leaves=31 # For Lossguide, controls number of leaves
    )

    # Convert categorical feature names to their indices for CatBoost
    # Only include features that are actually in X_train's columns
    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]
    print(f"Categorical feature indices for CatBoost: {cat_features_indices}")

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                  # Setting early_stopping_rounds will stop training if the validation score doesn't improve
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        print("This might indicate an issue with data format or extreme memory pressure even with optimized parameters.")
        # Re-raising for debugging or handling gracefully, depending on requirements.
        raise

    # Validate on internal validation set
    val_preds = model.predict(X_val)
    val_preds[val_preds < 0] = 0 # Ensure non-negative predictions
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    print(f"Development Validation RMSE: {val_rmse}")

    # Generate predictions for the test_df if provided
    submission_df = None
    if test_df is not None:
        print("Generating predictions for test data...")
        # Features for prediction are the same as training
        X_test = test_df[feature_cols]

        # CatBoost handles unseen categories in test data by default due to our NaN handling
        test_preds = model.predict(X_test)
        # Ensure predictions are non-negative
        test_preds[test_preds < 0] = 0

        # Create submission dataframe
        submission_df = test_df[['street_name', 'violation_description']].copy()
        submission_df['predicted_count'] = test_preds

        # Report RMSE if ground truth is available in test_df
        # Only consider rows where 'is_pure_prediction' is False (i.e., violation_count is not NaN)
        if 'is_pure_prediction' in test_df.columns and not test_df['is_pure_prediction'].all(): 
            ground_truth_test_df = test_df[~test_df['is_pure_prediction']]
            ground_truth_preds = submission_df[~test_df['is_pure_prediction']]['predicted_count']
            test_rmse = np.sqrt(mean_squared_error(ground_truth_test_df['violation_count'], ground_truth_preds))
            print(f"RMSE on provided test/evaluation data (with ground truth): {test_rmse}")

        # Report unseen key pairs
        train_keys = set(train_df.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
        test_keys = set(test_df.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
        unseen_keys_count = len(test_keys - train_keys)
        print(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {unseen_keys_count}")
        print("Unseen keys are handled by CatBoost's internal mechanism for new categorical levels (assigned to an 'unknown' category) or by the smoothed target encoding (which uses global mean, for numerical features). For categorical features passed to CatBoost, NaNs are filled with 'UNKNOWN'.")

    return submission_df, val_rmse

def main():
    """
    Main function to parse arguments, orchestrate data loading, training, and prediction.
    """
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional path to the 2023 test/evaluation data CSV. '
                             'If provided, predictions will be generated and RMSE reported if ground truth exists.')
    args = parser.parse_args()

    train_df, test_df, categorical_features = load_and_preprocess_data(args.train_path, args.test_path)
    submission_df, final_validation_score = train_and_predict(train_df, test_df, categorical_features)

    if submission_df is not None:
        submission_df.to_csv('submission.csv', index=False)
        print("Submission file 'submission.csv' generated successfully.")

    # Always print the final validation score
    print(f"Final Validation Performance: {final_validation_score}")

if __name__ == "__main__":
    main()
