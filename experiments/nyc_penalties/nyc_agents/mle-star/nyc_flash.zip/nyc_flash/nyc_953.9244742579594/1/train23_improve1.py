
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import os

# Function to clean column names: converts to snake_case for consistent access
def clean_col_names(df):
    cols = df.columns
    new_cols = []
    for col in cols:
        new_col = col.strip().lower().replace(' ', '_').replace('.', '').replace('/', '_')
        new_cols.append(new_col)
    df.columns = new_cols
    return df

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                        help="Path to the 2022 training data.")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Optional: Path to the test/evaluation data for 2023.")
    
    args = parser.parse_args()

    # --- Load and Preprocess 2022 Training Data ---
    try:
        train_df_2022 = pd.read_csv(args.train_path)
    except FileNotFoundError:
        print(f"Error: Training data not found at {args.train_path}. Please ensure the file exists.")
        return
    
    # Store original column names before cleaning for later use in submission if needed
    original_train_cols = train_df_2022.columns.tolist()
    train_df_2022 = clean_col_names(train_df_2022)

    # --- Feature Engineering and Augmentation from 2022 data ---
    # Define core keys for aggregation
    KEY_COLS = ['street_name', 'violation_description']
    TARGET_COL = 'violation_count'

    # Aggregate average violations per (street_name, violation_description) pair
    avg_violations_per_pair = train_df_2022.groupby(KEY_COLS)[TARGET_COL].mean().reset_index()
    avg_violations_per_pair.rename(columns={TARGET_COL: 'avg_violations_per_pair'}, inplace=True)
    
    # Aggregate average violations per street
    avg_violations_per_street = train_df_2022.groupby('street_name')[TARGET_COL].mean().reset_index()
    avg_violations_per_street.rename(columns={TARGET_COL: 'avg_violations_per_street'}, inplace=True)

    # Aggregate average violations per violation description
    avg_violations_per_desc = train_df_2022.groupby('violation_description')[TARGET_COL].mean().reset_index()
    avg_violations_per_desc.rename(columns={TARGET_COL: 'avg_violations_per_desc'}, inplace=True)

    # Merge these aggregates into the main training dataframe
    train_df_2022 = pd.merge(train_df_2022, avg_violations_per_pair, on=KEY_COLS, how='left')
    train_df_2022 = pd.merge(train_df_2022, avg_violations_per_street, on='street_name', how='left')
    train_df_2022 = pd.merge(train_df_2022, avg_violations_per_desc, on='violation_description', how='left')
    
    # Define features and target after augmentation
    features = KEY_COLS + ['avg_violations_per_pair', 'avg_violations_per_street', 'avg_violations_per_desc']

    # Handle potential NaN values from merges if a key combination did not exist for aggregation (should not happen for train_df_2022 itself)
    # This is more critical for the test set if new combinations appear. For now, fill with 0.
    for col in ['avg_violations_per_pair', 'avg_violations_per_street', 'avg_violations_per_desc']:
        train_df_2022[col] = train_df_2022[col].fillna(0) 

    # --- Split 2022 Data for Validation ---
    X = train_df_2022[features]
    y = train_df_2022[TARGET_COL]

    # Using a simple random split for validation. For grouped holdout, more complex logic is needed.
    # Grouped by (street_name, violation_description) to ensure validation data has similar characteristics.
    # However, for CatBoost with default handling of unseen categories, a simple split is often sufficient
    # to evaluate model's generalization on known patterns.
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    # --- CatBoost Model Training ---
    cat_features_in_data = [col for col in KEY_COLS if col in X_train.columns]
    
    model = CatBoostRegressor(
        iterations=500,
        learning_rate=0.05,
        depth=10,
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Set to True for more output during training
        early_stopping_rounds=50,
        cat_features=cat_features_in_data
    )

    model.fit(X_train, y_train, eval_set=(X_val, y_val))

    # --- Evaluate on Validation Set ---
    val_predictions = model.predict(X_val)
    val_predictions[val_predictions < 0] = 0 # Clip predictions to be non-negative
    val_rmse = np.sqrt(mean_squared_error(y_val, val_predictions))
    print(f"Final Validation Performance: {val_rmse}")

    # --- Prediction on Test Data (if provided) ---
    if args.test_path:
        try:
            test_df = pd.read_csv(args.test_path)
        except FileNotFoundError:
            print(f"Error: Test data not found at {args.test_path}. Please ensure the file exists.")
            return
        
        # Keep original columns for submission file output
        original_test_street_name = test_df[original_train_cols[0]] # Assuming 'Street Name' is first col
        original_test_violation_desc = test_df[original_train_cols[1]] # Assuming 'Violation Description' is second col

        test_df = clean_col_names(test_df)

        # Merge augmentation features into test_df
        test_df = pd.merge(test_df, avg_violations_per_pair, on=KEY_COLS, how='left')
        test_df = pd.merge(test_df, avg_violations_per_street, on='street_name', how='left')
        test_df = pd.merge(test_df, avg_violations_per_desc, on='violation_description', how='left')

        # Fill NaNs for new combinations or unseen streets/violations in the test set
        # Using 0 as a default for unseen values is a common strategy.
        for col in ['avg_violations_per_pair', 'avg_violations_per_street', 'avg_violations_per_desc']:
            test_df[col] = test_df[col].fillna(0) 

        # Identify unseen key pairs for reporting
        train_keys = set(train_df_2022[KEY_COLS].apply(tuple, axis=1))
        test_keys = set(test_df[KEY_COLS].apply(tuple, axis=1))
        unseen_keys_count = len(test_keys - train_keys)
        print(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_keys_count}")

        # Prepare test features. Ensure all features from training are present.
        # CatBoost handles unseen categories by assigning them to a special internal category.
        X_test = test_df[features]
        
        predictions = model.predict(X_test)
        predictions[predictions < 0] = 0 # Clip predictions to be non-negative

        # Create submission file as specified
        submission_df = pd.DataFrame({
            'street_name': original_test_street_name,
            'violation_type': original_test_violation_desc,
            'predicted_count': predictions.round().astype(int) 
        })
        submission_df.to_csv("submission.csv", index=False)
        print("Submission file 'submission.csv' created.")

        # If 'violation_count' is present in the test file, calculate RMSE
        if TARGET_COL in test_df.columns:
            true_counts = test_df[TARGET_COL]
            test_rmse = np.sqrt(mean_squared_error(true_counts, predictions))
            print(f"RMSE on provided test/evaluation data: {test_rmse}")
        else:
            print("Test file does not contain 'violation_count' for RMSE calculation.")

if __name__ == "__main__":
    # Create a dummy input directory and file for testing purposes if they don't exist
    input_dir = "./input"
    train_file = os.path.join(input_dir, "violations_per_street_2022.csv")

    if not os.path.exists(input_dir):
        os.makedirs(input_dir)
        print(f"Created directory: {input_dir}")

    if not os.path.exists(train_file):
        dummy_data = {
            'Street Name': ['MAIN ST', 'ELM AVE', 'OAK BLVD', 'MAIN ST', 'ELM AVE', 'PINE DR', 'MAPLE RD', 'ELM AVE'],
            'Violation Description': ['PARKING METER', 'NO STANDING', 'DOUBLE PARKING', 'PARKING METER', 'NO STANDING', 'FIRE HYDRANT', 'NO PARKING', 'PARKING METER'],
            'violation_count': [100, 50, 20, 120, 60, 15, 30, 75]
        }
        dummy_df = pd.DataFrame(dummy_data)
        dummy_df.to_csv(train_file, index=False)
        print(f"Created dummy training file: {train_file}")
    
    main()

