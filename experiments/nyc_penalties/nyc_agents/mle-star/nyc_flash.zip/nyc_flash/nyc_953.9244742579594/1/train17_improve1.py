
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    initial_memory = df.memory_usage(deep=True).sum() / (1024**2)
    for col in df.columns:
        if df[col].dtype == 'int66': # Changed from int64 to int66 as int64 might be too specific
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    final_memory = df.memory_usage(deep=True).sum() / (1024**2)
    # print(f"  Memory reduced from {initial_memory:.2f} MB to {final_memory:.2f} MB for dataframe.")
    return df

def load_and_preprocess_data(train_path, test_path=None):
    """
    Loads, preprocesses, and merges data from various sources.
    Handles memory efficiency by selective column loading, aggregation, and garbage collection.
    """
    print("Loading and preprocessing data...")

    # --- Load Core Data ---
    # Load training data
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)
    print(f"Initial train_df loaded. Shape: {train_df_raw.shape}, Memory: {train_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Load test data if provided
    test_df_raw = None
    if test_path:
        test_df_raw = pd.read_csv(test_path)
        test_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
        # Create a flag for pure prediction rows where violation_count is NaN
        test_df_raw['is_pure_prediction'] = test_df_raw['violation_count'].isna()
        test_df_raw = downcast_dtypes(test_df_raw)
        print(f"Test_df loaded. Shape: {test_df_raw.shape}, Memory: {test_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Combine unique street_name and violation_description pairs from train and test
    # for consistent feature engineering.
    # Exclude 'violation_count' to prevent target leakage and reduce memory.
    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_keys_test = pd.DataFrame()
    if test_df_raw is not None:
        combined_keys_test = test_df_raw[['street_name', 'violation_description']].drop_duplicates()

    combined_df = pd.concat([combined_keys_train, combined_keys_test], ignore_index=True).drop_duplicates().reset_index(drop=True)
    del combined_keys_train, combined_keys_test # Free memory
    gc.collect()
    print(f"Combined unique (street, violation) pairs for feature engineering. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # --- Feature Engineering and Augmentation ---

    # Basic features from core data
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # Feature Engineering: Extract street_type from street_name suffix
    street_suffix_map = {
        'ST': 'STREET', 'STREET': 'STREET',
        'AVE': 'AVENUE', 'AVENUE': 'AVENUE',
        'RD': 'ROAD', 'ROAD': 'ROAD',
        'BLVD': 'BOULEVARD', 'BOULEVARD': 'BOULEVARD',
        'PKWY': 'PARKWAY', 'PARKWAY': 'PARKWAY',
        'LN': 'LANE', 'LANE': 'LANE',
        'DR': 'DRIVE', 'DRIVE': 'DRIVE',
        'SQ': 'SQUARE', 'SQUARE': 'SQUARE',
        'PL': 'PLACE', 'PLACE': 'PLACE',
        'CT': 'COURT', 'COURT': 'COURT',
        'TER': 'TERRACE', 'TERRACE': 'TERRACE',
        'WY': 'WAY', 'WAY': 'WAY',
        'CIR': 'CIRCLE', 'CIRCLE': 'CIRCLE',
        'HWY': 'HIGHWAY', 'HIGHWAY': 'HIGHWAY',
        'FWY': 'FREEWAY', 'FREEWAY': 'FREEWAY',
        'ALY': 'ALLEY', 'ALLEY': 'ALLEY',
        'RUN': 'RUN',
        'GATE': 'GATE',
        'WALK': 'WALK',
        'PLAZA': 'PLAZA',
        'MALL': 'MALL',
        'CONC': 'CONCOURSE', 'CONCOURSE': 'CONCOURSE',
        'EXPY': 'EXPRESSWAY', 'EXPRESSWAY': 'EXPRESSWAY',
        'PKY': 'PARKWAY',
        'PT': 'POINT', 'POINT': 'POINT',
        'TRL': 'TRAIL', 'TRAIL': 'TRAIL',
        'VW': 'VIEW', 'VIEW': 'VIEW',
        'XING': 'CROSSING', 'CROSSING': 'CROSSING',
        'CR': 'CRESCENT', 'CRESCENT': 'CRESCENT',
        'ROW': 'ROW',
        'LOOP': 'LOOP',
        'COVE': 'COVE',
        'PATH': 'PATH',
        'VLY': 'VALLEY', 'VALLEY': 'VALLEY',
        'DIV': 'DIVIDE', 'DIVIDE': 'DIVIDE'
    }

    processed_street_map = {}
    for k, v in street_suffix_map.items():
        processed_street_map[k.upper().strip('.')] = v.upper()
        for direction in ['N', 'S', 'E', 'W', 'NORTH', 'SOUTH', 'EAST', 'WEST']:
            processed_street_map[f"{k.upper().strip('.')} {direction}"] = v.upper()
            processed_street_map[f"{k.upper().strip('.')}{direction}"] = v.upper()

    def get_street_type_from_suffix(street_name):
        if not isinstance(street_name, str):
            return 'OTHER'
        s_name_upper = street_name.upper().strip()

        for suffix_key in sorted(processed_street_map.keys(), key=len, reverse=True):
            if s_name_upper.endswith(suffix_key):
                return processed_street_map[suffix_key]

        parts = s_name_upper.split()
        if not parts:
            return 'OTHER'

        last_word = parts[-1].strip('.').strip(',')
        if last_word in processed_street_map:
            return processed_street_map[last_word]

        if len(parts) >= 2:
            second_last_word = parts[-2].strip('.').strip(',')
            if second_last_word in processed_street_map:
                return processed_street_map[second_last_word]
        return 'OTHER'

    combined_df['street_type'] = combined_df['street_name'].apply(get_street_type_from_suffix).astype('category')


    # Feature Engineering: Extract violation_category from violation_description keywords
    violation_keywords = {
        'NO PARKING': 'NO PARKING',
        'HANDICAP': 'HANDICAP',
        'FIRE LANE': 'FIRE LANE',
        'BUS STOP': 'BUS STOP',
        'HYDRANT': 'HYDRANT',
        'STANDING': 'STANDING',
        'METER': 'METER',
        'COMMERCIAL': 'COMMERCIAL',
        'LOADING': 'LOADING',
        'RESIDENTIAL': 'RESIDENTIAL',
        'DOUBLE PARKING': 'DOUBLE PARKING',
        'OVERTIME': 'OVERTIME',
        'EXPIRED': 'EXPIRED',
        'CLEANING': 'STREET CLEANING',
        'STREET CLEANING': 'STREET CLEANING',
        'PERMIT': 'PERMIT REQUIRED',
        'SAFETY ZONE': 'SAFETY ZONE',
        'DRIVEWAY': 'DRIVEWAY',
        'SIDEWALK': 'SIDEWALK',
        'NO STANDING': 'NO STANDING',
        'CROSSWALK': 'CROSSWALK',
        'INTERSECTION': 'INTERSECTION'
    }

    sorted_keywords = sorted(violation_keywords.keys(), key=len, reverse=True)

    def extract_violation_category(description):
        if not isinstance(description, str):
            return 'OTHER'
        desc_upper = description.upper()
        for keyword in sorted_keywords:
            if keyword in desc_upper:
                return violation_keywords[keyword]
        return 'OTHER'

    combined_df['violation_category'] = combined_df['violation_description'].apply(extract_violation_category).astype('category')

    # Augmentation 1: nyc_street_data.csv
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        print(f"Loading {street_data_path}...")
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
            print(f"Merged with street_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading or merging {street_data_path}: {e}. Skipping street data augmentation.")
    else:
        print(f"Warning: {street_data_path} not found. Skipping street data augmentation.")

    # Augmentation 2: nyc_violation_codes.csv
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        print(f"Loading {violation_codes_path}...")
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
            print(f"Merged with violation_codes. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading or merging {violation_codes_path}: {e}. Skipping violation codes augmentation.")
    else:
        print(f"Warning: {violation_codes_path} not found. Skipping violation codes augmentation.")

    # Augmentation 3: nyc_census_data.csv (Hypothetical)
    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        print(f"Loading {census_data_path}...")
        if 'borough' in combined_df.columns:
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
                    print(f"Merged with census_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
                else:
                    print(f"Warning: Missing one or more expected columns ({relevant_census_cols}) in {census_data_path}. Skipping census data augmentation.")
            except Exception as e:
                print(f"Error loading or merging {census_data_path}: {e}. Skipping census data augmentation.")
        else:
            print("Warning: Borough information not available in combined_df to merge census data. Skipping.")
    else:
        print(f"Warning: {census_data_path} not found. Skipping census data augmentation.")


    # Split back into train and test processed dataframes
    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    test_processed_df = None
    if test_df_raw is not None:
        test_processed_df = pd.merge(test_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
        del test_df_raw
        gc.collect()

    print(f"Final train_processed_df shape: {train_processed_df.shape}")
    if test_processed_df is not None:
        print(f"Final test_processed_df shape: {test_processed_df.shape}")

    # --- Bug Fix: Handle NaN values in categorical features for CatBoost ---
    # Identify all columns in the final processed DFs that should be treated as categorical by CatBoost.
    # This includes original identifiers and engineered/merged categorical features.
    final_categorical_cols = []
    # These are the columns explicitly expected to be categorical:
    potential_categorical_candidates = ['street_name', 'violation_description', 'street_type', 'violation_category']
    if 'borough' in train_processed_df.columns: # 'borough' is added via merge and can contain NaNs
        potential_categorical_candidates.append('borough')

    for col in potential_categorical_candidates:
        if col in train_processed_df.columns:
            final_categorical_cols.append(col)

    print(f"Handling NaN values and ensuring 'category' dtype for identified categorical features: {final_categorical_cols}")

    for col in final_categorical_cols:
        # Convert to string (to handle any NaN which is float type), fill NaN with a placeholder,
        # then convert to category. This robustly prepares categorical features for CatBoost.
        train_processed_df[col] = train_processed_df[col].astype(str).fillna('Unknown_Category').astype('category')
        if test_processed_df is not None and col in test_processed_df.columns:
            test_processed_df[col] = test_processed_df[col].astype(str).fillna('Unknown_Category').astype('category')
            
    # Update the categorical_features list to reflect the actual dtypes after processing
    categorical_features = final_categorical_cols
    print(f"Final categorical features for CatBoost: {categorical_features}")

    return train_processed_df, test_processed_df, categorical_features

def train_and_predict(train_df, test_df, categorical_features):
    """
    Trains a CatBoost Regressor model and generates predictions.
    Reports RMSE for validation and test sets (if ground truth available).
    """
    print("Training CatBoost model...")

    # Define features (X) and target (y)
    # Ensure 'is_pure_prediction' is not used as a feature
    features = [col for col in train_df.columns if col not in ['violation_count', 'is_pure_prediction']]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    # Split training data for validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    print(f"Training data split: X_train={X_train.shape}, X_val={X_val.shape}")

    # Initialize CatBoost Regressor with OOM-conscious parameters
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6, # Reduced depth to manage memory
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=100, # Print metrics every 100 iterations
        early_stopping_rounds=50, # Stop if validation RMSE doesn't improve for 50 iterations
        thread_count=-1, # Use all available cores if not explicitly limited by env
    )

    # Train the model
    # Convert categorical feature names to their indices for CatBoost
    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]
    print(f"Categorical feature indices for CatBoost: {cat_features_indices}")

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                  # use_best_model=True # Removed to simplify and avoid potential issues with early stopping interaction for basic fix
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        print("This might indicate an issue with data format or extreme memory pressure even with optimized parameters.")
        raise

    # Validate on internal validation set
    val_preds = model.predict(X_val)
    val_preds[val_preds < 0] = 0 # Ensure predictions are non-negative
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    print(f"Development Validation RMSE: {val_rmse}")

    # Generate predictions for the test_df if provided
    submission_df = None
    if test_df is not None:
        print("Generating predictions for test data...")
        # Features for prediction are the same as training
        X_test = test_df[features]

        test_preds = model.predict(X_test)
        # Ensure predictions are non-negative
        test_preds[test_preds < 0] = 0

        # Create submission dataframe
        submission_df = test_df[['street_name', 'violation_description']].copy()
        submission_df['predicted_count'] = test_preds

        # Report RMSE if ground truth is available in test_df
        if 'is_pure_prediction' in test_df.columns and not test_df['is_pure_prediction'].all(): # If some ground truth exists
            ground_truth_test_df = test_df[~test_df['is_pure_prediction']]
            # Make sure to align predictions with ground truth rows correctly
            ground_truth_preds_indexed = submission_df.loc[~test_df['is_pure_prediction'], 'predicted_count']
            test_rmse = np.sqrt(mean_squared_error(ground_truth_test_df['violation_count'], ground_truth_preds_indexed))
            print(f"RMSE on provided test/evaluation data (with ground truth): {test_rmse}")

        # Report unseen key pairs
        train_keys = set(train_df.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
        test_keys = set(test_df.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
        unseen_keys_count = len(test_keys - train_keys)
        print(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {unseen_keys_count}")
        print("Unseen keys are handled by CatBoost's internal mechanism for new categorical levels (assigned to an 'unknown' category generated from `Unknown_Category` placeholder).")

    return submission_df, val_rmse

def main():
    """
    Main function to parse arguments, orchestrate data loading, training, and prediction.
    """
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional path to the 2023 test/evaluation data CSV. '
                             'If provided, predictions will be generated and RMSE reported if ground truth exists.')
    args = parser.parse_args()

    train_df, test_df, categorical_features = load_and_preprocess_data(args.train_path, args.test_path)
    submission_df, final_validation_score = train_and_predict(train_df, test_df, categorical_features)

    if submission_df is not None:
        # Ensure required columns exist before writing
        required_cols = ['street_name', 'violation_description', 'predicted_count']
        submission_df_final = submission_df[required_cols]
        submission_df_final.columns = ['street_name', 'violation_type', 'predicted_count'] # Rename for output
        submission_df_final.to_csv('submission.csv', index=False)
        print("Submission file 'submission.csv' generated successfully.")

    # Always print the final validation score
    print(f"Final Validation Performance: {final_validation_score}")

if __name__ == "__main__":
    main()
