
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    initial_memory = df.memory_usage(deep=True).sum() / (1024**2)
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        # Important: NaNs in object columns will remain NaNs if converted to category here.
        # These need to be explicitly handled later for CatBoost.
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            # and it's not a primary key like 'street_name' or 'violation_description'
            # (though these keys generally shouldn't have NaNs and are fine as category)
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    final_memory = df.memory_usage(deep=True).sum() / (1024**2)
    # print(f"  Memory reduced from {initial_memory:.2f} MB to {final_memory:.2f} MB for dataframe.")
    return df

def load_and_preprocess_data(train_path, test_path=None):
    """
    Loads, preprocesses, and merges data from various sources.
    Handles memory efficiency by selective column loading, aggregation, and garbage collection.
    """
    print("Loading and preprocessing data...")

    # --- Load Core Data ---
    # Load training data
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)
    print(f"Initial train_df loaded. Shape: {train_df_raw.shape}, Memory: {train_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Load test data if provided
    test_df_raw = None
    if test_path:
        test_df_raw = pd.read_csv(test_path)
        test_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
        # Create a flag for pure prediction rows where violation_count is NaN
        test_df_raw['is_pure_prediction'] = test_df_raw['violation_count'].isna()
        test_df_raw = downcast_dtypes(test_df_raw)
        print(f"Test_df loaded. Shape: {test_df_raw.shape}, Memory: {test_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Combine unique street_name and violation_description pairs from train and test
    # for consistent feature engineering.
    # Exclude 'violation_count' to prevent target leakage and reduce memory.
    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_keys_test = pd.DataFrame()
    if test_df_raw is not None:
        combined_keys_test = test_df_raw[['street_name', 'violation_description']].drop_duplicates()

    combined_df = pd.concat([combined_keys_train, combined_keys_test], ignore_index=True).drop_duplicates().reset_index(drop=True)
    del combined_keys_train, combined_keys_test # Free memory
    gc.collect()
    print(f"Combined unique (street, violation) pairs for feature engineering. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # --- Feature Engineering and Augmentation ---

    # Basic features from core data
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # Augmentation 1: nyc_street_data.csv
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        print(f"Loading {street_data_path}...")
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough_street', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            
            # Fill NaNs in 'borough_street' column before merge to ensure consistency
            # if 'borough_street' becomes a categorical feature later
            street_data['borough_street'] = street_data['borough_street'].fillna('Unknown_Borough_Street')
            
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')

            combined_df['has_street_data'] = combined_df['street_length'].notna().astype('int8')
            combined_df['street_length'] = combined_df['street_length'].fillna(-1).astype('float32') 
            combined_df['num_lanes'] = combined_df['num_lanes'].fillna(-1).astype('int8') 
            
            # Fill NaNs for 'borough_street' that might result from the left merge
            # (if a street in combined_df had no match in street_data)
            combined_df['borough_street'] = combined_df['borough_street'].fillna('Unknown_Borough_Street')
            
            del street_data
            gc.collect()
            print(f"Merged with street_data and refined. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading or merging {street_data_path}: {e}. Skipping street data augmentation.")
    else:
        print(f"Warning: {street_data_path} not found. Skipping street data augmentation.")

    # Augmentation 2: nyc_violation_codes.csv
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        print(f"Loading {violation_codes_path}...")
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])

            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')

            combined_df['has_violation_codes'] = combined_df['fine_amount'].notna().astype('int8')
            combined_df['fine_amount'] = combined_df['fine_amount'].fillna(-1).astype('float32') 
            combined_df['points'] = combined_df['points'].fillna(-1).astype('int8') 

            del violation_codes
            gc.collect()
            print(f"Merged with violation_codes and refined. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading or merging {violation_codes_path}: {e}. Skipping violation codes augmentation.")
    else:
        print(f"Warning: {violation_codes_path} not found. Skipping violation codes augmentation.")

    # Augmentation 3: nyc_census_data.csv
    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        print(f"Loading {census_data_path}...")
        borough_key_col = 'borough_street' if 'borough_street' in combined_df.columns else None
        
        if borough_key_col:
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]

                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    # Fill NaNs in 'borough' column of census_data before aggregation if any exist
                    if 'borough' in census_data.columns and census_data['borough'].isnull().any():
                        census_data['borough'] = census_data['borough'].fillna('Unknown_Census_Borough')

                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    
                    combined_df = pd.merge(combined_df, census_agg, left_on=borough_key_col, right_on='borough', how='left', suffixes=('', '_census')) 
                    combined_df.drop(columns='borough_census', inplace=True, errors='ignore')

                    combined_df['has_census_data'] = combined_df['population_density'].notna().astype('int8')
                    combined_df['population_density'] = combined_df['population_density'].fillna(-1).astype('float32')
                    combined_df['avg_income'] = combined_df['avg_income'].fillna(-1).astype('float32')
                    
                    del census_data, census_agg
                    gc.collect()
                    print(f"Merged with census_data and refined. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
                else:
                    print(f"Warning: Missing one or more expected columns ({relevant_census_cols}) in {census_data_path}. Skipping census data augmentation.")
            except Exception as e:
                print(f"Error loading or merging {census_data_path}: {e}. Skipping census data augmentation.")
        else:
            print(f"Warning: '{borough_key_col}' information not available in combined_df to merge census data. Skipping.")
    else:
        print(f"Warning: {census_data_path} not found. Skipping census data augmentation.")


    # Split back into train and test processed dataframes
    # Merge the engineered features back to the raw dataframes (which still hold violation_count and is_pure_prediction)
    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    test_processed_df = None
    if test_df_raw is not None:
        test_processed_df = pd.merge(test_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
        del test_df_raw
        gc.collect()

    print(f"Final train_processed_df shape: {train_processed_df.shape}")
    if test_processed_df is not None:
        print(f"Final test_processed_df shape: {test_processed_df.shape}")

    # Identify categorical features from the *final* processed dataframes
    # and ensure they do not contain NaNs for CatBoost
    
    # Collect all columns that are currently object or category dtype in train_processed_df
    # These are the candidates for CatBoost's categorical features.
    potential_categorical_cols = [col for col in train_processed_df.columns if train_processed_df[col].dtype in ['object', 'category']]

    # Iterate through these candidates and fill any NaNs, then convert to 'category' dtype
    # This ensures consistency and handles any NaNs introduced by merges for string-like columns.
    categorical_features = []
    for col in potential_categorical_cols:
        if train_processed_df[col].isnull().any():
            train_processed_df[col] = train_processed_df[col].fillna('MISSING_CATEGORY_VALUE')
        train_processed_df[col] = train_processed_df[col].astype('category')
        categorical_features.append(col) # Add to list after ensuring no NaNs and proper type

        if test_processed_df is not None and col in test_processed_df.columns:
            if test_processed_df[col].isnull().any():
                test_processed_df[col] = test_processed_df[col].fillna('MISSING_CATEGORY_VALUE')
            # Ensure consistency of categories between train and test
            # By converting to category without explicit `categories=...`, pandas will infer.
            # CatBoost handles unseen categories in test data by mapping them to an 'unknown' category.
            test_processed_df[col] = test_processed_df[col].astype('category')

    # Re-verify the list of categorical features after final conversions
    # (redundant check, but ensures the list is accurate post-processing)
    categorical_features = [col for col in categorical_features if pd.api.types.is_categorical_dtype(train_processed_df[col])]


    print(f"Categorical features identified for CatBoost: {categorical_features}")

    return train_processed_df, test_processed_df, categorical_features

def train_and_predict(train_df, test_df, categorical_features):
    """
    Trains a CatBoost Regressor model and generates predictions.
    Reports RMSE for validation and test sets (if ground truth available).
    """
    print("Training CatBoost model...")

    # Define features (X) and target (y)
    # Ensure 'is_pure_prediction' is not used as a feature if it exists
    features_to_exclude = ['violation_count', 'is_pure_prediction']
    features = [col for col in train_df.columns if col not in features_to_exclude]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    # Split training data for validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    print(f"Training data split: X_train={X_train.shape}, X_val={X_val.shape}")

    # Initialize CatBoost Regressor with OOM-conscious parameters
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6, # Reduced depth to manage memory
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=100, # Print metrics every 100 iterations
        early_stopping_rounds=50, # Stop if validation RMSE doesn't improve for 50 iterations
        # thread_count=-1, # Use all available cores if not explicitly limited by env
        # grow_policy='Lossguide', # Can be more memory efficient for deep trees
        # max_leaves=31 # For Lossguide, controls number of leaves
    )

    # Train the model
    # Convert categorical feature names to their indices for CatBoost
    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]
    print(f"Categorical feature indices for CatBoost: {cat_features_indices}")

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        print("This might indicate an issue with data format or extreme memory pressure even with optimized parameters.")
        # Re-raising for debugging or handling gracefully, depending on requirements.
        raise

    # Validate on internal validation set
    val_preds = model.predict(X_val)
    val_preds[val_preds < 0] = 0 # Clip negative predictions
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    print(f"Development Validation RMSE: {val_rmse}")

    # Generate predictions for the test_df if provided
    submission_df = None
    if test_df is not None:
        print("Generating predictions for test data...")
        # Features for prediction are the same as training
        X_test = test_df[features]

        # CatBoost handles unseen categories in test data by default
        test_preds = model.predict(X_test)
        # Ensure predictions are non-negative
        test_preds[test_preds < 0] = 0

        # Create submission dataframe
        submission_df = test_df[['street_name', 'violation_description']].copy()
        submission_df['predicted_count'] = test_preds

        # Report RMSE if ground truth is available in test_df
        if 'is_pure_prediction' in test_df.columns and not test_df['is_pure_prediction'].all(): # If some ground truth exists
            ground_truth_test_df = test_df[~test_df['is_pure_prediction']]
            # Ensure ground_truth_preds aligns with ground_truth_test_df by using its index
            ground_truth_preds_series = pd.Series(test_preds, index=test_df.index)
            ground_truth_preds = ground_truth_preds_series.loc[~test_df['is_pure_prediction']]
            
            test_rmse = np.sqrt(mean_squared_error(ground_truth_test_df['violation_count'], ground_truth_preds))
            print(f"RMSE on provided test/evaluation data (with ground truth): {test_rmse}")

        # Report unseen key pairs
        train_keys = set(train_df.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
        test_keys = set(test_df.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
        unseen_keys_count = len(test_keys - train_keys)
        print(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {unseen_keys_count}")
        print("Unseen keys are handled by CatBoost's internal mechanism for new categorical levels (assigned to an 'unknown' category).")

    return submission_df, val_rmse

def main():
    """
    Main function to parse arguments, orchestrate data loading, training, and prediction.
    """
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional path to the 2023 test/evaluation data CSV. '
                             'If provided, predictions will be generated and RMSE reported if ground truth exists.')
    args = parser.parse_args()

    train_df, test_df, categorical_features = load_and_preprocess_data(args.train_path, args.test_path)
    submission_df, final_validation_score = train_and_predict(train_df, test_df, categorical_features)

    if submission_df is not None:
        # Ensure output directory exists if it's different from current
        output_dir = './'
        os.makedirs(output_dir, exist_ok=True)
        submission_df.to_csv(os.path.join(output_dir, 'submission.csv'), index=False)
        print(f"Submission file '{os.path.join(output_dir, 'submission.csv')}' generated successfully.")

    # Always print the final validation score
    print(f"Final Validation Performance: {final_validation_score}")

if __name__ == "__main__":
    main()
