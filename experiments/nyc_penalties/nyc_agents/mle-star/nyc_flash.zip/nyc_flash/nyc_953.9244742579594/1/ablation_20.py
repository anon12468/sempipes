
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# --- Helper functions copied and modified for ablation study ---

def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    # initial_memory = df.memory_usage(deep=True).sum() / (1024**2) # Suppress print
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    # final_memory = df.memory_usage(deep=True).sum() / (1024**2) # Suppress print
    # print(f"  Memory reduced from {initial_memory:.2f} MB to {final_memory:.2f} MB for dataframe.") # Suppress print
    return df

def load_and_preprocess_data_ablated(train_path,
                                     enable_violation_keyword_counts=True,
                                     enable_street_has_digit=True):
    """
    Loads, preprocesses, and merges data from various sources.
    Modified to allow ablating specific features. Test path is ignored.
    """
    # print("Loading and preprocessing data for ablation...") # Suppress print

    # --- Load Core Data ---
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)
    # print(f"Initial train_df loaded. Shape: {train_df_raw.shape}, Memory: {train_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB") # Suppress print

    # Combine unique street_name and violation_description pairs from train for consistent feature engineering.
    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_df = combined_keys_train.reset_index(drop=True)
    del combined_keys_train
    gc.collect()
    # print(f"Combined unique (street, violation) pairs for feature engineering. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB") # Suppress print

    # --- Feature Engineering and Augmentation ---
    combined_df['street_name_len'] = combined_df['street_name'].apply(lambda x: len(str(x))).astype('int16')
    combined_df['street_name_word_count'] = combined_df['street_name'].apply(lambda x: len(str(x).split())).astype('int16')
    if enable_street_has_digit:
        combined_df['street_name_has_digit'] = combined_df['street_name'].apply(lambda x: 1 if any(char.isdigit() for char in str(x)) else 0).astype('int8')

    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(lambda x: len(str(x))).astype('int16')
    combined_df['violation_desc_word_count'] = combined_df['violation_description'].apply(lambda x: len(str(x).split())).astype('int16')
    if enable_violation_keyword_counts:
        combined_df['violation_desc_parking_count'] = combined_df['violation_description'].str.lower().str.count('parking').fillna(0).astype('int16')
        combined_df['violation_desc_standing_count'] = combined_df['violation_description'].str.lower().str.count('standing').fillna(0).astype('int16')
        combined_df['violation_desc_unregistered_count'] = combined_df['violation_description'].str.lower().str.count('unregistered').fillna(0).astype('int16')
        combined_df['violation_desc_expired_count'] = combined_df['violation_description'].str.lower().str.count('expired').fillna(0).astype('int16')

    # Augmentation 1: nyc_street_data.csv
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        # print(f"Loading {street_data_path}...") # Suppress print
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
            # print(f"Merged with street_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB") # Suppress print
        except Exception as e:
            # print(f"Error loading or merging {street_data_path}: {e}. Skipping street data augmentation.") # Suppress print
            pass
    # else: # Suppress warning for ablation
        # print(f"Warning: {street_data_path} not found. Skipping street data augmentation.")

    # Augmentation 2: nyc_violation_codes.csv
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        # print(f"Loading {violation_codes_path}...") # Suppress print
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
            # print(f"Merged with violation_codes. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB") # Suppress print
        except Exception as e:
            # print(f"Error loading or merging {violation_codes_path}: {e}. Skipping violation codes augmentation.") # Suppress print
            pass
    # else: # Suppress warning for ablation
        # print(f"Warning: {violation_codes_path} not found. Skipping violation codes augmentation.")

    # Augmentation 3: nyc_census_data.csv (Hypothetical)
    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        # print(f"Loading {census_data_path}...") # Suppress print
        if 'borough' in combined_df.columns and combined_df['borough'].isnull().sum() < len(combined_df):
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
                    # print(f"Merged with census_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB") # Suppress print
            except Exception as e:
                # print(f"Error loading or merging {census_data_path}: {e}. Skipping census data augmentation.") # Suppress print
                pass
        # else: # Suppress warning for ablation
            # print("Warning: Borough information not available or mostly NaN in combined_df to merge census data. Skipping.")
    # else: # Suppress warning for ablation
        # print(f"Warning: {census_data_path} not found. Skipping census data augmentation.")

    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    # print(f"Final train_processed_df shape: {train_processed_df.shape}") # Suppress print

    categorical_features = []
    for col in combined_df.columns:
        if combined_df[col].dtype in ['object', 'category']:
            categorical_features.append(col)

    categorical_features_final = [col for col in categorical_features if col in train_processed_df.columns]
    # print(f"Categorical features identified for CatBoost: {categorical_features_final}") # Suppress print

    # Handle NaN values in categorical features
    for col in categorical_features_final:
        if train_processed_df[col].isnull().any():
            train_processed_df[col] = train_processed_df[col].astype(str).fillna('UNKNOWN_CATEGORY')
            # print(f"  Filled NaN values in categorical feature '{col}' of train_processed_df.") # Suppress print
    
    # Ensure columns are of 'category' type for consistency and potential memory benefits.
    for col in categorical_features_final:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].astype('category')

    return train_processed_df, None, categorical_features_final # Always return None for test_df in ablation

def train_and_predict_ablated(train_df, categorical_features,
                             catboost_depth=6, catboost_l2_leaf_reg=3):
    """
    Trains a CatBoost Regressor model and returns validation RMSE.
    Modified to allow ablating CatBoost hyperparameters. Test_df is ignored.
    """
    # print("Training CatBoost model for ablation...") # Suppress print

    features = [col for col in train_df.columns if col not in ['violation_count', 'is_pure_prediction']]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    # print(f"Training data split: X_train={X_train.shape}, X_val={X_val.shape}") # Suppress print

    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=catboost_depth,
        l2_leaf_reg=catboost_l2_leaf_reg,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Suppress verbose output for ablation runs
        early_stopping_rounds=50,
    )

    cat_features_for_catboost = [col for col in categorical_features if col in X_train.columns]
    cat_features_indices = [X_train.columns.get_loc(col) for col in cat_features_for_catboost]
    # print(f"Categorical feature indices for CatBoost: {cat_features_indices}") # Suppress print

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        print(f"Error during CatBoost training in ablation: {e}")
        raise

    val_preds = model.predict(X_val)
    val_preds[val_preds < 0] = 0
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    # print(f"Development Validation RMSE: {val_rmse}") # Suppress print

    return None, val_rmse # No submission_df needed for ablation


# --- Main Ablation Study Logic ---

def main_ablation():
    train_path = './input/violations_per_street_2022.csv'
    
    # Ensure a dummy input directory exists for the ablation script to run without errors
    if not os.path.exists('./input'):
        os.makedirs('./input')

    results = {}

    # Base Case
    train_df_base, _, categorical_features_base = load_and_preprocess_data_ablated(
        train_path,
        enable_violation_keyword_counts=True,
        enable_street_has_digit=True
    )
    _, rmse_base = train_and_predict_ablated(
        train_df_base,
        categorical_features_base,
        catboost_depth=6,
        catboost_l2_leaf_reg=3
    )
    results['Base Case'] = rmse_base
    print(f"Base Case Validation RMSE: {rmse_base:.4f}")
    del train_df_base, categorical_features_base
    gc.collect()

    # Ablation 1: No Violation Keyword Count Features
    train_df_abl1, _, categorical_features_abl1 = load_and_preprocess_data_ablated(
        train_path,
        enable_violation_keyword_counts=False,
        enable_street_has_digit=True
    )
    _, rmse_abl1 = train_and_predict_ablated(
        train_df_abl1,
        categorical_features_abl1,
        catboost_depth=6,
        catboost_l2_leaf_reg=3
    )
    results['No Violation Keyword Count Features'] = rmse_abl1
    print(f"Ablation 1 Validation RMSE (No Violation Keyword Count Features): {rmse_abl1:.4f} (Delta: {rmse_abl1 - rmse_base:.4f})")
    del train_df_abl1, categorical_features_abl1
    gc.collect()

    # Ablation 2: No Street Name Has Digit Feature
    train_df_abl2, _, categorical_features_abl2 = load_and_preprocess_data_ablated(
        train_path,
        enable_violation_keyword_counts=True,
        enable_street_has_digit=False
    )
    _, rmse_abl2 = train_and_predict_ablated(
        train_df_abl2,
        categorical_features_abl2,
        catboost_depth=6,
        catboost_l2_leaf_reg=3
    )
    results['No Street Name Has Digit Feature'] = rmse_abl2
    print(f"Ablation 2 Validation RMSE (No Street Name Has Digit Feature): {rmse_abl2:.4f} (Delta: {rmse_abl2 - rmse_base:.4f})")
    del train_df_abl2, categorical_features_abl2
    gc.collect()

    # Ablation 3: Increased CatBoost Depth (from 6 to 8)
    train_df_abl3, _, categorical_features_abl3 = load_and_preprocess_data_ablated(
        train_path,
        enable_violation_keyword_counts=True,
        enable_street_has_digit=True
    )
    _, rmse_abl3 = train_and_predict_ablated(
        train_df_abl3,
        categorical_features_abl3,
        catboost_depth=8, # Changed depth
        catboost_l2_leaf_reg=3
    )
    results['Increased CatBoost Depth (6 -> 8)'] = rmse_abl3
    print(f"Ablation 3 Validation RMSE (Increased CatBoost Depth (6 -> 8)): {rmse_abl3:.4f} (Delta: {rmse_abl3 - rmse_base:.4f})")
    del train_df_abl3, categorical_features_abl3
    gc.collect()

    print("\n--- Ablation Study Summary ---")
    for name, rmse in results.items():
        if name == 'Base Case':
            print(f"{name}: {rmse:.4f}")
        else:
            delta = rmse - results['Base Case']
            print(f"{name}: {rmse:.4f} (Delta from Base: {delta:.4f})")

    # Determine the most contributing part (largest absolute delta from base)
    most_impactful_change = None
    max_abs_delta = 0.0

    for name, rmse in results.items():
        if name != 'Base Case':
            delta = rmse - results['Base Case']
            abs_delta = abs(delta)
            if abs_delta > max_abs_delta:
                max_abs_delta = abs_delta
                most_impactful_change = name
    
    if most_impactful_change:
        final_delta = results[most_impactful_change] - results['Base Case']
        impact_type = "improved" if final_delta < 0 else "degraded"
        print(f"\nConclusion: The most contributing part to the overall performance (based on absolute RMSE change) was '{most_impactful_change}'. Its modification resulted in a {impact_type} RMSE by {abs(final_delta):.4f}.")
    else:
        print("\nConclusion: No measurable impact observed from the ablations.")

if __name__ == "__main__":
    main_ablation()
