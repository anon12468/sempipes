
import subprocess
import sys
import os
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import argparse

# --- Package Installation Check and Installation ---
def install(package):
    """Installs a pip package if it's not already installed."""
    try:
        __import__(package)
    except ImportError:
        print(f"Installing {package}...", file=sys.stderr)
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", package])
            print(f"Successfully installed {package}.", file=sys.stderr)
        except subprocess.CalledProcessError as e:
            print(f"Error installing {package}: {e}", file=sys.stderr)
            # Re-raise to ensure the script terminates if installation fails
            raise

required_packages = ['pandas', 'numpy', 'scikit-learn', 'catboost', 'argparse']
for pkg in required_packages:
    # Handle different import names vs. package names
    if pkg == 'scikit-learn':
        install('sklearn')
    else:
        install(pkg)

# --- Argument Parsing ---
parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                    help="Path to the 2022 training data CSV.")
parser.add_argument("--test-path", type=str, default=None,
                    help="Optional path to the test/evaluation data CSV for 2023. If provided, predictions will be generated and RMSE calculated if ground truth is present.")
args = parser.parse_args()

TRAIN_FILE = args.train_path
TEST_FILE = args.test_path

# --- File Existence Checks ---
if not os.path.exists(TRAIN_FILE):
    print(f"Error: Training file not found at '{TRAIN_FILE}'", file=sys.stderr)
    raise FileNotFoundError(f"Training file not found: {TRAIN_FILE}")

if TEST_FILE and not os.path.exists(TEST_FILE):
    print(f"Error: Test file not found at '{TEST_FILE}'", file=sys.stderr)
    raise FileNotFoundError(f"Test file not found: {TEST_FILE}")

print(f"Using training data from: {TRAIN_FILE}", file=sys.stderr)
if TEST_FILE:
    print(f"Using test/evaluation data from: {TEST_FILE}", file=sys.stderr)
else:
    print("No test/evaluation data provided. Will only perform internal validation.", file=sys.stderr)

# --- Data Loading ---
try:
    df_2022 = pd.read_csv(TRAIN_FILE)
    df_2022.columns = ['Street Name', 'Violation Description', 'violation_count'] # Ensure consistent column names
except Exception as e:
    print(f"Error loading training data from '{TRAIN_FILE}': {e}", file=sys.stderr)
    raise

# Load augmentation tables
input_dir = os.path.dirname(TRAIN_FILE) if os.path.dirname(TRAIN_FILE) else './input'
augmentation_dfs = {}
augmentation_files = {
    'streets': 'nyc_streets_metadata.csv',
    'violations': 'violation_codes.csv',
    'census': 'nyc_census_data.csv',
    # 'weather': 'nyc_weather_data.csv' # Not using weather for annual predictions in this version
}

for name, filename in augmentation_files.items():
    filepath = os.path.join(input_dir, filename)
    try:
        augmentation_dfs[name] = pd.read_csv(filepath)
        print(f"Loaded augmentation data: {filename}", file=sys.stderr)
    except FileNotFoundError:
        print(f"Warning: Augmentation file not found: '{filepath}'. Some features may be missing.", file=sys.stderr)
        augmentation_dfs[name] = pd.DataFrame() # Create empty DF to avoid KeyError
    except Exception as e:
        print(f"Error loading augmentation data '{filepath}': {e}", file=sys.stderr)
        raise

# --- Feature Engineering & Augmentation ---

# Standardize column names for merging
for name, df in augmentation_dfs.items():
    if not df.empty:
        augmentation_dfs[name].columns = df.columns.str.strip().str.lower().str.replace(' ', '_')

# Rename columns in main dataframe for consistency
df_2022 = df_2022.rename(columns={
    'Street Name': 'street_name',
    'Violation Description': 'violation_description'
})

df_2022_augmented = df_2022.copy()

# Merge census data with streets metadata first (on borough)
df_streets_augmented = augmentation_dfs['streets'].copy()
if not augmentation_dfs['census'].empty and not df_streets_augmented.empty:
    df_streets_augmented = pd.merge(
        df_streets_augmented,
        augmentation_dfs['census'][['borough', 'population', 'median_income', 'num_households']],
        on='borough',
        how='left'
    )

# Merge with street metadata (now augmented with census data)
if not df_streets_augmented.empty:
    street_features = ['street_name', 'borough', 'segment_length', 'from_street', 'to_street', 'population', 'median_income', 'num_households']
    # Filter to only include columns that actually exist after potential census merge
    street_features = [f for f in street_features if f in df_streets_augmented.columns]
    df_2022_augmented = pd.merge(
        df_2022_augmented,
        df_streets_augmented[street_features],
        on='street_name',
        how='left'
    )

# Merge with violation codes
if not augmentation_dfs['violations'].empty:
    df_2022_augmented = pd.merge(
        df_2022_augmented,
        augmentation_dfs['violations'][['violation_description', 'violation_code', 'fine_amount']],
        on='violation_description',
        how='left'
    )

# Define features and target
FEATURES = [
    'street_name',
    'violation_description',
    'borough',
    'segment_length',
    'violation_code',
    'fine_amount',
    'from_street',
    'to_street',
    'population',
    'median_income',
    'num_households'
]
TARGET = 'violation_count'

# Filter features to only include those present in the dataframe after merges
FEATURES = [f for f in FEATURES if f in df_2022_augmented.columns]

# List of columns expected to be categorical
categorical_cols_to_convert = ['street_name', 'violation_description', 'borough', 'violation_code', 'from_street', 'to_street']
# List of columns expected to be numerical
numerical_cols_to_convert = ['segment_length', 'fine_amount', 'population', 'median_income', 'num_households']

# Ensure categorical features are of object/string type and fill NaNs
for col in categorical_cols_to_convert:
    if col in FEATURES:
        df_2022_augmented[col] = df_2022_augmented[col].astype(str).fillna('Unknown')

# Handle missing values for numerical features, fill with median
for col in numerical_cols_to_convert:
    if col in FEATURES:
        df_2022_augmented[col] = df_2022_augmented[col].fillna(df_2022_augmented[col].median())


X = df_2022_augmented[FEATURES]
y = df_2022_augmented[TARGET]

# Identify categorical features for CatBoost by their names (must be in X.columns)
categorical_features_names = [col for col in FEATURES if col in categorical_cols_to_convert]
# CatBoost can handle NaNs in categorical features if `cat_features` are specified.
# However, we explicitly filled them with 'Unknown' to make sure.

print(f"Features used for training: {FEATURES}", file=sys.stderr)
print(f"Categorical features (by name) for CatBoost: {categorical_features_names}", file=sys.stderr)

# --- Training and Validation ---
# Use part of 2022 data as evaluation set
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

print(f"Training data shape: {X_train.shape}", file=sys.stderr)
print(f"Validation data shape: {X_val.shape}", file=sys.stderr)

# CatBoostRegressor Model
model = CatBoostRegressor(
    iterations=1000,
    learning_rate=0.05,
    depth=8,
    loss_function='RMSE',
    eval_metric='RMSE',
    random_seed=42,
    verbose=0,
    early_stopping_rounds=50,
    cat_features=categorical_features_names,
    thread_count=-1 # Use all available CPU cores
)

print("Starting model training...", file=sys.stderr)
model.fit(X_train, y_train,
          eval_set=(X_val, y_val),
          early_stopping_rounds=50,
          verbose=False) # Suppress verbose output during fit

val_preds = model.predict(X_val)
val_rmse = np.sqrt(mean_squared_error(y_val, val_preds.clip(min=0).round())) # Clip to non-negative and round

print(f"Final Validation Performance: {val_rmse}")


# --- Prediction for Test File (if provided) ---
if TEST_FILE:
    print("Processing test file for predictions...", file=sys.stderr)
    try:
        df_test = pd.read_csv(TEST_FILE)
        # The 'violation_count' column in test/eval is optional and only for ground truth.
        # Rename it to avoid using it as a feature.
        if 'violation_count' in df_test.columns:
            df_test.rename(columns={'violation_count': 'violation_count_ground_truth'}, inplace=True)
        else:
            # If not present, create a placeholder column to handle later logic
            df_test['violation_count_ground_truth'] = np.nan

        df_test.columns = [col.replace('Street Name', 'street_name').replace('Violation Description', 'violation_description') for col in df_test.columns]

        # Store original keys for submission
        original_test_keys = df_test[['street_name', 'violation_description']].copy()

    except Exception as e:
        print(f"Error loading test data from '{TEST_FILE}': {e}", file=sys.stderr)
        raise

    df_test_augmented = df_test.copy()

    # Augment test data with street metadata and violation codes
    if not df_streets_augmented.empty:
        street_features = ['street_name', 'borough', 'segment_length', 'from_street', 'to_street', 'population', 'median_income', 'num_households']
        street_features = [f for f in street_features if f in df_streets_augmented.columns]
        df_test_augmented = pd.merge(
            df_test_augmented,
            df_streets_augmented[street_features],
            on='street_name',
            how='left'
        )

    if not augmentation_dfs['violations'].empty:
        df_test_augmented = pd.merge(
            df_test_augmented,
            augmentation_dfs['violations'][['violation_description', 'violation_code', 'fine_amount']],
            on='violation_description',
            how='left'
        )

    # Ensure all features used in training are present in the test set
    for col in FEATURES:
        if col not in df_test_augmented.columns:
            # Add missing columns, fill with 'Unknown' for categorical, or median for numerical
            if col in categorical_cols_to_convert:
                df_test_augmented[col] = 'Unknown'
            elif col in numerical_cols_to_convert:
                # Use training data's median for missing numerical features
                if col in df_2022_augmented.columns:
                    df_test_augmented[col] = df_2022_augmented[col].median()
                else: # Fallback if feature was missing in training too
                    df_test_augmented[col] = 0
            else: # Should not happen if FEATURES are correctly derived
                df_test_augmented[col] = 'Unknown'

    # Handle missing values for test set based on training data logic
    for col in categorical_cols_to_convert:
        if col in FEATURES: # Only process features used in training
            df_test_augmented[col] = df_test_augmented[col].astype(str).fillna('Unknown')

    for col in numerical_cols_to_convert:
        if col in FEATURES:
            df_test_augmented[col] = df_test_augmented[col].fillna(df_2022_augmented[col].median())


    X_test = df_test_augmented[FEATURES]

    # Identify unseen key pairs
    train_keys = set(df_2022_augmented.set_index(['street_name', 'violation_description']).index)
    test_keys = set(df_test_augmented.set_index(['street_name', 'violation_description']).index)
    unseen_keys_count = len(test_keys - train_keys)
    print(f"Number of unseen (street_name, violation_description) pairs in test set: {unseen_keys_count}", file=sys.stderr)

    # Generate predictions
    test_predictions = model.predict(X_test)
    test_predictions = test_predictions.clip(min=0).round().astype(int) # Ensure non-negative integer counts

    # Create submission file
    submission_df = original_test_keys.copy()
    submission_df['predicted_count'] = test_predictions
    submission_df.columns = ['street_name', 'violation_type', 'predicted_count'] # Align with expected output
    submission_df.to_csv("submission.csv", index=False)
    print("Predictions saved to submission.csv", file=sys.stderr)

    # Calculate RMSE if ground truth is available in the test file
    if 'violation_count_ground_truth' in df_test.columns and not df_test['violation_count_ground_truth'].isnull().all():
        y_test_true = df_test['violation_count_ground_truth']
        test_rmse = np.sqrt(mean_squared_error(y_test_true, test_predictions))
        print(f"RMSE on the provided test/evaluation dataset: {test_rmse}", file=sys.stderr)
    else:
        print("Test file does not contain 'violation_count' column for RMSE calculation.", file=sys.stderr)

else:
    print("No test file provided. Skipping prediction generation.", file=sys.stderr)

print("Script finished successfully.", file=sys.stderr)
