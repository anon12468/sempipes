

import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    # Using a local copy for potential modifications specific to downcast_dtypes_ablation if needed,
    # but for this ablation study, the original is fine as the ablation is elsewhere.
    initial_memory = df.memory_usage(deep=True).sum() / (1024**2)
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    final_memory = df.memory_usage(deep=True).sum() / (1024**2)
    return df

def load_and_preprocess_data_ablation(train_path, disable_violation_desc_length_feat=False):
    """
    Loads, preprocesses, and merges data from various sources.
    Handles memory efficiency and specific ablations.
    This version is modified to only process training data and include ablation flags.
    """
    print("Loading and preprocessing data...")

    # --- Load Core Data ---
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw) # Using the original downcast_dtypes
    print(f"Initial train_df loaded. Shape: {train_df_raw.shape}, Memory: {train_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Combine unique street_name and violation_description pairs from train for consistent feature engineering.
    combined_df = train_df_raw[['street_name', 'violation_description']].drop_duplicates().reset_index(drop=True)
    gc.collect()
    print(f"Combined unique (street, violation) pairs for feature engineering. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # --- Feature Engineering and Augmentation ---

    # Basic features from core data
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # Augmentation 1: nyc_street_data.csv
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        print(f"Loading {street_data_path}...")
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
            print(f"Merged with street_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading or merging {street_data_path}: {e}. Skipping street data augmentation.")
    else:
        print(f"Warning: {street_data_path} not found. Skipping street data augmentation.")

    # Augmentation 2: nyc_violation_codes.csv
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        print(f"Loading {violation_codes_path}...")
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']

            # --- Start of Improvement Plan Implementation (from original solution) ---
            print("Extracting text features from 'violation_description'...")
            keywords = [
                "NO STANDING", "COMMERCIAL VEHICLE", "HYDRANT", "PARKING",
                "METER", "HANDICAP", "ZONE", "BUS", "TRUCK", "ALTERNATE SIDE",
                "TRAFFIC", "EXPIRED", "REGISTRATION", "INSPECTION", "NO PARKING",
                "CROSSWALK", "DRIVEWAY", "DOUBLE PARKING", "CURB"
            ]
            for keyword in keywords:
                col_name = f"violation_desc_has_{keyword.lower().replace(' ', '_')}"
                violation_codes[col_name] = violation_codes['violation_description'].str.contains(keyword, case=False, na=False).astype(bool)

            # Ablation 1: Disable 'violation_description_length' feature
            if not disable_violation_desc_length_feat:
                violation_codes['violation_description_length'] = violation_codes['violation_description'].astype(str).apply(len)
            # --- End of Improvement Plan Implementation ---

            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
            print(f"Merged with violation_codes. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading or merging {violation_codes_path}: {e}. Skipping violation codes augmentation.")
    else:
        print(f"Warning: {violation_codes_path} not found. Skipping violation codes augmentation.")

    # Augmentation 3: nyc_census_data.csv (Hypothetical)
    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        print(f"Loading {census_data_path}...")
        if 'borough' in combined_df.columns:
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
                    print(f"Merged with census_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
                else:
                    print(f"Warning: Missing one or more expected columns ({relevant_census_cols}) in {census_data_path}. Skipping census data augmentation.")
            except Exception as e:
                print(f"Error loading or merging {census_data_path}: {e}. Skipping census data augmentation.")
        else:
            print("Warning: Borough information not available in combined_df to merge census data. Skipping.")
    else:
        print(f"Warning: {census_data_path} not found. Skipping census data augmentation.")

    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    print(f"Final train_processed_df shape: {train_processed_df.shape}")

    all_possible_cat_cols = [col for col in combined_df.columns if combined_df[col].dtype in ['object', 'category']]
    categorical_features = [col for col in all_possible_cat_cols if col in train_processed_df.columns]
    print(f"Categorical features identified for CatBoost: {categorical_features}")

    for col in categorical_features:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].astype(object).fillna('NaN_CATEGORY_PLACEHOLDER').astype('category')

    return train_processed_df, None, categorical_features # Return None for test_df as we only do training/validation

def train_and_predict_ablation(train_df, categorical_features, disable_prediction_clamping=False, disable_early_stopping=False):
    """
    Trains a CatBoost Regressor model and generates predictions on the validation set.
    Includes ablation flags.
    """
    print("Training CatBoost model...")

    target = 'violation_count'
    features_to_exclude = [target]
    features = [col for col in train_df.columns if col not in features_to_exclude]

    X = train_df[features]
    y = train_df[target]

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    print(f"Training data split: X_train={X_train.shape}, X_val={X_val.shape}")

    model_params = {
        'iterations': 1000,
        'learning_rate': 0.05,
        'depth': 6,
        'l2_leaf_reg': 3,
        'loss_function': 'RMSE',
        'eval_metric': 'RMSE',
        'random_seed': 42,
        'verbose': 0, # Suppress verbose output for cleaner ablation results
    }

    # Ablation 3: Disable early_stopping_rounds
    if not disable_early_stopping:
        model_params['early_stopping_rounds'] = 50

    model = CatBoostRegressor(**model_params)

    cat_features_in_X_train = [col for col in categorical_features if col in X_train.columns]
    cat_features_indices = [X_train.columns.get_loc(col) for col in cat_features_in_X_train]

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        raise

    val_preds = model.predict(X_val)
    # Ablation 2: Disable negative prediction clamping
    if not disable_prediction_clamping:
        val_preds[val_preds < 0] = 0
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    print(f"Development Validation RMSE: {val_rmse}")

    return val_rmse

def run_ablation_scenario(
    ablation_name,
    disable_violation_desc_length_feat=False,
    disable_prediction_clamping=False,
    disable_early_stopping=False
):
    print(f"\n--- Running Ablation: {ablation_name} ---")

    train_df, _, categorical_features = load_and_preprocess_data_ablation(
        './input/violations_per_street_2022.csv',
        disable_violation_desc_length_feat=disable_violation_desc_length_feat
    )

    val_rmse = train_and_predict_ablation(
        train_df,
        categorical_features,
        disable_prediction_clamping=disable_prediction_clamping,
        disable_early_stopping=disable_early_stopping
    )
    return val_rmse

if __name__ == "__main__":
    results = {}

    # Base Case
    base_rmse = run_ablation_scenario("Base Case")
    results["Base Case"] = base_rmse

    # Ablation 1: No 'violation_description_length' feature
    rmse_no_desc_len = run_ablation_scenario(
        "No 'violation_description_length' feature",
        disable_violation_desc_length_feat=True
    )
    results["No 'violation_description_length' feature"] = rmse_no_desc_len

    # Ablation 2: No negative prediction clamping
    rmse_no_clamp = run_ablation_scenario(
        "No Negative Prediction Clamping",
        disable_prediction_clamping=True
    )
    results["No Negative Prediction Clamping"] = rmse_no_clamp

    # Ablation 3: No early stopping rounds
    rmse_no_early_stop = run_ablation_scenario(
        "No Early Stopping Rounds",
        disable_early_stopping=True
    )
    results["No Early Stopping Rounds"] = rmse_no_early_stop

    print("\n--- Ablation Study Results ---")
    base_rmse = results["Base Case"]
    print(f"Base Case RMSE: {base_rmse:.4f}")

    most_impactful_component_name = "No significant impact observed (all deltas were zero)"
    max_abs_delta = 0.0
    impact_type_final = "" # "beneficial" or "detrimental"

    for scenario, rmse in results.items():
        if scenario == "Base Case":
            continue
        delta = rmse - base_rmse
        impact_description = ""
        if delta > 0:
            impact_description = "degradation"
        elif delta < 0:
            impact_description = "improvement"
        else:
            impact_description = "no change"

        print(f"{scenario} RMSE: {rmse:.4f} (Delta from Base: {delta:+.4f}, {impact_description})")

        if abs(delta) > max_abs_delta:
            max_abs_delta = abs(delta)
            most_impactful_component_name = scenario
            if delta > 0: # Removing it made RMSE worse, so its presence was beneficial
                impact_type_final = "beneficial (its removal degraded performance)"
            else: # Removing it made RMSE better, so its presence was detrimental
                impact_type_final = "detrimental (its removal improved performance)"

    if max_abs_delta > 0:
        print(f"\nConclusion: The part with the most significant impact (largest absolute delta) was '{most_impactful_component_name}'. Its presence was {impact_type_final}.")
    else:
        print(f"\nConclusion: {most_impactful_component_name}. No significant impact (absolute delta > 0) found in this ablation study.")

