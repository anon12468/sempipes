
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys
import re

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    initial_memory = df.memory_usage(deep=True).sum() / (1024**2)
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            # and not a key column that might have very high cardinality.
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    final_memory = df.memory_usage(deep=True).sum() / (1024**2)
    return df

def load_and_preprocess_data(train_path, test_path=None):
    """
    Loads, preprocesses, and merges data from various sources.
    Handles memory efficiency by selective column loading, aggregation, and garbage collection.
    Ensures NaN values in categorical features are handled for CatBoost.
    """
    print("Loading and preprocessing data...")

    # --- Load Core Data ---
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)
    print(f"Initial train_df loaded. Shape: {train_df_raw.shape}, Memory: {train_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    test_df_raw = None
    if test_path:
        test_df_raw = pd.read_csv(test_path)
        test_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
        test_df_raw['is_pure_prediction'] = test_df_raw['violation_count'].isna()
        test_df_raw = downcast_dtypes(test_df_raw)
        print(f"Test_df loaded. Shape: {test_df_raw.shape}, Memory: {test_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Combine unique street_name and violation_description pairs for consistent feature engineering.
    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_keys_test = pd.DataFrame()
    if test_df_raw is not None:
        combined_keys_test = test_df_raw[['street_name', 'violation_description']].drop_duplicates()

    combined_df = pd.concat([combined_keys_train, combined_keys_test], ignore_index=True).drop_duplicates().reset_index(drop=True)
    del combined_keys_train, combined_keys_test
    gc.collect()
    print(f"Combined unique (street, violation) pairs for feature engineering. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Ensure 'street_name' and 'violation_description' are string types and fill any potential NaNs
    # This is crucial as they are keys for merges and categorical features
    combined_df['street_name'] = combined_df['street_name'].astype(str).fillna('Unknown Street')
    combined_df['violation_description'] = combined_df['violation_description'].astype(str).fillna('Unknown Violation')

    # --- Feature Engineering and Augmentation ---

    # 1. street_suffix_type from street_name
    combined_df['street_suffix_type'] = 'Other'
    street_name_lower = combined_df['street_name'].str.lower() # No need for .fillna('') as it's handled above

    combined_df.loc[street_name_lower.str.contains(r'\b(street|st|strt)\b(?:\.|\s*(?:[nsew]|north|south|east|west)?\s*)$', regex=True, na=False), 'street_suffix_type'] = 'St'
    combined_df.loc[street_name_lower.str.contains(r'\b(avenue|ave|avn)\b(?:\.|\s*(?:[nsew]|north|south|east|west)?\s*)$', regex=True, na=False), 'street_suffix_type'] = 'Ave'
    combined_df.loc[street_name_lower.str.contains(r'\b(boulevard|blvd)\b(?:\.|\s*(?:[nsew]|north|south|east|west)?\s*)$', regex=True, na=False), 'street_suffix_type'] = 'Blvd'
    combined_df.loc[street_name_lower.str.contains(r'\b(road|rd|rte)\b(?:\.|\s*(?:[nsew]|north|south|east|west)?\s*)$', regex=True, na=False), 'street_suffix_type'] = 'Rd'
    combined_df['street_suffix_type'] = combined_df['street_suffix_type'].astype('category')

    # 2. Boolean indicator features from violation_description
    violation_desc_lower = combined_df['violation_description'].str.lower() # No need for .fillna('') as it's handled above

    combined_df['has_parking_keyword'] = violation_desc_lower.str.contains(r'\b(parking|parked|no parking|park)\b', na=False, regex=True).astype('bool')
    combined_df['has_standing_keyword'] = violation_desc_lower.str.contains(r'\b(standing|no standing|stand)\b', na=False, regex=True).astype('bool')
    combined_df['has_hydrant_keyword'] = violation_desc_lower.str.contains(r'\b(hydrant|fire hydrant)\b', na=False, regex=True).astype('bool')
    combined_df['has_meter_keyword'] = violation_desc_lower.str.contains(r'\b(meter|expired meter|metered)\b', na=False, regex=True).astype('bool')
    combined_df['has_zone_keyword'] = violation_desc_lower.str.contains(r'\b(zone|permit zone|restricted zone|no zone)\b', na=False, regex=True).astype('bool')
    combined_df['has_sign_keyword'] = violation_desc_lower.str.contains(r'\b(sign|no sign|posted sign|posted regulation)\b', na=False, regex=True).astype('bool')
    combined_df['has_commercial_keyword'] = violation_desc_lower.str.contains(r'\b(commercial|loading zone|comm)\b', na=False, regex=True).astype('bool')
    combined_df['has_bus_keyword'] = violation_desc_lower.str.contains(r'\b(bus stop|bus lane)\b', na=False, regex=True).astype('bool')

    # Augmentation 1: nyc_street_data.csv
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        print(f"Loading {street_data_path}...")
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
            print(f"Merged with street_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading or merging {street_data_path}: {e}. Skipping street data augmentation.")
    else:
        print(f"Warning: {street_data_path} not found. Skipping street data augmentation.")

    # Augmentation 2: nyc_violation_codes.csv
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        print(f"Loading {violation_codes_path}...")
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
            print(f"Merged with violation_codes. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading or merging {violation_codes_path}: {e}. Skipping violation codes augmentation.")
    else:
        print(f"Warning: {violation_codes_path} not found. Skipping violation codes augmentation.")

    # Augmentation 3: nyc_census_data.csv (Hypothetical)
    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        print(f"Loading {census_data_path}...")
        if 'borough' in combined_df.columns:
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
                    print(f"Merged with census_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
                else:
                    print(f"Warning: Missing one or more expected columns ({relevant_census_cols}) in {census_data_path}. Skipping census data augmentation.")
            except Exception as e:
                print(f"Error loading or merging {census_data_path}: {e}. Skipping census data augmentation.")
        else:
            print("Warning: Borough information not available in combined_df to merge census data. Skipping.")
    else:
        print(f"Warning: {census_data_path} not found. Skipping census data augmentation.")

    # --- Post-augmentation NaN handling and type conversion for CatBoost ---
    categorical_features_for_catboost = []
    for col in combined_df.columns:
        if combined_df[col].dtype == 'object' or combined_df[col].dtype.name == 'category':
            # CatBoost requires string representation for categorical NaNs
            combined_df[col] = combined_df[col].astype(str).fillna('Unknown_Category')
            combined_df[col] = combined_df[col].astype('category')
            categorical_features_for_catboost.append(col)
        elif combined_df[col].dtype == 'bool':
            # CatBoost treats boolean features as categorical
            categorical_features_for_catboost.append(col)
        elif combined_df[col].isnull().any():
            # For numerical columns, fill NaNs (e.g., with 0 or a statistical measure)
            combined_df[col] = combined_df[col].fillna(0)
            # Ensure numerical columns are downcasted after fillna
            if combined_df[col].dtype == 'float64':
                combined_df[col] = combined_df[col].astype(np.float32)
            elif combined_df[col].dtype == 'int64':
                # Use nullable integer type if int column can have NaNs
                combined_df[col] = combined_df[col].astype(pd.Int32Dtype())
    
    # Identify unique categorical features for CatBoost
    categorical_features_for_catboost = list(set(categorical_features_for_catboost))

    # Split back into train and test processed dataframes
    # Merging train_df_raw with the processed combined_df to add features
    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')

    test_processed_df = None
    if test_df_raw is not None:
        test_processed_df = pd.merge(test_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')

    print(f"Final train_processed_df shape: {train_processed_df.shape}")
    if test_processed_df is not None:
        print(f"Final test_processed_df shape: {test_processed_df.shape}")

    # Ensure all categorical features identified for CatBoost are actually present in the final DFs
    # and update their dtypes if necessary (though the loop above should ensure this).
    final_categorical_features = [col for col in categorical_features_for_catboost if col in train_processed_df.columns]
    
    return train_processed_df, test_processed_df, final_categorical_features

def train_and_predict(train_df, test_df, categorical_features):
    """
    Trains a CatBoost Regressor model and generates predictions.
    Reports RMSE for validation and test sets (if ground truth available).
    """
    print("Training CatBoost model...")

    # Define features (X) and target (y)
    # Exclude the target, and any temporary flags like 'is_pure_prediction'
    features = [col for col in train_df.columns if col not in ['violation_count', 'is_pure_prediction']]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    # Split training data for validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    print(f"Training data split: X_train={X_train.shape}, X_val={X_val.shape}")

    # Initialize CatBoost Regressor with OOM-conscious parameters
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6, # Reduced depth to manage memory
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=100, # Print metrics every 100 iterations
        early_stopping_rounds=50, # Stop if validation RMSE doesn't improve for 50 iterations
    )

    # Convert categorical feature names to their indices for CatBoost
    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]
    print(f"Categorical feature indices for CatBoost: {cat_features_indices}")

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                  # Set verbose=False after initial debug if output is too long
                  # plot=True # For jupyter notebooks to visualize training
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        raise

    # Validate on internal validation set
    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    print(f"Development Validation RMSE: {val_rmse}")

    submission_df = None
    if test_df is not None:
        print("Generating predictions for test data...")
        # Features for prediction are the same as training
        X_test = test_df[features]

        test_preds = model.predict(X_test)
        # Ensure predictions are non-negative and can be rounded if desired
        test_preds[test_preds < 0] = 0
        
        submission_df = test_df[['street_name', 'violation_description']].copy()
        submission_df['predicted_count'] = test_preds

        # Report RMSE if ground truth is available in test_df (i.e., not a pure prediction file)
        if 'is_pure_prediction' in test_df.columns and not test_df['is_pure_prediction'].all():
            ground_truth_test_df = test_df[~test_df['is_pure_prediction']]
            # Align predictions with ground truth rows
            ground_truth_preds = submission_df.loc[ground_truth_test_df.index, 'predicted_count']
            test_rmse = np.sqrt(mean_squared_error(ground_truth_test_df['violation_count'], ground_truth_preds))
            print(f"RMSE on provided test/evaluation data (with ground truth): {test_rmse}")

        # Report unseen key pairs
        train_keys = set(train_df.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
        test_keys = set(test_df.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
        unseen_keys_count = len(test_keys - train_keys)
        print(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {unseen_keys_count}")
        print("Unseen keys are handled by CatBoost's internal mechanism for new categorical levels (assigned to an 'unknown' category).")

    return submission_df, val_rmse

def main():
    """
    Main function to parse arguments, orchestrate data loading, training, and prediction.
    """
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional path to the 2023 test/evaluation data CSV. '
                             'If provided, predictions will be generated and RMSE reported if ground truth exists.')
    args = parser.parse_args()

    train_df, test_df, categorical_features = load_and_preprocess_data(args.train_path, args.test_path)
    submission_df, final_validation_score = train_and_predict(train_df, test_df, categorical_features)

    if submission_df is not None:
        submission_df.to_csv('submission.csv', index=False)
        print("Submission file 'submission.csv' generated successfully.")

    print(f"Final Validation Performance: {final_validation_score}")

if __name__ == "__main__":
    main()
