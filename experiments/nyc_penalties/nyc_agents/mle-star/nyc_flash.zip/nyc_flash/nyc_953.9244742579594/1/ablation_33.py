
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    initial_memory = df.memory_usage(deep=True).sum() / (1024**2)
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    final_memory = df.memory_usage(deep=True).sum() / (1024**2)
    # print(f"  Memory reduced from {initial_memory:.2f} MB to {final_memory:.2f} MB for dataframe.")
    return df

# Modified load_and_preprocess_data to support ablations
def load_and_preprocess_data_ablated(train_path, ablation_config=None):
    """
    Loads, preprocesses, and merges data from various sources,
    with options for ablation study. Only for training data.
    """
    if ablation_config is None:
        ablation_config = {}

    no_combined_df_strategy = ablation_config.get('no_combined_df_strategy', False)
    fill_numerical_nans_with_constant = ablation_config.get('fill_numerical_nans_with_constant', False)
    nan_fill_value = -1 # Constant for numerical NaN filling

    # print(f"Loading and preprocessing data (Ablation Config: {ablation_config})...")

    # --- Load Core Data ---
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)

    if no_combined_df_strategy:
        # print("Ablation: Not using combined_df strategy for feature engineering.")
        train_processed_df = train_df_raw.copy()
        
        # Basic features directly on train_processed_df
        train_processed_df['street_name_len'] = train_processed_df['street_name'].apply(len).astype('int16')
        train_processed_df['violation_desc_len'] = train_processed_df['violation_description'].apply(len).astype('int16')

        # Augmentation 1: nyc_street_data.csv
        street_data_path = './input/nyc_street_data.csv'
        if os.path.exists(street_data_path):
            try:
                street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
                street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
                street_data = downcast_dtypes(street_data)
                street_data = street_data.drop_duplicates(subset=['street_name'])
                train_processed_df = pd.merge(train_processed_df, street_data, on='street_name', how='left')
                del street_data
                gc.collect()
            except Exception as e:
                # print(f"Error loading or merging {street_data_path}: {e}. Skipping street data augmentation.")
                pass
        # else:
            # print(f"Warning: {street_data_path} not found. Skipping street data augmentation.")
        
        # Augmentation 2: nyc_violation_codes.csv
        violation_codes_path = './input/nyc_violation_codes.csv'
        if os.path.exists(violation_codes_path):
            try:
                violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
                violation_codes.columns = ['violation_description', 'fine_amount', 'points']
                violation_codes = downcast_dtypes(violation_codes)
                violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
                train_processed_df = pd.merge(train_processed_df, violation_codes, on='violation_description', how='left')
                del violation_codes
                gc.collect()
            except Exception as e:
                # print(f"Error loading or merging {violation_codes_path}: {e}. Skipping violation codes augmentation.")
                pass
        # else:
            # print(f"Warning: {violation_codes_path} not found. Skipping violation codes augmentation.")

        # Augmentation 3: nyc_census_data.csv
        census_data_path = './input/nyc_census_data.csv'
        if os.path.exists(census_data_path):
            if 'borough' in train_processed_df.columns:
                try:
                    census_data = pd.read_csv(census_data_path)
                    census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                    relevant_census_cols = ['borough', 'population_density', 'avg_income']
                    if all(col in census_data.columns for col in relevant_census_cols):
                        census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                        census_agg = downcast_dtypes(census_agg)
                        train_processed_df = pd.merge(train_processed_df, census_agg, on='borough', how='left')
                        del census_data, census_agg
                        gc.collect()
                except Exception as e:
                    # print(f"Error loading or merging {census_data_path}: {e}. Skipping census data augmentation.")
                    pass
            # else:
                # print("Warning: Borough information not available in train_processed_df to merge census data. Skipping.")
        # else:
            # print(f"Warning: {census_data_path} not found. Skipping census data augmentation.")

        processed_df_for_cat_features_id = train_processed_df 

    else: # Original combined_df strategy
        combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
        # In ablation context, we only use train_df_raw for combined_df
        combined_df = pd.concat([combined_keys_train], ignore_index=True).drop_duplicates().reset_index(drop=True)
        del combined_keys_train
        gc.collect()

        combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
        combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

        # Augmentation 1: nyc_street_data.csv
        street_data_path = './input/nyc_street_data.csv'
        if os.path.exists(street_data_path):
            try:
                street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
                street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
                street_data = downcast_dtypes(street_data)
                street_data = street_data.drop_duplicates(subset=['street_name'])
                combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
                del street_data
                gc.collect()
            except Exception as e:
                # print(f"Error loading or merging {street_data_path}: {e}. Skipping street data augmentation.")
                pass
        # else:
            # print(f"Warning: {street_data_path} not found. Skipping street data augmentation.")

        # Augmentation 2: nyc_violation_codes.csv
        violation_codes_path = './input/nyc_violation_codes.csv'
        if os.path.exists(violation_codes_path):
            try:
                violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
                violation_codes.columns = ['violation_description', 'fine_amount', 'points']
                violation_codes = downcast_dtypes(violation_codes)
                violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
                combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
                del violation_codes
                gc.collect()
            except Exception as e:
                # print(f"Error loading or merging {violation_codes_path}: {e}. Skipping violation codes augmentation.")
                pass
        # else:
            # print(f"Warning: {violation_codes_path} not found. Skipping violation codes augmentation.")

        # Augmentation 3: nyc_census_data.csv (Hypothetical)
        census_data_path = './input/nyc_census_data.csv'
        if os.path.exists(census_data_path):
            if 'borough' in combined_df.columns:
                try:
                    census_data = pd.read_csv(census_data_path)
                    census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                    relevant_census_cols = ['borough', 'population_density', 'avg_income']
                    if all(col in census_data.columns for col in relevant_census_cols):
                        census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                        census_agg = downcast_dtypes(census_agg)
                        combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                        del census_data, census_agg
                        gc.collect()
                except Exception as e:
                    # print(f"Error loading or merging {census_data_path}: {e}. Skipping census data augmentation.")
                    pass
            # else:
                # print("Warning: Borough information not available in combined_df to merge census data. Skipping.")
        # else:
            # print(f"Warning: {census_data_path} not found. Skipping census data augmentation.")

        train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
        del train_df_raw, combined_df
        gc.collect()
        processed_df_for_cat_features_id = train_processed_df

    # Ablation: Explicitly fill NaNs for numerical augmented features
    if fill_numerical_nans_with_constant:
        # print(f"Ablation: Filling numerical NaNs with {nan_fill_value}.")
        numerical_cols_with_potential_nans = [
            'street_length', 'num_lanes', 'fine_amount', 'points', 'population_density', 'avg_income'
        ]
        for col in numerical_cols_with_potential_nans:
            if col in train_processed_df.columns and train_processed_df[col].isnull().any():
                train_processed_df[col] = train_processed_df[col].fillna(nan_fill_value)


    # Identify categorical features for CatBoost
    categorical_features = [col for col in processed_df_for_cat_features_id.columns if processed_df_for_cat_features_id[col].dtype in ['object', 'category']]
    categorical_features = [col for col in categorical_features if col in train_processed_df.columns]

    for col in categorical_features:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].astype('category')

    return train_processed_df, None, categorical_features

def train_and_predict_ablated(train_df, categorical_features, ablation_config=None):
    """
    Trains a CatBoost Regressor model with options for ablation study.
    Only performs validation, no test prediction.
    """
    if ablation_config is None:
        ablation_config = {}

    l2_leaf_reg_ablation = ablation_config.get('l2_leaf_reg', 3) 

    # print(f"Training CatBoost model (Ablation Config: {ablation_config})...")

    features = [col for col in train_df.columns if col not in ['violation_count']]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6, 
        l2_leaf_reg=l2_leaf_reg_ablation, 
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Turn off verbose for cleaner ablation output
        early_stopping_rounds=50, 
    )

    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        raise

    val_preds = model.predict(X_val)
    val_preds[val_preds < 0] = 0
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    
    return val_rmse

def run_ablation_study(train_path):
    print("--- Running Ablation Study ---")
    results = {}

    # Base Case
    print("\n--- Base Case ---")
    base_train_df, _, base_categorical_features = load_and_preprocess_data_ablated(train_path, ablation_config={})
    base_rmse = train_and_predict_ablated(base_train_df, base_categorical_features, ablation_config={})
    results['Base Case'] = base_rmse
    print(f"Base Case Validation RMSE: {base_rmse:.4f}")

    # Ablation 1: Explicitly fill numerical NaNs with -1 (instead of CatBoost's default handling)
    print("\n--- Ablation 1: Explicitly fill numerical NaNs with -1 ---")
    ablation1_train_df, _, ablation1_categorical_features = load_and_preprocess_data_ablated(train_path, ablation_config={'fill_numerical_nans_with_constant': True})
    ablation1_rmse = train_and_predict_ablated(ablation1_train_df, ablation1_categorical_features, ablation_config={})
    results['Ablation 1: Fill numerical NaNs with -1'] = ablation1_rmse
    print(f"Ablation 1 Validation RMSE: {ablation1_rmse:.4f} (Delta: {ablation1_rmse - base_rmse:.4f})")
    
    # Ablation 2: Remove combined_df strategy for Feature Engineering
    print("\n--- Ablation 2: Remove combined_df strategy for FE ---")
    ablation2_train_df, _, ablation2_categorical_features = load_and_preprocess_data_ablated(train_path, ablation_config={'no_combined_df_strategy': True})
    ablation2_rmse = train_and_predict_ablated(ablation2_train_df, ablation2_categorical_features, ablation_config={})
    results['Ablation 2: Remove combined_df strategy'] = ablation2_rmse
    print(f"Ablation 2 Validation RMSE: {ablation2_rmse:.4f} (Delta: {ablation2_rmse - base_rmse:.4f})")

    # Ablation 3: CatBoost l2_leaf_reg = 0 (No L2 Regularization)
    print("\n--- Ablation 3: CatBoost l2_leaf_reg = 0 ---")
    # Data preprocessing is the same as base for this ablation
    ablation3_train_df, _, ablation3_categorical_features = load_and_preprocess_data_ablated(train_path, ablation_config={}) 
    ablation3_rmse = train_and_predict_ablated(ablation3_train_df, ablation3_categorical_features, ablation_config={'l2_leaf_reg': 0})
    results['Ablation 3: CatBoost l2_leaf_reg = 0'] = ablation3_rmse
    print(f"Ablation 3 Validation RMSE: {ablation3_rmse:.4f} (Delta: {ablation3_rmse - base_rmse:.4f})")

    print("\n--- Ablation Study Summary ---")
    for name, rmse_val in results.items():
        if name == 'Base Case':
            print(f"{name}: RMSE = {rmse_val:.4f}")
        else:
            delta = rmse_val - results['Base Case']
            print(f"{name}: RMSE = {rmse_val:.4f} (Delta from Base: {delta:.4f})")

    # Determine the most contributing part (largest absolute delta from base RMSE)
    most_impactful_change = ""
    max_abs_delta = -1.0 

    for name, rmse_val in results.items():
        if name == 'Base Case':
            continue
        
        delta = rmse_val - results['Base Case']
        if abs(delta) > max_abs_delta:
            max_abs_delta = abs(delta)
            most_impactful_change = name
            
    if most_impactful_change:
        delta_val = results[most_impactful_change] - results['Base Case']
        impact_description = ""
        if delta_val > 0: # RMSE increased, so original part was beneficial
            impact_description = f"was beneficial, as its removal worsened performance by {delta_val:.4f} RMSE."
        elif delta_val < 0: # RMSE decreased, so original part was detrimental
            impact_description = f"was detrimental, as its removal improved performance by {-delta_val:.4f} RMSE."
        else: # delta_val == 0
             impact_description = f"had no measurable impact on performance (delta of 0.0000)."
        print(f"\nThe most contributing part to the overall performance (based on largest absolute RMSE change) was '{most_impactful_change}'. It {impact_description}")
    else:
        print("\nNo impactful changes observed in the ablation study.")


if __name__ == "__main__":
    # Create dummy input files if they don't exist, for demonstration
    input_dir = './input'
    os.makedirs(input_dir, exist_ok=True)

    train_path = os.path.join(input_dir, 'violations_per_street_2022.csv')
    street_data_path = os.path.join(input_dir, 'nyc_street_data.csv')
    violation_codes_path = os.path.join(input_dir, 'nyc_violation_codes.csv')
    census_data_path = os.path.join(input_dir, 'nyc_census_data.csv')

    if not os.path.exists(train_path):
        dummy_train_data = {
            'street_name': ['STREET A', 'STREET B', 'STREET A', 'STREET C', 'STREET B', 'STREET D'],
            'violation_description': ['PARKING VIOLATION', 'SPEEDING', 'NO STANDING', 'PARKING VIOLATION', 'NO STANDING', 'LITTERING'],
            'violation_count': [100, 50, 120, 80, 60, 200]
        }
        # Expand initial data to ensure more realistic merges
        initial_streets = list(set(dummy_train_data['street_name']))
        initial_violations = list(set(dummy_train_data['violation_description']))

        for _ in range(100): # Increase data size to make splits more meaningful
            dummy_train_data['street_name'].append(np.random.choice(initial_streets))
            dummy_train_data['violation_description'].append(np.random.choice(initial_violations))
            dummy_train_data['violation_count'].append(np.random.randint(10, 300))
        pd.DataFrame(dummy_train_data).to_csv(train_path, index=False)
        # print(f"Created dummy {train_path}")

    if not os.path.exists(street_data_path):
        dummy_street_data = {
            'Street Name': ['STREET A', 'STREET B', 'STREET C', 'STREET D', 'STREET E'],
            'Borough': ['MANHATTAN', 'BROOKLYN', 'QUEENS', 'BRONX', 'MANHATTAN'],
            'Street Length': [1000, 800, 1200, 900, 700],
            'Number of Lanes': [4, 2, 6, 4, 2]
        }
        pd.DataFrame(dummy_street_data).to_csv(street_data_path, index=False)
        # print(f"Created dummy {street_data_path}")

    if not os.path.exists(violation_codes_path):
        dummy_violation_codes = {
            'Violation Description': ['PARKING VIOLATION', 'SPEEDING', 'NO STANDING', 'DOUBLE PARKING', 'LITTERING', 'STOP SIGN'],
            'Fine Amount': [65, 115, 95, 80, 50, 100],
            'Points': [0, 3, 0, 0, 0, 1]
        }
        pd.DataFrame(dummy_violation_codes).to_csv(violation_codes_path, index=False)
        # print(f"Created dummy {violation_codes_path}")

    if not os.path.exists(census_data_path):
        dummy_census_data = {
            'Borough': ['MANHATTAN', 'BROOKLYN', 'QUEENS', 'BRONX', 'STATEN ISLAND'],
            'Population Density': [27000, 15000, 8000, 12000, 6000],
            'Avg Income': [100000, 75000, 60000, 55000, 70000]
        }
        pd.DataFrame(dummy_census_data).to_csv(census_data_path, index=False)
        # print(f"Created dummy {census_data_path}")

    run_ablation_study(train_path)
