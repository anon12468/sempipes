
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    # initial_memory = df.memory_usage(deep=True).sum() / (1024**2)
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            # and it's not a key column with potentially very high cardinality
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5 and num_unique_values < 10000:
                df[col] = df[col].astype('category')
    # final_memory = df.memory_usage(deep=True).sum() / (1024**2)
    # print(f"  Memory reduced from {initial_memory:.2f} MB to {final_memory:.2f} MB for dataframe.")
    return df

def load_and_preprocess_data_for_ablation(train_path, include_len_features=True):
    """
    Loads, preprocesses, and merges data from various sources for ablation study.
    Controls the inclusion of basic length features.
    """
    # --- Load Core Data ---
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)

    # Combine unique street_name and violation_description pairs from train
    combined_df = train_df_raw[['street_name', 'violation_description']].drop_duplicates().reset_index(drop=True)
    gc.collect()

    # --- Feature Engineering and Augmentation ---

    # Basic features from core data controlled by ablation
    if include_len_features:
        combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
        combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # Augmentation 1: nyc_street_data.csv - dummy check to prevent errors, actual contribution is assumed minimal
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
        except Exception:
            pass # Ignore errors for external files in ablation context
    
    # Augmentation 2: nyc_violation_codes.csv - dummy check
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
        except Exception:
            pass # Ignore errors
    
    # Augmentation 3: nyc_census_data.csv - dummy check
    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        if 'borough' in combined_df.columns:
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
            except Exception:
                pass # Ignore errors
    
    # Identify categorical features for CatBoost
    categorical_features = [col for col in combined_df.columns if combined_df[col].dtype in ['object', 'category']]
    
    # Ensure key identifiers are considered categorical
    if 'street_name' not in categorical_features: categorical_features.append('street_name')
    if 'violation_description' not in categorical_features: categorical_features.append('violation_description')

    # Remove numeric-like features that might have been converted to category by downcast_dtypes
    numeric_like_cols = ['street_name_len', 'violation_desc_len', 'street_length', 'num_lanes', 'fine_amount', 'points', 'population_density', 'avg_income']
    categorical_features = [col for col in categorical_features if col not in numeric_like_cols]

    # --- Handle NaNs in categorical features ---
    for col in categorical_features:
        if col in combined_df.columns:
            if combined_df[col].isnull().any():
                combined_df[col] = combined_df[col].astype(str).fillna('Unknown').astype('category')
            else:
                combined_df[col] = combined_df[col].astype('category')

    # Merge engineered features back to raw train data
    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw, combined_df
    gc.collect()

    # Re-verify and filter categorical features to only include those present in the final dataframe
    final_categorical_features = [col for col in categorical_features if col in train_processed_df.columns]

    # Ensure all identified categorical columns are of 'category' dtype for CatBoost
    for col in final_categorical_features:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].astype('category')

    return train_processed_df, final_categorical_features


def train_and_evaluate_for_ablation(train_df, categorical_features, include_street_name_as_feature=True, catboost_l2_reg=5):
    """
    Trains a CatBoost Regressor model and reports RMSE for validation set.
    Controls the inclusion of 'street_name' as a feature and CatBoost's l2_leaf_reg parameter.
    """
    # Define features (X) and target (y)
    feature_cols_all = [col for col in train_df.columns if col not in ['violation_count']]

    # Ablation: Remove 'street_name' as a feature
    if not include_street_name_as_feature and 'street_name' in feature_cols_all:
        feature_cols_all.remove('street_name')

    X = train_df[feature_cols_all]
    y = train_df['violation_count']

    # Identify categorical features present in X
    cat_features_in_X = [col for col in categorical_features if col in X.columns]

    # Split training data for validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    # Convert categorical feature names to their indices for CatBoost
    cat_features_indices = [X_train.columns.get_loc(col) for col in cat_features_in_X]

    # Initialize CatBoost Regressor
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6,
        l2_leaf_reg=catboost_l2_reg, # Ablation point
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Suppress verbose output for ablation runs
        early_stopping_rounds=50,
        grow_policy='Lossguide',
        max_leaves=63,
        use_best_model=True
    )

    # Train the model
    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        raise

    # Validate on internal validation set
    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    return val_rmse

def run_ablation_study():
    train_path = './input/violations_per_street_2022.csv'
    
    # Create dummy input files if they don't exist, to prevent warnings and ensure consistent behavior.
    # These files are assumed not to contribute meaningful features for this ablation study based on previous results.
    os.makedirs('./input', exist_ok=True)
    for fname, headers in [
        ('nyc_street_data.csv', "Street Name,Borough,Street Length,Number of Lanes\n"),
        ('nyc_violation_codes.csv', "Violation Description,Fine Amount,Points\n"),
        ('nyc_census_data.csv', "Borough,Population_Density,Avg_Income\n")
    ]:
        full_path = os.path.join('./input', fname)
        if not os.path.exists(full_path):
            with open(full_path, 'w') as f:
                f.write(headers)

    results = {}

    # --- Base Case ---
    print("Running Base Case...")
    base_train_df, base_cat_features = load_and_preprocess_data_for_ablation(
        train_path, include_len_features=True
    )
    base_rmse = train_and_evaluate_for_ablation(
        base_train_df.copy(), base_cat_features,
        include_street_name_as_feature=True, catboost_l2_reg=5
    )
    results['Base Case'] = base_rmse
    print(f"Base Case RMSE: {base_rmse:.4f}")

    # --- Ablation 1: No Basic Length Features ---
    # Re-evaluating the impact of these features due to conflicting results in previous studies.
    print("\nRunning Ablation 1: No Basic Length Features (street_name_len, violation_desc_len)")
    ablation1_train_df, ablation1_cat_features = load_and_preprocess_data_for_ablation(
        train_path, include_len_features=False # Disable length features
    )
    # Ensure to remove 'street_name_len' and 'violation_desc_len' from categorical_features if they were erroneously included.
    # They should not be present if include_len_features is False.
    ablation1_cat_features = [f for f in ablation1_cat_features if f not in ['street_name_len', 'violation_desc_len']]
    
    ablation1_rmse = train_and_evaluate_for_ablation(
        ablation1_train_df.copy(), ablation1_cat_features,
        include_street_name_as_feature=True, catboost_l2_reg=5
    )
    results['Ablation 1 (No Basic Length Features)'] = ablation1_rmse
    print(f"Ablation 1 RMSE: {ablation1_rmse:.4f} (Delta: {ablation1_rmse - base_rmse:.4f})")

    # --- Ablation 2: Remove 'street_name' as a direct feature ---
    # This evaluates the impact of one of the core identifier categorical features.
    print("\nRunning Ablation 2: Remove 'street_name' as a direct feature")
    ablation2_train_df, ablation2_cat_features = load_and_preprocess_data_for_ablation(
        train_path, include_len_features=True # Keep length features as in base case
    )
    # Explicitly remove 'street_name' from the list of categorical features for CatBoost
    ablation2_cat_features = [f for f in ablation2_cat_features if f != 'street_name']

    ablation2_rmse = train_and_evaluate_for_ablation(
        ablation2_train_df.copy(), ablation2_cat_features,
        include_street_name_as_feature=False, # Control parameter for feature selection
        catboost_l2_reg=5
    )
    results['Ablation 2 (No street_name feature)'] = ablation2_rmse
    print(f"Ablation 2 RMSE: {ablation2_rmse:.4f} (Delta: {ablation2_rmse - base_rmse:.4f})")

    # --- Ablation 3: CatBoost l2_leaf_reg=10 (increased regularization) ---
    # Testing a higher regularization value than the current default of 5.
    print("\nRunning Ablation 3: CatBoost l2_leaf_reg=10 (increased regularization)")
    ablation3_train_df, ablation3_cat_features = load_and_preprocess_data_for_ablation(
        train_path, include_len_features=True # Keep length features as in base case
    )
    ablation3_rmse = train_and_evaluate_for_ablation(
        ablation3_train_df.copy(), ablation3_cat_features,
        include_street_name_as_feature=True, catboost_l2_reg=10 # Higher L2 regularization
    )
    results['Ablation 3 (CatBoost l2_leaf_reg=10)'] = ablation3_rmse
    print(f"Ablation 3 RMSE: {ablation3_rmse:.4f} (Delta: {ablation3_rmse - base_rmse:.4f})")

    print("\n--- Ablation Study Results Summary ---")
    base_rmse = results['Base Case']
    most_impactful_change = ""
    max_abs_delta = 0.0
    
    for name, rmse in results.items():
        if name == 'Base Case':
            print(f"{name}: RMSE = {rmse:.4f}")
        else:
            delta = rmse - base_rmse
            print(f"{name}: RMSE = {rmse:.4f} (Delta from Base: {delta:.4f})")
            if abs(delta) > abs(max_abs_delta):
                max_abs_delta = delta
                most_impactful_change = name

    print("\n--- Conclusion ---")
    if most_impactful_change:
        if max_abs_delta < 0:
            print(f"The most impactful change observed was '{most_impactful_change}', which improved the RMSE by {-max_abs_delta:.4f}. This suggests the original component was detrimental or less optimal.")
        else:
            print(f"The most impactful change observed was '{most_impactful_change}', which degraded the RMSE by {max_abs_delta:.4f}. This indicates the original component was beneficial or more optimal.")
    else:
        print("No significant impact observed among the ablations. The model appears robust to these changes, or the changes themselves were not sufficiently impactful.")

if __name__ == "__main__":
    run_ablation_study()
