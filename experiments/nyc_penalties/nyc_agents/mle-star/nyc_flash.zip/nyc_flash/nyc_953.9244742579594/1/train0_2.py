
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import gc
import os
import sys
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    initial_memory = df.memory_usage(deep=True).sum() / (1024**2)
    for col in df.columns:
        if df[col].dtype == 'int64':
            # Check if values fit into smaller integer types
            min_val, max_val = df[col].min(), df[col].max()
            if min_val >= np.iinfo(np.int8).min and max_val <= np.iinfo(np.int8).max:
                df[col] = df[col].astype(np.int8)
            elif min_val >= np.iinfo(np.int16).min and max_val <= np.iinfo(np.int16).max:
                df[col] = df[col].astype(np.int16)
            elif min_val >= np.iinfo(np.int32).min and max_val <= np.iinfo(np.int32).max:
                df[col] = df[col].astype(np.int32)
            else:
                df[col] = pd.to_numeric(df[col], downcast='integer') # Fallback
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    final_memory = df.memory_usage(deep=True).sum() / (1024**2)
    logging.info(f"  Memory reduced from {initial_memory:.2f} MB to {final_memory:.2f} MB for dataframe.")
    return df

def load_augmentation_tables(input_dir="./input"):
    """
    Loads all other CSV files in the input directory for augmentation.
    Excludes the main training data file and downcasts them.
    """
    augmentation_data = {}
    if not os.path.exists(input_dir):
        logging.warning(f"Input directory {input_dir} not found. No augmentation tables loaded.")
        return augmentation_data

    for filename in os.listdir(input_dir):
        # Exclude the main training data file which is loaded separately
        if filename.endswith(".csv") and "violations_per_street_2022" not in filename:
            table_name = filename.replace(".csv", "")
            file_path = os.path.join(input_dir, filename)
            df = pd.read_csv(file_path) # No try-except as per instruction
            df = downcast_dtypes(df) # Apply downcasting
            augmentation_data[table_name] = df
            logging.info(f"Loaded augmentation table: {table_name}. Shape: {df.shape}")
    return augmentation_data

def load_and_preprocess_data(train_path, test_path=None):
    """
    Loads, preprocesses, and merges data from various sources, incorporating
    features from both base and reference solutions. Handles memory efficiency.
    """
    logging.info("Loading and preprocessing data...")

    # --- Load Core Data ---
    # Load training data
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)
    logging.info(f"Initial train_df loaded. Shape: {train_df_raw.shape}, Memory: {train_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Load test data if provided
    test_df_raw = None
    if test_path:
        test_df_raw = pd.read_csv(test_path)
        test_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
        test_df_raw['is_pure_prediction'] = test_df_raw['violation_count'].isna()
        test_df_raw = downcast_dtypes(test_df_raw)
        logging.info(f"Test_df loaded. Shape: {test_df_raw.shape}, Memory: {test_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Combine unique street_name and violation_description pairs from train and test
    # for consistent feature engineering.
    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_keys_test = pd.DataFrame()
    if test_df_raw is not None:
        combined_keys_test = test_df_raw[['street_name', 'violation_description']].drop_duplicates()

    combined_df = pd.concat([combined_keys_train, combined_keys_test], ignore_index=True).drop_duplicates().reset_index(drop=True)
    del combined_keys_train, combined_keys_test
    gc.collect()
    logging.info(f"Combined unique (street, violation) pairs for feature engineering. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Convert to string to ensure consistency for merging and CatBoost
    combined_df['street_name'] = combined_df['street_name'].astype(str)
    combined_df['violation_description'] = combined_df['violation_description'].astype(str)

    # --- Feature Engineering and Augmentation (integrated from base and reference) ---

    # Basic features from core data (from both base and reference solutions)
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')
    combined_df['violation_description_word_count'] = combined_df['violation_description'].apply(lambda x: len(str(x).split())).astype('int16')

    # Load all augmentation tables
    augmentation_data = load_augmentation_tables()

    # Augmentation 1: nyc_street_data.csv (from Base solution)
    if 'nyc_street_data' in augmentation_data:
        street_data = augmentation_data['nyc_street_data'].copy()
        # Ensure consistent column names before using
        street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
        street_data['street_name'] = street_data['street_name'].astype(str)
        street_data = street_data.drop_duplicates(subset=['street_name'])
        combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
        logging.info(f"Merged with nyc_street_data. Shape: {combined_df.shape}")
        del street_data
        gc.collect()
    else:
        logging.warning("nyc_street_data.csv not found in augmentation_data. Skipping this augmentation.")

    # Augmentation 2: nyc_streets_metadata.csv (from Reference solution)
    if 'nyc_streets_metadata' in augmentation_data:
        street_metadata_df = augmentation_data['nyc_streets_metadata'].copy()
        # Rename 'Street' to 'street_name' to match main dataframe
        if 'Street' in street_metadata_df.columns:
            street_metadata_df = street_metadata_df.rename(columns={'Street': 'street_name'})
        else:
            logging.warning("nyc_streets_metadata.csv does not contain 'Street' column. Skipping metadata augmentation.")
            del street_metadata_df
            gc.collect()
        
        street_metadata_df['street_name'] = street_metadata_df['street_name'].astype(str)
        # Handle potential duplicates in street_name
        street_metadata_df = street_metadata_df.drop_duplicates(subset=['street_name'], keep='first')

        # Select core features as per reference solution
        core_street_metadata_features = ['street_name', 'ZipCode', 'assesstot']
        street_metadata_features_to_use = [f for f in core_street_metadata_features if f in street_metadata_df.columns]
        
        if len(street_metadata_features_to_use) > 1: # at least 'street_name' and one other feature
            street_metadata_df = street_metadata_df[street_metadata_features_to_use]

            # Ensure numerical columns are handled, coerced, and downcasted
            for col in street_metadata_df.columns:
                if col != 'street_name':
                    street_metadata_df[col] = pd.to_numeric(street_metadata_df[col], errors='coerce')
                    # Downcast if the data type allows
                    if street_metadata_df[col].dtype == 'float64':
                        street_metadata_df[col] = street_metadata_df[col].astype(np.float32)
                    elif street_metadata_df[col].dtype == 'int64':
                        if street_metadata_df[col].max() <= np.iinfo(np.int32).max and street_metadata_df[col].min() >= np.iinfo(np.int32).min:
                            street_metadata_df[col] = street_metadata_df[col].astype(np.int32)
            
            combined_df = pd.merge(combined_df, street_metadata_df, on='street_name', how='left')
            logging.info(f"Merged with nyc_streets_metadata. Shape: {combined_df.shape}")
        else:
            logging.warning("nyc_streets_metadata.csv does not contain enough relevant columns. Skipping metadata augmentation.")
        del street_metadata_df
        gc.collect()
    else:
        logging.warning("nyc_streets_metadata.csv not found in augmentation_data. Skipping this augmentation.")

    # Augmentation 3: nyc_parking_zones.csv (from Reference solution)
    if 'nyc_parking_zones' in augmentation_data:
        parking_zones_df = augmentation_data['nyc_parking_zones'].copy()
        if 'Street' in parking_zones_df.columns:
            parking_zones_df = parking_zones_df.rename(columns={'Street': 'street_name'})
        else:
            logging.warning("nyc_parking_zones.csv does not contain 'Street' column. Skipping parking zones augmentation.")
            del parking_zones_df
            gc.collect()
        
        parking_zones_df['street_name'] = parking_zones_df['street_name'].astype(str)
        # Aggregate parking zone information per street_name
        parking_zone_features = parking_zones_df.groupby('street_name')['parking_zone'].nunique().reset_index()
        parking_zone_features.rename(columns={'parking_zone': 'num_parking_zones'}, inplace=True)
        parking_zone_features['num_parking_zones'] = parking_zone_features['num_parking_zones'].astype('int16')
        
        combined_df = pd.merge(combined_df, parking_zone_features, on='street_name', how='left')
        combined_df['num_parking_zones'] = combined_df['num_parking_zones'].fillna(0).astype('int16') # Fill NaN for streets with no parking zone info
        logging.info(f"Merged with nyc_parking_zones. Shape: {combined_df.shape}")
        del parking_zones_df, parking_zone_features
        gc.collect()
    else:
        logging.warning("nyc_parking_zones.csv not found in augmentation_data. Skipping this augmentation.")

    # Augmentation 4: nyc_violation_codes.csv (Base) / violation_codes.csv (Reference)
    if 'nyc_violation_codes' in augmentation_data:
        violation_codes = augmentation_data['nyc_violation_codes'].copy()
        violation_codes.columns = ['violation_description', 'fine_amount', 'points']
        violation_codes['violation_description'] = violation_codes['violation_description'].astype(str)
        violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
        combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
        logging.info(f"Merged with nyc_violation_codes. Shape: {combined_df.shape}")
        del violation_codes
        gc.collect()
    elif 'violation_codes' in augmentation_data: # Fallback for reference solution's naming
        violation_codes = augmentation_data['violation_codes'].copy()
        # Ensure column names are standardized
        violation_codes = violation_codes.rename(columns={'Violation Description': 'violation_description', 'Fine Amount': 'fine_amount', 'Points': 'points'})
        violation_codes['violation_description'] = violation_codes['violation_description'].astype(str)
        violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
        combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
        logging.info(f"Merged with violation_codes (from reference). Shape: {combined_df.shape}")
        del violation_codes
        gc.collect()
    else:
        logging.warning("Neither nyc_violation_codes.csv nor violation_codes.csv found. Skipping violation codes augmentation.")

    # Augmentation 5: nyc_census_data.csv (from Base solution)
    # Check if 'borough' column exists before trying to merge census data
    if 'nyc_census_data' in augmentation_data and 'borough' in combined_df.columns:
        census_data = augmentation_data['nyc_census_data'].copy()
        census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
        relevant_census_cols = ['borough', 'population_density', 'avg_income']
        
        if all(col in census_data.columns for col in relevant_census_cols):
            census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
            census_agg = downcast_dtypes(census_agg)
            combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
            logging.info(f"Merged with census_data. Shape: {combined_df.shape}")
            del census_data, census_agg
            gc.collect()
        else:
            logging.warning(f"Missing one or more expected columns ({relevant_census_cols}) in nyc_census_data. Skipping census data augmentation.")
    else:
        logging.warning("nyc_census_data.csv not found in augmentation_data or 'borough' column missing. Skipping census data augmentation.")

    # Fill any numerical NaN values introduced by left merges with a default (e.g., 0 or mean/median)
    # CatBoost handles categorical NaNs well, but numerical NaNs should be treated.
    numerical_cols_to_fill_with_zero = ['street_length', 'num_lanes', 'fine_amount', 'points', 'ZipCode', 'assesstot', 'population_density', 'avg_income', 'num_parking_zones']
    for col in numerical_cols_to_fill_with_zero:
        if col in combined_df.columns and combined_df[col].isnull().any():
            if combined_df[col].dtype.kind == 'f': # float types
                combined_df[col] = combined_df[col].fillna(0.0).astype('float32')
            elif combined_df[col].dtype.kind == 'i': # integer types
                combined_df[col] = combined_df[col].fillna(0).astype('int32') # Use int32 as fallback
            else:
                combined_df[col] = combined_df[col].fillna(0) # Generic fill for other numerical

    # Split back into train and test processed dataframes
    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    test_processed_df = None
    if test_df_raw is not None:
        test_processed_df = pd.merge(test_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
        del test_df_raw
        gc.collect()

    logging.info(f"Final train_processed_df shape: {train_processed_df.shape}")
    if test_processed_df is not None:
        logging.info(f"Final test_processed_df shape: {test_processed_df.shape}")

    # Identify categorical features for CatBoost
    all_features_except_target_and_flag = [col for col in train_processed_df.columns if col not in ['violation_count', 'is_pure_prediction']]
    categorical_features = [col for col in all_features_except_target_and_flag if train_processed_df[col].dtype in ['object', 'category']]

    # Ensure all identified categorical columns are explicitly of 'category' dtype for CatBoost
    for col in categorical_features:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].astype('category')
        if test_processed_df is not None and col in test_processed_df.columns:
            test_processed_df[col] = test_processed_df[col].astype('category')

    logging.info(f"Categorical features identified for CatBoost: {categorical_features}")

    return train_processed_df, test_processed_df, categorical_features

def train_and_predict(train_df, test_df, categorical_features):
    """
    Trains two distinct CatBoost Regressor models (one from base, one from reference solution),
    ensembles their predictions, and generates final predictions.
    """
    logging.info("Training CatBoost models and ensembling predictions...")

    # Define features (X) and target (y)
    target = 'violation_count'
    # Use all available features except the target and `is_pure_prediction` flag
    features = [col for col in train_df.columns if col not in [target, 'is_pure_prediction']]

    X = train_df[features]
    y = train_df[target]

    # Split training data for validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    logging.info(f"Training data split: X_train={X_train.shape}, X_val={X_val.shape}")

    # Convert categorical feature names to their indices for CatBoost
    # Only include features actually present in X_train
    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]
    logging.info(f"Categorical feature indices for CatBoost: {cat_features_indices}")

    # --- Model 1: Base Solution CatBoost Model ---
    logging.info("Training Model 1 (Base CatBoost Model)...")
    model_base = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6, # Base solution's depth
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Set to 0 to prevent excessive output during two trainings
        early_stopping_rounds=50,
        thread_count=-1,
    )
    model_base.fit(X_train, y_train,
                   eval_set=(X_val, y_val),
                   cat_features=cat_features_indices,
                   plot=False)
    val_preds_base = model_base.predict(X_val)
    logging.info(f"Model 1 (Base) finished training. Best iteration: {model_base.get_best_iteration()}")

    # --- Model 2: Reference Solution CatBoost Model ---
    logging.info("Training Model 2 (Reference CatBoost Model)...")
    model_ref = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=8, # Reference solution's depth
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Set to 0 to prevent excessive output during two trainings
        early_stopping_rounds=100, # Reference solution's early stopping
        l2_leaf_reg=3.0,
        thread_count=-1,
        nan_mode='Min' # Reference solution's nan handling for numerical features
    )
    # Create CatBoost Pool objects for reference model as per reference solution
    train_pool_ref = Pool(X_train, y_train, cat_features=cat_features_indices)
    val_pool_ref = Pool(X_val, y_val, cat_features=cat_features_indices)

    model_ref.fit(train_pool_ref, eval_set=val_pool_ref, plot=False)
    val_preds_ref = model_ref.predict(X_val)
    logging.info(f"Model 2 (Reference) finished training. Best iteration: {model_ref.get_best_iteration()}")

    # --- Ensembling Validation Predictions ---
    # Simple average ensemble
    val_preds_ensemble = (val_preds_base + val_preds_ref) / 2
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds_ensemble))
    logging.info(f"Ensembled Development Validation RMSE: {val_rmse}")

    # Generate predictions for the test_df if provided
    submission_df = None
    if test_df is not None:
        logging.info("Generating ensembled predictions for test data...")
        # Ensure X_test contains only the features used for training and in correct order/types
        X_test = test_df[features]

        # Get predictions from both models
        test_preds_base = model_base.predict(X_test)
        test_preds_ref = model_ref.predict(X_test)

        # Ensemble test predictions
        test_preds_ensemble = (test_preds_base + test_preds_ref) / 2

        # Ensure predictions are non-negative and round to nearest integer
        test_preds_ensemble[test_preds_ensemble < 0] = 0
        test_preds_ensemble = np.round(test_preds_ensemble).astype(int)

        # Create submission dataframe
        submission_df = test_df[['street_name', 'violation_description']].copy()
        submission_df['predicted_count'] = test_preds_ensemble

        # Report RMSE if ground truth is available in test_df
        if 'is_pure_prediction' in test_df.columns and not test_df['is_pure_prediction'].all():
            ground_truth_test_df = test_df[~test_df['is_pure_prediction']].copy() # Use .copy() to avoid SettingWithCopyWarning
            # Match predictions to ground truth rows
            ground_truth_preds = submission_df[~test_df['is_pure_prediction']]['predicted_count']
            test_rmse = np.sqrt(mean_squared_error(ground_truth_test_df[target], ground_truth_preds))
            logging.info(f"Ensembled RMSE on provided test/evaluation data (with ground truth): {test_rmse}")
        elif target in test_df.columns: # If no is_pure_prediction flag but target exists in test_df
             test_rmse = np.sqrt(mean_squared_error(test_df[target], test_preds_ensemble))
             logging.info(f"Ensembled RMSE on provided test/evaluation data: {test_rmse}")


        # Report unseen key pairs (from reference solution)
        train_keys = set(train_df.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
        test_keys = set(test_df.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
        unseen_keys_count = len(test_keys - train_keys)
        logging.info(f"Number of (street_name, violation_description) pairs in test/eval unseen in training: {unseen_keys_count}")
        logging.info("Unseen keys are handled by CatBoost's internal mechanism for new categorical levels.")

    return submission_df, val_rmse

def main():
    """
    Main function to parse arguments, orchestrate data loading, training, and prediction.
    """
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional path to the 2023 test/evaluation data CSV. '
                             'If provided, predictions will be generated and RMSE reported if ground truth exists.')
    args = parser.parse_args()

    train_df, test_df, categorical_features = load_and_preprocess_data(args.train_path, args.test_path)
    submission_df, final_validation_score = train_and_predict(train_df, test_df, categorical_features)

    if submission_df is not None:
        submission_df.to_csv('submission.csv', index=False)
        logging.info("Submission file 'submission.csv' generated successfully.")

    # Always print the final validation score as required
    print(f"Final Validation Performance: {final_validation_score}")

if __name__ == "__main__":
    main()

