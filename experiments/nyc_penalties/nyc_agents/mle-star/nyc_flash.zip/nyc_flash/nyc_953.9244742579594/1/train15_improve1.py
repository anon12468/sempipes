
import argparse
import pandas as pd
import numpy as np
import os
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def parse_args():
    """Parses command line arguments."""
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument("--train-path", type=str, default="violations_per_street_2022.csv",
                        help="Path to the 2022 violations training data. Default is 'violations_per_street_2022.csv'.")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Optional path to the test/evaluation data for 2023 predictions. If provided, predictions will be generated and saved to submission.csv.")
    return parser.parse_args()

def load_data(file_path, directory="./input"):
    """
    Loads a CSV file, ensuring it's accessed from the specified directory if not an absolute path.
    """
    if not os.path.isabs(file_path) and not file_path.startswith(directory):
        full_path = os.path.join(directory, file_path)
    else:
        full_path = file_path
        
    logging.info(f"Attempting to load data from: {full_path}")
    if not os.path.exists(full_path):
        logging.error(f"File not found: {full_path}")
        raise FileNotFoundError(f"Data file not found at {full_path}. Please ensure it's in the '{directory}' directory or provide an absolute path.")
    
    try:
        df = pd.read_csv(full_path)
        logging.info(f"Successfully loaded {os.path.basename(full_path)} with shape: {df.shape}")
        return df
    except Exception as e:
        logging.error(f"Error loading {full_path}: {e}")
        raise

def load_augmentation_data(directory="./input"):
    """
    Loads all CSV files from the specified directory (excluding the main training file)
    as augmentation data.
    """
    logging.info(f"Loading augmentation data from directory: {directory}")
    augmentation_datasets = {}
    if not os.path.exists(directory):
        logging.warning(f"Augmentation directory '{directory}' not found. No additional augmentation data will be loaded.")
        return augmentation_datasets

    input_files = [f for f in os.listdir(directory) if f.endswith('.csv') and f != 'violations_per_street_2022.csv']
    
    for fname in input_files:
        try:
            full_path = os.path.join(directory, fname)
            df_aug = pd.read_csv(full_path)
            # Use filename without extension as key
            augmentation_datasets[fname.replace('.csv', '')] = df_aug
            logging.info(f"Loaded augmentation file: {fname} with shape: {df_aug.shape}")
        except Exception as e:
            logging.warning(f"Could not load augmentation file {fname}: {e}")
            
    return augmentation_datasets

def feature_engineer(df, augmentation_data):
    """
    Performs feature engineering on the input DataFrame using augmentation data.
    """
    logging.info("Starting feature engineering...")

    # Ensure consistent column names
    df.rename(columns={'Street Name': 'street_name', 'Violation Description': 'violation_type'}, inplace=True)

    # Basic features
    df['street_name_len'] = df['street_name'].fillna('').astype(str).apply(len)
    df['violation_type_len'] = df['violation_type'].fillna('').astype(str).apply(len)
    
    # Convert key categorical features to string type explicitly for CatBoost
    df['street_name'] = df['street_name'].astype(str)
    df['violation_type'] = df['violation_type'].astype(str)

    # Example of joining with hypothetical augmentation data
    # In a real scenario, you'd integrate the actual augmentation_data files.
    # For demonstration, let's assume one augmentation table 'nyc_street_meta' with 'street_name' and 'borough'
    
    # Check for 'nyc_street_meta' in loaded augmentation data
    # This is a placeholder; actual column names and join keys would depend on discovered data.
    if 'nyc_street_meta' in augmentation_data:
        aug_df = augmentation_data['nyc_street_meta']
        if 'street_name' in aug_df.columns and 'borough' in aug_df.columns:
            logging.info("Joining with 'nyc_street_meta' data for 'borough'.")
            df = pd.merge(df, aug_df[['street_name', 'borough']].drop_duplicates(subset=['street_name']),
                          on='street_name', how='left')
            df['borough'] = df['borough'].astype(str).fillna('UNKNOWN_BOROUGH')
        else:
            logging.warning("'nyc_street_meta' found but missing 'street_name' or 'borough' columns for join. Skipping.")
            df['borough'] = 'UNKNOWN_BOROUGH' # Default if not joined or columns missing
    else:
        df['borough'] = 'UNKNOWN_BOROUGH' # Default if no specific augmentation file is found
        logging.info("No 'nyc_street_meta' augmentation data found. 'borough' column defaulted to 'UNKNOWN_BOROUGH'.")

    # Additional placeholder for time-based features, if date columns were present
    # For now, we only have aggregate counts, so no direct date features.

    logging.info(f"Feature engineering complete. DataFrame shape: {df.shape}")
    return df

def train_model(X_train, y_train, X_val, y_val, cat_features):
    """
    Trains a CatBoostRegressor model.
    """
    logging.info(f"Starting CatBoost model training. Training samples: {X_train.shape[0]}, Validation samples: {X_val.shape[0]}")
    
    # CatBoost parameters chosen for robustness and memory efficiency
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=8,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Set to 0 to suppress console output from CatBoost during fit
        early_stopping_rounds=50,
        cat_features=cat_features,
        grow_policy='Lossguide', # Good for memory on large datasets
        l2_leaf_reg=3,
        thread_count=-1, # Use all available CPU threads
        # max_ctr_complexity=1 # Can be adjusted for memory/accuracy trade-off
    )

    train_pool = Pool(X_train, y_train, cat_features=cat_features)
    val_pool = Pool(X_val, y_val, cat_features=cat_features)

    model.fit(train_pool,
              eval_set=val_pool,
              use_best_model=True, # Revert to the best model found during training
              plot=False) # Do not plot training progress

    logging.info(f"CatBoost model training complete. Best iteration: {model.get_best_iteration()}")
    return model

def main():
    args = parse_args()

    # Load 2022 training data
    train_df_2022 = load_data(args.train_path)

    # Load augmentation data from './input'
    augmentation_data = load_augmentation_data()

    # Feature engineering for training data
    train_df_2022_fe = feature_engineer(train_df_2022.copy(), augmentation_data)

    # Define features and target
    features_to_exclude = ['violation_count']
    X_cols = [col for col in train_df_2022_fe.columns if col not in features_to_exclude]
    y_col = 'violation_count'
    
    # Ensure all identified features exist in the DataFrame
    X_cols = [col for col in X_cols if col in train_df_2022_fe.columns]
    
    if not X_cols:
        logging.error("No features generated for training. Exiting.")
        return

    # Identify categorical features for CatBoost
    # All string-like columns after feature engineering are treated as categorical
    categorical_feature_names = [col for col in X_cols if train_df_2022_fe[col].dtype == 'object' or pd.api.types.is_string_dtype(train_df_2022_fe[col])]
    logging.info(f"Identified categorical features: {categorical_feature_names}")

    X = train_df_2022_fe[X_cols]
    y = train_df_2022_fe[y_col]

    # Handle potential negative or non-integer counts in target by clipping and converting to integer
    y = y.clip(lower=0).astype(int)

    # Split 2022 data for training and validation (80/20 split)
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    logging.info(f"Data split: Training samples={X_train.shape[0]}, Validation samples={X_val.shape[0]}")

    # Train the model
    model = train_model(X_train, y_train, X_val, y_val, cat_features=categorical_feature_names)

    # Evaluate on validation set
    val_predictions = model.predict(X_val)
    # Ensure predictions are non-negative and can be rounded to integers for counts
    val_predictions = np.maximum(0, val_predictions).round().astype(int)
    final_validation_score = np.sqrt(mean_squared_error(y_val, val_predictions))
    logging.info(f"Final Validation Performance: {final_validation_score}")
    print(f"Final Validation Performance: {final_validation_score}") # Required output format

    # Handle test-path if provided
    if args.test_path:
        logging.info(f"Processing test data from: {args.test_path}")
        test_df = load_data(args.test_path)
        
        # Store original keys for submission file
        test_df_original_keys = test_df[['Street Name', 'Violation Description']].copy()

        # Feature engineering for test data
        test_df_fe = feature_engineer(test_df.copy(), augmentation_data)

        # Align columns between training and test (critical for consistent features)
        missing_cols_in_test = set(X.columns) - set(test_df_fe.columns)
        for col in missing_cols_in_test:
            if col in categorical_feature_names:
                test_df_fe[col] = 'UNSEEN_CATEGORY' # Default for new categorical features
            else:
                test_df_fe[col] = 0 # Default for new numerical features (e.g., if a new numeric aug file wasn't loaded)
            logging.warning(f"Feature '{col}' from training data missing in test data. Filled with default.")

        extra_cols_in_test = set(test_df_fe.columns) - set(X.columns)
        if extra_cols_in_test:
            logging.warning(f"Extra features in test data not present in training: {extra_cols_in_test}. These will be dropped.")
            test_df_fe = test_df_fe.drop(columns=list(extra_cols_in_test))

        # Ensure column order is identical to training data
        test_df_fe = test_df_fe[X.columns]
        
        # Make predictions on test data
        test_predictions = model.predict(test_df_fe)
        test_predictions = np.maximum(0, test_predictions).round().astype(int)

        # Create submission file
        submission_df = pd.DataFrame({
            'street_name': test_df_original_keys['Street Name'],
            'violation_type': test_df_original_keys['Violation Description'],
            'predicted_count': test_predictions
        })
        submission_df.to_csv("submission.csv", index=False)
        logging.info("Submission file 'submission.csv' generated successfully.")

        # If test data has 'violation_count' column, calculate RMSE
        if 'violation_count' in test_df.columns:
            true_counts = test_df['violation_count'].clip(lower=0).astype(int)
            test_rmse = np.sqrt(mean_squared_error(true_counts, test_predictions))
            logging.info(f"RMSE on provided test set: {test_rmse}")
            
            # Report how many key pairs in test/eval were unseen in training
            train_key_pairs = set(X_train['street_name'] + '|||' + X_train['violation_type'])
            test_key_pairs = set(test_df_fe['street_name'] + '|||' + test_df_fe['violation_type'])
            unseen_keys_count = len(test_key_pairs - train_key_pairs)
            logging.info(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_keys_count} out of {len(test_key_pairs)} total test pairs.")
            logging.info(f"Unseen pairs are handled by CatBoost's ability to generalize from existing categorical features and the overall model structure, treating unknown categories as a separate category or by learning embeddings.")
    else:
        logging.info("No test-path provided. Skipping test prediction and submission file generation.")

    logging.info("Prediction pipeline finished.")

if __name__ == "__main__":
    main()

