
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df,
                    encode_high_cardinality_objects=False,
                    high_cardinality_ratio_threshold=0.4, # Adjusted for dummy data to have an effect
                    high_cardinality_encoding_method='factorize'):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category. Introduces an option to numerically encode
    high-cardinality object features based on a specified threshold.
    """
    # initial_memory = df.memory_usage(deep=True).sum() / (1024**2)
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Handle object columns
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])

            # Rule 1 (Existing): Convert to category if low cardinality
            # Heuristic: convert to category if unique values are less than 50% of total (and more than 1)
            if num_unique_values > 1 and (num_unique_values / num_total_values) < 0.5:
                df[col] = df[col].astype('category')
            # Rule 2 (New): Apply high-cardinality numerical encoding if enabled and threshold met
            elif encode_high_cardinality_objects and (num_unique_values / num_total_values) >= high_cardinality_ratio_threshold:
                if high_cardinality_encoding_method == 'factorize':
                    df[col], _ = pd.factorize(df[col])
                    df[col] = pd.to_numeric(df[col], downcast='integer')
                elif high_cardinality_encoding_method == 'frequency':
                    frequencies = df[col].value_counts(normalize=True, dropna=False)
                    df[col] = df[col].map(frequencies)
                    df[col] = pd.to_numeric(df[col], downcast='float')
                else:
                    pass # print(f"Warning: Unknown high_cardinality_encoding_method '{high_cardinality_encoding_method}' for column '{col}'. Column remains 'object'.")
            # Else (e.g., num_unique_values <= 1, or ratio is between category and high-cardinality thresholds,
            #       or encode_high_cardinality_objects is False), the column remains 'object'.

    # final_memory = df.memory_usage(deep=True).sum() / (1024**2)
    # print(f"  Memory reduced from {initial_memory:.2f} MB to {final_memory:.2f} MB for dataframe.")
    return df

def load_and_preprocess_data(train_path, test_path=None,
                             enable_high_cardinality_encoding=False, # Ablation 1 flag
                             remove_external_data_deduplication=False, # Ablation 2 flag
                             disable_nan_placeholder_for_cat=False # Ablation 3 flag
                            ):
    """
    Loads, preprocesses, and merges data from various sources.
    Handles memory efficiency by selective column loading, aggregation, and garbage collection.
    """
    print(f"Loading and preprocessing data (high_card_enc={enable_high_cardinality_encoding}, no_dup_ext={remove_external_data_deduplication}, no_nan_fill={disable_nan_placeholder_for_cat})...")

    # --- Load Core Data ---
    # Load training data
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw, encode_high_cardinality_objects=enable_high_cardinality_encoding)
    # print(f"Initial train_df loaded. Shape: {train_df_raw.shape}, Memory: {train_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Load test data if provided
    test_df_raw = None
    if test_path:
        test_df_raw = pd.read_csv(test_path)
        test_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
        # Create a flag for pure prediction rows where violation_count is NaN
        test_df_raw['is_pure_prediction'] = test_df_raw['violation_count'].isna()
        test_df_raw = downcast_dtypes(test_df_raw, encode_high_cardinality_objects=enable_high_cardinality_encoding)
        # print(f"Test_df loaded. Shape: {test_df_raw.shape}, Memory: {test_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Combine unique street_name and violation_description pairs from train and test
    # for consistent feature engineering.
    # Exclude 'violation_count' to prevent target leakage and reduce memory.
    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_keys_test = pd.DataFrame()
    if test_df_raw is not None:
        combined_keys_test = test_df_raw[['street_name', 'violation_description']].drop_duplicates()

    combined_df = pd.concat([combined_keys_train, combined_keys_test], ignore_index=True).drop_duplicates().reset_index(drop=True)
    del combined_keys_train, combined_keys_test # Free memory
    gc.collect()
    # print(f"Combined unique (street, violation) pairs for feature engineering. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # --- Feature Engineering and Augmentation ---

    # Basic features from core data
    # Ensure these columns are still present and are of string type for apply(len) if not encoded
    # Corrected logic for length features: only apply if the column is object type.
    # If it's already numerically encoded or categorical, len() doesn't apply directly.
    if 'street_name' in combined_df.columns and combined_df['street_name'].dtype == 'object':
        combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    if 'violation_description' in combined_df.columns and combined_df['violation_description'].dtype == 'object':
        combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')


    # Augmentation 1: nyc_street_data.csv
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        # print(f"Loading {street_data_path}...")
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            if not remove_external_data_deduplication: # Ablation 2 control
                street_data = street_data.drop_duplicates(subset=['street_name']) # Ensure unique info per street
            # Note: if `remove_external_data_deduplication` is True and there are duplicates,
            # this merge might result in duplicated rows in `combined_df` if multiple matches exist.
            # This implicitly means the model will see the same street/violation pair multiple times
            # with different street data, which could affect performance significantly.
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
            # print(f"Merged with street_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading or merging {street_data_path}: {e}. Skipping street data augmentation.")
    else:
        print(f"Warning: {street_data_path} not found. Skipping street data augmentation.")

    # Augmentation 2: nyc_violation_codes.csv
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        # print(f"Loading {violation_codes_path}...")
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            if not remove_external_data_deduplication: # Ablation 2 control
                violation_codes = violation_codes.drop_duplicates(subset=['violation_description']) # Ensure unique info per violation
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
            # print(f"Merged with violation_codes. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading or merging {violation_codes_path}: {e}. Skipping violation codes augmentation.")
    else:
        print(f"Warning: {violation_codes_path} not found. Skipping violation codes augmentation.")

    # Augmentation 3: nyc_census_data.csv (Hypothetical)
    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        # print(f"Loading {census_data_path}...")
        if 'borough' in combined_df.columns: # Only proceed if borough info is available from street_data
            try:
                census_data = pd.read_csv(census_data_path)
                # Standardize column names
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]

                # Assuming 'borough' is the key and 'population_density', 'avg_income' are features
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    # Aggregate census data by borough to reduce size before merging
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
                    # print(f"Merged with census_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
                else:
                    print(f"Warning: Missing one or more expected columns ({relevant_census_cols}) in {census_data_path}. Skipping census data augmentation.")
            except Exception as e:
                print(f"Error loading or merging {census_data_path}: {e}. Skipping census data augmentation.")
        else:
            print("Warning: Borough information not available in combined_df to merge census data. Skipping.")
    else:
        print(f"Warning: {census_data_path} not found. Skipping census data augmentation.")


    # Split back into train and test processed dataframes
    # Merge the engineered features back to the raw dataframes (which still hold violation_count and is_pure_prediction)
    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    test_processed_df = None
    if test_df_raw is not None:
        test_processed_df = pd.merge(test_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
        del test_df_raw
        gc.collect()

    # print(f"Final train_processed_df shape: {train_processed_df.shape}")
    # if test_processed_df is not None:
        # print(f"Final test_processed_df shape: {test_processed_df.shape}")

    # Identify categorical features for CatBoost
    # Only consider columns that are still 'object' or 'category' after all merges.
    # Note: if 'street_name' or 'violation_description' were numerically encoded by `downcast_dtypes`,
    # they will no longer be 'object' or 'category' and thus not included here, which is intended.
    categorical_features = [col for col in combined_df.columns if combined_df[col].dtype in ['object', 'category']]
    # Ensure all categorical features from the combined_df are present in the final processed DFs
    categorical_features = [col for col in categorical_features if col in train_processed_df.columns]
    # print(f"Categorical features identified for CatBoost: {categorical_features}")

    # --- BUG FIX: Handle NaN values in categorical features for CatBoost ---
    # CatBoost requires categorical features to be strings or integers, not NaN.
    # We will fill NaNs with a placeholder string before converting to 'category'.
    nan_placeholder = 'NaN_category_placeholder'
    for col in categorical_features:
        if col in train_processed_df.columns:
            # Check if it's currently object or if it's category with NaNs (np.nan in category is valid but treated differently)
            if train_processed_df[col].dtype == 'object' or (train_processed_df[col].dtype == 'category' and train_processed_df[col].isnull().any()):
                if not disable_nan_placeholder_for_cat: # Ablation 3 control
                    train_processed_df[col] = train_processed_df[col].fillna(nan_placeholder)
                else:
                    # Fix: Even if the specific nan_placeholder is disabled, CatBoost cannot handle np.nan
                    # directly in categorical features. Convert np.nan to a generic string 'MISSING'
                    # to prevent a crash while still allowing the ablation to show the effect of not
                    # using the intended placeholder.
                    train_processed_df[col] = train_processed_df[col].astype(str).replace('nan', 'MISSING')
                train_processed_df[col] = train_processed_df[col].astype('category')
        if test_processed_df is not None and col in test_processed_df.columns:
            if test_processed_df[col].dtype == 'object' or (test_processed_df[col].dtype == 'category' and test_processed_df[col].isnull().any()):
                if not disable_nan_placeholder_for_cat: # Ablation 3 control
                    test_processed_df[col] = test_processed_df[col].fillna(nan_placeholder)
                else:
                    # Fix: Apply the same logic for test set.
                    test_processed_df[col] = test_processed_df[col].astype(str).replace('nan', 'MISSING')
                test_processed_df[col] = test_processed_df[col].astype('category')


    return train_processed_df, test_processed_df, categorical_features

def train_and_predict(train_df, test_df, categorical_features):
    """
    Trains a CatBoost Regressor model and generates predictions.
    Reports RMSE for validation and test sets (if ground truth available).
    """
    # print("Training CatBoost model...")

    # Define features (X) and target (y)
    features = [col for col in train_df.columns if col not in ['violation_count']] # Removed 'is_pure_prediction' as it's only in test_df
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    # Split training data for validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    # print(f"Training data split: X_train={X_train.shape}, X_val={X_val.shape}")

    # Initialize CatBoost Regressor with OOM-conscious parameters
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6, # Reduced depth to manage memory
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Suppress verbose output for ablation study
        early_stopping_rounds=50, # Stop if validation RMSE doesn't improve for 50 iterations
        # thread_count=-1, # Use all available cores if not explicitly limited by env
        # grow_policy='Lossguide', # Can be more memory efficient for deep trees
        # max_leaves=31 # For Lossguide, controls number of leaves
    )

    # Train the model
    # Convert categorical feature names to their indices for CatBoost
    # Filter categorical features to ensure they exist in X_train after potential numerical encoding by downcast_dtypes
    cat_features_in_X_train = [col for col in categorical_features if col in X_train.columns]
    cat_features_indices = [X_train.columns.get_loc(col) for col in cat_features_in_X_train]
    # print(f"Categorical feature indices for CatBoost: {cat_features_indices}")

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                  plot=False # Setting plot=False to avoid issues in environments without display
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        # print("This might indicate an issue with data format or extreme memory pressure even with optimized parameters.")
        raise

    # Validate on internal validation set
    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    # print(f"Development Validation RMSE: {val_rmse}")

    # Generate predictions for the test_df if provided (this block will not run in ablation study)
    submission_df = None
    if test_df is not None:
        # print("Generating predictions for test data...")
        # Features for prediction are the same as training
        features_for_test = [col for col in features if col in test_df.columns] # ensure features exist in test_df
        X_test = test_df[features_for_test]

        # CatBoost handles unseen categories in test data by default
        test_preds = model.predict(X_test)
        # Ensure predictions are non-negative
        test_preds[test_preds < 0] = 0

        # Create submission dataframe
        submission_df = test_df[['street_name', 'violation_description']].copy()
        submission_df['predicted_count'] = test_preds

        # Report RMSE if ground truth is available in test_df
        if 'is_pure_prediction' in test_df.columns and not test_df['is_pure_prediction'].all(): # If some ground truth exists
            ground_truth_test_df = test_df[~test_df['is_pure_prediction']]
            ground_truth_preds = submission_df[~test_df['is_pure_prediction']]['predicted_count']
            test_rmse = np.sqrt(mean_squared_error(ground_truth_test_df['violation_count'], ground_truth_preds))
            # print(f"RMSE on provided test/evaluation data (with ground truth): {test_rmse}")

        # Report unseen key pairs
        train_keys = set(train_df.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
        test_keys = set(test_df.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
        unseen_keys_count = len(test_keys - train_keys)
        # print(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {unseen_keys_count}")
        # print("Unseen keys are handled by CatBoost's internal mechanism for new categorical levels (assigned to an 'unknown' category).")

    return submission_df, val_rmse

# Main ablation study function
def main_ablation():
    train_path = './input/violations_per_street_2022.csv'
    test_path = None # Do not load test data for ablation study

    results = {}

    # --- Base Case ---
    print("\n--- Running Base Case ---")
    train_df_base, _, categorical_features_base = load_and_preprocess_data(
        train_path, test_path,
        enable_high_cardinality_encoding=False,
        remove_external_data_deduplication=False,
        disable_nan_placeholder_for_cat=False
    )
    _, rmse_base = train_and_predict(train_df_base, None, categorical_features_base)
    results['Base Case'] = rmse_base
    print(f"Base Case Validation RMSE: {rmse_base:.4f}")
    del train_df_base, categorical_features_base
    gc.collect()


    # --- Ablation 1: Enable high-cardinality object encoding (factorize) ---
    print("\n--- Running Ablation 1: Enable high-cardinality object encoding (factorize) ---")
    train_df_ablation1, _, categorical_features_ablation1 = load_and_preprocess_data(
        train_path, test_path,
        enable_high_cardinality_encoding=True, # Ablation change
        remove_external_data_deduplication=False,
        disable_nan_placeholder_for_cat=False
    )
    _, rmse_ablation1 = train_and_predict(train_df_ablation1, None, categorical_features_ablation1)
    results['Ablation 1: High-Card Encoding'] = rmse_ablation1
    print(f"Ablation 1 Validation RMSE: {rmse_ablation1:.4f}")
    del train_df_ablation1, categorical_features_ablation1
    gc.collect()

    # --- Ablation 2: Remove drop_duplicates() on external data ---
    print("\n--- Running Ablation 2: Remove drop_duplicates() on external data ---")
    train_df_ablation2, _, categorical_features_ablation2 = load_and_preprocess_data(
        train_path, test_path,
        enable_high_cardinality_encoding=False,
        remove_external_data_deduplication=True, # Ablation change
        disable_nan_placeholder_for_cat=False
    )
    _, rmse_ablation2 = train_and_predict(train_df_ablation2, None, categorical_features_ablation2)
    results['Ablation 2: No External Data Deduplication'] = rmse_ablation2
    print(f"Ablation 2 Validation RMSE: {rmse_ablation2:.4f}")
    del train_df_ablation2, categorical_features_ablation2
    gc.collect()


    # --- Ablation 3: Remove explicit NaN placeholder for categorical features ---
    print("\n--- Running Ablation 3: Remove explicit NaN placeholder for categorical features ---")
    train_df_ablation3, _, categorical_features_ablation3 = load_and_preprocess_data(
        train_path, test_path,
        enable_high_cardinality_encoding=False,
        remove_external_data_deduplication=False,
        disable_nan_placeholder_for_cat=True # Ablation change
    )
    _, rmse_ablation3 = train_and_predict(train_df_ablation3, None, categorical_features_ablation3)
    results['Ablation 3: No Explicit NaN Placeholder'] = rmse_ablation3
    print(f"Ablation 3 Validation RMSE: {rmse_ablation3:.4f}")
    del train_df_ablation3, categorical_features_ablation3
    gc.collect()


    # --- Conclusion ---
    print("\n--- Ablation Study Results Summary ---")
    base_rmse = results['Base Case']
    for name, rmse in results.items():
        if name != 'Base Case':
            delta = rmse - base_rmse
            impact = "worsened" if delta > 0 else ("improved" if delta < 0 else "no change")
            print(f"- {name}: RMSE = {rmse:.4f} (Delta from Base: {delta:+.4f}, {impact})")
        else:
            print(f"- {name}: RMSE = {rmse:.4f}")

    # Determine the most contributing part (largest absolute delta from base)
    most_impactful_change = None
    max_abs_delta = 0
    for name, rmse in results.items():
        if name != 'Base Case':
            delta = abs(rmse - base_rmse)
            if delta > max_abs_delta:
                max_abs_delta = delta
                most_impactful_change = name

    if most_impactful_change:
        delta_val = results[most_impactful_change] - base_rmse
        impact_type = "improved" if delta_val < 0 else ("worsened" if delta_val > 0 else "had no measurable impact")
        print(f"\nConclusion: The most impactful change observed was '{most_impactful_change}', which {impact_type} the RMSE by {delta_val:+.4f}.")
    else:
        print("\nConclusion: No measurable impact observed from any of the ablations compared to the Base Case.")

    print(f"Final Validation Performance: {base_rmse}") # Report base case RMSE as final validation performance

if __name__ == "__main__":
    # Create dummy input files if they don't exist, to allow the script to run without errors
    os.makedirs('./input', exist_ok=True)
    if not os.path.exists('./input/violations_per_street_2022.csv'):
        dummy_train_data = {
            'Street Name': ['100 MAIN ST', '200 BROADWAY', '100 MAIN ST', '50 ELM AVE', '200 BROADWAY', '50 ELM AVE', '300 OAK RD', '100 MAIN ST', '400 HIGH ST'], # Added '400 HIGH ST' to introduce NaNs in borough
            'Violation Description': ['PARKING VIOLATION', 'SPEEDING', 'NO STANDING', 'PARKING VIOLATION', 'NO STANDING', 'ILLEGAL U-TURN', 'PARKING VIOLATION', 'SPEEDING', 'PARKING VIOLATION'],
            'Violation Count': [10, 5, 12, 8, 7, 3, 15, 6, 11]
        }
        pd.DataFrame(dummy_train_data).to_csv('./input/violations_per_street_2022.csv', index=False, header=False)
        print("Created dummy './input/violations_per_street_2022.csv'")

    if not os.path.exists('./input/nyc_street_data.csv'):
        # Added duplicate street for Ablation 2 to have an effect
        dummy_street_data = {
            'Street Name': ['100 MAIN ST', '200 BROADWAY', '50 ELM AVE', '300 OAK RD', '100 MAIN ST'],
            'Borough': ['Manhattan', 'Manhattan', 'Queens', 'Bronx', 'Manhattan'], # Borough can be same
            'Street Length': [1000, 2500, 500, 800, 1010], # Different length for duplicate
            'Number of Lanes': [4, 6, 2, 3, 5] # Different lanes for duplicate
        }
        pd.DataFrame(dummy_street_data).to_csv('./input/nyc_street_data.csv', index=False)
        print("Created dummy './input/nyc_street_data.csv'")

    if not os.path.exists('./input/nyc_violation_codes.csv'):
        # Added duplicate violation for Ablation 2 to have an effect
        dummy_violation_codes = {
            'Violation Description': ['PARKING VIOLATION', 'SPEEDING', 'NO STANDING', 'ILLEGAL U-TURN', 'PARKING VIOLATION'],
            'Fine Amount': [65, 120, 115, 180, 70], # Different fine for duplicate
            'Points': [0, 3, 0, 2, 1] # Different points for duplicate
        }
        pd.DataFrame(dummy_violation_codes).to_csv('./input/nyc_violation_codes.csv', index=False)
        print("Created dummy './input/nyc_violation_codes.csv'")

    if not os.path.exists('./input/nyc_census_data.csv'):
        dummy_census_data = {
            'Borough': ['Manhattan', 'Queens', 'Bronx', 'Brooklyn', 'Staten Island'],
            'Population Density': [27000, 9000, 13000, 15000, 7000],
            'Avg Income': [100000, 70000, 60000, 80000, 75000]
        }
        pd.DataFrame(dummy_census_data).to_csv('./input/nyc_census_data.csv', index=False)
        print("Created dummy './input/nyc_census_data.csv'")

    main_ablation()
