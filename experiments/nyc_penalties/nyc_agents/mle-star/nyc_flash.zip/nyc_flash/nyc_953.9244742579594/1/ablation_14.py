
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    # initial_memory = df.memory_usage(deep=True).sum() / (1024**2) # Suppressed for cleaner ablation output
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    # final_memory = df.memory_usage(deep=True).sum() / (1024**2) # Suppressed for cleaner ablation output
    # print(f"  Memory reduced from {initial_memory:.2f} MB to {final_memory:.2f} MB for dataframe.")
    return df

def load_and_preprocess_data_ablated(train_path, 
                                     no_street_data_augmentation=False,
                                     no_census_data_augmentation=False,
                                     no_explicit_category_conversion=False):
    """
    Loads, preprocesses, and merges data from various sources, with flags for ablation.
    Only focuses on train data for the ablation study.
    """
    print("\n--- Loading and preprocessing data for ablation ---")
    print(f"Ablation settings: No Street Data={no_street_data_augmentation}, No Census Data={no_census_data_augmentation}, No Explicit Cat Convert={no_explicit_category_conversion}")

    # --- Load Core Data ---
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)
    # print(f"Initial train_df loaded. Shape: {train_df_raw.shape}, Memory: {train_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Combine unique street_name and violation_description pairs from train only for feature engineering.
    combined_df = train_df_raw[['street_name', 'violation_description']].drop_duplicates().reset_index(drop=True)
    gc.collect()
    # print(f"Combined unique (street, violation) pairs for feature engineering. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # --- Feature Engineering and Augmentation ---

    # Basic features from core data
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # Augmentation 1: nyc_street_data.csv
    street_data_path = './input/nyc_street_data.csv'
    if not no_street_data_augmentation and os.path.exists(street_data_path):
        # print(f"Loading {street_data_path}...")
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
            # print(f"Merged with street_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading or merging {street_data_path}: {e}. Skipping street data augmentation.")
    else:
        print(f"Skipping street data augmentation (file not found or ablation active).")

    # Augmentation 2: nyc_violation_codes.csv (always included in this ablation setup as it's a core feature source)
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        # print(f"Loading {violation_codes_path}...")
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']

            def get_violation_category(description):
                desc = str(description).upper()
                if 'NO STANDING' in desc or 'NO PARKING' in desc or 'FIRE HYDRANT' in desc or 'BUS STOP' in desc or 'METER' in desc or 'GARAGE' in desc or 'PARKING' in desc:
                    return 'Parking'
                elif 'RED LIGHT' in desc or 'STOP SIGN' in desc or 'SPEED' in desc or 'LANE' in desc or 'TRAFFIC' in desc or 'MOVING' in desc or 'DRIVING' in desc or 'TURN' in desc or 'SIGNAL' in desc or 'PASSING' in desc:
                    return 'Moving'
                elif 'SEAT BELT' in desc or 'EQUIPMENT' in desc or 'INSPECTION' in desc or 'WINDOW' in desc or 'LICENCE' in desc or 'REGISTRATION' in desc or 'INSURANCE' in desc or 'SAFETY' in desc or 'DEFECTIVE' in desc or 'HAZARDOUS' in desc:
                    return 'Safety/Equipment'
                elif 'COMMERCIAL' in desc or 'TRUCK' in desc or 'LOADING' in desc or 'WEIGH' in desc:
                    return 'Commercial/Truck'
                elif 'STOP' in desc or 'STAND' in desc:
                    return 'Parking'
                return 'Other'

            violation_codes['violation_category'] = violation_codes['violation_description'].apply(get_violation_category)
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
            # print(f"Merged with violation_codes. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading or merging {violation_codes_path}: {e}. Skipping violation codes augmentation.")
    else:
        print(f"Warning: {violation_codes_path} not found. Skipping violation codes augmentation.")

    # Augmentation 3: nyc_census_data.csv
    census_data_path = './input/nyc_census_data.csv'
    if not no_census_data_augmentation and os.path.exists(census_data_path):
        # print(f"Loading {census_data_path}...")
        if 'borough' in combined_df.columns:
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
                    # print(f"Merged with census_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
                else:
                    print(f"Warning: Missing one or more expected columns ({relevant_census_cols}) in {census_data_path}. Skipping census data augmentation.")
            except Exception as e:
                print(f"Error loading or merging {census_data_path}: {e}. Skipping census data augmentation.")
        else:
            print("Warning: Borough information not available in combined_df to merge census data. Skipping.")
    else:
        print(f"Skipping census data augmentation (file not found or ablation active).")

    # Merge the engineered features back to the raw train dataframe
    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    print(f"Final train_processed_df shape: {train_processed_df.shape}")

    # Identify categorical features for CatBoost
    categorical_features = ['street_name', 'violation_description']
    for col in combined_df.columns:
        if combined_df[col].dtype == 'object' or combined_df[col].dtype == 'category':
            if col not in categorical_features:
                categorical_features.append(col)
    
    categorical_features = [col for col in categorical_features if col in train_processed_df.columns]
    # print(f"Categorical features identified for CatBoost: {categorical_features}")

    # Ensure all categorical columns are of 'category' dtype for CatBoost AND handle NaNs
    # Ablation point: No explicit astype('category') for core features
    if not no_explicit_category_conversion:
        for col in categorical_features:
            if col in train_processed_df.columns:
                train_processed_df[col] = train_processed_df[col].fillna('Unknown_Category').astype('category')
    else:
        print("Ablation: Skipping explicit astype('category') for categorical features. Columns will remain 'object' dtype (strings) where applicable.")
        for col in categorical_features:
            if col in train_processed_df.columns:
                # For object columns, fillna with a string placeholder. CatBoost handles object dtypes as categorical if specified.
                if train_processed_df[col].dtype == 'object':
                    train_processed_df[col] = train_processed_df[col].fillna('Unknown_Category')
                # If a column became 'category' (e.g., from downcast_dtypes or other earlier steps), ensure its NaNs are filled correctly within the category type.
                elif train_processed_df[col].dtype == 'category':
                    if 'Unknown_Category' not in train_processed_df[col].cat.categories:
                        train_processed_df[col] = train_processed_df[col].cat.add_categories('Unknown_Category')
                    train_processed_df[col] = train_processed_df[col].fillna('Unknown_Category')

    return train_processed_df, None, categorical_features # Return None for test_df in ablation study

def train_and_predict_ablated(train_df, categorical_features):
    """
    Trains a CatBoost Regressor model and reports RMSE for validation.
    """
    print("--- Training CatBoost model for ablation ---")

    features = [col for col in train_df.columns if col not in ['violation_count']] # No 'is_pure_prediction' in train_df
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    # print(f"Training data split: X_train={X_train.shape}, X_val={X_val.shape}")

    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6,
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Suppress verbose output for ablation runs
        early_stopping_rounds=50,
    )

    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]
    # print(f"Categorical feature indices for CatBoost: {cat_features_indices}")

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        raise

    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    return val_rmse

def run_ablation_study(train_path):
    results = {}

    # Base Case
    print("\n##### Running Base Case #####")
    train_df_base, _, categorical_features_base = load_and_preprocess_data_ablated(train_path)
    base_rmse = train_and_predict_ablated(train_df_base, categorical_features_base)
    results['Base Case'] = base_rmse
    print(f"Base Case Validation RMSE: {base_rmse:.4f}\n")

    # Ablation 1: No Street Data Augmentation
    print("\n##### Running Ablation: No Street Data Augmentation #####")
    train_df_ablation1, _, categorical_features_ablation1 = load_and_preprocess_data_ablated(
        train_path, no_street_data_augmentation=True
    )
    rmse_ablation1 = train_and_predict_ablated(train_df_ablation1, categorical_features_ablation1)
    results['No Street Data Augmentation'] = rmse_ablation1
    print(f"No Street Data Augmentation Validation RMSE: {rmse_ablation1:.4f}\n")

    # Ablation 2: No Census Data Augmentation
    # For this ablation, we assume street data *is* loaded for borough information to be available for merge,
    # otherwise census data merge wouldn't happen anyway due to 'borough' dependency in the base code logic.
    print("\n##### Running Ablation: No Census Data Augmentation #####")
    train_df_ablation2, _, categorical_features_ablation2 = load_and_preprocess_data_ablated(
        train_path, no_census_data_augmentation=True
    )
    rmse_ablation2 = train_and_predict_ablated(train_df_ablation2, categorical_features_ablation2)
    results['No Census Data Augmentation'] = rmse_ablation2
    print(f"No Census Data Augmentation Validation RMSE: {rmse_ablation2:.4f}\n")

    # Ablation 3: No Explicit astype('category') for core categorical features
    print("\n##### Running Ablation: No Explicit astype('category') for Core Categorical Features #####")
    train_df_ablation3, _, categorical_features_ablation3 = load_and_preprocess_data_ablated(
        train_path, no_explicit_category_conversion=True
    )
    rmse_ablation3 = train_and_predict_ablated(train_df_ablation3, categorical_features_ablation3)
    results['No Explicit astype(\'category\')'] = rmse_ablation3
    print(f"No Explicit astype('category') Validation RMSE: {rmse_ablation3:.4f}\n")

    # Summarize results
    print("\n### Ablation Study Summary ###")
    for name, rmse in results.items():
        delta = rmse - base_rmse
        print(f"- {name}: RMSE = {rmse:.4f} (Delta from Base: {delta:+.4f})")

    # Determine the most contributing part (most negative delta or most positive delta if that means it was detrimental)
    best_improvement = 0.0
    worst_degradation = 0.0
    most_beneficial_component = "None (No significant improvement)"
    most_detrimental_component = "None (No significant degradation)"

    for name, rmse in results.items():
        if name == 'Base Case':
            continue
        delta = rmse - base_rmse
        if delta < best_improvement: # Lower RMSE is better (improvement)
            best_improvement = delta
            most_beneficial_component = name
        if delta > worst_degradation: # Higher RMSE is worse (degradation)
            worst_degradation = delta
            most_detrimental_component = name

    print("\n### Conclusion ###")
    if abs(best_improvement) > abs(worst_degradation): # If improvement is larger in magnitude
        print(f"The most impactful component (in terms of improvement) was '{most_beneficial_component}', which improved RMSE by {-best_improvement:.4f}.")
        print("This means the model performed better when this component was removed, suggesting it was detrimental to the base model's performance.")
    elif abs(worst_degradation) > abs(best_improvement): # If degradation is larger in magnitude
        print(f"The most impactful component (in terms of degradation) was '{most_detrimental_component}', which degraded RMSE by {worst_degradation:.4f}.")
        print("This means the removed component was highly beneficial to the base model's performance.")
    else:
        print("No single component showed a significantly larger impact than others in this ablation study.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Ablation study for NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()

    # Create dummy input files if they don't exist for the ablation study to run without errors
    input_dir = './input'
    os.makedirs(input_dir, exist_ok=True)

    # Dummy train data
    if not os.path.exists(args.train_path):
        print(f"Creating dummy {args.train_path} for ablation study.")
        dummy_train_df = pd.DataFrame({
            'street_name': ['STREET A', 'STREET B', 'STREET A', 'STREET C', 'STREET D', 'STREET E', 'STREET F', 'STREET A'],
            'violation_description': ['PARKING VIOLATION', 'SPEEDING', 'NO STANDING', 'PARKING VIOLATION', 'RED LIGHT', 'NO PARKING', 'BUS LANE VIOLATION', 'SPEEDING'],
            'violation_count': [100, 50, 75, 120, 90, 60, 110, 55]
        })
        dummy_train_df.to_csv(args.train_path, index=False, header=False) # Original code reads without header

    # Dummy nyc_street_data.csv (needed for borough, street_length, num_lanes)
    street_data_path = './input/nyc_street_data.csv'
    if not os.path.exists(street_data_path):
        print(f"Creating dummy {street_data_path}.")
        dummy_street_df = pd.DataFrame({
            'Street Name': ['STREET A', 'STREET B', 'STREET C', 'STREET D', 'STREET E', 'STREET F'],
            'Borough': ['Manhattan', 'Brooklyn', 'Queens', 'Bronx', 'Staten Island', 'Manhattan'],
            'Street Length': [1000, 500, 750, 1200, 800, 900],
            'Number of Lanes': [4, 2, 3, 6, 2, 4]
        })
        dummy_street_df.to_csv(street_data_path, index=False)

    # Dummy nyc_violation_codes.csv (needed for fine_amount, points, violation_category)
    violation_codes_path = './input/nyc_violation_codes.csv'
    if not os.path.exists(violation_codes_path):
        print(f"Creating dummy {violation_codes_path}.")
        dummy_violation_df = pd.DataFrame({
            'Violation Description': ['PARKING VIOLATION', 'SPEEDING', 'NO STANDING', 'RED LIGHT', 'NO PARKING', 'BUS LANE VIOLATION'],
            'Fine Amount': [65, 150, 115, 200, 60, 180],
            'Points': [0, 3, 0, 3, 0, 2]
        })
        dummy_violation_df.to_csv(violation_codes_path, index=False)

    # Dummy nyc_census_data.csv (needed for population_density, avg_income)
    census_data_path = './input/nyc_census_data.csv'
    if not os.path.exists(census_data_path):
        print(f"Creating dummy {census_data_path}.")
        dummy_census_df = pd.DataFrame({
            'Borough': ['Manhattan', 'Brooklyn', 'Queens', 'Bronx', 'Staten Island'],
            'Population Density': [25000, 15000, 10000, 8000, 5000],
            'Avg Income': [100000, 70000, 60000, 50000, 75000]
        })
        dummy_census_df.to_csv(census_data_path, index=False)

    run_ablation_study(args.train_path)

