
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# --- Original Helper function to downcast dtypes for memory efficiency ---
def downcast_dtypes_original(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    # initial_memory = df.memory_usage(deep=True).sum() / (1024**2) # Commented for clean output
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    # final_memory = df.memory_usage(deep=True).sum() / (1024**2) # Commented for clean output
    return df

# --- Modified downcast_dtypes for ablation (no-op) ---
def downcast_dtypes_noop(df):
    """
    A no-operation version of downcast_dtypes for ablation studies.
    """
    return df

def load_and_preprocess_data_flexible(train_path, test_path=None, no_downcasting=False, direct_merge=False):
    """
    Loads, preprocesses, and merges data from various sources, with ablation toggles.
    """
    # print("Loading and preprocessing data...") # Commented for clean output

    downcast_func = downcast_dtypes_noop if no_downcasting else downcast_dtypes_original

    # --- Load Core Data ---
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_func(train_df_raw)

    test_df_raw = None
    if test_path:
        test_df_raw = pd.read_csv(test_path)
        test_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
        test_df_raw['is_pure_prediction'] = test_df_raw['violation_count'].isna()
        test_df_raw = downcast_func(test_df_raw)

    # --- Feature Engineering and Augmentation ---
    if direct_merge:
        # Ablation: Direct merge approach - merge augmentation data directly to train/test_df_raw
        train_processed_df = train_df_raw.copy()
        test_processed_df = test_df_raw.copy() if test_df_raw is not None else None

        all_dfs_to_process = [(train_processed_df, 'train')]
        if test_processed_df is not None:
            all_dfs_to_process.append((test_processed_df, 'test'))

        for df_tuple_idx, (current_df, df_name) in enumerate(all_dfs_to_process):
            # Basic features
            current_df['street_name_len'] = current_df['street_name'].apply(len).astype('int16')
            current_df['violation_desc_len'] = current_df['violation_description'].apply(len).astype('int16')

            # Augmentation 1: nyc_street_data.csv
            street_data_path = './input/nyc_street_data.csv'
            if os.path.exists(street_data_path):
                try:
                    street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
                    street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
                    street_data = downcast_func(street_data)
                    street_data = street_data.drop_duplicates(subset=['street_name'])
                    all_dfs_to_process[df_tuple_idx] = (pd.merge(current_df, street_data, on='street_name', how='left'), df_name)
                    del street_data
                    gc.collect()
                except Exception as e:
                    # print(f"Error loading or merging {street_data_path} in direct merge for {df_name}: {e}. Skipping.") # Commented for clean output
                    pass
            
            # Augmentation 2: nyc_violation_codes.csv
            violation_codes_path = './input/nyc_violation_codes.csv'
            if os.path.exists(violation_codes_path):
                try:
                    violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
                    violation_codes.columns = ['violation_description', 'fine_amount', 'points']
                    violation_codes = downcast_func(violation_codes)
                    violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
                    all_dfs_to_process[df_tuple_idx] = (pd.merge(all_dfs_to_process[df_tuple_idx][0], violation_codes, on='violation_description', how='left'), df_name)
                    del violation_codes
                    gc.collect()
                except Exception as e:
                    # print(f"Error loading or merging {violation_codes_path} in direct merge for {df_name}: {e}. Skipping.") # Commented for clean output
                    pass

            # Augmentation 3: nyc_census_data.csv
            census_data_path = './input/nyc_census_data.csv'
            if os.path.exists(census_data_path):
                if 'borough' in all_dfs_to_process[df_tuple_idx][0].columns:
                    try:
                        census_data = pd.read_csv(census_data_path)
                        census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                        relevant_census_cols = ['borough', 'population_density', 'avg_income']
                        if all(col in census_data.columns for col in relevant_census_cols):
                            census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                            census_agg = downcast_func(census_agg)
                            all_dfs_to_process[df_tuple_idx] = (pd.merge(all_dfs_to_process[df_tuple_idx][0], census_agg, on='borough', how='left'), df_name)
                            del census_data, census_agg
                            gc.collect()
                        # else:
                            # print(f"Warning: Missing one or more expected columns ({relevant_census_cols}) in {census_data_path} in direct merge for {df_name}. Skipping.") # Commented for clean output
                    except Exception as e:
                        # print(f"Error loading or merging {census_data_path} in direct merge for {df_name}: {e}. Skipping.") # Commented for clean output
                        pass
                # else:
                    # print(f"Warning: Borough information not available in direct merge for {df_name} to merge census data. Skipping.") # Commented for clean output
            # else:
                # print(f"Warning: {census_data_path} not found for {df_name}. Skipping census data augmentation.") # Commented for clean output
        
        train_processed_df = all_dfs_to_process[0][0]
        test_processed_df = all_dfs_to_process[1][0] if test_df_raw is not None else None

    else:
        # Original logic: Combined DF approach for feature engineering
        combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
        combined_keys_test = pd.DataFrame()
        if test_df_raw is not None:
            combined_keys_test = test_df_raw[['street_name', 'violation_description']].drop_duplicates()

        combined_df = pd.concat([combined_keys_train, combined_keys_test], ignore_index=True).drop_duplicates().reset_index(drop=True)
        del combined_keys_train, combined_keys_test
        gc.collect()

        combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
        combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

        street_data_path = './input/nyc_street_data.csv'
        if os.path.exists(street_data_path):
            try:
                street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
                street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
                street_data = downcast_func(street_data)
                street_data = street_data.drop_duplicates(subset=['street_name'])
                combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
                del street_data
                gc.collect()
            except Exception as e:
                # print(f"Error loading or merging {street_data_path}: {e}. Skipping street data augmentation.") # Commented for clean output
                pass
        # else:
            # print(f"Warning: {street_data_path} not found. Skipping street data augmentation.") # Commented for clean output

        violation_codes_path = './input/nyc_violation_codes.csv'
        if os.path.exists(violation_codes_path):
            try:
                violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
                violation_codes.columns = ['violation_description', 'fine_amount', 'points']
                violation_codes = downcast_func(violation_codes)
                violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
                combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
                del violation_codes
                gc.collect()
            except Exception as e:
                # print(f"Error loading or merging {violation_codes_path}: {e}. Skipping violation codes augmentation.") # Commented for clean output
                pass
        # else:
            # print(f"Warning: {violation_codes_path} not found. Skipping violation codes augmentation.") # Commented for clean output

        census_data_path = './input/nyc_census_data.csv'
        if os.path.exists(census_data_path):
            if 'borough' in combined_df.columns:
                try:
                    census_data = pd.read_csv(census_data_path)
                    census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                    relevant_census_cols = ['borough', 'population_density', 'avg_income']
                    if all(col in census_data.columns for col in relevant_census_cols):
                        census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                        census_agg = downcast_func(census_agg)
                        combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                        del census_data, census_agg
                        gc.collect()
                    # else:
                        # print(f"Warning: Missing one or more expected columns ({relevant_census_cols}) in {census_data_path}. Skipping census data augmentation.") # Commented for clean output
                except Exception as e:
                    # print(f"Error loading or merging {census_data_path}: {e}. Skipping census data augmentation.") # Commented for clean output
                    pass
            # else:
                # print("Warning: Borough information not available in combined_df to merge census data. Skipping.") # Commented for clean output
        # else:
            # print(f"Warning: {census_data_path} not found. Skipping census data augmentation.") # Commented for clean output

        train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
        del train_df_raw
        gc.collect()

        test_processed_df = None
        if test_df_raw is not None:
            test_processed_df = pd.merge(test_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
            del test_df_raw
            gc.collect()

    # Identify categorical features for CatBoost
    categorical_features = [col for col in train_processed_df.columns if train_processed_df[col].dtype in ['object', 'category']]
    categorical_features = [col for col in categorical_features if col in train_processed_df.columns]

    for col in categorical_features:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].astype('category')
        if test_processed_df is not None and col in test_processed_df.columns:
            test_processed_df[col] = test_processed_df[col].astype('category')
            # Ensure categories are aligned for test set (important if test set were used)
            train_cats = train_processed_df[col].cat.categories
            test_cats = test_processed_df[col].cat.categories
            new_test_cats = test_cats.difference(train_cats)
            if not new_test_cats.empty:
                train_processed_df[col] = train_processed_df[col].cat.add_categories(new_test_cats)
                test_processed_df[col] = test_processed_df[col].cat.set_categories(train_processed_df[col].cat.categories)

    return train_processed_df, test_processed_df, categorical_features

def train_and_predict_flexible(train_df, categorical_features, no_early_stopping=False):
    """
    Trains a CatBoost Regressor model and generates predictions.
    Reports RMSE for validation set. Test_df is ignored for ablation.
    """
    
    features = [col for col in train_df.columns if col not in ['violation_count', 'is_pure_prediction']] # 'is_pure_prediction' for safety
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    model_params = {
        'iterations': 1000,
        'learning_rate': 0.05,
        'depth': 6,
        'l2_leaf_reg': 3,
        'loss_function': 'RMSE',
        'eval_metric': 'RMSE',
        'random_seed': 42,
        'verbose': 0 # Suppress verbose output for clean ablation results
    }

    if not no_early_stopping:
        model_params['early_stopping_rounds'] = 50

    model = CatBoostRegressor(**model_params)

    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        raise

    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    return val_rmse

def run_ablation_experiment(description, train_path, modifications):
    print(f"\n--- Running Ablation: {description} ---")
    train_df, _, categorical_features = load_and_preprocess_data_flexible(
        train_path,
        test_path=None, # Explicitly no test data for ablation
        no_downcasting=modifications.get('no_downcasting', False),
        direct_merge=modifications.get('direct_merge', False)
    )
    
    val_rmse = train_and_predict_flexible(
        train_df,
        categorical_features,
        no_early_stopping=modifications.get('no_early_stopping', False)
    )
    print(f"Validation RMSE for '{description}': {val_rmse}")
    return val_rmse

# Main ablation study execution
def main_ablation():
    train_path = './input/violations_per_street_2022.csv'
    
    # --- Base Case ---
    base_rmse = run_ablation_experiment("Base Case (Original Setup)", train_path, {})
    
    results = {"Base Case": base_rmse}

    # --- Ablation 1: Remove downcast_dtypes function entirely ---
    abl_1_rmse = run_ablation_experiment(
        "Ablation 1: No downcast_dtypes",
        train_path,
        {'no_downcasting': True}
    )
    results["Ablation 1: No downcast_dtypes"] = abl_1_rmse

    # --- Ablation 2: Remove combined_df creation and directly merge augmentation data ---
    abl_2_rmse = run_ablation_experiment(
        "Ablation 2: Direct merge of augmentation data",
        train_path,
        {'direct_merge': True}
    )
    results["Ablation 2: Direct merge of augmentation data"] = abl_2_rmse

    # --- Ablation 3: Remove early_stopping_rounds from CatBoost parameters ---
    abl_3_rmse = run_ablation_experiment(
        "Ablation 3: No early_stopping_rounds",
        train_path,
        {'no_early_stopping': True}
    )
    results["Ablation 3: No early_stopping_rounds"] = abl_3_rmse

    print("\n--- Ablation Study Summary ---")
    
    performance_deltas = {}
    for name, rmse in results.items():
        if name != "Base Case":
            delta = rmse - base_rmse
            performance_deltas[name] = delta
            print(f"- {name}: RMSE = {rmse:.4f}, Delta from Base = {delta:+.4f}")
        else:
            print(f"- {name}: RMSE = {rmse:.4f}")

    if performance_deltas:
        # Find the most impactful change (largest absolute delta)
        most_impactful_change = max(performance_deltas, key=lambda k: abs(performance_deltas[k]))
        impact_value = performance_deltas[most_impactful_change]
        
        print(f"\nConclusion: The most contributing part to the overall performance (based on largest absolute RMSE delta) is '{most_impactful_change}'.")
        if impact_value > 0:
            print(f"Its removal/modification led to a degradation in performance (RMSE increased by {impact_value:+.4f}).")
        else:
            print(f"Its removal/modification led to an improvement in performance (RMSE decreased by {abs(impact_value):.4f}).")
    else:
        print("No ablation experiments were run.")

if __name__ == "__main__":
    # Create dummy input files if they don't exist, to ensure the script can run
    if not os.path.exists('./input'):
        os.makedirs('./input')
    
    # violations_per_street_2022.csv (train_path)
    if not os.path.exists('./input/violations_per_street_2022.csv'):
        dummy_train_data = {
            'Street Name': ['MAIN ST', 'OAK AVE', 'MAIN ST', 'ELM ST', 'OAK AVE', 'MAIN ST', 'ELM ST', 'MAPLE DR', 'ELM ST', 'MAIN ST'] * 100,
            'Violation Description': ['PARKING METER', 'NO PARKING', 'SPEEDING', 'PARKING METER', 'RED LIGHT', 'NO STANDING', 'PARKING METER', 'NO PARKING', 'SPEEDING', 'RED LIGHT'] * 100,
            'violation_count': [100, 50, 200, 120, 80, 70, 150, 60, 180, 90] * 100
        }
        pd.DataFrame(dummy_train_data).to_csv('./input/violations_per_street_2022.csv', index=False)
    
    # nyc_street_data.csv
    if not os.path.exists('./input/nyc_street_data.csv'):
        dummy_street_data = {
            'Street Name': ['MAIN ST', 'OAK AVE', 'ELM ST', 'MAPLE DR', 'PINE RD', 'CEDAR LN', 'BIRCH BLVD', 'WILLOW WY'],
            'Borough': ['MANHATTAN', 'QUEENS', 'BRONX', 'BROOKLYN', 'MANHATTAN', 'QUEENS', 'BRONX', 'BROOKLYN'],
            'Street Length': [5000, 3000, 4000, 2500, 6000, 3500, 4500, 2800],
            'Number of Lanes': [4, 2, 3, 2, 4, 2, 3, 2]
        }
        pd.DataFrame(dummy_street_data).to_csv('./input/nyc_street_data.csv', index=False)

    # nyc_violation_codes.csv
    if not os.path.exists('./input/nyc_violation_codes.csv'):
        dummy_violation_codes = {
            'Violation Description': ['PARKING METER', 'NO PARKING', 'SPEEDING', 'RED LIGHT', 'NO STANDING', 'FIRE HYDRANT', 'DOUBLE PARKING', 'BUS LANE VIOLATION'],
            'Fine Amount': [65, 50, 150, 115, 60, 180, 100, 115],
            'Points': [0, 0, 3, 2, 0, 0, 0, 2]
        }
        pd.DataFrame(dummy_violation_codes).to_csv('./input/nyc_violation_codes.csv', index=False)

    # nyc_census_data.csv
    if not os.path.exists('./input/nyc_census_data.csv'):
        dummy_census_data = {
            'Borough': ['MANHATTAN', 'QUEENS', 'BRONX', 'BROOKLYN', 'STATEN ISLAND'],
            'Population Density': [27000, 8000, 14000, 15000, 3500],
            'Avg Income': [120000, 75000, 60000, 85000, 90000]
        }
        pd.DataFrame(dummy_census_data).to_csv('./input/nyc_census_data.csv', index=False)

    main_ablation()
