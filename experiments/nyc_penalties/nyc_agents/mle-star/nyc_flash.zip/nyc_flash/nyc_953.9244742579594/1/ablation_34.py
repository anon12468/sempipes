

import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    return df

def load_and_preprocess_data_ablation(train_path, test_path=None, ablation_params=None):
    """
    Loads, preprocesses, and merges data from various sources.
    Handles memory efficiency by selective column loading, aggregation, and garbage collection.
    Ablation params can modify feature creation.
    """
    if ablation_params is None:
        ablation_params = {}

    # print("Loading and preprocessing data...") # Commented out for cleaner ablation output

    # --- Load Core Data ---
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)
    # print(f"Initial train_df loaded. Shape: {train_df_raw.shape}") # Commented out

    test_df_raw = None
    if test_path:
        test_df_raw = pd.read_csv(test_path)
        test_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
        test_df_raw['is_pure_prediction'] = test_df_raw['violation_count'].isna()
        test_df_raw = downcast_dtypes(test_df_raw)
        # print(f"Test_df loaded. Shape: {test_df_raw.shape}") # Commented out

    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_keys_test = pd.DataFrame()
    if test_df_raw is not None:
        combined_keys_test = test_df_raw[['street_name', 'violation_description']].drop_duplicates()

    combined_df = pd.concat([combined_keys_train, combined_keys_test], ignore_index=True).drop_duplicates().reset_index(drop=True)
    del combined_keys_train, combined_keys_test
    gc.collect()
    # print(f"Combined unique (street, violation) pairs for feature engineering. Shape: {combined_df.shape}") # Commented out

    # --- Feature Engineering and Augmentation ---

    # Basic features from core data
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # Enhanced features for 'street_name'
    combined_df['street_name_word_count'] = combined_df['street_name'].apply(
        lambda x: len(str(x).split())
    ).astype('int16')

    # Binary indicator for common street type abbreviations
    if not ablation_params.get('no_street_type_abbr_present', False):
        common_street_suffixes = [
            'ST', 'AVE', 'RD', 'BLVD', 'DR', 'LN', 'CT', 'PL', 'WY', 'CIR', 'HWY', 'TER',
            'GRN', 'PKY', 'SQ', 'TRCE', 'CR', 'WAY', 'PZ', 'PLZ', 'AVENUE', 'STREET',
            'ROAD', 'BOULEVARD', 'DRIVE', 'LANE', 'COURT', 'PLACE', 'CIRCLE', 'HIGHWAY',
            'TERRACE', 'GREEN', 'PARKWAY', 'SQUARE', 'TRACE', 'CRESCENT', 'PLAZA'
        ]
        combined_df['street_type_abbr_present'] = combined_df['street_name'].apply(
            lambda x: any(word in common_street_suffixes for word in str(x).upper().split())
        ).astype('int8')

    # Enhanced features for 'violation_description'
    combined_df['violation_desc_unique_word_count'] = combined_df['violation_description'].apply(
        lambda x: len(set(str(x).lower().split()))
    ).astype('int16')

    # Total number of numerical digits in violation_description
    if not ablation_params.get('no_violation_desc_digit_count', False):
        combined_df['violation_desc_digit_count'] = combined_df['violation_description'].apply(
            lambda x: sum(c.isdigit() for c in str(x))
        ).astype('int16')


    # Augmentation 1: nyc_street_data.csv
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
        except Exception as e:
            # print(f"Error loading or merging {street_data_path}: {e}. Skipping street data augmentation.")
            pass # Suppress warning for ablation study
    # else: print(f"Warning: {street_data_path} not found. Skipping street data augmentation.") # Suppress warning

    # Augmentation 2: nyc_violation_codes.csv
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
        except Exception as e:
            # print(f"Error loading or merging {violation_codes_path}: {e}. Skipping violation codes augmentation.")
            pass # Suppress warning for ablation study
    # else: print(f"Warning: {violation_codes_path} not found. Skipping violation codes augmentation.") # Suppress warning

    # Augmentation 3: nyc_census_data.csv (Hypothetical)
    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        if 'borough' in combined_df.columns:
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
                # else: print(f"Warning: Missing one or more expected columns ({relevant_census_cols}) in {census_data_path}. Skipping census data augmentation.") # Suppress warning
            except Exception as e:
                # print(f"Error loading or merging {census_data_path}: {e}. Skipping census data augmentation.")
                pass # Suppress warning for ablation study
        # else: print("Warning: Borough information not available in combined_df to merge census data. Skipping.") # Suppress warning
    # else: print(f"Warning: {census_data_path} not found. Skipping census data augmentation.") # Suppress warning


    # Split back into train and test processed dataframes
    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    test_processed_df = None
    if test_df_raw is not None:
        test_processed_df = pd.merge(test_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
        del test_df_raw
        gc.collect()

    # Identify categorical features for CatBoost
    categorical_features = [col for col in combined_df.columns if combined_df[col].dtype in ['object', 'category']]
    categorical_features = [col for col in categorical_features if col in train_processed_df.columns]

    # Ensure all categorical columns are of 'category' dtype for CatBoost
    for col in categorical_features:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].astype('category')
        if test_processed_df is not None and col in test_processed_df.columns:
            test_processed_df[col] = test_processed_df[col].astype('category')

    return train_processed_df, test_processed_df, categorical_features

def train_and_predict_ablation(train_df, test_df, categorical_features, ablation_params=None):
    """
    Trains a CatBoost Regressor model and generates predictions.
    Reports RMSE for validation and test sets (if ground truth available).
    Ablation params can modify CatBoost hyperparameters.
    """
    if ablation_params is None:
        ablation_params = {}

    # print("Training CatBoost model...") # Commented out

    features = [col for col in train_df.columns if col not in ['violation_count']]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6,
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric=ablation_params.get('eval_metric', 'RMSE'), # Ablation point for eval_metric
        random_seed=42,
        verbose=0, # Set verbose to 0 for cleaner ablation output
        early_stopping_rounds=50,
    )

    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        raise

    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    
    submission_df = None # Not generating submission for ablation
    return submission_df, val_rmse

def run_ablation_study(train_path):
    print("Starting ablation study...")

    results = {}

    # --- Base Case ---
    print("\n--- Running Base Case ---")
    train_df, _, categorical_features = load_and_preprocess_data_ablation(train_path, test_path=None, ablation_params={})
    _, base_rmse = train_and_predict_ablation(train_df, None, categorical_features, ablation_params={})
    results['Base Case'] = base_rmse
    print(f"Base Case Validation RMSE: {base_rmse:.4f}")

    # --- Ablation 1: No 'street_type_abbr_present' feature ---
    print("\n--- Running Ablation 1: No 'street_type_abbr_present' feature ---")
    ablation_params_1 = {'no_street_type_abbr_present': True}
    train_df_1, _, categorical_features_1 = load_and_preprocess_data_ablation(train_path, test_path=None, ablation_params=ablation_params_1)
    _, rmse_1 = train_and_predict_ablation(train_df_1, None, categorical_features_1, ablation_params={})
    results['Ablation 1: No street_type_abbr_present'] = rmse_1
    print(f"Ablation 1 (No street_type_abbr_present) Validation RMSE: {rmse_1:.4f} (Delta: {rmse_1 - base_rmse:.4f})")

    # --- Ablation 2: No 'violation_desc_digit_count' feature ---
    print("\n--- Running Ablation 2: No 'violation_desc_digit_count' feature ---")
    ablation_params_2 = {'no_violation_desc_digit_count': True}
    train_df_2, _, categorical_features_2 = load_and_preprocess_data_ablation(train_path, test_path=None, ablation_params=ablation_params_2)
    _, rmse_2 = train_and_predict_ablation(train_df_2, None, categorical_features_2, ablation_params={})
    results['Ablation 2: No violation_desc_digit_count'] = rmse_2
    print(f"Ablation 2 (No violation_desc_digit_count) Validation RMSE: {rmse_2:.4f} (Delta: {rmse_2 - base_rmse:.4f})")

    # --- Ablation 3: Change CatBoost eval_metric from 'RMSE' to 'MAE' ---
    print("\n--- Running Ablation 3: CatBoost eval_metric='MAE' ---")
    ablation_params_3 = {'eval_metric': 'MAE'}
    # For this ablation, features are the same as base case, only model params change
    train_df_3, _, categorical_features_3 = load_and_preprocess_data_ablation(train_path, test_path=None, ablation_params={})
    _, rmse_3 = train_and_predict_ablation(train_df_3, None, categorical_features_3, ablation_params=ablation_params_3)
    results['Ablation 3: CatBoost eval_metric=MAE'] = rmse_3
    print(f"Ablation 3 (CatBoost eval_metric=MAE) Validation RMSE: {rmse_3:.4f} (Delta: {rmse_3 - base_rmse:.4f})")


    print("\n--- Ablation Study Summary ---")
    for name, rmse in results.items():
        print(f"{name}: RMSE = {rmse:.4f} (Delta from Base: {rmse - base_rmse:.4f})")

    # Determine the most contributing part (largest absolute change from base)
    most_impactful_change = "Base Case"
    max_delta = 0.0
    is_beneficial = True # Flag to track if the change improved or worsened performance

    for name, rmse in results.items():
        if name == 'Base Case':
            continue
        delta_val = rmse - base_rmse
        abs_delta = abs(delta_val)
        
        if abs_delta > max_delta:
            max_delta = abs_delta
            most_impactful_change = name
            is_beneficial = (delta_val < 0) # If delta < 0, RMSE decreased, so it's beneficial

    if most_impactful_change == "Base Case":
        print("\nConclusion: All ablations had negligible impact or no single most contributing part was identified.")
    else:
        impact_description = "beneficial" if is_beneficial else "detrimental"
        print(f"\nConclusion: The most contributing part to the overall performance is: {most_impactful_change}, which was found to be {impact_description}.")


if __name__ == "__main__":
    # Create dummy files for external data if they don't exist
    input_dir = './input'
    os.makedirs(input_dir, exist_ok=True)

    dummy_train_path = os.path.join(input_dir, 'violations_per_street_2022.csv')
    if not os.path.exists(dummy_train_path):
        dummy_train_data = {
            'Street Name': ['MAIN ST', 'OAK AVE', 'ELM RD', 'MAIN ST', 'PINE LN', 'BIRCH CIR', 'MAIN ST', '123 MAIN', '4TH AVE', 'NO DIGITS'],
            'Violation Description': ['PARKING IN NO STANDING ZONE', 'EXPIRED METER', 'DOUBLE PARKING', 'SPEEDING', 'RED LIGHT VIOLATION 123', 'NO PARKING', 'PARKING IN NO STANDING ZONE 45', 'HYDRANT 678', 'TIME LIMIT 90', 'NO DIGITAL INFO HERE'],
            'Violation Count': [100, 50, 120, 30, 80, 60, 110, 75, 95, 40]
        }
        pd.DataFrame(dummy_train_data).to_csv(dummy_train_path, index=False)

    dummy_street_data_path = os.path.join(input_dir, 'nyc_street_data.csv')
    if not os.path.exists(dummy_street_data_path):
        dummy_street_data = {
            'Street Name': ['MAIN ST', 'OAK AVE', 'ELM RD', 'PINE LN', 'BIRCH CIR', '123 MAIN', '4TH AVE', 'NO DIGITS'],
            'Borough': ['MANHATTAN', 'BROOKLYN', 'QUEENS', 'BRONX', 'STATEN ISLAND', 'MANHATTAN', 'BROOKLYN', 'QUEENS'],
            'Street Length': [1000, 500, 800, 300, 400, 600, 700, 200],
            'Number of Lanes': [4, 2, 3, 2, 2, 4, 3, 1]
        }
        pd.DataFrame(dummy_street_data).to_csv(dummy_street_data_path, index=False)

    dummy_violation_codes_path = os.path.join(input_dir, 'nyc_violation_codes.csv')
    if not os.path.exists(dummy_violation_codes_path):
        dummy_violation_codes = {
            'Violation Description': ['PARKING IN NO STANDING ZONE', 'EXPIRED METER', 'DOUBLE PARKING', 'SPEEDING', 'RED LIGHT VIOLATION 123', 'NO PARKING', 'PARKING IN NO STANDING ZONE 45', 'HYDRANT 678', 'TIME LIMIT 90', 'NO DIGITAL INFO HERE'],
            'Fine Amount': [115, 65, 125, 150, 180, 80, 115, 200, 90, 70],
            'Points': [0, 0, 0, 3, 3, 0, 0, 0, 0, 0]
        }
        pd.DataFrame(dummy_violation_codes).to_csv(dummy_violation_codes_path, index=False)

    dummy_census_data_path = os.path.join(input_dir, 'nyc_census_data.csv')
    if not os.path.exists(dummy_census_data_path):
        dummy_census_data = {
            'Borough': ['MANHATTAN', 'BROOKLYN', 'QUEENS', 'BRONX', 'STATEN ISLAND'],
            'Population Density': [27000, 15000, 9000, 12000, 8000],
            'Avg Income': [100000, 70000, 80000, 60000, 90000]
        }
        pd.DataFrame(dummy_census_data).to_csv(dummy_census_data_path, index=False)


    run_ablation_study(dummy_train_path)
