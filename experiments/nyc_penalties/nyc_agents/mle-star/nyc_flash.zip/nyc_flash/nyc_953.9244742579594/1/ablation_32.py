
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
from sklearn.preprocessing import LabelEncoder
from sklearn.feature_selection import mutual_info_regression
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    return df

def load_and_preprocess_data(train_path):
    """
    Loads, preprocesses, and merges data from various sources.
    Handles memory efficiency by selective column loading, aggregation, and garbage collection.
    Simplified for ablation study (no test data processing).
    """
    # --- Load Core Data ---
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)

    # Combine unique street_name and violation_description pairs from train
    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_df = combined_keys_train.reset_index(drop=True)
    del combined_keys_train
    gc.collect()

    # --- Feature Engineering and Augmentation ---

    # Basic features from core data
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # Augmentation 1: nyc_street_data.csv
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
        except Exception as e:
            pass # Suppress error prints for clean ablation output

    # Augmentation 2: nyc_violation_codes.csv
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
        except Exception as e:
            pass # Suppress error prints for clean ablation output

    # Augmentation 3: nyc_census_data.csv (Hypothetical)
    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        if 'borough' in combined_df.columns:
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
            except Exception as e:
                pass # Suppress error prints for clean ablation output

    # Merge engineered features back to the raw training dataframe
    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    # Identify categorical features for CatBoost
    categorical_features = [col for col in combined_df.columns if combined_df[col].dtype in ['object', 'category']]
    categorical_features = [col for col in categorical_features if col in train_processed_df.columns]

    # Ensure all categorical columns are of 'category' dtype for CatBoost
    for col in categorical_features:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].astype('category')

    return train_processed_df, categorical_features

def train_and_evaluate(train_df, categorical_features, enable_mi_selection=True, mi_threshold=0.01, min_data_in_leaf=1):
    """
    Trains a CatBoost Regressor model and evaluates performance on a validation set.
    """
    target = 'violation_count'
    all_potential_features = [col for col in train_df.columns if col not in [target]]

    features = all_potential_features # Default to all features

    if enable_mi_selection:
        temp_df_for_mi = train_df[all_potential_features].copy()

        categorical_features_for_encoding = temp_df_for_mi.select_dtypes(include=['object', 'category']).columns.tolist()

        if categorical_features_for_encoding:
            for col in categorical_features_for_encoding:
                temp_df_for_mi[col] = temp_df_for_mi[col].astype(str).fillna('__MISSING__')
                le = LabelEncoder()
                temp_df_for_mi[col] = le.fit_transform(temp_df_for_mi[col])
        
        for col in temp_df_for_mi.select_dtypes(include=['number']).columns:
            if temp_df_for_mi[col].isnull().any():
                temp_df_for_mi[col] = temp_df_for_mi[col].fillna(temp_df_for_mi[col].median())

        y_for_mi = train_df[target].copy()
        if y_for_mi.isnull().any():
            y_for_mi = y_for_mi.fillna(y_for_mi.median())

        if not temp_df_for_mi.empty and not y_for_mi.empty and len(temp_df_for_mi.columns) > 0:
            mi_scores = mutual_info_regression(temp_df_for_mi, y_for_mi, random_state=42)
            mi_series = pd.Series(mi_scores, index=temp_df_for_mi.columns)
            selected_features = mi_series[mi_series > mi_threshold].index.tolist()
            if selected_features:
                features = selected_features
            # else: Fallback to all_potential_features as defined by default 'features' earlier

    X = train_df[features]
    y = train_df[target]

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6,
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Suppress verbose output for ablation study
        early_stopping_rounds=50,
        min_data_in_leaf=min_data_in_leaf
    )

    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                  early_stopping_rounds=50,
                  verbose=False
                 )
    except Exception as e:
        # Re-raise for debugging purposes if an error occurs
        raise

    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))

    return val_rmse

def main_ablation():
    """
    Main function to orchestrate the ablation study.
    """
    train_path = './input/violations_per_street_2022.csv'
    results = {}

    # --- Base Case ---
    print("Running Base Case (with MI selection, default CatBoost, mi_threshold=0.01, min_data_in_leaf=1)...")
    train_df_base, cat_features_base = load_and_preprocess_data(train_path)
    base_rmse = train_and_evaluate(train_df_base.copy(), cat_features_base, enable_mi_selection=True, mi_threshold=0.01, min_data_in_leaf=1)
    results['Base Case'] = base_rmse
    print(f"Base Case RMSE: {base_rmse:.4f}")
    gc.collect() # Clean up memory

    # --- Ablation 1: No Mutual Information (MI) based Feature Selection ---
    print("\nRunning Ablation 1: No Mutual Information (MI) based Feature Selection (using all potential features)...")
    train_df_ablation1, cat_features_ablation1 = load_and_preprocess_data(train_path) # Reload data
    rmse_ablation1 = train_and_evaluate(train_df_ablation1.copy(), cat_features_ablation1, enable_mi_selection=False, mi_threshold=0.01, min_data_in_leaf=1)
    results['No MI Feature Selection'] = rmse_ablation1
    print(f"Ablation 1 (No MI Feature Selection) RMSE: {rmse_ablation1:.4f} (Delta from Base: {rmse_ablation1 - base_rmse:+.4f})")
    gc.collect()

    # --- Ablation 2: CatBoost min_data_in_leaf = 20 ---
    print("\nRunning Ablation 2: CatBoost min_data_in_leaf = 20 (default is 1)...")
    train_df_ablation2, cat_features_ablation2 = load_and_preprocess_data(train_path) # Reload data
    rmse_ablation2 = train_and_evaluate(train_df_ablation2.copy(), cat_features_ablation2, enable_mi_selection=True, mi_threshold=0.01, min_data_in_leaf=20)
    results['CatBoost min_data_in_leaf = 20'] = rmse_ablation2
    print(f"Ablation 2 (CatBoost min_data_in_leaf = 20) RMSE: {rmse_ablation2:.4f} (Delta from Base: {rmse_ablation2 - base_rmse:+.4f})")
    gc.collect()

    # --- Ablation 3: Increased Mutual Information mi_threshold = 0.05 ---
    print("\nRunning Ablation 3: Increased Mutual Information mi_threshold = 0.05 (default is 0.01)...")
    train_df_ablation3, cat_features_ablation3 = load_and_preprocess_data(train_path) # Reload data
    rmse_ablation3 = train_and_evaluate(train_df_ablation3.copy(), cat_features_ablation3, enable_mi_selection=True, mi_threshold=0.05, min_data_in_leaf=1)
    results['Increased MI mi_threshold = 0.05'] = rmse_ablation3
    print(f"Ablation 3 (Increased MI mi_threshold = 0.05) RMSE: {rmse_ablation3:.4f} (Delta from Base: {rmse_ablation3 - base_rmse:+.4f})")
    gc.collect()

    # --- Conclusion ---
    print("\n--- Ablation Study Results ---")
    for name, rmse in results.items():
        if name != 'Base Case':
            print(f"{name}: {rmse:.4f} (Delta from Base: {rmse - base_rmse:+.4f})")

    largest_abs_delta = 0
    most_impactful_change_desc = ""
    most_contributing_part_summary = ""

    for name, rmse in results.items():
        if name == 'Base Case':
            continue
        delta = rmse - base_rmse
        if abs(delta) > largest_abs_delta:
            largest_abs_delta = abs(delta)
            most_impactful_change_desc = name
            if delta < 0: # Improvement means original state was detrimental
                most_contributing_part_summary = f"The original '{name}' was detrimental (its modification/removal improved RMSE by {-delta:.4f})."
            else: # Degradation means original state was beneficial
                most_contributing_part_summary = f"The original '{name}' was beneficial (its modification/removal worsened RMSE by {delta:.4f})."

    if most_impactful_change_desc:
        print(f"\nConclusion: The most impactful change in this ablation study was '{most_impactful_change_desc}'. {most_contributing_part_summary}")
    else:
        print("\nConclusion: No significant impact observed from any ablation compared to the Base Case.")


if __name__ == "__main__":
    # Create dummy input files if they don't exist, to ensure the script runs.
    input_dir = './input'
    os.makedirs(input_dir, exist_ok=True)

    dummy_train_path = os.path.join(input_dir, 'violations_per_street_2022.csv')
    if not os.path.exists(dummy_train_path):
        dummy_data = {
            'street_name': ['BROADWAY', 'MAIN ST', 'ELM ST', 'BROADWAY', 'OAK AVE', 'MAIN ST', 'PINE ST'],
            'violation_description': ['PARKING METER EXPIRED', 'NO STANDING', 'STOP SIGN VIOLATION', 'NO PARKING', 'SPEEDING', 'PARKING METER EXPIRED', 'NO U-TURN'],
            'violation_count': [100, 50, 20, 120, 10, 60, 15]
        }
        pd.DataFrame(dummy_data).to_csv(dummy_train_path, index=False)
        # print(f"Created dummy training data at {dummy_train_path}")
    
    dummy_street_data_path = os.path.join(input_dir, 'nyc_street_data.csv')
    if not os.path.exists(dummy_street_data_path):
        dummy_street_data = {
            'Street Name': ['BROADWAY', 'MAIN ST', 'ELM ST', 'OAK AVE', 'PINE ST'],
            'Borough': ['Manhattan', 'Brooklyn', 'Queens', 'Bronx', 'Manhattan'],
            'Street Length': [5000, 3000, 1500, 800, 1200],
            'Number of Lanes': [6, 4, 2, 2, 3]
        }
        pd.DataFrame(dummy_street_data).to_csv(dummy_street_data_path, index=False)
        # print(f"Created dummy street data at {dummy_street_data_path}")

    dummy_violation_codes_path = os.path.join(input_dir, 'nyc_violation_codes.csv')
    if not os.path.exists(dummy_violation_codes_path):
        dummy_violation_codes = {
            'Violation Description': ['PARKING METER EXPIRED', 'NO STANDING', 'STOP SIGN VIOLATION', 'NO PARKING', 'SPEEDING', 'NO U-TURN'],
            'Fine Amount': [65, 115, 50, 65, 150, 75],
            'Points': [0, 0, 3, 0, 4, 0]
        }
        pd.DataFrame(dummy_violation_codes).to_csv(dummy_violation_codes_path, index=False)
        # print(f"Created dummy violation codes data at {dummy_violation_codes_path}")

    dummy_census_data_path = os.path.join(input_dir, 'nyc_census_data.csv')
    if not os.path.exists(dummy_census_data_path):
        dummy_census_data = {
            'Borough': ['Manhattan', 'Brooklyn', 'Queens', 'Bronx', 'Staten Island'],
            'Population Density': [27000, 15000, 8000, 10000, 5000],
            'Avg Income': [100000, 70000, 60000, 55000, 75000]
        }
        pd.DataFrame(dummy_census_data).to_csv(dummy_census_data_path, index=False)
        # print(f"Created dummy census data at {dummy_census_data_path}")
        
    main_ablation()
