
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os
import logging
import sys

# Configure logging to output to stdout
# Suppress general INFO messages from the main script for cleaner ablation output
# Only warnings and errors will be shown by default from helper functions during ablation runs.
logging.basicConfig(level=logging.WARNING, stream=sys.stdout, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Helper Functions (adapted from original train.py) ---
def calculate_rmse(y_true, y_pred):
    """Calculates the Root Mean Squared Error."""
    return np.sqrt(mean_squared_error(y_true, y_pred))

def load_data(filepath, default_violations_column=True):
    """
    Loads a CSV file into a pandas DataFrame, standardizing column names.
    Handles potential FileNotFoundError and general exceptions.
    """
    try:
        df = pd.read_csv(filepath)
        # Standardize column names: lowercase, replace spaces with underscores, strip whitespace
        df.columns = [col.strip().replace(' ', '_').lower() for col in df.columns]

        if default_violations_column and 'violation_count' not in df.columns:
            logging.warning(f"'{filepath}' is expected to contain 'violation_count' but it's missing. "
                            f"Proceeding assuming it's a test file for prediction or target is optional.")

        # Ensure consistent naming for key columns used throughout the pipeline
        df = df.rename(columns={
            'street_name': 'street_name',
            'violation_description': 'violation_type'
        })
        return df
    except FileNotFoundError:
        logging.error(f"Error: File not found at {filepath}")
        return None
    except Exception as e:
        logging.error(f"Error loading data from {filepath}: {e}")
        return None

def augment_data(df, input_dir="./input", disable_street_violation_pair=False, disable_frequency_encoding=False):
    """
    Augments the DataFrame with additional features from other datasets found in input_dir.
    This function explicitly handles missing augmentation files and performs feature engineering
    that does not leak future information.
    Ablation specific parameters: disable_street_violation_pair, disable_frequency_encoding.
    """
    # Load and merge street attributes
    street_attributes_path = os.path.join(input_dir, "street_attributes.csv")
    if os.path.exists(street_attributes_path):
        street_attributes_df = load_data(street_attributes_path, default_violations_column=False)
        if street_attributes_df is not None:
            street_attributes_df.columns = [col.strip().replace(' ', '_').lower() for col in street_attributes_df.columns]
            street_attributes_df = street_attributes_df.rename(columns={'street_name': 'street_name'})
            street_attributes_df = street_attributes_df.drop_duplicates(subset=['street_name'])
            df = pd.merge(df, street_attributes_df, on='street_name', how='left')
        else:
            logging.warning(f"Could not load street_attributes.csv from {street_attributes_path}")
    else:
        logging.warning(f"street_attributes.csv not found at {street_attributes_path}. Skipping merge.")

    # Load and merge violation type severity
    violation_severity_path = os.path.join(input_dir, "violation_type_severity.csv")
    if os.path.exists(violation_severity_path):
        violation_severity_df = load_data(violation_severity_path, default_violations_column=False)
        if violation_severity_df is not None:
            violation_severity_df.columns = [col.strip().replace(' ', '_').lower() for col in violation_severity_df.columns]
            violation_severity_df = violation_severity_df.rename(columns={'violation_description': 'violation_type'})
            violation_severity_df = violation_severity_df.drop_duplicates(subset=['violation_type'])
            df = pd.merge(df, violation_severity_df, on='violation_type', how='left')
        else:
            logging.warning(f"Could not load violation_type_severity.csv from {violation_severity_path}")
    else:
        logging.warning(f"violation_type_severity.csv not found at {violation_severity_path}. Skipping merge.")

    # Feature Engineering: Create interaction terms and frequency encodings
    if not disable_street_violation_pair:
        df['street_violation_pair'] = df['street_name'] + '_' + df['violation_type']

    if not disable_frequency_encoding:
        for col in ['street_name', 'violation_type', 'borough']:
            if col in df.columns:
                df[f'{col}_freq'] = df[col].map(df[col].value_counts(normalize=True))

    return df

def prepare_features_and_target(df):
    """
    Prepares features (X) and target (y) from the DataFrame for training/validation.
    Identifies categorical features and handles missing values.
    """
    X = df.copy()
    
    if 'violation_count' not in X.columns:
        raise ValueError("DataFrame must contain 'violation_count' column for training/validation.")
    y = X['violation_count']
    X = X.drop(columns=['violation_count'])

    # Identify categorical features
    categorical_features_names = []
    for col in X.columns:
        # Heuristic for categorical: object dtype or low cardinality non-numeric
        if X[col].dtype == 'object' or (X[col].nunique() < len(X) * 0.05 and X[col].nunique() < 500 and X[col].dtype not in ['int64', 'float64']):
            categorical_features_names.append(col)
    
    # Handle categorical NaNs: convert to string 'NaN_Category' for CatBoost
    for col in categorical_features_names:
        if col in X.columns:
            X[col] = X[col].astype(str).fillna('NaN_Category')

    # Handle numerical NaNs: fill with median
    numerical_cols = [col for col in X.columns if col not in categorical_features_names]
    for col in numerical_cols:
        if col in X.columns and X[col].isnull().any():
            if X[col].isnull().all(): # If column is entirely NaN, fill with 0
                X[col] = X[col].fillna(0)
            else:
                X[col] = X[col].fillna(X[col].median())

    return X, y, categorical_features_names

# --- Ablation Study Function ---
def run_ablation(
    train_path, input_dir,
    disable_street_violation_pair=False,
    disable_frequency_encoding=False,
    catboost_depth=8
):
    """
    Runs a single ablation experiment and returns the validation RMSE.
    """
    # Load Training Data
    train_df = load_data(train_path)
    if train_df is None:
        return None

    # Augment Training Data with ablation specific flags
    train_df_augmented = augment_data(
        train_df, input_dir,
        disable_street_violation_pair=disable_street_violation_pair,
        disable_frequency_encoding=disable_frequency_encoding
    )

    # Prepare Features and Target
    X_train_full, y_train_full, categorical_features = prepare_features_and_target(train_df_augmented)

    # Train/Validation Split
    X_train, X_val, y_train, y_val = train_test_split(
        X_train_full, y_train_full, test_size=0.2, random_state=42
    )

    # CatBoost Model Training
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=catboost_depth, # Ablated parameter
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Suppress verbose output for ablation runs
        early_stopping_rounds=50,
        cat_features=categorical_features,
    )

    train_pool = Pool(X_train, y_train, cat_features=categorical_features)
    eval_pool = Pool(X_val, y_val, cat_features=categorical_features)

    model.fit(train_pool, eval_set=eval_pool, plot=False)

    # Evaluate
    val_predictions = model.predict(X_val)
    val_predictions = np.maximum(0, val_predictions) # Ensure predictions are non-negative
    validation_rmse = calculate_rmse(y_val, val_predictions)
    return validation_rmse

# --- Main Ablation Logic ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Ablation study for NYC parking violations model.")
    parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--input-dir", type=str, default="./input",
                        help="Directory containing augmentation tables.")
    args = parser.parse_args()

    results = {}

    # Base Case
    print("--- Running Base Case ---")
    base_rmse = run_ablation(args.train_path, args.input_dir)
    if base_rmse is not None:
        results['Base Case'] = base_rmse
        print(f"Base Case Validation RMSE: {base_rmse:.4f}")
    else:
        print("Base Case failed. Cannot proceed with ablation.")
        sys.exit(1)

    # Ablation 1: No 'street_violation_pair' feature
    print("\n--- Running Ablation: No 'street_violation_pair' feature ---")
    ablation1_rmse = run_ablation(args.train_path, args.input_dir, disable_street_violation_pair=True)
    if ablation1_rmse is not None:
        results['No street_violation_pair'] = ablation1_rmse
        print(f"Ablation (No street_violation_pair) Validation RMSE: {ablation1_rmse:.4f}")

    # Ablation 2: No Frequency Encoding features
    print("\n--- Running Ablation: No Frequency Encoding features ---")
    ablation2_rmse = run_ablation(args.train_path, args.input_dir, disable_frequency_encoding=True)
    if ablation2_rmse is not None:
        results['No Frequency Encoding'] = ablation2_rmse
        print(f"Ablation (No Frequency Encoding) Validation RMSE: {ablation2_rmse:.4f}")

    # Ablation 3: Reduced CatBoost Depth (from 8 to 5)
    print("\n--- Running Ablation: Reduced CatBoost Depth (8 -> 5) ---")
    ablation3_rmse = run_ablation(args.train_path, args.input_dir, catboost_depth=5)
    if ablation3_rmse is not None:
        results['Reduced CatBoost Depth (5)'] = ablation3_rmse
        print(f"Ablation (Reduced CatBoost Depth (5)) Validation RMSE: {ablation3_rmse:.4f}")

    print("\n--- Ablation Study Results Summary ---")
    most_impactful_change_name = "None identified"
    largest_absolute_impact_delta = 0.0
    impact_description = ""

    for name, rmse in results.items():
        if name == 'Base Case':
            continue
        
        delta = rmse - base_rmse
        print(f"{name}: RMSE = {rmse:.4f}, Delta from Base = {delta:+.4f}")
        
        # Determine the most impactful change (largest absolute delta)
        abs_delta = abs(delta)
        if abs_delta > largest_absolute_impact_delta:
            largest_absolute_impact_delta = abs_delta
            most_impactful_change_name = name
            if delta > 0:
                impact_description = f"Removing/changing '{name}' worsened RMSE by {delta:.4f} compared to the Base Case, indicating that the original component is beneficial."
            else:
                impact_description = f"Removing/changing '{name}' improved RMSE by {-delta:.4f} compared to the Base Case, indicating that the original component was detrimental."

    print(f"\nBased on these results, the most impactful modification was: '{most_impactful_change_name}'.")
    print(impact_description)
