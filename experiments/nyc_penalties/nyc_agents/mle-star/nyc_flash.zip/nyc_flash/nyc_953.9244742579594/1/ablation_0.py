
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys
import copy

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df, use_downcasting=True):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    if not use_downcasting:
        return df # Skip downcasting

    initial_memory = df.memory_usage(deep=True).sum() / (1024**2)
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    final_memory = df.memory_usage(deep=True).sum() / (1024**2)
    # print(f"  Memory reduced from {initial_memory:.2f} MB to {final_memory:.2f} MB for dataframe.")
    return df

def load_and_preprocess_data(train_path, test_path=None, use_downcasting=True, use_street_data=True, use_violation_codes=True, use_census_data=True):
    """
    Loads, preprocesses, and merges data from various sources.
    Handles memory efficiency by selective column loading, aggregation, and garbage collection.
    Flags control which augmentations are applied.
    """
    print("Loading and preprocessing data...")

    # --- Load Core Data ---
    # Load training data
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw, use_downcasting=use_downcasting)
    # print(f"Initial train_df loaded. Shape: {train_df_raw.shape}, Memory: {train_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # For ablation study, we only focus on train/validation, so test_df_raw will be None.
    test_df_raw = None
    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_df = combined_keys_train.copy().reset_index(drop=True)
    del combined_keys_train # Free memory
    gc.collect()
    # print(f"Combined unique (street, violation) pairs for feature engineering. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # --- Feature Engineering and Augmentation ---

    # Basic features from core data
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # Augmentation 1: nyc_street_data.csv
    if use_street_data:
        street_data_path = './input/nyc_street_data.csv'
        if os.path.exists(street_data_path):
            # print(f"Loading {street_data_path}...")
            try:
                street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
                street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
                street_data = downcast_dtypes(street_data, use_downcasting=use_downcasting)
                street_data = street_data.drop_duplicates(subset=['street_name']) # Ensure unique info per street
                combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
                del street_data
                gc.collect()
                # print(f"Merged with street_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
            except Exception as e:
                print(f"Error loading or merging {street_data_path}: {e}. Skipping street data augmentation.")
        else:
            print(f"Warning: {street_data_path} not found. Skipping street data augmentation.")
    else:
        print("Skipping nyc_street_data augmentation as per ablation configuration.")


    # Augmentation 2: nyc_violation_codes.csv
    if use_violation_codes:
        violation_codes_path = './input/nyc_violation_codes.csv'
        if os.path.exists(violation_codes_path):
            # print(f"Loading {violation_codes_path}...")
            try:
                violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
                violation_codes.columns = ['violation_description', 'fine_amount', 'points']
                violation_codes = downcast_dtypes(violation_codes, use_downcasting=use_downcasting)
                violation_codes = violation_codes.drop_duplicates(subset=['violation_description']) # Ensure unique info per violation
                combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
                del violation_codes
                gc.collect()
                # print(f"Merged with violation_codes. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
            except Exception as e:
                print(f"Error loading or merging {violation_codes_path}: {e}. Skipping violation codes augmentation.")
        else:
            print(f"Warning: {violation_codes_path} not found. Skipping violation codes augmentation.")
    else:
        print("Skipping nyc_violation_codes augmentation as per ablation configuration.")

    # Augmentation 3: nyc_census_data.csv (Hypothetical)
    if use_census_data:
        census_data_path = './input/nyc_census_data.csv'
        if os.path.exists(census_data_path):
            # print(f"Loading {census_data_path}...")
            if 'borough' in combined_df.columns: # Only proceed if borough info is available from street_data
                try:
                    census_data = pd.read_csv(census_data_path)
                    # Standardize column names
                    census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]

                    # Assuming 'borough' is the key and 'population_density', 'avg_income' are features
                    relevant_census_cols = ['borough', 'population_density', 'avg_income']
                    if all(col in census_data.columns for col in relevant_census_cols):
                        # Aggregate census data by borough to reduce size before merging
                        census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                        census_agg = downcast_dtypes(census_agg, use_downcasting=use_downcasting)
                        combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                        del census_data, census_agg
                        gc.collect()
                        # print(f"Merged with census_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
                    else:
                        print(f"Warning: Missing one or more expected columns ({relevant_census_cols}) in {census_data_path}. Skipping census data augmentation.")
                except Exception as e:
                    print(f"Error loading or merging {census_data_path}: {e}. Skipping census data augmentation.")
            else:
                print("Warning: Borough information not available in combined_df to merge census data. Skipping.")
        else:
            print(f"Warning: {census_data_path} not found. Skipping census data augmentation.")
    else:
        print("Skipping nyc_census_data augmentation as per ablation configuration.")


    # Split back into train and test processed dataframes
    # Merge the engineered features back to the raw dataframes (which still hold violation_count and is_pure_prediction)
    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    test_processed_df = None # For ablation, we don't process test data

    # print(f"Final train_processed_df shape: {train_processed_df.shape}")

    # Identify categorical features for CatBoost
    categorical_features = [col for col in combined_df.columns if combined_df[col].dtype in ['object', 'category']]
    # Ensure all categorical features from the combined_df are present in the final processed DFs
    categorical_features = [col for col in categorical_features if col in train_processed_df.columns]
    # print(f"Categorical features identified for CatBoost: {categorical_features}")

    # Ensure all categorical columns are of 'category' dtype for CatBoost
    for col in categorical_features:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].astype('category')

    return train_processed_df, test_processed_df, categorical_features

def train_and_predict(train_df, test_df, categorical_features, model_params=None):
    """
    Trains a CatBoost Regressor model and generates predictions.
    Reports RMSE for validation. test_df is expected to be None for this ablation study.
    """
    # print("Training CatBoost model...")

    # Define features (X) and target (y)
    features = [col for col in train_df.columns if col not in ['violation_count']]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    # Split training data for validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    # print(f"Training data split: X_train={X_train.shape}, X_val={X_val.shape}")

    # Initialize CatBoost Regressor
    default_model_params = {
        'iterations': 1000,
        'learning_rate': 0.05,
        'depth': 6,
        'l2_leaf_reg': 3,
        'loss_function': 'RMSE',
        'eval_metric': 'RMSE',
        'random_seed': 42,
        'verbose': 0, # Suppress verbose output during ablation runs
        'early_stopping_rounds': 50,
    }
    if model_params:
        default_model_params.update(model_params)

    model = CatBoostRegressor(**default_model_params)

    # Train the model
    # Convert categorical feature names to their indices for CatBoost
    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]
    # print(f"Categorical feature indices for CatBoost: {cat_features_indices}")

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        raise

    # Validate on internal validation set
    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    return val_rmse

def run_ablation(name, train_path,
                 use_downcasting=True,
                 use_street_data=True,
                 use_violation_codes=True,
                 use_census_data=True,
                 model_params=None):
    """
    Runs a single ablation study configuration and returns the validation RMSE.
    """
    print(f"\n--- Running Ablation: {name} ---")
    train_df, _, categorical_features = load_and_preprocess_data(
        train_path=train_path,
        test_path=None, # Only training data for ablation
        use_downcasting=use_downcasting,
        use_street_data=use_street_data,
        use_violation_codes=use_violation_codes,
        use_census_data=use_census_data
    )
    val_rmse = train_and_predict(train_df, None, categorical_features, model_params=model_params)
    print(f"Ablation '{name}' Validation RMSE: {val_rmse:.4f}")
    gc.collect() # Clean up memory after each run
    return val_rmse

def main_ablation():
    """
    Main function to orchestrate the ablation study.
    """
    train_path = './input/violations_per_street_2022.csv'

    results = {}

    # Base Case (Original configuration)
    print("--- Starting Ablation Study ---")
    base_rmse = run_ablation("Base Case", train_path)
    results["Base Case"] = base_rmse

    # Ablation 1: Disable Downcasting for memory efficiency
    no_downcast_rmse = run_ablation("Ablation: No Downcasting", train_path, use_downcasting=False)
    results["No Downcasting"] = no_downcast_rmse

    # Ablation 2: Remove nyc_street_data.csv augmentation
    no_street_data_rmse = run_ablation("Ablation: No Street Data", train_path, use_street_data=False)
    results["No Street Data"] = no_street_data_rmse

    # Ablation 3: Remove nyc_violation_codes.csv augmentation
    no_violation_codes_rmse = run_ablation("Ablation: No Violation Codes", train_path, use_violation_codes=False)
    results["No Violation Codes"] = no_violation_codes_rmse

    # Ablation 4: Reduce CatBoost depth significantly
    reduced_depth_params = {'depth': 3, 'iterations': 500} # Also reduce iterations for faster runs
    reduced_depth_rmse = run_ablation("Ablation: Reduced CatBoost Depth (3)", train_path, model_params=reduced_depth_params)
    results["Reduced CatBoost Depth"] = reduced_depth_rmse

    print("\n--- Ablation Study Results Summary ---")
    for name, rmse in results.items():
        print(f"{name}: RMSE = {rmse:.4f}")
        if name != "Base Case":
            diff = rmse - base_rmse
            print(f"  Difference from Base Case: {diff:+.4f}")

    # Determine the most contributing part (largest positive difference in RMSE indicates its removal hurt performance most)
    worst_ablation_name = None
    max_rmse_increase = -1.0

    for name, rmse in results.items():
        if name == "Base Case":
            continue
        increase = rmse - base_rmse
        if increase > max_rmse_increase:
            max_rmse_increase = increase
            worst_ablation_name = name

    if worst_ablation_name:
        print(f"\nConclusion: The part of the code that contributes most to overall performance (based on validation RMSE increase when removed/modified) is: '{worst_ablation_name}' (Increased RMSE by {max_rmse_increase:.4f}).")
        if "No Downcasting" in worst_ablation_name:
            print("This suggests that memory optimization (downcasting) is crucial for either performance or stability.")
        elif "No Street Data" in worst_ablation_name:
            print("This suggests that including street-level geographical/physical attributes is very important for prediction accuracy.")
        elif "No Violation Codes" in worst_ablation_name:
            print("This suggests that including financial/penalty details about violations significantly aids prediction.")
        elif "Reduced CatBoost Depth" in worst_ablation_name:
            print("This suggests that model complexity (tree depth) is vital for capturing underlying patterns.")
    else:
        print("\nNo significant performance drop detected across ablations, or an issue occurred.")

if __name__ == "__main__":
    main_ablation()
