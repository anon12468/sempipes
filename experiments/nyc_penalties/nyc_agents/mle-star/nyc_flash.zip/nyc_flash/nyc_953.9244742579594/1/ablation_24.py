
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Original helper function to downcast dtypes for memory efficiency
def downcast_dtypes_base(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    return df

# Ablation 2: Disable heuristic object to category conversion in downcast_dtypes
def downcast_dtypes_no_object_to_category_heuristic(df):
    """
    Downcasts numeric columns to more memory-efficient types, but skips heuristic
    conversion of object columns to category.
    """
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Object columns are NOT converted to category by heuristic in this version
    return df

def load_and_preprocess_data_ablated(train_path, test_path=None,
                                     skip_violation_codes_augmentation=False,
                                     downcaster_func=downcast_dtypes_base,
                                     fill_numeric_augmentation_nans_with=None):
    """
    Loads, preprocesses, and merges data from various sources, with ablation options.
    """
    # --- Load Core Data ---
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcaster_func(train_df_raw)

    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_df = pd.concat([combined_keys_train], ignore_index=True).drop_duplicates().reset_index(drop=True)
    del combined_keys_train
    gc.collect()

    # --- Feature Engineering and Augmentation ---
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # Augmentation 1: nyc_street_data.csv
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcaster_func(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
        except Exception as e:
            pass # Skip silently for ablation

    # Augmentation 2: nyc_violation_codes.csv (Ablation 1 controlled here)
    violation_codes_path = './input/nyc_violation_codes.csv'
    if not skip_violation_codes_augmentation and os.path.exists(violation_codes_path):
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcaster_func(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
        except Exception as e:
            pass # Skip silently for ablation

    # Augmentation 3: nyc_census_data.csv
    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        if 'borough' in combined_df.columns:
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcaster_func(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
            except Exception as e:
                pass # Skip silently for ablation

    # Ablation 3: Fill NaNs for numerical augmentation features
    if fill_numeric_augmentation_nans_with is not None:
        numeric_augmentation_cols = ['street_length', 'num_lanes', 'fine_amount', 'points', 'population_density', 'avg_income']
        for col in numeric_augmentation_cols:
            if col in combined_df.columns:
                if pd.api.types.is_numeric_dtype(combined_df[col]):
                    combined_df[col] = combined_df[col].fillna(fill_numeric_augmentation_nans_with)

    # Merge the engineered features back to the raw dataframes
    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    test_processed_df = None # Always None for ablation study

    # Identify categorical features for CatBoost
    # These are columns that were originally object/category and might contain NaNs after merges.
    # We will explicitly convert them to string (object) and fill NaNs for CatBoost.
    candidate_categorical_features = [col for col in combined_df.columns if combined_df[col].dtype in ['object', 'category']]
    # Filter to only include columns actually present in the final train_processed_df
    categorical_features = [col for col in candidate_categorical_features if col in train_processed_df.columns]

    # FIX: Explicitly handle NaNs in categorical columns for CatBoost.
    # CatBoost expects categorical features to be strings or integers.
    # If a categorical column contains np.nan, it needs to be converted to a string representation.
    for col in categorical_features:
        if col in train_processed_df.columns:
            # Convert to string type first. This turns np.nan into the string "nan".
            # Then, replace the string "nan" with a more explicit placeholder 'Missing_Category_Value'.
            # This ensures consistency even if some 'NaN's were already strings.
            train_processed_df[col] = train_processed_df[col].astype(str).replace('nan', 'Missing_Category_Value')
            # Ensure the column is of object dtype, which CatBoost can interpret as categorical.
            train_processed_df[col] = train_processed_df[col].astype('object')

    return train_processed_df, test_processed_df, categorical_features

def train_and_predict_ablated(train_df, test_df, categorical_features):
    """
    Trains a CatBoost Regressor model and generates predictions.
    Reports RMSE for validation.
    """
    features = [col for col in train_df.columns if col not in ['violation_count']]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6,
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Set to 0 for cleaner ablation output
        early_stopping_rounds=50,
    )

    # Get indices of categorical features for CatBoost.
    # These columns are already preprocessed to handle NaNs as strings ('Missing_Category_Value').
    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        # Re-raise the exception after printing for clearer debugging in case it's a new error
        raise

    val_preds = model.predict(X_val)
    val_preds[val_preds < 0] = 0 # Ensure non-negative predictions
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    
    return None, val_rmse # Only return validation RMSE

def run_ablation_scenario(scenario_name, train_path,
                           skip_violation_codes_augmentation=False,
                           downcaster_func=downcast_dtypes_base,
                           fill_numeric_augmentation_nans_with=None):

    print(f"--- Running Scenario: {scenario_name} ---")
    train_df, _, categorical_features = load_and_preprocess_data_ablated(
        train_path=train_path,
        test_path=None, # Explicitly no test_path for ablation
        skip_violation_codes_augmentation=skip_violation_codes_augmentation,
        downcaster_func=downcaster_func,
        fill_numeric_augmentation_nans_with=fill_numeric_augmentation_nans_with
    )
    # Optional: Check for NaNs in categorical columns after preprocessing, before training
    for col in categorical_features:
        if train_df[col].isnull().any():
            print(f"WARNING: NaN found in categorical column '{col}' after preprocessing in scenario '{scenario_name}'. This should ideally be handled.")
            # print(train_df[col].value_counts(dropna=False)) # Uncomment for detailed check

    _, val_rmse = train_and_predict_ablated(train_df, None, categorical_features)
    print(f"Scenario '{scenario_name}' Validation RMSE: {val_rmse:.4f}")
    gc.collect() # Clean up memory after each scenario
    return val_rmse

if __name__ == "__main__":
    # Ensure dummy input files exist for running the ablation.
    input_dir = "./input"
    train_file = os.path.join(input_dir, "violations_per_street_2022.csv")
    street_data_file = os.path.join(input_dir, "nyc_street_data.csv")
    violation_codes_file = os.path.join(input_dir, "nyc_violation_codes.csv")
    census_data_file = os.path.join(input_dir, "nyc_census_data.csv")

    if not os.path.exists(input_dir):
        os.makedirs(input_dir)

    # Create dummy data if files don't exist
    # Modified dummy data to ensure some NaNs are generated for the 'borough' column after merging
    if not os.path.exists(train_file):
        dummy_data = {
            'street_name': ['MAIN ST', 'ELM AVE', 'OAK BLVD', 'MAIN ST', 'ELM AVE', 'PINE DR', 'MAPLE RD', 'ELM AVE', 'UNKNOWN ST'],
            'violation_description': ['PARKING METER', 'NO STANDING', 'DOUBLE PARKING', 'PARKING METER', 'NO STANDING', 'FIRE HYDRANT', 'NO PARKING', 'PARKING METER', 'NO STANDING'],
            'violation_count': [100, 50, 20, 120, 60, 15, 30, 75, 40]
        }
        pd.DataFrame(dummy_data).to_csv(train_file, index=False)

    if not os.path.exists(street_data_file):
        dummy_street_data = {
            'Street Name': ['MAIN ST', 'OAK BLVD', 'PINE DR', 'MAPLE RD'], # 'ELM AVE' and 'UNKNOWN ST' are missing to create NaNs in 'borough'
            'Borough': ['Manhattan', 'Brooklyn', 'Queens', 'Bronx'],
            'Street Length': [1.5, 2.1, 0.5, 1.2],
            'Number of Lanes': [4, 6, 2, 3]
        }
        pd.DataFrame(dummy_street_data).to_csv(street_data_file, index=False)

    if not os.path.exists(violation_codes_file):
        dummy_violation_codes = {
            'Violation Description': ['PARKING METER', 'NO STANDING', 'DOUBLE PARKING', 'FIRE HYDRANT', 'NO PARKING'],
            'Fine Amount': [65, 115, 125, 180, 60],
            'Points': [0, 0, 0, 3, 0]
        }
        pd.DataFrame(dummy_violation_codes).to_csv(violation_codes_file, index=False)

    if not os.path.exists(census_data_file):
        dummy_census_data = {
            'Borough': ['Manhattan', 'Brooklyn', 'Queens', 'Bronx', 'Staten Island'],
            'Population Density': [27000, 15000, 8000, 10000, 5000],
            'Avg Income': [90000, 60000, 70000, 55000, 65000]
        }
        pd.DataFrame(dummy_census_data).to_csv(census_data_file, index=False)

    results = {}
    
    base_case_rmse = run_ablation_scenario("Base Case", train_file)
    results["Base Case"] = base_case_rmse

    # Ablation 1: No nyc_violation_codes.csv Augmentation
    rmse_no_violation_codes = run_ablation_scenario(
        "Ablation 1: No Violation Codes Augmentation",
        train_file,
        skip_violation_codes_augmentation=True
    )
    results["Ablation 1: No Violation Codes Augmentation"] = rmse_no_violation_codes

    # Ablation 2: Disable heuristic object to category conversion in downcast_dtypes
    rmse_no_obj_to_cat_heuristic = run_ablation_scenario(
        "Ablation 2: No Object to Category Heuristic in Downcaster",
        train_file,
        downcaster_func=downcast_dtypes_no_object_to_category_heuristic
    )
    results["Ablation 2: No Object to Category Heuristic in Downcaster"] = rmse_no_obj_to_cat_heuristic

    # Ablation 3: Fill Numerical NaNs with -1 for Augmentation Features
    rmse_fill_numeric_nans = run_ablation_scenario(
        "Ablation 3: Fill Numeric Augmentation NaNs with -1",
        train_file,
        fill_numeric_augmentation_nans_with=-1
    )
    results["Ablation 3: Fill Numeric Augmentation NaNs with -1"] = rmse_fill_numeric_nans

    print("\n--- Ablation Study Summary ---")
    for scenario, rmse in results.items():
        delta = rmse - base_case_rmse
        print(f"{scenario}: RMSE = {rmse:.4f} (Delta from Base: {delta:+.4f})")

    # Determine the most contributing part based on largest absolute change in RMSE
    most_contributing_part_name = "None"
    largest_abs_delta = -1.0
    
    for scenario, rmse in results.items():
        if scenario == "Base Case":
            continue
        delta = rmse - base_case_rmse
        if abs(delta) > largest_abs_delta:
            largest_abs_delta = abs(delta)
            most_contributing_part_name = scenario

    print(f"\nThe part of the code that contributes the most to the overall performance (based on largest absolute change in RMSE) is: '{most_contributing_part_name}'.")
    if results[most_contributing_part_name] > base_case_rmse:
        print(f"Its removal or modification (as per scenario description) led to a degradation in performance (RMSE increased by {largest_abs_delta:+.4f}).")
    else:
        print(f"Its removal or modification (as per scenario description) led to an improvement in performance (RMSE decreased by {largest_abs_delta:+.4f}).")
    
    # Required final performance print
    final_validation_score = base_case_rmse # Assuming Base Case is the final desired validation RMSE
    print(f'Final Validation Performance: {final_validation_score}')
