
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    # Create a copy to avoid SettingWithCopyWarning, especially important when modifying in place
    df = df.copy() 
    initial_memory = df.memory_usage(deep=True).sum() / (1024**2)
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        # NaNs in these columns will be handled explicitly for CatBoost later.
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    final_memory = df.memory_usage(deep=True).sum() / (1024**2)
    return df

def load_and_preprocess_data(train_path, test_path=None, 
                             use_street_group_features=True, 
                             use_violation_group_features=True, 
                             use_census_ratio_features=True):
    """
    Loads, preprocesses, and merges data from various sources.
    Handles memory efficiency by selective column loading, aggregation, and garbage collection.
    Includes flags for ablating specific new feature groups.
    Handles NaN values in categorical features for CatBoost.
    """
    print("Loading and preprocessing data...")

    # --- Load Core Data ---
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)

    test_df_raw = None
    if test_path:
        test_df_raw = pd.read_csv(test_path)
        test_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
        test_df_raw['is_pure_prediction'] = test_df_raw['violation_count'].isna()
        test_df_raw = downcast_dtypes(test_df_raw)

    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_keys_test = pd.DataFrame()
    if test_df_raw is not None:
        combined_keys_test = test_df_raw[['street_name', 'violation_description']].drop_duplicates()

    combined_df = pd.concat([combined_keys_train, combined_keys_test], ignore_index=True).drop_duplicates().reset_index(drop=True)
    del combined_keys_train, combined_keys_test # Free memory
    gc.collect()

    # --- Feature Engineering and Augmentation ---

    # Basic features
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # Augmentation 1: nyc_street_data.csv
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()

            if use_street_group_features and 'borough' in combined_df.columns and 'street_length' in combined_df.columns and 'num_lanes' in combined_df.columns:
                borough_street_stats = combined_df.groupby('borough')[['street_length', 'num_lanes']].mean().reset_index()
                borough_street_stats.columns = ['borough', 'avg_street_length_borough', 'avg_num_lanes_borough']
                borough_street_stats = downcast_dtypes(borough_street_stats)

                combined_df = pd.merge(combined_df, borough_street_stats, on='borough', how='left')

                combined_df['street_length_dev_borough'] = combined_df['street_length'] - combined_df['avg_street_length_borough']
                combined_df['num_lanes_dev_borough'] = combined_df['num_lanes'] - combined_df['avg_num_lanes_borough']

                # Ensure these are downcasted after calculation
                combined_df['street_length_dev_borough'] = downcast_dtypes(pd.DataFrame({'col': combined_df['street_length_dev_borough']}))['col']
                combined_df['num_lanes_dev_borough'] = downcast_dtypes(pd.DataFrame({'col': combined_df['num_lanes_dev_borough']}))['col']

                del borough_street_stats
                gc.collect()
            elif use_street_group_features:
                print("Warning: Missing 'borough', 'street_length', or 'num_lanes' for street statistics generation (even with use_street_group_features=True).")
        except Exception as e:
            print(f"Error loading or merging {street_data_path}: {e}. Skipping street data augmentation.")
    else:
        print(f"Warning: {street_data_path} not found. Skipping street data augmentation (and related group features).")


    # Augmentation 2: nyc_violation_codes.csv
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()

            if use_violation_group_features and 'violation_description' in combined_df.columns and 'fine_amount' in combined_df.columns and 'points' in combined_df.columns:
                violation_stats = combined_df.groupby('violation_description')[['fine_amount', 'points']].mean().reset_index()
                violation_stats.columns = ['violation_description', 'avg_fine_amount_desc', 'avg_points_desc']
                violation_stats = downcast_dtypes(violation_stats)

                combined_df = pd.merge(combined_df, violation_stats, on='violation_description', how='left')

                combined_df['fine_amount_dev_desc'] = combined_df['fine_amount'] - combined_df['avg_fine_amount_desc']
                combined_df['points_dev_desc'] = combined_df['points'] - combined_df['avg_points_desc']
                
                # Ensure these are downcasted after calculation
                combined_df['fine_amount_dev_desc'] = downcast_dtypes(pd.DataFrame({'col': combined_df['fine_amount_dev_desc']}))['col']
                combined_df['points_dev_desc'] = downcast_dtypes(pd.DataFrame({'col': combined_df['points_dev_desc']}))['col']

                del violation_stats
                gc.collect()
            elif use_violation_group_features:
                print("Warning: Missing 'violation_description', 'fine_amount', or 'points' for violation statistics generation (even with use_violation_group_features=True).")

        except Exception as e:
            print(f"Error loading or merging {violation_codes_path}: {e}. Skipping violation codes augmentation.")
    else:
        print(f"Warning: {violation_codes_path} not found. Skipping violation codes augmentation (and related group features).")

    # Augmentation 3: nyc_census_data.csv (Hypothetical)
    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        if 'borough' in combined_df.columns:
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]

                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()

                    if use_census_ratio_features and 'fine_amount' in combined_df.columns and 'population_density' in combined_df.columns:
                        combined_df['fine_amount_per_pop_density'] = combined_df['fine_amount'] / combined_df['population_density'].replace(0, np.nan)
                        
                        if 'points' in combined_df.columns:
                            combined_df['points_per_pop_density'] = combined_df['points'] / combined_df['population_density'].replace(0, np.nan)
                        
                        if 'avg_income' in combined_df.columns:
                            combined_df['fine_amount_per_avg_income'] = combined_df['fine_amount'] / combined_df['avg_income'].replace(0, np.nan)

                        for col in ['fine_amount_per_pop_density', 'points_per_pop_density', 'fine_amount_per_avg_income']:
                            if col in combined_df.columns:
                                # Ensure downcasting of new float features
                                combined_df[col] = downcast_dtypes(pd.DataFrame({'col': combined_df[col]}))['col']

                        gc.collect()
                    elif use_census_ratio_features:
                        print("Warning: Missing 'fine_amount', 'population_density' or 'points'/'avg_income' for ratio feature generation (even with use_census_ratio_features=True).")
                else:
                    print(f"Warning: Missing one or more expected columns ({relevant_census_cols}) in {census_data_path}. Skipping census data augmentation.")
            except Exception as e:
                print(f"Error loading or merging {census_data_path}: {e}. Skipping census data augmentation.")
        else:
            print("Warning: Borough information not available in combined_df to merge census data. Skipping.")
    else:
        print(f"Warning: {census_data_path} not found. Skipping census data augmentation (and related ratio features).")

    # --- Handle NaNs in categorical features explicitly for CatBoost ---
    # CatBoost does not handle NaN values directly in categorical features.
    # We identify columns that are meant to be categorical and fill NaNs with a placeholder string.
    cat_cols_to_process = []
    if 'street_name' in combined_df.columns: cat_cols_to_process.append('street_name')
    if 'violation_description' in combined_df.columns: cat_cols_to_process.append('violation_description')
    if 'borough' in combined_df.columns: cat_cols_to_process.append('borough')
    # Add any other columns here that are text-based and expected to be categorical by CatBoost

    for col in cat_cols_to_process:
        if col in combined_df.columns:
            # Convert to string to handle any mixed types (e.g., float NaNs) and ensure fillna works correctly.
            # Then fill NaNs with a specific string, and convert to category type.
            combined_df[col] = combined_df[col].astype(str).fillna('__MISSING__').astype('category')
    
    # Identify categorical features for CatBoost based on the final dtype after processing
    categorical_features = [col for col in combined_df.columns if combined_df[col].dtype.name == 'category']

    # Split back into train and test processed dataframes
    # Merging will inherit the pre-processed dtypes and filled NaNs from combined_df
    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    test_processed_df = None
    if test_df_raw is not None:
        test_processed_df = pd.merge(test_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
        del test_df_raw
        gc.collect()

    # Re-apply category type for consistency after merge, using the identified categorical_features list.
    # The NaN handling is done on combined_df, so this is mainly to ensure dtype correctness post-merge.
    for col in categorical_features:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].astype('category')
        if test_processed_df is not None and col in test_processed_df.columns:
            test_processed_df[col] = test_processed_df[col].astype('category')

    return train_processed_df, test_processed_df, categorical_features

def train_and_predict(train_df, test_df, categorical_features):
    """
    Trains a CatBoost Regressor model and generates predictions.
    Reports RMSE for validation and test sets (if ground truth available).
    """
    features = [col for col in train_df.columns if col not in ['violation_count']]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6,
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Suppress verbose output for ablation runs
        early_stopping_rounds=50,
    )

    # Ensure categorical_features only contains columns actually present in X_train
    cat_features_in_X_train = [col for col in categorical_features if col in X_train.columns]
    cat_features_indices = [X_train.columns.get_loc(col) for col in cat_features_in_X_train]

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        raise

    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))

    submission_df = None # Not needed for ablation study, only for final submission
    return submission_df, val_rmse

def ablation_main():
    """
    Main function to orchestrate the ablation study.
    """
    train_path = './input/violations_per_street_2022.csv'
    
    # Create dummy external files if they don't exist, for consistent local execution
    os.makedirs('./input', exist_ok=True)
    if not os.path.exists('./input/violations_per_street_2022.csv'):
        dummy_train_data = pd.DataFrame({
            'Street Name': ['MAIN ST', 'PARK AVE', 'ELM ST', 'BROADWAY', 'MAIN ST', 'PARK AVE'],
            'Violation Description': ['NO PARKING', 'SPEEDING', 'RED LIGHT', 'NO STANDING', 'NO PARKING', 'DOUBLE PARKING'],
            'violation_count': [100, 50, 75, 120, 90, 60]
        })
        dummy_train_data.to_csv('./input/violations_per_street_2022.csv', index=False)

    if not os.path.exists('./input/nyc_street_data.csv'):
        dummy_street_data = pd.DataFrame({
            'Street Name': ['MAIN ST', 'PARK AVE', 'ELM ST', 'BROADWAY'],
            'Borough': ['Manhattan', 'Brooklyn', 'Queens', 'Manhattan'],
            'Street Length': [1000.0, 1500.0, 800.0, 2000.0],
            'Number of Lanes': [4, 6, 2, 8]
        })
        dummy_street_data.to_csv('./input/nyc_street_data.csv', index=False)
    
    if not os.path.exists('./input/nyc_violation_codes.csv'):
        dummy_violation_codes = pd.DataFrame({
            'Violation Description': ['NO PARKING', 'SPEEDING', 'RED LIGHT', 'NO STANDING', 'DOUBLE PARKING'],
            'Fine Amount': [65.0, 150.0, 200.0, 100.0, 120.0],
            'Points': [0, 3, 2, 0, 0]
        })
        dummy_violation_codes.to_csv('./input/nyc_violation_codes.csv', index=False)

    if not os.path.exists('./input/nyc_census_data.csv'):
        dummy_census_data = pd.DataFrame({
            'Borough': ['Manhattan', 'Brooklyn', 'Queens', 'Bronx'],
            'Population_Density': [70000.0, 35000.0, 20000.0, 40000.0],
            'Avg_Income': [100000.0, 60000.0, 50000.0, 45000.0]
        })
        dummy_census_data.to_csv('./input/nyc_census_data.csv', index=False)

    results = {}

    # Base Case: All new features enabled
    print("\n--- Running Base Case (All new features enabled) ---")
    train_df_base, _, cat_features_base = load_and_preprocess_data(
        train_path, None, 
        use_street_group_features=True, 
        use_violation_group_features=True, 
        use_census_ratio_features=True
    )
    _, base_rmse = train_and_predict(train_df_base, None, cat_features_base)
    results['Base Case'] = base_rmse
    print(f"Base Case Validation RMSE: {base_rmse:.4f}")
    gc.collect()

    # Ablation 1: No Street Group/Deviation Features
    print("\n--- Running Ablation 1 (No Street Group/Deviation Features) ---")
    train_df_ablation1, _, cat_features_ablation1 = load_and_preprocess_data(
        train_path, None, 
        use_street_group_features=False, 
        use_violation_group_features=True, 
        use_census_ratio_features=True
    )
    _, ablation1_rmse = train_and_predict(train_df_ablation1, None, cat_features_ablation1)
    results['No Street Group Features'] = ablation1_rmse
    print(f"Ablation 1 Validation RMSE: {ablation1_rmse:.4f} (Delta from Base: {ablation1_rmse - base_rmse:.4f})")
    gc.collect()

    # Ablation 2: No Violation Group/Deviation Features
    print("\n--- Running Ablation 2 (No Violation Group/Deviation Features) ---")
    train_df_ablation2, _, cat_features_ablation2 = load_and_preprocess_data(
        train_path, None, 
        use_street_group_features=True, 
        use_violation_group_features=False, 
        use_census_ratio_features=True
    )
    _, ablation2_rmse = train_and_predict(train_df_ablation2, None, cat_features_ablation2)
    results['No Violation Group Features'] = ablation2_rmse
    print(f"Ablation 2 Validation RMSE: {ablation2_rmse:.4f} (Delta from Base: {ablation2_rmse - base_rmse:.4f})")
    gc.collect()

    # Ablation 3: No Census Ratio Features
    print("\n--- Running Ablation 3 (No Census Ratio Features) ---")
    train_df_ablation3, _, cat_features_ablation3 = load_and_preprocess_data(
        train_path, None, 
        use_street_group_features=True, 
        use_violation_group_features=True, 
        use_census_ratio_features=False
    )
    _, ablation3_rmse = train_and_predict(train_df_ablation3, None, cat_features_ablation3)
    results['No Census Ratio Features'] = ablation3_rmse
    print(f"Ablation 3 Validation RMSE: {ablation3_rmse:.4f} (Delta from Base: {ablation3_rmse - base_rmse:.4f})")
    gc.collect()


    print("\n--- Ablation Study Results Summary ---")
    final_validation_score = results['Base Case'] # Initialize with Base Case RMSE
    for name, rmse in results.items():
        if name == 'Base Case':
            print(f"  {name}: RMSE = {rmse:.4f}")
        else:
            delta = rmse - results['Base Case']
            print(f"  {name}: RMSE = {rmse:.4f} (Delta from Base: {delta:.4f})")

    # Determine the most impacting part (either most contributing or most detrimental)
    most_impacting_part = None
    largest_impact_delta = 0.0 # This will store the signed delta with the largest absolute value

    for name, rmse in results.items():
        if name != 'Base Case':
            delta = rmse - results['Base Case'] 
            if abs(delta) > abs(largest_impact_delta):
                largest_impact_delta = delta
                most_impacting_part = name
    
    if most_impacting_part is not None:
        if largest_impact_delta > 0:
            print(f"\nConclusion: The '{most_impacting_part}' features contribute the most to the overall performance, as their removal increased RMSE by {largest_impact_delta:.4f}.")
        elif largest_impact_delta < 0:
            print(f"\nConclusion: The '{most_impacting_part}' features are the most detrimental, as their removal improved RMSE by {-largest_impact_delta:.4f}.")
        else:
            print("\nConclusion: No single ablated feature set showed a significant positive or negative contribution in this study (largest RMSE change: 0.0000).")
    else:
        print("\nConclusion: No specific feature set was identified as most impacting.")

    print(f"Final Validation Performance: {final_validation_score}")

if __name__ == "__main__":
    ablation_main()
