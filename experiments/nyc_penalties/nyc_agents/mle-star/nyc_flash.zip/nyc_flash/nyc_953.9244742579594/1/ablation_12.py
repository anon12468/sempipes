
import argparse
import pandas as pd
import numpy as np
import os
import logging
from catboost import CatBoostRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

# Configure logging to suppress INFO messages, only warnings and errors, to keep output clean for ablation
logging.basicConfig(level=logging.WARNING, format='%(asctime)s - %(levelname)s - %(message)s')

def load_and_preprocess_data(file_path):
    """Loads and preprocesses a CSV file."""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")

    df = pd.read_csv(file_path)
    df.columns = [col.strip().replace(' ', '_').lower() for col in df.columns]

    if 'street_name' not in df.columns or 'violation_description' not in df.columns or 'violation_count' not in df.columns:
        raise ValueError("Input file must contain 'Street Name', 'Violation Description', and 'violation_count' columns.")
    
    # Ensure street_name and violation_description are strings for consistency in feature engineering
    df['street_name'] = df['street_name'].astype(str)
    df['violation_description'] = df['violation_description'].astype(str)

    return df

def feature_engineer(df, augmentation_tables_dir="./input", enable_word_counts=True, enable_interaction_feature=True):
    """Applies feature engineering and joins augmentation tables."""
    # Create a unique key for merging and tracking
    df['key'] = df['street_name'].astype(str) + '_' + df['violation_description'].astype(str)

    # --- Augmentation Tables ---
    # These parts are kept as in the base solution from plan_implement_debug_agent_1
    street_codes_path = os.path.join(augmentation_tables_dir, 'street_codes.csv')
    if os.path.exists(street_codes_path):
        try:
            street_codes = pd.read_csv(street_codes_path)
            street_codes.columns = [col.strip().replace(' ', '_').lower() for col in street_codes.columns]
            if 'street_name' in street_codes.columns and 'street_code' in street_codes.columns:
                street_codes_unique = street_codes[['street_name', 'street_code']].drop_duplicates(subset=['street_name'])
                df = df.merge(street_codes_unique, on='street_name', how='left')
        except Exception as e:
            logging.warning(f"Error loading or merging {street_codes_path}: {e}")

    borough_data_path = os.path.join(augmentation_tables_dir, 'borough_data.csv')
    if os.path.exists(borough_data_path):
        try:
            borough_data = pd.read_csv(borough_data_path)
            borough_data.columns = [col.strip().replace(' ', '_').lower() for col in borough_data.columns]
            if 'street_name' in borough_data.columns and 'borough' in borough_data.columns:
                borough_data_unique = borough_data[['street_name', 'borough']].drop_duplicates(subset=['street_name'])
                df = df.merge(borough_data_unique, on='street_name', how='left')
        except Exception as e:
            logging.warning(f"Error loading or merging {borough_data_path}: {e}")

    census_data_path = os.path.join(augmentation_tables_dir, 'census_data.csv')
    if os.path.exists(census_data_path):
        try:
            census_data = pd.read_csv(census_data_path)
            census_data.columns = [col.strip().replace(' ', '_').lower() for col in census_data.columns]
            if 'street_name' in census_data.columns:
                census_data_unique = census_data.drop_duplicates(subset=['street_name'])
                df = df.merge(census_data_unique, on='street_name', how='left')
        except Exception as e:
            logging.warning(f"Error loading or merging {census_data_path}: {e}")

    # --- Derived Features ---
    df['street_name_len'] = df['street_name'].apply(lambda x: len(x) if pd.notna(x) else 0)
    df['violation_desc_len'] = df['violation_description'].apply(lambda x: len(x) if pd.notna(x) else 0)

    # Ablation point 1: Word Count Features
    if enable_word_counts:
        df['street_name_word_count'] = df['street_name'].apply(lambda x: len(x.split()) if pd.notna(x) else 0)
        df['violation_desc_word_count'] = df['violation_description'].apply(lambda x: len(x.split()) if pd.notna(x) else 0)

    # Ablation point 2: Interaction feature (street_name_len * violation_desc_len)
    if enable_interaction_feature:
        df['street_violation_interaction'] = df['street_name_len'] * df['violation_desc_len']

    return df

def train_model(X_train, y_train, X_val, y_val, categorical_features_indices):
    """Trains the CatBoost model."""
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=8,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Suppress verbose output during ablation runs
        early_stopping_rounds=50,
        cat_features=categorical_features_indices,
        use_best_model=True
    )

    model.fit(
        X_train, y_train,
        eval_set=(X_val, y_val),
        plot=False
    )
    return model

def run_ablation(train_path, description, enable_word_counts, enable_interaction_feature, fill_nan_category):
    """Runs a single ablation scenario and returns validation RMSE."""
    
    df = load_and_preprocess_data(train_path)
    df = feature_engineer(df, enable_word_counts=enable_word_counts, enable_interaction_feature=enable_interaction_feature)

    initial_categorical_features = ['street_name', 'violation_description', 'street_code', 'borough']
    categorical_features = [col for col in initial_categorical_features if col in df.columns]

    for col in categorical_features:
        if fill_nan_category: # Ablation point 3: Categorical NaN handling
            # Original handling: convert to str, then fill explicit 'NaN_Category'
            df[col] = df[col].astype(str).fillna('NaN_Category')
        else:
            # Alternative handling: convert to 'category' dtype, let CatBoost handle NaNs natively
            # This will treat np.nan or pd.NA as a special internal category.
            # If after .astype(str) there are 'nan' strings, they would remain 'nan' string values and CatBoost would treat them as a category.
            df[col] = df[col].astype('category')

    features = [col for col in df.columns if col not in ['violation_count', 'key']]
    X = df[features]
    y = df['violation_count']

    # Ensure categorical_features_indices are correctly mapped to X.columns
    actual_categorical_features = [col for col in categorical_features if col in X.columns]
    categorical_features_indices = [X.columns.get_loc(col) for col in actual_categorical_features]

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42, shuffle=True)
    
    model = train_model(X_train, y_train, X_val, y_val, categorical_features_indices)

    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    print(f"{description}: {val_rmse:.4f}")
    return val_rmse

def main_ablation_study():
    parser = argparse.ArgumentParser(description="Ablation study for NYC parking violations prediction.")
    parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV file.")
    args = parser.parse_args()

    results = {}

    # Base Case (all features/settings enabled as per `plan_implement_debug_agent_1`'s final code)
    print("Running Base Case...")
    base_rmse = run_ablation(args.train_path, "Base Case RMSE", 
                             enable_word_counts=True, enable_interaction_feature=True,
                             fill_nan_category=True)
    results["Base Case"] = base_rmse

    # Ablation 1: No Word Count Features
    print("Running Ablation 1: No Word Count Features...")
    abl1_rmse = run_ablation(args.train_path, "Ablation 1 (No Word Count Features) RMSE", 
                             enable_word_counts=False, enable_interaction_feature=True,
                             fill_nan_category=True)
    results["Ablation 1 (No Word Count Features)"] = abl1_rmse

    # Ablation 2: No street_violation_interaction feature
    print("Running Ablation 2: No Street-Violation Interaction Feature...")
    abl2_rmse = run_ablation(args.train_path, "Ablation 2 (No Street-Violation Interaction Feature) RMSE",
                             enable_word_counts=True, enable_interaction_feature=False,
                             fill_nan_category=True)
    results["Ablation 2 (No Street-Violation Interaction Feature)"] = abl2_rmse

    # Ablation 3: Alternative Categorical NaN Handling (just use 'category' dtype, no explicit 'NaN_Category' string)
    print("Running Ablation 3: Categorical NaN handling (rely on CatBoost native 'category' type)...")
    abl3_rmse = run_ablation(args.train_path, "Ablation 3 (Categorical NaN handling) RMSE",
                             enable_word_counts=True, enable_interaction_feature=True,
                             fill_nan_category=False)
    results["Ablation 3 (Categorical NaN handling)"] = abl3_rmse

    diffs = {
        "Word Count Features": abl1_rmse - base_rmse,
        "Street-Violation Interaction Feature": abl2_rmse - base_rmse,
        "Explicit 'NaN_Category' filling": abl3_rmse - base_rmse # This is the effect of turning it OFF, so if diff > 0, turning off was bad, so it was beneficial.
    }

    print("\n--- Ablation Study Summary ---")
    for name, rmse_val in results.items():
        print(f"{name}: {rmse_val:.4f}")
    
    # Determine the component with the largest absolute impact on RMSE
    max_abs_impact = 0.0
    most_impactful_component = "Base Case (no single part showed a significantly larger positive or negative contribution)"
    impact_type = "" # "positive contributor" or "detrimental"

    for component, diff in diffs.items():
        if abs(diff) > max_abs_impact:
            max_abs_impact = abs(diff)
            most_impactful_component = component
            if diff > 0: # Removal of component worsened performance, so component is a positive contributor
                impact_type = "a positive contributor (its removal caused degradation)"
            else: # Removal of component improved performance, so component is detrimental
                impact_type = "detrimental (its removal caused improvement)"
    
    print("\n--- Conclusion ---")
    if max_abs_impact > 0.001: # Check for meaningful impact (threshold for negligible change)
        if impact_type == "a positive contributor (its removal caused degradation)":
            print(f"The most contributing part (its removal caused the largest performance degradation) is: {most_impactful_component}. RMSE increased by {diffs[most_impactful_component]:.4f}.")
        else: # detrimental
            # For 'Explicit NaN_Category filling', a negative diff means *not filling* improved performance.
            # So, the filling itself was detrimental.
            if most_impactful_component == "Explicit 'NaN_Category' filling":
                 print(f"The most impactful part (its presence was detrimental, its removal caused the largest performance improvement) is: {most_impactful_component}. RMSE decreased by {-diffs[most_impactful_component]:.4f}.")
            else:
                 print(f"The most impactful part (its removal caused the largest performance improvement) is: {most_impactful_component}. RMSE decreased by {-diffs[most_impactful_component]:.4f}.")
    else:
        print("No single part showed a significantly larger positive or negative contribution from these ablations.")

# Ensure the script runs the ablation study when executed
if __name__ == "__main__":
    main_ablation_study()
