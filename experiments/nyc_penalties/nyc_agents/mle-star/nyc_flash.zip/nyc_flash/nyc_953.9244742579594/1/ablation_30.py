
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys
from io import StringIO # For creating dummy CSVs

# --- Helper functions (copied from original solution) ---

def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    return df

def load_and_preprocess_data(train_path, test_path=None):
    """
    Loads, preprocesses, and merges data from various sources.
    Handles memory efficiency by selective column loading, aggregation, and garbage collection.
    """
    # print("Loading and preprocessing data...") # Commented out for cleaner ablation output

    # --- Load Core Data ---
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)

    test_df_raw = None
    if test_path:
        test_df_raw = pd.read_csv(test_path)
        test_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
        test_df_raw['is_pure_prediction'] = test_df_raw['violation_count'].isna()
        test_df_raw = downcast_dtypes(test_df_raw)

    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_keys_test = pd.DataFrame()
    if test_df_raw is not None:
        combined_keys_test = test_df_raw[['street_name', 'violation_description']].drop_duplicates()

    combined_df = pd.concat([combined_keys_train, combined_keys_test], ignore_index=True).drop_duplicates().reset_index(drop=True)
    del combined_keys_train, combined_keys_test
    gc.collect()

    # --- Feature Engineering and Augmentation ---
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
        except Exception as e:
            pass # print(f"Error loading or merging {street_data_path}: {e}. Skipping street data augmentation.")
    else:
        pass # print(f"Warning: {street_data_path} not found. Skipping street data augmentation.")

    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
        except Exception as e:
            pass # print(f"Error loading or merging {violation_codes_path}: {e}. Skipping violation codes augmentation.")
    else:
        pass # print(f"Warning: {violation_codes_path} not found. Skipping violation codes augmentation.")

    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        if 'borough' in combined_df.columns:
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
            except Exception as e:
                pass # print(f"Error loading or merging {census_data_path}: {e}. Skipping census data augmentation.")
        else:
            pass # print("Warning: Borough information not available in combined_df to merge census data. Skipping.")
    else:
        pass # print(f"Warning: {census_data_path} not found. Skipping census data augmentation.")

    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    test_processed_df = None
    if test_df_raw is not None:
        test_processed_df = pd.merge(test_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
        del test_df_raw
        gc.collect()

    categorical_features = [col for col in combined_df.columns if combined_df[col].dtype in ['object', 'category']]
    categorical_features = [col for col in categorical_features if col in train_processed_df.columns]

    for col in categorical_features:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].astype('category')
        if test_processed_df is not None and col in test_processed_df.columns:
            test_processed_df[col] = test_processed_df[col].astype('category')

    return train_processed_df, test_processed_df, categorical_features

def train_and_predict(train_df, test_df, categorical_features, catboost_params=None):
    """
    Trains a CatBoost Regressor model and generates predictions.
    Reports RMSE for validation.
    """
    # print("Training CatBoost model...") # Commented out for cleaner ablation output

    features = [col for col in train_df.columns if col not in ['violation_count', 'is_pure_prediction']] # Exclude is_pure_prediction if it accidentally makes it to train_df
    target = 'vi_count' # Using a generic target name to avoid conflict with actual 'violation_count'
    # Rename target column in df for internal consistency with fixed list 'features'
    train_df = train_df.rename(columns={'violation_count': target})

    X = train_df[features]
    y = train_df[target]

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    model_params = {
        'iterations': 1000,
        'learning_rate': 0.05,
        'depth': 6,
        'l2_leaf_reg': 3,
        'subsample': 0.8,
        'colsample_bylevel': 0.7,
        'loss_function': 'RMSE',
        'eval_metric': 'RMSE',
        'random_seed': 42,
        'verbose': 0, # Set to 0 for silent training during ablation
        'early_stopping_rounds': 50,
        'grow_policy': 'Lossguide',
        'max_leaves': 31
    }
    if catboost_params:
        model_params.update(catboost_params)

    model = CatBoostRegressor(**model_params)

    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        # print(f"Error during CatBoost training: {e}")
        raise

    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    return val_rmse

# --- Dummy Data Creation (for self-contained execution) ---
def create_dummy_data_if_not_exists():
    if not os.path.exists('./input'):
        os.makedirs('./input')

    train_data = """street_name,violation_description,violation_count
Main St,PARKING OVERTIME,100
Elm St,NO STANDING,50
Oak Ave,FIRE HYDRANT,200
Main St,NO PARKING,120
Elm St,PARKING OVERTIME,60
Maple Rd,NO STANDING,70
Cedar Blvd,FIRE HYDRANT,250
Main St,FIRE HYDRANT,150
Oak Ave,NO PARKING,90
Pine St,PARKING OVERTIME,40
Willow Ln,NO STANDING,30
Main St,PARKING OVERTIME,110
Fifth Ave,DOUBLE PARKING,300
Fifth Ave,NO STANDING,180
Broadway,NO PARKING,220
Broadway,FIRE HYDRANT,350
First St,PARKING METER EXPIRED,80
Second St,NO STANDING,45
Third Ave,FIRE LANE,130
Fourth St,LOAD/UNLOAD ZONE,160
Sixth Ave,NO STOPPING,270
Seventh St,HANDICAP ZONE,95
Eighth Ave,BUS STOP,140
Ninth St,COMMERCIAL VEHICLE,190
Tenth Ave,ALTERNATE SIDE,210
Main St,PARKING METER EXPIRED,105
Elm St,DOUBLE PARKING,55
Oak Ave,FIRE LANE,210
Fifth Ave,PARKING OVERTIME,290
"""
    if not os.path.exists('./input/violations_per_street_2022.csv'):
        with open('./input/violations_per_street_2022.csv', 'w') as f:
            f.write(train_data)

    street_data = """Street Name,Borough,Street Length,Number of Lanes
Main St,Manhattan,1000,4
Elm St,Brooklyn,800,2
Oak Ave,Bronx,500,2
Maple Rd,Queens,1200,3
Cedar Blvd,Manhattan,1500,4
Pine St,Staten Island,700,2
Willow Ln,Brooklyn,600,2
Fifth Ave,Manhattan,2000,6
Broadway,Manhattan,3000,6
First St,Brooklyn,400,2
Second St,Brooklyn,450,2
Third Ave,Bronx,550,3
Fourth St,Bronx,600,3
Sixth Ave,Manhattan,2500,8
Seventh St,Queens,800,2
Eighth Ave,Queens,900,2
Ninth St,Staten Island,1000,3
Tenth Ave,Staten Island,1100,3
"""
    if not os.path.exists('./input/nyc_street_data.csv'):
        with open('./input/nyc_street_data.csv', 'w') as f:
            f.write(street_data)

    violation_codes_data = """Violation Description,Fine Amount,Points
PARKING OVERTIME,65,0
NO STANDING,115,0
FIRE HYDRANT,165,2
NO PARKING,60,0
DOUBLE PARKING,120,0
PARKING METER EXPIRED,50,0
FIRE LANE,150,2
LOAD/UNLOAD ZONE,80,0
NO STOPPING,130,0
HANDICAP ZONE,250,3
BUS STOP,100,0
COMMERCIAL VEHICLE,90,0
ALTERNATE SIDE,75,0
"""
    if not os.path.exists('./input/nyc_violation_codes.csv'):
        with open('./input/nyc_violation_codes.csv', 'w') as f:
            f.write(violation_codes_data)

    census_data = """Borough,Population Density,Avg Income
Manhattan,27000,100000
Brooklyn,15000,75000
Bronx,13000,60000
Queens,8000,80000
Staten Island,6000,90000
"""
    if not os.path.exists('./input/nyc_census_data.csv'):
        with open('./input/nyc_census_data.csv', 'w') as f:
            f.write(census_data)

create_dummy_data_if_not_exists()


# --- Ablation Study ---

results = {}

# BASE CASE
print("Running Base Case...")
base_train_df, _, base_categorical_features = load_and_preprocess_data(
    './input/violations_per_street_2022.csv', None
)
base_rmse = train_and_predict(base_train_df, None, base_categorical_features)
results['Base Case'] = base_rmse
print(f"Base Case Validation RMSE: {base_rmse:.4f}")
print("-" * 30)

# ABLATION 1: No Basic Length Features (street_name_len, violation_desc_len)
print("Running Ablation 1: No Basic Length Features (street_name_len, violation_desc_len)")
# Create a modified version of load_and_preprocess_data for ablation 1
def load_and_preprocess_data_ablation1(train_path, test_path=None):
    # Copy original logic up to feature engineering
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)
    test_df_raw = None
    if test_path:
        test_df_raw = pd.read_csv(test_path)
        test_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
        test_df_raw['is_pure_prediction'] = test_df_raw['violation_count'].isna()
        test_df_raw = downcast_dtypes(test_df_raw)
    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_keys_test = pd.DataFrame()
    if test_df_raw is not None:
        combined_keys_test = test_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_df = pd.concat([combined_keys_train, combined_keys_test], ignore_index=True).drop_duplicates().reset_index(drop=True)
    del combined_keys_train, combined_keys_test
    gc.collect()

    # --- Feature Engineering and Augmentation ---
    # SKIPPED: combined_df['street_name_len'] and combined_df['violation_desc_len']

    # Remainder of augmentation logic is same as original
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
        except Exception as e: pass

    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
        except Exception as e: pass

    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        if 'borough' in combined_df.columns:
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
            except Exception as e: pass
        else: pass

    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()
    test_processed_df = None
    if test_df_raw is not None:
        test_processed_df = pd.merge(test_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
        del test_df_raw
        gc.collect()

    categorical_features = [col for col in combined_df.columns if combined_df[col].dtype in ['object', 'category']]
    categorical_features = [col for col in categorical_features if col in train_processed_df.columns]

    for col in categorical_features:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].astype('category')
        if test_processed_df is not None and col in test_processed_df.columns:
            test_processed_df[col] = test_processed_df[col].astype('category')
            
    return train_processed_df, test_processed_df, categorical_features

ablation1_train_df, _, ablation1_categorical_features = load_and_preprocess_data_ablation1(
    './input/violations_per_street_2022.csv', None
)
ablation1_rmse = train_and_predict(ablation1_train_df, None, ablation1_categorical_features)
results['Ablation 1: No Basic Length Features'] = ablation1_rmse
print(f"Ablation 1 Validation RMSE: {ablation1_rmse:.4f}")
print("-" * 30)

# ABLATION 2: No `num_lanes` feature
print("Running Ablation 2: No `num_lanes` feature")
# Create a modified version of load_and_preprocess_data for ablation 2
def load_and_preprocess_data_ablation2(train_path, test_path=None):
    # Copy original logic up to street data loading
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)
    test_df_raw = None
    if test_path:
        test_df_raw = pd.read_csv(test_path)
        test_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
        test_df_raw['is_pure_prediction'] = test_df_raw['violation_count'].isna()
        test_df_raw = downcast_dtypes(test_df_raw)
    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_keys_test = pd.DataFrame()
    if test_df_raw is not None:
        combined_keys_test = test_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_df = pd.concat([combined_keys_train, combined_keys_test], ignore_index=True).drop_duplicates().reset_index(drop=True)
    del combined_keys_train, combined_keys_test
    gc.collect()

    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # Augmentation 1: nyc_street_data.csv - MODIFIED to exclude 'Number of Lanes'
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length']) # MODIFIED
            street_data.columns = ['street_name', 'borough', 'street_length'] # MODIFIED
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
        except Exception as e: pass
    else: pass

    # Remainder of augmentation logic is same as original
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
        except Exception as e: pass
    else: pass

    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        if 'borough' in combined_df.columns:
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
            except Exception as e: pass
        else: pass
    else: pass

    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()
    test_processed_df = None
    if test_df_raw is not None:
        test_processed_df = pd.merge(test_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
        del test_df_raw
        gc.collect()

    categorical_features = [col for col in combined_df.columns if combined_df[col].dtype in ['object', 'category']]
    categorical_features = [col for col in categorical_features if col in train_processed_df.columns]

    for col in categorical_features:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].astype('category')
        if test_processed_df is not None and col in test_processed_df.columns:
            test_processed_df[col] = test_processed_df[col].astype('category')
            
    return train_processed_df, test_processed_df, categorical_features

ablation2_train_df, _, ablation2_categorical_features = load_and_preprocess_data_ablation2(
    './input/violations_per_street_2022.csv', None
)
ablation2_rmse = train_and_predict(ablation2_train_df, None, ablation2_categorical_features)
results['Ablation 2: No num_lanes feature'] = ablation2_rmse
print(f"Ablation 2 Validation RMSE: {ablation2_rmse:.4f}")
print("-" * 30)


# ABLATION 3: CatBoost l2_leaf_reg=0.1
print("Running Ablation 3: CatBoost l2_leaf_reg=0.1")
ablation3_train_df, _, ablation3_categorical_features = load_and_preprocess_data(
    './input/violations_per_street_2022.csv', None
)
ablation3_rmse = train_and_predict(ablation3_train_df, None, ablation3_categorical_features,
                                   catboost_params={'l2_leaf_reg': 0.1})
results['Ablation 3: CatBoost l2_leaf_reg=0.1'] = ablation3_rmse
print(f"Ablation 3 Validation RMSE: {ablation3_rmse:.4f}")
print("-" * 30)

# --- Conclusion ---
print("\nAblation Study Results:")
for name, rmse in results.items():
    delta = rmse - results['Base Case']
    print(f"- {name}: RMSE = {rmse:.4f} (Delta from Base: {delta:+.4f})")

most_impactful_ablation_name = "None"
largest_absolute_delta = 0.0
# The "most contributing part" is interpreted as the component whose modification/removal
# leads to the largest absolute change in RMSE from the base case.
# A positive delta (increase in RMSE) means the original component was beneficial.
# A negative delta (decrease in RMSE) means the original component was detrimental (and its removal/change improved performance).

for name, rmse in results.items():
    if name == 'Base Case':
        continue
    delta = rmse - results['Base Case']
    if abs(delta) > largest_absolute_delta:
        largest_absolute_delta = abs(delta)
        most_impactful_ablation_name = name

print(f"\nConclusion on Most Contributing Part:")
if most_impactful_ablation_name != "None":
    delta = results[most_impactful_ablation_name] - results['Base Case']
    if delta > 0:
        print(f"The modification '{most_impactful_ablation_name}' led to the largest degradation in performance (RMSE increased by {delta:.4f}). This implies the original component was the most beneficial to the model's overall performance among the tested ablations.")
    elif delta < 0:
        print(f"The modification '{most_impactful_ablation_name}' led to the largest improvement in performance (RMSE decreased by {-delta:.4f}). This implies the original component was the most detrimental to the model's overall performance among the tested ablations, and its removal/change was beneficial.")
    else:
        print("No significant change observed across the ablation scenarios, implying no single component had a dominant impact on performance among the tested ablations.")
else:
    print("No significant change observed across the ablation scenarios, implying no single component had a dominant impact on performance among the tested ablations.")
