
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    initial_memory = df.memory_usage(deep=True).sum() / (1024**2)
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            # Also ensure we have enough unique values to make it a category (more than 1)
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
            elif num_unique_values == 1: # If only one unique value, it might not be a useful category
                pass # CatBoost can handle single value categories implicitly or ignore them
            else: # High cardinality object, keep as object or convert to string if CatBoost needs it
                df[col] = df[col].astype(str) # CatBoost handles string categories
    final_memory = df.memory_usage(deep=True).sum() / (1024**2)
    print(f"  Memory reduced from {initial_memory:.2f} MB to {final_memory:.2f} MB for dataframe.")
    return df

def load_all_data(train_path, test_path=None):
    """
    Loads all core and augmentation datasets.
    """
    print("Loading all core and augmentation data...")

    # --- Load Core Data ---
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)
    print(f"Initial train_df loaded. Shape: {train_df_raw.shape}, Memory: {train_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    test_df_raw = None
    if test_path:
        test_df_raw = pd.read_csv(test_path)
        # Check if 'violation_count' column exists in test file
        if 'violation_count' not in test_df_raw.columns:
            test_df_raw['violation_count'] = np.nan # Add if missing for consistent schema
        test_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
        test_df_raw['is_pure_prediction'] = test_df_raw['violation_count'].isna()
        test_df_raw = downcast_dtypes(test_df_raw)
        print(f"Test_df loaded. Shape: {test_df_raw.shape}, Memory: {test_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # --- Load Augmentation Data ---
    nyc_street_data_df = pd.DataFrame()
    nyc_violation_codes_df = pd.DataFrame()
    nyc_census_data_df = pd.DataFrame()

    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        print(f"Loading {street_data_path}...")
        try:
            nyc_street_data_df = pd.read_csv(street_data_path)
            nyc_street_data_df.columns = [col.lower().replace(' ', '_') for col in nyc_street_data_df.columns]
            nyc_street_data_df = nyc_street_data_df.drop_duplicates(subset=['street_name'])
            nyc_street_data_df = downcast_dtypes(nyc_street_data_df)
            print(f"  {street_data_path} loaded. Shape: {nyc_street_data_df.shape}, Memory: {nyc_street_data_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading {street_data_path}: {e}. Initializing as empty DataFrame.")
            nyc_street_data_df = pd.DataFrame()
    else:
        print(f"Warning: {street_data_path} not found. Skipping street data augmentation.")

    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        print(f"Loading {violation_codes_path}...")
        try:
            nyc_violation_codes_df = pd.read_csv(violation_codes_path)
            nyc_violation_codes_df.columns = [col.lower().replace(' ', '_') for col in nyc_violation_codes_df.columns]
            nyc_violation_codes_df = nyc_violation_codes_df.drop_duplicates(subset=['violation_description'])
            nyc_violation_codes_df = downcast_dtypes(nyc_violation_codes_df)
            print(f"  {violation_codes_path} loaded. Shape: {nyc_violation_codes_df.shape}, Memory: {nyc_violation_codes_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading {violation_codes_path}: {e}. Initializing as empty DataFrame.")
            nyc_violation_codes_df = pd.DataFrame()
    else:
        print(f"Warning: {violation_codes_path} not found. Skipping violation codes augmentation.")

    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        print(f"Loading {census_data_path}...")
        try:
            nyc_census_data_df = pd.read_csv(census_data_path)
            nyc_census_data_df.columns = [col.lower().replace(' ', '_') for col in nyc_census_data_df.columns]
            
            numerical_cols_census = nyc_census_data_df.select_dtypes(include=np.number).columns.tolist()
            if 'borough' in nyc_census_data_df.columns and numerical_cols_census:
                nyc_census_data_df = nyc_census_data_df.groupby('borough')[numerical_cols_census].mean().reset_index()
            else: # If no 'borough' or no numerical columns, just keep it as is after renaming
                 pass 
            nyc_census_data_df = downcast_dtypes(nyc_census_data_df)
            print(f"  {census_data_path} loaded. Shape: {nyc_census_data_df.shape}, Memory: {nyc_census_data_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading {census_data_path}: {e}. Initializing as empty DataFrame.")
            nyc_census_data_df = pd.DataFrame()
    else:
        print(f"Warning: {census_data_path} not found. Skipping census data augmentation.")

    return train_df_raw, test_df_raw, nyc_street_data_df, nyc_violation_codes_df, nyc_census_data_df


def _prepare_data_and_engineer_features(df_to_process, nyc_street_data_df, nyc_violation_codes_df, nyc_census_data_df, df_name="df"):
    """
    Helper function to merge external datasets and engineer features for a given dataframe.
    """
    print(f"Engineering features for {df_name}...")
    df_processed = df_to_process.copy()

    # Basic features from core data
    df_processed['street_name_len'] = df_processed['street_name'].apply(len).astype('int16')
    df_processed['violation_desc_len'] = df_processed['violation_description'].apply(len).astype('int16')

    # --- Merge with external datasets ---

    # Merge with street data based on 'street_name'
    if not nyc_street_data_df.empty and 'street_name' in df_processed.columns and 'street_name' in nyc_street_data_df.columns:
        print(f"  Merging {df_name} with street data...")
        street_cols_to_merge = ['street_name'] + [col for col in nyc_street_data_df.columns if col not in df_processed.columns and col != 'street_name']
        df_processed = df_processed.merge(nyc_street_data_df[street_cols_to_merge], on='street_name', how='left')
    else:
        print(f"  Skipping street data merge for {df_name} (either df is empty or 'street_name' missing).")

    # Merge with violation codes data based on 'violation_description'
    if not nyc_violation_codes_df.empty and 'violation_description' in df_processed.columns and 'violation_description' in nyc_violation_codes_df.columns:
        print(f"  Merging {df_name} with violation codes data...")
        violation_cols_to_merge = ['violation_description'] + [col for col in nyc_violation_codes_df.columns if col not in df_processed.columns and col != 'violation_description']
        df_processed = df_processed.merge(nyc_violation_codes_df[violation_cols_to_merge], on='violation_description', how='left')
    else:
        print(f"  Skipping violation codes merge for {df_name} (either df is empty or 'violation_description' missing).")

    # Merge with census data (requires 'borough', typically from street data)
    if not nyc_census_data_df.empty and 'borough' in df_processed.columns and 'borough' in nyc_census_data_df.columns:
        print(f"  Merging {df_name} with census data...")
        census_cols_to_merge = ['borough'] + [col for col in nyc_census_data_df.columns if col not in df_processed.columns and col != 'borough']
        df_processed = df_processed.merge(nyc_census_data_df[census_cols_to_merge], on='borough', how='left')
    else:
        print(f"  Skipping census data merge for {df_name} (either df is empty or 'borough' missing from df_processed or census_data_df).")

    # --- Feature Engineering and Missing Value Handling for new features ---

    # Identify potential new categorical features introduced by merges
    potential_categorical_cols = [
        'borough', 'on_street_name', 'from_street_name', 'to_street_name', # From street_data
        'street_type', # From street_data (example, if exists)
        'violation_category', 'violation_type' # From violation_codes (example, if exists)
    ]
    # Identify potential new numerical features introduced by merges
    potential_numerical_cols = [
        'street_length', 'number_of_lanes', # from nyc_street_data (renamed num_lanes to number_of_lanes for consistency if that's the raw name)
        'fine_amount', 'points', # from nyc_violation_codes
        'population_density', 'avg_income', 'population', 'median_income', 'housing_density' # from nyc_census_data
    ]

    # Handle missing values for new categorical features
    for col in potential_categorical_cols:
        if col in df_processed.columns:
            df_processed[col] = df_processed[col].fillna('Unknown').astype('category')

    # Handle missing values for new numerical features
    for col in potential_numerical_cols:
        if col in df_processed.columns:
            df_processed[col] = df_processed[col].fillna(0) # Using 0 as a simple placeholder

    # Convert remaining object columns to category or string for CatBoost
    for col in df_processed.select_dtypes(include='object').columns:
        num_unique_values = len(df_processed[col].unique())
        num_total_values = len(df_processed[col])
        if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
            df_processed[col] = df_processed[col].astype('category')
        else: # High cardinality or single unique value (if not handled above), treat as string for CatBoost
            df_processed[col] = df_processed[col].astype(str)

    print(f"  Processed {df_name} shape: {df_processed.shape}, Memory: {df_processed.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
    return df_processed


def train_and_predict(train_df_raw, test_df_raw, nyc_street_data_df, nyc_violation_codes_df, nyc_census_data_df):
    """
    Trains a CatBoost Regressor model and generates predictions.
    Reports RMSE for validation and test sets (if ground truth available).
    """
    print("Training CatBoost model...")

    # --- Step 1: Integrate external data and engineer features ---
    train_df_processed = _prepare_data_and_engineer_features(train_df_raw, nyc_street_data_df, nyc_violation_codes_df, nyc_census_data_df, df_name="train_df")
    del train_df_raw # Free memory
    gc.collect()

    test_df_processed = None
    if test_df_raw is not None:
        test_df_processed = _prepare_data_and_engineer_features(test_df_raw, nyc_street_data_df, nyc_violation_codes_df, nyc_census_data_df, df_name="test_df")
        del test_df_raw # Free memory
        gc.collect()

    # --- Step 2: Define features (X) and target (y) for the model ---
    target = 'violation_count'

    # Features to exclude from X
    exclude_features = [target, 'is_pure_prediction']

    # All columns in the processed train_df that are not excluded are potential features
    features = [col for col in train_df_processed.columns if col not in exclude_features]

    # Align features between train and test
    if test_df_processed is not None:
        # Identify features present in training data but not in test data, or vice versa
        train_only_features = set(features) - set(test_df_processed.columns)
        test_only_features = set(test_df_processed.columns) - set(features)

        if train_only_features:
            print(f"Warning: Features {list(train_only_features)} present in training but not in test. These will be dropped from training features for consistency.")
            features = [f for f in features if f not in train_only_features]

        # Add missing features to test_df_processed, filling with appropriate defaults
        for col in test_only_features:
            # Drop features in test_only_features from test_df_processed if they are not in `features`
            test_df_processed = test_df_processed.drop(columns=[col])
        
        # Now, ensure all 'features' are in test_df_processed, adding with defaults if still missing
        for col in features:
            if col not in test_df_processed.columns:
                if train_df_processed[col].dtype.name == 'category' or train_df_processed[col].dtype == object:
                    # For categorical, fill with 'Unknown' and ensure type matches training
                    test_df_processed[col] = 'Unknown'
                    test_df_processed[col] = test_df_processed[col].astype(train_df_processed[col].dtype)
                else:
                    # For numerical, fill with 0 and ensure type matches training
                    test_df_processed[col] = 0
                    test_df_processed[col] = test_df_processed[col].astype(train_df_processed[col].dtype)
    
    X = train_df_processed[features]
    y = train_df_processed[target]

    # --- Step 3: Determine categorical_features list for CatBoost ---
    categorical_features_for_catboost = [col for col in X.columns if X[col].dtype.name == 'category' or X[col].dtype == object]
    
    # Ensure all categorical columns are of 'category' or 'object' dtype for CatBoost
    for col in categorical_features_for_catboost:
        if X[col].dtype != 'category':
             X[col] = X[col].astype('category')
        if test_df_processed is not None and col in test_df_processed.columns and test_df_processed[col].dtype != 'category':
            test_df_processed[col] = test_df_processed[col].astype('category')

    # Split training data for validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    print(f"Training data split: X_train={X_train.shape}, X_val={X_val.shape}")

    # Initialize CatBoost Regressor with OOM-conscious parameters
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6,
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=100,
        early_stopping_rounds=50,
        # thread_count=-1,
        # grow_policy='Lossguide',
        # max_leaves=31
    )

    # Train the model
    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features_for_catboost if col in X_train.columns]
    
    print(f"Categorical features used by CatBoost: {categorical_features_for_catboost}")
    print(f"Categorical feature indices for CatBoost: {cat_features_indices}")

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        print("This might indicate an issue with data format or extreme memory pressure even with optimized parameters.")
        raise

    # Validate on internal validation set
    val_preds = model.predict(X_val)
    val_preds[val_preds < 0] = 0 # Ensure predictions are non-negative
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    print(f"Development Validation RMSE: {val_rmse}")

    submission_df = None
    if test_df_processed is not None:
        print("Generating predictions for test data...")
        # Use the same features for prediction as used for training
        X_test = test_df_processed[features]

        test_preds = model.predict(X_test)
        # Ensure predictions are non-negative
        test_preds[test_preds < 0] = 0

        submission_df = test_df_processed[['street_name', 'violation_description']].copy()
        submission_df['predicted_count'] = test_preds

        # Report RMSE if ground truth is available in test_df (not pure prediction)
        if 'is_pure_prediction' in test_df_processed.columns and not test_df_processed['is_pure_prediction'].all():
            ground_truth_test_df_with_preds = submission_df.copy()
            ground_truth_test_df_with_preds['violation_count'] = test_df_processed['violation_count']
            ground_truth_test_df_with_preds = ground_truth_test_df_with_preds[~test_df_processed['is_pure_prediction']]

            if not ground_truth_test_df_with_preds.empty:
                test_rmse = np.sqrt(mean_squared_error(ground_truth_test_df_with_preds['violation_count'], ground_truth_test_df_with_preds['predicted_count']))
                print(f"RMSE on provided test/evaluation data (with ground truth): {test_rmse}")
            else:
                print("No ground truth available in the test/evaluation data to compute RMSE.")

        # Report unseen key pairs
        train_keys = set(train_df_processed.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
        test_keys = set(test_df_processed.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
        unseen_keys_count = len(test_keys - train_keys)
        print(f"Number of (street_name, violation_description) pairs in test/eval unseen in training: {unseen_keys_count}")
        print("Unseen keys are handled by CatBoost's internal mechanism for new categorical levels (assigned to an 'unknown' category or implicitly handled).")

    return submission_df, val_rmse

def main():
    """
    Main function to parse arguments, orchestrate data loading, training, and prediction.
    """
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional path to the 2023 test/evaluation data CSV. '
                             'If provided, predictions will be generated and RMSE reported if ground truth exists.')
    args = parser.parse_args()

    # Load all raw dataframes
    train_df_raw, test_df_raw, nyc_street_data_df, nyc_violation_codes_df, nyc_census_data_df = \
        load_all_data(args.train_path, args.test_path)
    
    # Pass all loaded dataframes to the training and prediction function
    submission_df, final_validation_score = train_and_predict(
        train_df_raw, test_df_raw, nyc_street_data_df, nyc_violation_codes_df, nyc_census_data_df
    )

    if submission_df is not None:
        submission_df.to_csv('submission.csv', index=False)
        print("Submission file 'submission.csv' generated successfully.")

    # Always print the final validation score
    print(f"Final Validation Performance: {final_validation_score}")

if __name__ == "__main__":
    main()
