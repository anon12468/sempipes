
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    return df

def load_and_preprocess_data(train_path):
    """
    Loads, preprocesses, and merges data from various sources.
    Handles memory efficiency by selective column loading, aggregation, and garbage collection.
    No test data is loaded as per ablation study requirements.
    """
    # --- Load Core Data ---
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)

    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_df = combined_keys_train.reset_index(drop=True)
    del combined_keys_train
    gc.collect()

    # --- Feature Engineering and Augmentation ---

    # Basic features from core data
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16') # Corrected typo

    # Feature Engineering: Extract street_type from street_name suffix
    street_suffix_map = {
        'ST': 'STREET', 'STREET': 'STREET', 'AVE': 'AVENUE', 'AVENUE': 'AVENUE',
        'RD': 'ROAD', 'ROAD': 'ROAD', 'BLVD': 'BOULEVARD', 'BOULEVARD': 'BOULEVARD',
        'PKWY': 'PARKWAY', 'PARKWAY': 'PARKWAY', 'LN': 'LANE', 'LANE': 'LANE',
        'DR': 'DRIVE', 'DRIVE': 'DRIVE', 'SQ': 'SQUARE', 'SQUARE': 'SQUARE',
        'PL': 'PLACE', 'PLACE': 'PLACE', 'CT': 'COURT', 'COURT': 'COURT',
        'TER': 'TERRACE', 'TERRACE': 'TERRACE', 'WY': 'WAY', 'WAY': 'WAY',
        'CIR': 'CIRCLE', 'CIRCLE': 'CIRCLE', 'HWY': 'HIGHWAY', 'HIGHWAY': 'HIGHWAY',
        'FWY': 'FREEWAY', 'FREEWAY': 'FREEWAY', 'ALY': 'ALLEY', 'ALLEY': 'ALLEY',
        'RUN': 'RUN', 'GATE': 'GATE', 'WALK': 'WALK', 'PLAZA': 'PLAZA',
        'MALL': 'MALL', 'CONC': 'CONCOURSE', 'CONCOURSE': 'CONCOURSE',
        'EXPY': 'EXPRESSWAY', 'EXPRESSWAY': 'EXPRESSWAY', 'PKY': 'PARKWAY',
        'PT': 'POINT', 'POINT': 'POINT', 'TRL': 'TRAIL', 'TRAIL': 'TRAIL',
        'VW': 'VIEW', 'VIEW': 'VIEW', 'XING': 'CROSSING', 'CROSSING': 'CROSSING',
        'CR': 'CRESCENT', 'CRESCENT': 'CRESCENT', 'ROW': 'ROW', 'LOOP': 'LOOP',
        'COVE': 'COVE', 'PATH': 'PATH', 'VLY': 'VALLEY', 'VALLEY': 'VALLEY',
        'DIV': 'DIVIDE', 'DIVIDE': 'DIVIDE'
    }

    processed_street_map = {}
    for k, v in street_suffix_map.items():
        processed_street_map[k.upper().strip('.')] = v.upper()
        for direction in ['N', 'S', 'E', 'W', 'NORTH', 'SOUTH', 'EAST', 'WEST']:
            processed_street_map[f"{k.upper().strip('.')} {direction}"] = v.upper()
            processed_street_map[f"{k.upper().strip('.')}{direction}"] = v.upper()

    def get_street_type_from_suffix(street_name):
        if not isinstance(street_name, str): return 'OTHER'
        s_name_upper = street_name.upper().strip()
        for suffix_key in sorted(processed_street_map.keys(), key=len, reverse=True):
            if s_name_upper.endswith(suffix_key): return processed_street_map[suffix_key]
        parts = s_name_upper.split()
        if not parts: return 'OTHER'
        last_word = parts[-1].strip('.').strip(',')
        if last_word in processed_street_map: return processed_street_map[last_word]
        if len(parts) >= 2:
            second_last_word = parts[-2].strip('.').strip(',')
            if second_last_word in processed_street_map: return processed_street_map[second_last_word]
        return 'OTHER'

    combined_df['street_type'] = combined_df['street_name'].apply(get_street_type_from_suffix).astype('category')

    # Feature Engineering: Extract violation_category from violation_description keywords
    violation_keywords = {
        'NO PARKING': 'NO PARKING', 'HANDICAP': 'HANDICAP', 'FIRE LANE': 'FIRE LANE',
        'BUS STOP': 'BUS STOP', 'HYDRANT': 'HYDRANT', 'STANDING': 'STANDING',
        'METER': 'METER', 'COMMERCIAL': 'COMMERCIAL', 'LOADING': 'LOADING',
        'RESIDENTIAL': 'RESIDENTIAL', 'DOUBLE PARKING': 'DOUBLE PARKING',
        'OVERTIME': 'OVERTIME', 'EXPIRED': 'EXPIRED', 'CLEANING': 'STREET CLEANING',
        'STREET CLEANING': 'STREET CLEANING', 'PERMIT': 'PERMIT REQUIRED',
        'SAFETY ZONE': 'SAFETY ZONE', 'DRIVEWAY': 'DRIVEWAY', 'SIDEWALK': 'SIDEWALK',
        'NO STANDING': 'NO STANDING', 'CROSSWALK': 'CROSSWALK', 'INTERSECTION': 'INTERSECTION'
    }
    sorted_keywords = sorted(violation_keywords.keys(), key=len, reverse=True)

    def extract_violation_category(description):
        if not isinstance(description, str): return 'OTHER'
        desc_upper = description.upper()
        for keyword in sorted_keywords:
            if keyword in desc_upper: return violation_keywords[keyword]
        return 'OTHER'

    combined_df['violation_category'] = combined_df['violation_description'].apply(extract_violation_category).astype('category')

    # External Augmentations (warnings and errors suppressed for ablation study)
    external_data_paths = {
        'street_data': './input/nyc_street_data.csv',
        'violation_codes': './input/nyc_violation_codes.csv',
        'census_data': './input/nyc_census_data.csv'
    }

    if os.path.exists(external_data_paths['street_data']):
        try:
            street_data = pd.read_csv(external_data_paths['street_data'], usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data).drop_duplicates(subset=['street_name'])
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data; gc.collect()
        except Exception: pass

    if os.path.exists(external_data_paths['violation_codes']):
        try:
            violation_codes = pd.read_csv(external_data_paths['violation_codes'], usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes).drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes; gc.collect()
        except Exception: pass

    if os.path.exists(external_data_paths['census_data']) and 'borough' in combined_df.columns:
        try:
            census_data = pd.read_csv(external_data_paths['census_data'])
            census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
            relevant_census_cols = ['borough', 'population_density', 'avg_income']
            if all(col in census_data.columns for col in relevant_census_cols):
                census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                census_agg = downcast_dtypes(census_agg)
                combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                del census_data, census_agg; gc.collect()
        except Exception: pass

    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw; gc.collect()

    # --- Handle NaN values and ensure 'category' dtype for CatBoost ---
    final_categorical_cols = ['street_name', 'violation_description', 'street_type', 'violation_category']
    if 'borough' in train_processed_df.columns:
        final_categorical_cols.append('borough')

    for col in final_categorical_cols:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].astype(str).fillna('Unknown_Category').astype('category')
            
    categorical_features = final_categorical_cols

    return train_processed_df, None, categorical_features

def train_and_predict_ablation(train_df, categorical_features,
                               grow_policy_lossguide=False,
                               subsample_rate=1.0,
                               l2_leaf_regularization=3):
    """
    Trains a CatBoost Regressor model and generates predictions.
    Reports RMSE for validation.
    """
    features = [col for col in train_df.columns if col not in ['violation_count']]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    model_params = {
        'iterations': 1000,
        'learning_rate': 0.05,
        'depth': 6,
        'l2_leaf_reg': l2_leaf_regularization,
        'loss_function': 'RMSE',
        'eval_metric': 'RMSE',
        'random_seed': 42,
        'verbose': 0, # Suppress verbose output for ablation
        'early_stopping_rounds': 50,
        'thread_count': -1,
    }

    if grow_policy_lossguide:
        model_params['grow_policy'] = 'Lossguide'
        model_params['max_leaves'] = 31

    if subsample_rate < 1.0:
        model_params['subsample'] = subsample_rate
        # CatBoost uses 'MVS' bootstrap_type by default when subsample < 1.0

    model = CatBoostRegressor(**model_params)

    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                  use_best_model=False # Explicitly setting to False as per original code's commented state
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        raise

    val_preds = model.predict(X_val)
    val_preds[val_preds < 0] = 0
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))

    return val_rmse

def main():
    parser = argparse.ArgumentParser(description="Perform ablation study on NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()

    print("Starting ablation study...")
    
    train_df, _, categorical_features = load_and_preprocess_data(args.train_path)

    results = {}

    # --- Base Case ---
    print("\n--- Running Base Case ---")
    base_rmse = train_and_predict_ablation(train_df.copy(), categorical_features.copy())
    results['Base Case'] = base_rmse
    print(f"Base Case Validation RMSE: {base_rmse:.4f}")

    # --- Ablation 1: Enable CatBoost grow_policy='Lossguide' ---
    print("\n--- Running Ablation 1: Enable CatBoost grow_policy='Lossguide' ---")
    ablation1_rmse = train_and_predict_ablation(train_df.copy(), categorical_features.copy(),
                                               grow_policy_lossguide=True)
    results["Enable grow_policy='Lossguide'"] = ablation1_rmse
    print(f"Ablation 1 Validation RMSE: {ablation1_rmse:.4f} (Delta: {ablation1_rmse - base_rmse:.4f})")

    # --- Ablation 2: Enable CatBoost subsample=0.8 ---
    print("\n--- Running Ablation 2: Enable CatBoost subsample=0.8 ---")
    ablation2_rmse = train_and_predict_ablation(train_df.copy(), categorical_features.copy(),
                                               subsample_rate=0.8)
    results["Enable subsample=0.8"] = ablation2_rmse
    print(f"Ablation 2 Validation RMSE: {ablation2_rmse:.4f} (Delta: {ablation2_rmse - base_rmse:.4f})")

    # --- Ablation 3: Change CatBoost l2_leaf_reg=5 ---
    print("\n--- Running Ablation 3: Change CatBoost l2_leaf_reg=5 ---")
    ablation3_rmse = train_and_predict_ablation(train_df.copy(), categorical_features.copy(),
                                               l2_leaf_regularization=5)
    results["Change l2_leaf_reg=5"] = ablation3_rmse
    print(f"Ablation 3 Validation RMSE: {ablation3_rmse:.4f} (Delta: {ablation3_rmse - base_rmse:.4f})")

    print("\n--- Ablation Study Summary ---")
    for name, rmse in results.items():
        print(f"{name}: RMSE = {rmse:.4f}")
    
    # Determine the most contributing part (largest improvement or largest degradation for negative contributions)
    best_improvement_delta = 0
    most_beneficial_part = "Base Case (no changes)"

    worst_degradation_delta = 0
    most_detrimental_part = "None"

    # Compare ablations to base case
    for name, rmse in results.items():
        if name == 'Base Case':
            continue
        delta = rmse - base_rmse # Positive delta means worse, negative delta means better

        if delta < best_improvement_delta: # Larger negative delta (more improvement)
            best_improvement_delta = delta
            most_beneficial_part = name
        
        if delta > worst_degradation_delta: # Larger positive delta (more degradation)
            worst_degradation_delta = delta
            most_detrimental_part = name
    
    print("\n--- Conclusion ---")
    if best_improvement_delta < 0:
        print(f"The most contributing part to overall performance (largest improvement) was '{most_beneficial_part}', which improved RMSE by {-best_improvement_delta:.4f}.")
    elif worst_degradation_delta > 0:
        print(f"The most contributing part to overall performance (largest degradation) was '{most_detrimental_part}', which worsened RMSE by {worst_degradation_delta:.4f}.")
    else:
        print("No significant change observed across ablations or base case was already optimal.")


if __name__ == "__main__":
    main()
