
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    return df

# Modified load_and_preprocess_data to accept ablation flags
def load_and_preprocess_data(train_path, test_path=None, enable_street_length_per_lane=True, enable_contextual_aggregations=True):
    """
    Loads, preprocesses, and merges data from various sources.
    Handles memory efficiency by selective column loading, aggregation, and garbage collection.
    Ablation flags:
        - enable_street_length_per_lane: Controls creation of 'street_length_per_lane' feature.
        - enable_contextual_aggregations: Controls creation of 'avg_street_length_by_violation' and 'avg_num_lanes_by_violation'.
    """
    print("Loading and preprocessing data...")

    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)

    test_df_raw = None
    if test_path:
        test_df_raw = pd.read_csv(test_path)
        test_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
        test_df_raw['is_pure_prediction'] = test_df_raw['violation_count'].isna()
        test_df_raw = downcast_dtypes(test_df_raw)

    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_keys_test = pd.DataFrame()
    if test_df_raw is not None:
        combined_keys_test = test_df_raw[['street_name', 'violation_description']].drop_duplicates()

    combined_df = pd.concat([combined_keys_train, combined_keys_test], ignore_index=True).drop_duplicates().reset_index(drop=True)
    del combined_keys_train, combined_keys_test
    gc.collect()

    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    street_data_path = './input/nyc_street_data.csv'
    street_data_merged_successfully = False
    if os.path.exists(street_data_path):
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'],
                                      dtype={'Street Name': str})
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            
            combined_df['street_name'] = combined_df['street_name'].astype(str)

            initial_cols = combined_df.shape[1]
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            
            if combined_df.shape[1] > initial_cols:
                street_data_merged_successfully = True
            
            del street_data
            gc.collect()
        except Exception as e:
            print(f"Error loading or merging {street_data_path}: {e}. Skipping street data augmentation.")
    else:
        print(f"Warning: {street_data_path} not found. Skipping street data augmentation.")

    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
        except Exception as e:
            print(f"Error loading or merging {violation_codes_path}: {e}. Skipping violation codes augmentation.")
    else:
        print(f"Warning: {violation_codes_path} not found. Skipping violation codes augmentation.")

    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        if 'borough' in combined_df.columns:
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
                else:
                    print(f"Warning: Missing one or more expected columns ({relevant_census_cols}) in {census_data_path}. Skipping census data augmentation.")
            except Exception as e:
                print(f"Error loading or merging {census_data_path}: {e}. Skipping census data augmentation.")
        else:
            print("Warning: Borough information not available in combined_df to merge census data. Skipping.")
    else:
        print(f"Warning: {census_data_path} not found. Skipping census data augmentation.")

    # --- New Feature Engineering based on Improvement Plan ---
    if street_data_merged_successfully:
        if enable_street_length_per_lane:
            combined_df['num_lanes_for_division'] = combined_df['num_lanes'].replace(0, np.nan)
            combined_df['street_length_per_lane'] = combined_df['street_length'] / combined_df['num_lanes_for_division']
            combined_df = combined_df.drop(columns=['num_lanes_for_division'])
            combined_df['street_length_per_lane'] = combined_df['street_length_per_lane'].astype('float32')
        else:
            print("Ablation: Skipping 'street_length_per_lane' feature.")

        if enable_contextual_aggregations:
            combined_df['violation_description'] = combined_df['violation_description'].astype(str)

            violation_agg = combined_df.groupby('violation_description').agg(
                avg_street_length_by_violation=('street_length', 'mean'),
                avg_num_lanes_by_violation=('num_lanes', 'mean')
            ).reset_index()

            violation_agg['avg_street_length_by_violation'] = violation_agg['avg_street_length_by_violation'].astype('float32')
            violation_agg['avg_num_lanes_by_violation'] = violation_agg['avg_num_lanes_by_violation'].astype('float32')
            
            combined_df = pd.merge(combined_df, violation_agg, on='violation_description', how='left')
            
            del violation_agg
            gc.collect()
        else:
            print("Ablation: Skipping contextual aggregation features.")
    else:
        print("Skipping creation of new interaction and aggregation features as street data was not merged successfully.")

    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    test_processed_df = None
    if test_df_raw is not None:
        test_processed_df = pd.merge(test_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
        del test_df_raw
        gc.collect()

    categorical_features = [col for col in combined_df.columns if combined_df[col].dtype in ['object', 'category']]
    categorical_features = [col for col in categorical_features if col in train_processed_df.columns]

    for col in categorical_features:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].astype('category')
        if test_processed_df is not None and col in test_processed_df.columns:
            test_processed_df[col] = test_processed_df[col].astype('category')

    return train_processed_df, test_processed_df, categorical_features

# Modified train_and_predict to accept ablation flags
def train_and_predict(train_df, test_df, categorical_features, catboost_thread_count=-1):
    """
    Trains a CatBoost Regressor model and generates predictions.
    Reports RMSE for validation.
    Ablation flag:
        - catboost_thread_count: Controls the 'thread_count' parameter for CatBoost.
    """
    features = [col for col in train_df.columns if col not in ['violation_count', 'is_pure_prediction']]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6,
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Set to 0 for silent training during ablation
        early_stopping_rounds=50,
        thread_count=catboost_thread_count, # Ablated parameter
    )

    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        raise

    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    
    # We don't generate submission_df for ablation studies
    return val_rmse

def run_ablation_experiment(train_path, test_path, experiment_name,
                            enable_street_length_per_lane=True,
                            enable_contextual_aggregations=True,
                            catboost_thread_count=-1):
    """
    Runs a single ablation experiment and returns its validation RMSE.
    """
    print(f"\n--- Running Experiment: {experiment_name} ---")
    train_df, _, categorical_features = load_and_preprocess_data(
        train_path,
        test_path,
        enable_street_length_per_lane=enable_street_length_per_lane,
        enable_contextual_aggregations=enable_contextual_aggregations
    )
    
    if 'is_pure_prediction' in train_df.columns:
        train_df = train_df.drop(columns=['is_pure_prediction'])

    val_rmse = train_and_predict(train_df, None, categorical_features, catboost_thread_count=catboost_thread_count)
    return val_rmse

def main_ablation():
    """
    Main function to orchestrate the ablation study.
    """
    parser = argparse.ArgumentParser(description="Perform an ablation study on NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default='./input/violations_per_street_2023.csv',
                        help='Path to the 2023 test/evaluation data CSV for combined_df consistency.')
    args = parser.parse_args()

    results = {}

    # Base Case: All new features enabled, default CatBoost thread_count (-1)
    base_case_rmse = run_ablation_experiment(
        args.train_path,
        args.test_path,
        "Base Case",
        enable_street_length_per_lane=True,
        enable_contextual_aggregations=True,
        catboost_thread_count=-1
    )
    results["Base Case"] = base_case_rmse
    print(f"Base Case Validation RMSE: {base_case_rmse:.4f}")

    # Ablation 1: No 'street_length_per_lane' feature
    ablation1_name = "Ablation 1: No 'street_length_per_lane' feature"
    ablation1_rmse = run_ablation_experiment(
        args.train_path,
        args.test_path,
        ablation1_name,
        enable_street_length_per_lane=False,
        enable_contextual_aggregations=True,
        catboost_thread_count=-1
    )
    results[ablation1_name] = ablation1_rmse
    delta1 = ablation1_rmse - base_case_rmse
    print(f"{ablation1_name} Validation RMSE: {ablation1_rmse:.4f}, Delta from Base: {delta1:.4f}")

    # Ablation 2: No Contextual Aggregation features
    ablation2_name = "Ablation 2: No Contextual Aggregation features"
    ablation2_rmse = run_ablation_experiment(
        args.train_path,
        args.test_path,
        ablation2_name,
        enable_street_length_per_lane=True,
        enable_contextual_aggregations=False,
        catboost_thread_count=-1
    )
    results[ablation2_name] = ablation2_rmse
    delta2 = ablation2_rmse - base_case_rmse
    print(f"{ablation2_name} Validation RMSE: {ablation2_rmse:.4f}, Delta from Base: {delta2:.4f}")

    # Ablation 3: CatBoost thread_count = 1 (vs default -1)
    ablation3_name = "Ablation 3: CatBoost thread_count = 1"
    ablation3_rmse = run_ablation_experiment(
        args.train_path,
        args.test_path,
        ablation3_name,
        enable_street_length_per_lane=True,
        enable_contextual_aggregations=True,
        catboost_thread_count=1
    )
    results[ablation3_name] = ablation3_rmse
    delta3 = ablation3_rmse - base_case_rmse
    print(f"{ablation3_name} Validation RMSE: {ablation3_rmse:.4f}, Delta from Base: {delta3:.4f}")

    # Determine most contributing part
    max_abs_delta = 0
    most_contributing_part = "None (or all changes had minimal impact)"

    # Identify the ablation with the largest absolute change from the Base Case
    for name, rmse in results.items():
        if name == "Base Case":
            continue
        current_abs_delta = abs(rmse - base_case_rmse)
        if current_abs_delta > max_abs_delta:
            max_abs_delta = current_abs_delta
            most_contributing_part = name

    print(f"\nConclusion: The most contributing part to the overall performance (based on largest absolute RMSE delta) is: {most_contributing_part}")

if __name__ == "__main__":
    main_ablation()
