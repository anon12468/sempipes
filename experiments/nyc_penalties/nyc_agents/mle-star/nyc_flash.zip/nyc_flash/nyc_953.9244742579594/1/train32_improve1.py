
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import os
import sys

# Function to calculate RMSE
def rmse(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))

def load_data(file_path):
    """Loads CSV data."""
    try:
        df = pd.read_csv(file_path)
        return df
    except FileNotFoundError:
        raise FileNotFoundError(f"Error: File not found at {file_path}")
    except Exception as e:
        raise Exception(f"Error loading {file_path}: {e}")

def preprocess_df(df, is_train_source=True):
    """
    Standardize column names and types.
    is_train_source: True if this DataFrame is the primary 2022 training data (contains target).
                     False if it's the 2023 test/eval data (target is optional for scoring).
    """
    df = df.rename(columns={
        'Street Name': 'street_name',
        'Violation Description': 'violation_type',
        'violation_count': 'violation_count'
    })

    # Ensure required columns are present
    required_cols = ['street_name', 'violation_type']
    if is_train_source:
        required_cols.append('violation_count')

    if not all(col in df.columns for col in required_cols):
        missing = [col for col in required_cols if col not in df.columns]
        raise ValueError(f"Missing required columns in input data: {missing}. Expected: {required_cols}")

    # Convert categorical features to string type
    df['street_name'] = df['street_name'].astype(str)
    df['violation_type'] = df['violation_type'].astype(str)

    # Handle potential NaNs in categorical columns by filling with a placeholder
    df['street_name'] = df['street_name'].fillna('UNKNOWN_STREET')
    df['violation_type'] = df['violation_type'].fillna('UNKNOWN_VIOLATION')

    return df

def create_features(df):
    """
    Creates features from the data for both training/validation and prediction.
    """
    df['street_name_len'] = df['street_name'].apply(len)
    df['violation_type_len'] = df['violation_type'].apply(len)

    # Add interaction features
    df['street_violation_hash'] = df['street_name'] + '_' + df['violation_type']

    return df

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 parking violations training data.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional: Path to the 2023 parking violations test data for prediction/evaluation.')
    parser.add_argument('--violation-codes-path', type=str,
                        default='./input/ParkingViolationCodes_January2020.csv', # Assuming a CSV version
                        help='Path to a CSV file with additional violation code details.')

    args = parser.parse_args()

    # --- Load Primary Training Data (2022 violations) ---
    print(f"Loading training data from {args.train_path}...")
    try:
        raw_train_df_2022 = load_data(args.train_path)
        train_df_2022_processed = preprocess_df(raw_train_df_2022, is_train_source=True)
    except Exception as e:
        print(f"Failed to load or preprocess primary training data: {e}")
        sys.exit(1)

    print(f"Primary training data shape: {train_df_2022_processed.shape}")

    # --- Load Augmentation Data ---
    violation_codes_augment_df = None
    if os.path.exists(args.violation_codes_path):
        print(f"Loading augmentation data: {args.violation_codes_path}")
        try:
            violation_codes_augment_df = load_data(args.violation_codes_path)
            # Assuming it has 'Violation Description' and 'Fine Amount'
            violation_codes_augment_df = violation_codes_augment_df.rename(
                columns={'Violation Description': 'violation_type', 'Fine Amount': 'fine_amount_category_level'}
            )
            # Ensure 'violation_type' is string for merging
            violation_codes_augment_df['violation_type'] = violation_codes_augment_df['violation_type'].astype(str).fillna('UNKNOWN_VIOLATION')

            if 'fine_amount_category_level' in violation_codes_augment_df.columns:
                 # Keep only relevant columns and drop duplicates to avoid merge explosion
                 violation_codes_augment_df = violation_codes_augment_df[['violation_type', 'fine_amount_category_level']].drop_duplicates(subset=['violation_type'])
                 # Handle potential non-numeric 'fine_amount_category_level'
                 violation_codes_augment_df['fine_amount_category_level'] = pd.to_numeric(
                     violation_codes_augment_df['fine_amount_category_level'], errors='coerce'
                 ).fillna(0) # Fill NaNs with 0 if conversion fails
                 print("Augmented data loaded with 'fine_amount_category_level'.")
            else:
                 print("Warning: 'Fine Amount' column not found or not suitable in violation codes augmentation file. Skipping specific augmentation features.")
                 violation_codes_augment_df = None
        except Exception as e:
            print(f"Warning: Could not load or process {args.violation_codes_path}. Error: {e}")
            violation_codes_augment_df = None
    else:
        print(f"Augmentation file not found: {args.violation_codes_path}. Skipping augmentation.")


    # --- Prepare Training Features and Target for internal validation ---
    X_train_val = train_df_2022_processed[['street_name', 'violation_type']].copy()
    y_train_val = train_df_2022_processed['violation_count']

    # Add generic features
    X_train_val = create_features(X_train_val)

    # Augment with violation codes data if available
    if violation_codes_augment_df is not None and 'fine_amount_category_level' in violation_codes_augment_df.columns:
        X_train_val = pd.merge(X_train_val, violation_codes_augment_df, on='violation_type', how='left')
        X_train_val['fine_amount_category_level'] = X_train_val['fine_amount_category_level'].fillna(0)
        print("Merged violation code augmentation features into training set.")

    # Split training data for validation
    print("Splitting training data for internal validation...")
    X_train, X_val, y_train, y_val = train_test_split(X_train_val, y_train_val, test_size=0.2, random_state=42)
    print(f"X_train shape: {X_train.shape}, y_train shape: {y_train.shape}")
    print(f"X_val shape: {X_val.shape}, y_val shape: {y_val.shape}")

    # Define features for the model
    features_to_use = list(X_train.columns)
    categorical_features_names = ['street_name', 'violation_type', 'street_violation_hash']
    # Filter to only include those present in the actual training data
    categorical_features_indices = [features_to_use.index(col) for col in categorical_features_names if col in features_to_use]

    # --- Train CatBoost Model ---
    print("Training CatBoostRegressor model...")
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=8,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=100,
        early_stopping_rounds=100,
        cat_features=categorical_features_indices,
        thread_count=-1, # Use all available CPU cores
        # Other parameters to consider for large datasets/OOM:
        # train_dir='catboost_info',
        # used_ram_limit='10gb',
        # max_ctr_complexity=2,
    )

    model.fit(X_train, y_train,
              eval_set=(X_val, y_val),
              early_stopping_rounds=100,
              verbose=100)

    # --- Evaluate on Validation Set ---
    val_preds = model.predict(X_val)
    val_preds[val_preds < 0] = 0 # Clip negative predictions
    final_validation_score = rmse(y_val, val_preds)
    print(f"Final Validation Performance: {final_validation_score}")

    # --- Prediction on Test Data (2023) ---
    if args.test_path:
        print(f"Loading test data from {args.test_path} for prediction...")
        try:
            raw_test_df_2023 = load_data(args.test_path)
            test_df_2023_processed = preprocess_df(raw_test_df_2023, is_train_source=False)
        except Exception as e:
            print(f"Failed to load or preprocess test data: {e}")
            sys.exit(1)

        print(f"Test data shape: {test_df_2023_processed.shape}")

        # Prepare test features
        X_test = test_df_2023_processed[['street_name', 'violation_type']].copy()
        X_test = create_features(X_test)

        # Augment with violation codes data if available
        if violation_codes_augment_df is not None and 'fine_amount_category_level' in violation_codes_augment_df.columns:
            X_test = pd.merge(X_test, violation_codes_augment_df, on='violation_type', how='left')
            X_test['fine_amount_category_level'] = X_test['fine_amount_category_level'].fillna(0)
            print("Merged violation code augmentation features into test set.")

        # Ensure test features match training features
        # Add missing columns with default values (e.g., 0 for numerical, 'UNKNOWN' for categorical)
        # Drop extra columns not seen during training
        for col in features_to_use:
            if col not in X_test.columns:
                if col in categorical_features_names:
                    X_test[col] = 'UNKNOWN_' + col.upper() # Placeholder for unseen categorical
                else:
                    X_test[col] = 0 # Default for numerical features
        
        extra_in_test = set(X_test.columns) - set(features_to_use)
        if extra_in_test:
            X_test = X_test.drop(columns=list(extra_in_test))

        X_test = X_test[features_to_use] # Ensure column order is the same as training

        # Keep original order for submission
        submission_df = test_df_2023_processed[['street_name', 'violation_type']].copy()

        print("Generating predictions for test data...")
        predictions = model.predict(X_test)
        predictions[predictions < 0] = 0 # Clip negative predictions
        predictions = np.round(predictions).astype(int) # Round to nearest integer for counts

        submission_df['predicted_count'] = predictions

        # --- Report RMSE if ground truth is available in test_path ---
        if 'violation_count' in test_df_2023_processed.columns:
            y_test_true = test_df_2023_processed['violation_count']
            test_rmse = rmse(y_test_true, predictions)
            print(f"RMSE on provided test data (2023 ground truth): {test_rmse}")
        else:
            print("No 'violation_count' column found in test data. Skipping RMSE calculation for test set.")

        # --- Handle unseen key pairs in test set ---
        train_keys_df = train_df_2022_processed[['street_name', 'violation_type']].drop_duplicates()
        train_keys = set(tuple(row) for row in train_keys_df.values)
        test_keys_df = test_df_2023_processed[['street_name', 'violation_type']].drop_duplicates()
        test_keys = set(tuple(row) for row in test_keys_df.values)
        unseen_keys = test_keys - train_keys
        print(f"Number of unseen (street_name, violation_type) pairs in test set: {len(unseen_keys)}")

        # --- Save Submission ---
        submission_df.to_csv('submission.csv', index=False)
        print("Submission file 'submission.csv' created successfully.")

    else:
        print("No test path provided. Skipping final prediction and submission generation.")

if __name__ == "__main__":
    main()
