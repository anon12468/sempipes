
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    # initial_memory = df.memory_usage(deep=True).sum() / (1024**2) # Commented out print for clean output
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    # final_memory = df.memory_usage(deep=True).sum() / (1024**2) # Commented out print for clean output
    # print(f"  Memory reduced from {initial_memory:.2f} MB to {final_memory:.2f} MB for dataframe.")
    return df

def load_and_preprocess_data(train_path, test_path=None,
                             enable_temporal_features=True,
                             enable_frequency_encoding=True,
                             enable_interaction_feature=True):
    """
    Loads, preprocesses, and merges data from various sources.
    Handles memory efficiency by selective column loading, aggregation, and garbage collection.
    Includes flags for ablating new feature groups.
    """
    # print("Loading and preprocessing data...") # Commented out print for clean output

    # --- Load Core Data ---
    # Load training data
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']

    # Add dummy 'issue_datetime' column to train_df_raw for temporal features testing
    # In a real scenario, this column would be present in the raw data.
    if 'issue_datetime' not in train_df_raw.columns:
        train_df_raw['issue_datetime'] = pd.to_datetime('2022-01-01 10:00:00') + pd.to_timedelta(np.arange(len(train_df_raw)), unit='h')
        # print("Added dummy 'issue_datetime' column to train_df_raw for temporal feature testing.") # Commented out print for clean output

    train_df_raw = downcast_dtypes(train_df_raw)
    # print(f"Initial train_df loaded. Shape: {train_df_raw.shape}, Memory: {train_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB") # Commented out print for clean output

    test_df_raw = None
    if test_path:
        test_df_raw = pd.read_csv(test_path)
        test_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
        # Create a flag for pure prediction rows where violation_count is NaN
        test_df_raw['is_pure_prediction'] = test_df_raw['violation_count'].isna()
        # Add dummy 'issue_datetime' to test_df_raw if needed
        if 'issue_datetime' not in test_df_raw.columns:
            test_df_raw['issue_datetime'] = pd.to_datetime('2023-01-01 10:00:00') + pd.to_timedelta(np.arange(len(test_df_raw)), unit='h')
            # print("Added dummy 'issue_datetime' column to test_df_raw for temporal feature testing.") # Commented out print for clean output
        test_df_raw = downcast_dtypes(test_df_raw)
        # print(f"Test_df loaded. Shape: {test_df_raw.shape}, Memory: {test_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB") # Commented out print for clean output

    # Combine unique street_name and violation_description pairs from train and test
    # for consistent feature engineering.
    # Exclude 'violation_count' to prevent target leakage and reduce memory.
    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_keys_test = pd.DataFrame()
    if test_df_raw is not None:
        combined_keys_test = test_df_raw[['street_name', 'violation_description']].drop_duplicates()

    combined_df = pd.concat([combined_keys_train, combined_keys_test], ignore_index=True).drop_duplicates().reset_index(drop=True)
    del combined_keys_train, combined_keys_test # Free memory
    gc.collect()
    # print(f"Combined unique (street, violation) pairs for feature engineering. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB") # Commented out print for clean output

    # --- Feature Engineering and Augmentation ---

    # Basic features from core data
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # NEW: Temporal Features (Ablation Target 1) - Aggregated from raw data
    if enable_temporal_features:
        # print("Extracting and aggregating temporal features...") # Commented out print for clean output
        temp_df = train_df_raw.copy() # Use train_df_raw to calculate temporal features
        if 'issue_datetime' in temp_df.columns:
            # Ensure it's datetime type, coerce errors to NaT
            if not pd.api.types.is_datetime64_any_dtype(temp_df['issue_datetime']):
                temp_df['issue_datetime'] = pd.to_datetime(temp_df['issue_datetime'], errors='coerce')

            temp_df['day_of_week'] = temp_df['issue_datetime'].dt.dayofweek
            temp_df['hour_of_day'] = temp_df['issue_datetime'].dt.hour
            temp_df['month'] = temp_df['issue_datetime'].dt.month

            # Aggregate temporal features to the (street, violation) level
            temporal_agg = temp_df.groupby(['street_name', 'violation_description']).agg(
                mean_day_of_week=('day_of_week', 'mean'),
                mean_hour_of_day=('hour_of_day', 'mean'),
                mean_month=('month', 'mean')
            ).reset_index()
            
            combined_df = pd.merge(combined_df, temporal_agg, on=['street_name', 'violation_description'], how='left')
            combined_df['mean_day_of_week'] = combined_df['mean_day_of_week'].astype('float32') # Use float for mean
            combined_df['mean_hour_of_day'] = combined_df['mean_hour_of_day'].astype('float32')
            combined_df['mean_month'] = combined_df['mean_month'].astype('float32')
            # print("Aggregated temporal features added: mean_day_of_week, mean_hour_of_day, mean_month.") # Commented out print for clean output
        else:
            pass # print("Warning: 'issue_datetime' column not found in train_df_raw. Skipping temporal feature extraction.") # Commented out print for clean output
    else:
        pass # print("Temporal features ablation: SKIPPED temporal feature extraction.") # Commented out print for clean output


    # NEW: Frequency Encoding (Ablation Target 2)
    if enable_frequency_encoding:
        # print("Applying Frequency Encoding for 'street_name' and 'violation_description'...") # Commented out print for clean output
        combined_df['street_name_freq'] = combined_df['street_name'].map(combined_df['street_name'].value_counts()).astype('int32')
        combined_df['violation_desc_freq'] = combined_df['violation_description'].map(combined_df['violation_description'].value_counts()).astype('int32')
        # print("Frequency encoding features added: street_name_freq, violation_desc_freq.") # Commented out print for clean output
    else:
        pass # print("Frequency encoding ablation: SKIPPED frequency encoding.") # Commented out print for clean output

    # Augmentation 1: nyc_street_data.csv
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        # print(f"Loading {street_data_path}...") # Commented out print for clean output
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name']) # Ensure unique info per street
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
            # print(f"Merged with street_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB") # Commented out print for clean output
        except Exception as e:
            pass # print(f"Error loading or merging {street_data_path}: {e}. Skipping street data augmentation.") # Commented out print for clean output
    else:
        pass # print(f"Warning: {street_data_path} not found. Skipping street data augmentation.") # Commented out print for clean output

    # NEW: Interaction Feature 'violation_density_per_lane_mile' (Ablation Target 3)
    # This feature requires 'street_name_freq', 'street_length', and 'num_lanes'.
    # It must be created AFTER the street_data merge and frequency encoding.
    if enable_interaction_feature and \
       'street_name_freq' in combined_df.columns and \
       'street_length' in combined_df.columns and \
       'num_lanes' in combined_df.columns:
        # print("Creating interaction feature: 'violation_density_per_lane_mile'...") # Commented out print for clean output
        temp_street_length = combined_df['street_length'].replace(0, np.nan)
        temp_num_lanes = combined_df['num_lanes'].replace(0, np.nan)
        denominator = temp_street_length * temp_num_lanes
        combined_df['violation_density_per_lane_mile'] = (combined_df['street_name_freq'] / denominator).astype('float32')
        # print("Interaction feature 'violation_density_per_lane_mile' created.") # Commented out print for clean output
    else:
        pass # print("Interaction feature ablation: SKIPPED 'violation_density_per_lane_mile'.") # Commented out print for clean output

    # Augmentation 2: nyc_violation_codes.csv
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        # print(f"Loading {violation_codes_path}...") # Commented out print for clean output
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description']) # Ensure unique info per violation
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
            # print(f"Merged with violation_codes. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB") # Commented out print for clean output
        except Exception as e:
            pass # print(f"Error loading or merging {violation_codes_path}: {e}. Skipping violation codes augmentation.") # Commented out print for clean output
    else:
        pass # print(f"Warning: {violation_codes_path} not found. Skipping violation codes augmentation.") # Commented out print for clean output

    # Augmentation 3: nyc_census_data.csv (Hypothetical)
    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        # print(f"Loading {census_data_path}...") # Commented out print for clean output
        if 'borough' in combined_df.columns: # Only proceed if borough info is available from street_data
            try:
                census_data = pd.read_csv(census_data_path)
                # Standardize column names
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]

                # Assuming 'borough' is the key and 'population_density', 'avg_income' are features
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    # Aggregate census data by borough to reduce size before merging
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
                    # print(f"Merged with census_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB") # Commented out print for clean output
                else:
                    pass # print(f"Warning: Missing one or more expected columns ({relevant_census_cols}) in {census_data_path}. Skipping census data augmentation.") # Commented out print for clean output
            except Exception as e:
                pass # print(f"Error loading or merging {census_data_path}: {e}. Skipping census data augmentation.") # Commented out print for clean output
        else:
            pass # print("Warning: Borough information not available in combined_df to merge census data. Skipping.") # Commented out print for clean output
    else:
        pass # print(f"Warning: {census_data_path} not found. Skipping census data augmentation.") # Commented out print for clean output


    # Split back into train and test processed dataframes
    # Merge the engineered features back to the raw dataframes (which still hold violation_count and is_pure_prediction)
    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    test_processed_df = None
    if test_df_raw is not None:
        test_processed_df = pd.merge(test_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
        del test_df_raw
        gc.collect()

    # print(f"Final train_processed_df shape: {train_processed_df.shape}") # Commented out print for clean output
    # if test_processed_df is not None: # Commented out print for clean output
    #     print(f"Final test_processed_df shape: {test_processed_df.shape}") # Commented out print for clean output

    # Identify categorical features for CatBoost
    categorical_features = [col for col in combined_df.columns if combined_df[col].dtype in ['object', 'category']]
    # Ensure all categorical features from the combined_df are present in the final processed DFs
    categorical_features = [col for col in categorical_features if col in train_processed_df.columns]
    # print(f"Categorical features identified for CatBoost: {categorical_features}") # Commented out print for clean output

    # Ensure all categorical columns are of 'category' dtype for CatBoost
    for col in categorical_features:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].astype('category')
        if test_processed_df is not None and col in test_processed_df.columns:
            test_processed_df[col] = test_processed_df[col].astype('category')


    return train_processed_df, test_processed_df, categorical_features

def train_and_predict(train_df, test_df, categorical_features):
    """
    Trains a CatBoost Regressor model and generates predictions.
    Reports RMSE for validation.
    """
    # print("Training CatBoost model...") # Commented out print for clean output

    # Define features (X) and target (y)
    # Exclude 'issue_datetime' from features as its components are used
    features = [col for col in train_df.columns if col not in ['violation_count', 'issue_datetime']]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    # Split training data for validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    # print(f"Training data split: X_train={X_train.shape}, X_val={X_val.shape}") # Commented out print for clean output

    # Initialize CatBoost Regressor with OOM-conscious parameters
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6, # Reduced depth to manage memory
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Set verbose to 0 for cleaner ablation output
        early_stopping_rounds=50, # Stop if validation RMSE doesn't improve for 50 iterations
    )

    # Train the model
    # Convert categorical feature names to their indices for CatBoost
    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]
    # print(f"Categorical feature indices for CatBoost: {cat_features_indices}") # Commented out print for clean output

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        raise

    # Validate on internal validation set
    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    # print(f"Development Validation RMSE: {val_rmse}") # Commented out print for clean output

    # No test prediction or submission generation for ablation study
    submission_df = None

    return submission_df, val_rmse

def main_ablation_study():
    """
    Main function to orchestrate the ablation study.
    """
    train_path = './input/violations_per_street_2022.csv'
    # Ensure dummy data files exist for external augmentations if they are expected.
    # The existing code prints warnings if they don't exist.
    # For a clean run, these files (even if empty or with dummy data) should be present.
    # Create dummy files if they don't exist for the purpose of this ablation.
    dummy_files = ['./input/nyc_street_data.csv', './input/nyc_violation_codes.csv', './input/nyc_census_data.csv']
    for f in dummy_files:
        if not os.path.exists(f):
            os.makedirs(os.path.dirname(f), exist_ok=True)
            if 'street_data.csv' in f:
                pd.DataFrame({'Street Name': ['Dummy Street 1'], 'Borough': ['Manhattan'], 'Street Length': [1000], 'Number of Lanes': [4]}).to_csv(f, index=False)
            elif 'violation_codes.csv' in f:
                pd.DataFrame({'Violation Description': ['DUMMY VIOLATION'], 'Fine Amount': [100], 'Points': [0]}).to_csv(f, index=False)
            elif 'census_data.csv' in f:
                pd.DataFrame({'Borough': ['Manhattan'], 'Population Density': [25000], 'Avg Income': [120000]}).to_csv(f, index=False)


    results = {}

    # Base Case
    train_df, _, categorical_features = load_and_preprocess_data(
        train_path, test_path=None,
        enable_temporal_features=True,
        enable_frequency_encoding=True,
        enable_interaction_feature=True
    )
    _, base_rmse = train_and_predict(train_df, None, categorical_features)
    results['Base Case'] = base_rmse

    # Ablation 1: No Temporal Features
    train_df_no_temporal, _, categorical_features_no_temporal = load_and_preprocess_data(
        train_path, test_path=None,
        enable_temporal_features=False,
        enable_frequency_encoding=True,
        enable_interaction_feature=True
    )
    _, rmse_no_temporal = train_and_predict(train_df_no_temporal, None, categorical_features_no_temporal)
    results['No Temporal Features'] = rmse_no_temporal

    # Ablation 2: No Frequency Encoding (will also implicitly affect interaction feature)
    train_df_no_freq_enc, _, categorical_features_no_freq_enc = load_and_preprocess_data(
        train_path, test_path=None,
        enable_temporal_features=True,
        enable_frequency_encoding=False,
        enable_interaction_feature=True # Interaction feature depends on freq encoding, will be skipped if freq enc is off
    )
    _, rmse_no_freq_enc = train_and_predict(train_df_no_freq_enc, None, categorical_features_no_freq_enc)
    results['No Frequency Encoding (and dependent interaction feature)'] = rmse_no_freq_enc

    # Ablation 3: No Interaction Feature (keeping temporal and frequency encoding)
    train_df_no_interaction, _, categorical_features_no_interaction = load_and_preprocess_data(
        train_path, test_path=None,
        enable_temporal_features=True,
        enable_frequency_encoding=True,
        enable_interaction_feature=False
    )
    _, rmse_no_interaction = train_and_predict(train_df_no_interaction, None, categorical_features_no_interaction)
    results['No Interaction Feature'] = rmse_no_interaction

    print(f"Ablation Study Results (Validation RMSE):\n")
    for name, rmse in results.items():
        delta = rmse - base_rmse
        print(f"- {name}: {rmse:.4f} (Delta from Base: {delta:+.4f})")

    # Determine the most contributing part
    most_impactful_change = None
    max_abs_delta = 0
    impact_type = ""

    for name, rmse in results.items():
        if name == 'Base Case':
            continue
        delta = rmse - base_rmse
        if abs(delta) > max_abs_delta:
            max_abs_delta = abs(delta)
            most_impactful_change = name
            impact_type = "worsened" if delta > 0 else "improved"

    if most_impactful_change:
        print(f"\nConclusion: The most impactful change was '{most_impactful_change}', which {impact_type} the RMSE by {max_abs_delta:.4f}.")
    else:
        print("\nConclusion: No significant impact observed from the ablations.")


if __name__ == "__main__":
    main_ablation_study()
