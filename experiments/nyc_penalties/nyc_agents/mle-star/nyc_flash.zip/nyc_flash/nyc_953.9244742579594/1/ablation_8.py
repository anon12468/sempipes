
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types.
    Object columns are not converted to category here, but rather handled explicitly later
    to ensure NaN values are addressed before category conversion for CatBoost.
    """
    initial_memory = df.memory_usage(deep=True).sum() / (1024**2)
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
    final_memory = df.memory_usage(deep=True).sum() / (1024**2)
    return df

def load_and_preprocess_data(train_path, test_path=None, enable_freq_encoding=True, enable_aggregate_features=True):
    """
    Loads, preprocesses, and merges data from various sources.
    Handles memory efficiency by selective column loading, aggregation, and garbage collection.
    Addresses NaN values in categorical features before passing to CatBoost.
    Includes flags for ablating Frequency Encoding and Aggregate Features.
    """
    # --- Load Core Data ---
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)

    test_df_raw = None
    if test_path:
        test_df_raw = pd.read_csv(test_path)
        test_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
        test_df_raw['is_pure_prediction'] = test_df_raw['violation_count'].isna()
        test_df_raw = downcast_dtypes(test_df_raw)

    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_keys_test = pd.DataFrame()
    if test_df_raw is not None:
        combined_keys_test = test_df_raw[['street_name', 'violation_description']].drop_duplicates()

    combined_df = pd.concat([combined_keys_train, combined_keys_test], ignore_index=True).drop_duplicates().reset_index(drop=True)
    del combined_keys_train, combined_keys_test
    gc.collect()

    # --- Feature Engineering and Augmentation ---

    # Basic features from core data
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # Augmentation 1: nyc_street_data.csv
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')

            if 'borough' in combined_df.columns:
                combined_df['borough'] = combined_df['borough'].astype(str).fillna('Unknown_Borough')
                combined_df['borough'] = combined_df['borough'].astype('category')

            for col in ['street_length', 'num_lanes']:
                if col in combined_df.columns:
                    combined_df[col].fillna(0, inplace=True)

            del street_data
            gc.collect()
        except Exception as e:
            pass # Suppress output for ablation
    else:
        pass # Suppress output for ablation

    # Augmentation 2: nyc_violation_codes.csv
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            
            for col in ['fine_amount', 'points']:
                if col in combined_df.columns:
                    combined_df[col].fillna(0, inplace=True)

            del violation_codes
            gc.collect()
        except Exception as e:
            pass # Suppress output for ablation
    else:
        pass # Suppress output for ablation

    # Augmentation 3: nyc_census_data.csv (Hypothetical)
    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        if 'borough' in combined_df.columns:
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]

                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')

                    for col in ['population_density', 'avg_income']:
                        if col in combined_df.columns:
                            combined_df[col].fillna(0, inplace=True)

                    del census_data, census_agg
                    gc.collect()
                else:
                    pass # Suppress output for ablation
            except Exception as e:
                pass # Suppress output for ablation
        else:
            pass # Suppress output for ablation
    else:
        pass # Suppress output for ablation

    # --- New Features for Ablation Study ---
    if enable_freq_encoding:
        if 'street_name' in combined_df.columns:
            combined_df['street_name_freq'] = combined_df['street_name'].map(combined_df['street_name'].value_counts()).astype('int32')
        if 'violation_description' in combined_df.columns:
            combined_df['violation_desc_freq'] = combined_df['violation_description'].map(combined_df['violation_description'].value_counts()).astype('int32')
    
    if enable_aggregate_features:
        agg_columns_to_process = []
        for col in ['fine_amount', 'street_length', 'num_lanes', 'population_density', 'avg_income']:
            if col in combined_df.columns:
                agg_columns_to_process.append(col)

        if agg_columns_to_process and 'street_name' in combined_df.columns and 'violation_description' in combined_df.columns:
            try:
                for col in agg_columns_to_process:
                    if combined_df[col].isnull().any():
                        combined_df[col].fillna(0, inplace=True)

                grouped_stats = combined_df.groupby(['street_name', 'violation_description'])[agg_columns_to_process].agg(['mean', 'median', 'std'])
                grouped_stats.columns = [f"{col[0]}_{col[1]}_by_street_violation" for col in grouped_stats.columns]
                grouped_stats = downcast_dtypes(grouped_stats) 
                
                combined_df = pd.merge(combined_df, grouped_stats, on=['street_name', 'violation_description'], how='left')
                
                del grouped_stats
                gc.collect()
            except Exception as e:
                pass # Suppress output for ablation
        else:
            pass # Suppress output for ablation
    
    # --- End of New Features ---

    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    test_processed_df = None
    if test_df_raw is not None:
        test_processed_df = pd.merge(test_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
        del test_df_raw
        gc.collect()

    categorical_features = ['street_name', 'violation_description']
    if 'borough' in combined_df.columns:
        categorical_features.append('borough')
    
    categorical_features = [col for col in categorical_features if col in train_processed_df.columns]

    for col in categorical_features:
        if col in train_processed_df.columns:
            if train_processed_df[col].isnull().any():
                train_processed_df[col] = train_processed_df[col].astype(str).fillna('UNKNOWN_CATEGORY_TRAIN')
            train_processed_df[col] = train_processed_df[col].astype('category')
        if test_processed_df is not None and col in test_processed_df.columns:
            if test_processed_df[col].isnull().any():
                test_processed_df[col] = test_processed_df[col].astype(str).fillna('UNKNOWN_CATEGORY_TEST')
            test_processed_df[col] = test_processed_df[col].astype('category')

    return train_processed_df, test_processed_df, categorical_features

def train_and_predict(train_df, test_df, categorical_features, catboost_depth=6):
    """
    Trains a CatBoost Regressor model and generates predictions.
    Reports RMSE for validation and test sets (if ground truth available).
    Includes flags for ablating CatBoost depth.
    """
    features = [col for col in train_df.columns if col not in ['violation_count', 'is_pure_prediction']]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=catboost_depth, # Ablation point
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Suppress verbose output for ablation runs
        early_stopping_rounds=50,
    )

    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        raise

    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))

    submission_df = None # No test data is loaded for ablation study
    return submission_df, val_rmse

def run_ablation_scenario(
    train_path,
    scenario_name,
    enable_freq_encoding=True,
    enable_aggregate_features=True,
    catboost_depth=6
):
    """Runs a single ablation scenario and returns the validation RMSE."""
    train_df, _, categorical_features = load_and_preprocess_data(
        train_path=train_path,
        test_path=None, # Ensure no test data is loaded
        enable_freq_encoding=enable_freq_encoding,
        enable_aggregate_features=enable_aggregate_features
    )
    
    _, val_rmse = train_and_predict(
        train_df=train_df,
        test_df=None, # Ensure no test data is used for prediction
        categorical_features=categorical_features,
        catboost_depth=catboost_depth
    )
    return val_rmse

# Main ablation study execution
if __name__ == "__main__":
    train_file_path = './input/violations_per_street_2022.csv'

    results = {}

    # Base Case
    print("Running Base Case (All features enabled, CatBoost depth=6)")
    results['Base Case'] = run_ablation_scenario(
        train_file_path,
        'Base Case',
        enable_freq_encoding=True,
        enable_aggregate_features=True,
        catboost_depth=6
    )
    print(f"Base Case Validation RMSE: {results['Base Case']:.4f}")

    # Ablation 1: No Frequency Encoding Features
    print("Running Ablation: No Frequency Encoding Features")
    results['No Frequency Encoding'] = run_ablation_scenario(
        train_file_path,
        'No Frequency Encoding Features',
        enable_freq_encoding=False,
        enable_aggregate_features=True,
        catboost_depth=6
    )
    print(f"Ablation (No Frequency Encoding) Validation RMSE: {results['No Frequency Encoding']:.4f}")

    # Ablation 2: No Aggregate Features
    print("Running Ablation: No Aggregate Features")
    results['No Aggregate Features'] = run_ablation_scenario(
        train_file_path,
        'No Aggregate Features',
        enable_freq_encoding=True,
        enable_aggregate_features=False,
        catboost_depth=6
    )
    print(f"Ablation (No Aggregate Features) Validation RMSE: {results['No Aggregate Features']:.4f}")

    # Ablation 3: Reduced CatBoost Depth (e.g., from 6 to 3)
    print("Running Ablation: Reduced CatBoost Depth (from 6 to 3)")
    results['Reduced CatBoost Depth'] = run_ablation_scenario(
        train_file_path,
        'Reduced CatBoost Depth',
        enable_freq_encoding=True,
        enable_aggregate_features=True,
        catboost_depth=3
    )
    print(f"Ablation (Reduced CatBoost Depth) Validation RMSE: {results['Reduced CatBoost Depth']:.4f}")

    # Determine the most contributing part
    base_rmse = results['Base Case']
    impacts = {}
    
    for scenario, rmse in results.items():
        if scenario != 'Base Case':
            # Impact is the change in RMSE relative to the base.
            # A positive impact (RMSE increase) means the ablated part was beneficial.
            # A negative impact (RMSE decrease) means the ablated part was detrimental.
            impacts[scenario] = rmse - base_rmse

    print(f"\nBase Case RMSE: {base_rmse:.4f}")
    for scenario, impact in impacts.items():
        print(f"Scenario: {scenario}, RMSE: {results[scenario]:.4f}, Delta from Base: {impact:+.4f}")

    most_contributing_part = None
    max_impact_increase = 0 # Looking for the largest *increase* in RMSE when a part is removed (meaning it's beneficial)
    max_impact_decrease = 0 # Looking for the largest *decrease* in RMSE when a part is removed (meaning it's detrimental)
    most_detrimental_part_label = None

    for scenario, impact in impacts.items():
        if impact > max_impact_increase: # If removing it increases RMSE, it was beneficial
            max_impact_increase = impact
            most_contributing_part = f"Original '{scenario.replace('No ', '').replace('Reduced ', '')}' component"

        if impact < max_impact_decrease: # If removing it decreases RMSE, it was detrimental
            max_impact_decrease = impact
            most_detrimental_part_label = f"The removal of '{scenario.replace('No ', '').replace('Reduced ', '')}' component"

    if most_contributing_part and max_impact_increase > abs(max_impact_decrease):
        print(f"\nThe most contributing part to the overall performance is: {most_contributing_part} (Its removal increased RMSE by {max_impact_increase:.4f}, meaning it was beneficial).")
    elif most_detrimental_part_label:
        print(f"\nThe most contributing part to the overall performance is: {most_detrimental_part_label} (Its removal decreased RMSE by {abs(max_impact_decrease):.4f}, meaning the ablated part was detrimental and removing it improved performance).")
    else:
        print("\nNo significant most contributing part found or all impacts were zero.")

