
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    initial_memory = df.memory_usage(deep=True).sum() / (1024**2)
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    final_memory = df.memory_usage(deep=True).sum() / (1024**2)
    # print(f"  Memory reduced from {initial_memory:.2f} MB to {final_memory:.2f} MB for dataframe.")
    return df

import pandas as pd
import gc
import os

# Assuming downcast_dtypes function is defined elsewhere in the environment
# For example:
def downcast_dtypes(df):
    _start_mem = df.memory_usage(deep=True).sum() / (1024**2)
    for col in df.columns:
        col_type = df[col].dtype

        if col_type == object:
            df[col] = df[col].astype('category')
        elif col_type == int:
            c_min = df[col].min()
            c_max = df[col].max()
            if c_min > np.iinfo(np.int8).min and c_max < np.iinfo(np.int8).max:
                df[col] = df[col].astype(np.int8)
            elif c_min > np.iinfo(np.int16).min and c_max < np.iinfo(np.int16).max:
                df[col] = df[col].astype(np.int16)
            elif c_min > np.iinfo(np.int32).min and c_max < np.iinfo(np.int32).max:
                df[col] = df[col].astype(np.int32)
            elif c_min > np.iinfo(np.int64).min and c_max < np.iinfo(np.int64).max:
                df[col] = df[col].astype(np.int64)
        elif col_type == float:
            c_min = df[col].min()
            c_max = df[col].max()
            if c_min > np.finfo(np.float16).min and c_max < np.finfo(np.float16).max:
                df[col] = df[col].astype(np.float16)
            elif c_min > np.finfo(np.float32).min and c_max < np.finfo(np.float32).max:
                df[col] = df[col].astype(np.float32)
            else:
                df[col] = df[col].astype(np.float64) # Keep as float64 if not possible to downcast further
    _end_mem = df.memory_usage(deep=True).sum() / (1024**2)
    # print(f"Memory usage after optimization: {_end_mem:.2f} MB (reduced by {(_start_mem - _end_mem) / _start_mem * 100:.1f}%)")
    return df
import numpy as np # Required for downcast_dtypes example


def load_and_preprocess_data(train_path, test_path=None):
    """
    Loads, preprocesses, and merges data from various sources.
    Handles memory efficiency by selective column loading, aggregation, and garbage collection.
    """
    print("Loading and preprocessing data...")

    # --- Load Core Data ---
    # Load training data
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)
    print(f"Initial train_df loaded. Shape: {train_df_raw.shape}, Memory: {train_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Load test data if provided
    test_df_raw = None
    if test_path:
        test_df_raw = pd.read_csv(test_path)
        test_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
        # Create a flag for pure prediction rows where violation_count is NaN
        test_df_raw['is_pure_prediction'] = test_df_raw['violation_count'].isna()
        test_df_raw = downcast_dtypes(test_df_raw)
        print(f"Test_df loaded. Shape: {test_df_raw.shape}, Memory: {test_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Combine unique street_name and violation_description pairs from train and test
    # for consistent feature engineering.
    # Exclude 'violation_count' to prevent target leakage and reduce memory.
    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_keys_test = pd.DataFrame()
    if test_df_raw is not None:
        combined_keys_test = test_df_raw[['street_name', 'violation_description']].drop_duplicates()

    combined_df = pd.concat([combined_keys_train, combined_keys_test], ignore_index=True).drop_duplicates().reset_index(drop=True)
    del combined_keys_train, combined_keys_test # Free memory
    gc.collect()
    print(f"Combined unique (street, violation) pairs for feature engineering. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # --- Feature Engineering and Augmentation ---

    # Basic features from core data
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # New Aggregated Features (from improvement plan)
    print("Calculating aggregated features from training data...")

    # Aggregate by street_name
    street_agg = train_df_raw.groupby('street_name')['violation_count'].agg(['mean', 'median'])
    street_agg.columns = ['street_mean_violation_count', 'street_median_violation_count']
    street_agg = downcast_dtypes(street_agg).reset_index()
    combined_df = pd.merge(combined_df, street_agg, on='street_name', how='left')
    del street_agg
    gc.collect()
    print(f"Merged street-level aggregated features. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Aggregate by violation_description
    violation_agg = train_df_raw.groupby('violation_description')['violation_count'].agg(['mean', 'median'])
    violation_agg.columns = ['desc_mean_violation_count', 'desc_median_violation_count']
    violation_agg = downcast_dtypes(violation_agg).reset_index()
    combined_df = pd.merge(combined_df, violation_agg, on='violation_description', how='left')
    del violation_agg
    gc.collect()
    print(f"Merged violation-level aggregated features. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Aggregate by street_name and violation_description (this is essentially the target, but aggregated over all occurrences)
    # We rename to avoid direct target leakage from single row and introduce a smoothed version.
    street_violation_agg = train_df_raw.groupby(['street_name', 'violation_description'])['violation_count'].agg(['mean', 'median'])
    street_violation_agg.columns = ['street_desc_mean_violation_count', 'street_desc_median_violation_count']
    street_violation_agg = downcast_dtypes(street_violation_agg).reset_index()
    combined_df = pd.merge(combined_df, street_violation_agg, on=['street_name', 'violation_description'], how='left')
    del street_violation_agg
    gc.collect()
    print(f"Merged street-violation combined aggregated features. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Augmentation 1: nyc_street_data.csv
    # Assuming this file exists and contains relevant street-level information
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        print(f"Loading {street_data_path}...")
        # Load only necessary columns
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name']) # Ensure unique info per street
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
            print(f"Merged with street_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading or merging {street_data_path}: {e}. Skipping street data augmentation.")
    else:
        print(f"Warning: {street_data_path} not found. Skipping street data augmentation.")

    # Augmentation 2: nyc_violation_codes.csv
    # Assuming this file exists and contains details about violation codes
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        print(f"Loading {violation_codes_path}...")
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description']) # Ensure unique info per violation
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
            print(f"Merged with violation_codes. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading or merging {violation_codes_path}: {e}. Skipping violation codes augmentation.")
    else:
        print(f"Warning: {violation_codes_path} not found. Skipping violation codes augmentation.")

    # Augmentation 3: nyc_census_data.csv (Hypothetical)
    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        print(f"Loading {census_data_path}...")
        if 'borough' in combined_df.columns: # Only proceed if borough info is available from street_data
            try:
                census_data = pd.read_csv(census_data_path)
                # Standardize column names
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]

                # Assuming 'borough' is the key and 'population_density', 'avg_income' are features
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    # Aggregate census data by borough to reduce size before merging
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
                    print(f"Merged with census_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
                else:
                    print(f"Warning: Missing one or more expected columns ({relevant_census_cols}) in {census_data_path}. Skipping census data augmentation.")
            except Exception as e:
                print(f"Error loading or merging {census_data_path}: {e}. Skipping census data augmentation.")
        else:
            print("Warning: Borough information not available in combined_df to merge census data. Skipping.")
    else:
        print(f"Warning: {census_data_path} not found. Skipping census data augmentation.")


    # Split back into train and test processed dataframes
    # Merge the engineered features back to the raw dataframes (which still hold violation_count and is_pure_prediction)
    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    test_processed_df = None
    if test_df_raw is not None:
        test_processed_df = pd.merge(test_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
        del test_df_raw
        gc.collect()

    print(f"Final train_processed_df shape: {train_processed_df.shape}")
    if test_processed_df is not None:
        print(f"Final test_processed_df shape: {test_processed_df.shape}")

    # Identify categorical features for CatBoost
    categorical_features = [col for col in combined_df.columns if combined_df[col].dtype in ['object', 'category']]
    # Ensure all categorical features from the combined_df are present in the final processed DFs
    categorical_features = [col for col in categorical_features if col in train_processed_df.columns]
    print(f"Categorical features identified for CatBoost: {categorical_features}")

    # Ensure all categorical columns are of 'category' dtype for CatBoost
    for col in categorical_features:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].astype('category')
        if test_processed_df is not None and col in test_processed_df.columns:
            test_processed_df[col] = test_processed_df[col].astype('category')


    return train_processed_df, test_processed_df, categorical_features

def train_and_predict(train_df, test_df, categorical_features):
    """
    Trains a CatBoost Regressor model and generates predictions.
    Reports RMSE for validation and test sets (if ground truth available).
    """
    print("Training CatBoost model...")

    # Define features (X) and target (y)
    features = [col for col in train_df.columns if col not in ['violation_count']]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    # Split training data for validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    print(f"Training data split: X_train={X_train.shape}, X_val={X_val.shape}")

    # Initialize CatBoost Regressor with OOM-conscious parameters
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6, # Reduced depth to manage memory
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=100, # Print metrics every 100 iterations
        early_stopping_rounds=50, # Stop if validation RMSE doesn't improve for 50 iterations
        # thread_count=-1, # Use all available cores if not explicitly limited by env
        # grow_policy='Lossguide', # Can be more memory efficient for deep trees
        # max_leaves=31 # For Lossguide, controls number of leaves
    )

    # Train the model
    # Convert categorical feature names to their indices for CatBoost
    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]
    print(f"Categorical feature indices for CatBoost: {cat_features_indices}")

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        print("This might indicate an issue with data format or extreme memory pressure even with optimized parameters.")
        # Re-raising for debugging or handling gracefully, depending on requirements.
        raise

    # Validate on internal validation set
    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    print(f"Development Validation RMSE: {val_rmse}")

    # Generate predictions for the test_df if provided
    submission_df = None
    if test_df is not None:
        print("Generating predictions for test data...")
        # Features for prediction are the same as training
        X_test = test_df[features]

        # CatBoost handles unseen categories in test data by default
        test_preds = model.predict(X_test)
        # Ensure predictions are non-negative
        test_preds[test_preds < 0] = 0

        # Create submission dataframe
        submission_df = test_df[['street_name', 'violation_description']].copy()
        submission_df['predicted_count'] = test_preds

        # Report RMSE if ground truth is available in test_df
        if not test_df['is_pure_prediction'].all(): # If some ground truth exists
            ground_truth_test_df = test_df[~test_df['is_pure_prediction']]
            ground_truth_preds = submission_df[~test_df['is_pure_prediction']]['predicted_count']
            test_rmse = np.sqrt(mean_squared_error(ground_truth_test_df['violation_count'], ground_truth_preds))
            print(f"RMSE on provided test/evaluation data (with ground truth): {test_rmse}")

        # Report unseen key pairs
        train_keys = set(train_df.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
        test_keys = set(test_df.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
        unseen_keys_count = len(test_keys - train_keys)
        print(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {unseen_keys_count}")
        print("Unseen keys are handled by CatBoost's internal mechanism for new categorical levels (assigned to an 'unknown' category).")

    return submission_df, val_rmse

def main():
    """
    Main function to parse arguments, orchestrate data loading, training, and prediction.
    """
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional path to the 2023 test/evaluation data CSV. '
                             'If provided, predictions will be generated and RMSE reported if ground truth exists.')
    args = parser.parse_args()

    train_df, test_df, categorical_features = load_and_preprocess_data(args.train_path, args.test_path)
    submission_df, final_validation_score = train_and_predict(train_df, test_df, categorical_features)

    if submission_df is not None:
        submission_df.to_csv('submission.csv', index=False)
        print("Submission file 'submission.csv' generated successfully.")

    # Always print the final validation score
    print(f"Final Validation Performance: {final_validation_score}")

if __name__ == "__main__":
    main()
