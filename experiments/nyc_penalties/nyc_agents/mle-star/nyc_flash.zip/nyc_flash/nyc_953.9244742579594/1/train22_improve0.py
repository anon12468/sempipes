
# To install the necessary packages, uncomment and run the following lines:
# !pip install pandas numpy scikit-learn catboost

import argparse
import pandas as pd
import numpy as np
import os
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

# Conditional import for CatBoost
try:
    from catboost import CatBoostRegressor
    CATBOOST_AVAILABLE = True
except ImportError:
    print("CatBoost not found. Predictions will be generated using a fallback strategy (mean of training target).")
    CATBOOST_AVAILABLE = False
    
    class CatBoostRegressor: # Dummy class for fallback
        """
        A dummy regressor to serve as a fallback if CatBoost is not installed.
        It simply predicts the mean of the training target.
        """
        def __init__(self, **kwargs):
            self.avg_target = 0.0
            # Store kwargs to mimic a real constructor call if needed for debugging
            self.kwargs = kwargs 
        
        def fit(self, X, y, cat_features=None, eval_set=None, verbose=False):
            if isinstance(y, pd.Series):
                self.avg_target = y.mean()
            else:
                self.avg_target = np.mean(y)
            print(f"Dummy CatBoostRegressor fitted. Will predict average target: {self.avg_target:.2f}")

        def predict(self, X):
            return np.full(len(X), self.avg_target)

def rmse(y_true, y_pred):
    """
    Calculates the Root Mean Squared Error.
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations for 2023 using 2022 data and augmentation.")
    parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV (e.g., violations_per_street_2022.csv).")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Optional path to the 2023 test/evaluation data CSV for prediction or scoring. "
                             "If provided, predictions are generated for this file. "
                             "If 'violation_count' is present, RMSE is reported.")
    parser.add_argument("--input-dir", type=str, default="./input",
                        help="Directory containing augmentation tables (e.g., street_info.csv, violation_info.csv).")

    args = parser.parse_args()

    # --- Load Training Data ---
    print(f"Loading training data from {args.train_path}...")
    try:
        df_train = pd.read_csv(args.train_path)
    except FileNotFoundError:
        print(f"Error: Training data not found at {args.train_path}. Please check the path.")
        return

    df_train.rename(columns={
        'Street Name': 'street_name',
        'Violation Description': 'violation_type',
        'violation_count': 'violation_count'
    }, inplace=True)

    # --- Load Augmentation Data ---
    print("Loading augmentation data from specified input directory...")
    augmentation_data = {}
    
    # Example augmentation table: street_info.csv
    street_info_path = os.path.join(args.input_dir, "street_info.csv")
    if os.path.exists(street_info_path):
        try:
            augmentation_data['street_info'] = pd.read_csv(street_info_path)
            augmentation_data['street_info'].rename(columns={'Street Name': 'street_name'}, inplace=True)
            print(f"  - Loaded street info from {street_info_path}")
        except Exception as e:
            print(f"  - Error loading street_info.csv: {e}")
    else:
        print(f"  - Warning: street_info.csv not found at {street_info_path}. Skipping street info augmentation.")

    # Example augmentation table: violation_info.csv
    violation_info_path = os.path.join(args.input_dir, "violation_info.csv")
    if os.path.exists(violation_info_path):
        try:
            augmentation_data['violation_info'] = pd.read_csv(violation_info_path)
            augmentation_data['violation_info'].rename(columns={'Violation Description': 'violation_type'}, inplace=True)
            print(f"  - Loaded violation info from {violation_info_path}")
        except Exception as e:
            print(f"  - Error loading violation_info.csv: {e}")
    else:
        print(f"  - Warning: violation_info.csv not found at {violation_info_path}. Skipping violation info augmentation.")

    # --- Feature Engineering and Augmentation ---
    print("Performing feature engineering and data augmentation on training data...")

    # Join street info
    if 'street_info' in augmentation_data:
        df_train = pd.merge(df_train, augmentation_data['street_info'], on='street_name', how='left')

    # Join violation info
    if 'violation_info' in augmentation_data:
        df_train = pd.merge(df_train, augmentation_data['violation_info'], on='violation_type', how='left')

    # Identify categorical and numerical columns for processing
    # Start with core keys
    categorical_features = ['street_name', 'violation_type']
    numerical_features = [] # Other numerical features will be identified dynamically

    # Add augmentation table columns to respective lists
    if 'street_info' in augmentation_data:
        for col in augmentation_data['street_info'].columns:
            if col != 'street_name':
                if augmentation_data['street_info'][col].dtype == 'object':
                    categorical_features.append(col)
                elif augmentation_data['street_info'][col].dtype in ['int64', 'float64']:
                    numerical_features.append(col)
    
    if 'violation_info' in augmentation_data:
        for col in augmentation_data['violation_info'].columns:
            if col != 'violation_type':
                if augmentation_data['violation_info'][col].dtype == 'object':
                    categorical_features.append(col)
                elif augmentation_data['violation_info'][col].dtype in ['int64', 'float64']:
                    numerical_features.append(col)
    
    # Clean up and ensure uniqueness and order
    categorical_features = list(dict.fromkeys(categorical_features))
    numerical_features = list(dict.fromkeys(numerical_features))

    # Apply data type conversions and handle NaNs for training data
    for col in categorical_features:
        if col in df_train.columns:
            df_train[col] = df_train[col].fillna('Unknown').astype('category')
    
    for col in numerical_features:
        if col in df_train.columns:
            df_train[col] = df_train[col].fillna(0) # Simple imputation, can be improved (e.g., mean/median)

    # --- Prepare Data for Model Training ---
    X = df_train.drop('violation_count', axis=1)
    y = df_train['violation_count']

    # Ensure all categorical columns in X are of type 'category'
    for col in categorical_features:
        if col in X.columns:
            X[col] = X[col].astype('category')

    # Identify categorical features for CatBoost by name (CatBoost can handle string names directly)
    cat_features_for_model = [col for col in categorical_features if col in X.columns]
    
    print(f"Features used for training: {list(X.columns)}")
    print(f"Categorical features for CatBoost model: {cat_features_for_model}")

    # Use part of 2022 data for evaluation (grouped holdout / pseudo-time split is ideal but not implemented here)
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    # --- Model Training ---
    print("Training model...")
    if CATBOOST_AVAILABLE:
        model = CatBoostRegressor(
            iterations=1000,
            learning_rate=0.05,
            depth=6,
            loss_function='RMSE',
            eval_metric='RMSE',
            random_seed=42,
            verbose=0, # Set to 0 to suppress verbose output
            early_stopping_rounds=50 # Stop if validation RMSE doesn't improve for 50 rounds
        )
        model.fit(X_train, y_train,
                  cat_features=cat_features_for_model,
                  eval_set=(X_val, y_val),
                  verbose=False)
    else:
        model = CatBoostRegressor() # This uses the dummy regressor
        model.fit(X_train, y_train)

    # --- Validation Performance ---
    y_pred_val = model.predict(X_val)
    y_pred_val[y_pred_val < 0] = 0 # Clip negative predictions to 0 as counts cannot be negative
    val_rmse = rmse(y_val, y_pred_val)
    print(f"Validation RMSE: {val_rmse:.4f}")
    print(f"Final Validation Performance: {val_rmse:.4f}") # Required output format

    # --- Prediction for Test Data (if provided) ---
    if args.test_path:
        print(f"\nLoading test data from {args.test_path}...")
        try:
            df_test = pd.read_csv(args.test_path)
        except FileNotFoundError:
            print(f"Error: Test data not found at {args.test_path}. Please check the path.")
            return

        df_test.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type'
        }, inplace=True)

        # Store original keys for submission file
        submission_keys = df_test[['street_name', 'violation_type']].copy()
        
        # Check if 'violation_count' is present in test data for scoring
        test_has_target = 'violation_count' in df_test.columns
        if test_has_target:
            y_test_true = df_test['violation_count']
            df_test_features = df_test.drop('violation_count', axis=1)
        else:
            df_test_features = df_test.copy()

        # Augment test data in the same way as training data
        if 'street_info' in augmentation_data:
            df_test_features = pd.merge(df_test_features, augmentation_data['street_info'], on='street_name', how='left')
        if 'violation_info' in augmentation_data:
            df_test_features = pd.merge(df_test_features, augmentation_data['violation_info'], on='violation_type', how='left')
        
        # Count unseen (street_name, violation_type) pairs
        train_pairs = set(df_train.set_index(['street_name', 'violation_type']).index)
        test_pairs = set(df_test_features.set_index(['street_name', 'violation_type']).index)
        unseen_pairs_in_test = test_pairs - train_pairs
        
        print(f"Number of (street_name, violation_type) pairs in test set unseen in training: {len(unseen_pairs_in_test)} out of {len(df_test_features)} total rows.")
        
        # Handle new/unseen categories and NaNs for test data
        # Ensure test categorical columns have the same categories as train, or handle new ones
        for col in categorical_features:
            if col in df_test_features.columns:
                # Fill NaNs for augmented categorical columns in test set
                df_test_features[col] = df_test_features[col].fillna('Unknown')
                
                # CatBoost handles unseen categorical feature values automatically, but it's good practice
                # to ensure dtype consistency. We create a union of categories.
                if col in X.columns and isinstance(X[col].dtype, pd.CategoricalDtype):
                    known_categories = X[col].cat.categories
                    # Add any new categories from test data to the known set
                    all_categories = list(known_categories.union(df_test_features[col].unique()))
                    df_test_features[col] = pd.Categorical(df_test_features[col], categories=all_categories)
                else: # If column was newly added or not categorical in train for some reason
                    df_test_features[col] = df_test_features[col].astype('category')
            elif col in X.columns: # If a categorical feature was in train but not in test, add it as 'Unknown'
                 df_test_features[col] = 'Unknown'
                 df_test_features[col] = df_test_features[col].astype('category')


        for col in numerical_features:
            if col in df_test_features.columns:
                df_test_features[col] = df_test_features[col].fillna(0)
            elif col in X.columns: # If a numerical feature was in train but not in test, add it as 0
                df_test_features[col] = 0

        # Align columns between training and test features to ensure consistent input for the model
        # This adds missing columns to test_features and fills with appropriate defaults, and removes extra columns.
        train_cols_for_prediction = X.columns
        
        # Add missing columns in test_features that were in train_cols_for_prediction
        missing_in_test = set(train_cols_for_prediction) - set(df_test_features.columns)
        for col in missing_in_test:
            if col in categorical_features:
                df_test_features[col] = 'Unknown'
                df_test_features[col] = df_test_features[col].astype('category')
            else: # Must be numerical or other types that should default to 0
                df_test_features[col] = 0
        
        # Remove extra columns in test_features not present in train_cols_for_prediction
        df_test_features = df_test_features[train_cols_for_prediction]

        # Make predictions on the test set
        y_pred_test = model.predict(df_test_features)
        y_pred_test[y_pred_test < 0] = 0 # Clip negative predictions

        # Create submission file
        submission_df = submission_keys
        # Round and convert to integer, as violation counts are discrete
        submission_df['predicted_count'] = y_pred_test.round().astype(int)

        submission_file = "submission.csv"
        submission_df.to_csv(submission_file, index=False)
        print(f"Predictions for test data saved to {submission_file}")

        if test_has_target:
            test_rmse = rmse(y_test_true, y_pred_test)
            print(f"RMSE on provided test data: {test_rmse:.4f}")
    else:
        print("\nNo --test-path provided. Skipping final prediction generation.")

if __name__ == "__main__":
    # --- Create Dummy Input Files for Demonstration/Testing ---
    # These files will be created in the './input' directory if they don't exist.
    # This allows the script to be run directly for demonstration purposes.
    input_dir = "./input"
    os.makedirs(input_dir, exist_ok=True)

    # Dummy violations_per_street_2022.csv
    train_file_path = os.path.join(input_dir, "violations_per_street_2022.csv")
    if not os.path.exists(train_file_path):
        print(f"Creating dummy {os.path.basename(train_file_path)}...")
        dummy_train_data = {
            'Street Name': ['BROADWAY', 'MAIN ST', 'PARK AVE', 'BROADWAY', 'MAIN ST', '42ND ST', 'BROADWAY', 'ELM ST', 'OAK AVE'],
            'Violation Description': ['PARKING METER', 'NO PARKING', 'FIRE HYDRANT', 'DOUBLE PARKING', 'PARKING METER', 'NO STANDING', 'NO PARKING', 'BUS LANE', 'LOADING ZONE'],
            'violation_count': [100, 50, 10, 75, 40, 200, 120, 30, 60]
        }
        pd.DataFrame(dummy_train_data).to_csv(train_file_path, index=False)

    # Dummy street_info.csv
    street_info_file_path = os.path.join(input_dir, "street_info.csv")
    if not os.path.exists(street_info_file_path):
        print(f"Creating dummy {os.path.basename(street_info_file_path)}...")
        dummy_street_info = {
            'Street Name': ['BROADWAY', 'MAIN ST', 'PARK AVE', '42ND ST', 'ELM ST'],
            'Borough': ['MANHATTAN', 'QUEENS', 'MANHATTAN', 'MANHATTAN', 'BROOKLYN'],
            'ZipCodePrefix': [10001, 11101, 10010, 10036, 11201],
            'StreetLengthMiles': [13.0, 5.2, 8.1, 1.5, 3.0]
        }
        pd.DataFrame(dummy_street_info).to_csv(street_info_file_path, index=False)

    # Dummy violation_info.csv
    violation_info_file_path = os.path.join(input_dir, "violation_info.csv")
    if not os.path.exists(violation_info_file_path):
        print(f"Creating dummy {os.path.basename(violation_info_file_path)}...")
        dummy_violation_info = {
            'Violation Description': ['PARKING METER', 'NO PARKING', 'FIRE HYDRANT', 'DOUBLE PARKING', 'NO STANDING', 'BUS LANE'],
            'FineAmount': [65, 60, 115, 80, 115, 150],
            'ViolationCategory': ['Meter', 'Standing', 'Safety', 'Double', 'Standing', 'Moving'],
            'SeverityScore': [3, 2, 5, 4, 5, 5]
        }
        pd.DataFrame(dummy_violation_info).to_csv(violation_info_file_path, index=False)

    # Dummy test file (for pure prediction - no violation_count)
    test_keys_only_file_path = os.path.join(input_dir, "violations_per_street_2023_test_keys_only.csv")
    if not os.path.exists(test_keys_only_file_path):
        print(f"Creating dummy {os.path.basename(test_keys_only_file_path)}...")
        dummy_test_keys_only = {
            'Street Name': ['BROADWAY', 'NEW ST', 'MAIN ST', 'PARK AVE', 'UNKNOWN ST', '42ND ST'],
            'Violation Description': ['PARKING METER', 'NO PARKING', 'NEW VIOLATION', 'FIRE HYDRANT', 'DOUBLE PARKING', 'BUS LANE']
        }
        pd.DataFrame(dummy_test_keys_only).to_csv(test_keys_only_file_path, index=False)

    # Dummy eval file (for scoring - with violation_count)
    eval_file_path = os.path.join(input_dir, "violations_per_street_2023_eval.csv")
    if not os.path.exists(eval_file_path):
        print(f"Creating dummy {os.path.basename(eval_file_path)}...")
        dummy_test_eval = {
            'Street Name': ['BROADWAY', 'MAIN ST', 'PARK AVE', '42ND ST', 'BROADWAY', 'ELM ST', 'OAK AVE'],
            'Violation Description': ['PARKING METER', 'NO PARKING', 'FIRE HYDRANT', 'NO STANDING', 'DOUBLE PARKING', 'BUS LANE', 'LOADING ZONE'],
            'violation_count': [110, 55, 12, 210, 80, 35, 65]
        }
        pd.DataFrame(dummy_test_eval).to_csv(eval_file_path, index=False)

    main()
