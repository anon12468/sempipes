
import argparse
import pandas as pd
import numpy as np
import os
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame."""
    try:
        df = pd.read_csv(file_path)
        logging.info(f"Successfully loaded data from {file_path}. Shape: {df.shape}")
        return df
    except FileNotFoundError:
        logging.error(f"Error: File not found at {file_path}")
        return None
    except Exception as e:
        logging.error(f"Error loading data from {file_path}: {e}")
        return None

def load_augmentation_tables(input_dir="./input"):
    """Loads all other CSV files in the input directory for augmentation."""
    augmentation_data = {}
    if not os.path.exists(input_dir):
        logging.warning(f"Input directory {input_dir} not found. No augmentation tables loaded.")
        return augmentation_data

    for filename in os.listdir(input_dir):
        if filename.endswith(".csv") and "violations_per_street_2022" not in filename:
            table_name = filename.replace(".csv", "")
            file_path = os.path.join(input_dir, filename)
            df = load_data(file_path)
            if df is not None:
                augmentation_data[table_name] = df
                logging.info(f"Loaded augmentation table: {table_name}")
    return augmentation_data

def feature_engineering(df, augmentation_data):
    """
    Performs feature engineering and merges augmentation tables.
    Includes handling for potential missing keys during merges.
    """
    logging.info("Starting feature engineering...")

    # Rename columns for consistency
    df = df.rename(columns={
        'Street Name': 'street_name',
        'Violation Description': 'violation_type',
        'violation_count': 'violation_count'
    })

    # Convert street_name and violation_type to string to ensure consistency for merging and CatBoost
    df['street_name'] = df['street_name'].astype(str)
    df['violation_type'] = df['violation_type'].astype(str)

    # Augment with street_attributes if available
    if 'street_attributes' in augmentation_data:
        street_attr_df = augmentation_data['street_attributes'].copy()
        street_attr_df = street_attr_df.rename(columns={'Street Name': 'street_name'})
        street_attr_df['street_name'] = street_attr_df['street_name'].astype(str)

        # Drop duplicates in street_attributes to avoid many-to-many merge issues
        original_rows = street_attr_df.shape[0]
        street_attr_df.drop_duplicates(subset=['street_name'], inplace=True)
        if original_rows > street_attr_df.shape[0]:
            logging.warning(f"Removed {original_rows - street_attr_df.shape[0]} duplicate street_name entries from street_attributes.")

        df = pd.merge(df, street_attr_df, on='street_name', how='left')
        logging.info("Merged with street_attributes.")

    # Augment with violation_codes if available
    if 'violation_codes' in augmentation_data:
        violation_codes_df = augmentation_data['violation_codes'].copy()
        violation_codes_df = violation_codes_df.rename(columns={'Violation Description': 'violation_type'})
        violation_codes_df['violation_type'] = violation_codes_df['violation_type'].astype(str)

        # Drop duplicates in violation_codes
        original_rows = violation_codes_df.shape[0]
        violation_codes_df.drop_duplicates(subset=['violation_type'], inplace=True)
        if original_rows > violation_codes_df.shape[0]:
            logging.warning(f"Removed {original_rows - violation_codes_df.shape[0]} duplicate violation_type entries from violation_codes.")

        df = pd.merge(df, violation_codes_df, on='violation_type', how='left')
        logging.info("Merged with violation_codes.")

    # Additional simple features
    # Example: length of street name, number of words in violation type
    df['street_name_len'] = df['street_name'].apply(len)
    df['violation_type_word_count'] = df['violation_type'].apply(lambda x: len(str(x).split()))

    logging.info("Finished feature engineering. DataFrame shape: %s", df.shape)
    return df

def train_predict_evaluate(train_df, test_df=None):
    """
    Trains a CatBoost model, evaluates on a validation set,
    and generates predictions for a test set if provided.
    """
    logging.info("Starting model training and prediction process.")

    # Define features and target
    TARGET = 'violation_count'
    # Exclude the original street_name and violation_type if new features derived from them are used
    # Or keep them if CatBoost handles them as categorical features
    
    # Identify categorical features
    # CatBoost can handle NaNs in categorical features directly
    categorical_features_indices = []
    
    # Check for presence of columns before adding to features and cat_features
    features_to_use = ['street_name', 'violation_type', 'street_name_len', 'violation_type_word_count']
    
    if 'borough' in train_df.columns:
        features_to_use.append('borough')
    if 'street_width' in train_df.columns: # Example from street_attributes
        features_to_use.append('street_width')
    if 'fine_amount' in train_df.columns: # Example from violation_codes
        features_to_use.append('fine_amount')
    
    # Filter features_to_use to only include columns actually present in train_df
    features_to_use = [f for f in features_to_use if f in train_df.columns]
    
    # Identify categorical features from the final list of features
    # Assuming 'street_name', 'violation_type', 'borough' are categorical
    categorical_cols = ['street_name', 'violation_type']
    if 'borough' in features_to_use:
        categorical_cols.append('borough')

    categorical_features_indices = [features_to_use.index(col) for col in categorical_cols if col in features_to_use]

    X = train_df[features_to_use]
    y = train_df[TARGET]

    # Split 2022 data into training and validation sets
    # Using a random split, consider stratifying if target distribution is highly skewed
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    logging.info(f"Split training data: Train shape {X_train.shape}, Validation shape {X_val.shape}")

    # Initialize CatBoostRegressor
    # Loss function RMSE is specified directly
    # iterations can be tuned, early stopping can be used
    # verbose to monitor training
    # nan_mode='Max' or 'Min' or 'Forbidden' for numerical features, CatBoost handles NaN in categorical.
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=10,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=100,
        early_stopping_rounds=50,
        cat_features=categorical_features_indices,
        nan_mode='Min' # Handle NaN for numerical features by treating them as a separate category (Min)
    )

    # Create CatBoost Pool objects
    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices)

    # Train the model
    logging.info("Training CatBoostRegressor...")
    model.fit(train_pool, eval_set=val_pool, plot=False)
    logging.info("Model training complete.")

    # Evaluate on validation set
    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    logging.info(f"Validation RMSE: {val_rmse:.4f}")
    print(f"Final Validation Performance: {val_rmse:.4f}")

    # Handle unseen keys in validation set (for reporting)
    # This is implicitly handled by CatBoost, but we can report on it.
    validation_pairs = set(zip(X_val['street_name'], X_val['violation_type']))
    training_pairs = set(zip(X_train['street_name'], X_train['violation_type']))
    unseen_val_pairs = validation_pairs - training_pairs
    logging.info(f"Number of unseen (street_name, violation_type) pairs in validation set: {len(unseen_val_pairs)}")

    # Generate predictions for the test set if provided
    if test_df is not None:
        logging.info("Generating predictions for the provided test file.")
        
        # Keep original street_name and violation_type for submission
        submission_df = test_df[['street_name', 'violation_type']].copy()

        # Ensure test_df has all features used during training
        for col in features_to_use:
            if col not in test_df.columns:
                # If a feature is missing in test, fill with NaN or a default based on its type
                # For categorical, CatBoost handles NaN. For numerical, nan_mode='Min' will apply.
                test_df[col] = np.nan
                logging.warning(f"Feature '{col}' missing in test data, filled with NaN.")
        
        X_test = test_df[features_to_use]
        test_preds = model.predict(X_test)
        
        # Ensure predictions are non-negative
        test_preds[test_preds < 0] = 0
        test_preds = np.round(test_preds).astype(int) # Round to nearest integer and convert to int

        submission_df['predicted_count'] = test_preds
        submission_df.to_csv('submission.csv', index=False)
        logging.info("Submission file 'submission.csv' created.")

        # If test_df contains 'violation_count', calculate and report test RMSE
        if TARGET in test_df.columns:
            y_test_true = test_df[TARGET]
            test_rmse = np.sqrt(mean_squared_error(y_test_true, test_preds))
            logging.info(f"Test RMSE: {test_rmse:.4f}")
            
            # Report on unseen keys in test set
            test_pairs = set(zip(X_test['street_name'], X_test['violation_type']))
            unseen_test_pairs = test_pairs - training_pairs
            logging.info(f"Number of unseen (street_name, violation_type) pairs in test set: {len(unseen_test_pairs)}")
            logging.info(f"Unseen keys in test set handled by CatBoost's internal mechanism for new categories.")
        else:
            logging.info("Test file does not contain 'violation_count'. Skipping test RMSE calculation.")
    else:
        logging.info("No test file provided. Skipping test prediction and submission generation.")

    return val_rmse

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations for 2023.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help="Path to the 2022 violations training data CSV.")
    parser.add_argument('--test-path', type=str, default=None,
                        help="Optional: Path to the test data CSV for 2023 predictions.")
    
    args = parser.parse_args()

    # Load main training data
    train_df_2022 = load_data(args.train_path)
    if train_df_2022 is None:
        logging.error("Failed to load training data. Exiting.")
        return

    # Load augmentation tables
    augmentation_data = load_augmentation_tables()

    # Feature engineering for training data
    processed_train_df = feature_engineering(train_df_2022.copy(), augmentation_data)

    # Process test data if provided
    test_df_processed = None
    if args.test_path:
        test_df_raw = load_data(args.test_path)
        if test_df_raw is not None:
            test_df_processed = feature_engineering(test_df_raw.copy(), augmentation_data)
        else:
            logging.warning("Failed to load test data. Skipping test predictions.")

    # Train, predict, and evaluate
    train_predict_evaluate(processed_train_df, test_df=test_df_processed)

if __name__ == "__main__":
    main()
