
import pandas as pd
import numpy as np
import argparse
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import os

# Function to load data
def load_data(filepath, columns=None, parse_dates=None):
    """
    Loads data from a CSV file. Includes error handling for file not found
    and general loading issues.
    """
    if not os.path.exists(filepath):
        print(f"Error: File not found at {filepath}")
        return None
    try:
        # Use low_memory=False to avoid DtypeWarning with mixed types
        df = pd.read_csv(filepath, usecols=columns, parse_dates=parse_dates, low_memory=False)
        return df
    except Exception as e:
        print(f"Error loading file {filepath}: {e}")
        return None

# Function to calculate RMSE
def calculate_rmse(y_true, y_pred):
    """
    Calculates the Root Mean Squared Error (RMSE).
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                        help="Path to the training data (2022 violations).")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Path to the test/evaluation data (optional).")
    args = parser.parse_args()

    train_file_path = args.train_path
    test_file_path = args.test_path

    # --- Data Loading ---
    print(f"Loading training data from {train_file_path}...")
    train_df_raw = load_data(train_file_path)
    if train_df_raw is None:
        print("Training data could not be loaded. Exiting.")
        return

    # Rename columns for easier access
    train_df_raw.rename(columns={
        'Street Name': 'street_name',
        'Violation Description': 'violation_type',
        'violation_count': 'violation_count'
    }, inplace=True)

    # Load augmentation tables
    print("Loading augmentation data...")
    street_metadata = load_data("./input/nyc_street_metadata.csv")
    violation_codes = load_data("./input/nyc_violation_codes.csv")

    # --- Feature Engineering (Training Data) ---
    print("Performing feature engineering on training data...")
    df = train_df_raw.copy()

    # Basic features: length of street name and violation type
    df['street_name_len'] = df['street_name'].astype(str).apply(len)
    df['violation_type_len'] = df['violation_type'].astype(str).apply(len)

    # Frequency encoding using only training data
    street_freq = train_df_raw['street_name'].value_counts(normalize=True).to_dict()
    violation_freq = train_df_raw['violation_type'].value_counts(normalize=True).to_dict()

    df['street_name_freq'] = df['street_name'].map(street_freq).fillna(0)
    df['violation_type_freq'] = df['violation_type'].map(violation_freq).fillna(0)
    df['street_violation_freq_interaction'] = df['street_name_freq'] * df['violation_type_freq']

    # Join with augmentation tables if available
    if street_metadata is not None:
        street_metadata.rename(columns={'Street Name': 'street_name'}, inplace=True)
        # Drop duplicates in street_metadata based on 'street_name' to prevent merge issues
        street_metadata.drop_duplicates(subset=['street_name'], inplace=True)
        df['street_name'] = df['street_name'].astype(str)
        street_metadata['street_name'] = street_metadata['street_name'].astype(str)
        df = pd.merge(df, street_metadata[['street_name', 'Borough']], on='street_name', how='left')
        df['Borough'] = df['Borough'].fillna('Unknown') # Handle missing borough information
        print("Joined with street_metadata.")

    if violation_codes is not None:
        violation_codes.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
        # Drop duplicates in violation_codes based on 'violation_type'
        violation_codes.drop_duplicates(subset=['violation_type'], inplace=True)
        df['violation_type'] = df['violation_type'].astype(str)
        violation_codes['violation_type'] = violation_codes['violation_type'].astype(str)
        df = pd.merge(df, violation_codes[['violation_type', 'Fine Amount']], on='violation_type', how='left')
        df['Fine Amount'] = df['Fine Amount'].fillna(0) # Fill NaN with 0 or a reasonable default
        print("Joined with violation_codes.")

    # Target variable transformation (log transform for count data)
    df['violation_count_log'] = np.log1p(df['violation_count'])

    # Define all possible features that could be used in the model
    # Note: 'street_name' and 'violation_type' themselves are used by CatBoost as categorical features.
    # The _len and _freq features are numerical representations.
    candidate_features = [
        'street_name', 'violation_type', 'street_name_len', 'violation_type_len',
        'street_name_freq', 'violation_type_freq', 'street_violation_freq_interaction',
        'Borough', 'Fine Amount'
    ]
    # Filter to only include features that actually exist in the DataFrame after joins
    final_features = [f for f in candidate_features if f in df.columns]

    # Identify categorical features for CatBoost. These must be present in final_features.
    # CatBoost can accept column names directly for 'cat_features'.
    # It handles string/object types as categorical by default if not explicitly specified as numerical.
    # Explicitly list them to be safe and ensure correct handling.
    categorical_features_for_model = [
        col for col in ['street_name', 'violation_type', 'Borough'] if col in final_features
    ]
    # Ensure these columns are of string type for CatBoost's categorical handling by name
    for col in categorical_features_for_model:
        df[col] = df[col].astype(str)

    print(f"Features used in the model: {final_features}")
    print(f"Categorical features passed to CatBoost: {categorical_features_for_model}")

    X = df[final_features]
    y = df['violation_count_log']

    # --- Data Splitting (Validation) ---
    print("Splitting data for validation using grouped holdout on street names...")
    unique_street_names = df['street_name'].unique()

    X_train, X_val, y_train, y_val = pd.DataFrame(), pd.DataFrame(), pd.Series(), pd.Series()

    if len(unique_street_names) > 1: # Need at least two unique streets to split
        train_streets, val_streets = train_test_split(unique_street_names, test_size=0.2, random_state=42)
        X_train = X[X['street_name'].isin(train_streets)]
        y_train = y[X['street_name'].isin(train_streets)]
        X_val = X[X['street_name'].isin(val_streets)]
        y_val = y[X['street_name'].isin(val_streets)]

    # Fallback if grouped split results in empty sets or is not possible
    if X_train.empty or X_val.empty:
        print("Grouped split resulted in empty sets or not enough unique streets. Reverting to standard random split.")
        X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    
    if X_train.empty or X_val.empty:
        print("Error: Training or validation set is empty after splitting. Cannot proceed with training.")
        return

    print(f"Train samples: {len(X_train)}, Validation samples: {len(X_val)}")

    # --- Model Training ---
    print("Training CatBoostRegressor model...")
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=10,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=100, # Print progress every 100 iterations
        early_stopping_rounds=50,
        cat_features=categorical_features_for_model, # Pass categorical feature names
        # thread_count=-1 # Uncomment to use all available CPU cores, be mindful of RAM usage
        # This parameter might be crucial for OOM issues on large datasets.
    )

    model.fit(X_train, y_train,
              eval_set=(X_val, y_val),
              early_stopping_rounds=50,
              verbose=False) # Suppress detailed iteration output from fit, as verbose is set in constructor

    # --- Evaluation ---
    print("Evaluating model performance on validation set...")
    val_preds_log = model.predict(X_val)
    val_preds = np.expm1(val_preds_log) # Inverse transform log1p
    val_preds[val_preds < 0] = 0 # Ensure predictions are non-negative

    rmse_val = calculate_rmse(np.expm1(y_val), val_preds) # Calculate RMSE on original scale
    print(f"Final Validation Performance: {rmse_val}") # Required output format

    # --- Prediction on Test Data (if provided) ---
    if test_file_path:
        print(f"Loading test data from {test_file_path}...")
        test_df_raw = load_data(test_file_path)
        if test_df_raw is None:
            print("Test data could not be loaded. Skipping prediction.")
            return

        test_df_raw.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type',
            'violation_count': 'violation_count_actual' # Rename if present, not to be used as feature
        }, inplace=True)

        test_df = test_df_raw.copy()

        # Apply same feature engineering steps as training
        test_df['street_name_len'] = test_df['street_name'].astype(str).apply(len)
        test_df['violation_type_len'] = test_df['violation_type'].astype(str).apply(len)

        # Use frequencies from training data. Handle unseen categories by mapping to 0.
        test_df['street_name_freq'] = test_df['street_name'].map(street_freq).fillna(0)
        test_df['violation_type_freq'] = test_df['violation_type'].map(violation_freq).fillna(0)
        test_df['street_violation_freq_interaction'] = test_df['street_name_freq'] * test_df['violation_type_freq']

        # Join with augmentation tables
        if street_metadata is not None:
            test_df['street_name'] = test_df['street_name'].astype(str)
            test_df = pd.merge(test_df, street_metadata[['street_name', 'Borough']], on='street_name', how='left')
            test_df['Borough'] = test_df['Borough'].fillna('Unknown')

        if violation_codes is not None:
            test_df['violation_type'] = test_df['violation_type'].astype(str)
            test_df = pd.merge(test_df, violation_codes[['violation_type', 'Fine Amount']], on='violation_type', how='left')
            test_df['Fine Amount'] = test_df['Fine Amount'].fillna(0)

        # Ensure categorical features are of string type for CatBoost
        for col in categorical_features_for_model:
            if col in test_df.columns:
                test_df[col] = test_df[col].astype(str)

        # Identify unseen pairs
        train_pairs = set(train_df_raw.set_index(['street_name', 'violation_type']).index)
        test_pairs = set(test_df_raw.set_index(['street_name', 'violation_type']).index)
        unseen_pairs_count = len(test_pairs - train_pairs)
        print(f"Number of unseen (street_name, violation_type) pairs in test/eval set: {unseen_pairs_count}")

        # Make predictions
        # Ensure test_df has the same feature columns in the same order as X_train
        X_test = test_df[final_features]
        
        test_preds_log = model.predict(X_test)
        test_preds = np.expm1(test_preds_log)
        test_preds[test_preds < 0] = 0 # Ensure non-negative predictions

        # Generate submission file
        submission_df = test_df_raw[['street_name', 'violation_type']].copy()
        submission_df['predicted_count'] = test_preds
        submission_df.to_csv("submission.csv", index=False)
        print("Predictions saved to submission.csv")

        # Report RMSE if ground truth is available in test_path
        if 'violation_count_actual' in test_df_raw.columns and not test_df_raw['violation_count_actual'].isnull().all():
            test_rmse = calculate_rmse(test_df_raw['violation_count_actual'], test_preds)
            print(f"RMSE on test/evaluation data: {test_rmse}")
        else:
            print("No 'violation_count_actual' column found in test data for RMSE calculation or it contains only NaNs.")
    else:
        print("No test-path provided. Skipping prediction generation.")

if __name__ == "__main__":
    main()
