
import argparse
import pandas as pd
import numpy as np
import gc
import logging
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os
import sys

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Configuration Constants ---
TRAIN_FILE = './input/violations_per_street_2022.csv'
AUGMENTATION_STREET_INFO_FILE = './input/street_info.csv'
AUGMENTATION_VIOLATION_INFO_FILE = './input/violation_info.csv'
SUBMISSION_FILE = 'submission.csv'

STREET_NAME_COL = 'Street Name'
VIOLATION_DESC_COL = 'Violation Description'
VIOLATION_COUNT_COL = 'violation_count'

# --- Helper Functions ---

def reduce_mem_usage(df):
    """ Iterate through all columns of a dataframe and modify the data type
        to reduce memory usage.        
    """
    start_mem = df.memory_usage().sum() / 1024**2
    logging.info(f'Memory usage of dataframe is {start_mem:.2f} MB')

    for col in df.columns:
        col_type = df[col].dtype

        if col_type != object:
            c_min = df[col].min()
            c_max = df[col].max()
            if str(col_type)[:3] == 'int':
                if c_min > np.iinfo(np.int8).min and c_max < np.iinfo(np.int8).max:
                    df[col] = df[col].astype(np.int8)
                elif c_min > np.iinfo(np.int16).min and c_max < np.iinfo(np.int16).max:
                    df[col] = df[col].astype(np.int16)
                elif c_min > np.iinfo(np.int32).min and c_max < np.iinfo(np.int32).max:
                    df[col] = df[col].astype(np.int32)
                elif c_min > np.iinfo(np.int64).min and c_max < np.iinfo(np.int64).max:
                    df[col] = df[col].astype(np.int64)
            else:
                # Handle boolean types specifically before converting to float
                if col_type == bool:
                    df[col] = df[col].astype(np.int8)
                elif c_min > np.finfo(np.float16).min and c_max < np.finfo(np.float16).max:
                    df[col] = df[col].astype(np.float16)
                elif c_min > np.finfo(np.float32).min and c_max < np.finfo(np.float32).max:
                    df[col] = df[col].astype(np.float32)
                else:
                    df[col] = df[col].astype(np.float64)
        else:
            df[col] = df[col].astype('category')

    end_mem = df.memory_usage().sum() / 1024**2
    logging.info(f'Memory usage after optimization is: {end_mem:.2f} MB')
    logging.info(f'Decreased by {100 * (start_mem - end_mem) / start_mem:.1f}%')
    return df

def load_data(filepath, required_cols=None):
    """Loads a CSV file and handles potential errors, returning None on failure."""
    if not os.path.exists(filepath):
        logging.error(f"Error: File not found at {filepath}. Cannot proceed.")
        return None
    
    try:
        df = pd.read_csv(filepath)
        if required_cols:
            missing_cols = [col for col in required_cols if col not in df.columns]
            if missing_cols:
                logging.error(f"Error: Missing required columns {missing_cols} in {filepath}. Cannot proceed.")
                return None
        df = reduce_mem_usage(df)
        logging.info(f"Successfully loaded {filepath} with {len(df)} rows and {len(df.columns)} columns.")
        return df
    except Exception as e:
        logging.error(f"Error loading {filepath}: {e}. Cannot proceed.")
        return None

def create_dummy_augmentation_data():
    """
    Creates dummy augmentation dataframes if they don't exist.
    In a real scenario, these would be loaded from actual data sources.
    """
    try:
        # Street Info
        street_info_data = {
            STREET_NAME_COL: ['100 ST', 'BROADWAY', 'MAIN ST', 'PARK AVE', 'UNKNOWN_STREET'],
            'Borough': ['MANHATTAN', 'MANHATTAN', 'BROOKLYN', 'MANHATTAN', 'UNKNOWN'],
            'Street_Type': ['Avenue', 'Street', 'Road', 'Avenue', 'Other'],
            'Avg_Daily_Traffic_2022': [5000, 15000, 7000, 12000, 1000]
        }
        street_info_df = pd.DataFrame(street_info_data)
        street_info_df.to_csv(AUGMENTATION_STREET_INFO_FILE, index=False)
        
        # Violation Info
        violation_info_data = {
            VIOLATION_DESC_COL: ['NO STANDING', 'NO PARKING', 'FIRE HYDRANT', 'DOUBLE PARKING', 'METER EXPIRED', 'UNKNOWN_VIOLATION'],
            'Violation_Category': ['Standing', 'Parking', 'Safety', 'Parking', 'Meter', 'Other'],
            'Base_Fine_Amount': [115, 65, 180, 200, 45, 100],
            'Points_Assessed': [0, 0, 2, 0, 0, 0]
        }
        violation_info_df = pd.DataFrame(violation_info_data)
        violation_info_df.to_csv(AUGMENTATION_VIOLATION_INFO_FILE, index=False)
        
        logging.info("Created dummy augmentation files.")
    except Exception as e:
        logging.warning(f"Could not create dummy augmentation files (maybe they exist?): {e}")

def feature_engineer(df, street_info_df, violation_info_df, is_training=False):
    """Applies feature engineering steps."""
    initial_rows = len(df)
    
    # Merge with street information
    df = pd.merge(df, street_info_df, on=STREET_NAME_COL, how='left')
    
    # Fill NaNs for new street features
    for col in ['Borough', 'Street_Type', 'Avg_Daily_Traffic_2022']:
        if col in df.columns:
            if df[col].dtype == 'object' or df[col].dtype.name == 'category':
                df[col] = df[col].fillna('UNKNOWN')
            else:
                # For numerical columns, fill with median from training or 0 for test
                if is_training:
                    df[col] = df[col].fillna(df[col].median())
                else:
                    # For test set, use a sensible default or 0 if median from training is unavailable/unknown
                    # This implies 'median' would need to be stored from training, for simplicity, use 0
                    df[col] = df[col].fillna(0)
    
    # Merge with violation information
    df = pd.merge(df, violation_info_df, on=VIOLATION_DESC_COL, how='left')

    # Fill NaNs for new violation features
    for col in ['Violation_Category', 'Base_Fine_Amount', 'Points_Assessed']:
        if col in df.columns:
            if df[col].dtype == 'object' or df[col].dtype.name == 'category':
                df[col] = df[col].fillna('UNKNOWN')
            else:
                if is_training:
                    df[col] = df[col].fillna(df[col].median())
                else:
                    df[col] = df[col].fillna(0)

    # Example: Create interaction feature
    if 'Base_Fine_Amount' in df.columns and 'Avg_Daily_Traffic_2022' in df.columns:
        df['Fine_Traffic_Interaction'] = df['Base_Fine_Amount'] * df['Avg_Daily_Traffic_2022']
        df['Fine_Traffic_Interaction'] = df['Fine_Traffic_Interaction'].fillna(0) # Handle NaNs if any after interaction

    logging.info(f"Feature engineering applied. {len(df)} rows after merges (initial: {initial_rows}).")
    return df

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default=TRAIN_FILE,
                        help=f"Path to the 2022 training data (default: {TRAIN_FILE})")
    parser.add_argument('--test-path', type=str, default=None,
                        help="Optional: Path to the 2023 test/evaluation data.")
    args = parser.parse_args()

    logging.info(f"Starting prediction pipeline with train_path={args.train_path}, test_path={args.test_path}")

    # Ensure augmentation files exist for demonstration
    create_dummy_augmentation_data()

    # Load data
    train_df_2022 = load_data(args.train_path, required_cols=[STREET_NAME_COL, VIOLATION_DESC_COL, VIOLATION_COUNT_COL])
    street_info_df = load_data(AUGMENTATION_STREET_INFO_FILE)
    violation_info_df = load_data(AUGMENTATION_VIOLATION_INFO_FILE)

    # Exit early if primary data loading fails
    if train_df_2022 is None or street_info_df is None or violation_info_df is None:
        logging.error("Failed to load essential dataframes. Exiting main function.")
        return

    # Store original keys for unseen check later
    train_keys_2022 = set(train_df_2022.apply(lambda row: (row[STREET_NAME_COL], row[VIOLATION_DESC_COL]), axis=1))

    # Feature Engineering for training data
    train_df_2022 = feature_engineer(train_df_2022.copy(), street_info_df, violation_info_df, is_training=True)
    gc.collect()

    # Split 2022 data for validation
    X = train_df_2022.drop(columns=[VIOLATION_COUNT_COL])
    y = train_df_2022[VIOLATION_COUNT_COL]

    # Grouped split to ensure validation set represents similar distribution of street/violation pairs
    # Simple random split for now, ensuring sufficient data for both train/val.
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    logging.info(f"Training data shape: {X_train.shape}, Validation data shape: {X_val.shape}")

    # Define categorical features for CatBoost
    categorical_features_indices = [
        col for col in X_train.columns 
        if X_train[col].dtype == 'object' or X_train[col].dtype.name == 'category'
    ]
    
    # Initialize and train CatBoost model
    model = None
    try:
        model = CatBoostRegressor(
            iterations=1000,
            learning_rate=0.05,
            depth=8,
            loss_function='RMSE',
            eval_metric='RMSE',
            random_seed=42,
            verbose=100,
            early_stopping_rounds=50,
            cat_features=categorical_features_indices,
            # Adjust these for memory if OOM occurs
            # max_ctr_complexity=4,
            # one_hot_max_size=50,
            # used_ram_limit='1gb' # Can set a limit if needed
        )

        model.fit(X_train, y_train, eval_set=(X_val, y_val), early_stopping_rounds=50)
        
        val_preds = model.predict(X_val)
        val_rmse = np.sqrt(mean_squared_error(y_val, val_preds.clip(min=0)))
        logging.info(f"Final Validation Performance: {val_rmse}") # Required output format
        print(f"Final Validation Performance: {val_rmse}") # Ensure it's printed to stdout
    except Exception as e:
        logging.error(f"Error during CatBoost model training: {e}. Model training failed.")
        return # Exit main function if training fails

    gc.collect()

    # If test-path is provided, generate predictions
    if args.test_path and model: # Only proceed if model trained successfully
        logging.info(f"Processing test data from {args.test_path}")
        test_df = load_data(args.test_path)

        if test_df is None:
            logging.error("Failed to load test data. Skipping prediction.")
            return
        
        # Check if violation_count is in test_df (for scoring)
        has_ground_truth = VIOLATION_COUNT_COL in test_df.columns
        test_ground_truth = None
        if has_ground_truth:
            test_ground_truth = test_df[VIOLATION_COUNT_COL].copy()
            test_df_for_prediction = test_df.drop(columns=[VIOLATION_COUNT_COL])
        else:
            test_df_for_prediction = test_df.copy()

        original_test_keys = test_df_for_prediction.apply(lambda row: (row[STREET_NAME_COL], row[VIOLATION_DESC_COL]), axis=1)
        unseen_keys_count = 0
        for key in original_test_keys:
            if key not in train_keys_2022:
                unseen_keys_count += 1
        logging.info(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_keys_count}/{len(test_df_for_prediction)}")

        test_df_processed = feature_engineer(test_df_for_prediction, street_info_df, violation_info_df, is_training=False)
        gc.collect()

        # Align columns between training and test
        # CatBoost handles unseen categories by default for prediction, but missing columns need to be added.
        train_cols = set(X_train.columns)
        test_cols = set(test_df_processed.columns)
        
        missing_in_test = list(train_cols - test_cols)
        for col in missing_in_test:
            # Add missing columns to test_df_processed with a default (e.g., 0 or 'UNKNOWN')
            # and ensure their type matches the training data if possible.
            if col in categorical_features_indices:
                test_df_processed[col] = 'UNKNOWN'
                test_df_processed[col] = test_df_processed[col].astype('category')
            else:
                test_df_processed[col] = 0.0 # Default numerical to 0.0 or a sensible mean/median from training
        
        # Ensure order of columns is the same as training
        test_df_processed = test_df_processed[X_train.columns]

        test_predictions = None
        try:
            test_predictions = model.predict(test_df_processed)
            test_predictions = test_predictions.clip(min=0).round().astype(int) # Clip and round to integer counts
        except Exception as e:
            logging.error(f"Error during CatBoost model prediction on test data: {e}. Prediction failed.")
            return # Exit main function if prediction fails

        # Create submission file
        submission_df = pd.DataFrame({
            STREET_NAME_COL: test_df_for_prediction[STREET_NAME_COL],
            VIOLATION_DESC_COL: test_df_for_prediction[VIOLATION_DESC_COL],
            'predicted_count': test_predictions
        })
        submission_df.to_csv(SUBMISSION_FILE, index=False)
        logging.info(f"Predictions saved to {SUBMISSION_FILE}")

        if has_ground_truth and test_predictions is not None:
            test_rmse = np.sqrt(mean_squared_error(test_ground_truth, test_predictions))
            logging.info(f"Test Set RMSE: {test_rmse}")
        
    logging.info("Prediction pipeline finished.")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logging.critical(f"An unhandled error occurred in the main execution: {e}", exc_info=True)

