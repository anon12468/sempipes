
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import gc
import os
import sys
import subprocess
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Package Installation Check and Installation ---
def install(package):
    """Installs a pip package if it's not already installed."""
    try:
        __import__(package)
    except ImportError:
        logging.info(f"Installing {package}...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        logging.info(f"Successfully installed {package}.")

required_packages = ['pandas', 'numpy', 'scikit-learn', 'catboost', 'argparse']
for pkg in required_packages:
    # Handle different import names vs. package names
    if pkg == 'scikit-learn':
        install('sklearn')
    else:
        install(pkg)

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    initial_memory = df.memory_usage(deep=True).sum() / (1024**2)
    for col in df.columns:
        if df[col].dtype == 'int64':
            min_val, max_val = df[col].min(), df[col].max()
            if min_val >= np.iinfo(np.int8).min and max_val <= np.iinfo(np.int8).max:
                df[col] = df[col].astype(np.int8)
            elif min_val >= np.iinfo(np.int16).min and max_val <= np.iinfo(np.int16).max:
                df[col] = df[col].astype(np.int16)
            elif min_val >= np.iinfo(np.int32).min and max_val <= np.iinfo(np.int32).max:
                df[col] = df[col].astype(np.int32)
            else:
                df[col] = pd.to_numeric(df[col], downcast='integer') # Fallback
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    final_memory = df.memory_usage(deep=True).sum() / (1024**2)
    logging.info(f"  Memory reduced from {initial_memory:.2f} MB to {final_memory:.2f} MB for dataframe.")
    return df

def load_augmentation_tables(input_dir="./input"):
    """
    Loads all other CSV files in the input directory for augmentation.
    Excludes the main training data file and downcasts them.
    """
    augmentation_data = {}
    if not os.path.exists(input_dir):
        logging.warning(f"Input directory {input_dir} not found. No augmentation tables loaded.")
        return augmentation_data

    for filename in os.listdir(input_dir):
        if filename.endswith(".csv") and "violations_per_street" not in filename: # Exclude main files
            table_name = filename.replace(".csv", "")
            file_path = os.path.join(input_dir, filename)
            df = pd.read_csv(file_path)
            df = downcast_dtypes(df)
            augmentation_data[table_name] = df
            logging.info(f"Loaded augmentation table: {table_name}. Shape: {df.shape}")
    return augmentation_data


def load_and_preprocess_data(train_path, test_path=None):
    """
    Loads, preprocesses, and merges data from various sources.
    Handles memory efficiency by selective column loading, aggregation, and garbage collection.
    Integrates features from both base and reference solutions.
    """
    logging.info("Loading and preprocessing data...")

    # --- Load Core Data ---
    # Load training data
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)
    logging.info(f"Initial train_df loaded. Shape: {train_df_raw.shape}, Memory: {train_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Load test data if provided
    test_df_raw = None
    if test_path:
        test_df_raw = pd.read_csv(test_path)
        # Rename violation_count to avoid target leakage if present and create pure prediction flag
        if 'violation_count' in test_df_raw.columns:
            test_df_raw.rename(columns={'violation_count': 'violation_count_ground_truth'}, inplace=True)
            test_df_raw['is_pure_prediction'] = test_df_raw['violation_count_ground_truth'].isna()
        else:
            test_df_raw['is_pure_prediction'] = True
            test_df_raw['violation_count_ground_truth'] = np.nan # Ensure column exists
        test_df_raw.columns = [col.replace('Street Name', 'street_name').replace('Violation Description', 'violation_description') for col in test_df_raw.columns]
        test_df_raw = downcast_dtypes(test_df_raw)
        logging.info(f"Test_df loaded. Shape: {test_df_raw.shape}, Memory: {test_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Combine unique street_name and violation_description pairs from train and test
    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_keys_test = pd.DataFrame()
    if test_df_raw is not None:
        combined_keys_test = test_df_raw[['street_name', 'violation_description']].drop_duplicates()

    combined_df = pd.concat([combined_keys_train, combined_keys_test], ignore_index=True).drop_duplicates().reset_index(drop=True)
    del combined_keys_train, combined_keys_test # Free memory
    gc.collect()
    logging.info(f"Combined unique (street, violation) pairs for feature engineering. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Convert to string to ensure consistency for merging and CatBoost
    combined_df['street_name'] = combined_df['street_name'].astype(str)
    combined_df['violation_description'] = combined_df['violation_description'].astype(str)

    # --- Feature Engineering and Augmentation ---

    # Basic features from core data (Base and Reference)
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')
    combined_df['violation_description_word_count'] = combined_df['violation_description'].apply(lambda x: len(str(x).split())).astype('int16')

    # Load all augmentation tables
    augmentation_data = load_augmentation_tables()

    # Augmentation 1: nyc_street_data.csv (Base solution)
    if 'nyc_street_data' in augmentation_data:
        street_data = augmentation_data['nyc_street_data'].copy()
        street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
        street_data['street_name'] = street_data['street_name'].astype(str)
        street_data = street_data.drop_duplicates(subset=['street_name'])
        combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
        logging.info(f"Merged with nyc_street_data. Shape: {combined_df.shape}")
        del street_data
        gc.collect()
    else:
        logging.warning("nyc_street_data.csv not found. Skipping this augmentation.")

    # Augmentation 2: nyc_streets_metadata.csv (Reference solution)
    # This provides additional street features like ZipCode, assesstot
    if 'nyc_streets_metadata' in augmentation_data:
        street_metadata_df = augmentation_data['nyc_streets_metadata'].copy()
        if 'Street' in street_metadata_df.columns:
            street_metadata_df = street_metadata_df.rename(columns={'Street': 'street_name'})
        else:
            logging.warning("nyc_streets_metadata.csv does not contain 'Street' column. Skipping metadata augmentation.")
            del street_metadata_df
            gc.collect()

        if 'street_name' in locals() and not street_metadata_df.empty: # Only proceed if df is not empty after rename check
            street_metadata_df['street_name'] = street_metadata_df['street_name'].astype(str)
            street_metadata_df = street_metadata_df.drop_duplicates(subset=['street_name'], keep='first')

            # Select and clean relevant columns
            cols_to_keep = ['street_name', 'ZipCode', 'assesstot']
            street_metadata_df = street_metadata_df[[col for col in cols_to_keep if col in street_metadata_df.columns]]

            for col in street_metadata_df.columns:
                if col != 'street_name':
                    street_metadata_df[col] = pd.to_numeric(street_metadata_df[col], errors='coerce')
                    # Downcast if the data type allows
                    if street_metadata_df[col].dtype == 'float64':
                        street_metadata_df[col] = street_metadata_df[col].astype(np.float32)
                    elif street_metadata_df[col].dtype == 'int64':
                        if street_metadata_df[col].max() <= np.iinfo(np.int32).max and street_metadata_df[col].min() >= np.iinfo(np.int32).min:
                            street_metadata_df[col] = street_metadata_df[col].astype(np.int32)

            combined_df = pd.merge(combined_df, street_metadata_df, on='street_name', how='left')
            logging.info(f"Merged with nyc_streets_metadata. Shape: {combined_df.shape}")
        del street_metadata_df
        gc.collect()
    else:
        logging.warning("nyc_streets_metadata.csv not found. Skipping this augmentation.")

    # Augmentation 3: nyc_parking_zones.csv (Reference solution)
    if 'nyc_parking_zones' in augmentation_data:
        parking_zones_df = augmentation_data['nyc_parking_zones'].copy()
        if 'Street' in parking_zones_df.columns:
            parking_zones_df = parking_zones_df.rename(columns={'Street': 'street_name'})
        else:
            logging.warning("nyc_parking_zones.csv does not contain 'Street' column. Skipping parking zones augmentation.")
            del parking_zones_df
            gc.collect()

        if 'street_name' in parking_zones_df.columns and not parking_zones_df.empty:
            parking_zones_df['street_name'] = parking_zones_df['street_name'].astype(str)
            # Aggregate parking zone information per street_name
            # Ensure 'parking_zone' column exists
            if 'parking_zone' in parking_zones_df.columns:
                parking_zone_features = parking_zones_df.groupby('street_name')['parking_zone'].nunique().reset_index()
                parking_zone_features.rename(columns={'parking_zone': 'num_parking_zones'}, inplace=True)
                parking_zone_features['num_parking_zones'] = parking_zone_features['num_parking_zones'].astype('int16')

                combined_df = pd.merge(combined_df, parking_zone_features, on='street_name', how='left')
                combined_df['num_parking_zones'] = combined_df['num_parking_zones'].fillna(0).astype('int16') # Fill NaN for streets with no parking zone info
                logging.info(f"Merged with nyc_parking_zones. Shape: {combined_df.shape}")
                del parking_zone_features
            else:
                logging.warning("nyc_parking_zones.csv does not contain 'parking_zone' column.")
        del parking_zones_df
        gc.collect()
    else:
        logging.warning("nyc_parking_zones.csv not found. Skipping this augmentation.")

    # Augmentation 4: violation codes (Base: nyc_violation_codes.csv, Reference: violation_codes.csv)
    if 'nyc_violation_codes' in augmentation_data:
        violation_codes = augmentation_data['nyc_violation_codes'].copy()
        violation_codes.columns = ['violation_description', 'fine_amount', 'points']
        violation_codes['violation_description'] = violation_codes['violation_description'].astype(str)
        violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
        combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
        logging.info(f"Merged with nyc_violation_codes. Shape: {combined_df.shape}")
        del violation_codes
        gc.collect()
    elif 'violation_codes' in augmentation_data: # Fallback for reference solution's naming
        violation_codes = augmentation_data['violation_codes'].copy()
        violation_codes.columns = [col.lower().replace(' ', '_') for col in violation_codes.columns] # Standardize names
        if 'violation_description' in violation_codes.columns and 'fine_amount' in violation_codes.columns:
            violation_codes['violation_description'] = violation_codes['violation_description'].astype(str)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes[['violation_description', 'fine_amount']], on='violation_description', how='left')
            logging.info(f"Merged with violation_codes (from reference). Shape: {combined_df.shape}")
        else:
            logging.warning("Violation codes CSV (reference) missing key columns like 'violation_description' or 'fine_amount'.")
        del violation_codes
        gc.collect()
    else:
        logging.warning("Neither nyc_violation_codes.csv nor violation_codes.csv found. Skipping violation codes augmentation.")

    # Augmentation 5: nyc_census_data.csv (Base and Reference solution)
    if 'nyc_census_data' in augmentation_data and 'borough' in combined_df.columns:
        census_data = augmentation_data['nyc_census_data'].copy()
        census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
        
        # Combine relevant columns from both base and reference solutions
        relevant_census_cols = ['borough', 'population_density', 'avg_income', 'population', 'median_income', 'num_households']
        
        # Filter to actual columns present
        census_cols_present = [col for col in relevant_census_cols if col in census_data.columns]
        
        if len(census_cols_present) > 1: # At least 'borough' and one other feature
            census_agg = census_data.groupby('borough')[list(set(census_cols_present) - {'borough'})].mean().reset_index()
            census_agg = downcast_dtypes(census_agg)
            combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
            logging.info(f"Merged with census_data. Shape: {combined_df.shape}")
            del census_data, census_agg
            gc.collect()
        else:
            logging.warning(f"Missing enough relevant columns in nyc_census_data. Skipping census data augmentation.")
    else:
        logging.warning("nyc_census_data.csv not found or 'borough' column missing. Skipping census data augmentation.")

    # Handle missing numerical values (introduced by left merges)
    for col in combined_df.select_dtypes(include=np.number).columns:
        if combined_df[col].isnull().any():
            median_val = combined_df[col].median()
            combined_df[col] = combined_df[col].fillna(median_val)
            logging.debug(f"Filled NaN in numerical column '{col}' with median: {median_val}")

    # Handle missing categorical values
    for col in combined_df.select_dtypes(include=['object', 'category']).columns:
        if combined_df[col].isnull().any():
            combined_df[col] = combined_df[col].fillna('Unknown_Category')
            logging.debug(f"Filled NaN in categorical column '{col}' with 'Unknown_Category'")


    # Split back into train and test processed dataframes
    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    test_processed_df = None
    if test_df_raw is not None:
        test_processed_df = pd.merge(test_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
        del test_df_raw
        gc.collect()

    logging.info(f"Final train_processed_df shape: {train_processed_df.shape}")
    if test_processed_df is not None:
        logging.info(f"Final test_processed_df shape: {test_processed_df.shape}")

    # Identify categorical features for CatBoost
    # All columns that are not 'violation_count' or 'violation_count_ground_truth' or 'is_pure_prediction'
    # and are of object or category dtype.
    all_potential_features = [col for col in train_processed_df.columns if col not in ['violation_count', 'violation_count_ground_truth', 'is_pure_prediction']]
    categorical_features = [col for col in all_potential_features if train_processed_df[col].dtype in ['object', 'category']]

    # Ensure all identified categorical columns are explicitly of 'category' dtype for CatBoost
    for col in categorical_features:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].astype('category')
        if test_processed_df is not None and col in test_processed_df.columns:
            test_processed_df[col] = test_processed_df[col].astype('category')

    logging.info(f"Categorical features identified for CatBoost: {categorical_features}")

    return train_processed_df, test_processed_df, categorical_features

def train_and_predict(train_df, test_df, categorical_features):
    """
    Trains two distinct CatBoost Regressor models (one from base, one from reference solution),
    ensembles their predictions, and generates final predictions.
    """
    logging.info("Training CatBoost models and ensembling predictions...")

    # Define features (X) and target (y)
    target = 'violation_count'
    # Use all available features except the target and `is_pure_prediction` flag
    features = [col for col in train_df.columns if col not in [target, 'violation_count_ground_truth', 'is_pure_prediction']]

    X = train_df[features]
    y = train_df[target]

    # Split training data for validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    logging.info(f"Training data split: X_train={X_train.shape}, X_val={X_val.shape}")

    # Convert categorical feature names to their indices for CatBoost
    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]
    logging.info(f"Categorical feature indices for CatBoost: {cat_features_indices}")

    # --- Model 1: Base Solution CatBoost Model ---
    logging.info("Training Model 1 (Base CatBoost Model)...")
    model_base = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6, # Base solution's depth
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Set to 0 to prevent excessive output during two trainings
        early_stopping_rounds=50,
        thread_count=-1,
    )
    model_base.fit(X_train, y_train,
                   eval_set=(X_val, y_val),
                   cat_features=cat_features_indices,
                   plot=False)
    val_preds_base = model_base.predict(X_val)
    logging.info(f"Model 1 (Base) finished training. Best iteration: {model_base.get_best_iteration()}")

    # --- Model 2: Reference Solution CatBoost Model ---
    logging.info("Training Model 2 (Reference CatBoost Model)...")
    model_ref = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=8, # Reference solution's depth
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Set to 0 to prevent excessive output during two trainings
        early_stopping_rounds=100, # Reference solution's early stopping
        l2_leaf_reg=3.0,
        thread_count=-1,
        nan_mode='Min' # Reference solution's nan handling for numerical features
    )
    # Create CatBoost Pool objects for reference model as per reference solution
    train_pool_ref = Pool(X_train, y_train, cat_features=cat_features_indices)
    val_pool_ref = Pool(X_val, y_val, cat_features=cat_features_indices)

    model_ref.fit(train_pool_ref, eval_set=val_pool_ref, plot=False)
    val_preds_ref = model_ref.predict(X_val)
    logging.info(f"Model 2 (Reference) finished training. Best iteration: {model_ref.get_best_iteration()}")

    # --- Ensembling Validation Predictions ---
    # Simple average ensemble
    val_preds_ensemble = (val_preds_base + val_preds_ref) / 2
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds_ensemble))
    logging.info(f"Ensembled Development Validation RMSE: {val_rmse}")

    # Generate predictions for the test_df if provided
    submission_df = None
    if test_df is not None:
        logging.info("Generating ensembled predictions for test data...")
        X_test = test_df[features]

        # Get predictions from both models
        test_preds_base = model_base.predict(X_test)
        test_preds_ref = model_ref.predict(X_test)

        # Ensemble test predictions
        test_preds_ensemble = (test_preds_base + test_preds_ref) / 2

        # Ensure predictions are non-negative and round to nearest integer
        test_preds_ensemble[test_preds_ensemble < 0] = 0
        test_preds_ensemble = np.round(test_preds_ensemble).astype(int)

        # Create submission dataframe
        submission_df = test_df[['street_name', 'violation_description']].copy()
        submission_df['predicted_count'] = test_preds_ensemble

        # Report RMSE if ground truth is available in test_df
        if 'is_pure_prediction' in test_df.columns and not test_df['is_pure_prediction'].all():
            ground_truth_test_df = test_df[~test_df['is_pure_prediction']].copy()
            ground_truth_preds = submission_df[~test_df['is_pure_prediction']]['predicted_count']
            test_rmse = np.sqrt(mean_squared_error(ground_truth_test_df['violation_count_ground_truth'], ground_truth_preds))
            logging.info(f"Ensembled RMSE on provided test/evaluation data (with ground truth): {test_rmse}")
        elif 'violation_count_ground_truth' in test_df.columns and not test_df['violation_count_ground_truth'].isnull().all(): # if target exists but no explicit flag
             test_rmse = np.sqrt(mean_squared_error(test_df['violation_count_ground_truth'], test_preds_ensemble))
             logging.info(f"Ensembled RMSE on provided test/evaluation data: {test_rmse}")


        # Report unseen key pairs (from reference solution)
        train_keys = set(train_df.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
        test_keys = set(test_df.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
        unseen_keys_count = len(test_keys - train_keys)
        logging.info(f"Number of (street_name, violation_description) pairs in test/eval unseen in training: {unseen_keys_count}")
        logging.info("Unseen keys are handled by CatBoost's internal mechanism for new categorical levels.")

    return submission_df, val_rmse

def main():
    """
    Main function to parse arguments, orchestrate data loading, training, and prediction.
    """
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional path to the 2023 test/evaluation data CSV. '
                             'If provided, predictions will be generated and RMSE reported if ground truth exists.')
    args = parser.parse_args()

    train_df, test_df, categorical_features = load_and_preprocess_data(args.train_path, args.test_path)
    submission_df, final_validation_score = train_and_predict(train_df, test_df, categorical_features)

    if submission_df is not None:
        # Align submission columns to match reference solution's expected output
        submission_df.columns = ['street_name', 'violation_type', 'predicted_count']
        submission_df.to_csv('submission.csv', index=False)
        logging.info("Submission file 'submission.csv' generated successfully.")

    # Always print the final validation score
    print(f"Final Validation Performance: {final_validation_score}")

if __name__ == "__main__":
    main()
