
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    return df

def load_and_preprocess_data_for_ablation(train_path, test_path=None, 
                                           enable_street_type_feature=True, 
                                           enable_violation_category_feature=True, 
                                           apply_downcasting_on_raw_data=True):
    """
    Loads, preprocesses, and merges data from various sources, with flags for ablation.
    """
    # --- Load Core Data ---
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    
    if apply_downcasting_on_raw_data:
        train_df_raw = downcast_dtypes(train_df_raw)
    
    # For ablation study, we only focus on training and validation, so test_df_raw is not used.
    test_df_raw = None

    # Ensure the merge keys are of 'object' type for consistent merging behavior
    # This is important because pd.merge can behave differently with category dtypes.
    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    if combined_keys_train['street_name'].dtype != 'object':
        combined_keys_train['street_name'] = combined_keys_train['street_name'].astype(str)
    if combined_keys_train['violation_description'].dtype != 'object':
        combined_keys_train['violation_description'] = combined_keys_train['violation_description'].astype(str)

    combined_keys_test = pd.DataFrame() # Always empty for this ablation study setup

    combined_df = pd.concat([combined_keys_train, combined_keys_test], ignore_index=True).drop_duplicates().reset_index(drop=True)
    del combined_keys_train, combined_keys_test
    gc.collect()

    # --- Feature Engineering ---
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # Feature: street_type (Ablation Point 1)
    if enable_street_type_feature:
        def get_street_type(street_name):
            if not isinstance(street_name, str): return 'Other'
            street_name_upper = street_name.upper()
            if street_name_upper.endswith(' ST') or street_name_upper.endswith(' STREET'): return 'Street'
            elif street_name_upper.endswith(' AVE') or street_name_upper.endswith(' AVENUE'): return 'Avenue'
            elif street_name_upper.endswith(' BLVD') or street_name_upper.endswith(' BOULEVARD'): return 'Boulevard'
            elif street_name_upper.endswith(' RD') or street_name_upper.endswith(' ROAD'): return 'Road'
            elif street_name_upper.endswith(' DR') or street_name_upper.endswith(' DRIVE'): return 'Drive'
            elif street_name_upper.endswith(' CT') or street_name_upper.endswith(' COURT'): return 'Court'
            elif street_name_upper.endswith(' LN') or street_name_upper.endswith(' LANE'): return 'Lane'
            elif street_name_upper.endswith(' PL') or street_name_upper.endswith(' PLACE'): return 'Place'
            elif street_name_upper.endswith(' PKWY') or street_name_upper.endswith(' PARKWAY'): return 'Parkway'
            elif street_name_upper.endswith(' TER') or street_name_upper.endswith(' TERRACE'): return 'Terrace'
            elif street_name_upper.endswith(' WY') or street_name_upper.endswith(' WAY'): return 'Way'
            elif street_name_upper.endswith(' EXPY') or street_name_upper.endswith(' EXPRESSWAY'): return 'Expressway'
            elif street_name_upper.endswith(' HWY') or street_name_upper.endswith(' HIGHWAY'): return 'Highway'
            return 'Other'
        combined_df['street_type'] = combined_df['street_name'].apply(get_street_type)
    
    # Feature: violation_category (Ablation Point 2)
    if enable_violation_category_feature:
        def get_violation_category(description):
            if not isinstance(description, str): return 'Other'
            desc_upper = description.upper()
            if 'PARKING' in desc_upper: return 'Parking'
            elif 'STANDING' in desc_upper: return 'Standing'
            elif 'METER' in desc_upper: return 'Meter'
            elif 'BUS STOP' in desc_upper: return 'Bus Stop'
            elif 'HYDRANT' in desc_upper: return 'Hydrant'
            elif 'NO STOPPING' in desc_upper: return 'No Stopping'
            elif 'COMMERCIAL' in desc_upper: return 'Commercial'
            elif 'LOADING ZONE' in desc_upper: return 'Loading Zone'
            return 'Other'
        combined_df['violation_category'] = combined_df['violation_description'].apply(get_violation_category)
    
    # --- External Data Augmentation ---
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data) 
            if street_data['street_name'].dtype != 'object': # Ensure merge key is object
                street_data['street_name'] = street_data['street_name'].astype(str)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data; gc.collect()
        except Exception as e: pass
    
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            if violation_codes['violation_description'].dtype != 'object': # Ensure merge key is object
                violation_codes['violation_description'] = violation_codes['violation_description'].astype(str)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes; gc.collect()
        except Exception as e: pass

    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        if 'borough' in combined_df.columns:
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    if census_agg['borough'].dtype != 'object': # Ensure merge key is object
                        census_agg['borough'] = census_agg['borough'].astype(str)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg; gc.collect()
            except Exception as e: pass

    # Ensure 'street_name' and 'violation_description' in train_df_raw are 'object' before final merge
    # to avoid potential type conflicts with combined_df (which also has them as 'object' for merging).
    if train_df_raw['street_name'].dtype != 'object':
        train_df_raw['street_name'] = train_df_raw['street_name'].astype(str)
    if train_df_raw['violation_description'].dtype != 'object':
        train_df_raw['violation_description'] = train_df_raw['violation_description'].astype(str)

    # After all feature engineering, merge with raw train_df
    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw, combined_df
    gc.collect()

    # Explicitly convert all identified categorical columns to 'category' dtype for CatBoost
    # This is crucial to ensure CatBoost recognizes them as categorical, overriding any
    # default pandas type inference after merges.
    potential_cat_cols = ['street_name', 'violation_description']
    if enable_street_type_feature:
        potential_cat_cols.append('street_type')
    if enable_violation_category_feature:
        potential_cat_cols.append('violation_category')
    if 'borough' in train_processed_df.columns:
        potential_cat_cols.append('borough')

    for col in potential_cat_cols:
        if col in train_processed_df.columns:
            if train_processed_df[col].isnull().any():
                train_processed_df[col] = train_processed_df[col].fillna('Unknown_Category') # Explicit NaN filling
            train_processed_df[col] = train_processed_df[col].astype('category')
    
    # Identify categorical features for CatBoost from the final train_processed_df
    categorical_features = [col for col in train_processed_df.columns if train_processed_df[col].dtype == 'category']

    # Remove features that were conditionally disabled from the final list and dataframe
    if not enable_street_type_feature and 'street_type' in categorical_features:
        categorical_features.remove('street_type')
        if 'street_type' in train_processed_df.columns:
            train_processed_df = train_processed_df.drop(columns=['street_type'])
    if not enable_violation_category_feature and 'violation_category' in categorical_features:
        categorical_features.remove('violation_category')
        if 'violation_category' in train_processed_df.columns:
            train_processed_df = train_processed_df.drop(columns=['violation_category'])
    
    # Filter out columns that might not exist in the dataframe (e.g., if external data was not loaded)
    categorical_features = [f for f in categorical_features if f in train_processed_df.columns]
    
    return train_processed_df, test_df_raw, categorical_features

def train_and_predict_for_ablation(train_df, test_df, categorical_features):
    """
    Trains a CatBoost Regressor model and reports RMSE for validation.
    Optimized for ablation study with reduced verbose output.
    """
    features = [col for col in train_df.columns if col not in ['violation_count']] 
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    # Ensure all identified categorical features in X are indeed category dtype
    for col in categorical_features:
        if col in X.columns and X[col].dtype != 'category':
            X[col] = X[col].astype('category')

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6,
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Suppress verbose output during training
        early_stopping_rounds=50,
        cat_features=[col for col in categorical_features if col in X_train.columns] # Pass column names directly
    )
    
    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        raise

    val_preds = model.predict(X_val)
    val_preds[val_preds < 0] = 0 # Ensure non-negative predictions
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    
    return None, val_rmse

def ablation_study_main():
    train_path = './input/violations_per_street_2022.csv'
    
    # Create dummy external data files with headers if they don't exist
    os.makedirs('./input', exist_ok=True)
    dummy_files_content = {
        'nyc_street_data.csv': 'Street Name,Borough,Street Length,Number of Lanes\n',
        'nyc_violation_codes.csv': 'Violation Description,Fine Amount,Points\n',
        'nyc_census_data.csv': 'Borough,Population_Density,Avg_Income\n'
    }
    for fname, header in dummy_files_content.items():
        if not os.path.exists(f'./input/{fname}'):
            with open(f'./input/{fname}', 'w') as f:
                f.write(header)
    
    # Create a dummy violations_per_street_2022.csv for testing if it doesn't exist
    if not os.path.exists(train_path):
        print(f"Creating dummy train file: {train_path}")
        dummy_train_data = {
            'Street Name': ['BROADWAY', 'MAIN ST', 'ELM AVE', 'BROADWAY', 'MAIN ST', 'PARK ROW', 'WEST ST'],
            'Violation Description': ['NO PARKING', 'STANDING COMML VEH', 'METER EXPIRED', 'DOUBLE PARKING', 'NO STANDING', 'BUS STOP', 'HYDRANT'],
            'violation_count': [100, 50, 75, 120, 60, 30, 45]
        }
        pd.DataFrame(dummy_train_data).to_csv(train_path, index=False)
        
    results = {}

    print("--- Running Ablation Study ---")

    # Base Case
    print("\nScenario: Base Case (All new features enabled, downcasting on raw data)")
    train_df, _, categorical_features = load_and_preprocess_data_for_ablation(
        train_path, None, enable_street_type_feature=True, 
        enable_violation_category_feature=True, apply_downcasting_on_raw_data=True
    )
    _, base_rmse = train_and_predict_for_ablation(train_df, None, categorical_features)
    results['Base Case'] = base_rmse
    print(f"Base Case Validation RMSE: {base_rmse:.4f}")

    # Ablation 1: No 'street_type' feature
    print("\nScenario: Ablation 1 - No 'street_type' feature")
    train_df_ablation1, _, categorical_features_ablation1 = load_and_preprocess_data_for_ablation(
        train_path, None, enable_street_type_feature=False, 
        enable_violation_category_feature=True, apply_downcasting_on_raw_data=True
    )
    _, rmse_ablation1 = train_and_predict_for_ablation(train_df_ablation1, None, categorical_features_ablation1)
    results['No Street Type Feature'] = rmse_ablation1
    print(f"Ablation 1 ('No Street Type Feature') Validation RMSE: {rmse_ablation1:.4f}")

    # Ablation 2: No 'violation_category' feature
    print("\nScenario: Ablation 2 - No 'violation_category' feature")
    train_df_ablation2, _, categorical_features_ablation2 = load_and_preprocess_data_for_ablation(
        train_path, None, enable_street_type_feature=True, 
        enable_violation_category_feature=False, apply_downcasting_on_raw_data=True
    )
    _, rmse_ablation2 = train_and_predict_for_ablation(train_df_ablation2, None, categorical_features_ablation2)
    results['No Violation Category Feature'] = rmse_ablation2
    print(f"Ablation 2 ('No Violation Category Feature') Validation RMSE: {rmse_ablation2:.4f}")

    # Ablation 3: No downcasting on raw data
    print("\nScenario: Ablation 3 - No downcasting on raw train_df_raw (e.g., initial violations_per_street_2022.csv)")
    train_df_ablation3, _, categorical_features_ablation3 = load_and_preprocess_data_for_ablation(
        train_path, None, enable_street_type_feature=True, 
        enable_violation_category_feature=True, apply_downcasting_on_raw_data=False
    )
    _, rmse_ablation3 = train_and_predict_for_ablation(train_df_ablation3, None, categorical_features_ablation3)
    results['No Downcasting on Raw Data'] = rmse_ablation3
    print(f"Ablation 3 ('No Downcasting on Raw Data') Validation RMSE: {rmse_ablation3:.4f}")

    print("\n--- Ablation Study Summary ---")
    final_validation_score = None 
    for scenario, rmse in results.items():
        print(f"{scenario}: RMSE = {rmse:.4f}")
        if scenario == 'Base Case':
            final_validation_score = rmse

    if final_validation_score is not None:
        print(f"Final Validation Performance: {final_validation_score}")

    # Determine the most contributing part
    deltas = {}
    if 'No Street Type Feature' in results:
        deltas['street_type feature'] = results['No Street Type Feature'] - base_rmse
    if 'No Violation Category Feature' in results:
        deltas['violation_category feature'] = results['No Violation Category Feature'] - base_rmse
    if 'No Downcasting on Raw Data' in results:
        deltas['downcasting on raw data'] = results['No Downcasting on Raw Data'] - base_rmse

    if not deltas:
        print("\nNo significant change observed across ablations.")
        return

    # Find the largest absolute change to determine the most impactful component
    most_impactful_component_name = max(deltas, key=lambda k: abs(deltas[k]))
    impact_value = deltas[most_impactful_component_name]

    if impact_value > 0:
        print(f"\nThe most contributing part (whose removal caused the largest degradation) is: '{most_impactful_component_name}' (RMSE increased by {impact_value:.4f}).")
    elif impact_value < 0:
        print(f"\nThe most impactful change (whose removal caused the largest improvement) is: '{most_impactful_component_name}' (RMSE decreased by {-impact_value:.4f}). This component was detrimental.")
    else:
        print(f"\nThe '{most_impactful_component_name}' had no measurable impact (RMSE change of {impact_value:.4f}).")

if __name__ == "__main__":
    ablation_study_main()
