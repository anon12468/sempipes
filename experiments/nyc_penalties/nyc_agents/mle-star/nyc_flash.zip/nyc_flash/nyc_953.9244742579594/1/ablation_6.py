
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    # initial_memory = df.memory_usage(deep=True).sum() / (1024**2) # Suppress for cleaner output
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    # final_memory = df.memory_usage(deep=True).sum() / (1024**2) # Suppress for cleaner output
    return df

def load_and_preprocess_data_ablated(train_path,
                                    enable_freq_encoding=True,
                                    enable_numerical_interaction_features=True):
    """
    Loads, preprocesses, and merges data from various sources, with ablation options.
    Note: test_path is explicitly not used, focusing only on training data.
    """
    # print(f"Preprocessing data (freq_encoding={enable_freq_encoding}, interactions={enable_numerical_interaction_features})...")

    # --- Load Core Data ---
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)

    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_df = combined_keys_train.reset_index(drop=True)
    del combined_keys_train
    gc.collect()

    # --- Feature Engineering and Augmentation ---

    # Basic features from core data
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # Frequency encoding for high-cardinality categorical features (Ablation Point 1)
    if enable_freq_encoding:
        if 'street_name' in combined_df.columns:
            street_name_counts = train_df_raw['street_name'].value_counts() # Use raw train_df for counts to avoid test data leakage (even though we're not using test here, good practice)
            combined_df['street_name_freq'] = combined_df['street_name'].map(street_name_counts).astype('int32')

        if 'violation_description' in combined_df.columns:
            violation_desc_counts = train_df_raw['violation_description'].value_counts()
            combined_df['violation_desc_freq'] = combined_df['violation_description'].map(violation_desc_counts).astype('int32')
        gc.collect()

    # Augmentation 1: nyc_street_data.csv
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
        except Exception:
            pass # Suppress detailed error messages for cleaner ablation output
    
    # Augmentation 2: nyc_violation_codes.csv
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
        except Exception:
            pass

    # Augmentation 3: nyc_census_data.csv
    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        if 'borough' in combined_df.columns:
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
            except Exception:
                pass
        
    # --- Numerical Interaction Features (Ablation Point 2) ---
    if enable_numerical_interaction_features:
        # Interaction: Fine Amount per Street Length
        if all(col in combined_df.columns for col in ['fine_amount', 'street_length']):
            combined_df['fine_amount_per_street_length'] = (
                combined_df['fine_amount'] / combined_df['street_length'].replace(0, np.nan)
            ).astype('float32')

        # Interaction: Population Density per Street Length
        if all(col in combined_df.columns for col in ['population_density', 'street_length']):
            combined_df['density_per_street_length'] = (
                combined_df['population_density'] / combined_df['street_length'].replace(0, np.nan)
            ).astype('float32')

        # Interaction: Fine Amount multiplied by Number of Lanes
        if all(col in combined_df.columns for col in ['fine_amount', 'num_lanes']):
            combined_df['fine_amount_x_num_lanes'] = (
                combined_df['fine_amount'] * combined_df['num_lanes']
            ).astype('float32')
            
        # Interaction: Average Income per Population Density
        if all(col in combined_df.columns for col in ['avg_income', 'population_density']):
            combined_df['avg_income_per_capita_density'] = (
                combined_df['avg_income'] / combined_df['population_density'].replace(0, np.nan)
            ).astype('float32')
        gc.collect()

    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    test_processed_df = None # Always None for ablation study

    candidate_categorical_features = []
    for col in train_processed_df.columns:
        if train_processed_df[col].dtype in ['object', 'category']:
            candidate_categorical_features.append(col)

    if 'violation_count' in candidate_categorical_features:
        candidate_categorical_features.remove('violation_count')

    for col in candidate_categorical_features:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].fillna('NaN_category_placeholder').astype('category')
    
    features_to_be_used_in_model = [col for col in train_processed_df.columns if col not in ['violation_count']]
    final_categorical_features_for_catboost = [col for col in candidate_categorical_features if col in features_to_be_used_in_model]
    
    if 'street_name' not in final_categorical_features_for_catboost and 'street_name' in train_processed_df.columns:
        final_categorical_features_for_catboost.append('street_name')
    if 'violation_description' not in final_categorical_features_for_catboost and 'violation_description' in train_processed_df.columns:
        final_categorical_features_for_catboost.append('violation_description')

    final_categorical_features_for_catboost = list(set(final_categorical_features_for_catboost))
    
    return train_processed_df, test_processed_df, final_categorical_features_for_catboost

def train_and_evaluate_ablated(train_df, categorical_features, learning_rate=0.05):
    """
    Trains a CatBoost Regressor model and evaluates on validation set.
    """
    features = [col for col in train_df.columns if col not in ['violation_count']]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=learning_rate, # Ablation Point 3
        depth=6,
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Suppress verbose output for clean ablation results
        early_stopping_rounds=50,
        grow_policy='Lossguide',
        max_leaves=31,
        use_best_model=True
    )

    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        raise

    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    return val_rmse

def main_ablation():
    train_path = './input/violations_per_street_2022.csv'
    
    # Ensure './input' directory exists for dummy files
    if not os.path.exists('./input'):
        os.makedirs('./input')
    
    # Create dummy external data files with minimal headers if they don't exist
    # This allows the data loading to proceed without FileNotFoundError, but the data will be sparse.
    dummy_street_data_path = './input/nyc_street_data.csv'
    dummy_violation_codes_path = './input/nyc_violation_codes.csv'
    dummy_census_data_path = './input/nyc_census_data.csv'

    if not os.path.exists(dummy_street_data_path):
        pd.DataFrame(columns=['Street Name', 'Borough', 'Street Length', 'Number of Lanes']).to_csv(dummy_street_data_path, index=False)
    if not os.path.exists(dummy_violation_codes_path):
        pd.DataFrame(columns=['Violation Description', 'Fine Amount', 'Points']).to_csv(dummy_violation_codes_path, index=False)
    if not os.path.exists(dummy_census_data_path):
        pd.DataFrame(columns=['Borough', 'Population Density', 'Avg Income']).to_csv(dummy_census_data_path, index=False)


    results = {}

    # Base Case
    print("--- Running Base Case ---")
    train_df_base, _, cat_features_base = load_and_preprocess_data_ablated(train_path)
    rmse_base = train_and_evaluate_ablated(train_df_base, cat_features_base)
    results['Base Case'] = rmse_base
    print(f"Base Case Validation RMSE: {rmse_base:.4f}\n")
    del train_df_base, cat_features_base
    gc.collect()

    # Ablation 1: No Frequency Encoding Features
    print("--- Running Ablation: No Frequency Encoding Features ---")
    train_df_no_freq, _, cat_features_no_freq = load_and_preprocess_data_ablated(train_path, enable_freq_encoding=False)
    rmse_no_freq = train_and_evaluate_ablated(train_df_no_freq, cat_features_no_freq)
    results['No Frequency Encoding Features'] = rmse_no_freq
    print(f"No Frequency Encoding Features Validation RMSE: {rmse_no_freq:.4f}\n")
    del train_df_no_freq, cat_features_no_freq
    gc.collect()

    # Ablation 2: No Numerical Interaction Features
    print("--- Running Ablation: No Numerical Interaction Features ---")
    train_df_no_interactions, _, cat_features_no_interactions = load_and_preprocess_data_ablated(train_path, enable_numerical_interaction_features=False)
    rmse_no_interactions = train_and_evaluate_ablated(train_df_no_interactions, cat_features_no_interactions)
    results['No Numerical Interaction Features'] = rmse_no_interactions
    print(f"No Numerical Interaction Features Validation RMSE: {rmse_no_interactions:.4f}\n")
    del train_df_no_interactions, cat_features_no_interactions
    gc.collect()

    # Ablation 3: CatBoost Learning Rate 0.03 (vs default 0.05)
    print("--- Running Ablation: CatBoost Learning Rate 0.03 ---")
    train_df_lr_changed, _, cat_features_lr_changed = load_and_preprocess_data_ablated(train_path) # Data is the same as base
    rmse_lr_changed = train_and_evaluate_ablated(train_df_lr_changed, cat_features_lr_changed, learning_rate=0.03)
    results['CatBoost Learning Rate 0.03'] = rmse_lr_changed
    print(f"CatBoost Learning Rate 0.03 Validation RMSE: {rmse_lr_changed:.4f}\n")
    del train_df_lr_changed, cat_features_lr_changed
    gc.collect()

    print("\n--- Ablation Study Results Summary ---")
    for name, rmse in results.items():
        delta = rmse - results['Base Case']
        print(f"{name}: RMSE = {rmse:.4f} (Delta from Base: {delta:+.4f})")

    # Determine the most contributing part
    most_impactful_change_desc = "None of the ablations showed a significant impact compared to the Base Case."
    largest_abs_impact = 0.0

    for name, rmse in results.items():
        if name == 'Base Case':
            continue
        delta = rmse - results['Base Case']
        if abs(delta) > largest_abs_impact:
            largest_abs_impact = abs(delta)
            if "No " in name:
                if delta > 0: # Removal worsened performance -> the feature was beneficial
                    most_impactful_change_desc = f"The presence of '{name.replace('No ', '')}' (its removal worsened RMSE by {delta:.4f})."
                else: # Removal improved performance -> the feature was detrimental
                    most_impactful_change_desc = f"The removal of '{name.replace('No ', '')}' (it improved RMSE by {abs(delta):.4f}, indicating it was detrimental to the Base Case)."
            else: # Parameter change
                if delta < 0: # Change improved performance
                    most_impactful_change_desc = f"The modification: '{name}' (it improved RMSE by {abs(delta):.4f})."
                else: # Change worsened performance
                    most_impactful_change_desc = f"The modification: '{name}' (it worsened RMSE by {delta:.4f})."
    
    print(f"\n--- Conclusion on Most Contributing Part ---")
    print(f"Based on this ablation study, the part of the code that contributes the most to the overall performance (or has the largest absolute impact) is:")
    print(f"{most_impactful_change_desc}")


if __name__ == "__main__":
    main_ablation()
