
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    # Using deep=True for accurate memory usage
    # initial_memory = df.memory_usage(deep=True).sum() / (1024**2)
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    # final_memory = df.memory_usage(deep=True).sum() / (1024**2)
    return df

def load_and_preprocess_data_ablated(train_path, test_path=None, 
                                     include_avg_word_len_features=True,
                                     include_raw_high_cardinality_cats=True):
    """
    Loads, preprocesses, and merges data from various sources.
    Handles memory efficiency by selective column loading, aggregation, and garbage collection.
    Ablation parameters:
    - include_avg_word_len_features: If False, 'street_name_avg_word_len' and 'violation_desc_avg_word_len' are not added.
    - include_raw_high_cardinality_cats: If False, 'street_name' and 'violation_description' are removed from the final feature set
                                         passed to the model, but still used for creating other features.
    """
    # print("Loading and preprocessing data...")

    # --- Load Core Data ---
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)

    # Load test data not needed for this ablation, so we skip it to simplify
    test_df_raw = None

    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_df = combined_keys_train.copy().reset_index(drop=True)
    del combined_keys_train
    gc.collect()

    # --- Feature Engineering and Augmentation ---

    # Basic features from core data
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # Add word count features
    combined_df['street_name_word_count'] = combined_df['street_name'].apply(lambda x: len(str(x).split())).astype('int16')
    combined_df['violation_desc_word_count'] = combined_df['violation_description'].apply(lambda x: len(str(x).split())).astype('int16')

    # Ablation point 1: Average Word Length Features
    if include_avg_word_len_features:
        def calculate_avg_word_len(text):
            words = str(text).split()
            if not words:
                return 0.0
            total_length = sum(len(word) for word in words)
            return total_length / len(words)

        combined_df['street_name_avg_word_len'] = combined_df['street_name'].apply(calculate_avg_word_len).astype('float32')
        combined_df['violation_desc_avg_word_len'] = combined_df['violation_description'].apply(calculate_avg_word_len).astype('float32')

    # Augmentation 1: nyc_street_data.csv
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
        except Exception as e:
            pass # print(f"Error loading or merging {street_data_path}: {e}. Skipping street data augmentation.")
    
    # Augmentation 2: nyc_violation_codes.csv
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
        except Exception as e:
            pass # print(f"Error loading or merging {violation_codes_path}: {e}. Skipping violation codes augmentation.")
    
    # Augmentation 3: nyc_census_data.csv
    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path) and 'borough' in combined_df.columns:
        try:
            census_data = pd.read_csv(census_data_path)
            census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
            relevant_census_cols = ['borough', 'population_density', 'avg_income']
            if all(col in census_data.columns for col in relevant_census_cols):
                census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                census_agg = downcast_dtypes(census_agg)
                combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                del census_data, census_agg
                gc.collect()
        except Exception as e:
            pass # print(f"Error loading or merging {census_data_path}: {e}. Skipping census data augmentation.")
    
    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    # Identify categorical features for CatBoost
    categorical_features = [col for col in combined_df.columns if combined_df[col].dtype in ['object', 'category']]
    categorical_features = [col for col in categorical_features if col in train_processed_df.columns]
    
    # Ablation point 2: Remove raw high-cardinality categorical features
    # If not including raw high cardinality cats, remove 'street_name' and 'violation_description'
    # from the list of features the model will use *as categoricals*,
    # and also from the main feature set 'features' later in train_and_predict.
    if not include_raw_high_cardinality_cats:
        if 'street_name' in categorical_features:
            categorical_features.remove('street_name')
        if 'violation_description' in categorical_features:
            categorical_features.remove('violation_description')

    for col in categorical_features:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].astype(str).astype('category')
    
    return train_processed_df, test_df_raw, categorical_features

def train_and_predict_ablated(train_df, test_df, categorical_features, test_size_split=0.2,
                              exclude_raw_high_cardinality_cats_from_features=False):
    """
    Trains a CatBoost Regressor model and generates predictions.
    Reports RMSE for validation.
    Ablation parameters:
    - test_size_split: The test_size parameter for train_test_split.
    - exclude_raw_high_cardinality_cats_from_features: If True, 'street_name' and 'violation_description' are removed from X.
    """

    features = [col for col in train_df.columns if col not in ['violation_count', 'is_pure_prediction']]
    target = 'violation_count'

    # Ablation point 2 implementation (continued from load_and_preprocess_data_ablated)
    # Exclude 'street_name' and 'violation_description' from the feature set `X` if specified.
    if exclude_raw_high_cardinality_cats_from_features:
        if 'street_name' in features:
            features.remove('street_name')
        if 'violation_description' in features:
            features.remove('violation_description')

    X = train_df[features]
    y = train_df[target]

    # Ablation point 3: Change test_size for train_test_split
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=test_size_split, random_state=42)

    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6, 
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Set to 0 to suppress verbose output for ablation study
        early_stopping_rounds=50, 
    )

    # Convert categorical feature names to their indices for CatBoost
    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        raise

    val_preds = model.predict(X_val)
    val_preds[val_preds < 0] = 0 
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    
    return val_rmse

def run_ablation_study(train_path='./input/violations_per_street_2022.csv'):
    
    results = {}

    # --- Base Case ---
    print("Running Base Case: All features, test_size=0.2")
    base_train_df, _, base_categorical_features = load_and_preprocess_data_ablated(
        train_path, 
        include_avg_word_len_features=True,
        include_raw_high_cardinality_cats=True
    )
    base_rmse = train_and_predict_ablated(
        base_train_df, None, base_categorical_features, 
        test_size_split=0.2,
        exclude_raw_high_cardinality_cats_from_features=False
    )
    results['Base Case'] = base_rmse
    print(f"Base Case Validation RMSE: {base_rmse:.4f}\n")
    del base_train_df; gc.collect()

    # --- Ablation 1: No Average Word Length Features ---
    print("Running Ablation 1: No Average Word Length Features")
    ablation1_train_df, _, ablation1_categorical_features = load_and_preprocess_data_ablated(
        train_path, 
        include_avg_word_len_features=False,
        include_raw_high_cardinality_cats=True
    )
    ablation1_rmse = train_and_predict_ablated(
        ablation1_train_df, None, ablation1_categorical_features, 
        test_size_split=0.2,
        exclude_raw_high_cardinality_cats_from_features=False
    )
    results['No Average Word Length Features'] = ablation1_rmse
    print(f"Ablation 1 (No Average Word Length Features) Validation RMSE: {ablation1_rmse:.4f} (Delta: {ablation1_rmse - base_rmse:.4f})\n")
    del ablation1_train_df; gc.collect()


    # --- Ablation 2: No Raw 'street_name' and 'violation_description' as direct CatBoost features ---
    # Note: These columns are still used to derive other features (length, word count etc.)
    print("Running Ablation 2: Exclude Raw 'street_name'/'violation_description' as direct features")
    ablation2_train_df, _, ablation2_categorical_features = load_and_preprocess_data_ablated(
        train_path, 
        include_avg_word_len_features=True,
        include_raw_high_cardinality_cats=False # This flag modifies the categorical_features list
    )
    ablation2_rmse = train_and_predict_ablated(
        ablation2_train_df, None, ablation2_categorical_features, 
        test_size_split=0.2,
        exclude_raw_high_cardinality_cats_from_features=True # This flag modifies the `features` list
    )
    results['No Raw Street/Violation Description Features'] = ablation2_rmse
    print(f"Ablation 2 (No Raw Street/Violation Description Features) Validation RMSE: {ablation2_rmse:.4f} (Delta: {ablation2_rmse - base_rmse:.4f})\n")
    del ablation2_train_df; gc.collect()

    # --- Ablation 3: Change train_test_split test_size to 0.3 ---
    print("Running Ablation 3: Changed train_test_split test_size to 0.3")
    ablation3_train_df, _, ablation3_categorical_features = load_and_preprocess_data_ablated(
        train_path, 
        include_avg_word_len_features=True,
        include_raw_high_cardinality_cats=True
    )
    ablation3_rmse = train_and_predict_ablated(
        ablation3_train_df, None, ablation3_categorical_features, 
        test_size_split=0.3, # Modified test_size
        exclude_raw_high_cardinality_cats_from_features=False
    )
    results['Changed Test Size (0.3)'] = ablation3_rmse
    print(f"Ablation 3 (Changed Test Size to 0.3) Validation RMSE: {ablation3_rmse:.4f} (Delta: {ablation3_rmse - base_rmse:.4f})\n")
    del ablation3_train_df; gc.collect()

    # --- Conclusion ---
    print("\n--- Ablation Study Summary ---")
    base_rmse = results['Base Case']
    most_impactful_change = "Base Case"
    largest_abs_delta = 0.0

    for name, rmse in results.items():
        if name == 'Base Case':
            continue
        delta = rmse - base_rmse
        print(f"{name}: RMSE = {rmse:.4f}, Delta from Base = {delta:.4f}")
        if abs(delta) > largest_abs_delta:
            largest_abs_delta = abs(delta)
            most_impactful_change = name

    print(f"\nBase Case RMSE: {base_rmse:.4f}")
    print(f"The most impactful change was: '{most_impactful_change}' with an absolute RMSE delta of {largest_abs_delta:.4f}.")

if __name__ == "__main__":
    run_ablation_study()
