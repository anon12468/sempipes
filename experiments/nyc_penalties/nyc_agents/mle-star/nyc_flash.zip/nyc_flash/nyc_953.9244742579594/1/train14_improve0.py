
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import argparse
import os

# Function to calculate RMSE
def rmse(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))

# Main pipeline function
def run_pipeline(train_file_path, test_file_path=None):
    # --- Configuration and File Paths ---
    BASE_DIR = "./input"
    
    # Core files
    violations_2022_path = os.path.join(BASE_DIR, train_file_path)

    # Augmentation tables (assuming they are always in BASE_DIR)
    # Ensure these paths are correct
    parking_codes_path = os.path.join(BASE_DIR, "parking_ticket_codes.csv")
    nyc_streets_path = os.path.join(BASE_DIR, "nyc_streets.csv")
    nyc_census_path = os.path.join(BASE_DIR, "nyc_census_data.csv")
    borough_data_path = os.path.join(BASE_DIR, "borough_data.csv")
    # holidays.csv and weather_data.csv are omitted for now due to lack of direct date linkage in aggregate data

    print(f"Loading training data from: {violations_2022_path}")
    try:
        train_df = pd.read_csv(violations_2022_path)
    except FileNotFoundError:
        print(f"Error: Training file not found at {violations_2022_path}")
        return
    except Exception as e:
        print(f"Error loading training data: {e}")
        return

    # --- Load Augmentation Data ---
    print("Loading augmentation data...")
    try:
        parking_codes_df = pd.read_csv(parking_codes_path)
        nyc_streets_df = pd.read_csv(nyc_streets_path)
        nyc_census_df = pd.read_csv(nyc_census_path)
        borough_data_df = pd.read_csv(borough_data_path)
    except FileNotFoundError as e:
        print(f"Error: Augmentation file not found: {e}")
        return
    except Exception as e:
        print(f"Error loading augmentation data: {e}")
        return

    # --- Feature Engineering and Merging (Training Data) ---
    print("Performing feature engineering and merging on training data...")
    
    # Merge parking codes
    # Rename 'Violation Description' in parking_codes_df to avoid conflicts and keep original description
    train_df = pd.merge(
        train_df,
        parking_codes_df.rename(columns={'Violation Description': 'Violation Description_Code'}),
        left_on="Violation Description",
        right_on="Violation Description_Code",
        how="left"
    )
    train_df = train_df.drop(columns=['Violation Description_Code'], errors='ignore') # Drop the column used for merging

    # Merge NYC streets data
    train_df = pd.merge(
        train_df,
        nyc_streets_df,
        left_on="Street Name",
        right_on="Street Name",
        how="left"
    )

    # Merge borough data (assuming 'Borough' column is now available from nyc_streets_df)
    train_df = pd.merge(
        train_df,
        borough_data_df,
        left_on="Borough",
        right_on="Borough",
        how="left"
    )

    # Merge NYC census data (assuming 'Borough' column is available)
    train_df = pd.merge(
        train_df,
        nyc_census_df,
        left_on="Borough",
        right_on="Borough",
        how="left"
    )
    
    # Define categorical and numerical features
    # These lists need to be carefully curated based on available columns after merges
    # and the nature of the data.
    initial_categorical_features = [
        'Street Name', 'Violation Description', 'Violation Type', 'Law Section',
        'Sub Division', 'Violation Code', 'Days Parking In Effect', 'From Hours In Effect',
        'To Hours In Effect', 'No Standing or Stopping Violation', 'Hydrant Violation',
        'Double Parking Violation', 'Borough', 'Street Type', 'Segment Type', 'Boro' # 'Boro' from borough_data, if distinct
    ]
    
    initial_numerical_features = [
        'Fine Amount', 'Length (miles)', 'Number of Lanes', 'Population',
        'Median Income', 'Number of Households', 'Area (sq mi)' # 'Area (sq mi)' from borough_data
    ]

    # Filter features to only include those actually present in the DataFrame
    categorical_features = [f for f in initial_categorical_features if f in train_df.columns]
    numerical_features = [f for f in initial_numerical_features if f in train_df.columns]

    # Fill NaN values for categorical features with a distinct string 'Unknown_NaN_Category'
    for col in categorical_features:
        if col in train_df.columns:
            train_df[col] = train_df[col].fillna('Unknown_NaN_Category').astype(str)
        
    # Fill NaN values for numerical features with the median of the respective column
    # CatBoost can handle NaNs in numerical features, but explicit filling can sometimes
    # provide more stable results or be necessary if nan_mode is not precisely tuned.
    for col in numerical_features:
        if col in train_df.columns:
            train_df[col] = train_df[col].fillna(train_df[col].median())

    # Define features (X) and target (y)
    X = train_df[categorical_features + numerical_features]
    y = train_df["violation_count"]

    # --- Train/Validation Split ---
    print("Splitting data into training and validation sets...")
    # Using a simple random split for development validation.
    # For time-series like data, a time-based split would be more appropriate if date info was available.
    X_train, X_val, y_train, y_val = train_test_split(
        X, y, test_size=0.2, random_state=42, shuffle=True
    )

    # CatBoost expects categorical features identified by index or name
    cat_feature_indices = [X.columns.get_loc(col) for col in categorical_features]
    
    train_pool = Pool(X_train, y_train, cat_features=cat_feature_indices)
    val_pool = Pool(X_val, y_val, cat_features=cat_feature_indices)

    # --- Model Training ---
    print("Training CatBoostRegressor model...")
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=8,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=100, # Print metrics every 100 iterations
        early_stopping_rounds=50, # Stop if validation metric doesn't improve for 50 rounds
        nan_mode='Forbidden' # Set nan_mode to 'Forbidden' since we explicitly fill NaNs
                              # If NaNs are still present, this will raise an error.
    )

    model.fit(train_pool, eval_set=val_pool)

    # --- Validation Performance ---
    val_preds = model.predict(X_val)
    # Clip predictions to be non-negative
    val_preds[val_preds < 0] = 0
    final_validation_score = rmse(y_val, val_preds)
    print(f"Final Validation Performance: {final_validation_score}")

    # --- Prediction on Test Data (if provided) ---
    if test_file_path:
        test_data_path = os.path.join(BASE_DIR, test_file_path)
        print(f"Loading test data from: {test_data_path}")
        try:
            test_df = pd.read_csv(test_data_path)
        except FileNotFoundError:
            print(f"Error: Test file not found at {test_data_path}")
            return
        except Exception as e:
            print(f"Error loading test data: {e}")
            return

        # Store original keys for submission
        submission_keys_df = test_df[['Street Name', 'Violation Description']].copy()
        
        # Check for 'violation_count' in test_df for evaluation
        has_ground_truth = 'violation_count' in test_df.columns
        if has_ground_truth:
            y_test_true = test_df['violation_count'].copy()
            # Drop the column if it's ground truth, so it's not used as a feature
            test_df = test_df.drop(columns=['violation_count'])

        print("Performing feature engineering and merging on test data...")
        # Apply the same feature engineering as training data
        test_df = pd.merge(
            test_df,
            parking_codes_df.rename(columns={'Violation Description': 'Violation Description_Code'}),
            left_on="Violation Description",
            right_on="Violation Description_Code",
            how="left"
        )
        test_df = test_df.drop(columns=['Violation Description_Code'], errors='ignore')

        test_df = pd.merge(
            test_df,
            nyc_streets_df,
            left_on="Street Name",
            right_on="Street Name",
            how="left"
        )
        test_df = pd.merge(
            test_df,
            borough_data_df,
            left_on="Borough",
            right_on="Borough",
            how="left"
        )
        test_df = pd.merge(
            test_df,
            nyc_census_df,
            left_on="Borough",
            right_on="Borough",
            how="left"
        )
        
        # Prepare test_df to match training features (X)
        # Add missing columns to test_df that were in X (training features) and fill with defaults
        missing_cols_in_test = set(X.columns) - set(test_df.columns)
        for col in missing_cols_in_test:
            if col in categorical_features:
                test_df[col] = 'Unknown_NaN_Category'
            elif col in numerical_features:
                test_df[col] = 0.0 # Use 0.0 as a safe default for numerical features
            else:
                # This should ideally not happen if feature lists are consistent
                print(f"Warning: Missing feature '{col}' in test data not classified as cat/num. Filling with 0.0")
                test_df[col] = 0.0

        # Fill NaN values in existing test columns (post-merge)
        for col in categorical_features:
            if col in test_df.columns: # Check again, as new columns might have been added by missing_cols_in_test logic
                test_df[col] = test_df[col].fillna('Unknown_NaN_Category').astype(str)
        
        for col in numerical_features:
            if col in test_df.columns:
                test_df[col] = test_df[col].fillna(0.0) # Using 0.0 for test set numerical NaNs for consistency

        # Ensure the order of columns in X_test matches X_train
        X_test = test_df[X.columns]

        # Make predictions
        test_preds = model.predict(X_test)
        test_preds[test_preds < 0] = 0 # Clip negative predictions

        # Create submission file
        submission_df = pd.DataFrame({
            'street_name': submission_keys_df['Street Name'],
            'violation_type': submission_keys_df['Violation Description'],
            'predicted_count': test_preds
        })
        submission_df.to_csv("submission.csv", index=False)
        print("Predictions saved to submission.csv")

        if has_ground_truth:
            test_rmse = rmse(y_test_true, test_preds)
            print(f"RMSE on provided test/evaluation data: {test_rmse}")

            # Report unseen key pairs
            train_keys = set(train_df.set_index(['Street Name', 'Violation Description']).index)
            test_keys = set(submission_keys_df.set_index(['Street Name', 'Violation Description']).index)
            
            unseen_keys_count = len(test_keys - train_keys)
            total_test_keys = len(test_keys)
            print(f"Number of unseen (street_name, violation_type) pairs in test/eval set: {unseen_keys_count} out of {total_test_keys}")
            print("Unseen pairs were handled by CatBoost's ability to generalize from individual feature components (Street Name, Violation Description) and other augmented features.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Predict NYC parking violations for 2023."
    )
    parser.add_argument(
        "--train-path",
        type=str,
        default="violations_per_street_2022.csv",
        help="Path to the 2022 violations training data CSV.",
    )
    parser.add_argument(
        "--test-path",
        type=str,
        default=None,
        help="Optional: Path to the 2023 test/evaluation data CSV for predictions.",
    )
    args = parser.parse_args()

    run_pipeline(args.train_path, args.test_path)
