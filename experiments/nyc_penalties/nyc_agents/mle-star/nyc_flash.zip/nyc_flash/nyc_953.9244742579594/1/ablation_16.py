
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            # Check for actual unique values excluding NaN for cardinality calculation
            unique_values_non_nan = df[col].dropna().unique()
            num_unique_values = len(unique_values_non_nan)
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            # and there's more than one unique value (to avoid converting columns with all same values)
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    return df

def load_and_preprocess_data_for_ablation(train_path, add_length_features=True):
    """
    Loads, preprocesses, and merges data from various sources, customized for ablation.
    'test_path' is ignored as per ablation study instructions to not load test data.
    """
    # --- Load Core Data ---
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)

    # Combine unique street_name and violation_description pairs from train
    # for consistent feature engineering.
    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_df = combined_keys_train.reset_index(drop=True)
    del combined_keys_train # Free memory
    gc.collect()

    # --- Feature Engineering and Augmentation ---

    # Basic features from core data, conditionally added for ablation
    if add_length_features:
        combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
        combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # Augmentation 1: nyc_street_data.csv
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
        except Exception as e:
            print(f"Error loading or merging {street_data_path}: {e}. Skipping street data augmentation.")

    # Augmentation 2: nyc_violation_codes.csv
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
        except Exception as e:
            print(f"Error loading or merging {violation_codes_path}: {e}. Skipping violation codes augmentation.")

    # Augmentation 3: nyc_census_data.csv (Hypothetical)
    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        if 'borough' in combined_df.columns:
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
                else:
                    print(f"Warning: Missing one or more expected columns ({relevant_census_cols}) in {census_data_path}. Skipping census data augmentation.")
            except Exception as e:
                print(f"Error loading or merging {census_data_path}: {e}. Skipping census data augmentation.")

    # Merge the engineered features back to the raw training dataframe
    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw, combined_df
    gc.collect()

    # Identify categorical features for CatBoost
    # Note: street_name and violation_description are typically high cardinality but for this task
    # we treat them as categories if they are 'object' or 'category' type.
    categorical_features = [col for col in train_processed_df.columns if train_processed_df[col].dtype in ['object', 'category']]

    # Handle NaN values in categorical features by filling with a placeholder string
    # This is crucial for CatBoost which doesn't handle NaNs in categorical features by default
    for col in categorical_features:
        if train_processed_df[col].isnull().any():
            train_processed_df[col] = train_processed_df[col].fillna('Missing_Category').astype('category')
        else:
            # Ensure it's category type even if no NaNs
            train_processed_df[col] = train_processed_df[col].astype('category')


    # test_processed_df is always None for ablation study
    return train_processed_df, None, categorical_features

def train_and_evaluate_ablated(train_df, categorical_features, catboost_depth=6, catboost_grow_policy=None, catboost_max_leaves=None):
    """
    Trains a CatBoost Regressor model and evaluates it on a validation set.
    """
    # Define features (X) and target (y)
    features = [col for col in train_df.columns if col not in ['violation_count']]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    # Split training data for validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    # Initialize CatBoost Regressor with parameters
    model_params = {
        'iterations': 1000,
        'learning_rate': 0.05,
        'depth': catboost_depth,
        'l2_leaf_reg': 3,
        'loss_function': 'RMSE',
        'eval_metric': 'RMSE',
        'random_seed': 42,
        'verbose': 0, # Suppress verbose output during ablation runs
        'early_stopping_rounds': 50,
    }

    if catboost_grow_policy:
        model_params['grow_policy'] = catboost_grow_policy
    if catboost_max_leaves:
        model_params['max_leaves'] = catboost_max_leaves

    model = CatBoostRegressor(**model_params)

    # Convert categorical feature names to their indices for CatBoost
    # Filter categorical_features to only include those present in X_train
    cat_features_in_X_train = [col for col in categorical_features if col in X_train.columns]
    cat_features_indices = [X_train.columns.get_loc(col) for col in cat_features_in_X_train]

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                  early_stopping_rounds=model_params['early_stopping_rounds'],
                  use_best_model=True
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        raise

    # Validate on internal validation set
    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    return val_rmse

def run_ablation_study(train_path='./input/violations_per_street_2022.csv'):
    """
    Orchestrates the ablation study by running different scenarios.
    """
    print("--- Starting Ablation Study ---")
    results = {}

    # 1. Base Case
    print("\nRunning Base Case...")
    train_df_base, _, cat_features_base = load_and_preprocess_data_for_ablation(train_path)
    rmse_base = train_and_evaluate_ablated(train_df_base, cat_features_base)
    results['Base Case'] = rmse_base
    print(f"Base Case Validation RMSE: {rmse_base:.4f}")

    # 2. Ablation: No Basic Length Features
    print("\nRunning Ablation: No Basic Length Features ('street_name_len', 'violation_desc_len')...")
    train_df_no_len, _, cat_features_no_len = load_and_preprocess_data_for_ablation(train_path, add_length_features=False)
    rmse_no_len = train_and_evaluate_ablated(train_df_no_len, cat_features_no_len)
    results['No Basic Length Features'] = rmse_no_len
    print(f"No Basic Length Features Validation RMSE: {rmse_no_len:.4f}")

    # 3. Ablation: CatBoost grow_policy='Lossguide' (with max_leaves=31)
    print("\nRunning Ablation: CatBoost grow_policy='Lossguide' (from default SymmetricTree)...")
    train_df_lossguide, _, cat_features_lossguide = load_and_preprocess_data_for_ablation(train_path)
    rmse_lossguide = train_and_evaluate_ablated(train_df_lossguide, cat_features_lossguide,
                                                 catboost_grow_policy='Lossguide', catboost_max_leaves=31)
    results["CatBoost grow_policy='Lossguide'"] = rmse_lossguide
    print(f"CatBoost grow_policy='Lossguide' Validation RMSE: {rmse_lossguide:.4f}")

    # 4. Ablation: CatBoost depth=8 (from 6)
    print("\nRunning Ablation: CatBoost depth=8 (from original 6)...")
    train_df_depth8, _, cat_features_depth8 = load_and_preprocess_data_for_ablation(train_path)
    rmse_depth8 = train_and_evaluate_ablated(train_df_depth8, cat_features_depth8, catboost_depth=8)
    results['CatBoost depth=8'] = rmse_depth8
    print(f"CatBoost depth=8 Validation RMSE: {rmse_depth8:.4f}")

    # --- Summarize Results ---
    print("\n--- Ablation Study Summary ---")
    print(f"Base Case RMSE: {results['Base Case']:.4f}")

    most_impactful_change = "Base Case"
    largest_impact_delta = 0.0

    for scenario, rmse in results.items():
        if scenario == 'Base Case':
            continue
        delta = rmse - results['Base Case']
        impact_description = ""
        if delta < 0:
            impact_description = "improved"
            if abs(delta) > abs(largest_impact_delta) or (delta < 0 and largest_impact_delta >= 0): # Check for improvement
                 largest_impact_delta = delta
                 most_impactful_change = scenario
        elif delta > 0:
            impact_description = "degraded"
            if abs(delta) > abs(largest_impact_delta) or (delta > 0 and largest_impact_delta <= 0): # Check for degradation or if no improvement found yet
                 largest_impact_delta = delta
                 most_impactful_change = scenario
        else:
            impact_description = "no change"

        print(f"- {scenario}: RMSE {rmse:.4f} (Delta: {delta:+.4f}, {impact_description})")

    # Determine most contributing part
    print("\n--- Most Contributing Part ---")
    if largest_impact_delta == 0.0:
        print("No single ablation showed a significant positive or negative impact on performance compared to the Base Case.")
    else:
        effect = "improvement" if largest_impact_delta < 0 else "degradation"
        print(f"The most impactful change was '{most_impactful_change}', which resulted in a {effect} of {abs(largest_impact_delta):.4f} RMSE.")
        if largest_impact_delta < 0:
            print(f"This indicates that '{most_impactful_change}' contributes positively to the overall performance.")
        else:
            print(f"This indicates that '{most_impactful_change}' as implemented (or its removal) contributes negatively to the overall performance.")

    # Final Validation Performance line as required
    final_validation_score = results['Base Case']
    print(f"\nFinal Validation Performance: {final_validation_score}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Ablation study for NYC parking violations model.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()
    run_ablation_study(args.train_path)
