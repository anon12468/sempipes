
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys
import re
import shutil
from io import StringIO

# --- Start of the provided train.py script content ---
# This content will be modified and executed for each ablation scenario.
TRAIN_PY_CONTENT = """
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    \"\"\"
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    \"\"\"
    initial_memory = df.memory_usage(deep=True).sum() / (1024**2)
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    final_memory = df.memory_usage(deep=True).sum() / (1024**2)
    # print(f"  Memory reduced from {initial_memory:.2f} MB to {final_memory:.2f} MB for dataframe.")
    return df

def load_and_preprocess_data(train_path, test_path=None):
    \"\"\"
    Loads, preprocesses, and merges data from various sources.
    Handles memory efficiency by selective column loading, aggregation, and garbage collection.
    \"\"\"
    print("Loading and preprocessing data...")

    # --- Load Core Data ---
    # Load training data
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)
    print(f"Initial train_df loaded. Shape: {train_df_raw.shape}, Memory: {train_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Load test data if provided
    test_df_raw = None
    if test_path:
        test_df_raw = pd.read_csv(test_path)
        test_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
        # Create a flag for pure prediction rows where violation_count is NaN
        test_df_raw['is_pure_prediction'] = test_df_raw['violation_count'].isna()
        test_df_raw = downcast_dtypes(test_df_raw)
        print(f"Test_df loaded. Shape: {test_df_raw.shape}, Memory: {test_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Combine unique street_name and violation_description pairs from train and test
    # for consistent feature engineering.
    # Exclude 'violation_count' to prevent target leakage and reduce memory.
    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_keys_test = pd.DataFrame()
    if test_df_raw is not None:
        combined_keys_test = test_df_raw[['street_name', 'violation_description']].drop_duplicates()

    combined_df = pd.concat([combined_keys_train, combined_keys_test], ignore_index=True).drop_duplicates().reset_index(drop=True)
    del combined_keys_train, combined_keys_test # Free memory
    gc.collect()
    print(f"Combined unique (street, violation) pairs for feature engineering. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # --- Feature Engineering and Augmentation ---

    # Basic features from core data
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # Augmentation 1: nyc_street_data.csv
    # Assuming this file exists and contains relevant street-level information
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        print(f"Loading {street_data_path}...")
        # Load only necessary columns
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name']) # Ensure unique info per street
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
            print(f"Merged with street_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading or merging {street_data_path}: {e}. Skipping street data augmentation.")
    else:
        print(f"Warning: {street_data_path} not found. Skipping street data augmentation.")

    # Augmentation 2: nyc_violation_codes.csv
    # Assuming this file exists and contains details about violation codes
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        print(f"Loading {violation_codes_path}...")
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description']) # Ensure unique info per violation
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
            print(f"Merged with violation_codes. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading or merging {violation_codes_path}: {e}. Skipping violation codes augmentation.")
    else:
        print(f"Warning: {violation_codes_path} not found. Skipping violation codes augmentation.")

    # Augmentation 3: nyc_census_data.csv (Hypothetical)
    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        print(f"Loading {census_data_path}...")
        if 'borough' in combined_df.columns: # Only proceed if borough info is available from street_data
            try:
                census_data = pd.read_csv(census_data_path)
                # Standardize column names
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]

                # Assuming 'borough' is the key and 'population_density', 'avg_income' are features
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    # Aggregate census data by borough to reduce size before merging
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
                    print(f"Merged with census_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
                else:
                    print(f"Warning: Missing one or more expected columns ({relevant_census_cols}) in {census_data_path}. Skipping census data augmentation.")
            except Exception as e:
                print(f"Error loading or merging {census_data_path}: {e}. Skipping census data augmentation.")
        else:
            print("Warning: Borough information not available in combined_df to merge census data. Skipping.")
    else:
        print(f"Warning: {census_data_path} not found. Skipping census data augmentation.")


    # Split back into train and test processed dataframes
    # Merge the engineered features back to the raw dataframes (which still hold violation_count and is_pure_prediction)
    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    test_processed_df = None
    if test_df_raw is not None:
        test_processed_df = pd.merge(test_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
        del test_df_raw
        gc.collect()

    print(f"Final train_processed_df shape: {train_processed_df.shape}")
    if test_processed_df is not None:
        print(f"Final test_processed_df shape: {test_processed_df.shape}")

    # Identify categorical features for CatBoost
    categorical_features = [col for col in combined_df.columns if combined_df[col].dtype in ['object', 'category']]
    # Ensure all categorical features from the combined_df are present in the final processed DFs
    categorical_features = [col for col in categorical_features if col in train_processed_df.columns]
    print(f"Categorical features identified for CatBoost: {categorical_features}")

    # Ensure all categorical columns are of 'category' dtype for CatBoost
    for col in categorical_features:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].astype('category')
        if test_processed_df is not None and col in test_processed_df.columns:
            test_processed_df[col] = test_processed_df[col].astype('category')


    return train_processed_df, test_processed_df, categorical_features

def train_and_predict(train_df, test_df, categorical_features):
    \"\"\"
    Trains a CatBoost Regressor model and generates predictions.
    Reports RMSE for validation and test sets (if ground truth available).
    \"\"\"
    print("Training CatBoost model...")

    # Define features (X) and target (y)
    features = [col for col in train_df.columns if col not in ['violation_count']]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    # Split training data for validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    print(f"Training data split: X_train={X_train.shape}, X_val={X_val.shape}")

    # Initialize CatBoost Regressor with OOM-conscious parameters
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6, # Reduced depth to manage memory
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=100, # Print metrics every 100 iterations
        early_stopping_rounds=50, # Stop if validation RMSE doesn't improve for 50 iterations
        # thread_count=-1, # Use all available cores if not explicitly limited by env
        # grow_policy='Lossguide', # Can be more memory efficient for deep trees
        # max_leaves=31 # For Lossguide, controls number of leaves
    )

    # Train the model
    # Convert categorical feature names to their indices for CatBoost
    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]
    print(f"Categorical feature indices for CatBoost: {cat_features_indices}")

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        print("This might indicate an issue with data format or extreme memory pressure even with optimized parameters.")
        # Re-raising for debugging or handling gracefully, depending on requirements.
        raise

    # Validate on internal validation set
    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    print(f"Development Validation RMSE: {val_rmse}")

    # Generate predictions for the test_df if provided
    submission_df = None
    if test_df is not None:
        print("Generating predictions for test data...")
        # Features for prediction are the same as training
        X_test = test_df[features]

        # CatBoost handles unseen categories in test data by default
        test_preds = model.predict(X_test)
        # Ensure predictions are non-negative
        test_preds[test_preds < 0] = 0

        # Create submission dataframe
        submission_df = test_df[['street_name', 'violation_description']].copy()
        submission_df['predicted_count'] = test_preds

        # Report RMSE if ground truth is available in test_df
        if not test_df['is_pure_prediction'].all(): # If some ground truth exists
            ground_truth_test_df = test_df[~test_df['is_pure_prediction']]
            ground_truth_preds = submission_df[~test_df['is_pure_prediction']]['predicted_count']
            test_rmse = np.sqrt(mean_squared_error(ground_truth_test_df['violation_count'], ground_truth_preds))
            print(f"RMSE on provided test/evaluation data (with ground truth): {test_rmse}")

        # Report unseen key pairs
        train_keys = set(train_df.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
        test_keys = set(test_df.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
        unseen_keys_count = len(test_keys - train_keys)
        print(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {unseen_keys_count}")
        print("Unseen keys are handled by CatBoost's internal mechanism for new categorical levels (assigned to an 'unknown' category).")

    return submission_df, val_rmse

def main():
    \"\"\"
    Main function to parse arguments, orchestrate data loading, training, and prediction.
    \"\"\"
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional path to the 2023 test/evaluation data CSV. '
                             'If provided, predictions will be generated and RMSE reported if ground truth exists.')
    args = parser.parse_args()

    train_df, test_df, categorical_features = load_and_preprocess_data(args.train_path, args.test_path)
    submission_df, final_validation_score = train_and_predict(train_df, test_df, categorical_features)

    if submission_df is not None:
        submission_df.to_csv('submission.csv', index=False)
        print("Submission file 'submission.csv' generated successfully.")

    # Always print the final validation score
    print(f"Final Validation Performance: {final_validation_score}")

if __name__ == "__main__":
    main()
"""
# --- End of the provided train.py script content ---

def create_dummy_data(input_dir="./input"):
    """
    Creates dummy CSV files needed by train.py if they don't exist.
    """
    os.makedirs(input_dir, exist_ok=True)

    # Dummy train data
    if not os.path.exists(os.path.join(input_dir, 'violations_per_street_2022.csv')):
        train_data = {
            'Street Name': ['MAIN ST', 'OAK AVE', 'MAIN ST', 'ELM RD', 'MAPLE LN', 'MAIN ST', 'OAK AVE', 'ELM RD', 'MAIN ST', 'MAPLE LN'],
            'Violation Description': ['PARKING VIOLATION A', 'STOPPING VIOLATION', 'PARKING VIOLATION B', 'NO PARKING', 'FIRE HYDRANT', 'PARKING VIOLATION A', 'STOPPING VIOLATION', 'NO PARKING', 'PARKING VIOLATION C', 'FIRE HYDRANT'],
            'Violation Count': [100, 50, 120, 30, 80, 110, 55, 35, 90, 85]
        }
        pd.DataFrame(train_data).to_csv(os.path.join(input_dir, 'violations_per_street_2022.csv'), index=False)
        print("Created dummy violations_per_street_2022.csv")

    # Dummy street data
    if not os.path.exists(os.path.join(input_dir, 'nyc_street_data.csv')):
        street_data = {
            'Street Name': ['MAIN ST', 'OAK AVE', 'ELM RD', 'MAPLE LN', 'HIGH ST'],
            'Borough': ['MANHATTAN', 'BROOKLYN', 'QUEENS', 'BRONX', 'MANHATTAN'],
            'Street Length': [1000, 500, 750, 300, 600],
            'Number of Lanes': [4, 2, 3, 2, 4]
        }
        pd.DataFrame(street_data).to_csv(os.path.join(input_dir, 'nyc_street_data.csv'), index=False)
        print("Created dummy nyc_street_data.csv")

    # Dummy violation codes
    if not os.path.exists(os.path.join(input_dir, 'nyc_violation_codes.csv')):
        violation_codes_data = {
            'Violation Description': ['PARKING VIOLATION A', 'STOPPING VIOLATION', 'PARKING VIOLATION B', 'NO PARKING', 'FIRE HYDRANT', 'PARKING VIOLATION C'],
            'Fine Amount': [65, 115, 60, 55, 180, 70],
            'Points': [0, 2, 0, 0, 3, 0]
        }
        pd.DataFrame(violation_codes_data).to_csv(os.path.join(input_dir, 'nyc_violation_codes.csv'), index=False)
        print("Created dummy nyc_violation_codes.csv")

    # Dummy census data
    if not os.path.exists(os.path.join(input_dir, 'nyc_census_data.csv')):
        census_data = {
            'Borough': ['MANHATTAN', 'BROOKLYN', 'QUEENS', 'BRONX', 'STATEN ISLAND'],
            'Population_Density': [70000, 35000, 25000, 20000, 10000],
            'Avg_Income': [120000, 80000, 70000, 60000, 90000]
        }
        pd.DataFrame(census_data).to_csv(os.path.join(input_dir, 'nyc_census_data.csv'), index=False)
        print("Created dummy nyc_census_data.csv")

def run_experiment(original_script_content, scenario_name, modifications, train_file_path):
    """
    Executes a modified version of the train.py script and extracts the final validation RMSE.
    The script's main entry point is replaced to directly call the necessary functions for ablation.
    """
    print(f"\n--- Running Ablation: {scenario_name} ---")

    modified_script_content = original_script_content

    # Apply specific string modifications for the ablation scenario
    for original, replacement in modifications.items():
        modified_script_content = modified_script_content.replace(original, replacement)
    
    # Override the original main execution block (argparse and main() call)
    # to make it callable directly by the ablation script.
    # This ensures consistency and avoids issues with sys.argv or parsing.
    execution_block_replacement = f"""
# --- Ablation Study Entry Point ---
# These variables simulate the arguments passed to the original main function.
_train_path_for_ablation = "{train_file_path}"
_test_path_for_ablation = None # Ablation study focuses on validation RMSE

# Direct calls to the script's functions
_train_df_ablation, _test_df_ablation, _categorical_features_ablation = load_and_preprocess_data(_train_path_for_ablation, _test_path_for_ablation)
_submission_df_ablation, _final_validation_score_ablation = train_and_predict(_train_df_ablation, _test_df_ablation, _categorical_features_ablation)

# This print statement is crucial for parsing the RMSE by the ablation study runner
print(f"Final Validation Performance: {{_final_validation_score_ablation}}")
"""
    # Find the line 'if __name__ == "__main__":' and replace everything from that point onwards
    # This effectively comments out the original argparse and main() call and inserts our entry point.
    modified_script_content = re.sub(r"if __name__ == \"__main__\":[\s\S]*", execution_block_replacement, modified_script_content)

    # Capture stdout to parse the RMSE
    old_stdout = sys.stdout
    redirected_output = sys.stdout = StringIO()

    # Execute the modified script content.
    # globals() is used for the global namespace so imports like pandas, numpy, etc., are available.
    try:
        exec(modified_script_content, globals())
    except Exception as e:
        print(f"Error executing script for scenario {scenario_name}: {e}")
        sys.stdout = old_stdout # Restore stdout before re-raising
        raise
    finally:
        sys.stdout = old_stdout # Always restore stdout

    output = redirected_output.getvalue()
    # print(output) # Uncomment to see the full output of each script run

    # Parse the final validation RMSE from the captured output
    rmse_match = re.search(r"Final Validation Performance: (\d+\.\d+)", output)
    if rmse_match:
        rmse = float(rmse_match.group(1))
        return rmse
    else:
        print(f"WARNING: Could not find RMSE in output for {scenario_name}")
        return None

if __name__ == "__main__":
    # Create dummy data files for a consistent starting point
    create_dummy_data()
    train_file = './input/violations_per_street_2022.csv'
    
    results = {}

    # --- Base Case ---
    # Runs the original script with all features and default parameters.
    # This acts as a baseline for comparison.
    results['Base Case'] = run_experiment(TRAIN_PY_CONTENT, 'Base Case', {}, train_file)

    # --- Ablation 1: Disable all external data augmentations ---
    # This test evaluates the combined contribution of 'nyc_street_data.csv',
    # 'nyc_violation_codes.csv', and 'nyc_census_data.csv'.
    # We replace the 'if os.path.exists()' checks with 'if False' to prevent loading them.
    modifications_no_external_data = {
        "if os.path.exists(street_data_path):": "if False: # Ablated: External Street Data",
        "if os.path.exists(violation_codes_path):": "if False: # Ablated: External Violation Codes",
        "if os.path.exists(census_data_path):": "if False: # Ablated: External Census Data"
    }
    results['No External Data Augmentations'] = run_experiment(TRAIN_PY_CONTENT, 'No External Data Augmentations', modifications_no_external_data, train_file)

    # --- Ablation 2: Disable Basic Length Features ---
    # This test evaluates the contribution of 'street_name_len' and 'violation_desc_len'.
    # These lines are commented out.
    modifications_no_length_features = {
        "combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')": "# Ablated: combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')",
        "combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')": "# Ablated: combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')"
    }
    results['No Basic Length Features'] = run_experiment(TRAIN_PY_CONTENT, 'No Basic Length Features', modifications_no_length_features, train_file)

    # --- Ablation 3: Modify CatBoost l2_leaf_reg parameter ---
    # This test changes the L2 regularization from 3 (default in script) to 1.
    # A lower L2 regularization might lead to a more complex model (less constrained).
    modifications_catboost_l2_reg = {
        "l2_leaf_reg=3,": "l2_leaf_reg=1, # Ablated: Changed from 3"
    }
    results['CatBoost l2_leaf_reg=1'] = run_experiment(TRAIN_PY_CONTENT, 'CatBoost l2_leaf_reg=1', modifications_catboost_l2_reg, train_file)

    print("\n--- Ablation Study Results ---")
    base_rmse = results.get('Base Case')
    if base_rmse is None:
        print("Base Case RMSE not found. Cannot compute deltas for comparison.")
    else:
        # Sort results for better readability, putting N/A at the end
        sorted_results = sorted(results.items(), key=lambda item: item[1] if item[1] is not None else float('inf'))
        
        print(f"Base Case RMSE: {base_rmse:.4f}\n")
        most_impactful_change = None
        largest_rmse_change_abs = 0.0 # Absolute change

        for scenario, rmse in sorted_results:
            if rmse is not None:
                delta = rmse - base_rmse
                print(f"{scenario}: RMSE = {rmse:.4f} (Delta from Base: {delta:+.4f})")
                if abs(delta) > largest_rmse_change_abs:
                    largest_rmse_change_abs = abs(delta)
                    most_impactful_change = (scenario, delta)
            else:
                print(f"{scenario}: RMSE = N/A (Could not run or parse)")

        print("\n--- Conclusion ---")
        if most_impactful_change:
            scenario, delta_val = most_impactful_change
            if delta_val > 0:
                print(f"The most contributing part (removing/modifying it *worsened* performance the most) is: '{scenario}'.")
                print(f"Removing/modifying it increased RMSE by {delta_val:.4f}, indicating it was a beneficial component.")
            elif delta_val < 0:
                print(f"The most detrimental part (removing/modifying it *improved* performance the most) is: '{scenario}'.")
                print(f"Removing/modifying it decreased RMSE by {abs(delta_val):.4f}, indicating it was either negative or suboptimal.")
            else:
                print(f"The change in '{scenario}' had no measurable impact on performance.")
        else:
            print("Could not determine the most impactful part due to missing RMSE data or no changes observed.")

    # Clean up dummy data files and directory
    if os.path.exists("./input"):
        shutil.rmtree("./input")
        print("\nCleaned up dummy 'input' directory.")

