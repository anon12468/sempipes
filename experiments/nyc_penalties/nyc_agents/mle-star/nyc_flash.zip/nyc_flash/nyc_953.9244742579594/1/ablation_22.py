
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys
import re

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    initial_memory = df.memory_usage(deep=True).sum() / (1024**2)
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    final_memory = df.memory_usage(deep=True).sum() / (1024**2)
    return df

# Modified load_and_preprocess_data to accept ablation flags
def load_and_preprocess_data(train_path, test_path=None, use_external_data=True, use_semantic_features=True):
    """
    Loads, preprocesses, and merges data from various sources.
    Handles memory efficiency by selective column loading, aggregation, and garbage collection.
    Ensures NaN values in categorical features are handled for CatBoost.
    Ablation flags:
    - use_external_data: If False, skips loading nyc_street_data, nyc_violation_codes, nyc_census_data.
    - use_semantic_features: If False, skips creating street_suffix_type and has_..._keyword features.
    """
    # --- Load Core Data ---
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)

    # Test data path will be None for this ablation study
    test_df_raw = None

    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_df = combined_keys_train.reset_index(drop=True)
    del combined_keys_train
    gc.collect()

    # Ensure 'street_name' and 'violation_description' are string types and fill any potential NaNs
    combined_df['street_name'] = combined_df['street_name'].astype(str).fillna('Unknown Street')
    combined_df['violation_description'] = combined_df['violation_description'].astype(str).fillna('Unknown Violation')

    # --- Feature Engineering and Augmentation ---

    # Basic features from core data (always included unless specifically ablated, not in this study)
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # Semantic Description/Suffix Features (Ablation Point 2)
    if use_semantic_features:
        # 1. street_suffix_type from street_name
        combined_df['street_suffix_type'] = 'Other'
        street_name_lower = combined_df['street_name'].str.lower()

        combined_df.loc[street_name_lower.str.contains(r'\b(street|st|strt)\b(?:\.|\s*(?:[nsew]|north|south|east|west)?\s*)$', regex=True, na=False), 'street_suffix_type'] = 'St'
        combined_df.loc[street_name_lower.str.contains(r'\b(avenue|ave|avn)\b(?:\.|\s*(?:[nsew]|north|south|east|west)?\s*)$', regex=True, na=False), 'street_suffix_type'] = 'Ave'
        combined_df.loc[street_name_lower.str.contains(r'\b(boulevard|blvd)\b(?:\.|\s*(?:[nsew]|north|south|east|west)?\s*)$', regex=True, na=False), 'street_suffix_type'] = 'Blvd'
        combined_df.loc[street_name_lower.str.contains(r'\b(road|rd|rte)\b(?:\.|\s*(?:[nsew]|north|south|east|west)?\s*)$', regex=True, na=False), 'street_suffix_type'] = 'Rd'
        combined_df['street_suffix_type'] = combined_df['street_suffix_type'].astype('category')

        # 2. Boolean indicator features from violation_description
        violation_desc_lower = combined_df['violation_description'].str.lower()

        combined_df['has_parking_keyword'] = violation_desc_lower.str.contains(r'\b(parking|parked|no parking|park)\b', na=False, regex=True).astype('bool')
        combined_df['has_standing_keyword'] = violation_desc_lower.str.contains(r'\b(standing|no standing|stand)\b', na=False, regex=True).astype('bool')
        combined_df['has_hydrant_keyword'] = violation_desc_lower.str.contains(r'\b(hydrant|fire hydrant)\b', na=False, regex=True).astype('bool')
        combined_df['has_meter_keyword'] = violation_desc_lower.str.contains(r'\b(meter|expired meter|metered)\b', na=False, regex=True).astype('bool')
        combined_df['has_zone_keyword'] = violation_desc_lower.str.contains(r'\b(zone|permit zone|restricted zone|no zone)\b', na=False, regex=True).astype('bool')
        combined_df['has_sign_keyword'] = violation_desc_lower.str.contains(r'\b(sign|no sign|posted sign|posted regulation)\b', na=False, regex=True).astype('bool')
        combined_df['has_commercial_keyword'] = violation_desc_lower.str.contains(r'\b(commercial|loading zone|comm)\b', na=False, regex=True).astype('bool')
        combined_df['has_bus_keyword'] = violation_desc_lower.str.contains(r'\b(bus stop|bus lane)\b', na=False, regex=True).astype('bool')
    else:
        pass # Semantic features are skipped

    # Augmentation 1: nyc_street_data.csv (Ablation Point 1)
    street_data_path = './input/nyc_street_data.csv'
    if use_external_data and os.path.exists(street_data_path):
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
        except Exception as e:
            pass # Error loading street_data

    # Augmentation 2: nyc_violation_codes.csv (Ablation Point 1)
    violation_codes_path = './input/nyc_violation_codes.csv'
    if use_external_data and os.path.exists(violation_codes_path):
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
        except Exception as e:
            pass # Error loading violation_codes

    # Augmentation 3: nyc_census_data.csv (Hypothetical) (Ablation Point 1)
    census_data_path = './input/nyc_census_data.csv'
    if use_external_data and os.path.exists(census_data_path):
        if 'borough' in combined_df.columns:
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
                else:
                    pass # Missing one or more expected columns
            except Exception as e:
                pass # Error loading census_data
        else:
            pass # Borough information not available


    # --- Post-augmentation NaN handling and type conversion for CatBoost ---
    categorical_features_for_catboost = []
    for col in combined_df.columns:
        if combined_df[col].dtype == 'object' or combined_df[col].dtype.name == 'category':
            combined_df[col] = combined_df[col].astype(str).fillna('Unknown_Category')
            combined_df[col] = combined_df[col].astype('category')
            categorical_features_for_catboost.append(col)
        elif combined_df[col].dtype == 'bool':
            categorical_features_for_catboost.append(col)
        elif combined_df[col].isnull().any():
            combined_df[col] = combined_df[col].fillna(0)
            if combined_df[col].dtype == 'float64':
                combined_df[col] = combined_df[col].astype(np.float32)
            elif combined_df[col].dtype == 'int64':
                combined_df[col] = combined_df[col].astype(pd.Int32Dtype())

    categorical_features_for_catboost = list(set(categorical_features_for_catboost))

    # Split back into train processed dataframes
    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    final_categorical_features = [col for col in categorical_features_for_catboost if col in train_processed_df.columns]
    
    return train_processed_df, test_df_raw, final_categorical_features # test_df_raw will be None

# Modified train_and_predict to accept CatBoost parameters for ablation
def train_and_predict(train_df, test_df, categorical_features, catboost_depth=6, catboost_iterations=1000):
    """
    Trains a CatBoost Regressor model and generates predictions.
    Reports RMSE for validation.
    Ablation flags:
    - catboost_depth: CatBoost 'depth' parameter.
    - catboost_iterations: CatBoost 'iterations' parameter.
    """
    features = [col for col in train_df.columns if col not in ['violation_count', 'is_pure_prediction']]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    model = CatBoostRegressor(
        iterations=catboost_iterations,
        learning_rate=0.05,
        depth=catboost_depth,
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Set to 0 for cleaner ablation output
        early_stopping_rounds=50,
    )

    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        raise

    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))

    # The ablation study does not load test data, so submission_df will always be None
    submission_df = None
    return submission_df, val_rmse

# Helper to create dummy files for external data
def create_dummy_input_files():
    os.makedirs('./input', exist_ok=True)

    # nyc_street_data.csv
    with open('./input/nyc_street_data.csv', 'w') as f:
        f.write("Street Name,Borough,Street Length,Number of Lanes\n")
        f.write("MAIN ST,Manhattan,1000,4\n")
        f.write("OAK AVE,Bronx,500,2\n")
        f.write("ELM BLVD,Queens,750,3\n")
        f.write("HIGH STREET,Brooklyn,600,2\n")
        f.write("BROADWAY,Manhattan,1500,6\n")

    # nyc_violation_codes.csv
    with open('./input/nyc_violation_codes.csv', 'w') as f:
        f.write("Violation Description,Fine Amount,Points\n")
        f.write("NO PARKING,50,0\n")
        f.write("FIRE HYDRANT,100,3\n")
        f.write("METER EXPIRED,35,0\n")
        f.write("NO STANDING,40,0\n")
        f.write("INVALID LICENSE,75,1\n")
        f.write("BUS LANE,60,0\n")


    # nyc_census_data.csv
    with open('./input/nyc_census_data.csv', 'w') as f:
        f.write("Borough,Population_Density,Avg_Income\n")
        f.write("Manhattan,27000,120000\n")
        f.write("Bronx,14000,60000\n")
        f.write("Queens,9000,80000\n")
        f.write("Brooklyn,15000,90000\n")
        f.write("Staten Island,4000,75000\n")

def cleanup_dummy_input_files():
    if os.path.exists('./input/nyc_street_data.csv'):
        os.remove('./input/nyc_street_data.csv')
    if os.path.exists('./input/nyc_violation_codes.csv'):
        os.remove('./input/nyc_violation_codes.csv')
    if os.path.exists('./input/nyc_census_data.csv'):
        os.remove('./input/nyc_census_data.csv')
    # os.rmdir('./input') # Only remove if empty, safer not to if other files might be there

def run_ablation_study():
    train_path = './input/violations_per_street_2022.csv'
    
    # Create a dummy train file if it doesn't exist for testing purposes
    if not os.path.exists(train_path):
        os.makedirs('./input', exist_ok=True)
        with open(train_path, 'w') as f:
            f.write("street_name,violation_description,violation_count\n")
            f.write("MAIN ST,NO PARKING,10\n")
            f.write("MAIN ST,FIRE HYDRANT,5\n")
            f.write("OAK AVE,NO PARKING,8\n")
            f.write("OAK AVE,METER EXPIRED,12\n")
            f.write("ELM BLVD,NO STANDING,7\n")
            f.write("MAIN ST,NO STANDING,15\n")
            f.write("MAIN ST,METER EXPIRED,9\n")
            f.write("OAK AVE,FIRE HYDRANT,3\n")
            f.write("ELM BLVD,NO PARKING,11\n")
            f.write("HIGH STREET,INVALID LICENSE,6\n") # New street, violation
            f.write("BROADWAY,BUS LANE,20\n") # Another new one

    create_dummy_input_files() # Ensure external files are present for base case

    ablation_results = {}

    # Base Case: All external data, all semantic features, default CatBoost params
    train_df_base, _, categorical_features_base = load_and_preprocess_data(train_path, test_path=None, 
                                                                           use_external_data=True, 
                                                                           use_semantic_features=True)
    _, base_rmse = train_and_predict(train_df_base, test_df=None, 
                                    categorical_features=categorical_features_base,
                                    catboost_depth=6, catboost_iterations=1000)
    ablation_results['Base Case'] = base_rmse
    print(f"Base Case RMSE: {base_rmse:.4f}")

    # Ablation 1: No External Data Augmentations
    train_df_ablation1, _, categorical_features_ablation1 = load_and_preprocess_data(train_path, test_path=None, 
                                                                                 use_external_data=False, 
                                                                                 use_semantic_features=True)
    _, rmse_ablation1 = train_and_predict(train_df_ablation1, test_df=None, 
                                         categorical_features=categorical_features_ablation1,
                                         catboost_depth=6, catboost_iterations=1000)
    ablation_results['No External Data Augmentations'] = rmse_ablation1
    print(f"Ablation 1 (No External Data Augmentations) RMSE: {rmse_ablation1:.4f} (Delta: {rmse_ablation1 - base_rmse:.4f})")

    # Ablation 2: No Semantic Description/Suffix Features
    train_df_ablation2, _, categorical_features_ablation2 = load_and_preprocess_data(train_path, test_path=None, 
                                                                                 use_external_data=True, 
                                                                                 use_semantic_features=False)
    _, rmse_ablation2 = train_and_predict(train_df_ablation2, test_df=None, 
                                         categorical_features=categorical_features_ablation2,
                                         catboost_depth=6, catboost_iterations=1000)
    ablation_results['No Semantic Description/Suffix Features'] = rmse_ablation2
    print(f"Ablation 2 (No Semantic Description/Suffix Features) RMSE: {rmse_ablation2:.4f} (Delta: {rmse_ablation2 - base_rmse:.4f})")

    # Ablation 3: Reduced CatBoost Complexity (depth=3, iterations=500)
    train_df_ablation3, _, categorical_features_ablation3 = load_and_preprocess_data(train_path, test_path=None, 
                                                                                 use_external_data=True, 
                                                                                 use_semantic_features=True)
    _, rmse_ablation3 = train_and_predict(train_df_ablation3, test_df=None, 
                                         categorical_features=categorical_features_ablation3,
                                         catboost_depth=3, catboost_iterations=500)
    ablation_results['Reduced CatBoost Complexity'] = rmse_ablation3
    print(f"Ablation 3 (Reduced CatBoost Complexity) RMSE: {rmse_ablation3:.4f} (Delta: {rmse_ablation3 - base_rmse:.4f})")

    # Determine most contributing part
    most_impactful_change = ""
    largest_abs_delta = 0.0

    for ablation_name, rmse in ablation_results.items():
        if ablation_name == 'Base Case':
            continue
        delta = abs(rmse - base_rmse)
        if delta > largest_abs_delta:
            largest_abs_delta = delta
            most_impactful_change = ablation_name

    if most_impactful_change:
        print(f"\nThe most contributing part to the overall performance (largest absolute RMSE delta) was: {most_impactful_change}")
    else:
        print("\nCould not determine the most contributing part.")
    
    cleanup_dummy_input_files()
    if os.path.exists(train_path):
         os.remove(train_path)
         if os.path.exists('./input') and not os.listdir('./input'):
            os.rmdir('./input')


if __name__ == "__main__":
    run_ablation_study()
