
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys
import copy

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    return df

def load_and_preprocess_data_ablation(train_path, test_path_unused, no_quantization, no_nan_cat_filling):
    """
    Loads, preprocesses, and merges data for ablation study, allowing control over
    quantization and categorical NaN handling.
    """
    # --- Load Core Data ---
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)

    # Combine unique street_name and violation_description pairs from train only
    combined_df = train_df_raw[['street_name', 'violation_description']].drop_duplicates().reset_index(drop=True)
    gc.collect()

    # --- Feature Engineering and Augmentation ---
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # Augmentation 1: nyc_street_data.csv
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name'])

            if not no_quantization:
                n_bins = 5
                for col in ['street_length', 'num_lanes']:
                    if col in street_data.columns and street_data[col].dtype.kind in 'fi':
                        if street_data[col].dropna().nunique() > 1:
                            try:
                                street_data[col] = pd.cut(
                                    street_data[col],
                                    bins=n_bins,
                                    labels=False,
                                    include_lowest=True,
                                    duplicates='drop'
                                ).astype('Int8') # Becomes categorical after binning
                            except Exception as e:
                                pass # Keep as original numerical if binning fails
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
        except Exception as e:
            pass 

    # Augmentation 2: nyc_violation_codes.csv
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
        except Exception as e:
            pass 

    # Augmentation 3: nyc_census_data.csv
    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        if 'borough' in combined_df.columns:
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
            except Exception as e:
                pass 

    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    test_processed_df = None # Always None for ablation

    # Define explicit list of columns to be treated as categorical by CatBoost
    explicit_cat_cols = ['street_name', 'violation_description', 'borough']
    # Add 'street_length' and 'num_lanes' to categorical list ONLY if quantization was applied
    if not no_quantization:
        # Check if they became Int8 (binned categorical) after quantization
        explicit_cat_cols.extend([col for col in ['street_length', 'num_lanes'] if col in train_processed_df.columns and train_processed_df[col].dtype.name == 'Int8'])

    categorical_features = [col for col in explicit_cat_cols if col in train_processed_df.columns]

    # Handle NaN values in identified categorical features and convert to 'category' dtype
    for col in categorical_features:
        if col in train_processed_df.columns:
            if not no_nan_cat_filling:
                # Original behavior: convert NaN to 'NaN_category' string
                train_processed_df[col] = train_processed_df[col].astype(str).replace('nan', 'NaN_category').astype('category')
            else:
                # FIX: Even when not explicitly filling with 'NaN_category', CatBoost requires NaNs in categorical
                # features to be converted to a string. Convert NaNs to the string 'nan'.
                train_processed_df[col] = train_processed_df[col].astype(str).astype('category')
        
    return train_processed_df, test_processed_df, categorical_features

def train_and_predict_ablation(train_df, test_df_unused, categorical_features, catboost_lossguide):
    """
    Trains a CatBoost Regressor model for ablation study, allowing control over grow_policy.
    """
    features = [col for col in train_df.columns if col not in ['violation_count']]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    catboost_params = {
        'iterations': 1000,
        'learning_rate': 0.05,
        'depth': 6,
        'l2_leaf_reg': 3,
        'loss_function': 'RMSE',
        'eval_metric': 'RMSE',
        'random_seed': 42,
        'verbose': 0, # Suppress verbose output for clean ablation results
        'early_stopping_rounds': 50,
    }

    if catboost_lossguide:
        catboost_params['grow_policy'] = 'Lossguide'
        catboost_params['max_leaves'] = 31

    model = CatBoostRegressor(**catboost_params)

    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        raise

    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    return None, val_rmse # return None for submission_df as we don't predict on test

def run_ablation_experiment(
    train_path,
    experiment_name,
    no_quantization=False,
    no_nan_cat_filling=False,
    catboost_lossguide=False
):
    print(f"\n--- Running: {experiment_name} ---")

    train_df, _, categorical_features = load_and_preprocess_data_ablation(
        train_path,
        None, # test_path_unused
        no_quantization=no_quantization,
        no_nan_cat_filling=no_nan_cat_filling
    )

    _, val_rmse = train_and_predict_ablation(
        train_df,
        None, # test_df_unused
        categorical_features,
        catboost_lossguide=catboost_lossguide
    )
    print(f"Result for {experiment_name}: Validation RMSE = {val_rmse:.4f}")
    return val_rmse

if __name__ == "__main__":
    train_file_path = './input/violations_per_street_2022.csv'

    results = {}

    # Base Case
    results['Base Case'] = run_ablation_experiment(
        train_file_path,
        "Base Case (All features/params enabled)"
    )

    # Ablation 1: No Quantization for street_length and num_lanes
    results['No Quantization'] = run_ablation_experiment(
        train_file_path,
        "Ablation 1 (No Quantization for street_length/num_lanes)",
        no_quantization=True
    )

    # Ablation 2: No 'NaN_category' filling for categorical features
    results['No NaN_category Filling'] = run_ablation_experiment(
        train_file_path,
        "Ablation 2 (No 'NaN_category' filling for categorical features)",
        no_nan_cat_filling=True
    )

    # Ablation 3: CatBoost grow_policy='Lossguide'
    results['CatBoost Lossguide'] = run_ablation_experiment(
        train_file_path,
        "Ablation 3 (CatBoost grow_policy='Lossguide')",
        catboost_lossguide=True
    )

    print("\n--- Ablation Study Results Summary ---")
    base_rmse = results['Base Case']
    print(f"Base Case RMSE: {base_rmse:.4f}\n")

    best_improvement = 0
    most_impactful_part = "Base Case (no ablation improved performance or had major impact)"
    
    for name, rmse in results.items():
        if name == 'Base Case':
            continue
        delta = base_rmse - rmse # Positive delta means improvement, negative means degradation
        print(f"{name}: RMSE = {rmse:.4f}, Delta from Base = {delta:.4f} (positive is improvement)")
        
        if delta > best_improvement:
            best_improvement = delta
            most_impactful_part = name

    if best_improvement > 0:
        print(f"\nThe most contributing part (leading to the greatest improvement) is: {most_impactful_part} with an RMSE improvement of {best_improvement:.4f}.")
    else:
        # If no improvement, find the part with the largest absolute change (either improvement or degradation)
        largest_absolute_change = 0
        current_most_impactful = "No significant impact from any ablated component observed."
        for name, rmse in results.items():
            if name == 'Base Case':
                continue
            delta = base_rmse - rmse
            if abs(delta) > largest_absolute_change:
                largest_absolute_change = abs(delta)
                current_most_impactful = name
        
        if largest_absolute_change > 0:
            print(f"\nThe part with the largest impact on performance (absolute delta from Base Case) is: {current_most_impactful} with an absolute RMSE change of {largest_absolute_change:.4f}.")
        else:
            print("\nNo significant impact from any ablated component observed.")

    print(f"\nFinal Validation Performance: {base_rmse:.4f}")

