

import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    # initial_memory = df.memory_usage(deep=True).sum() / (1024**2) # Commented for cleaner output
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    # final_memory = df.memory_usage(deep=True).sum() / (1024**2) # Commented for cleaner output
    # print(f"  Memory reduced from {initial_memory:.2f} MB to {final_memory:.2f} MB for dataframe.")
    return df

def load_and_preprocess_data(train_path, test_path=None, include_advanced_features=True, include_length_features=True):
    """
    Loads, preprocesses, and merges data from various sources.
    Handles memory efficiency by selective column loading, aggregation, and garbage collection.
    """
    print("Loading and preprocessing data...")

    # --- Load Core Data ---
    # Load training data
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)
    # print(f"Initial train_df loaded. Shape: {train_df_raw.shape}, Memory: {train_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Load test data if provided (but for ablation we'll pass test_path=None)
    test_df_raw = None
    if test_path:
        test_df_raw = pd.read_csv(test_path)
        test_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
        # Create a flag for pure prediction rows where violation_count is NaN
        test_df_raw['is_pure_prediction'] = test_df_raw['violation_count'].isna()
        test_df_raw = downcast_dtypes(test_df_raw)
        # print(f"Test_df loaded. Shape: {test_df_raw.shape}, Memory: {test_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Combine unique street_name and violation_description pairs from train and test
    # for consistent feature engineering.
    # Exclude 'violation_count' to prevent target leakage and reduce memory.
    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_keys_test = pd.DataFrame()
    if test_df_raw is not None:
        combined_keys_test = test_df_raw[['street_name', 'violation_description']].drop_duplicates()

    combined_df = pd.concat([combined_keys_train, combined_keys_test], ignore_index=True).drop_duplicates().reset_index(drop=True)
    del combined_keys_train, combined_keys_test # Free memory
    gc.collect()
    # print(f"Combined unique (street, violation) pairs for feature engineering. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # --- Feature Engineering and Augmentation ---

    # Basic features from core data
    if include_length_features:
        combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
        combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # Advanced Interaction and Aggregation Features
    if include_advanced_features:
        # print("Generating advanced interaction and aggregation features...")
        # 1. Frequency of the combined (street_name, violation_description) pair
        combined_freq_map = combined_df.groupby(['street_name', 'violation_description']).size().reset_index(name='street_violation_pair_freq')
        combined_df = pd.merge(combined_df, combined_freq_map, on=['street_name', 'violation_description'], how='left')
        combined_df['street_violation_pair_freq'] = combined_df['street_violation_pair_freq'].astype('int32')

        # 2. Individual frequencies of street_name and violation_description (needed for aggregation)
        street_freq_map = combined_df['street_name'].value_counts().reset_index()
        street_freq_map.columns = ['street_name', 'street_name_freq']
        combined_df = pd.merge(combined_df, street_freq_map, on='street_name', how='left')
        combined_df['street_name_freq'] = combined_df['street_name_freq'].astype('int32')

        violation_freq_map = combined_df['violation_description'].value_counts().reset_index()
        violation_freq_map.columns = ['violation_description', 'violation_description_freq']
        combined_df = pd.merge(combined_df, violation_freq_map, on='violation_description', how='left')
        combined_df['violation_description_freq'] = combined_df['violation_description_freq'].astype('int32')

        # 3. Aggregated frequency statistics
        # For each unique street_name, calculate the average violation_description_freq of all its associated violations
        avg_violation_freq_by_street = combined_df.groupby('street_name')['violation_description_freq'].mean().reset_index(name='avg_violation_desc_freq_for_street')
        combined_df = pd.merge(combined_df, avg_violation_freq_by_street, on='street_name', how='left')
        combined_df['avg_violation_desc_freq_for_street'] = combined_df['avg_violation_desc_freq_for_street'].astype('float32')

        # For each unique violation_description, calculate the average street_name_freq of all its associated streets
        avg_street_freq_by_violation = combined_df.groupby('violation_description')['street_name_freq'].mean().reset_index(name='avg_street_name_freq_for_violation')
        combined_df = pd.merge(combined_df, avg_street_freq_by_violation, on='violation_description', how='left')
        combined_df['avg_street_name_freq_for_violation'] = combined_df['avg_street_name_freq_for_violation'].astype('float32')

        # Clean up intermediate frequency maps to save memory
        del combined_freq_map, street_freq_map, violation_freq_map, avg_violation_freq_by_street, avg_street_freq_by_violation
        gc.collect()

    # Augmentation 1: nyc_street_data.csv
    # Assuming this file exists and contains relevant street-level information
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        # print(f"Loading {street_data_path}...")
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name']) # Ensure unique info per street
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
            # print(f"Merged with street_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading or merging {street_data_path}: {e}. Skipping street data augmentation.")
    # else:
        # print(f"Warning: {street_data_path} not found. Skipping street data augmentation.")

    # Augmentation 2: nyc_violation_codes.csv
    # Assuming this file exists and contains details about violation codes
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        # print(f"Loading {violation_codes_path}...")
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description']) # Ensure unique info per violation
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
            # print(f"Merged with violation_codes. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading or merging {violation_codes_path}: {e}. Skipping violation codes augmentation.")
    # else:
        # print(f"Warning: {violation_codes_path} not found. Skipping violation codes augmentation.")

    # Augmentation 3: nyc_census_data.csv (Hypothetical)
    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        # print(f"Loading {census_data_path}...")
        if 'borough' in combined_df.columns: # Only proceed if borough info is available from street_data
            try:
                census_data = pd.read_csv(census_data_path)
                # Standardize column names
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]

                # Assuming 'borough' is the key and 'population_density', 'avg_income' are features
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    # Aggregate census data by borough to reduce size before merging
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
                    # print(f"Merged with census_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
                # else:
                    # print(f"Warning: Missing one or more expected columns ({relevant_census_cols}) in {census_data_path}. Skipping census data augmentation.")
            except Exception as e:
                print(f"Error loading or merging {census_data_path}: {e}. Skipping census data augmentation.")
        # else:
            # print("Warning: Borough information not available in combined_df to merge census data. Skipping.")
    # else:
        # print(f"Warning: {census_data_path} not found. Skipping census data augmentation.")


    # Split back into train and test processed dataframes
    # Merge the engineered features back to the raw dataframes (which still hold violation_count and is_pure_prediction)
    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    test_processed_df = None
    if test_df_raw is not None:
        test_processed_df = pd.merge(test_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
        del test_df_raw
        gc.collect()

    # print(f"Final train_processed_df shape: {train_processed_df.shape}")
    # if test_processed_df is not None:
        # print(f"Final test_processed_df shape: {test_processed_df.shape}")

    # Identify categorical features for CatBoost
    categorical_features = [col for col in combined_df.columns if combined_df[col].dtype in ['object', 'category']]
    # Ensure all categorical features from the combined_df are present in the final processed DFs
    categorical_features = [col for col in categorical_features if col in train_processed_df.columns]
    # print(f"Categorical features identified for CatBoost: {categorical_features}")

    # Ensure all categorical columns are of 'category' dtype for CatBoost
    for col in categorical_features:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].astype('category')
        if test_processed_df is not None and col in test_processed_df.columns:
            test_processed_df[col] = test_processed_df[col].astype('category')


    return train_processed_df, test_processed_df, categorical_features

def train_and_predict(train_df, test_df, categorical_features, catboost_params=None):
    """
    Trains a CatBoost Regressor model and generates predictions.
    Reports RMSE for validation and test sets (if ground truth available).
    """
    print("Training CatBoost model...")

    # Define features (X) and target (y)
    features = [col for col in train_df.columns if col not in ['violation_count']]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    # Split training data for validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    # print(f"Training data split: X_train={X_train.shape}, X_val={X_val.shape}")

    # Default CatBoost parameters
    default_catboost_params = {
        'iterations': 1000,
        'learning_rate': 0.05,
        'depth': 6,
        'l2_leaf_reg': 3,
        'loss_function': 'RMSE',
        'eval_metric': 'RMSE',
        'random_seed': 42,
        'verbose': 0, # Suppress verbose output for ablation runs
        'early_stopping_rounds': 50,
    }
    
    # Override defaults with provided params
    if catboost_params:
        default_catboost_params.update(catboost_params)

    model = CatBoostRegressor(**default_catboost_params)

    # Train the model
    # Convert categorical feature names to their indices for CatBoost
    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]
    # print(f"Categorical feature indices for CatBoost: {cat_features_indices}")

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        raise

    # Validate on internal validation set
    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    # print(f"Development Validation RMSE: {val_rmse}")

    # For ablation study, we don't need test predictions or submission file
    submission_df = None
    return submission_df, val_rmse

def main():
    """
    Main function to orchestrate data loading, training, and prediction for ablation study.
    """
    train_path = './input/violations_per_street_2022.csv' # Path to the 2022 training data CSV.
    
    # Create dummy files for external data if they don't exist, to avoid warnings in base run
    # This ensures the base model acts as if these files aren't found, consistent with previous studies.
    dummy_files = [
        './input/nyc_street_data.csv',
        './input/nyc_violation_codes.csv',
        './input/nyc_census_data.csv'
    ]
    for df in dummy_files:
        if not os.path.exists(df):
            # Create an empty directory and empty file if needed
            os.makedirs(os.path.dirname(df), exist_ok=True)
            with open(df, 'w') as f:
                f.write('header1,header2\n') # CatBoost doesn't mind empty files with headers
            print(f"Created dummy file: {df}")


    results = {}
    
    # --- Base Case ---
    print("\n--- Running Base Case: Current Solution ---")
    train_df_base, _, categorical_features_base = load_and_preprocess_data(train_path, test_path=None, 
                                                                             include_advanced_features=True, 
                                                                             include_length_features=True)
    _, val_rmse_base = train_and_predict(train_df_base.copy(), None, categorical_features_base)
    results['Base Case'] = val_rmse_base
    del train_df_base
    gc.collect()

    # --- Ablation 1: No Advanced Interaction and Aggregation Features ---
    print("\n--- Running Ablation 1: No Advanced Interaction and Aggregation Features ---")
    train_df_ab1, _, categorical_features_ab1 = load_and_preprocess_data(train_path, test_path=None, 
                                                                           include_advanced_features=False, 
                                                                           include_length_features=True)
    _, val_rmse_ab1 = train_and_predict(train_df_ab1.copy(), None, categorical_features_ab1)
    results['No Advanced Features'] = val_rmse_ab1
    del train_df_ab1
    gc.collect()

    # --- Ablation 2: No Basic Length Features ---
    print("\n--- Running Ablation 2: No Basic Length Features (street_name_len, violation_desc_len) ---")
    train_df_ab2, _, categorical_features_ab2 = load_and_preprocess_data(train_path, test_path=None, 
                                                                           include_advanced_features=True, 
                                                                           include_length_features=False)
    _, val_rmse_ab2 = train_and_predict(train_df_ab2.copy(), None, categorical_features_ab2)
    results['No Length Features'] = val_rmse_ab2
    del train_df_ab2
    gc.collect()

    # --- Ablation 3: Reduced CatBoost early_stopping_rounds (from 50 to 20) ---
    print("\n--- Running Ablation 3: Reduced CatBoost early_stopping_rounds (20) ---")
    train_df_ab3, _, categorical_features_ab3 = load_and_preprocess_data(train_path, test_path=None, 
                                                                           include_advanced_features=True, 
                                                                           include_length_features=True) # Use base data processing
    catboost_params_ab3 = {'early_stopping_rounds': 20}
    _, val_rmse_ab3 = train_and_predict(train_df_ab3.copy(), None, categorical_features_ab3, catboost_params=catboost_params_ab3)
    results['Reduced Early Stopping (20)'] = val_rmse_ab3
    del train_df_ab3
    gc.collect()
    
    print("\n--- Ablation Study Results ---")
    base_rmse = results['Base Case']
    print(f"Base Case RMSE: {base_rmse:.4f}")
    
    most_impactful_change = "Base Case"
    best_rmse = base_rmse

    for ablation_name, rmse in results.items():
        if ablation_name == 'Base Case':
            continue
        impact = base_rmse - rmse # Positive if ablation improved RMSE, negative if worsened
        print(f"{ablation_name} RMSE: {rmse:.4f} (Change from Base: {impact:+.4f})")
        if rmse < best_rmse:
            best_rmse = rmse
            most_impactful_change = ablation_name
            
    print(f"\nThe part of the code that contributes the most to the overall performance (i.e., resulted in the best RMSE when modified or removed) is: {most_impactful_change} with RMSE: {best_rmse:.4f}")

if __name__ == "__main__":
    main()
