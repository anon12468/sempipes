
import pandas as pd
import numpy as np
import argparse
import os
import logging
from catboost import CatBoostRegressor, Pool
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def load_and_preprocess_data(file_path, is_train=True):
    """Loads and preprocesses a CSV file."""
    if not os.path.exists(file_path):
        logging.error(f"File not found: {file_path}")
        raise FileNotFoundError(f"File not found: {file_path}")

    logging.info(f"Loading data from {file_path}")
    df = pd.read_csv(file_path)

    # Standardize column names for easier access
    df.columns = [col.strip().replace(' ', '_').lower() for col in df.columns]

    if 'street_name' not in df.columns or 'violation_description' not in df.columns:
        raise ValueError("Input file must contain 'Street Name' and 'Violation Description' columns.")

    if is_train and 'violation_count' not in df.columns:
        raise ValueError("Training file must contain 'violation_count' column.")

    return df

def feature_engineer(df, augmentation_tables_dir="./input"):
    """Applies feature engineering and joins augmentation tables."""
    logging.info("Starting feature engineering...")

    # Create a unique key for merging and tracking
    df['key'] = df['street_name'].astype(str) + '_' + df['violation_description'].astype(str)

    # --- Augmentation Tables ---
    # street_codes.csv: Potentially useful for street types or IDs
    street_codes_path = os.path.join(augmentation_tables_dir, 'street_codes.csv')
    if os.path.exists(street_codes_path):
        street_codes = pd.read_csv(street_codes_path)
        street_codes.columns = [col.strip().replace(' ', '_').lower() for col in street_codes.columns]
        if 'street_name' in street_codes.columns and 'street_code' in street_codes.columns:
            # Drop duplicates in street_codes if a street can have multiple codes, pick one or aggregate
            street_codes_unique = street_codes[['street_name', 'street_code']].drop_duplicates(subset=['street_name'])
            df = df.merge(street_codes_unique, on='street_name', how='left')
            logging.info(f"Merged {street_codes_path}")
        else:
            logging.warning(f"Skipping {street_codes_path}: Missing 'Street Name' or 'Street Code' columns.")
    else:
        logging.warning(f"Augmentation file not found: {street_codes_path}")

    # borough_data.csv: Borough information
    borough_data_path = os.path.join(augmentation_tables_dir, 'borough_data.csv')
    if os.path.exists(borough_data_path):
        borough_data = pd.read_csv(borough_data_path)
        borough_data.columns = [col.strip().replace(' ', '_').lower() for col in borough_data.columns]
        if 'street_name' in borough_data.columns and 'borough' in borough_data.columns:
            borough_data_unique = borough_data[['street_name', 'borough']].drop_duplicates(subset=['street_name'])
            df = df.merge(borough_data_unique, on='street_name', how='left')
            logging.info(f"Merged {borough_data_path}")
        else:
            logging.warning(f"Skipping {borough_data_path}: Missing 'Street Name' or 'Borough' columns.")
    else:
        logging.warning(f"Augmentation file not found: {borough_data_path}")

    # census_data.csv: Socio-economic data per street/area (can be useful)
    census_data_path = os.path.join(augmentation_tables_dir, 'census_data.csv')
    if os.path.exists(census_data_path):
        census_data = pd.read_csv(census_data_path)
        census_data.columns = [col.strip().replace(' ', '_').lower() for col in census_data.columns]
        if 'street_name' in census_data.columns:
            # Merge all columns from census_data except potentially conflicting ones if they exist
            census_data_unique = census_data.drop_duplicates(subset=['street_name'])
            df = df.merge(census_data_unique, on='street_name', how='left')
            logging.info(f"Merged {census_data_path}")
        else:
            logging.warning(f"Skipping {census_data_path}: Missing 'Street Name' column. Census data requires a join key.")
    else:
        logging.warning(f"Augmentation file not found: {census_data_path}")

    # --- Derived Features ---
    df['street_name_len'] = df['street_name'].apply(lambda x: len(str(x)) if pd.notna(x) else 0)
    df['violation_desc_len'] = df['violation_description'].apply(lambda x: len(str(x)) if pd.notna(x) else 0)

    df['street_name_word_count'] = df['street_name'].apply(lambda x: len(str(x).split()) if pd.notna(x) else 0)
    df['violation_desc_word_count'] = df['violation_description'].apply(lambda x: len(str(x).split()) if pd.notna(x) else 0)

    # Interaction features
    df['street_violation_interaction'] = df['street_name_len'] * df['violation_desc_len']

    logging.info("Finished feature engineering.")
    return df

def train_model(X_train, y_train, X_val, y_val, categorical_features_indices):
    """Trains the CatBoost model."""
    logging.info("Training CatBoostRegressor model...")
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=8,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=100,
        early_stopping_rounds=50,
        cat_features=categorical_features_indices,
        # To avoid OOM, consider reducing depth, iterations, or using fewer threads if on CPU.
        # CatBoost is generally memory efficient, but large datasets might require tuning.
        # thread_count=-1 # Use all available CPU cores
    )

    model.fit(
        X_train, y_train,
        eval_set=(X_val, y_val),
        use_best_model=True,
        plot=False
    )
    logging.info("Model training complete.")
    return model

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV file.")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Optional path to the 2023 test/evaluation data CSV file.")
    parser.add_argument("--augmentation-tables-dir", type=str, default="./input",
                        help="Directory containing augmentation tables (e.g., street_codes.csv).")
    args = parser.parse_args()

    # --- Load and preprocess training data ---
    train_df = load_and_preprocess_data(args.train_path, is_train=True)
    train_df = feature_engineer(train_df, args.augmentation_tables_dir)

    # Identify categorical features
    # CatBoost can handle NaNs in categorical features if they are passed as strings or specified correctly.
    # We will explicitly convert them to string and fill NaNs to ensure consistent category handling.
    initial_categorical_features = ['street_name', 'violation_description', 'street_code', 'borough']
    
    # Filter to only include columns actually present in the dataframe after feature engineering
    categorical_features = [col for col in initial_categorical_features if col in train_df.columns]

    # Convert specified categorical columns to string type and fill NaNs
    for col in categorical_features:
        train_df[col] = train_df[col].astype(str).fillna('NaN_Category')

    features = [col for col in train_df.columns if col not in ['violation_count', 'key']]
    
    X = train_df[features]
    y = train_df['violation_count']

    # Get indices of categorical features for CatBoost
    # Ensure these features are actually present in X
    categorical_features_indices = [X.columns.get_loc(col) for col in categorical_features if col in X.columns]

    # Split 2022 data for validation (grouped holdout / pseudo-time split is simulated by random split here)
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42, shuffle=True)

    # Train the model
    model = train_model(X_train, y_train, X_val, y_val, categorical_features_indices)

    # --- Evaluate on development validation set ---
    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    logging.info(f"Development Validation RMSE: {val_rmse:.4f}")
    print(f"Final Validation Performance: {val_rmse:.4f}") # Required print for parsing

    # --- Prediction on test data if provided ---
    if args.test_path:
        logging.info(f"Processing test data from {args.test_path}")
        test_df = load_and_preprocess_data(args.test_path, is_train=False)
        original_test_keys = test_df[['street_name', 'violation_description']].copy()

        test_df = feature_engineer(test_df, args.augmentation_tables_dir)

        # Ensure test data has the same features and types as training data
        for col in features:
            if col not in test_df.columns:
                test_df[col] = np.nan # Add missing columns, CatBoost handles NaNs in numerical features
                logging.warning(f"Column '{col}' from training features not found in test data. Filling with NaN.")
            
            # Ensure categorical features have consistent string type and filled NaNs
            if col in categorical_features:
                test_df[col] = test_df[col].astype(str).fillna('NaN_Category')

        X_test = test_df[features]

        # Handle unseen key pairs
        train_keys = set(train_df['key'].unique())
        test_keys = set(test_df['key'].unique())
        unseen_keys = test_keys - train_keys
        num_unseen = len(unseen_keys)
        logging.info(f"Number of unseen (street_name, violation_type) pairs in test set: {num_unseen}")
        logging.info(f"Unseen pairs are handled by the model's generalization based on other features.")

        # Predict
        test_preds = model.predict(X_test)
        # Ensure predictions are non-negative
        test_preds[test_preds < 0] = 0

        # Create submission file
        submission_df = pd.DataFrame({
            'street_name': original_test_keys['street_name'],
            'violation_description': original_test_keys['violation_description'],
            'predicted_count': test_preds.round().astype(int) # Round to nearest integer and cast
        })
        submission_df.to_csv('submission.csv', index=False)
        logging.info("Submission file 'submission.csv' created.")

        # If 'violation_count' is present in the test file, calculate RMSE
        if 'violation_count' in test_df.columns:
            test_true_counts = test_df['violation_count']
            test_rmse = np.sqrt(mean_squared_error(test_true_counts, test_preds))
            logging.info(f"Test Set RMSE (against ground truth): {test_rmse:.4f}")
            print(f"Test Set Performance: {test_rmse:.4f}")
        else:
            logging.info("Test file does not contain 'violation_count' for scoring. Only predictions are generated.")

    else:
        logging.info("No test-path provided. Skipping test prediction.")

if __name__ == "__main__":
    main()
