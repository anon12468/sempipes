
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    return df

def load_and_preprocess_data_ablated(train_path, test_path=None,
                                     enable_basic_length_features=True,
                                     enable_semantic_street_features=True,
                                     enable_semantic_violation_features=True):
    """
    Loads, preprocesses, and merges data from various sources, with options for ablation.
    """
    # --- Load Core Data ---
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)

    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_df = combined_keys_train.reset_index(drop=True)

    # --- Feature Engineering and Augmentation ---

    # Basic features from core data
    if enable_basic_length_features:
        combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
        combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # Semantic sub-features from street_name
    if enable_semantic_street_features:
        street_name_upper = combined_df['street_name'].str.upper()
        combined_df['street_is_ave'] = street_name_upper.str.contains(r'\bAVE\b', na=False).astype(int)
        combined_df['street_is_st'] = street_name_upper.str.contains(r'\bST\b', na=False).astype(int)
        combined_df['street_is_blvd'] = street_name_upper.str.contains(r'\bBLVD\b', na=False).astype(int)
        combined_df['street_has_numeric'] = street_name_upper.str.contains(r'\d', na=False).astype(int)

    # Semantic sub-features from violation_description
    if enable_semantic_violation_features:
        violation_desc_upper = combined_df['violation_description'].str.upper()
        combined_df['violation_is_parking'] = violation_desc_upper.str.contains(r'\bPARKING\b', na=False).astype(int)
        combined_df['violation_is_standing'] = violation_desc_upper.str.contains(r'\bSTANDING\b', na=False).astype(int)
        combined_df['violation_is_hydrant'] = violation_desc_upper.str.contains(r'\bHYDRANT\b', na=False).astype(int)

    # External data loading (kept as in original, warnings suppressed for cleaner output)
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data; gc.collect()
        except Exception as e:
            pass
    else:
        pass

    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes; gc.collect()
        except Exception as e:
            pass
    else:
        pass

    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        if 'borough' in combined_df.columns:
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg; gc.collect()
            except Exception as e:
                pass
        else:
            pass
    else:
        pass

    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw; gc.collect()

    categorical_features = [col for col in combined_df.columns if combined_df[col].dtype in ['object', 'category']]
    categorical_features = [col for col in categorical_features if col in train_processed_df.columns]

    for col in categorical_features:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].fillna('UNKNOWN_CATEGORY').astype('category')

    return train_processed_df, None, categorical_features

def train_and_predict_ablated(train_df, categorical_features):
    """
    Trains a CatBoost Regressor model and reports validation RMSE.
    """
    features = [col for col in train_df.columns if col not in ['violation_count', 'is_pure_prediction']]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6,
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Suppress verbose output for ablation runs
        early_stopping_rounds=50,
        # 'plot' is an argument for the .fit() method, not the constructor.
        # Removing it from here to fix TypeError.
    )

    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        raise

    val_preds = model.predict(X_val)
    val_preds[val_preds < 0] = 0
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    return val_rmse

if __name__ == "__main__":
    train_path = './input/violations_per_street_2022.csv'
    
    # Create dummy CSVs for external data if they don't exist
    os.makedirs('./input', exist_ok=True)
    if not os.path.exists(train_path):
        dummy_data = {
            'street_name': ['STREET A', 'STREET B', 'STREET A', 'STREET C', 'STREET B'],
            'violation_description': ['PARKING-METER', 'NO STANDING', 'SPEEDING', 'PARKING-METER', 'NO STANDING'],
            'violation_count': [10, 5, 12, 8, 7]
        }
        pd.DataFrame(dummy_data).to_csv(train_path, index=False, header=False)

    for fname in ['nyc_street_data.csv', 'nyc_violation_codes.csv', 'nyc_census_data.csv']:
        filepath = os.path.join('./input', fname)
        if not os.path.exists(filepath):
            with open(filepath, 'w') as f:
                if fname == 'nyc_street_data.csv':
                    f.write("Street Name,Borough,Street Length,Number of Lanes\nSTREET A,MANHATTAN,1000,2\nSTREET B,QUEENS,800,1\nSTREET C,BRONX,500,2")
                elif fname == 'nyc_violation_codes.csv':
                    f.write("Violation Description,Fine Amount,Points\nPARKING-METER,50,0\nNO STANDING,100,0\nSPEEDING,150,3")
                elif fname == 'nyc_census_data.csv':
                    f.write("Borough,Population_Density,Avg_Income\nMANHATTAN,27000,100000\nQUEENS,8000,75000\nBRONX,14000,60000")

    results = {}

    # Base Case
    print("--- Running Base Case ---")
    train_df_base, _, categorical_features_base = load_and_preprocess_data_ablated(train_path,
                                                                                       enable_basic_length_features=True,
                                                                                       enable_semantic_street_features=True,
                                                                                       enable_semantic_violation_features=True)
    base_rmse = train_and_predict_ablated(train_df_base, categorical_features_base)
    results['Base Case'] = base_rmse
    print(f"Base Case Validation RMSE: {base_rmse:.4f}\n")

    # Ablation 1: No Semantic Street Features
    print("--- Running Ablation: No Semantic Street Features ---")
    train_df_ablation1, _, categorical_features_ablation1 = load_and_preprocess_data_ablated(train_path,
                                                                                                 enable_basic_length_features=True,
                                                                                                 enable_semantic_street_features=False,
                                                                                                 enable_semantic_violation_features=True)
    rmse_ablation1 = train_and_predict_ablated(train_df_ablation1, categorical_features_ablation1)
    results['No Semantic Street Features'] = rmse_ablation1
    print(f"Ablation (No Semantic Street Features) Validation RMSE: {rmse_ablation1:.4f}\n")

    # Ablation 2: No Semantic Violation Features
    print("--- Running Ablation: No Semantic Violation Features ---")
    train_df_ablation2, _, categorical_features_ablation2 = load_and_preprocess_data_ablated(train_path,
                                                                                                 enable_basic_length_features=True,
                                                                                                 enable_semantic_street_features=True,
                                                                                                 enable_semantic_violation_features=False)
    rmse_ablation2 = train_and_predict_ablated(train_df_ablation2, categorical_features_ablation2)
    results['No Semantic Violation Features'] = rmse_ablation2
    print(f"Ablation (No Semantic Violation Features) Validation RMSE: {rmse_ablation2:.4f}\n")

    # Ablation 3: No Basic Length Features
    print("--- Running Ablation: No Basic Length Features ---")
    train_df_ablation3, _, categorical_features_ablation3 = load_and_preprocess_data_ablated(train_path,
                                                                                                 enable_basic_length_features=False,
                                                                                                 enable_semantic_street_features=True,
                                                                                                 enable_semantic_violation_features=True)
    rmse_ablation3 = train_and_predict_ablated(train_df_ablation3, categorical_features_ablation3)
    results['No Basic Length Features'] = rmse_ablation3
    print(f"Ablation (No Basic Length Features) Validation RMSE: {rmse_ablation3:.4f}\n")

    print("--- Ablation Study Summary ---")
    most_impacting_part = None
    max_abs_delta = 0.0
    impact_description = "" # "beneficial" or "detrimental"

    for scenario, rmse in results.items():
        if scenario == 'Base Case':
            continue
        
        delta = rmse - base_rmse
        print(f"{scenario}: RMSE = {rmse:.4f} (Delta from Base: {delta:+.4f})")

        if abs(delta) > max_abs_delta:
            max_abs_delta = abs(delta)
            most_impacting_part = scenario
            if delta > 0: # Removing this component increased RMSE, so the component was beneficial.
                impact_description = "beneficial (its removal degraded performance)"
            else: # Removing this component decreased RMSE, so the component was detrimental.
                impact_description = "detrimental (its removal improved performance)"

    if most_impacting_part:
        print(f"\nThe '{most_impacting_part}' part of the code contributes the most to the overall performance.")
        print(f"Its removal resulted in the largest absolute change in RMSE ({max_abs_delta:.4f}), indicating it was {impact_description}.")
    else:
        print("\nNo significant impact observed across the ablated components.")
    
    print(f"Final Validation Performance: {base_rmse:.4f}")
