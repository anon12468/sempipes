
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def load_data(filepath, is_test_data=False):
    """
    Loads data from a CSV file.
    Args:
        filepath (str): The path to the CSV file.
        is_test_data (bool): True if loading test data, where 'violation_count' might be missing.
    Returns:
        pd.DataFrame: Loaded data.
    """
    if not os.path.exists(filepath):
        logging.error(f"File not found: {filepath}")
        raise FileNotFoundError(f"File not found: {filepath}")
    
    logging.info(f"Loading data from {filepath}")
    df = pd.read_csv(filepath) #
    
    # Rename columns for easier access
    df = df.rename(columns={
        'Street Name': 'street_name',
        'Violation Description': 'violation_type',
        'violation_count': 'violation_count'
    })

    if not is_test_data and 'violation_count' not in df.columns:
        logging.error(f"Training file {filepath} must contain 'violation_count' column.")
        raise ValueError(f"Training file {filepath} must contain 'violation_count' column.")
    
    if is_test_data and 'violation_count' in df.columns:
        logging.warning("Test data contains 'violation_count'. It will be used for scoring but not as a feature.")

    logging.info(f"Data loaded successfully from {filepath}. Shape: {df.shape}")
    return df

def feature_engineer(df, mode='train', train_df=None):
    """
    Performs feature engineering on the dataframe.
    Args:
        df (pd.DataFrame): The dataframe to engineer features for.
        mode (str): 'train' or 'predict'.
        train_df (pd.DataFrame): Training dataframe, used for fitting encoders/scalers in 'predict' mode.
    Returns:
        pd.DataFrame: Dataframe with engineered features.
    """
    logging.info(f"Starting feature engineering in {mode} mode.")

    # Ensure key columns exist and are string type
    df['street_name'] = df['street_name'].astype(str).fillna('UNKNOWN_STREET')
    df['violation_type'] = df['violation_type'].astype(str).fillna('UNKNOWN_VIOLATION')

    # Create a unique identifier for (street_name, violation_type) pair
    df['street_violation_pair'] = df['street_name'] + '_' + df['violation_type']

    # Frequency encoding
    if mode == 'train':
        df['street_name_freq'] = df['street_name'].map(df['street_name'].value_counts(normalize=True))
        df['violation_type_freq'] = df['violation_type'].map(df['violation_type'].value_counts(normalize=True))
        df['street_violation_pair_freq'] = df['street_violation_pair'].map(df['street_violation_pair'].value_counts(normalize=True))
    elif mode == 'predict':
        if train_df is None:
            raise ValueError("train_df must be provided for feature engineering in 'predict' mode.")
        street_freq_map = train_df['street_name'].value_counts(normalize=True).to_dict()
        violation_freq_map = train_df['violation_type'].value_counts(normalize=True).to_dict()
        pair_freq_map = train_df['street_violation_pair'].value_counts(normalize=True).to_dict()

        df['street_name_freq'] = df['street_name'].map(street_freq_map).fillna(0) # Fill unseen with 0
        df['violation_type_freq'] = df['violation_type'].map(violation_freq_map).fillna(0)
        df['street_violation_pair_freq'] = df['street_violation_pair'].map(pair_freq_map).fillna(0)
    
    # Simple length features
    df['street_name_len'] = df['street_name'].apply(len)
    df['violation_type_len'] = df['violation_type'].apply(len)

    logging.info("Feature engineering complete.")
    return df

def train_model(train_df, eval_df):
    """
    Trains the CatBoostRegressor model.
    Args:
        train_df (pd.DataFrame): Training data.
        eval_df (pd.DataFrame): Evaluation data.
    Returns:
        CatBoostRegressor: Trained model.
    """
    logging.info("Preparing data for CatBoost training.")

    features = [
        'street_name', 
        'violation_type', 
        'street_violation_pair',
        'street_name_freq',
        'violation_type_freq',
        'street_violation_pair_freq',
        'street_name_len',
        'violation_type_len'
    ]
    
    # Ensure all features exist, fill with a default value if missing after feature engineering (e.g. 0 for numerical freqs)
    for col in features:
        if col not in train_df.columns:
            train_df[col] = 0 # Default for non-existent columns (should not happen with current FE)
        if col not in eval_df.columns:
            eval_df[col] = 0

    X_train = train_df[features]
    y_train = train_df['violation_count']
    X_eval = eval_df[features]
    y_eval = eval_df['violation_count']

    categorical_features_indices = [
        X_train.columns.get_loc(col) for col in ['street_name', 'violation_type', 'street_violation_pair']
    ]

    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    eval_pool = Pool(X_eval, y_eval, cat_features=categorical_features_indices)

    logging.info("Initializing CatBoostRegressor.")
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=8,
        loss_function='RMSE', #
        eval_metric='RMSE',
        random_seed=42,
        early_stopping_rounds=50,
        verbose=100,
        thread_count=-1, # Use all available CPU cores
        nan_mode='Min', # Handle NaN values by treating them as minimum values
        grow_policy='Lossguide' # Faster training
    )

    logging.info("Starting model training.")
    model.fit(train_pool, eval_set=eval_pool, plot=False) #
    logging.info("Model training finished.")
    return model

def evaluate_model(model, X_eval, y_eval):
    """
    Evaluates the model on the given data.
    Args:
        model (CatBoostRegressor): Trained model.
        X_eval (pd.DataFrame): Features for evaluation.
        y_eval (pd.Series): True labels for evaluation.
    Returns:
        float: RMSE score.
    """
    logging.info("Making predictions on the evaluation set.")
    predictions = model.predict(X_eval)
    predictions = np.maximum(0, predictions) # Ensure predictions are non-negative
    rmse = np.sqrt(mean_squared_error(y_eval, predictions)) #
    logging.info(f"Evaluation RMSE: {rmse}")
    return rmse

def predict_on_test_data(model, test_df, train_original_df):
    """
    Generates predictions for the test dataset.
    Args:
        model (CatBoostRegressor): Trained model.
        test_df (pd.DataFrame): Test data (potentially without 'violation_count').
        train_original_df (pd.DataFrame): Original training data for unseen key handling.
    Returns:
        pd.DataFrame: DataFrame with predictions.
    """
    logging.info("Preparing test data for prediction.")
    # Apply feature engineering to test data using statistics from training data
    test_engineered_df = feature_engineer(test_df.copy(), mode='predict', train_df=train_original_df)

    # Identify unseen (street_name, violation_type) pairs
    train_keys = set(train_original_df['street_name'] + '_' + train_original_df['violation_type'])
    test_keys = set(test_engineered_df['street_name'] + '_' + test_engineered_df['violation_type'])
    unseen_keys_count = len(test_keys - train_keys)
    logging.info(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_keys_count}")

    # Prepare features for prediction
    features = [
        'street_name', 
        'violation_type', 
        'street_violation_pair',
        'street_name_freq',
        'violation_type_freq',
        'street_violation_pair_freq',
        'street_name_len',
        'violation_type_len'
    ]
    
    # Ensure all features expected by the model exist in the test_engineered_df
    for col in features:
        if col not in test_engineered_df.columns:
            test_engineered_df[col] = 0 # Fallback, should be handled by feature_engineer

    X_test = test_engineered_df[features]

    # Create a Pool for prediction if categorical features are used
    categorical_features_indices = [
        X_test.columns.get_loc(col) for col in ['street_name', 'violation_type', 'street_violation_pair']
    ]
    test_pool = Pool(X_test, cat_features=categorical_features_indices)

    logging.info("Generating predictions on test data.")
    predictions = model.predict(test_pool)
    predictions = np.maximum(0, predictions) # Ensure predictions are non-negative

    test_df['predicted_count'] = predictions
    logging.info("Predictions generated.")
    return test_df[['street_name', 'violation_type', 'predicted_count']]

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations for 2023.") #
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV file.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional: Path to the 2023 test data CSV file for prediction/evaluation.')
    
    args = parser.parse_args()

    # Load training data
    train_data_2022 = load_data(args.train_path)

    # Feature engineering for training data
    train_engineered_df = feature_engineer(train_data_2022.copy(), mode='train')

    # Split 2022 data into training and validation sets
    # Using a random split of keys to simulate grouped holdout
    unique_pairs = train_engineered_df[['street_name', 'violation_type']].drop_duplicates()
    train_pairs, eval_pairs = train_test_split(unique_pairs, test_size=0.2, random_state=42) #

    # Reconstruct train/eval dataframes based on the split pairs
    train_set = pd.merge(train_engineered_df, train_pairs, on=['street_name', 'violation_type'], how='inner')
    eval_set = pd.merge(train_engineered_df, eval_pairs, on=['street_name', 'violation_type'], how='inner')

    logging.info(f"Split 2022 data into training set (rows: {train_set.shape[0]}) and evaluation set (rows: {eval_set.shape[0]}).")

    # Train the model
    model = train_model(train_set, eval_set)

    # Evaluate on the internal validation set
    X_eval = eval_set[[col for col in eval_set.columns if col not in ['violation_count']]]
    y_eval = eval_set['violation_count']
    final_validation_score = evaluate_model(model, X_eval, y_eval)
    print(f'Final Validation Performance: {final_validation_score}')

    # If test-path is provided, generate predictions
    if args.test_path:
        logging.info(f"Test path provided: {args.test_path}. Generating predictions.")
        test_data_2023 = load_data(args.test_path, is_test_data=True)
        
        # Original 2022 data is needed for `feature_engineer` in 'predict' mode for frequency mapping
        predictions_df = predict_on_test_data(model, test_data_2023.copy(), train_data_2022)
        
        output_filename = 'submission.csv'
        predictions_df.to_csv(output_filename, index=False)
        logging.info(f"Predictions saved to {output_filename}")

        # If violation_count is present in test_data_2023, calculate RMSE
        if 'violation_count' in test_data_2023.columns:
            logging.info("Calculating RMSE for the provided test set.")
            y_true_test = test_data_2023['violation_count']
            y_pred_test = predictions_df['predicted_count']
            test_rmse = np.sqrt(mean_squared_error(y_true_test, y_pred_test))
            logging.info(f"RMSE on test data: {test_rmse}")
        else:
            logging.info("Test data does not contain 'violation_count'. Skipping RMSE calculation for test set.")

if __name__ == '__main__':
    main()
