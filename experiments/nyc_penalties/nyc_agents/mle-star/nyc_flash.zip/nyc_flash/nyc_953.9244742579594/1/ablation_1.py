
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys
import copy

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    initial_memory = df.memory_usage(deep=True).sum() / (1024**2)
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            # Also ensure we have enough unique values to make it a category (more than 1)
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
            elif num_unique_values == 1:
                pass 
            else:
                df[col] = df[col].astype(str)
    final_memory = df.memory_usage(deep=True).sum() / (1024**2)
    return df

def load_all_data_for_ablation(train_path):
    """
    Loads all core and augmentation datasets for the ablation study.
    Modified to only load train data and augmentation data, no test data.
    """
    print("Loading all core and augmentation data for ablation...")

    # --- Load Core Data ---
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)
    print(f"Initial train_df loaded. Shape: {train_df_raw.shape}, Memory: {train_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # --- Load Augmentation Data ---
    nyc_street_data_df = pd.DataFrame()
    nyc_violation_codes_df = pd.DataFrame()
    nyc_census_data_df = pd.DataFrame()

    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        # print(f"Loading {street_data_path}...") # Suppress for cleaner output
        try:
            nyc_street_data_df = pd.read_csv(street_data_path)
            nyc_street_data_df.columns = [col.lower().replace(' ', '_') for col in nyc_street_data_df.columns]
            nyc_street_data_df = nyc_street_data_df.drop_duplicates(subset=['street_name'])
            nyc_street_data_df = downcast_dtypes(nyc_street_data_df)
            # print(f"  {street_data_path} loaded. Shape: {nyc_street_data_df.shape}, Memory: {nyc_street_data_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading {street_data_path}: {e}. Initializing as empty DataFrame.")
            nyc_street_data_df = pd.DataFrame()
    else:
        print(f"Warning: {street_data_path} not found. Skipping street data augmentation.")

    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        # print(f"Loading {violation_codes_path}...") # Suppress for cleaner output
        try:
            nyc_violation_codes_df = pd.read_csv(violation_codes_path)
            nyc_violation_codes_df.columns = [col.lower().replace(' ', '_') for col in nyc_violation_codes_df.columns]
            nyc_violation_codes_df = nyc_violation_codes_df.drop_duplicates(subset=['violation_description'])
            nyc_violation_codes_df = downcast_dtypes(nyc_violation_codes_df)
            # print(f"  {violation_codes_path} loaded. Shape: {nyc_violation_codes_df.shape}, Memory: {nyc_violation_codes_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading {violation_codes_path}: {e}. Initializing as empty DataFrame.")
            nyc_violation_codes_df = pd.DataFrame()
    else:
        print(f"Warning: {violation_codes_path} not found. Skipping violation codes augmentation.")

    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        # print(f"Loading {census_data_path}...") # Suppress for cleaner output
        try:
            nyc_census_data_df = pd.read_csv(census_data_path)
            nyc_census_data_df.columns = [col.lower().replace(' ', '_') for col in nyc_census_data_df.columns]
            
            numerical_cols_census = nyc_census_data_df.select_dtypes(include=np.number).columns.tolist()
            if 'borough' in nyc_census_data_df.columns and numerical_cols_census:
                nyc_census_data_df = nyc_census_data_df.groupby('borough')[numerical_cols_census].mean().reset_index()
            else:
                 pass 
            nyc_census_data_df = downcast_dtypes(nyc_census_data_df)
            # print(f"  {census_data_path} loaded. Shape: {nyc_census_data_df.shape}, Memory: {nyc_census_data_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading {census_data_path}: {e}. Initializing as empty DataFrame.")
            nyc_census_data_df = pd.DataFrame()
    else:
        print(f"Warning: {census_data_path} not found. Skipping census data augmentation.")

    return train_df_raw, nyc_street_data_df, nyc_violation_codes_df, nyc_census_data_df


def _prepare_data_and_engineer_features_ablated(df_to_process, nyc_street_data_df, nyc_violation_codes_df, nyc_census_data_df, df_name="df", include_len_features=True):
    """
    Helper function to merge external datasets and engineer features for a given dataframe.
    Modified to include 'include_len_features' flag for ablation.
    """
    df_processed = df_to_process.copy()

    # Basic features from core data
    if include_len_features:
        df_processed['street_name_len'] = df_processed['street_name'].apply(len).astype('int16')
        df_processed['violation_desc_len'] = df_processed['violation_description'].apply(len).astype('int16')

    # --- Merge with external datasets ---
    if not nyc_street_data_df.empty and 'street_name' in df_processed.columns and 'street_name' in nyc_street_data_df.columns:
        street_cols_to_merge = ['street_name'] + [col for col in nyc_street_data_df.columns if col not in df_processed.columns and col != 'street_name']
        df_processed = df_processed.merge(nyc_street_data_df[street_cols_to_merge], on='street_name', how='left')

    if not nyc_violation_codes_df.empty and 'violation_description' in df_processed.columns and 'violation_description' in nyc_violation_codes_df.columns:
        violation_cols_to_merge = ['violation_description'] + [col for col in nyc_violation_codes_df.columns if col not in df_processed.columns and col != 'violation_description']
        df_processed = df_processed.merge(nyc_violation_codes_df[violation_cols_to_merge], on='violation_description', how='left')

    if not nyc_census_data_df.empty and 'borough' in df_processed.columns and 'borough' in nyc_census_data_df.columns:
        census_cols_to_merge = ['borough'] + [col for col in nyc_census_data_df.columns if col not in df_processed.columns and col != 'borough']
        df_processed = df_processed.merge(nyc_census_data_df[census_cols_to_merge], on='borough', how='left')

    # --- Feature Engineering and Missing Value Handling for new features ---
    potential_categorical_cols = [
        'borough', 'on_street_name', 'from_street_name', 'to_street_name',
        'street_type',
        'violation_category', 'violation_type'
    ]
    potential_numerical_cols = [
        'street_length', 'number_of_lanes',
        'fine_amount', 'points',
        'population_density', 'avg_income', 'population', 'median_income', 'housing_density'
    ]

    for col in potential_categorical_cols:
        if col in df_processed.columns:
            df_processed[col] = df_processed[col].fillna('Unknown').astype('category')

    for col in potential_numerical_cols:
        if col in df_processed.columns:
            df_processed[col] = df_processed[col].fillna(0)

    for col in df_processed.select_dtypes(include='object').columns:
        num_unique_values = len(df_processed[col].unique())
        num_total_values = len(df_processed[col])
        if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
            df_processed[col] = df_processed[col].astype('category')
        else:
            df_processed[col] = df_processed[col].astype(str)

    return df_processed


def train_model_and_evaluate_ablated(
    train_df_raw,
    nyc_street_data_df,
    nyc_violation_codes_df,
    nyc_census_data_df,
    include_len_features=True,
    cb_iterations=1000,
    cb_learning_rate=0.05,
    cb_depth=6,
    cb_l2_leaf_reg=3,
):
    """
    Trains a CatBoost Regressor model and evaluates on a validation set.
    Parameters for ablation are passed directly.
    """
    train_df_processed = _prepare_data_and_engineer_features_ablated(
        train_df_raw,
        nyc_street_data_df,
        nyc_violation_codes_df,
        nyc_census_data_df,
        df_name="train_df",
        include_len_features=include_len_features
    )
    gc.collect()

    target = 'violation_count'
    exclude_features = [target]
    features = [col for col in train_df_processed.columns if col not in exclude_features]
    
    X = train_df_processed[features]
    y = train_df_processed[target]

    categorical_features_for_catboost = [col for col in X.columns if X[col].dtype.name == 'category' or X[col].dtype == object]
    
    for col in categorical_features_for_catboost:
        if X[col].dtype != 'category':
             X[col] = X[col].astype('category')

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    model = CatBoostRegressor(
        iterations=cb_iterations,
        learning_rate=cb_learning_rate,
        depth=cb_depth,
        l2_leaf_reg=cb_l2_leaf_reg,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Suppress verbose output for ablation runs
        early_stopping_rounds=50,
    )

    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features_for_catboost if col in X_train.columns]
    
    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        raise

    val_preds = model.predict(X_val)
    val_preds[val_preds < 0] = 0
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))

    return val_rmse

def ablation_main():
    """
    Main function to orchestrate the ablation study.
    """
    parser = argparse.ArgumentParser(description="Perform an ablation study on NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()

    # Load all raw dataframes once
    base_train_df_raw, base_nyc_street_data_df, base_nyc_violation_codes_df, base_nyc_census_data_df = \
        load_all_data_for_ablation(args.train_path)
    
    results = {}

    print("\n--- Starting Ablation Study ---")

    # --- Base Case ---
    print("\n--- Running Base Case: All features, all augmentations, default CatBoost ---")
    base_rmse = train_model_and_evaluate_ablated(
        train_df_raw=base_train_df_raw.copy(), # Pass a copy to avoid modification affecting subsequent runs
        nyc_street_data_df=base_nyc_street_data_df,
        nyc_violation_codes_df=base_nyc_violation_codes_df,
        nyc_census_data_df=base_nyc_census_data_df,
        include_len_features=True,
        cb_iterations=1000,
        cb_learning_rate=0.05,
        cb_depth=6,
        cb_l2_leaf_reg=3,
    )
    results['Base Case'] = base_rmse
    print(f"Base Case Validation RMSE: {base_rmse:.4f}")

    # --- Ablation 1: No External Data Augmentations ---
    print("\n--- Running Ablation 1: No External Data Augmentations (street, violation codes, census) ---")
    ablation1_rmse = train_model_and_evaluate_ablated(
        train_df_raw=base_train_df_raw.copy(),
        nyc_street_data_df=pd.DataFrame(), # Empty dataframe to disable street data
        nyc_violation_codes_df=pd.DataFrame(), # Empty dataframe to disable violation codes
        nyc_census_data_df=pd.DataFrame(), # Empty dataframe to disable census data
        include_len_features=True,
        cb_iterations=1000,
        cb_learning_rate=0.05,
        cb_depth=6,
        cb_l2_leaf_reg=3,
    )
    results['No External Data Augmentations'] = ablation1_rmse
    print(f"Ablation 1 Validation RMSE (No Augmentations): {ablation1_rmse:.4f}")

    # --- Ablation 2: No Basic Length Features (street_name_len, violation_desc_len) ---
    print("\n--- Running Ablation 2: No Basic Length Features (street_name_len, violation_desc_len) ---")
    ablation2_rmse = train_model_and_evaluate_ablated(
        train_df_raw=base_train_df_raw.copy(),
        nyc_street_data_df=base_nyc_street_data_df,
        nyc_violation_codes_df=base_nyc_violation_codes_df,
        nyc_census_data_df=base_nyc_census_data_df,
        include_len_features=False, # Disable length features
        cb_iterations=1000,
        cb_learning_rate=0.05,
        cb_depth=6,
        cb_l2_leaf_reg=3,
    )
    results['No Basic Length Features'] = ablation2_rmse
    print(f"Ablation 2 Validation RMSE (No Basic Length Features): {ablation2_rmse:.4f}")

    # --- Ablation 3: Changed CatBoost Hyperparameters (More aggressive learning rate, less L2) ---
    print("\n--- Running Ablation 3: CatBoost Hyperparameters (LR=0.1, L2=1) ---")
    ablation3_rmse = train_model_and_evaluate_ablated(
        train_df_raw=base_train_df_raw.copy(),
        nyc_street_data_df=base_nyc_street_data_df,
        nyc_violation_codes_df=base_nyc_violation_codes_df,
        nyc_census_data_df=base_nyc_census_data_df,
        include_len_features=True,
        cb_iterations=1000,
        cb_learning_rate=0.1, # Increased learning rate
        cb_depth=6,
        cb_l2_leaf_reg=1, # Reduced L2 regularization
    )
    results['Aggressive CatBoost Hyperparameters'] = ablation3_rmse
    print(f"Ablation 3 Validation RMSE (Aggressive CatBoost): {ablation3_rmse:.4f}")

    print("\n--- Ablation Study Summary ---")
    for name, rmse in results.items():
        print(f"- {name}: RMSE = {rmse:.4f}")

    print(f"\nBase Case RMSE: {results['Base Case']:.4f}")
    
    # Determine the "most contributing part" by comparing to the base case
    best_improvement = 0
    best_improvement_name = "None (Base Case is optimal or no ablation improved performance)"
    
    worst_degradation = 0
    worst_degradation_name = "None (No ablation degraded performance more than 0)"

    for name, rmse in results.items():
        if name == 'Base Case':
            continue
        
        diff_from_base = results['Base Case'] - rmse # Positive if ablation improved (lower RMSE)
        if diff_from_base > best_improvement:
            best_improvement = diff_from_base
            best_improvement_name = name
        
        diff_to_base = rmse - results['Base Case'] # Positive if ablation degraded (higher RMSE)
        if diff_to_base > worst_degradation:
            worst_degradation = diff_to_base
            worst_degradation_name = name

    print("\n--- Conclusion on Most Contributing Part ---")

    if best_improvement > 0:
        print(f"The most impactful change (resulting in the best performance improvement) was '{best_improvement_name}'.")
        print(f"This modification reduced the RMSE by {best_improvement:.4f} compared to the Base Case.")
        print("This suggests the default configuration for this part was suboptimal, and the ablated version performs better.")
    elif worst_degradation > 0:
        print(f"The most impactful component (whose removal/modification caused the largest performance degradation) was '{worst_degradation_name}'.")
        print(f"Removing/modifying this component increased the RMSE by {worst_degradation:.4f} compared to the Base Case.")
        print("This indicates it is a crucial component for the model's performance.")
    else:
        print("No significant change in RMSE observed across ablations. The Base Case appears robust or already optimal for the tested components.")

if __name__ == "__main__":
    ablation_main()
