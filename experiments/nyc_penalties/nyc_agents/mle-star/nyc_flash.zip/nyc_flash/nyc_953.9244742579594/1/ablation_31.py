
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Suppress warnings for cleaner output during ablation runs
import warnings
warnings.filterwarnings('ignore', category=UserWarning)
warnings.filterwarnings('ignore', category=FutureWarning)
pd.options.mode.chained_assignment = None # Suppress SettingWithCopyWarning

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    # initial_memory = df.memory_usage(deep=True).sum() / (1024**2) # Commented for ablation
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    # final_memory = df.memory_usage(deep=True).sum() / (1024**2) # Commented for ablation
    return df

def load_and_preprocess_data_base(train_path, test_path=None):
    """
    Loads, preprocesses, and merges data from various sources.
    This is the base function used for the ablation study.
    """
    # print("Loading and preprocessing data...") # Commented for ablation

    # --- Load Core Data ---
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)
    # print(f"Initial train_df loaded. Shape: {train_df_raw.shape}, Memory: {train_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB") # Commented for ablation

    test_df_raw = None # For ablation, we don't strictly need test_path to be passed
    if test_path and os.path.exists(test_path): # Check if test_path is provided and exists
        test_df_raw = pd.read_csv(test_path)
        test_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
        test_df_raw['is_pure_prediction'] = test_df_raw['violation_count'].isna()
        test_df_raw = downcast_dtypes(test_df_raw)
        # print(f"Test_df loaded. Shape: {test_df_raw.shape}, Memory: {test_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB") # Commented for ablation

    # Combine unique street_name and violation_description pairs from train and test
    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_keys_test = pd.DataFrame()
    if test_df_raw is not None:
        combined_keys_test = test_df_raw[['street_name', 'violation_description']].drop_duplicates()

    combined_df = pd.concat([combined_keys_train, combined_keys_test], ignore_index=True).drop_duplicates().reset_index(drop=True)
    del combined_keys_train, combined_keys_test # Free memory
    gc.collect()
    # print(f"Combined unique (street, violation) pairs for feature engineering. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB") # Commented for ablation

    # --- Feature Engineering and Augmentation ---
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        # print(f"Loading {street_data_path}...") # Commented for ablation
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
        except Exception as e:
            # print(f"Error loading or merging {street_data_path}: {e}. Skipping street data augmentation.") # Commented for ablation
            pass # Silently skip errors for ablation brevity
    # else: print(f"Warning: {street_data_path} not found. Skipping street data augmentation.") # Commented for ablation

    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        # print(f"Loading {violation_codes_path}...") # Commented for ablation
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
        except Exception as e:
            # print(f"Error loading or merging {violation_codes_path}: {e}. Skipping violation codes augmentation.") # Commented for ablation
            pass
    # else: print(f"Warning: {violation_codes_path} not found. Skipping violation codes augmentation.") # Commented for ablation

    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        # print(f"Loading {census_data_path}...") # Commented for ablation
        if 'borough' in combined_df.columns:
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
            except Exception as e:
                # print(f"Error loading or merging {census_data_path}: {e}. Skipping census data augmentation.") # Commented for ablation
                pass
        # else: print("Warning: Borough information not available in combined_df to merge census data. Skipping.") # Commented for ablation
    # else: print(f"Warning: {census_data_path} not found. Skipping census data augmentation.") # Commented for ablation

    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    test_processed_df = None # For ablation, we only care about train_processed_df

    categorical_features = [col for col in combined_df.columns if combined_df[col].dtype in ['object', 'category']]
    categorical_features = [col for col in categorical_features if col in train_processed_df.columns]
    # print(f"Categorical features identified for CatBoost: {categorical_features}") # Commented for ablation

    for col in categorical_features:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].astype('category')
        if test_processed_df is not None and col in test_processed_df.columns:
            test_processed_df[col] = test_processed_df[col].astype('category')

    return train_processed_df, test_processed_df, categorical_features

def train_and_predict_base(train_df, test_df, categorical_features):
    """
    Trains a CatBoost Regressor model and generates predictions.
    This is the base function used for the ablation study.
    """
    # print("Training CatBoost model...") # Commented for ablation

    features = [col for col in train_df.columns if col not in ['violation_count']]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    # print(f"Training data split: X_train={X_train.shape}, X_val={X_val.shape}") # Commented for ablation

    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6,
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Reduced verbose for ablation study
        early_stopping_rounds=50,
    )

    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]
    # print(f"Categorical feature indices for CatBoost: {cat_features_indices}") # Commented for ablation

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        raise

    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    # print(f"Development Validation RMSE: {val_rmse}") # Commented for ablation

    return None, val_rmse # Only return val_rmse for ablation

# --- Dummy data creation function ---
def create_dummy_data(input_dir='./input'):
    os.makedirs(input_dir, exist_ok=True)

    # Dummy train data
    train_path = os.path.join(input_dir, 'violations_per_street_2022.csv')
    if not os.path.exists(train_path):
        # print(f"Creating dummy train data: {train_path}") # Commented for ablation
        dummy_train_data = {
            'Street Name': ['A ST', 'B ST', 'C AVE', 'D BLVD', 'A ST', 'B ST', 'C AVE', 'E RD', 'F ST', 'G AVE', 'A ST', 'B ST'],
            'Violation Description': ['PARKING VIOLATION', 'NO PARKING', 'SPEEDING', 'RED LIGHT', 'NO PARKING', 'PARKING VIOLATION', 'RED LIGHT', 'STOP SIGN', 'PARKING VIOLATION', 'SPEEDING', 'PARKING VIOLATION', 'NO PARKING'],
            'Violation Count': [100, 150, 50, 75, 120, 130, 60, 40, 110, 55, 90, 160]
        }
        pd.DataFrame(dummy_train_data).to_csv(train_path, index=False)

    # Dummy test data (only for structure, not used in ablation, but needed by load_and_preprocess_data_base if test_path is passed)
    test_path = os.path.join(input_dir, 'violations_per_street_2023.csv')
    if not os.path.exists(test_path):
        # print(f"Creating dummy test data: {test_path}") # Commented for ablation
        dummy_test_data = {
            'Street Name': ['A ST', 'H AVE', 'C AVE', 'I ST', 'B ST', 'Z ST'],
            'Violation Description': ['PARKING VIOLATION', 'NO PARKING', 'SPEEDING', 'RED LIGHT', 'PARKING VIOLATION', 'NO PARKING'],
            'Violation Count': [110, 160, np.nan, 80, 140, 70]
        }
        pd.DataFrame(dummy_test_data).to_csv(test_path, index=False)

    # Dummy nyc_street_data.csv
    street_data_path = os.path.join(input_dir, 'nyc_street_data.csv')
    if not os.path.exists(street_data_path):
        # print(f"Creating dummy street data: {street_data_path}") # Commented for ablation
        dummy_street_data = {
            'Street Name': ['A ST', 'B ST', 'C AVE', 'D BLVD', 'E RD', 'F ST', 'G AVE', 'H AVE', 'I ST', 'Z ST'],
            'Borough': ['Manhattan', 'Manhattan', 'Bronx', 'Brooklyn', 'Queens', 'Manhattan', 'Bronx', 'Brooklyn', 'Queens', 'Staten Island'],
            'Street Length': [1000, 1200, 800, 1500, 900, 1100, 700, 1300, 1000, 500],
            'Number of Lanes': [2, 3, 2, 4, 2, 3, 2, 3, 2, 1]
        }
        pd.DataFrame(dummy_street_data).to_csv(street_data_path, index=False)

    # Dummy nyc_violation_codes.csv
    violation_codes_path = os.path.join(input_dir, 'nyc_violation_codes.csv')
    if not os.path.exists(violation_codes_path):
        # print(f"Creating dummy violation codes data: {violation_codes_path}") # Commented for ablation
        dummy_violation_codes = {
            'Violation Description': ['PARKING VIOLATION', 'NO PARKING', 'SPEEDING', 'RED LIGHT', 'STOP SIGN'],
            'Fine Amount': [65, 115, 150, 200, 100],
            'Points': [0, 0, 3, 2, 1]
        }
        pd.DataFrame(dummy_violation_codes).to_csv(violation_codes_path, index=False)

    # Dummy nyc_census_data.csv
    census_data_path = os.path.join(input_dir, 'nyc_census_data.csv')
    if not os.path.exists(census_data_path):
        # print(f"Creating dummy census data: {census_data_path}") # Commented for ablation
        dummy_census_data = {
            'Borough': ['Manhattan', 'Bronx', 'Brooklyn', 'Queens', 'Staten Island'],
            'Population Density': [27000, 13000, 15000, 8000, 3000],
            'Avg Income': [120000, 60000, 75000, 85000, 70000]
        }
        pd.DataFrame(dummy_census_data).to_csv(census_data_path, index=False)

# --- Ablation Study Main ---
def run_ablation_study():
    create_dummy_data()

    train_path = './input/violations_per_street_2022.csv'
    test_path = './input/violations_per_street_2023.csv' # Kept for load_and_preprocess_data_base, but only train_df is used

    results = {}

    # --- Base Case ---
    print("\n--- Running Base Case ---")
    train_df, _, categorical_features = load_and_preprocess_data_base(train_path, test_path)
    _, base_rmse = train_and_predict_base(train_df, None, categorical_features)
    results['Base Case'] = base_rmse
    print(f"Base Case Validation RMSE: {base_rmse:.4f}\n")

    # --- Ablation 1: Build combined_df only from training data ---
    # This changes the strategy for feature engineering (e.g., frequencies, merged external data)
    # by only using unique street/violation pairs observed in the training data, not pooled from train+test.
    print("\n--- Running Ablation 1: Build combined_df only from training data ---")
    def load_and_preprocess_data_ablation1(train_path_a1, test_path_a1=None):
        train_df_raw_mod = pd.read_csv(train_path_a1)
        train_df_raw_mod.columns = ['street_name', 'violation_description', 'violation_count']
        train_df_raw_mod = downcast_dtypes(train_df_raw_mod)

        # IMPORTANT CHANGE: combined_keys_test is completely ignored
        combined_keys_train_mod = train_df_raw_mod[['street_name', 'violation_description']].drop_duplicates()
        combined_df_ablation1 = combined_keys_train_mod.reset_index(drop=True) # Only from train
        del combined_keys_train_mod; gc.collect()

        # Rest of the feature engineering (len, external merges) is the same as base
        combined_df_ablation1['street_name_len'] = combined_df_ablation1['street_name'].apply(len).astype('int16')
        combined_df_ablation1['violation_desc_len'] = combined_df_ablation1['violation_description'].apply(len).astype('int16')

        street_data_path = './input/nyc_street_data.csv'
        if os.path.exists(street_data_path):
            try:
                street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
                street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
                street_data = downcast_dtypes(street_data)
                street_data = street_data.drop_duplicates(subset=['street_name'])
                combined_df_ablation1 = pd.merge(combined_df_ablation1, street_data, on='street_name', how='left')
                del street_data; gc.collect()
            except Exception as e: pass

        violation_codes_path = './input/nyc_violation_codes.csv'
        if os.path.exists(violation_codes_path):
            try:
                violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
                violation_codes.columns = ['violation_description', 'fine_amount', 'points']
                violation_codes = downcast_dtypes(violation_codes)
                violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
                combined_df_ablation1 = pd.merge(combined_df_ablation1, violation_codes, on='violation_description', how='left')
                del violation_codes; gc.collect()
            except Exception as e: pass

        census_data_path = './input/nyc_census_data.csv'
        if os.path.exists(census_data_path):
            if 'borough' in combined_df_ablation1.columns:
                try:
                    census_data = pd.read_csv(census_data_path)
                    census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                    relevant_census_cols = ['borough', 'population_density', 'avg_income']
                    if all(col in census_data.columns for col in relevant_census_cols):
                        census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                        census_agg = downcast_dtypes(census_agg)
                        combined_df_ablation1 = pd.merge(combined_df_ablation1, census_agg, on='borough', how='left')
                        del census_data, census_agg; gc.collect()
                except Exception as e: pass

        train_processed_df_ablation1 = pd.merge(train_df_raw_mod, combined_df_ablation1, on=['street_name', 'violation_description'], how='left')
        del train_df_raw_mod; gc.collect()

        test_processed_df_ablation1 = None # Not needed for ablation, so explicitly set to None

        categorical_features_ablation1 = [col for col in combined_df_ablation1.columns if combined_df_ablation1[col].dtype in ['object', 'category']]
        categorical_features_ablation1 = [col for col in categorical_features_ablation1 if col in train_processed_df_ablation1.columns]

        for col in categorical_features_ablation1:
            if col in train_processed_df_ablation1.columns:
                train_processed_df_ablation1[col] = train_processed_df_ablation1[col].astype('category')
        
        return train_processed_df_ablation1, test_processed_df_ablation1, categorical_features_ablation1

    train_df_a1, _, categorical_features_a1 = load_and_preprocess_data_ablation1(train_path, test_path)
    _, rmse_a1 = train_and_predict_base(train_df_a1, None, categorical_features_a1)
    results['Ablation 1: Only Train Keys for FE'] = rmse_a1
    print(f"Ablation 1 Validation RMSE (Only Train Keys for FE): {rmse_a1:.4f}\n")


    # --- Ablation 2: Enable CatBoost grow_policy='Lossguide' with max_leaves=31 ---
    # This changes the tree building strategy for CatBoost.
    print("\n--- Running Ablation 2: CatBoost grow_policy='Lossguide' ---")
    def train_and_predict_ablation2(train_df_a2_mod, test_df_a2_mod, categorical_features_a2_mod):
        features = [col for col in train_df_a2_mod.columns if col not in ['violation_count']]
        target = 'violation_count'
        X = train_df_a2_mod[features]
        y = train_df_a2_mod[target]
        X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

        model = CatBoostRegressor(
            iterations=1000,
            learning_rate=0.05,
            depth=6, # Depth might be ignored with Lossguide, but kept as original for consistency
            l2_leaf_reg=3,
            loss_function='RMSE',
            eval_metric='RMSE',
            random_seed=42,
            verbose=0,
            early_stopping_rounds=50,
            grow_policy='Lossguide', # ADDED FOR ABLATION
            max_leaves=31 # ADDED FOR ABLATION (important for Lossguide)
        )
        cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features_a2_mod if col in X_train.columns]
        try:
            model.fit(X_train, y_train, eval_set=(X_val, y_val), cat_features=cat_features_indices)
        except Exception as e: print(f"Error during CatBoost training: {e}"); raise
        val_preds = model.predict(X_val)
        val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
        return None, val_rmse

    train_df_a2, _, categorical_features_a2 = load_and_preprocess_data_base(train_path, test_path)
    _, rmse_a2 = train_and_predict_ablation2(train_df_a2, None, categorical_features_a2)
    results['Ablation 2: CatBoost Lossguide'] = rmse_a2
    print(f"Ablation 2 Validation RMSE (CatBoost Lossguide): {rmse_a2:.4f}\n")

    # --- Ablation 3: Remove raw 'street_name' and 'violation_description' from features ---
    # This tests if the raw high-cardinality features are beneficial after other features (like length, external data)
    # have been engineered using them.
    print("\n--- Running Ablation 3: Remove raw street_name/violation_description ---")
    def train_and_predict_ablation3(train_df_a3_mod, test_df_a3_mod, categorical_features_a3_mod):
        # Exclude raw 'street_name' and 'violation_description' from the final feature set
        features_to_exclude = ['violation_count', 'street_name', 'violation_description']
        features = [col for col in train_df_a3_mod.columns if col not in features_to_exclude]
        target = 'violation_count'
        X = train_df_a3_mod[features]
        y = train_df_a3_mod[target]
        X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

        model = CatBoostRegressor(
            iterations=1000,
            learning_rate=0.05,
            depth=6,
            l2_leaf_reg=3,
            loss_function='RMSE',
            eval_metric='RMSE',
            random_seed=42,
            verbose=0,
            early_stopping_rounds=50,
        )
        # Update categorical features as well, removing 'street_name' and 'violation_description'
        categorical_features_mod = [f for f in categorical_features_a3_mod if f not in ['street_name', 'violation_description']]
        cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features_mod if col in X_train.columns]
        try:
            model.fit(X_train, y_train, eval_set=(X_val, y_val), cat_features=cat_features_indices)
        except Exception as e: print(f"Error during CatBoost training: {e}"); raise
        val_preds = model.predict(X_val)
        val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
        return None, val_rmse

    train_df_a3, _, categorical_features_a3 = load_and_preprocess_data_base(train_path, test_path)
    _, rmse_a3 = train_and_predict_ablation3(train_df_a3, None, categorical_features_a3)
    results['Ablation 3: No Raw Street/Violation Features'] = rmse_a3
    print(f"Ablation 3 Validation RMSE (No Raw Street/Violation Features): {rmse_a3:.4f}\n")

    # --- Conclusion ---
    print("\n--- Ablation Study Summary ---")
    base_rmse = results['Base Case']
    most_impactful_change = ''
    largest_abs_delta = 0
    impact_type = '' # 'beneficial' or 'detrimental'

    for name, rmse in results.items():
        if name == 'Base Case':
            continue
        delta = rmse - base_rmse
        print(f"  {name}: RMSE = {rmse:.4f}, Delta from Base = {delta:+.4f}")
        if abs(delta) > largest_abs_delta:
            largest_abs_delta = abs(delta)
            most_impactful_change = name
            if delta < 0:
                impact_type = 'beneficial'
            else:
                impact_type = 'detrimental'

    if most_impactful_change:
        print(f"\nConclusion: The most impactful change was '{most_impactful_change}', which was {impact_type} with an absolute RMSE delta of {largest_abs_delta:.4f}.")
    else:
        print("\nConclusion: No measurable impact observed from any ablations.")

# Run the ablation study
if __name__ == "__main__":
    run_ablation_study()
    pd.options.mode.chained_assignment = 'warn' # Reset to default
