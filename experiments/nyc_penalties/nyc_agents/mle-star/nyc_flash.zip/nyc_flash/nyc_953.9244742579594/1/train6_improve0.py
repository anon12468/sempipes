
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category. Handles NaN values gracefully.
    """
    initial_memory = df.memory_usage(deep=True).sum() / (1024**2)
    for col in df.columns:
        if df[col].dtype == 'object':
            num_unique_values = df[col].nunique(dropna=False) # Count unique, including NaN
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            # and there's more than one unique value (otherwise it's constant or all NaNs)
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
        elif pd.api.types.is_integer_dtype(df[col]):
            if df[col].min() >= np.iinfo(np.int8).min and df[col].max() <= np.iinfo(np.int8).max:
                df[col] = df[col].astype(np.int8)
            elif df[col].min() >= np.iinfo(np.int16).min and df[col].max() <= np.iinfo(np.int16).max:
                df[col] = df[col].astype(np.int16)
            elif df[col].min() >= np.iinfo(np.int32).min and df[col].max() <= np.iinfo(np.int32).max:
                df[col] = df[col].astype(np.int32)
        elif pd.api.types.is_float_dtype(df[col]):
            # Downcast float only if no NaNs or if NaNs can be handled by the smaller float type
            # CatBoost handles NaNs in numerical features, so we can downcast if possible.
            # Avoids issues with min/max on all-NaN series
            if not df[col].isnull().all():
                if df[col].min() >= np.finfo(np.float16).min and df[col].max() <= np.finfo(np.float16).max:
                    df[col] = df[col].astype(np.float16)
                elif df[col].min() >= np.finfo(np.float32).min and df[col].max() <= np.finfo(np.float32).max:
                    df[col] = df[col].astype(np.float32)
    final_memory = df.memory_usage(deep=True).sum() / (1024**2)
    return df


def load_and_preprocess_data(train_path, test_path=None):
    """
    Loads, preprocesses, and merges data from various sources.
    Handles memory efficiency by selective column loading, aggregation, and garbage collection.
    Fixes: Fills NaN values in categorical features with 'UNKNOWN_CATEGORY' to prevent CatBoost errors.
    """
    print("Loading and preprocessing data...")

    # --- Load Core Data ---
    # Load training data
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)
    print(f"Initial train_df loaded. Shape: {train_df_raw.shape}, Memory: {train_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Load test data if provided
    test_df_raw = None
    if test_path:
        test_df_raw = pd.read_csv(test_path)
        test_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
        # Create a flag for pure prediction rows where violation_count is NaN
        test_df_raw['is_pure_prediction'] = test_df_raw['violation_count'].isna()
        test_df_raw = downcast_dtypes(test_df_raw)
        print(f"Test_df loaded. Shape: {test_df_raw.shape}, Memory: {test_df_raw.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Combine unique street_name and violation_description pairs from train and test
    # for consistent feature engineering.
    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_keys_test = pd.DataFrame()
    if test_df_raw is not None:
        combined_keys_test = test_df_raw[['street_name', 'violation_description']].drop_duplicates()

    combined_df = pd.concat([combined_keys_train, combined_keys_test], ignore_index=True).drop_duplicates().reset_index(drop=True)
    combined_df = downcast_dtypes(combined_df) # Downcast again after concat
    del combined_keys_train, combined_keys_test # Free memory
    gc.collect()
    print(f"Combined unique (street, violation) pairs for feature engineering. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # --- Feature Engineering and Augmentation ---

    # Basic features from core data
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # Augmentation 1: nyc_street_data.csv
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        print(f"Loading {street_data_path}...")
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
            print(f"Merged with street_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading or merging {street_data_path}: {e}. Skipping street data augmentation.")
    else:
        print(f"Warning: {street_data_path} not found. Skipping street data augmentation.")

    # Augmentation 2: nyc_violation_codes.csv
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        print(f"Loading {violation_codes_path}...")
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
            print(f"Merged with violation_codes. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
        except Exception as e:
            print(f"Error loading or merging {violation_codes_path}: {e}. Skipping violation codes augmentation.")
    else:
        print(f"Warning: {violation_codes_path} not found. Skipping violation codes augmentation.")

    # Augmentation 3: nyc_census_data.csv (Hypothetical)
    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        print(f"Loading {census_data_path}...")
        if 'borough' in combined_df.columns:
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]

                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
                    print(f"Merged with census_data. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
                else:
                    print(f"Warning: Missing one or more expected columns ({relevant_census_cols}) in {census_data_path}. Skipping census data augmentation.")
            except Exception as e:
                print(f"Error loading or merging {census_data_path}: {e}. Skipping census data augmentation.")
        else:
            print("Warning: Borough information not available in combined_df to merge census data. Skipping.")
    else:
        print(f"Warning: {census_data_path} not found. Skipping census data augmentation.")

    # --- New Feature Engineering (Frequency Encoding & Numerical Interactions) ---
    print("Generating new engineered features...")

    # Frequency Encoding
    print("  Applying frequency encoding...")
    street_name_counts = combined_df['street_name'].value_counts(normalize=True)
    combined_df['street_name_freq'] = combined_df['street_name'].map(street_name_counts).astype(np.float32)
    violation_desc_counts = combined_df['violation_description'].value_counts(normalize=True)
    combined_df['violation_desc_freq'] = combined_df['violation_description'].map(violation_desc_counts).astype(np.float32)
    gc.collect()
    print(f"  Frequency encoding complete. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")

    # Numerical Interaction Features (aggregations based on categorical features)
    numerical_cols_for_interaction = [
        'street_name_len', 'violation_desc_len',
        'street_length', 'num_lanes',
        'fine_amount', 'points',
        'population_density', 'avg_income',
        'street_name_freq', 'violation_desc_freq'
    ]
    numerical_cols_for_interaction = [col for col in numerical_cols_for_interaction if col in combined_df.columns]

    if 'borough' in combined_df.columns and len(numerical_cols_for_interaction) > 0:
        print("  Generating numerical interaction features (aggregations by borough)...")
        for num_col in numerical_cols_for_interaction:
            # Calculate mean per borough
            borough_mean = combined_df.groupby('borough')[num_col].transform('mean')
            combined_df[f'{num_col}_per_borough_mean'] = borough_mean.astype(np.float32)
            # Calculate std dev per borough (handle cases where std dev might be NaN for single-item groups)
            borough_std = combined_df.groupby('borough')[num_col].transform('std')
            combined_df[f'{num_col}_per_borough_std'] = borough_std.astype(np.float32).fillna(0)
        gc.collect()
        print(f"  Numerical interaction features complete. Shape: {combined_df.shape}, Memory: {combined_df.memory_usage(deep=True).sum() / (1024**2):.2f} MB")
    else:
        print("  Skipping numerical interaction features due to missing 'borough' or numerical columns.")

    # Split back into train and test processed dataframes
    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    train_processed_df = train_processed_df.loc[:,~train_processed_df.columns.duplicated()] # Safeguard against duplicate columns
    del train_df_raw
    gc.collect()

    test_processed_df = None
    if test_df_raw is not None:
        test_processed_df = pd.merge(test_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
        test_processed_df = test_processed_df.loc[:,~test_processed_df.columns.duplicated()] # Safeguard
        del test_df_raw
        gc.collect()

    print(f"Final train_processed_df shape: {train_processed_df.shape}")
    if test_processed_df is not None:
        print(f"Final test_processed_df shape: {test_processed_df.shape}")

    # Identify categorical features for CatBoost
    # And handle NaNs in them by filling with a placeholder string.
    # CatBoost requires categorical features to be integer or string type,
    # so NaN (which is float) is not directly compatible without conversion.
    categorical_features = []
    # Columns to ignore from being considered as features
    ignore_cols = ['violation_count', 'is_pure_prediction']

    for col in train_processed_df.columns:
        if col not in ignore_cols and train_processed_df[col].dtype in ['object', 'category']:
            categorical_features.append(col)

            # Fill NaN values with a placeholder string and ensure category dtype
            if train_processed_df[col].isnull().any():
                train_processed_df[col] = train_processed_df[col].fillna('UNKNOWN_CATEGORY').astype('category')
            else:
                # Ensure it's category type even if no NaNs
                train_processed_df[col] = train_processed_df[col].astype('category')

            if test_processed_df is not None:
                if test_processed_df[col].isnull().any():
                    test_processed_df[col] = test_processed_df[col].fillna('UNKNOWN_CATEGORY').astype('category')
                else:
                    test_processed_df[col] = test_processed_df[col].astype('category')

    print(f"Categorical features identified for CatBoost: {categorical_features}")

    return train_processed_df, test_processed_df, categorical_features


def train_and_predict(train_df, test_df, categorical_features):
    """
    Trains a CatBoost Regressor model and generates predictions.
    Reports RMSE for validation and test sets (if ground truth available).
    """
    print("Training CatBoost model...")

    # Define features (X) and target (y)
    # Filter out target and test-specific flag from features
    features = [col for col in train_df.columns if col not in ['violation_count', 'is_pure_prediction']]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    # Split training data for validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    print(f"Training data split: X_train={X_train.shape}, X_val={X_val.shape}")

    # Convert categorical feature names to their indices for CatBoost
    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]
    print(f"Categorical feature indices for CatBoost: {cat_features_indices}")

    # Initialize CatBoost Regressor with OOM-conscious parameters
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6,
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=100,
        early_stopping_rounds=50,
        # Further memory optimizations (uncomment if OOM persists)
        # grow_policy='Lossguide',
        # max_leaves=31,
        # devices='0' # For GPU, if available and configured
    )

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                  # Use 'skip' for unseen categories if 'UNKNOWN_CATEGORY' filling wasn't used,
                  # but explicit filling is safer.
                  # train_dir is for saving logs, useful for debugging OOM
                  # train_dir='catboost_info'
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        print("This might indicate an issue with data format or extreme memory pressure even with optimized parameters.")
        raise

    # Validate on internal validation set
    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    print(f"Development Validation RMSE: {val_rmse}")

    # Generate predictions for the test_df if provided
    submission_df = None
    if test_df is not None:
        print("Generating predictions for test data...")
        X_test = test_df[features]

        test_preds = model.predict(X_test)
        # Ensure predictions are non-negative
        test_preds[test_preds < 0] = 0

        # Create submission dataframe
        submission_df = test_df[['street_name', 'violation_description']].copy()
        submission_df['predicted_count'] = test_preds

        # Report RMSE if ground truth is available in test_df
        if 'violation_count' in test_df.columns and not test_df['is_pure_prediction'].all():
            ground_truth_test_df = test_df[~test_df['is_pure_prediction']]
            # Ensure ground_truth_preds aligns with ground_truth_test_df rows
            ground_truth_preds_aligned = submission_df[~test_df['is_pure_prediction']]['predicted_count']
            test_rmse = np.sqrt(mean_squared_error(ground_truth_test_df['violation_count'], ground_truth_preds_aligned))
            print(f"RMSE on provided test/evaluation data (with ground truth): {test_rmse}")

        # Report unseen key pairs
        train_keys = set(train_df.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
        test_keys = set(test_df.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
        unseen_keys_count = len(test_keys - train_keys)
        print(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {unseen_keys_count}")
        print("Unseen keys are handled by filling new categorical levels with 'UNKNOWN_CATEGORY' placeholder.")

    return submission_df, val_rmse

def main():
    """
    Main function to parse arguments, orchestrate data loading, training, and prediction.
    """
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional path to the 2023 test/evaluation data CSV. '
                             'If provided, predictions will be generated and RMSE reported if ground truth exists.')
    args = parser.parse_args()

    train_df, test_df, categorical_features = load_and_preprocess_data(args.train_path, args.test_path)
    submission_df, final_validation_score = train_and_predict(train_df, test_df, categorical_features)

    if submission_df is not None:
        submission_df.to_csv('submission.csv', index=False)
        print("Submission file 'submission.csv' generated successfully.")

    # Always print the final validation score
    print(f"Final Validation Performance: {final_validation_score}")

if __name__ == "__main__":
    main()
