
import argparse
import pandas as pd
import numpy as np
import os
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import sys

# Install necessary packages if not already installed.
# This block is added as a common fix for "module not found" errors,
# which are often the cause of generic non-zero exit codes.
try:
    import pandas
    import numpy
    import sklearn
    import catboost
    import argparse
except ImportError:
    print("One or more required modules not found. Attempting to install them now...", file=sys.stderr)
    try:
        import subprocess
        # Use a more targeted install to ensure only missing packages are installed
        required_packages = ["pandas", "numpy", "scikit-learn", "catboost"]
        installed_packages = [pkg.key for pkg in pkg_resources.working_set]
        missing_packages = [pkg for pkg in required_packages if pkg not in installed_packages]

        if missing_packages:
            subprocess.check_call([sys.executable, "-m", "pip", "install", *missing_packages])
            print("Missing modules installed successfully.", file=sys.stderr)
            # Re-import after installation
            import pandas
            import numpy
            import sklearn
            import catboost
            import argparse
        else:
            print("All required modules are already installed.", file=sys.stderr)

    except Exception as e:
        print(f"Failed to install modules: {e}", file=sys.stderr)
        # If installation fails, the script cannot proceed.
        # We let the program continue and fail later due to missing imports if they couldn't be installed.

# Import pkg_resources for checking installed packages
try:
    import pkg_resources
except ImportError:
    # If pkg_resources is not available, we can't check efficiently,
    # so we'll just try to install everything.
    pass


def parse_args():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument(
        "--train-path",
        type=str,
        default="./input/violations_per_street_2022.csv",
        help="Path to the 2022 training data CSV.",
    )
    parser.add_argument(
        "--test-path",
        type=str,
        default=None,
        help="Optional path to the test/evaluation data CSV for prediction.",
    )
    return parser.parse_args()

def load_data(file_path):
    """Loads a CSV file and handles potential FileNotFoundError."""
    if not os.path.exists(file_path):
        print(f"Error: File not found at {file_path}", file=sys.stderr)
        return pd.DataFrame()
    try:
        df = pd.read_csv(file_path)
        print(f"Successfully loaded {file_path} with {len(df)} rows.", file=sys.stderr)
        return df
    except Exception as e:
        print(f"Error loading {file_path}: {e}", file=sys.stderr)
        return pd.DataFrame()

def preprocess_data(df, street_data, violation_codes):
    """
    Performs feature engineering and data cleaning.
    Assumes 'Street Name', 'Violation Description', 'violation_count' are present in df
    or will be provided by the caller for test data.
    """
    if df.empty:
        return df

    # Rename columns for consistency
    df = df.rename(columns={
        'Street Name': 'street_name',
        'Violation Description': 'violation_description',
        'violation_count': 'violation_count' # This might not exist in test data, handled later
    })

    # Basic cleaning
    df['street_name'] = df['street_name'].fillna('UNKNOWN').astype(str).str.strip().str.upper()
    df['violation_description'] = df['violation_description'].fillna('UNKNOWN').astype(str).str.strip().str.upper()

    # Join with street data (assuming 'Street Name' in street_data matches 'street_name' in df)
    if not street_data.empty:
        street_data_processed = street_data.copy().rename(columns={'Street Name': 'street_name'})
        street_data_processed['street_name'] = street_data_processed['street_name'].astype(str).str.strip().str.upper()
        
        # Identify features to merge, excluding 'street_name' and columns already in df
        street_features_to_add = [
            col for col in street_data_processed.columns
            if col != 'street_name' and col not in df.columns
        ]
        if street_features_to_add:
            df = pd.merge(df, street_data_processed[['street_name'] + street_features_to_add], on='street_name', how='left')
            print(f"Merged with street data. New shape: {df.shape}", file=sys.stderr)
        else:
            print("No new features to merge from street_data.", file=sys.stderr)
    else:
        print("Street data is empty, skipping merge.", file=sys.stderr)

    # Join with violation codes (assuming 'Violation Description' in violation_codes matches 'violation_description' in df)
    if not violation_codes.empty:
        violation_codes_processed = violation_codes.copy().rename(columns={'Violation Description': 'violation_description'})
        violation_codes_processed['violation_description'] = violation_codes_processed['violation_description'].astype(str).str.strip().str.upper()

        # Identify features to merge, excluding 'violation_description' and columns already in df
        violation_features_to_add = [
            col for col in violation_codes_processed.columns
            if col != 'violation_description' and col not in df.columns
        ]
        if violation_features_to_add:
            df = pd.merge(df, violation_codes_processed[['violation_description'] + violation_features_to_add], on='violation_description', how='left')
            print(f"Merged with violation codes. New shape: {df.shape}", file=sys.stderr)
        else:
            print("No new features to merge from violation_codes.", file=sys.stderr)
    else:
        print("Violation codes data is empty, skipping merge.", file=sys.stderr)

    # Identify categorical features for CatBoost
    # All object columns are treated as categorical, plus explicit identifiers
    categorical_cols = [col for col in df.columns if df[col].dtype == 'object']
    
    # Convert categorical features to 'category' dtype and handle NaNs
    for col in categorical_cols:
        # Fill NaN in categorical features with a string placeholder before converting to category
        df[col] = df[col].fillna('MISSING_CATEGORY').astype('category')
        
    # Handle any remaining NaN in numerical features (e.g., from joins)
    numerical_features = df.select_dtypes(include=np.number).columns.tolist()
    if 'violation_count' in numerical_features:
        numerical_features.remove('violation_count')
    for col in numerical_features:
        df[col] = df[col].fillna(df[col].median() if not df[col].isnull().all() else 0) # Impute with median or 0 if all are NaN

    return df


def main():
    args = parse_args()

    # Define base input directory
    input_dir = "./input"

    # --- Load Data ---
    train_df_2022 = load_data(args.train_path)
    if train_df_2022.empty:
        print("Training data is empty. Exiting.", file=sys.stderr)
        return

    street_data = load_data(os.path.join(input_dir, "nyc_street_data.csv"))
    violation_codes = load_data(os.path.join(input_dir, "nyc_violation_codes.csv"))

    # --- Preprocess Training Data ---
    # Store original keys before preprocessing, useful for later joining predictions if needed (though not directly for this task)
    train_df_2022['original_street_name'] = train_df_2022['Street Name'].astype(str)
    train_df_2022['original_violation_description'] = train_df_2022['Violation Description'].astype(str)

    processed_train_df = preprocess_data(train_df_2022.copy(), street_data, violation_codes)

    # Ensure required columns are present after preprocessing
    if 'street_name' not in processed_train_df.columns or 'violation_description' not in processed_train_df.columns:
        print("Error: 'street_name' or 'violation_description' columns missing after preprocessing.", file=sys.stderr)
        return
    if 'violation_count' not in processed_train_df.columns:
        print("Error: 'violation_count' column missing in training data after preprocessing.", file=sys.stderr)
        return

    # --- Feature and Target Definition ---
    # Features will include 'street_name', 'violation_description' and any merged features
    features_to_drop = ['violation_count', 'original_street_name', 'original_violation_description']
    X = processed_train_df.drop(columns=[col for col in features_to_drop if col in processed_train_df.columns])
    y = processed_train_df['violation_count']

    # Identify categorical features for CatBoost
    cat_features_names = [col for col in X.columns if X[col].dtype == 'category']
    
    # --- Train/Validation Split ---
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    print(f"Training data shape: {X_train.shape}, Validation data shape: {X_val.shape}", file=sys.stderr)

    # --- Model Training ---
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=8,
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0,
        early_stopping_rounds=50,
        cat_features=cat_features_names, # Use column names for CatBoost
        allow_writing_files=False
    )

    print("Starting model training...", file=sys.stderr)
    model.fit(
        X_train, y_train,
        eval_set=(X_val, y_val),
        verbose=False
    )
    print("Model training complete.", file=sys.stderr)

    # --- Validation Performance ---
    val_predictions = model.predict(X_val)
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions
    validation_rmse = np.sqrt(mean_squared_error(y_val, val_predictions))
    print(f"Final Validation Performance: {validation_rmse}", file=sys.stdout)

    # --- Test Prediction ---
    if args.test_path:
        print(f"\nProcessing test file: {args.test_path}", file=sys.stderr)
        test_df = load_data(args.test_path)
        if test_df.empty:
            print("Test data is empty. Skipping prediction.", file=sys.stderr)
        else:
            # Check if 'violation_count' exists in test_df for ground truth comparison
            test_has_ground_truth = 'violation_count' in test_df.columns
            
            # Store original keys for submission file
            original_test_submission_df = test_df[['Street Name', 'Violation Description']].copy()
            original_test_submission_df.columns = ['street_name', 'violation_type']

            processed_test_df = preprocess_data(test_df.copy(), street_data, violation_codes)

            # Align columns and categories between training and test sets
            X_test_aligned = pd.DataFrame(columns=X.columns) # Create an empty DataFrame with train columns
            
            # Populate X_test_aligned with data from processed_test_df
            for col in X.columns:
                if col in processed_test_df.columns:
                    if X[col].dtype == 'category':
                        # Ensure test set category column matches train set categories
                        # Add any new categories from test to train's categories first (temporarily for alignment)
                        # This avoids errors if test has categories not seen in train
                        test_categories = processed_test_df[col].cat.categories
                        train_categories = X[col].cat.categories
                        new_categories_in_test = test_categories.difference(train_categories)
                        
                        # Create a unified category dtype for conversion
                        unified_categories = pd.CategoricalDtype(categories=list(train_categories) + list(new_categories_in_test), ordered=False)
                        
                        X_test_aligned[col] = processed_test_df[col].astype(unified_categories)
                        # Fill any categories from test that are not in train with 'MISSING_CATEGORY'
                        X_test_aligned[col] = X_test_aligned[col].cat.add_categories('MISSING_CATEGORY').fillna('MISSING_CATEGORY')

                    else:
                        X_test_aligned[col] = processed_test_df[col]
                else:
                    # Column missing in test set; add it with a default value
                    if X[col].dtype == 'category':
                        X_test_aligned[col] = 'MISSING_CATEGORY'
                        X_test_aligned[col] = X_test_aligned[col].astype(pd.CategoricalDtype(categories=X[col].cat.categories.tolist() + ['MISSING_CATEGORY'], ordered=False))
                    else:
                        X_test_aligned[col] = 0 # Default for numerical features

            # Ensure the final X_test_aligned has the same category types as X
            for col in X.columns:
                if X[col].dtype == 'category':
                    # Ensure all categories in X[col] are present in X_test_aligned[col]
                    # This ensures CatBoost sees the same category mapping.
                    current_test_cats = X_test_aligned[col].cat.categories
                    train_cats = X[col].cat.categories
                    missing_in_test_cats = train_cats.difference(current_test_cats)
                    if not missing_in_test_cats.empty:
                        X_test_aligned[col] = X_test_aligned[col].cat.add_categories(list(missing_in_test_cats))
                    # Finally, reorder categories to match the training set
                    X_test_aligned[col] = X_test_aligned[col].cat.reorder_categories(train_cats.tolist(), ordered=False)


            # Track unseen key pairs
            train_key_pairs = set(X.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
            test_key_pairs = set(processed_test_df.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
            unseen_key_pairs_count = len(test_key_pairs - train_key_pairs)
            print(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_key_pairs_count}", file=sys.stderr)

            # Make predictions
            test_predictions = model.predict(X_test_aligned)
            test_predictions[test_predictions < 0] = 0 # Clip negative predictions

            submission_df = original_test_submission_df.copy()
            submission_df['predicted_count'] = test_predictions

            # Save submission file
            submission_filename = "submission.csv"
            submission_df.to_csv(submission_filename, index=False)
            print(f"Predictions saved to {submission_filename}", file=sys.stderr)

            if test_has_ground_truth:
                ground_truth = test_df['violation_count'] # Get original ground truth
                test_rmse = np.sqrt(mean_squared_error(ground_truth, test_predictions))
                print(f"Test RMSE (with ground truth): {test_rmse}", file=sys.stderr)
            else:
                print("Test file does not contain 'violation_count'. Skipping test RMSE calculation.", file=sys.stderr)

    else:
        print("No test-path provided. Skipping test prediction.", file=sys.stderr)

if __name__ == "__main__":
    main()

