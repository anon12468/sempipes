
import pandas as pd
import numpy as np
import os
import argparse
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor

def rmse(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))

def load_and_preprocess_data(train_path, data_dir):
    """
    Loads and preprocesses the 2022 violations data and augments it with external datasets.
    """
    print(f"Loading training data from {train_path}")
    df_2022 = pd.read_csv(train_path)
    df_2022 = df_2022.rename(columns={
        'Street Name': 'street_name',
        'Violation Description': 'violation_type',
        'violation_count': 'violation_count'
    })

    # Convert to category type to save memory and for CatBoost
    df_2022['street_name'] = df_2022['street_name'].astype('category')
    df_2022['violation_type'] = df_2022['violation_type'].astype('category')
    # Downcast violation_count to save memory, handling potential NaNs
    df_2022['violation_count'] = pd.to_numeric(df_2022['violation_count'], errors='coerce').fillna(0).astype(np.int32)

    df_2022_augmented = df_2022.copy()

    # Augment with NYC Street Metadata
    try:
        df_streets_metadata = pd.read_csv(os.path.join(data_dir, 'nyc_streets_metadata.csv'))
        df_streets_metadata = df_streets_metadata.rename(columns={'Street': 'street_name'})

        # Reduced set of street_features to mitigate memory issues and select relevant ones.
        # Original list was very large. Keeping 'ZipCode' and 'assesstot' as potentially
        # most useful numerical features, and 'street_name' for the merge key.
        core_street_features = ['street_name', 'ZipCode', 'assesstot']

        # Filter to only relevant street features that are present in the metadata file
        street_features_to_use = [f for f in core_street_features if f in df_streets_metadata.columns]
        
        # Select only the features identified and create a copy to avoid SettingWithCopyWarning
        df_streets_augmented_temp = df_streets_metadata[street_features_to_use].copy()
        
        # Handle potential duplicates in street_name in metadata by taking the first unique entry.
        # This is crucial to prevent combinatorial explosion during the merge operation and thus OOM.
        df_streets_augmented_temp = df_streets_augmented_temp.drop_duplicates(subset=['street_name'], keep='first')

        # Ensure numerical columns are handled, coerced, and downcasted for memory efficiency.
        for col in df_streets_augmented_temp.columns:
            if col != 'street_name': # Do not convert 'street_name' which is the key
                # Convert to numeric, coercing errors to NaN
                df_streets_augmented_temp[col] = pd.to_numeric(df_streets_augmented_temp[col], errors='coerce')
                # Downcast if the data type allows
                if df_streets_augmented_temp[col].dtype == 'float64':
                    df_streets_augmented_temp[col] = df_streets_augmented_temp[col].astype(np.float32)
                elif df_streets_augmented_temp[col].dtype == 'int64':
                    # Only downcast if max value fits in int32
                    if df_streets_augmented_temp[col].max() <= np.iinfo(np.int32).max and df_streets_augmented_temp[col].min() >= np.iinfo(np.int32).min:
                        df_streets_augmented_temp[col] = df_streets_augmented_temp[col].astype(np.int32)

        # Fill NaN values that might result from coercion or missing metadata.
        # Filling with 0 is a simple strategy; more sophisticated imputation (e.g., mean/median)
        # could be considered but increases complexity.
        df_streets_augmented_temp = df_streets_augmented_temp.fillna(0)

        # Perform the merge. By processing df_streets_augmented_temp first, we ensure it's lean.
        df_2022_augmented = pd.merge(
            df_2022_augmented,
            df_streets_augmented_temp, # Use the processed df_streets_augmented_temp directly
            on='street_name',
            how='left'
        )
        print("Augmented with street metadata.")
    except FileNotFoundError:
        print("nyc_streets_metadata.csv not found, proceeding without street metadata augmentation.")
    except Exception as e:
        print(f"Error augmenting with street metadata: {e}, proceeding without it.")
        # If an error occurs, ensure that features from this table are not included in the model
        for f in street_features_to_use:
            if f != 'street_name' and f in df_2022_augmented.columns:
                df_2022_augmented = df_2022_augmented.drop(columns=[f])


    # Augment with NYC Parking Zones
    try:
        df_parking_zones = pd.read_csv(os.path.join(data_dir, 'nyc_parking_zones.csv'))
        df_parking_zones = df_parking_zones.rename(columns={'Street': 'street_name'})

        # Aggregate parking zone information per street_name to prevent combinatorial explosion.
        # Counting unique parking zones per street provides a single numeric feature.
        parking_zone_features = df_parking_zones.groupby('street_name')['parking_zone'].nunique().reset_index()
        parking_zone_features.rename(columns={'parking_zone': 'num_parking_zones'}, inplace=True)
        
        # Downcast num_parking_zones for memory efficiency
        parking_zone_features['num_parking_zones'] = parking_zone_features['num_parking_zones'].astype(np.int16)

        df_2022_augmented = pd.merge(
            df_2022_augmented,
            parking_zone_features,
            on='street_name',
            how='left'
        )
        # Fill NaN for streets with no parking zone info (i.e., no entry in nyc_parking_zones) with 0.
        df_2022_augmented['num_parking_zones'] = df_2022_augmented['num_parking_zones'].fillna(0).astype(np.int16)
        print("Augmented with parking zone data.")
    except FileNotFoundError:
        print("nyc_parking_zones.csv not found, proceeding without parking zone augmentation.")
    except Exception as e:
        print(f"Error augmenting with parking zone data: {e}, proceeding without it.")
        # If an error occurs, ensure the feature is not included
        if 'num_parking_zones' in df_2022_augmented.columns:
            df_2022_augmented = df_2022_augmented.drop(columns=['num_parking_zones'])


    # Note: nyc_holidays.csv and nyc_weather.csv are not directly usable with the provided
    # aggregate 2022 data as they require date information (e.g., daily counts),
    # which is not present in violations_per_street_2022.csv schema.
    # Therefore, no augmentation is performed using these files.

    return df_2022_augmented

def train_model(df_train_full):
    """
    Trains a CatBoostRegressor model and evaluates it using a validation set.
    """
    print("Splitting data into training and validation sets.")
    
    X = df_train_full.drop(columns=['violation_count'])
    y = df_train_full['violation_count']

    # Using a simple random split for validation from the 2022 data.
    # For robust validation on future data, a time-based split or grouped split
    # could be more appropriate, but with aggregated yearly data, this is a reasonable start.
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    # Dynamically identify features for training based on what was successfully augmented
    features = ['street_name', 'violation_type']
    if 'ZipCode' in X_train.columns:
        features.append('ZipCode')
    if 'assesstot' in X_train.columns:
        features.append('assesstot')
    if 'num_parking_zones' in X_train.columns:
        features.append('num_parking_zones')

    X_train_processed = X_train[features]
    X_val_processed = X_val[features]

    # Identify categorical features for CatBoost. CatBoost handles 'category' dtype directly.
    categorical_features_indices = [i for i, col in enumerate(features) if X_train_processed[col].dtype.name in ['category', 'object']]
    
    print(f"Training with features: {features}")
    print(f"Categorical features indices for CatBoost: {categorical_features_indices}")

    model = CatBoostRegressor(
        iterations=1000, # Increased iterations for better convergence
        learning_rate=0.05,
        depth=8, # Slightly reduced depth from 10 to 8 to mitigate overfitting and memory
        loss_function='RMSE',
        verbose=0, # Disable verbose during fit, only show early stopping
        cat_features=categorical_features_indices,
        random_seed=42,
        early_stopping_rounds=100, # Early stopping for robustness and to prevent overfitting
        l2_leaf_reg=3.0, # L2 regularization to help prevent overfitting
        thread_count=-1 # Use all available CPU cores
    )

    model.fit(X_train_processed, y_train, eval_set=(X_val_processed, y_val), 
              early_stopping_rounds=100, verbose=200) # verbose every 200 iterations for evaluation progress

    val_preds = model.predict(X_val_processed)
    val_rmse = rmse(y_val, val_preds)
    print(f"Final Validation Performance: {val_rmse}")

    return model, features

def make_predictions(model, features, df_test, df_train_full):
    """
    Generates predictions for the test dataset.
    """
    print("Preparing test data for prediction.")
    # Ensure test data has the same columns and types as training data
    df_test_processed = df_test.copy()
    
    # Rename columns in test data to match training data
    df_test_processed = df_test_processed.rename(columns={
        'Street Name': 'street_name',
        'Violation Description': 'violation_type'
    })

    # Handle categorical features (street_name, violation_type)
    for col in ['street_name', 'violation_type']:
        if col in df_test_processed.columns:
            # Convert to string first to handle any potential non-string types, then to category
            df_test_processed[col] = df_test_processed[col].astype(str).astype('category')
            # CatBoost internally handles unseen categories by mapping them to a default value.
            # No explicit `add_categories` needed here.

    # For numerical features (from augmentation), ensure they are present and filled correctly
    for col in features:
        if col not in ['street_name', 'violation_type']: # These are handled as categories
            if col not in df_test_processed.columns:
                # If an augmented feature is missing in test, fill with 0 (consistent with train fillna)
                df_test_processed[col] = 0
            else:
                df_test_processed[col] = pd.to_numeric(df_test_processed[col], errors='coerce').fillna(0)
                # Downcast if applicable
                if df_test_processed[col].dtype == 'float64':
                    df_test_processed[col] = df_test_processed[col].astype(np.float32)
                elif df_test_processed[col].dtype == 'int64':
                    if df_test_processed[col].max() <= np.iinfo(np.int32).max and df_test_processed[col].min() >= np.iinfo(np.int32).min:
                        df_test_processed[col] = df_test_processed[col].astype(np.int32)
    
    # Ensure the test DataFrame only contains the features the model was trained on
    df_test_processed = df_test_processed[features]

    # Report unseen key pairs in the test set relative to the training set
    train_keys = df_train_full[['street_name', 'violation_type']].drop_duplicates()
    test_keys = df_test_processed[['street_name', 'violation_type']].drop_duplicates()

    merged_keys = pd.merge(test_keys, train_keys, on=['street_name', 'violation_type'], how='left', indicator=True)
    unseen_keys_count = (merged_keys['_merge'] == 'left_only').sum()
    print(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_keys_count}")
    print(f"These unseen pairs are handled by CatBoost's internal mechanism for new categories (if treated as categorical features) or by imputation (for numerical features that might be missing).")

    predictions = model.predict(df_test_processed)
    
    # Ensure predictions are non-negative and round to integer counts
    predictions[predictions < 0] = 0
    predictions = np.round(predictions).astype(np.int32)

    submission_df = pd.DataFrame({
        'street_name': df_test['Street Name'], # Use original column names for output
        'violation_type': df_test['Violation Description'],
        'predicted_count': predictions
    })
    return submission_df

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional: Path to the 2023 test/evaluation data CSV.')
    parser.add_argument('--data-dir', type=str, default='./input',
                        help='Directory containing additional augmentation CSV files.')
    
    args = parser.parse_args()

    # Load and preprocess training data
    df_train_full = load_and_preprocess_data(args.train_path, args.data_dir)
    
    # Train model
    model, features = train_model(df_train_full)

    if args.test_path:
        print(f"\nLoading test data from {args.test_path}")
        df_test = pd.read_csv(args.test_path)
        
        # Make predictions
        submission_df = make_predictions(model, features, df_test, df_train_full)
        
        # Save predictions
        submission_df.to_csv('submission.csv', index=False)
        print("Predictions saved to submission.csv")

        # If 'violation_count' is present in test data, evaluate RMSE
        if 'violation_count' in df_test.columns:
            print("Evaluating RMSE on provided test data.")
            # Ensure true counts are numeric and handle potential NaNs
            y_test_true = pd.to_numeric(df_test['violation_count'], errors='coerce').fillna(0).astype(np.int32)
            y_test_pred = submission_df['predicted_count']
            test_rmse = rmse(y_test_true, y_test_pred)
            print(f"Test Set RMSE: {test_rmse}")
    else:
        print("\nNo test-path provided. Skipping prediction generation.")

if __name__ == '__main__':
    main()
