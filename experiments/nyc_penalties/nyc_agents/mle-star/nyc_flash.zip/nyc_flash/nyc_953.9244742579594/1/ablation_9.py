
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    # initial_memory = df.memory_usage(deep=True).sum() / (1024**2) # Suppress for ablation
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    # final_memory = df.memory_usage(deep=True).sum() / (1024**2) # Suppress for ablation
    return df

def load_and_preprocess_data(train_path):
    """
    Loads, preprocesses, and merges data from various sources.
    Handles memory efficiency by selective column loading, aggregation, and garbage collection.
    For ablation study, it only loads training data and suppresses verbose output.
    """
    # print("Loading and preprocessing data for ablation study...") # Suppress for ablation

    # --- Load Core Data ---
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)
    # print(f"Initial train_df loaded. Shape: {train_df_raw.shape}") # Suppress for ablation

    # Combine unique street_name and violation_description pairs from train
    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    
    combined_df = combined_keys_train.reset_index(drop=True)
    del combined_keys_train
    gc.collect()
    # print(f"Combined unique (street, violation) pairs for feature engineering. Shape: {combined_df.shape}") # Suppress for ablation

    # --- Feature Engineering and Augmentation ---
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
        except Exception as e:
            pass # Suppress detailed error messages for ablation study
    else:
        pass # Suppress warning for ablation study

    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
        except Exception as e:
            pass # Suppress detailed error messages for ablation study
    else:
        pass # Suppress warning for ablation study

    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        if 'borough' in combined_df.columns:
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
            except Exception as e:
                pass # Suppress detailed error messages for ablation study
        else:
            pass # Suppress warning for ablation study
    else:
        pass # Suppress warning for ablation study

    final_features_for_model = list(combined_df.columns)

    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    _all_possible_categorical_cols = [col for col in final_features_for_model if combined_df[col].dtype in ['object', 'category']]
    
    for col in _all_possible_categorical_cols:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].astype(str).fillna('NaN_category_placeholder').astype('category')

    categorical_features_final = [col for col in _all_possible_categorical_cols if col in train_processed_df.columns]

    # print(f"Final train_processed_df shape: {train_processed_df.shape}") # Suppress for ablation
    # print(f"Categorical features identified and NaNs handled: {categorical_features_final}") # Suppress for ablation

    return train_processed_df, categorical_features_final, final_features_for_model


def train_and_evaluate_ablated(train_df, categorical_features, final_features_for_model,
                               subsample_param=0.8, use_best_model_param=True, learning_rate_param=0.03):
    """
    Trains a CatBoost Regressor model with ablated parameters and reports validation RMSE.
    """
    X = train_df[final_features_for_model]
    y = train_df['violation_count']

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    model = CatBoostRegressor(
        iterations=2000,
        learning_rate=learning_rate_param,
        depth=6,
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Suppress CatBoost verbose output for clean ablation
        early_stopping_rounds=50,
        subsample=subsample_param,
        use_best_model=use_best_model_param,
        # thread_count=-1 # Can add this if multi-threading is desired and not limited by environment
    )

    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                  # plot=False # Disable plot for ablation studies
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        raise

    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    return val_rmse

def main_ablation():
    """
    Main function for performing the ablation study.
    """
    train_path = './input/violations_per_street_2022.csv'
    
    print("--- Starting Ablation Study ---")
    train_df, categorical_features, final_features_for_model = load_and_preprocess_data(train_path)

    results = {}

    # Base Case: Current configuration in the provided script
    print("\n--- Running Base Case (subsample=0.8, use_best_model=True, learning_rate=0.03) ---")
    base_rmse = train_and_evaluate_ablated(train_df, categorical_features, final_features_for_model,
                                          subsample_param=0.8, use_best_model_param=True, learning_rate_param=0.03)
    results['Base Case'] = base_rmse
    print(f"Base Case Validation RMSE: {base_rmse:.4f}")

    # Ablation 1: No Subsample (subsample=1.0)
    print("\n--- Running Ablation 1: No Subsample (subsample_param=1.0) ---")
    no_subsample_rmse = train_and_evaluate_ablated(train_df, categorical_features, final_features_for_model,
                                                  subsample_param=1.0, use_best_model_param=True, learning_rate_param=0.03)
    results['No Subsample'] = no_subsample_rmse
    print(f"No Subsample Validation RMSE: {no_subsample_rmse:.4f} (Delta from Base: {no_subsample_rmse - base_rmse:.4f})")

    # Ablation 2: No Use Best Model (use_best_model=False)
    print("\n--- Running Ablation 2: No Use Best Model (use_best_model_param=False) ---")
    no_use_best_model_rmse = train_and_evaluate_ablated(train_df, categorical_features, final_features_for_model,
                                                      subsample_param=0.8, use_best_model_param=False, learning_rate_param=0.03)
    results['No Use Best Model'] = no_use_best_model_rmse
    print(f"No Use Best Model Validation RMSE: {no_use_best_model_rmse:.4f} (Delta from Base: {no_use_best_model_rmse - base_rmse:.4f})")

    # Ablation 3: Changed Learning Rate (from 0.03 to 0.05)
    print("\n--- Running Ablation 3: Changed Learning Rate (learning_rate_param=0.05) ---")
    changed_lr_rmse = train_and_evaluate_ablated(train_df, categorical_features, final_features_for_model,
                                               subsample_param=0.8, use_best_model_param=True, learning_rate_param=0.05)
    results['Changed Learning Rate (0.05)'] = changed_lr_rmse
    print(f"Changed Learning Rate (0.05) Validation RMSE: {changed_lr_rmse:.4f} (Delta from Base: {changed_lr_rmse - base_rmse:.4f})")

    print("\n--- Ablation Study Summary ---")
    for name, rmse in results.items():
        print(f"{name}: RMSE = {rmse:.4f}")

    print("\n--- Conclusion on Most Contributing Part ---")

    max_abs_delta = 0
    most_impactful_component_name = "N/A"
    impact_description = ""

    for name, rmse in results.items():
        if name == 'Base Case':
            continue
        delta = rmse - base_rmse
        abs_delta = abs(delta)

        if abs_delta > max_abs_delta:
            max_abs_delta = abs_delta
            most_impactful_component_name = name
            if delta > 0: # Current change made performance worse (higher RMSE)
                impact_description = f"The Base Case setting for '{name}' was beneficial. Changing it (to '{name}' setting) *worsened* performance (increased RMSE by {delta:.4f})."
            else: # delta < 0, Current change improved performance (lower RMSE)
                impact_description = f"The Base Case setting for '{name}' was suboptimal. Changing it (to '{name}' setting) *improved* performance (decreased RMSE by {abs(delta):.4f})."
    
    if most_impactful_component_name == "N/A":
        print("No significant impact observed from any ablation.")
    else:
        print(f"The most impactful component/parameter modification observed was related to: **{most_impactful_component_name}**.")
        print(impact_description)

if __name__ == "__main__":
    main_ablation()
