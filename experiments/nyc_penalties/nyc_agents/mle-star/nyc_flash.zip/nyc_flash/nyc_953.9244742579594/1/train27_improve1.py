
import pandas as pd
import numpy as np
import argparse
import os
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import logging

# Configure logging for better visibility of potential issues
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def rmse(y_true, y_pred):
    """Calculates the Root Mean Squared Error."""
    return np.sqrt(mean_squared_error(y_true, y_pred))

class TargetEncoder:
    """
    A robust target encoder for categorical features.
    Handles NaN values and prevents data leakage using cross-validation.
    Applies smoothing and uses global mean for unseen categories.
    """
    def __init__(self, cols, smoothing=1.0, min_samples_leaf=1):
        self.cols = cols
        self.smoothing = smoothing
        self.min_samples_leaf = min_samples_leaf
        self.global_mean = None
        self.mapping = {} # Stores mappings for full dataset after fit_transform

    def fit(self, X, y):
        """
        Fits the target encoder on the full dataset to create a mapping for transformation.
        This is typically called after cross-validated fit_transform to prepare for new data.
        """
        self.global_mean = y.mean()
        for col in self.cols:
            temp_df = pd.DataFrame({'col': X[col], 'target': y})
            agg = temp_df.groupby('col')['target'].agg(['count', 'mean'])
            counts = agg['count']
            means = agg['mean']

            # Apply smoothing
            smooth_mean = (counts * means + self.smoothing * self.global_mean) / (counts + self.smoothing)
            
            # Apply min_samples_leaf threshold (replace low-count means with global mean)
            # For target encoding, typically smoothing is enough, but could further refine here.
            # Currently, smoothing itself acts as a form of regularization.
            self.mapping[col] = smooth_mean.to_dict()

    def transform(self, X):
        """
        Transforms the input DataFrame using the learned mappings.
        Handles unseen categories by filling with the global mean.
        """
        X_encoded = X.copy()
        for col in self.cols:
            feature_name = f'{col}_te'
            if col in self.mapping:
                # Use .get() with global_mean as default for unseen categories during map,
                # then fill any remaining NaNs (e.g., from original NaNs in X[col]) with global_mean.
                encoded_feature = X_encoded[col].map(self.mapping[col])
                # Ensure the Series is numeric (float32) before fillna to avoid TypeError
                X_encoded[feature_name] = encoded_feature.astype(np.float32).fillna(self.global_mean)
            else:
                logging.warning(f"Column {col} not found in target encoder mapping during transform. Filling with global mean.")
                X_encoded[feature_name] = np.full(len(X_encoded), self.global_mean, dtype=np.float32)
        return X_encoded

    def fit_transform(self, X, y, cv_folds=5):
        """
        Performs cross-validated target encoding to prevent data leakage.
        For each fold, encodes the validation set using statistics from the training set.
        """
        X_encoded = X.copy()
        self.global_mean = y.mean()

        for col in self.cols:
            oof_encoded = np.zeros(len(X_encoded), dtype=np.float32)
            kf = KFold(n_splits=cv_folds, shuffle=True, random_state=42)

            for fold, (train_idx, val_idx) in enumerate(kf.split(X_encoded, y)):
                X_train_fold, X_val_fold = X_encoded.iloc[train_idx], X_encoded.iloc[val_idx]
                y_train_fold = y.iloc[train_idx]

                temp_df = pd.DataFrame({'col': X_train_fold[col], 'target': y_train_fold})
                agg = temp_df.groupby('col')['target'].agg(['count', 'mean'])
                counts = agg['count']
                means = agg['mean']

                # Apply smoothing for this fold's mapping
                smooth_mean = (counts * means + self.smoothing * self.global_mean) / (counts + self.smoothing)
                
                fold_mapping = smooth_mean.to_dict()
                
                # Apply the fold's mapping to the validation set
                # Ensure the Series is numeric (float32) before fillna
                encoded_val = X_val_fold[col].map(fold_mapping).astype(np.float32)
                oof_encoded[val_idx] = encoded_val.fillna(self.global_mean).values

            X_encoded[f'{col}_te'] = oof_encoded
            
            # Store the full mapping for prediction on new data (after all OOF folds are done)
            # This is critical for the 'transform' method later.
            self.fit(X, y) 

        return X_encoded

def frequency_encode(df, cols):
    """Applies frequency encoding to specified categorical columns."""
    df_encoded = df.copy()
    for col in cols:
        freq_map = df_encoded[col].value_counts(normalize=True)
        df_encoded[f'{col}_freq'] = df_encoded[col].map(freq_map).astype(np.float32)
    return df_encoded

def main(train_path, test_path=None):
    logging.info("Starting script execution for parking violation prediction.")

    # --- Load Training Data ---
    try:
        train_df = pd.read_csv(train_path)
        logging.info(f"Loaded training data from {train_path}. Shape: {train_df.shape}")
        logging.info(f"Training data columns: {train_df.columns.tolist()}")
    except FileNotFoundError:
        logging.error(f"Training file not found: {train_path}. Please ensure the file exists.")
        return
    except Exception as e:
        logging.error(f"Error loading training data from {train_path}: {e}", exc_info=True)
        return

    # Standardize column names
    train_df.columns = [col.replace(' ', '_').lower() for col in train_df.columns]
    
    # Ensure violation_count is numeric and non-negative
    train_df['violation_count'] = pd.to_numeric(train_df['violation_count'], errors='coerce')
    train_df.dropna(subset=['violation_count'], inplace=True)
    train_df = train_df[train_df['violation_count'] >= 0]
    logging.info(f"Cleaned training data shape: {train_df.shape}")

    # Identify categorical features
    categorical_features = ['street_name', 'violation_description']

    # Handle NaNs in categorical features and convert to 'category' type
    for col in categorical_features:
        if col not in train_df.columns:
            logging.error(f"Required categorical column '{col}' not found in training data.")
            return
        if train_df[col].isnull().any():
            train_df[col] = train_df[col].fillna('UNKNOWN_CATEGORY').astype('category')
        else:
            train_df[col] = train_df[col].astype('category')

    # --- Feature Engineering for Training Data ---
    logging.info("Starting feature engineering for training data.")
    
    # Target Encoding
    target_encoder = TargetEncoder(cols=categorical_features, smoothing=100.0, min_samples_leaf=50) 
    X_train_processed = target_encoder.fit_transform(train_df.drop('violation_count', axis=1), train_df['violation_count'], cv_folds=5)
    
    # Frequency Encoding
    X_train_processed = frequency_encode(X_train_processed, categorical_features)

    y_train = train_df['violation_count']
    
    # Define features to use in the model: original categorical features + engineered features
    model_features = categorical_features + [col for col in X_train_processed.columns if col.endswith(('_te', '_freq'))]
    X_train_final = X_train_processed[model_features].copy() # Use .copy() to avoid SettingWithCopyWarning

    # CatBoost expects categorical features as strings or integers, ensure string representation
    for col in categorical_features:
        X_train_final[col] = X_train_final[col].astype(str)

    # Get indices of categorical features for CatBoost Pool
    cat_features_indices = [X_train_final.columns.get_loc(col) for col in categorical_features]
    
    logging.info(f"Final training features: {X_train_final.columns.tolist()}")

    # --- Model Training (CatBoost with Cross-Validation) ---
    logging.info("Starting CatBoost model training with KFold cross-validation.")
    kf = KFold(n_splits=5, shuffle=True, random_state=42)
    oof_predictions = np.zeros(len(X_train_final))
    models = []
    val_rmses = []

    for fold, (train_idx, val_idx) in enumerate(kf.split(X_train_final, y_train)):
        logging.info(f"Training Fold {fold+1}/{kf.n_splits}...")
        X_train_fold, X_val_fold = X_train_final.iloc[train_idx], X_train_final.iloc[val_idx]
        y_train_fold, y_val_fold = y_train.iloc[train_idx], y_train.iloc[val_idx]

        train_pool = Pool(X_train_fold, y_train_fold, cat_features=cat_features_indices)
        val_pool = Pool(X_val_fold, y_val_fold, cat_features=cat_features_indices)

        model = CatBoostRegressor(
            iterations=1000,
            learning_rate=0.05,
            depth=8,
            loss_function='RMSE',
            eval_metric='RMSE',
            random_seed=42,
            verbose=False, # Set to True for more verbose output during training
            early_stopping_rounds=50,
            allow_writing_files=False, # Prevent CatBoost from writing temp files to disk
            thread_count=-1, # Use all available CPU threads
            # used_ram_limit='16gb' # Uncomment and adjust if OOM errors occur on large datasets
        )
        model.fit(train_pool, eval_set=val_pool, use_best_model=True)
        
        val_preds = model.predict(val_pool)
        oof_predictions[val_idx] = val_preds
        fold_rmse = rmse(y_val_fold, val_preds)
        val_rmses.append(fold_rmse)
        logging.info(f"Fold {fold+1} RMSE: {fold_rmse:.4f}. Best iteration: {model.get_best_iteration()}")
        models.append(model)

    final_validation_score = np.mean(val_rmses)
    # Required output format
    print(f"Final Validation Performance: {final_validation_score:.4f}")
    logging.info(f"Average OOF RMSE across all folds: {final_validation_score:.4f}")

    # --- Prediction on Test Data (if provided) ---
    if test_path:
        logging.info("Processing test data for predictions.")
        try:
            test_df = pd.read_csv(test_path)
            logging.info(f"Loaded test data from {test_path}. Shape: {test_df.shape}")
            logging.info(f"Test data columns: {test_df.columns.tolist()}")
        except FileNotFoundError:
            logging.error(f"Test file not found: {test_path}. Skipping prediction generation.")
            return
        except Exception as e:
            logging.error(f"Error loading test data from {test_path}: {e}", exc_info=True)
            return

        # Store original test data for submission output, especially original column names
        original_test_df = test_df.copy()

        # Standardize column names for processing
        test_df.columns = [col.replace(' ', '_').lower() for col in test_df.columns]

        # Handle 'violation_count' if present in test data (for scoring, not as a feature)
        has_ground_truth = 'violation_count' in test_df.columns
        if has_ground_truth:
            y_test_true = pd.to_numeric(test_df['violation_count'], errors='coerce')
            test_df = test_df.drop('violation_count', axis=1)
            logging.info("Test file contains 'violation_count' column; will be used for scoring if valid.")
        else:
            y_test_true = None
            logging.info("Test file does not contain 'violation_count' column; pure prediction mode.")


        # Handle NaNs in categorical features in test data
        for col in categorical_features:
            if col in test_df.columns:
                if test_df[col].isnull().any():
                    test_df[col] = test_df[col].fillna('UNKNOWN_CATEGORY').astype('category')
                else:
                    test_df[col] = test_df[col].astype('category')
            else:
                logging.warning(f"Categorical column '{col}' missing in test data. Adding 'UNKNOWN_CATEGORY' placeholder.")
                test_df[col] = 'UNKNOWN_CATEGORY' # Add missing columns to maintain structure


        # Apply feature engineering to test data
        X_test_processed = target_encoder.transform(test_df) # Use the full-data trained target encoder
        X_test_processed = frequency_encode(X_test_processed, categorical_features)
        
        # Select and reorder features to match training data
        missing_cols_in_test_features = set(model_features) - set(X_test_processed.columns)
        if missing_cols_in_test_features:
            logging.warning(f"Missing features in test data after processing: {missing_cols_in_test_features}. Filling with 0 or appropriate default.")
            for col in missing_cols_in_test_features:
                if col.endswith('_te') or col.endswith('_freq'): # Numeric encoded features
                    X_test_processed[col] = 0.0 # Default to 0 for missing numeric features
                elif col in categorical_features: # Original categorical features
                    X_test_processed[col] = 'UNKNOWN_CATEGORY_MISSING' # Default for missing categorical
        
        X_test_final = X_test_processed[model_features].copy()

        # Ensure categorical features are strings for CatBoost
        for col in categorical_features:
            if col in X_test_final.columns:
                X_test_final[col] = X_test_final[col].astype(str)
            else:
                logging.warning(f"Categorical column '{col}' is still missing or incorrectly typed in X_test_final. Defaulting to 'MISSING'.")
                X_test_final[col] = 'MISSING'


        # Predict with all trained models and average their predictions
        test_predictions = np.zeros(len(X_test_final))
        for i, model in enumerate(models):
            logging.info(f"Predicting with model {i+1}/{len(models)}...")
            test_predictions += model.predict(Pool(X_test_final, cat_features=cat_features_indices))
        test_predictions /= len(models)

        # Ensure non-negative predictions and round
        test_predictions[test_predictions < 0] = 0
        test_predictions = np.round(test_predictions).astype(int) # Round to nearest integer

        # --- Generate Submission File ---
        submission_df = original_test_df[['Street Name', 'Violation Description']].copy()
        submission_df.columns = ['street_name', 'violation_type'] # Rename to specified output format
        submission_df['predicted_count'] = test_predictions
        
        output_filename = 'submission.csv'
        submission_df.to_csv(output_filename, index=False)
        logging.info(f"Submission file generated: {output_filename}")

        # Report RMSE if ground truth was available in the test file
        if has_ground_truth and y_test_true is not None:
            valid_indices = ~y_test_true.isnull()
            if valid_indices.any():
                test_rmse = rmse(y_test_true[valid_indices], test_predictions[valid_indices])
                logging.info(f"RMSE on provided test ground truth: {test_rmse:.4f}")
            else:
                logging.warning("No valid ground truth values found in test data for RMSE calculation.")
        
        # Report how many key pairs in test/eval were unseen in training
        train_keys = set(train_df.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
        test_keys_standardized = set(test_df.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
        unseen_keys_count = len(test_keys_standardized - train_keys)
        logging.info(f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {unseen_keys_count}")
        logging.info(f"These unseen keys are handled by CatBoost's internal categorical feature handling for unseen values and target encoding's global mean fallback during prediction.")

    logging.info("Script execution finished successfully.")

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Predict NYC parking violations for 2023.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help="Path to the 2022 training data CSV (e.g., violations_per_street_2022.csv).")
    parser.add_argument('--test-path', type=str, default=None,
                        help="Optional path to the 2023 test/evaluation data CSV. If provided, predictions will be generated and RMSE reported if ground truth is present.")
    
    args = parser.parse_args()

    # Wrap the main execution in a try-except block to catch any unhandled exceptions
    # This is crucial for debugging silent exits and ensuring errors are logged.
    try:
        main(args.train_path, args.test_path)
    except Exception as e:
        logging.exception("An unhandled error occurred during script execution:")
        # Re-raise the exception to ensure the process exits with a non-zero status
        # and the error is visible in environments that capture stderr.
        raise

