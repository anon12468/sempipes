
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# Helper function to downcast dtypes for memory efficiency
def downcast_dtypes_ablated(df, apply_downcast):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category, or skips if apply_downcast is False.
    """
    if not apply_downcast:
        return df

    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        # Convert object columns to category if they have low cardinality
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Heuristic: convert to category if unique values are less than 50% of total
            # This initial conversion helps with memory but doesn't prevent NaNs from merges
            # The later NaN handling for CatBoost's categorical features will re-process.
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    return df

def load_and_preprocess_data_ablated(train_path, test_path=None, apply_downcast=True, enable_street_borough_interaction=True, use_usecols_external_data=True):
    """
    Loads, preprocesses, and merges data from various sources.
    Handles memory efficiency by selective column loading, aggregation, and garbage collection.
    Ablation points are controlled by flags.
    """

    # --- Load Core Data ---
    # Load training data
    train_df_raw = pd.read_csv(train_path)
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes_ablated(train_df_raw, apply_downcast)

    # Load test data if provided (will be None in this ablation study)
    test_df_raw = None
    if test_path:
        test_df_raw = pd.read_csv(test_path)
        test_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
        test_df_raw['is_pure_prediction'] = test_df_raw['violation_count'].isna()
        test_df_raw = downcast_dtypes_ablated(test_df_raw, apply_downcast)

    # Combine unique street_name and violation_description pairs from train and test
    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_keys_test = pd.DataFrame()
    if test_df_raw is not None:
        combined_keys_test = test_df_raw[['street_name', 'violation_description']].drop_duplicates()

    combined_df = pd.concat([combined_keys_train, combined_keys_test], ignore_index=True).drop_duplicates().reset_index(drop=True)
    del combined_keys_train, combined_keys_test
    gc.collect()

    # --- Feature Engineering and Augmentation ---

    # Basic features from core data
    combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
    combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # Frequency Encoding for street_name and violation_description
    street_name_freq_map = combined_df['street_name'].value_counts().astype('int32')
    violation_desc_freq_map = combined_df['violation_description'].value_counts().astype('int32')
    combined_df['street_name_freq'] = combined_df['street_name'].map(street_name_freq_map).fillna(0).astype('int32')
    combined_df['violation_desc_freq'] = combined_df['violation_description'].map(violation_desc_freq_map).fillna(0).astype('int32')


    # Augmentation 1: nyc_street_data.csv
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        try:
            if use_usecols_external_data:
                street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
                street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            else: # Ablation: load all columns and rename expected ones
                street_data = pd.read_csv(street_data_path)
                street_data.rename(columns={'Street Name': 'street_name', 'Borough': 'borough', 
                                            'Street Length': 'street_length', 'Number of Lanes': 'num_lanes'}, inplace=True)
                if not all(col in street_data.columns for col in ['street_name', 'borough', 'street_length', 'num_lanes']):
                    raise ValueError("Essential columns not found after loading street data without usecols.")

            street_data = downcast_dtypes_ablated(street_data, apply_downcast)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()

            # Interaction Feature: street_name_borough
            if enable_street_borough_interaction and 'borough' in combined_df.columns:
                # Ensure borough is string for concatenation, fill NaN first to prevent 'nan' string
                combined_df['borough'] = combined_df['borough'].astype(str).replace('nan', 'UNKNOWN_BOROUGH')
                combined_df['street_name_borough'] = combined_df['street_name'].fillna('').astype(str) + '_' + combined_df['borough'].fillna('').astype(str)
        except Exception as e:
            pass # Suppress detailed error messages for cleaner ablation output

    # Augmentation 2: nyc_violation_codes.csv
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        try:
            if use_usecols_external_data:
                violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
                violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            else: # Ablation: load all columns and rename expected ones
                violation_codes = pd.read_csv(violation_codes_path)
                violation_codes.rename(columns={'Violation Description': 'violation_description', 
                                                'Fine Amount': 'fine_amount', 'Points': 'points'}, inplace=True)
                if not all(col in violation_codes.columns for col in ['violation_description', 'fine_amount', 'points']):
                    raise ValueError("Essential columns not found after loading violation codes without usecols.")

            violation_codes = downcast_dtypes_ablated(violation_codes, apply_downcast)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
        except Exception as e:
            pass # Suppress detailed error messages for cleaner ablation output

    # Augmentation 3: nyc_census_data.csv (Hypothetical)
    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        if 'borough' in combined_df.columns: # Check if 'borough' was successfully merged before attempting census merge
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes_ablated(census_agg, apply_downcast)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
            except Exception as e:
                pass # Suppress detailed error messages for cleaner ablation output

    # Split back into train and test processed dataframes
    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw
    gc.collect()

    test_processed_df = None
    if test_df_raw is not None:
        test_processed_df = pd.merge(test_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
        del test_df_raw
        gc.collect()

    # Identify categorical features for CatBoost
    # A column is considered categorical if its dtype is 'object' or 'category' in combined_df (where features are built)
    # and it exists in the final training dataframe.
    categorical_features = [col for col in combined_df.columns if combined_df[col].dtype in ['object', 'category']]
    
    # Add newly created interaction feature if present and not already in the list
    if enable_street_borough_interaction and 'street_name_borough' in combined_df.columns:
        if 'street_name_borough' not in categorical_features:
            categorical_features.append('street_name_borough')
    
    # Filter for columns that actually exist in the processed training data
    categorical_features = [col for col in categorical_features if col in train_processed_df.columns]

    # Ensure all categorical columns are of 'category' dtype for CatBoost and handle NaNs
    # Fill NaNs with a placeholder string before converting to category to prevent CatBoost errors
    for col in categorical_features:
        if col in train_processed_df.columns:
            train_processed_df[col] = train_processed_df[col].fillna('UNKNOWN_CATEGORY').astype('category')
        if test_processed_df is not None and col in test_processed_df.columns:
            test_processed_df[col] = test_processed_df[col].fillna('UNKNOWN_CATEGORY').astype('category')

    return train_processed_df, test_processed_df, categorical_features

def train_and_predict_ablated(train_df, test_df, categorical_features):
    """
    Trains a CatBoost Regressor model and generates predictions.
    Reports RMSE for validation.
    """
    # Define features (X) and target (y)
    features = [col for col in train_df.columns if col not in ['violation_count']]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    # Split training data for validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    # Initialize CatBoost Regressor with OOM-conscious parameters
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6,
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Suppress CatBoost training output for cleaner ablation results
        early_stopping_rounds=50,
    )

    # Train the model
    # Convert categorical feature names to their integer indices in the DataFrame X_train
    cat_features_indices = [X_train.columns.get_loc(col) for col in categorical_features if col in X_train.columns]

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        raise

    # Validate on internal validation set
    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    
    return None, val_rmse # submission_df is not needed for ablation study

def run_ablation_experiment(name, train_path, apply_downcast, enable_street_borough_interaction, use_usecols_external_data):
    
    train_df, _, categorical_features = load_and_preprocess_data_ablated(
        train_path, 
        test_path=None, # Explicitly do not load test data for ablation
        apply_downcast=apply_downcast,
        enable_street_borough_interaction=enable_street_borough_interaction,
        use_usecols_external_data=use_usecols_external_data
    )
    
    _, val_rmse = train_and_predict_ablated(train_df, None, categorical_features)
    gc.collect() 
    return val_rmse

def main_ablation_study():
    parser = argparse.ArgumentParser(description="Perform ablation study on NYC parking violations prediction.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    args = parser.parse_args()

    # Create dummy external files if they don't exist, for consistent testing.
    # These dummy files contain extra columns for the 'No usecols' ablation to be meaningful.
    os.makedirs('./input', exist_ok=True)
    if not os.path.exists('./input/nyc_street_data.csv'):
        dummy_street_data = pd.DataFrame({
            'Street Name': ['BROADWAY', 'MAIN ST', 'PARK AVE', 'ELM STREET', 'UNKNOWN STREET'],
            'Borough': ['MANHATTAN', 'QUEENS', 'MANHATTAN', 'BRONX', np.nan],
            'Street Length': [5000, 2000, 3000, 1500, 1000],
            'Number of Lanes': [6, 4, 8, 2, 2],
            'Traffic_Intensity': ['HIGH', 'MEDIUM', 'HIGH', 'LOW', 'LOW'],
            'Speed_Limit': [30, 25, 30, 20, 20]
        })
        dummy_street_data.to_csv('./input/nyc_street_data.csv', index=False)

    if not os.path.exists('./input/nyc_violation_codes.csv'):
        dummy_violation_codes = pd.DataFrame({
            'Violation Description': ['NO PARKING', 'RED LIGHT', 'SPEEDING', 'DO NOT ENTER', 'EXPIRED METER'],
            'Fine Amount': [65, 275, 120, 150, 45],
            'Points': [0, 3, 2, 0, 0],
            'Violation_Category': ['PARKING', 'MOVING', 'MOVING', 'SIGNAGE', 'PARKING']
        })
        dummy_violation_codes.to_csv('./input/nyc_violation_codes.csv', index=False)
    
    if not os.path.exists('./input/nyc_census_data.csv'):
        dummy_census_data = pd.DataFrame({
            'Borough': ['MANHATTAN', 'QUEENS', 'BROOKLYN', 'BRONX', 'STATEN ISLAND'],
            'Population Density': [27000, 8000, 15000, 12000, 5000],
            'Avg Income': [120000, 70000, 90000, 60000, 80000],
            'Median_Age': [38, 35, 36, 32, 40]
        })
        dummy_census_data.to_csv('./input/nyc_census_data.csv', index=False)

    # Create a dummy violations_per_street_2022.csv if it doesn't exist
    if not os.path.exists(args.train_path):
        dummy_violations_data = pd.DataFrame({
            'Street Name': ['BROADWAY', 'MAIN ST', 'PARK AVE', 'ELM STREET', 'SECOND AVE', 'FIFTH AVE'],
            'Violation Description': ['NO PARKING', 'RED LIGHT', 'SPEEDING', 'DO NOT ENTER', 'NO PARKING', 'EXPIRED METER'],
            'violation_count': [100, 50, 75, 30, 120, 60]
        })
        dummy_violations_data.to_csv(args.train_path, index=False)

    results = {}

    # Base Case
    base_rmse = run_ablation_experiment("Base Case (All enabled)", args.train_path, 
                                        apply_downcast=True, enable_street_borough_interaction=True, use_usecols_external_data=True)
    results["Base Case"] = base_rmse
    print(f"Base Case RMSE: {base_rmse:.4f}")

    # Ablation 1: No 'street_name_borough' interaction feature
    ablation1_rmse = run_ablation_experiment("No 'street_name_borough' interaction feature", args.train_path, 
                                            apply_downcast=True, enable_street_borough_interaction=False, use_usecols_external_data=True)
    results["No 'street_name_borough' interaction feature"] = ablation1_rmse
    print(f"No 'street_name_borough' interaction feature RMSE: {ablation1_rmse:.4f} (Delta from Base: {ablation1_rmse - base_rmse:+.4f})")

    # Ablation 2: No 'usecols' for external data
    ablation2_rmse = run_ablation_experiment("No 'usecols' for external data", args.train_path, 
                                            apply_downcast=True, enable_street_borough_interaction=True, use_usecols_external_data=False)
    results["No 'usecols' for external data"] = ablation2_rmse
    print(f"No 'usecols' for external data RMSE: {ablation2_rmse:.4f} (Delta from Base: {ablation2_rmse - base_rmse:+.4f})")

    # Ablation 3: No 'downcast_dtypes' function call
    ablation3_rmse = run_ablation_experiment("No 'downcast_dtypes' function call", args.train_path, 
                                            apply_downcast=False, enable_street_borough_interaction=True, use_usecols_external_data=True)
    results["No 'downcast_dtypes' function call"] = ablation3_rmse
    print(f"No 'downcast_dtypes' function call RMSE: {ablation3_rmse:.4f} (Delta from Base: {ablation3_rmse - base_rmse:+.4f})")

    # Determine the most contributing part
    most_contributing_part = ""
    max_abs_delta = 0.0
    impactful_delta_value = 0.0
    
    for name, rmse in results.items():
        if name == "Base Case":
            continue
        delta = rmse - base_rmse
        if abs(delta) > max_abs_delta:
            max_abs_delta = abs(delta)
            most_contributing_part = name
            impactful_delta_value = delta

    if impactful_delta_value > 0:
        contribution_summary = f"Removing '{most_contributing_part}' degraded performance by {impactful_delta_value:.4f} RMSE, indicating it is a highly beneficial component."
    elif impactful_delta_value < 0:
        contribution_summary = f"Removing '{most_contributing_part}' improved performance by {-impactful_delta_value:.4f} RMSE, indicating it is a highly detrimental component."
    else:
        contribution_summary = f"No single component showed a significant impact. All changes had a negligible effect on performance."

    print(f"\nThe most contributing part to the overall performance is: {contribution_summary}")
    print(f"Final Validation Performance: {results['Base Case']:.4f}")

if __name__ == "__main__":
    main_ablation_study()
