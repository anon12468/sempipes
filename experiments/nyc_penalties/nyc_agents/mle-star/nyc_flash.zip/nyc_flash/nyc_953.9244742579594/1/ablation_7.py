
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, KFold
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import gc
import os
import sys

# --- Helper function to downcast dtypes for memory efficiency ---
def downcast_dtypes(df):
    """
    Downcasts numeric columns to more memory-efficient types and converts suitable
    object columns to category.
    """
    for col in df.columns:
        if df[col].dtype == 'int64':
            df[col] = pd.to_numeric(df[col], downcast='integer')
        elif df[col].dtype == 'float64':
            df[col] = pd.to_numeric(df[col], downcast='float')
        if df[col].dtype == 'object':
            num_unique_values = len(df[col].unique())
            num_total_values = len(df[col])
            # Only convert to category if it's not mostly unique, to save memory and be effective
            if num_unique_values > 1 and num_unique_values / num_total_values < 0.5:
                df[col] = df[col].astype('category')
    return df

# --- Modified load_and_preprocess_data for ablation study flexibility ---
def load_and_preprocess_data_ablation(
    train_path,
    enable_target_encoding=True,
    enable_basic_length_features=True,
    fill_categorical_nans_explicitly=True
):
    """
    Loads, preprocesses, and merges data from various sources, with flags
    to enable/disable specific feature engineering steps for ablation.
    Note: For ablation, it only processes training data and returns None for test_df.
    External data loading is kept for consistency but warnings/errors are suppressed
    to keep ablation output clean.
    """
    train_df_raw = pd.read_csv(train_path)
    # The training data provided has no header, so assign columns explicitly
    train_df_raw.columns = ['street_name', 'violation_description', 'violation_count']
    train_df_raw = downcast_dtypes(train_df_raw)

    # --- Target Encoding Strategy ---
    target_col = 'violation_count'
    te_features = ['street_name', 'violation_description']
    n_splits = 5

    if enable_target_encoding:
        global_mean_target = train_df_raw[target_col].mean()

        for col in te_features:
            kf = KFold(n_splits=n_splits, shuffle=True, random_state=42)
            oof_train_encodings = np.zeros(train_df_raw.shape[0])
            for fold, (train_idx, val_idx) in enumerate(kf.split(train_df_raw)):
                train_fold = train_df_raw.iloc[train_idx]
                val_fold = train_df_raw.iloc[val_idx]
                train_means = train_fold.groupby(col)[target_col].mean()
                oof_train_encodings[val_idx] = val_fold[col].map(train_means).fillna(global_mean_target)
            train_df_raw[f'{col}_target_enc'] = oof_train_encodings.astype(np.float32)
        gc.collect()

    combined_keys_train = train_df_raw[['street_name', 'violation_description']].drop_duplicates()
    combined_df = combined_keys_train.reset_index(drop=True)
    del combined_keys_train
    gc.collect()

    # --- Feature Engineering and Augmentation ---
    if enable_basic_length_features:
        combined_df['street_name_len'] = combined_df['street_name'].apply(len).astype('int16')
        combined_df['violation_desc_len'] = combined_df['violation_description'].apply(len).astype('int16')

    # External data loading
    street_data_path = './input/nyc_street_data.csv'
    if os.path.exists(street_data_path):
        try:
            street_data = pd.read_csv(street_data_path, usecols=['Street Name', 'Borough', 'Street Length', 'Number of Lanes'])
            street_data.columns = ['street_name', 'borough', 'street_length', 'num_lanes']
            street_data = downcast_dtypes(street_data)
            street_data = street_data.drop_duplicates(subset=['street_name'])
            combined_df = pd.merge(combined_df, street_data, on='street_name', how='left')
            del street_data
            gc.collect()
        except Exception:
            pass # Suppress errors for ablation flexibility
    
    violation_codes_path = './input/nyc_violation_codes.csv'
    if os.path.exists(violation_codes_path):
        try:
            violation_codes = pd.read_csv(violation_codes_path, usecols=['Violation Description', 'Fine Amount', 'Points'])
            violation_codes.columns = ['violation_description', 'fine_amount', 'points']
            violation_codes = downcast_dtypes(violation_codes)
            violation_codes = violation_codes.drop_duplicates(subset=['violation_description'])
            combined_df = pd.merge(combined_df, violation_codes, on='violation_description', how='left')
            del violation_codes
            gc.collect()
        except Exception:
            pass # Suppress errors for ablation flexibility

    census_data_path = './input/nyc_census_data.csv'
    if os.path.exists(census_data_path):
        if 'borough' in combined_df.columns:
            try:
                census_data = pd.read_csv(census_data_path)
                census_data.columns = [col.lower().replace(' ', '_') for col in census_data.columns]
                relevant_census_cols = ['borough', 'population_density', 'avg_income']
                if all(col in census_data.columns for col in relevant_census_cols):
                    census_agg = census_data.groupby('borough')[['population_density', 'avg_income']].mean().reset_index()
                    census_agg = downcast_dtypes(census_agg)
                    combined_df = pd.merge(combined_df, census_agg, on='borough', how='left')
                    del census_data, census_agg
                    gc.collect()
            except Exception:
                pass # Suppress errors for ablation flexibility

    train_processed_df = pd.merge(train_df_raw, combined_df, on=['street_name', 'violation_description'], how='left')
    del train_df_raw, combined_df # Free up memory
    gc.collect()

    # Identify all columns that are either object or already categorical,
    # as these are candidates for CatBoost's categorical features.
    candidate_categorical_cols = [col for col in train_processed_df.columns 
                                  if train_processed_df[col].dtype == 'object' or pd.api.types.is_categorical_dtype(train_processed_df[col])]

    # Apply ablation-specific categorical NaN filling (controlled by flag)
    # This block fills NaNs with 'Unknown_Category' if the flag is True.
    if fill_categorical_nans_explicitly:
        for col in candidate_categorical_cols:
            if col in train_processed_df.columns:
                if train_processed_df[col].dtype == 'object' or pd.api.types.is_categorical_dtype(train_processed_df[col]):
                    if train_processed_df[col].isnull().any():
                        train_processed_df[col] = train_processed_df[col].fillna('Unknown_Category')
    
    # Crucial Fix: Ensure all intended categorical columns have NaNs handled for CatBoost.
    # CatBoost does not accept NaN values in its categorical features, regardless of the
    # `fill_categorical_nans_explicitly` ablation flag. This block ensures all remaining
    # NaNs in categorical-candidate columns are filled with a placeholder string, and then
    # converted to 'category' dtype, satisfying CatBoost's requirements.
    final_cat_features_for_catboost = []
    for col in candidate_categorical_cols:
        if col in train_processed_df.columns:
            # Only process if it's an object or category type. Skip if it became numeric.
            if train_processed_df[col].dtype == 'object' or pd.api.types.is_categorical_dtype(train_processed_df[col]):
                if train_processed_df[col].isnull().any():
                    # Fill any remaining NaNs with a generic placeholder for CatBoost.
                    # This handles cases where `fill_categorical_nans_explicitly` was False,
                    # or if new NaNs appeared from merges into non-explicitly filled columns.
                    train_processed_df[col] = train_processed_df[col].fillna('CatBoost_NaN_Placeholder')
                
                # Ensure the column is explicitly of 'category' dtype for CatBoost
                train_processed_df[col] = train_processed_df[col].astype('category')
                
                # Add to the list of final categorical features for CatBoost
                final_cat_features_for_catboost.append(col)

    # Filter out target encoded features from `final_cat_features_for_catboost`
    # as they are now numerical and should not be treated as categorical by CatBoost.
    final_cat_features_for_catboost = [f for f in final_cat_features_for_catboost if not f.endswith('_target_enc')]

    return train_processed_df, None, final_cat_features_for_catboost

# --- Original train_and_predict (with CatBoost params from previous ablation) ---
def train_and_predict(train_df, test_df, categorical_features):
    """
    Trains a CatBoost Regressor model and reports RMSE for the validation set.
    """
    features = [col for col in train_df.columns if col not in ['violation_count', 'is_pure_prediction']]
    # Ensure all features actually exist in the dataframe
    features = [f for f in features if f in train_df.columns] 
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Initialize CatBoost Regressor with optimal parameters from previous ablations
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6,
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Set verbose to 0 for silent training during ablation
        early_stopping_rounds=50,
        grow_policy='Lossguide', # Beneficial from Ablation Study 6
        max_leaves=31 # Associated with Lossguide, from Ablation Study 6
    )

    # Ensure cat_features_in_X_train contains only columns present in X_train
    cat_features_in_X_train = [col for col in categorical_features if col in X_train.columns]
    cat_features_indices = [X_train.columns.get_loc(col) for col in cat_features_in_X_train]

    try:
        model.fit(X_train, y_train,
                  eval_set=(X_val, y_val),
                  cat_features=cat_features_indices,
                 )
    except Exception as e:
        print(f"Error during CatBoost training: {e}")
        # Add debugging information for the categorical features
        print(f"Problematic categorical features being passed to CatBoost: {cat_features_in_X_train}")
        for col in cat_features_in_X_train:
            if X_train[col].isnull().any():
                print(f"Column '{col}' in X_train still contains NaNs before CatBoost fit.")
            if not (X_train[col].dtype == 'object' or pd.api.types.is_categorical_dtype(X_train[col])):
                print(f"Column '{col}' has unexpected dtype '{X_train[col].dtype}' for a categorical feature.")
        raise # Re-raise the exception after printing debug info

    val_preds = model.predict(X_val)
    val_preds[val_preds < 0] = 0 # Clip negative predictions
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    
    return None, val_rmse # Only return validation RMSE for ablation study

# --- Main ablation study logic ---
def main_ablation():
    train_path = './input/violations_per_street_2022.csv'

    results = {}

    # Base Case: All selected features/preprocessing steps enabled
    print("\n--- Running Base Case: All enabled ---")
    train_df_base, _, categorical_features_base = load_and_preprocess_data_ablation(
        train_path,
        enable_target_encoding=True,
        enable_basic_length_features=True,
        fill_categorical_nans_explicitly=True
    )
    _, rmse_base = train_and_predict(train_df_base, None, categorical_features_base)
    results['Base Case'] = rmse_base
    print(f"Base Case Validation RMSE: {rmse_base:.4f}")

    # Ablation 1: Disable K-fold Target Encoding
    print("\n--- Running Ablation 1: No K-fold Target Encoding ---")
    train_df_no_te, _, categorical_features_no_te = load_and_preprocess_data_ablation(
        train_path,
        enable_target_encoding=False,
        enable_basic_length_features=True,
        fill_categorical_nans_explicitly=True
    )
    _, rmse_no_te = train_and_predict(train_df_no_te, None, categorical_features_no_te)
    results['No K-fold Target Encoding'] = rmse_no_te
    print(f"Ablation (No TE) Validation RMSE: {rmse_no_te:.4f}")

    # Ablation 2: Disable Basic Length Features ('street_name_len', 'violation_desc_len')
    print("\n--- Running Ablation 2: No Basic Length Features ---")
    train_df_no_len, _, categorical_features_no_len = load_and_preprocess_data_ablation(
        train_path,
        enable_target_encoding=True,
        enable_basic_length_features=False,
        fill_categorical_nans_explicitly=True
    )
    _, rmse_no_len = train_and_predict(train_df_no_len, None, categorical_features_no_len)
    results['No Basic Length Features'] = rmse_no_len
    print(f"Ablation (No Basic Length Features) Validation RMSE: {rmse_no_len:.4f}")

    # Ablation 3: Disable Explicit NaN Filling for Categorical Features
    print("\n--- Running Ablation 3: No Explicit NaN Filling for Categorical Features ---")
    train_df_no_nan_fill, _, categorical_features_no_nan_fill = load_and_preprocess_data_ablation(
        train_path,
        enable_target_encoding=True,
        enable_basic_length_features=True,
        fill_categorical_nans_explicitly=False
    )
    _, rmse_no_nan_fill = train_and_predict(train_df_no_nan_fill, None, categorical_features_no_nan_fill)
    results['No Explicit NaN Filling for Categorical Features'] = rmse_no_nan_fill
    print(f"Ablation (No Explicit NaN Fill) Validation RMSE: {rmse_no_nan_fill:.4f}")


    print("\n--- Ablation Study Results Summary ---")
    print(f"Base Case RMSE: {results['Base Case']:.4f}")
    for name, rmse in results.items():
        if name != 'Base Case':
            delta = rmse - results['Base Case']
            print(f"{name}: RMSE = {rmse:.4f}, Delta from Base = {delta:+.4f}")

    # Determine the most impactful change
    most_impactful_change = ""
    max_abs_delta = 0
    impact_description = ""

    for name, rmse in results.items():
        if name != 'Base Case':
            delta = rmse - results['Base Case']
            if abs(delta) > max_abs_delta:
                max_abs_delta = abs(delta)
                most_impactful_change = name
                if delta > 0: # Removing it increased RMSE -> it was beneficial
                    impact_description = f"beneficial (removing it worsened performance by {delta:+.4f})"
                elif delta < 0: # Removing it decreased RMSE -> it was detrimental
                    impact_description = f"detrimental (removing it improved performance by {delta:+.4f})"
                else:
                    impact_description = "neutral (removing it had no observable effect)"

    if most_impactful_change:
        print(f"\nThe most impactful part identified in this study is '{most_impactful_change}'.")
        print(f"It was {impact_description}.")
    else:
        print("No significant change observed across ablations.")

    # Final Validation Performance
    final_validation_score = results['Base Case'] # Report the base case RMSE as the final performance
    print(f'Final Validation Performance: {final_validation_score}')


if __name__ == "__main__":
    # Create dummy input files if they don't exist, consistent with previous ablation study notes
    os.makedirs('./input', exist_ok=True)
    if not os.path.exists('./input/violations_per_street_2022.csv'):
        dummy_data = {
            'street_name': ['Main St', 'Oak Ave', 'Main St', 'Elm St', 'Oak Ave', 'Pine Rd', 'Main St', 'Elm St', 'Maple Ave'],
            'violation_description': ['Parking', 'Speeding', 'No Standing', 'Parking', 'No Parking', 'Loading Zone', 'Parking', 'Speeding', 'Expired Meter'],
            'violation_count': [100, 50, 120, 80, 60, 45, 110, 55, 70]
        }
        # header=False because the first row is data, not header according to task description for this file
        pd.DataFrame(dummy_data).to_csv('./input/violations_per_street_2022.csv', header=False, index=False)
    if not os.path.exists('./input/nyc_street_data.csv'):
        dummy_street_data = {
            'Street Name': ['Main St', 'Oak Ave', 'Elm St', 'Pine Rd'], # Note: Maple Ave from violations is missing here to create NaNs for 'borough'
            'Borough': ['Manhattan', 'Brooklyn', 'Queens', 'Bronx'],
            'Street Length': [1000, 800, 500, 650],
            'Number of Lanes': [4, 2, 3, 2]
        }
        pd.DataFrame(dummy_street_data).to_csv('./input/nyc_street_data.csv', index=False)
    if not os.path.exists('./input/nyc_violation_codes.csv'):
        dummy_violation_codes = {
            'Violation Description': ['Parking', 'Speeding', 'No Standing', 'No Parking', 'Loading Zone', 'Expired Meter'],
            'Fine Amount': [60, 100, 115, 65, 90, 45],
            'Points': [0, 3, 0, 0, 0, 0]
        }
        pd.DataFrame(dummy_violation_codes).to_csv('./input/nyc_violation_codes.csv', index=False)
    if not os.path.exists('./input/nyc_census_data.csv'):
        dummy_census_data = {
            'Borough': ['Manhattan', 'Brooklyn', 'Queens', 'Bronx', 'Staten Island'],
            'Population Density': [27000, 15000, 8000, 12000, 6000],
            'Avg Income': [120000, 75000, 60000, 50000, 80000]
        }
        pd.DataFrame(dummy_census_data).to_csv('./input/nyc_census_data.csv', index=False)

    main_ablation()
