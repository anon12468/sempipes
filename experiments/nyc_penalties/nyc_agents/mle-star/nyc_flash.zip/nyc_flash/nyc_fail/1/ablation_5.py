

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import argparse
import os
import logging
from collections import defaultdict

# Set up logging for better visibility during execution
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Helper function to load data safely ---
def load_data(file_path, df_name="DataFrame"):
    """
    Loads a CSV file into a pandas DataFrame.
    Handles file not found errors and general exceptions during loading.
    """
    if not os.path.exists(file_path):
        logging.warning(f"File not found at {file_path} for {df_name}. Returning empty DataFrame.")
        return pd.DataFrame()
    try:
        df = pd.read_csv(file_path)
        logging.info(f"Successfully loaded {df_name} from {file_path} with {len(df)} rows.")
        return df
    except Exception as e:
        logging.error(f"Error loading {file_path} for {df_name}: {e}. Returning empty DataFrame.")
        return pd.DataFrame()

# --- Feature Engineering and Preprocessing Class ---
class FeatureEngineer:
    """
    Handles loading auxiliary data, creating new features, and imputing missing values
    for both training and prediction datasets.
    It prepares data suitable for RandomForest, which requires numerical input.
    """
    def __init__(self, 
                 use_plan_implement_agent_1_imputation=True, # Ablation point 1: Median imputation with missingness indicators
                 include_violation_codes_features=True,    # Ablation point 2: Violation codes aux features
                 include_traffic_counts_features=True):    # Ablation point 3: Traffic counts aux features
        self.trained_street_violation_pairs = None 
        self.feature_columns = [] 
        self.median_values = {} # To store median values for consistent imputation in transform
        
        self.le_street = LabelEncoder()
        self.le_violation = LabelEncoder()
        self.le_borough = LabelEncoder()
        
        self._original_categorical_cols = ['street_name', 'violation_type', 'borough']

        # Ablation flags
        self.use_plan_implement_agent_1_imputation = use_plan_implement_agent_1_imputation
        self.include_violation_codes_features = include_violation_codes_features
        self.include_traffic_counts_features = include_traffic_counts_features

    def fit(self, df_train_raw, aux_data_dir="./input"):
        """
        Fits the feature engineer on the raw training data.
        Performs feature creation, imputation, and fits LabelEncoders.
        Returns processed features (X) and target (y) for training.
        """
        logging.info("Fitting FeatureEngineer...")
        self.trained_street_violation_pairs = set(
            df_train_raw.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1)
        )
        
        df_train_features = self._add_auxiliary_features(df_train_raw.copy(), aux_data_dir)
        
        df_train_features.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type',
            'violation_count': 'violation_count'
        }, inplace=True)
        
        target = 'violation_count'
        y_train = df_train_features[target]
        df_train_features.drop(columns=[target], inplace=True)

        df_train_features['street_name_encoded'] = self.le_street.fit_transform(
            df_train_features['street_name'].fillna('UNKNOWN_STREET').astype(str)
        )
        df_train_features['violation_type_encoded'] = self.le_violation.fit_transform(
            df_train_features['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str)
        )
        
        if 'borough' in df_train_features.columns:
            df_train_features['borough_encoded'] = self.le_borough.fit_transform(
                df_train_features['borough'].fillna('UNKNOWN_BOROUGH').astype(str)
            )
        else:
            df_train_features['borough_encoded'] = -1 
            logging.warning("No 'borough' column found during feature engineering in train. Using -1 for encoded.")

        # --- Numerical Imputation Logic ---
        numerical_cols = df_train_features.select_dtypes(include=np.number).columns
        for col in numerical_cols:
            if df_train_features[col].isnull().any():
                if self.use_plan_implement_agent_1_imputation:
                    # Imputation strategy proposed by plan_implement_agent_1: Median + Missingness Indicator
                    df_train_features[f'{col}_was_missing'] = df_train_features[col].isnull().astype(int)
                    median_val = df_train_features[col].median()
                    self.median_values[col] = median_val # Store for consistent transformation
                    df_train_features[col].fillna(median_val, inplace=True)
                else:
                    # Ablated imputation: Simple zero fill (original code's behavior)
                    df_train_features[col].fillna(0, inplace=True)
        
        # Define the final feature columns for the model
        # Exclude original string columns, and any temporary columns
        self.feature_columns = [
            col for col in df_train_features.columns
            if col not in self._original_categorical_cols and col != 'actual_violation_count'
        ]
        
        logging.info(f"Identified {len(self.feature_columns)} features for RandomForest.")
        return df_train_features[self.feature_columns], y_train

    def transform(self, df_data_raw, aux_data_dir="./input"):
        """
        Transforms new raw data (e.g., test/evaluation data) using the fitted feature engineer.
        Applies feature creation and imputation based on training data.
        """
        logging.info("Transforming data using fitted FeatureEngineer...")
        df_data_features = self._add_auxiliary_features(df_data_raw.copy(), aux_data_dir)
        
        if 'violation_count' in df_data_features.columns:
            df_data_features['actual_violation_count'] = df_data_features['violation_count']
            df_data_features.drop(columns=['violation_count'], inplace=True)

        df_data_features.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type'
        }, inplace=True)

        df_data_features['street_name_encoded'] = df_data_features['street_name'].fillna('UNKNOWN_STREET').astype(str).map(
            lambda x: self.le_street.transform([x])[0] if x in self.le_street.classes_ else -1
        )
        df_data_features['violation_type_encoded'] = self.le_violation.transform(
            df_data_features['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str).map(
                lambda x: self.le_violation.transform([x])[0] if x in self.le_violation.classes_ else -1
            )
        )
        
        if 'borough' in df_data_features.columns:
            df_data_features['borough_encoded'] = df_data_features['borough'].fillna('UNKNOWN_BOROUGH').astype(str).map(
                lambda x: self.le_borough.transform([x])[0] if x in self.le_borough.classes_ else -1
            )
        else:
            df_data_features['borough_encoded'] = -1 
            logging.warning("No 'borough' column found during feature engineering in test. Using -1 for encoded.")

        # --- Numerical Imputation Logic for transform ---
        # Identify numerical columns from the feature_columns list (which were determined during fit)
        numerical_cols_to_impute = [col for col in self.feature_columns 
                                     if col in df_data_features.columns 
                                     and df_data_features[col].dtype in [np.number] 
                                     and not col.endswith('_was_missing') # Exclude _was_missing columns themselves
                                     and col not in self._original_categorical_cols] 

        for col in numerical_cols_to_impute:
            if self.use_plan_implement_agent_1_imputation:
                # Create missingness indicator if this feature column was part of the training set
                indicator_col_name = f'{col}_was_missing'
                if indicator_col_name in self.feature_columns: 
                    df_data_features[indicator_col_name] = df_data_features[col].isnull().astype(int)
                
                # Impute original column using stored median from training, or median of test if not found (fallback)
                median_val = self.median_values.get(col, df_data_features[col].median())
                df_data_features[col].fillna(median_val, inplace=True)
            else:
                # If simple zero fill was used in fit, apply it consistently
                df_data_features[col].fillna(0, inplace=True)
        
        # Ensure all _was_missing columns that were in training are present in test, even if all 0s
        if self.use_plan_implement_agent_1_imputation:
            for col_name_in_features in self.feature_columns:
                if col_name_in_features.endswith('_was_missing') and col_name_in_features not in df_data_features.columns:
                    df_data_features[col_name_in_features] = 0 

        # Ensure all feature columns from training are present and in order
        for col in self.feature_columns:
            if col not in df_data_features.columns:
                df_data_features[col] = 0 
                logging.warning(f"Added missing feature '{col}' to test data with 0.")

        return df_data_features[self.feature_columns]

    def _add_auxiliary_features(self, df, aux_data_dir):
        """
        Loads and merges auxiliary data to enrich the main DataFrame with additional features.
        """
        logging.info("Adding auxiliary features...")

        # --- Violation Codes Features (Ablation Point 2) ---
        if self.include_violation_codes_features:
            violation_codes_df = load_data(os.path.join(aux_data_dir, 'violation_codes.csv'), 'Violation Codes')
            if not violation_codes_df.empty:
                violation_codes_df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
                violation_codes_df['fine_amount_avg'] = (
                    violation_codes_df['Manhattan 96th St. & Below'].fillna(0) + 
                    violation_codes_df['All Other Areas'].fillna(0)
                ) / 2
                violation_codes_df.drop(columns=['Violation Code', 'Manhattan 96th St. & Below', 'All Other Areas'], errors='ignore', inplace=True)
                df = pd.merge(df, violation_codes_df, on='violation_type', how='left')
                logging.info(f"Merged violation codes. DF shape: {df.shape}")
            else:
                logging.warning("Skipping merging violation codes: Data not loaded or empty.")
        else:
            logging.info("Ablation: Skipping violation codes features.")
        
        # --- Street Segments Features ---
        street_segments_df = load_data(os.path.join(aux_data_dir, 'nyc_street_segments.csv'), 'Street Segments')
        if not street_segments_df.empty:
            street_segments_agg = street_segments_df.groupby('Street Name').agg(
                street_segment_length_sum=('Segment Length', 'sum'),
                street_speed_limit_mean=('Speed Limit', 'mean'),
                street_num_lanes_mean=('Number of Lanes', 'mean'),
                borough_ss=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            street_segments_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, street_segments_agg, on='street_name', how='left')
            logging.info(f"Merged street segments. DF shape: {df.shape}")
            
        # --- Parking Zones Features ---
        parking_zones_df = load_data(os.path.join(aux_data_dir, 'nyc_parking_zones.csv'), 'Parking Zones')
        if not parking_zones_df.empty:
            parking_zones_agg = parking_zones_df.groupby('Street Name').agg(
                num_parking_zones=('Parking Zone', 'count'),
                avg_max_duration_parking=('Max Duration', 'mean'),
                borough_pz=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            parking_zones_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, parking_zones_agg, on='street_name', how='left')

            if 'borough_ss' in df.columns and 'borough_pz' in df.columns:
                df['borough'] = df['borough_ss'].fillna(df['borough_pz'])
            elif 'borough_ss' in df.columns:
                 df['borough'] = df['borough_ss']
            elif 'borough_pz' in df.columns:
                 df['borough'] = df['borough_pz']
            else:
                df['borough'] = np.nan
            
            df.drop(columns=['borough_ss', 'borough_pz'], errors='ignore', inplace=True)
            logging.info(f"Merged parking zones. DF shape: {df.shape}")

        # --- Traffic Counts Features (Ablation Point 3) ---
        if self.include_traffic_counts_features:
            traffic_counts_df = load_data(os.path.join(aux_data_dir, 'traffic_counts_nyc.csv'), 'Traffic Counts')
            if not traffic_counts_df.empty:
                traffic_counts_agg = traffic_counts_df.groupby('Street Name').agg(
                    avg_vehicle_count=('Vehicle Count', 'mean'),
                    max_vehicle_count=('Vehicle Count', 'max'),
                    std_vehicle_count=('Vehicle Count', 'std')
                ).reset_index()
                traffic_counts_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
                df = pd.merge(df, traffic_counts_agg, on='street_name', how='left')
                logging.info(f"Merged traffic counts. DF shape: {df.shape}")
            else:
                logging.warning("Skipping merging traffic counts: Data not loaded or empty.")
        else:
            logging.info("Ablation: Skipping traffic counts features.")

        # --- Census Tracts Features ---
        if 'borough' not in df.columns:
            df['borough'] = np.nan
        
        census_tracts_df = load_data(os.path.join(aux_data_dir, 'nyc_census_tracts.csv'), 'Census Tracts')
        if not census_tracts_df.empty:
            census_borough_agg = census_tracts_df.groupby('Borough').agg(
                total_population_borough=('Total Population', 'sum'),
                median_household_income_borough=('Median Household Income', 'mean'),
                poverty_rate_borough=('Poverty Rate', 'mean')
            ).reset_index()
            df = pd.merge(df, census_borough_agg, on='Borough', how='left')
            logging.info(f"Merged census tracts. DF shape: {df.shape}")
        else:
            logging.warning("Census tracts data not available or empty.")

        logging.info("Finished adding auxiliary features.")
        return df

def run_experiment(description, 
                   use_plan_implement_agent_1_imputation=True, 
                   include_violation_codes_features=True, 
                   include_traffic_counts_features=True,
                   train_path="./input/violations_per_street_2022.csv",
                   aux_data_dir="./input"):
    """
    Runs a single experiment with specified ablation settings and returns the validation RMSE.
    """
    logging.info(f"\n--- Running Experiment: {description} ---")

    train_2022_raw = load_data(train_path, '2022 Training Data')
    if train_2022_raw.empty:
        logging.error("Training data is empty or could not be loaded. Exiting experiment.")
        return None

    fe = FeatureEngineer(
        use_plan_implement_agent_1_imputation=use_plan_implement_agent_1_imputation,
        include_violation_codes_features=include_violation_codes_features,
        include_traffic_counts_features=include_traffic_counts_features
    )

    X_full_2022, y_full_2022 = fe.fit(train_2022_raw, aux_data_dir)
    
    X_train, X_val, y_train, y_val = train_test_split(
        X_full_2022, y_full_2022, test_size=0.2, random_state=42
    )
    
    logging.info(f"Training data shape: {X_train.shape}, Validation data shape: {X_val.shape}")

    rf_model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1, min_samples_leaf=5)
    rf_model.fit(X_train, y_train)
    logging.info("Model training complete.")

    val_predictions = rf_model.predict(X_val)
    val_predictions[val_predictions < 0] = 0 
    val_predictions = np.round(val_predictions).astype(int) 

    val_rmse = np.sqrt(mean_squared_error(y_val, val_predictions))
    logging.info(f"Validation RMSE for '{description}': {val_rmse:.4f}")
    return val_rmse

if __name__ == '__main__':
    # Define paths (assuming data is in a sibling 'input' directory)
    current_dir = os.path.dirname(os.path.abspath(__file__))
    input_dir = os.path.join(current_dir, 'input')
    train_file = os.path.join(input_dir, 'violations_per_street_2022.csv')

    results = {}

    # --- Baseline Experiment (with plan_implement_agent_1's imputation and all specified aux features) ---
    baseline_rmse = run_experiment(
        "Baseline (plan_implement_agent_1 Imputation, All Aux Features)",
        use_plan_implement_agent_1_imputation=True,
        include_violation_codes_features=True,
        include_traffic_counts_features=True,
        train_path=train_file,
        aux_data_dir=input_dir
    )
    results["Baseline (plan_implement_agent_1 Imputation, All Aux Features)"] = baseline_rmse

    # --- Ablation 1: Revert Numerical Imputation to Simple Zero Fill (No Missingness Indicators) ---
    rmse_ablation_imputation = run_experiment(
        "Ablation 1: Simple Zero Fill Imputation (No Missingness Indicators)",
        use_plan_implement_agent_1_imputation=False,
        include_violation_codes_features=True,
        include_traffic_counts_features=True,
        train_path=train_file,
        aux_data_dir=input_dir
    )
    results["Ablation 1: Simple Zero Fill Imputation"] = rmse_ablation_imputation

    # --- Ablation 2: Remove Violation Codes Features ---
    rmse_ablation_violation_codes = run_experiment(
        "Ablation 2: No Violation Codes Features",
        use_plan_implement_agent_1_imputation=True, 
        include_violation_codes_features=False,
        include_traffic_counts_features=True,
        train_path=train_file,
        aux_data_dir=input_dir
    )
    results["Ablation 2: No Violation Codes Features"] = rmse_ablation_violation_codes

    # --- Ablation 3: Remove Traffic Counts Features ---
    rmse_ablation_traffic_counts = run_experiment(
        "Ablation 3: No Traffic Counts Features",
        use_plan_implement_agent_1_imputation=True, 
        include_violation_codes_features=True,
        include_traffic_counts_features=False,
        train_path=train_file,
        aux_data_dir=input_dir
    )
    results["Ablation 3: No Traffic Counts Features"] = rmse_ablation_traffic_counts

    print("\n--- Ablation Study Results ---")
    if baseline_rmse is None: 
        print("Baseline experiment failed to run. Cannot compare ablations.")
    else:
        performance_changes = defaultdict(float)
        
        for name, rmse in results.items():
            if name == "Baseline (plan_implement_agent_1 Imputation, All Aux Features)" or rmse is None:
                continue
            
            diff = rmse - baseline_rmse
            performance_changes[name] = diff
            print(f"- {name}: RMSE = {rmse:.4f} (Change from Baseline: {'+' if diff > 0 else ''}{diff:.4f})")

        largest_degradation_key = None
        largest_degradation_value = 0.0

        for name, diff in performance_changes.items():
            # A positive diff indicates performance degradation (increase in RMSE) when the component was ablated.
            if diff > largest_degradation_value:
                largest_degradation_value = diff
                largest_degradation_key = name

        print("\n--- Conclusion ---")
        if largest_degradation_key:
            # Extract the component name from the ablation description
            component_name = largest_degradation_key.split(": ", 1)[1].strip()
            print(f"The part of the code that contributed the most to the overall performance (i.e., its removal caused the largest degradation) is: '{component_name}'")
            print(f"Its ablation resulted in a performance degradation (RMSE increase) of: {largest_degradation_value:.4f}")
        else:
            print("Based on this ablation study, none of the ablated components significantly degraded performance when removed, or their contributions were minimal compared to other factors.")

