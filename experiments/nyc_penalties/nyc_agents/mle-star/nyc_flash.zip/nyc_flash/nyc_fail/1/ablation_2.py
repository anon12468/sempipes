
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import argparse
import os
import logging

# Set up logging for better visibility during execution
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Helper function to load data safely ---
def load_data(file_path, df_name="DataFrame"):
    """
    Loads a CSV file into a pandas DataFrame.
    Handles file not found errors and general exceptions during loading.
    """
    if not os.path.exists(file_path):
        logging.warning(f"File not found at {file_path} for {df_name}. Returning empty DataFrame.")
        return pd.DataFrame()
    try:
        df = pd.read_csv(file_path)
        logging.info(f"Successfully loaded {df_name} from {file_path} with {len(df)} rows.")
        return df
    except Exception as e:
        logging.error(f"Error loading {file_path} for {df_name}: {e}. Returning empty DataFrame.")
        return pd.DataFrame()

# --- Original Feature Engineering and Preprocessing Class ---
class FeatureEngineer:
    """
    Handles loading auxiliary data, creating new features, and imputing missing values
    for both training and prediction datasets.
    It prepares data suitable for RandomForest, which requires numerical input.
    """
    def __init__(self):
        self.trained_street_violation_pairs = None 
        self.feature_columns = [] 
        self.le_street = LabelEncoder()
        self.le_violation = LabelEncoder()
        self.le_borough = LabelEncoder()
        self._original_categorical_cols = ['street_name', 'violation_type', 'borough']

    def fit(self, df_train_raw, aux_data_dir="./input"):
        """
        Fits the feature engineer on the raw training data.
        Performs feature creation, imputation, and fits LabelEncoders.
        Returns processed features (X) and target (y) for training.
        """
        logging.info("Fitting FeatureEngineer...")
        self.trained_street_violation_pairs = set(
            df_train_raw.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1)
        )
        
        df_train_features = self._add_auxiliary_features(df_train_raw.copy(), aux_data_dir)
        
        df_train_features.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type',
            'violation_count': 'violation_count'
        }, inplace=True)
        
        target = 'violation_count'
        y_train = df_train_features[target]
        df_train_features.drop(columns=[target], inplace=True)

        df_train_features['street_name_encoded'] = self.le_street.fit_transform(
            df_train_features['street_name'].fillna('UNKNOWN_STREET').astype(str)
        )
        df_train_features['violation_type_encoded'] = self.le_violation.fit_transform(
            df_train_features['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str)
        )
        if 'borough' in df_train_features.columns:
            df_train_features['borough_encoded'] = self.le_borough.fit_transform(
                df_train_features['borough'].fillna('UNKNOWN_BOROUGH').astype(str)
            )
        else:
            df_train_features['borough_encoded'] = -1 
            logging.warning("No 'borough' column found during feature engineering in train. Using -1 for encoded.")

        numerical_cols = df_train_features.select_dtypes(include=np.number).columns
        for col in numerical_cols:
            df_train_features[col].fillna(0, inplace=True)
        
        self.feature_columns = [
            col for col in df_train_features.columns
            if col not in self._original_categorical_cols and col != 'actual_violation_count'
        ]
        
        logging.info(f"Identified {len(self.feature_columns)} features for RandomForest.")
        return df_train_features[self.feature_columns], y_train

    def transform(self, df_data_raw, aux_data_dir="./input"):
        """
        Transforms new raw data (e.g., test/evaluation data) using the fitted feature engineer.
        Applies feature creation and imputation based on training data.
        """
        logging.info("Transforming data using fitted FeatureEngineer...")
        df_data_features = self._add_auxiliary_features(df_data_raw.copy(), aux_data_dir)
        
        if 'violation_count' in df_data_features.columns:
            df_data_features['actual_violation_count'] = df_data_features['violation_count']
            df_data_features.drop(columns=['violation_count'], inplace=True)

        df_data_features.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type'
        }, inplace=True)

        df_data_features['street_name_encoded'] = df_data_features['street_name'].fillna('UNKNOWN_STREET').astype(str).map(
            lambda x: self.le_street.transform([x])[0] if x in self.le_street.classes_ else -1
        )
        df_data_features['violation_type_encoded'] = self.le_violation.transform(
            df_data_features['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str).map(
                lambda x: x if x in self.le_violation.classes_ else 'UNKNOWN_VIOLATION_PLACEHOLDER'
            )
        )
        
        if 'borough' in df_data_features.columns:
            df_data_features['borough_encoded'] = df_data_features['borough'].fillna('UNKNOWN_BOROUGH').astype(str).map(
                lambda x: self.le_borough.transform([x])[0] if x in self.le_borough.classes_ else -1
            )
        else:
            df_data_features['borough_encoded'] = -1 
            logging.warning("No 'borough' column found during feature engineering in test. Using -1 for encoded.")

        numerical_cols = df_data_features.select_dtypes(include=np.number).columns
        for col in numerical_cols:
            df_data_features[col].fillna(0, inplace=True)
            
        for col in self.feature_columns:
            if col not in df_data_features.columns:
                df_data_features[col] = 0 
                logging.warning(f"Added missing feature '{col}' to test data with 0.")

        return df_data_features[self.feature_columns]

    def _add_auxiliary_features(self, df, aux_data_dir):
        """
        Loads and merges auxiliary data to enrich the main DataFrame with additional features.
        This is the method that will be overridden for ablation studies.
        """
        logging.info("Adding auxiliary features (ORIGINAL FULL)...")

        # --- Violation Codes Features ---
        violation_codes_df = load_data(os.path.join(aux_data_dir, 'violation_codes.csv'), 'Violation Codes')
        if not violation_codes_df.empty:
            violation_codes_df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
            violation_codes_df['fine_amount_avg'] = (
                violation_codes_df['Manhattan 96th St. & Below'].fillna(0) + 
                violation_codes_df['All Other Areas'].fillna(0)
            ) / 2
            violation_codes_df.drop(columns=['Violation Code', 'Manhattan 96th St. & Below', 'All Other Areas'], errors='ignore', inplace=True)
            df = pd.merge(df, violation_codes_df, on='violation_type', how='left')
            logging.info(f"Merged violation codes. DF shape: {df.shape}")
        
        # --- Street Segments Features ---
        street_segments_df = load_data(os.path.join(aux_data_dir, 'nyc_street_segments.csv'), 'Street Segments')
        if not street_segments_df.empty:
            street_segments_agg = street_segments_df.groupby('Street Name').agg(
                street_segment_length_sum=('Segment Length', 'sum'),
                street_speed_limit_mean=('Speed Limit', 'mean'),
                street_num_lanes_mean=('Number of Lanes', 'mean'),
                borough_ss=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            street_segments_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, street_segments_agg, on='street_name', how='left')
            logging.info(f"Merged street segments. DF shape: {df.shape}")
            
        # --- Parking Zones Features ---
        parking_zones_df = load_data(os.path.join(aux_data_dir, 'nyc_parking_zones.csv'), 'Parking Zones')
        if not parking_zones_df.empty:
            parking_zones_agg = parking_zones_df.groupby('Street Name').agg(
                num_parking_zones=('Parking Zone', 'count'),
                avg_max_duration_parking=('Max Duration', 'mean'),
                borough_pz=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            parking_zones_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, parking_zones_agg, on='street_name', how='left')

            # Consolidate borough information
            if 'borough_ss' in df.columns and 'borough_pz' in df.columns:
                df['borough'] = df['borough_ss'].fillna(df['borough_pz'])
            elif 'borough_ss' in df.columns:
                 df['borough'] = df['borough_ss']
            elif 'borough_pz' in df.columns:
                 df['borough'] = df['borough_pz']
            else: # If no borough from aux data, initialize
                df['borough'] = np.nan
            
            df.drop(columns=['borough_ss', 'borough_pz'], errors='ignore', inplace=True)
            logging.info(f"Merged parking zones. DF shape: {df.shape}")

        # --- Traffic Counts Features ---
        traffic_counts_df = load_data(os.path.join(aux_data_dir, 'traffic_counts_nyc.csv'), 'Traffic Counts')
        if not traffic_counts_df.empty:
            traffic_counts_agg = traffic_counts_df.groupby('Street Name').agg(
                avg_vehicle_count=('Vehicle Count', 'mean'),
                max_vehicle_count=('Vehicle Count', 'max'),
                std_vehicle_count=('Vehicle Count', 'std')
            ).reset_index()
            traffic_counts_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, traffic_counts_agg, on='street_name', how='left')
            logging.info(f"Merged traffic counts. DF shape: {df.shape}")

        # --- Census Tracts Features ---
        if 'borough' not in df.columns:
            df['borough'] = np.nan 
        
        census_tracts_df = load_data(os.path.join(aux_data_dir, 'nyc_census_tracts.csv'), 'Census Tracts')
        if not census_tracts_df.empty:
            census_borough_agg = census_tracts_df.groupby('Borough').agg(
                total_population_borough=('Total Population', 'sum'),
                median_household_income_borough=('Median Household Income', 'mean'),
                poverty_rate_borough=('Poverty Rate', 'mean')
            ).reset_index()
            df = pd.merge(df, census_borough_agg, on='Borough', how='left')
            logging.info(f"Merged census tracts. DF shape: {df.shape}")
        else:
            logging.warning("Census tracts data not available or empty.")

        # --- Interaction Features ---
        if 'street_segment_length_sum' in df.columns:
            if 'num_parking_zones' in df.columns:
                df['parking_zone_density_per_length'] = df['num_parking_zones'] / df['street_segment_length_sum'].replace(0, np.nan)
                df['parking_zone_density_per_length'].fillna(0, inplace=True)
            
            if 'avg_vehicle_count' in df.columns:
                df['traffic_density_per_length'] = df['avg_vehicle_count'] / df['street_segment_length_sum'].replace(0, np.nan)
                df['traffic_density_per_length'].fillna(0, inplace=True)
            
            logging.info("Added interaction features.")

        logging.info("Finished adding auxiliary features (ORIGINAL FULL).")
        return df

# --- Ablation 1: No Interaction Features ---
class FeatureEngineerNoInteractions(FeatureEngineer):
    def _add_auxiliary_features(self, df, aux_data_dir):
        logging.info("Adding auxiliary features (NO INTERACTIONS)...")

        # --- Violation Codes Features --- (Keep)
        violation_codes_df = load_data(os.path.join(aux_data_dir, 'violation_codes.csv'), 'Violation Codes')
        if not violation_codes_df.empty:
            violation_codes_df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
            violation_codes_df['fine_amount_avg'] = (
                violation_codes_df['Manhattan 96th St. & Below'].fillna(0) + 
                violation_codes_df['All Other Areas'].fillna(0)
            ) / 2
            violation_codes_df.drop(columns=['Violation Code', 'Manhattan 96th St. & Below', 'All Other Areas'], errors='ignore', inplace=True)
            df = pd.merge(df, violation_codes_df, on='violation_type', how='left')
            logging.info(f"Merged violation codes. DF shape: {df.shape}")
        
        # --- Street Segments Features --- (Keep)
        street_segments_df = load_data(os.path.join(aux_data_dir, 'nyc_street_segments.csv'), 'Street Segments')
        if not street_segments_df.empty:
            street_segments_agg = street_segments_df.groupby('Street Name').agg(
                street_segment_length_sum=('Segment Length', 'sum'),
                street_speed_limit_mean=('Speed Limit', 'mean'),
                street_num_lanes_mean=('Number of Lanes', 'mean'),
                borough_ss=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            street_segments_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, street_segments_agg, on='street_name', how='left')
            logging.info(f"Merged street segments. DF shape: {df.shape}")
            
        # --- Parking Zones Features --- (Keep)
        parking_zones_df = load_data(os.path.join(aux_data_dir, 'nyc_parking_zones.csv'), 'Parking Zones')
        if not parking_zones_df.empty:
            parking_zones_agg = parking_zones_df.groupby('Street Name').agg(
                num_parking_zones=('Parking Zone', 'count'),
                avg_max_duration_parking=('Max Duration', 'mean'),
                borough_pz=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            parking_zones_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, parking_zones_agg, on='street_name', how='left')

            # Consolidate borough information
            if 'borough_ss' in df.columns and 'borough_pz' in df.columns:
                df['borough'] = df['borough_ss'].fillna(df['borough_pz'])
            elif 'borough_ss' in df.columns:
                 df['borough'] = df['borough_ss']
            elif 'borough_pz' in df.columns:
                 df['borough'] = df['borough_pz']
            else: # If no borough from aux data, initialize
                df['borough'] = np.nan
            
            df.drop(columns=['borough_ss', 'borough_pz'], errors='ignore', inplace=True)
            logging.info(f"Merged parking zones. DF shape: {df.shape}")

        # --- Traffic Counts Features --- (Keep)
        traffic_counts_df = load_data(os.path.join(aux_data_dir, 'traffic_counts_nyc.csv'), 'Traffic Counts')
        if not traffic_counts_df.empty:
            traffic_counts_agg = traffic_counts_df.groupby('Street Name').agg(
                avg_vehicle_count=('Vehicle Count', 'mean'),
                max_vehicle_count=('Vehicle Count', 'max'),
                std_vehicle_count=('Vehicle Count', 'std')
            ).reset_index()
            traffic_counts_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, traffic_counts_agg, on='street_name', how='left')
            logging.info(f"Merged traffic counts. DF shape: {df.shape}")

        # --- Census Tracts Features --- (Keep)
        if 'borough' not in df.columns:
            df['borough'] = np.nan 
        
        census_tracts_df = load_data(os.path.join(aux_data_dir, 'nyc_census_tracts.csv'), 'Census Tracts')
        if not census_tracts_df.empty:
            census_borough_agg = census_tracts_df.groupby('Borough').agg(
                total_population_borough=('Total Population', 'sum'),
                median_household_income_borough=('Median Household Income', 'mean'),
                poverty_rate_borough=('Poverty Rate', 'mean')
            ).reset_index()
            df = pd.merge(df, census_borough_agg, on='Borough', how='left')
            logging.info(f"Merged census tracts. DF shape: {df.shape}")
        else:
            logging.warning("Census tracts data not available or empty.")

        # --- Interaction Features --- (ABLATED)
        logging.info("Skipping interaction features for ablation.")

        logging.info("Finished adding auxiliary features (NO INTERACTIONS).")
        return df

# --- Ablation 2: No Street Segments Features ---
class FeatureEngineerNoStreetSegments(FeatureEngineer):
    def _add_auxiliary_features(self, df, aux_data_dir):
        logging.info("Adding auxiliary features (NO STREET SEGMENTS)...")

        # --- Violation Codes Features --- (Keep)
        violation_codes_df = load_data(os.path.join(aux_data_dir, 'violation_codes.csv'), 'Violation Codes')
        if not violation_codes_df.empty:
            violation_codes_df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
            violation_codes_df['fine_amount_avg'] = (
                violation_codes_df['Manhattan 96th St. & Below'].fillna(0) + 
                violation_codes_df['All Other Areas'].fillna(0)
            ) / 2
            violation_codes_df.drop(columns=['Violation Code', 'Manhattan 96th St. & Below', 'All Other Areas'], errors='ignore', inplace=True)
            df = pd.merge(df, violation_codes_df, on='violation_type', how='left')
            logging.info(f"Merged violation codes. DF shape: {df.shape}")
        
        # --- Street Segments Features --- (ABLATED)
        logging.info("Skipping Street Segments Features for ablation.")
        # 'borough_ss' would normally come from here, ensure 'borough' is still handled.
            
        # --- Parking Zones Features --- (Keep)
        parking_zones_df = load_data(os.path.join(aux_data_dir, 'nyc_parking_zones.csv'), 'Parking Zones')
        if not parking_zones_df.empty:
            parking_zones_agg = parking_zones_df.groupby('Street Name').agg(
                num_parking_zones=('Parking Zone', 'count'),
                avg_max_duration_parking=('Max Duration', 'mean'),
                borough_pz=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            parking_zones_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, parking_zones_agg, on='street_name', how='left')

            # Consolidate borough information (borough_ss will not exist)
            if 'borough_pz' in df.columns: # Check only for parking zones borough
                 df['borough'] = df['borough_pz']
            else: 
                df['borough'] = np.nan
            
            df.drop(columns=['borough_ss', 'borough_pz'], errors='ignore', inplace=True) # borough_ss might not exist
            logging.info(f"Merged parking zones. DF shape: {df.shape}")

        # --- Traffic Counts Features --- (Keep)
        traffic_counts_df = load_data(os.path.join(aux_data_dir, 'traffic_counts_nyc.csv'), 'Traffic Counts')
        if not traffic_counts_df.empty:
            traffic_counts_agg = traffic_counts_df.groupby('Street Name').agg(
                avg_vehicle_count=('Vehicle Count', 'mean'),
                max_vehicle_count=('Vehicle Count', 'max'),
                std_vehicle_count=('Vehicle Count', 'std')
            ).reset_index()
            traffic_counts_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, traffic_counts_agg, on='street_name', how='left')
            logging.info(f"Merged traffic counts. DF shape: {df.shape}")

        # --- Census Tracts Features --- (Keep)
        if 'borough' not in df.columns:
            df['borough'] = np.nan 
        
        census_tracts_df = load_data(os.path.join(aux_data_dir, 'nyc_census_tracts.csv'), 'Census Tracts')
        if not census_tracts_df.empty:
            census_borough_agg = census_tracts_df.groupby('Borough').agg(
                total_population_borough=('Total Population', 'sum'),
                median_household_income_borough=('Median Household Income', 'mean'),
                poverty_rate_borough=('Poverty Rate', 'mean')
            ).reset_index()
            df = pd.merge(df, census_borough_agg, on='Borough', how='left')
            logging.info(f"Merged census tracts. DF shape: {df.shape}")
        else:
            logging.warning("Census tracts data not available or empty.")

        # --- Interaction Features --- (Will implicitly not create features if dependencies are missing)
        if 'street_segment_length_sum' in df.columns: # This condition will now likely be false
            if 'num_parking_zones' in df.columns:
                df['parking_zone_density_per_length'] = df['num_parking_zones'] / df['street_segment_length_sum'].replace(0, np.nan)
                df['parking_zone_density_per_length'].fillna(0, inplace=True)
            if 'avg_vehicle_count' in df.columns:
                df['traffic_density_per_length'] = df['avg_vehicle_count'] / df['street_segment_length_sum'].replace(0, np.nan)
                df['traffic_density_per_length'].fillna(0, inplace=True)
            logging.info("Added interaction features.")

        logging.info("Finished adding auxiliary features (NO STREET SEGMENTS).")
        return df

# --- Ablation 3: No Parking Zones Features ---
class FeatureEngineerNoParkingZones(FeatureEngineer):
    def _add_auxiliary_features(self, df, aux_data_dir):
        logging.info("Adding auxiliary features (NO PARKING ZONES)...")

        # --- Violation Codes Features --- (Keep)
        violation_codes_df = load_data(os.path.join(aux_data_dir, 'violation_codes.csv'), 'Violation Codes')
        if not violation_codes_df.empty:
            violation_codes_df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
            violation_codes_df['fine_amount_avg'] = (
                violation_codes_df['Manhattan 96th St. & Below'].fillna(0) + 
                violation_codes_df['All Other Areas'].fillna(0)
            ) / 2
            violation_codes_df.drop(columns=['Violation Code', 'Manhattan 96th St. & Below', 'All Other Areas'], errors='ignore', inplace=True)
            df = pd.merge(df, violation_codes_df, on='violation_type', how='left')
            logging.info(f"Merged violation codes. DF shape: {df.shape}")
        
        # --- Street Segments Features --- (Keep)
        street_segments_df = load_data(os.path.join(aux_data_dir, 'nyc_street_segments.csv'), 'Street Segments')
        if not street_segments_df.empty:
            street_segments_agg = street_segments_df.groupby('Street Name').agg(
                street_segment_length_sum=('Segment Length', 'sum'),
                street_speed_limit_mean=('Speed Limit', 'mean'),
                street_num_lanes_mean=('Number of Lanes', 'mean'),
                borough_ss=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            street_segments_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, street_segments_agg, on='street_name', how='left')
            logging.info(f"Merged street segments. DF shape: {df.shape}")
            
        # --- Parking Zones Features --- (ABLATED)
        logging.info("Skipping Parking Zones Features for ablation.")
        # 'borough_pz' would normally come from here, ensure 'borough' is still handled.

        # Consolidate borough information (borough_pz will not exist)
        if 'borough_ss' in df.columns: # Check only for street segments borough
            df['borough'] = df['borough_ss']
        else:
            df['borough'] = np.nan
        df.drop(columns=['borough_ss', 'borough_pz'], errors='ignore', inplace=True) # borough_pz might not exist
            

        # --- Traffic Counts Features --- (Keep)
        traffic_counts_df = load_data(os.path.join(aux_data_dir, 'traffic_counts_nyc.csv'), 'Traffic Counts')
        if not traffic_counts_df.empty:
            traffic_counts_agg = traffic_counts_df.groupby('Street Name').agg(
                avg_vehicle_count=('Vehicle Count', 'mean'),
                max_vehicle_count=('Vehicle Count', 'max'),
                std_vehicle_count=('Vehicle Count', 'std')
            ).reset_index()
            traffic_counts_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, traffic_counts_agg, on='street_name', how='left')
            logging.info(f"Merged traffic counts. DF shape: {df.shape}")

        # --- Census Tracts Features --- (Keep)
        if 'borough' not in df.columns:
            df['borough'] = np.nan 
        
        census_tracts_df = load_data(os.path.join(aux_data_dir, 'nyc_census_tracts.csv'), 'Census Tracts')
        if not census_tracts_df.empty:
            census_borough_agg = census_tracts_df.groupby('Borough').agg(
                total_population_borough=('Total Population', 'sum'),
                median_household_income_borough=('Median Household Income', 'mean'),
                poverty_rate_borough=('Poverty Rate', 'mean')
            ).reset_index()
            df = pd.merge(df, census_borough_agg, on='Borough', how='left')
            logging.info(f"Merged census tracts. DF shape: {df.shape}")
        else:
            logging.warning("Census tracts data not available or empty.")

        # --- Interaction Features --- (Will implicitly not create features if dependencies are missing)
        if 'street_segment_length_sum' in df.columns:
            if 'num_parking_zones' in df.columns: # This condition will now likely be false
                df['parking_zone_density_per_length'] = df['num_parking_zones'] / df['street_segment_length_sum'].replace(0, np.nan)
                df['parking_zone_density_per_length'].fillna(0, inplace=True)
            if 'avg_vehicle_count' in df.columns:
                df['traffic_density_per_length'] = df['avg_vehicle_count'] / df['street_segment_length_sum'].replace(0, np.nan)
                df['traffic_density_per_length'].fillna(0, inplace=True)
            logging.info("Added interaction features.")

        logging.info("Finished adding auxiliary features (NO PARKING ZONES).")
        return df

def run_experiment(feature_engineer_class, train_path, aux_data_dir, experiment_name):
    """
    Runs a single experiment with a given FeatureEngineer class and returns the validation RMSE.
    """
    logging.info(f"\n--- Running Experiment: {experiment_name} ---")

    train_2022_raw = load_data(train_path, '2022 Training Data')
    if train_2022_raw.empty:
        logging.error("Training data is empty or could not be loaded. Exiting experiment.")
        return experiment_name, np.nan

    fe = feature_engineer_class()

    X_full_2022, y_full_2022 = fe.fit(train_2022_raw, aux_data_dir)
    
    X_train, X_val, y_train, y_val = train_test_split(
        X_full_2022, y_full_2022, test_size=0.2, random_state=42
    )
    
    logging.info(f"Training data shape: {X_train.shape}, Validation data shape: {X_val.shape}")

    rf_model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1, min_samples_leaf=5)
    rf_model.fit(X_train, y_train)

    val_predictions = rf_model.predict(X_val)
    val_predictions[val_predictions < 0] = 0
    val_predictions = np.round(val_predictions).astype(int)

    val_rmse = np.sqrt(mean_squared_error(y_val, val_predictions))
    
    logging.info(f"Experiment '{experiment_name}' Validation RMSE: {val_rmse:.4f}")
    return experiment_name, val_rmse

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Ablation study for NYC parking violations prediction.")
    parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--aux-data-dir", type=str, default="./input",
                        help="Directory containing auxiliary data CSV files.")
    
    args = parser.parse_args()

    results = {}

    # Baseline Experiment
    _, baseline_rmse = run_experiment(FeatureEngineer, args.train_path, args.aux_data_dir, "Baseline (All Features)")
    results["Baseline (All Features)"] = baseline_rmse

    # Ablation 1: No Interaction Features
    _, no_interactions_rmse = run_experiment(FeatureEngineerNoInteractions, args.train_path, args.aux_data_dir, "Ablation: No Interaction Features")
    results["Ablation: No Interaction Features"] = no_interactions_rmse

    # Ablation 2: No Street Segments Features
    _, no_street_segments_rmse = run_experiment(FeatureEngineerNoStreetSegments, args.train_path, args.aux_data_dir, "Ablation: No Street Segments Features")
    results["Ablation: No Street Segments Features"] = no_street_segments_rmse

    # Ablation 3: No Parking Zones Features
    _, no_parking_zones_rmse = run_experiment(FeatureEngineerNoParkingZones, args.train_path, args.aux_data_dir, "Ablation: No Parking Zones Features")
    results["Ablation: No Parking Zones Features"] = no_parking_zones_rmse

    print("\n--- Ablation Study Results ---")
    
    max_degradation = 0
    most_critical_positive_component = "None of the ablated components showed a significant positive contribution when removed."

    for name, rmse in results.items():
        if name == "Baseline (All Features)":
            print(f"{name}: RMSE = {rmse:.4f}")
        else:
            diff = rmse - baseline_rmse
            print(f"{name}: RMSE = {rmse:.4f} (Difference from Baseline: {diff:+.4f})")
            
            if diff > max_degradation:
                max_degradation = diff
                # The name of the *ablation* is "Ablation: No X". So X is the contributing part.
                most_critical_positive_component = name.replace("Ablation: No ", "")
            elif diff < 0:
                 logging.warning(f"Removing {name.replace('Ablation: No ', '')} improved performance by {-diff:.4f} RMSE.")

    if max_degradation > 0:
        print(f"\nConclusion: Among the ablated components, '{most_critical_positive_component}' contributes the most to the overall performance, as its removal led to an increase of {max_degradation:.4f} in Validation RMSE. This indicates it is a valuable feature group.")
    else:
        print(f"\nConclusion: None of the ablated components (Interaction Features, Street Segments Features, Parking Zones Features) showed a significant positive contribution to the model's performance when removed (i.e., their removal did not substantially worsen RMSE).")

