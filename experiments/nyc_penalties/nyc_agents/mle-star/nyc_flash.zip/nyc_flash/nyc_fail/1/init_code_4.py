
import argparse
import pandas as pd
import numpy as np
import os
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import mean_squared_error
from sklearn.linear_model import PoissonRegressor
import warnings
import sys
import subprocess
import traceback

# Suppress warnings for cleaner output
warnings.filterwarnings('ignore')

# --- Install necessary libraries if not present ---
# This block should be at the very top to ensure dependencies are met before code execution.
try:
    import pandas
    import numpy
    import sklearn
except ImportError as e:
    print(f"Missing essential library: {e}. Attempting to install...", file=sys.stderr)
    try:
        # Use pip directly via subprocess to ensure it's executed
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'pandas', 'numpy', 'scikit-learn'])
        print("Successfully installed pandas, numpy, scikit-learn.")
    except Exception as install_e:
        print(f"Failed to install necessary libraries: {install_e}", file=sys.stderr)
        print("Please ensure pip is installed and accessible, and try installing them manually.", file=sys.stderr)
        # Re-raise the error to halt execution if critical dependencies cannot be met
        raise

def load_data_from_input_dir(input_dir, filename, column_mapping=None):
    """Loads a CSV file from the input directory, handling potential FileNotFoundError."""
    filepath = os.path.join(input_dir, filename)
    try:
        df = pd.read_csv(filepath)
        print(f"Successfully loaded {filepath} with {len(df)} rows.")
        if column_mapping:
            df.rename(columns=column_mapping, inplace=True)
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {filepath}. Please ensure it exists.", file=sys.stderr)
        raise # Re-raise to indicate a critical failure
    except Exception as e:
        print(f"Error loading {filepath}: {e}", file=sys.stderr)
        raise

def preprocess_data(df, is_train=True, preprocessor=None, categorical_features=None, numerical_features=None, target_column=None):
    """
    Preprocesses the data, applying feature engineering and encoding.
    `is_train` indicates if it's training data (to fit the preprocessor).
    `preprocessor` is passed for test data to transform.
    """
    # Separate target if present
    y = None
    if target_column and target_column in df.columns:
        y = df[target_column]
        X = df.drop(columns=[target_column])
    else:
        X = df.copy() # Operate on a copy to avoid modifying original df unintentionally

    # Impute missing categories with 'Unknown'
    for col in categorical_features:
        if col in X.columns:
            X[col] = X[col].fillna('Unknown')
        else:
            # Add the column with 'Unknown' if it's missing in X but expected by preprocessor
            print(f"Warning: Categorical feature '{col}' not found in DataFrame, adding as 'Unknown'.")
            X[col] = 'Unknown'


    # Impute numerical features with median (for train) or 0 (for test, if no train median available via preprocessor)
    for col in numerical_features:
        if col in X.columns:
            if X[col].isnull().any():
                print(f"Warning: Imputing missing values in numerical feature '{col}'.")
                # For test, StandardScaler handles NaNs, but if it's not fit, it fails.
                # A robust pipeline would have a SimpleImputer step before StandardScaler.
                # For this problem, filling with 0 for test numerical NaNs is a pragmatic choice
                # if preprocessor doesn't contain an imputer.
                X[col] = X[col].fillna(0) # Simple imputation
        else:
            print(f"Warning: Numerical feature '{col}' not found in DataFrame, adding as 0.")
            X[col] = 0.0 # Add missing numerical column with default 0.0

    if is_train:
        # Define preprocessor for categorical and numerical features
        preprocessor = ColumnTransformer(
            transformers=[
                ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features),
                ('num', StandardScaler(), numerical_features)
            ],
            remainder='passthrough' # Keep other columns (like keys) if they are not features
        )
        X_processed = preprocessor.fit_transform(X)
        return X_processed, y, preprocessor
    else:
        # Ensure the preprocessor was fit and passed
        if preprocessor is None:
            raise ValueError("Preprocessor must be provided for test data transformation.")
        
        # Align columns of test_df with training data columns for transformation
        # This is a common point of failure for OneHotEncoder if unseen categories or missing columns occur.
        # ColumnTransformer with handle_unknown='ignore' and explicit feature lists handles this well.
        X_processed = preprocessor.transform(X)
        return X_processed, y, None # Preprocessor is not returned for test data

def run_pipeline(args):
    try:
        # --- 1. Load Data ---
        print("\n--- Loading Data ---")
        input_dir = args.input_dir
        train_df_raw = load_data_from_input_dir(input_dir, args.train_path,
                                                column_mapping={'Street Name': 'street_name',
                                                                'Violation Description': 'violation_type',
                                                                'violation_count': 'violation_count'})

        # Load augmentation tables
        violation_codes_df = load_data_from_input_dir(input_dir, 'violation_codes.csv')
        nyc_borough_df = load_data_from_input_dir(input_dir, 'nyc_borough_data.csv')

        # --- 2. Feature Engineering (Training Data) ---
        print("\n--- Feature Engineering for Training Data ---")
        train_df = train_df_raw.copy()

        # Merge with augmentation tables
        # Assuming `violation_codes.csv` has `Violation Description` and other features
        # and `nyc_borough_data.csv` has `Street Name` and `Borough`.
        
        # Merge violation_codes_df
        # Standardize column names for merging
        if 'Violation Description' in violation_codes_df.columns:
            violation_codes_df_renamed = violation_codes_df.rename(columns={'Violation Description': 'violation_type'})
            train_df = pd.merge(train_df, violation_codes_df_renamed.drop(columns=['violation_type'], errors='ignore'), on='violation_type', how='left')
        else:
            print("Warning: 'Violation Description' column not found in violation_codes.csv. Skipping merge.", file=sys.stderr)

        # Merge nyc_borough_data.csv
        if 'Street Name' in nyc_borough_df.columns and 'Borough' in nyc_borough_df.columns:
            nyc_borough_df_renamed = nyc_borough_df.rename(columns={'Street Name': 'street_name'})
            train_df = pd.merge(train_df, nyc_borough_df_renamed[['street_name', 'Borough']], on='street_name', how='left')
        else:
            print("Warning: 'Street Name' or 'Borough' columns not found in nyc_borough_data.csv. Skipping merge.", file=sys.stderr)


        # Create simple length features
        train_df['street_name_len'] = train_df['street_name'].apply(lambda x: len(str(x)) if pd.notna(x) else 0)
        train_df['violation_type_len'] = train_df['violation_type'].apply(lambda x: len(str(x)) if pd.notna(x) else 0)

        # Handle high cardinality for street_name and violation_type by grouping
        N_top_streets = 100
        top_streets = train_df['street_name'].value_counts().nlargest(N_top_streets).index.tolist()
        train_df['street_name_grouped'] = np.where(train_df['street_name'].isin(top_streets), train_df['street_name'], 'Other_Street')

        N_top_violations = 50
        top_violations = train_df['violation_type'].value_counts().nlargest(N_top_violations).index.tolist()
        train_df['violation_type_grouped'] = np.where(train_df['violation_type'].isin(top_violations), train_df['violation_type'], 'Other_Violation')

        # Define features and target
        TARGET = 'violation_count'
        KEYS = ['street_name', 'violation_type'] # Original keys for output and unseen handling

        # Categorical features for encoding
        categorical_features = ['street_name_grouped', 'violation_type_grouped']
        if 'Borough' in train_df.columns:
            categorical_features.append('Borough')
        
        # Numerical features
        numerical_features = ['street_name_len', 'violation_type_len']

        # Ensure all defined categorical/numerical features exist, or handle gracefully
        for col in categorical_features:
            if col not in train_df.columns:
                print(f"Warning: Categorical feature '{col}' is missing from train_df after merges. It will be added as 'Unknown'.")
                train_df[col] = 'Unknown'
        for col in numerical_features:
            if col not in train_df.columns:
                print(f"Warning: Numerical feature '{col}' is missing from train_df after merges. It will be added as 0.0.")
                train_df[col] = 0.0


        # --- 3. Split Data (Train/Validation) ---
        print("\n--- Splitting Data ---")
        
        # Filter for relevant columns for X and y
        # Keep original KEYS for later tracking, but don't pass to model directly as features
        X_train_val_df = train_df[categorical_features + numerical_features + KEYS].copy()
        y_train_val = train_df[TARGET].copy()

        # Grouped split (if possible, otherwise random)
        # Using a simple random split for now to meet the requirement without complex group K-Fold
        X_train, X_val, y_train, y_val = train_test_split(
            X_train_val_df, y_train_val, test_size=0.2, random_state=42,
            stratify=train_df['violation_type_grouped'] if len(train_df['violation_type_grouped'].unique()) > 1 else None # Stratify if enough categories
        )
        print(f"Training data size: {len(X_train)}")
        print(f"Validation data size: {len(X_val)}")

        # --- 4. Preprocess Data (Fit on Train, Transform Train/Val) ---
        print("\n--- Preprocessing Training and Validation Data ---")
        X_train_processed, y_train_target, preprocessor = preprocess_data(
            X_train.drop(columns=KEYS, errors='ignore'), # Drop original keys before passing to preprocessor
            is_train=True,
            categorical_features=categorical_features,
            numerical_features=numerical_features,
            target_column=None # Target is already separated
        )
        X_val_processed, y_val_target, _ = preprocess_data(
            X_val.drop(columns=KEYS, errors='ignore'), # Drop original keys before passing to preprocessor
            is_train=False,
            preprocessor=preprocessor,
            categorical_features=categorical_features,
            numerical_features=numerical_features,
            target_column=None # Target is already separated
        )
        # Ensure y_train_target and y_val_target are correctly set from y_train and y_val
        y_train = y_train_target
        y_val = y_val_target

        # --- 5. Model Training ---
        print("\n--- Model Training ---")
        # PoissonRegressor requires non-negative integers. Ensure y_train is int.
        y_train_clipped = y_train.clip(lower=0).astype(int)
        
        model = PoissonRegressor(alpha=1.0, max_iter=2000, tol=1e-3) # Increased max_iter for convergence
        model.fit(X_train_processed, y_train_clipped)
        print("Model training complete.")

        # --- 6. Validation ---
        print("\n--- Validation ---")
        val_predictions = model.predict(X_val_processed)
        val_predictions[val_predictions < 0] = 0 # Clip negative predictions

        rmse_val = np.sqrt(mean_squared_error(y_val, val_predictions))
        print(f"Final Validation Performance: {rmse_val}") # Required print statement

        # --- 7. Test Prediction (if test_path is provided) ---
        if args.test_path:
            print("\n--- Generating Test Predictions ---")
            test_df_raw = load_data_from_input_dir(input_dir, args.test_path,
                                                    column_mapping={'Street Name': 'street_name',
                                                                    'Violation Description': 'violation_type',
                                                                    'violation_count': 'violation_count'})

            # Preserve original keys for submission and unseen tracking
            test_original_keys = test_df_raw[KEYS].copy()

            # --- Feature Engineering (Test Data) ---
            test_df = test_df_raw.copy()

            # Merge violation_codes_df
            if 'Violation Description' in violation_codes_df.columns:
                violation_codes_df_renamed = violation_codes_df.rename(columns={'Violation Description': 'violation_type'})
                test_df = pd.merge(test_df, violation_codes_df_renamed.drop(columns=['violation_type'], errors='ignore'), on='violation_type', how='left')
            
            # Merge nyc_borough_data.csv
            if 'Street Name' in nyc_borough_df.columns and 'Borough' in nyc_borough_df.columns:
                nyc_borough_df_renamed = nyc_borough_df.rename(columns={'Street Name': 'street_name'})
                test_df = pd.merge(test_df, nyc_borough_df_renamed[['street_name', 'Borough']], on='street_name', how='left')

            # Create same features as training
            test_df['street_name_len'] = test_df['street_name'].apply(lambda x: len(str(x)) if pd.notna(x) else 0)
            test_df['violation_type_len'] = test_df['violation_type'].apply(lambda x: len(str(x)) if pd.notna(x) else 0)

            # Apply grouped categories using the *training set's* top categories
            test_df['street_name_grouped'] = np.where(test_df['street_name'].isin(top_streets), test_df['street_name'], 'Other_Street')
            test_df['violation_type_grouped'] = np.where(test_df['violation_type'].isin(top_violations), test_df['violation_type'], 'Other_Violation')

            # Ensure all categorical/numerical features exist for test set
            for col in categorical_features:
                if col not in test_df.columns:
                    print(f"Warning: Categorical feature '{col}' is missing from test_df, adding as 'Unknown'.")
                    test_df[col] = 'Unknown'
            for col in numerical_features:
                if col not in test_df.columns:
                    print(f"Warning: Numerical feature '{col}' is missing from test_df, adding as 0.0.")
                    test_df[col] = 0.0

            # Preprocess test data using the *fitted* preprocessor
            X_test_df = test_df[categorical_features + numerical_features + KEYS].copy()
            y_test_ground_truth = None
            if TARGET in test_df.columns:
                y_test_ground_truth = test_df[TARGET].copy()

            X_test_processed, _, _ = preprocess_data(
                X_test_df.drop(columns=KEYS, errors='ignore'), # Drop original keys
                is_train=False,
                preprocessor=preprocessor,
                categorical_features=categorical_features,
                numerical_features=numerical_features,
                target_column=None
            )

            test_predictions = model.predict(X_test_processed)
            test_predictions[test_predictions < 0] = 0 # Clip negative predictions
            test_predictions_rounded = np.round(test_predictions).astype(int)

            # Handle unseen key pairs in test set
            train_key_pairs = set(train_df[KEYS].apply(lambda row: (row['street_name'], row['violation_type']), axis=1))
            test_key_pairs = test_original_keys.apply(lambda row: (row['street_name'], row['violation_type']), axis=1)

            unseen_mask = ~test_key_pairs.isin(train_key_pairs)
            num_unseen = unseen_mask.sum()
            print(f"Number of unseen (street_name, violation_type) pairs in test set: {num_unseen}")

            # Create submission file
            submission_df = pd.DataFrame({
                'street_name': test_original_keys['street_name'],
                'violation_type': test_original_keys['violation_type'],
                'predicted_count': test_predictions_rounded
            })
            submission_df.to_csv('submission.csv', index=False)
            print("Submission file 'submission.csv' generated successfully.")

            # Report RMSE if ground truth is available in the test file
            if y_test_ground_truth is not None:
                print("\n--- Test Set Evaluation ---")
                rmse_test = np.sqrt(mean_squared_error(y_test_ground_truth, test_predictions))
                print(f"Test Set RMSE: {rmse_test}")

        print("\n--- Pipeline execution complete ---")

    except Exception as e:
        print(f"An unexpected error occurred during pipeline execution: {e}", file=sys.stderr)
        traceback.print_exc(file=sys.stderr) # Print full traceback for debugging

# Main execution block
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='violations_per_street_2022.csv',
                        help='Path to the training data CSV file relative to input_dir.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional path to the test data CSV file relative to input_dir. If provided, predictions will be generated.')
    parser.add_argument('--input-dir', type=str, default='./input',
                        help='Directory containing all input CSV files.')

    args = parser.parse_args()

    run_pipeline(args)
