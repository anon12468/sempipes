
import pandas as pd
import numpy as np
import argparse
import os
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import lightgbm as lgb
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def parse_args():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument("--train-path", type=str,
                        default="./input/violations_per_street_2022.csv",
                        help="Path to the training data CSV file (2022 violations).")
    parser.add_argument("--test-path", type=str,
                        default=None,
                        help="Optional: Path to the test/evaluation data CSV file (e.g., 2023 violations).")
    return parser.parse_args()

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame."""
    try:
        df = pd.read_csv(file_path)
        logging.info(f"Successfully loaded data from {file_path}. Shape: {df.shape}")
        return df
    except FileNotFoundError:
        logging.warning(f"Warning: File not found at {file_path}. Returning empty DataFrame.")
        return pd.DataFrame() # Return empty DataFrame to avoid errors downstream
    except Exception as e:
        logging.error(f"Error loading {file_path}: {e}")
        return pd.DataFrame()

def _add_auxiliary_features(df, street_metadata, violation_descriptions, nyc_holidays):
    """
    Adds auxiliary features to the DataFrame.
    This function includes the fix for KeyError by renaming columns.
    """
    if df.empty:
        logging.warning("Input DataFrame is empty, skipping auxiliary feature addition.")
        return df

    logging.info("Adding auxiliary features...")

    # Rename columns for consistency, fixing the KeyError
    # The bug summary explicitly mentioned 'Street Name' and 'Violation Description'
    # were passed when 'street_name' and 'violation_type' were expected.
    # This ensures consistency for merges and feature engineering.
    if 'Street Name' in df.columns:
        df.rename(columns={'Street Name': 'street_name'}, inplace=True)
    if 'Violation Description' in df.columns:
        df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)

    # Ensure 'street_name' and 'violation_type' exist before proceeding
    if 'street_name' not in df.columns or 'violation_type' not in df.columns:
        logging.error("Required columns 'street_name' or 'violation_type' are missing after renaming.")
        return df # Return df as is, cannot proceed with merges

    # Convert to lowercase for robust merging
    df['street_name_lower'] = df['street_name'].astype(str).str.lower()
    df['violation_type_lower'] = df['violation_type'].astype(str).str.lower()

    # --- Augmentation: Street Metadata ---
    if street_metadata is not None and not street_metadata.empty:
        logging.info("Merging with street_metadata...")
        street_metadata_copy = street_metadata.copy()
        if 'street_name' in street_metadata_copy.columns:
            street_metadata_copy['street_name_lower'] = street_metadata_copy['street_name'].astype(str).str.lower()
            df = pd.merge(df, street_metadata_copy.drop(columns=['street_name'], errors='ignore'), on='street_name_lower', how='left', suffixes=('', '_street_meta'))
            logging.info(f"Merged with street_metadata. New shape: {df.shape}")
        else:
            logging.warning("street_metadata.csv does not contain 'street_name' column. Skipping merge.")

    # --- Augmentation: Violation Descriptions ---
    if violation_descriptions is not None and not violation_descriptions.empty:
        logging.info("Merging with violation_descriptions...")
        violation_descriptions_copy = violation_descriptions.copy()
        if 'violation_type' in violation_descriptions_copy.columns:
            violation_descriptions_copy['violation_type_lower'] = violation_descriptions_copy['violation_type'].astype(str).str.lower()
            df = pd.merge(df, violation_descriptions_copy.drop(columns=['violation_type'], errors='ignore'), on='violation_type_lower', how='left', suffixes=('', '_viol_desc'))
            logging.info(f"Merged with violation_descriptions. New shape: {df.shape}")
        else:
            logging.warning("violation_descriptions.csv does not contain 'violation_type' column. Skipping merge.")

    # --- Augmentation: NYC Holidays ---
    # As discussed in thought process, direct use for yearly aggregate counts is complex.
    # If a 'month' or 'day' feature could be derived from violation_type, it would be useful.
    # For now, we'll skip direct holiday features on yearly aggregate data.

    # Example of simple features from existing data:
    df['street_name_len'] = df['street_name'].astype(str).apply(len)
    df['violation_type_len'] = df['violation_type'].astype(str).apply(len)

    logging.info("Finished adding auxiliary features.")
    return df

def preprocess_features(df, is_training=True, encoders=None, categorical_features=None, numeric_features=None):
    """
    Preprocesses features, handles categorical encoding and NaN values.
    Returns processed DataFrame and updated encoders if is_training is True.
    """
    if df.empty:
        logging.warning("Input DataFrame for preprocessing is empty.")
        return df, encoders if encoders is not None else {}

    if encoders is None:
        encoders = {}
    if categorical_features is None:
        # Default categorical features, these should be consistently present
        categorical_features = ['street_name', 'violation_type']
    if numeric_features is None:
        # Default numeric features
        numeric_features = ['street_name_len', 'violation_type_len']

    processed_df = df.copy()

    # Dynamically identify additional categorical features introduced by merges
    # Exclude helper columns and already included base categorical features
    potential_new_cat_features = [
        col for col in processed_df.select_dtypes(include='object').columns
        if col not in ['street_name', 'violation_type', 'street_name_lower', 'violation_type_lower']
    ]
    all_categorical_features = list(set(categorical_features + potential_new_cat_features))

    # Handle categorical features
    for col in all_categorical_features:
        if col in processed_df.columns:
            # Fill NaN for categorical columns with a placeholder before converting to category
            # This is important for LightGBM to treat NaN as a separate category
            processed_df[col] = processed_df[col].fillna('__MISSING__').astype(str)

            if is_training:
                # Convert to category and store categories
                processed_df[col] = processed_df[col].astype('category')
                encoders[col] = processed_df[col].cat.categories
            else:
                # Apply categories from training data to test data
                if col in encoders:
                    # Create a CategoricalDtype based on training categories
                    cat_dtype = pd.CategoricalDtype(categories=encoders[col])
                    # Apply to test data, unseen values become NaN
                    processed_df[col] = processed_df[col].astype(cat_dtype)
                    # Fill NaN (unseen categories) with a special category, or '__MISSING__' if we filled before
                    # For LightGBM, a NaN in a categorical column is usually treated as a separate category,
                    # but explicit handling ensures consistency.
                    processed_df[col] = processed_df[col].fillna('__MISSING__')
                else:
                    logging.warning(f"Category encoder not found for '{col}' during testing. Treating new values as new categories.")
                    processed_df[col] = processed_df[col].astype('category')
        else:
            logging.warning(f"Categorical feature '{col}' not found in DataFrame during preprocessing.")

    # Identify all potential numeric features (excluding target)
    all_numeric_features = list(set(numeric_features + [col for col in processed_df.select_dtypes(include=np.number).columns if col not in ['violation_count']]))

    # Handle numeric features (imputation)
    for col in all_numeric_features:
        if col in processed_df.columns:
            if processed_df[col].isnull().any():
                if is_training:
                    median_val = processed_df[col].median()
                    encoders[f'{col}_median'] = median_val
                    processed_df[col].fillna(median_val, inplace=True)
                else:
                    median_val = encoders.get(f'{col}_median', processed_df[col].median() if not processed_df[col].empty else 0) # Use test median if training median not found or default to 0
                    processed_df[col].fillna(median_val, inplace=True)
        # Ensure column exists, if not, add it with imputed values if it's expected as a feature
        elif col in numeric_features and is_training: # Only log if it's a primary feature expected to exist
             logging.warning(f"Numeric feature '{col}' not found in DataFrame during preprocessing, but expected.")

    logging.info("Finished preprocessing features.")
    return processed_df, encoders, all_categorical_features # Return all_categorical_features for the model

def train_model(X_train, y_train, X_val, y_val, categorical_features_for_model):
    """Trains a LightGBM Regressor model."""
    logging.info("Starting model training...")

    # Ensure categorical features passed to LightGBM are actually in the DataFrame
    # and are of 'category' dtype.
    lgbm_categorical_features = [col for col in categorical_features_for_model if col in X_train.columns and str(X_train[col].dtype) == 'category']

    lgb_params = {
        'objective': 'regression_l1', # MAE objective, often good for count data, robust to outliers
        'metric': 'rmse',
        'n_estimators': 1000,
        'learning_rate': 0.05,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'verbose': -1, # Suppress verbose output
        'n_jobs': -1,
        'seed': 42,
        'boosting_type': 'gbdt',
        # 'early_stopping_round' is passed via callbacks in model.fit
    }

    model = lgb.LGBMRegressor(**lgb_params)

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(50, verbose=False)], # Use callbacks for early stopping
              categorical_feature=lgbm_categorical_features)

    logging.info("Model training complete.")
    return model

def main():
    args = parse_args()

    # Load core training data
    train_df = load_data(args.train_path)
    if train_df.empty:
        logging.error("Training data not loaded or is empty. Exiting.")
        return

    # Discover and load augmentation tables
    input_dir = os.path.dirname(args.train_path)
    # Assume these files might exist. load_data handles FileNotFoundError gracefully.
    street_metadata_path = os.path.join(input_dir, "street_metadata.csv")
    violation_descriptions_path = os.path.join(input_dir, "violation_descriptions.csv")
    nyc_holidays_path = os.path.join(input_dir, "nyc_holidays.csv")

    street_metadata = load_data(street_metadata_path)
    violation_descriptions = load_data(violation_descriptions_path)
    nyc_holidays = load_data(nyc_holidays_path) # Loaded, but not directly used in this aggregate scenario

    # --- Feature Engineering ---
    train_df_processed = _add_auxiliary_features(train_df.copy(), street_metadata, violation_descriptions, nyc_holidays)

    # Define features and target
    target_column = 'violation_count'
    key_columns = ['street_name', 'violation_type'] # Used for identification and final output

    # Check if target column exists in processed training data
    if target_column not in train_df_processed.columns:
        logging.error(f"Target column '{target_column}' not found in processed training data. Exiting.")
        return

    # Identify all potential features (excluding target, original key columns, and helper lowercased columns)
    initial_features = [
        col for col in train_df_processed.columns
        if col not in [target_column, 'street_name_lower', 'violation_type_lower'] + key_columns
    ]

    # Split training data for validation
    X = train_df_processed[initial_features]
    y = train_df_processed[target_column]

    X_train, X_val, y_train, y_val, train_idx, val_idx = train_test_split(
        X, y, train_df_processed.index, test_size=0.2, random_state=42, shuffle=True
    )

    # Preprocess (encode categorical features, handle NaNs)
    X_train_processed, encoders, categorical_features_for_model = preprocess_features(X_train.copy(), is_training=True)
    X_val_processed, _, _ = preprocess_features(X_val.copy(), is_training=False, encoders=encoders)

    # Ensure feature consistency between train and validation sets
    # This step is crucial if augmentation introduced columns unevenly or if some were dropped due to NaNs.
    common_features = list(set(X_train_processed.columns) & set(X_val_processed.columns))
    X_train_processed = X_train_processed[common_features]
    X_val_processed = X_val_processed[common_features]
    categorical_features_for_model = [f for f in categorical_features_for_model if f in common_features]


    # Train model
    model = train_model(X_train_processed, y_train, X_val_processed, y_val, categorical_features_for_model)

    # Evaluate on validation set
    val_predictions = model.predict(X_val_processed)
    val_predictions = np.maximum(0, val_predictions) # Ensure non-negative predictions
    validation_rmse = np.sqrt(mean_squared_error(y_val, val_predictions))
    logging.info(f"Validation RMSE: {validation_rmse:.4f}")
    print(f"Final Validation Performance: {validation_rmse:.4f}")


    # --- Prediction for test-path or full training data if no test-path ---
    if args.test_path:
        test_df = load_data(args.test_path)
        if test_df.empty:
            logging.error("Test data not loaded or is empty. Cannot generate predictions.")
            return

        logging.info("Processing test data for prediction...")

        # Keep original keys for submission
        submission_keys = test_df[key_columns].copy()

        # Add auxiliary features to test data
        test_df_processed = _add_auxiliary_features(test_df.copy(), street_metadata, violation_descriptions, nyc_holidays)

        # Handle unseen key pairs for reporting
        train_key_pairs = train_df_processed[key_columns].drop_duplicates()
        test_key_pairs = test_df_processed[key_columns].drop_duplicates()

        # Merge to find which test keys are not in train keys
        merged_keys = pd.merge(test_key_pairs, train_key_pairs, on=key_columns, how='left', indicator=True)
        unseen_pairs_count = (merged_keys['_merge'] == 'left_only').sum()
        logging.info(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_pairs_count}")

        # Preprocess test features using encoders from training
        X_test_processed, _, _ = preprocess_features(test_df_processed[initial_features].copy(), is_training=False, encoders=encoders)

        # Align test features with training features
        # Add missing columns (if any) and fill with 0 or appropriate default
        for col in X_train_processed.columns:
            if col not in X_test_processed.columns:
                if str(X_train_processed[col].dtype) == 'category':
                    # Add as a new category if it was a category in training
                    X_test_processed[col] = pd.Categorical(np.full(len(X_test_processed), '__MISSING__'), categories=encoders.get(col, ['__MISSING__']))
                else:
                    X_test_processed[col] = encoders.get(f'{col}_median', 0) # Fill numeric with median from training or 0
        # Drop columns in test not in train
        X_test_processed = X_test_processed[X_train_processed.columns]


        # Make predictions
        test_predictions = model.predict(X_test_processed)
        test_predictions = np.maximum(0, test_predictions) # Ensure non-negative predictions

        # Create submission file
        submission_df = submission_keys.copy()
        submission_df['predicted_count'] = test_predictions
        submission_df.to_csv("submission.csv", index=False)
        logging.info("Submission file 'submission.csv' created.")

        # If test_df has 'violation_count', calculate RMSE
        if target_column in test_df_processed.columns:
            y_test = test_df_processed[target_column]
            test_rmse = np.sqrt(mean_squared_error(y_test, test_predictions))
            logging.info(f"Test Set RMSE: {test_rmse:.4f}")
            print(f"Test Set RMSE: {test_rmse:.4f}")
        else:
            logging.info("Test file does not contain 'violation_count'. No RMSE calculated for test set.")
    else:
        logging.info("No --test-path provided. Skipping test prediction.")

if __name__ == "__main__":
    main()
