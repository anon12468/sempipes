
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import argparse
import os
import logging

# Set up logging for better visibility during execution
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Helper function to load data safely ---
def load_data(file_path, df_name="DataFrame"):
    """
    Loads a CSV file into a pandas DataFrame.
    Handles file not found errors and general exceptions during loading.
    """
    if not os.path.exists(file_path):
        logging.warning(f"File not found at {file_path} for {df_name}. Returning empty DataFrame.")
        return pd.DataFrame()
    try:
        df = pd.read_csv(file_path)
        logging.info(f"Successfully loaded {df_name} from {file_path} with {len(df)} rows.")
        return df
    except Exception as e:
        logging.error(f"Error loading {file_path} for {df_name}: {e}. Returning empty DataFrame.")
        return pd.DataFrame()

# --- Feature Engineering and Preprocessing Class ---
class FeatureEngineer:
    """
    Handles loading auxiliary data, creating new features, and imputing missing values
    for both training and prediction datasets.
    It prepares data suitable for RandomForest, which requires numerical input.
    """
    def __init__(self):
        self.trained_street_violation_pairs = None # To track unseen pairs in test
        self.feature_columns = [] # To store names of final features for the model
        
        # Label encoders for categorical features
        self.le_street = LabelEncoder()
        self.le_violation = LabelEncoder()
        self.le_borough = LabelEncoder()
        
        # Keep track of original categorical column names to process them
        self._original_categorical_cols = ['street_name', 'violation_type', 'borough']

    def fit(self, df_train_raw, aux_data_dir="./input"):
        """
        Fits the feature engineer on the raw training data.
        Performs feature creation, imputation, and fits LabelEncoders.
        Returns processed features (X) and target (y) for training.
        """
        logging.info("Fitting FeatureEngineer...")
        # Store unique (street_name, violation_type) pairs from training for unseen pair tracking
        self.trained_street_violation_pairs = set(
            df_train_raw.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1)
        )
        
        # Process core data and add auxiliary features
        df_train_features = self._add_auxiliary_features(df_train_raw.copy(), aux_data_dir)
        
        # Rename core columns to be consistent
        df_train_features.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type',
            'violation_count': 'violation_count'
        }, inplace=True)
        
        # Handle target column
        target = 'violation_count'
        y_train = df_train_features[target]
        df_train_features.drop(columns=[target], inplace=True) # Drop target from features

        # Fit LabelEncoders for categorical features
        df_train_features['street_name_encoded'] = self.le_street.fit_transform(
            df_train_features['street_name'].fillna('UNKNOWN_STREET').astype(str)
        )
        df_train_features['violation_type_encoded'] = self.le_violation.fit_transform(
            df_train_features['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str)
        )
        # Borough might not always be present or fully filled, ensure it's handled
        if 'borough' in df_train_features.columns:
            df_train_features['borough_encoded'] = self.le_borough.fit_transform(
                df_train_features['borough'].fillna('UNKNOWN_BOROUGH').astype(str)
            )
        else:
            df_train_features['borough_encoded'] = -1 # Default for missing borough
            logging.warning("No 'borough' column found during feature engineering in train. Using -1 for encoded.")

        # Impute missing numerical values (after all joins and encodings)
        numerical_cols = df_train_features.select_dtypes(include=np.number).columns
        for col in numerical_cols:
            df_train_features[col].fillna(0, inplace=True) # Simple imputation with 0
        
        # Define the final feature columns for the model
        # Exclude original string columns, and any temporary columns
        self.feature_columns = [
            col for col in df_train_features.columns
            if col not in self._original_categorical_cols and col != 'actual_violation_count'
        ]
        
        logging.info(f"Identified {len(self.feature_columns)} features for RandomForest.")
        return df_train_features[self.feature_columns], y_train

    def transform(self, df_data_raw, aux_data_dir="./input"):
        """
        Transforms new raw data (e.g., test/evaluation data) using the fitted feature engineer.
        Applies feature creation and imputation based on training data.
        """
        logging.info("Transforming data using fitted FeatureEngineer...")
        df_data_features = self._add_auxiliary_features(df_data_raw.copy(), aux_data_dir)
        
        # Store actual_violation_count if present for later evaluation
        if 'violation_count' in df_data_features.columns:
            df_data_features['actual_violation_count'] = df_data_features['violation_count']
            df_data_features.drop(columns=['violation_count'], inplace=True)

        # Rename core columns
        df_data_features.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type'
        }, inplace=True)

        # Check and initialize unseen category maps and counter if not already present on 'self'.
        # These attributes are designed to persist across multiple calls to the feature engineering process.
        if not hasattr(self, '_unseen_category_maps'):
            self._unseen_category_maps = {
                'street_name': {},
                'violation_type': {},
                'borough': {}
            }
        if not hasattr(self, '_next_unseen_id_counter'):
            # Initialize counter for unique negative IDs. Starts from -1, then -2, -3, etc.
            self._next_unseen_id_counter = -1

        # Define a local helper function to handle encoding logic, including unique negative IDs for unseen categories.
        # This function captures 'self' to access its state attributes.
        def _get_encoded_value_with_unseen_id_tracking(category_value, encoder, feature_name):
            # If the category value is known by the LabelEncoder (i.e., seen during training)
            if category_value in encoder.classes_:
                return encoder.transform([category_value])[0]
            else:
                # This is an unseen category value.
                # Check if we have already assigned a unique negative ID to this specific unseen value.
                if category_value not in self._unseen_category_maps[feature_name]:
                    # If it's a new unseen category, assign the next unique negative ID and store it.
                    self._unseen_category_maps[feature_name][category_value] = self._next_unseen_id_counter
                    self._next_unseen_id_counter -= 1 # Decrement counter for the next unique ID
                # Return the assigned unique negative ID for this unseen category.
                return self._unseen_category_maps[feature_name][category_value]

        # Apply LabelEncoders, now using the refined strategy for handling unseen categories.
        df_data_features['street_name_encoded'] = df_data_features['street_name'].fillna('UNKNOWN_STREET').astype(str).map(
            lambda x: _get_encoded_value_with_unseen_id_tracking(x, self.le_street, 'street_name')
        )
        df_data_features['violation_type_encoded'] = df_data_features['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str).map(
            lambda x: _get_encoded_value_with_unseen_id_tracking(x, self.le_violation, 'violation_type')
        )
        
        if 'borough' in df_data_features.columns:
            df_data_features['borough_encoded'] = df_data_features['borough'].fillna('UNKNOWN_BOROUGH').astype(str).map(
                lambda x: _get_encoded_value_with_unseen_id_tracking(x, self.le_borough, 'borough')
            )
        else:
            # If the 'borough' column is entirely missing, we still assign a generic -1.
            # This is different from an unseen category value within an existing column.
            df_data_features['borough_encoded'] = -1
            logging.warning("No 'borough' column found during feature engineering in test. Using -1 for encoded.")

        # Impute missing numerical values
        numerical_cols = df_data_features.select_dtypes(include=np.number).columns
        for col in numerical_cols:
            df_data_features[col].fillna(0, inplace=True) # Simple imputation with 0
            
        # Ensure all feature columns from training are present and in order
        for col in self.feature_columns:
            if col not in df_data_features.columns:
                df_data_features[col] = 0 # Add missing features with a default value (e.g., 0)
                logging.warning(f"Added missing feature '{col}' to test data with 0.")

        return df_data_features[self.feature_columns]

    def _add_auxiliary_features(self, df, aux_data_dir):
        """
        Loads and merges auxiliary data to enrich the main DataFrame with additional features.
        """
        logging.info("Adding auxiliary features...")

        # --- Violation Codes Features ---
        violation_codes_df = load_data(os.path.join(aux_data_dir, 'violation_codes.csv'), 'Violation Codes')
        if not violation_codes_df.empty:
            violation_codes_df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
            violation_codes_df['fine_amount_avg'] = (
                violation_codes_df['Manhattan 96th St. & Below'].fillna(0) + 
                violation_codes_df['All Other Areas'].fillna(0)
            ) / 2
            violation_codes_df.drop(columns=['Violation Code', 'Manhattan 96th St. & Below', 'All Other Areas'], errors='ignore', inplace=True)
            df = pd.merge(df, violation_codes_df, on='violation_type', how='left')
            logging.info(f"Merged violation codes. DF shape: {df.shape}")
        
        # --- Street Segments Features ---
        street_segments_df = load_data(os.path.join(aux_data_dir, 'nyc_street_segments.csv'), 'Street Segments')
        if not street_segments_df.empty:
            street_segments_agg = street_segments_df.groupby('Street Name').agg(
                street_segment_length_sum=('Segment Length', 'sum'),
                street_speed_limit_mean=('Speed Limit', 'mean'),
                street_num_lanes_mean=('Number of Lanes', 'mean'),
                borough_ss=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            street_segments_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, street_segments_agg, on='street_name', how='left')
            logging.info(f"Merged street segments. DF shape: {df.shape}")
            
        # --- Parking Zones Features ---
        parking_zones_df = load_data(os.path.join(aux_data_dir, 'nyc_parking_zones.csv'), 'Parking Zones')
        if not parking_zones_df.empty:
            parking_zones_agg = parking_zones_df.groupby('Street Name').agg(
                num_parking_zones=('Parking Zone', 'count'),
                avg_max_duration_parking=('Max Duration', 'mean'),
                borough_pz=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            parking_zones_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, parking_zones_agg, on='street_name', how='left')

            # Consolidate borough information
            if 'borough_ss' in df.columns and 'borough_pz' in df.columns:
                df['borough'] = df['borough_ss'].fillna(df['borough_pz'])
            elif 'borough_ss' in df.columns:
                 df['borough'] = df['borough_ss']
            elif 'borough_pz' in df.columns:
                 df['borough'] = df['borough_pz']
            else: # If no borough from aux data, initialize
                df['borough'] = np.nan
            
            df.drop(columns=['borough_ss', 'borough_pz'], errors='ignore', inplace=True)
            logging.info(f"Merged parking zones. DF shape: {df.shape}")

        # --- Traffic Counts Features ---
        traffic_counts_df = load_data(os.path.join(aux_data_dir, 'traffic_counts_nyc.csv'), 'Traffic Counts')
        if not traffic_counts_df.empty:
            traffic_counts_agg = traffic_counts_df.groupby('Street Name').agg(
                avg_vehicle_count=('Vehicle Count', 'mean'),
                max_vehicle_count=('Vehicle Count', 'max'),
                std_vehicle_count=('Vehicle Count', 'std')
            ).reset_index()
            traffic_counts_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, traffic_counts_agg, on='street_name', how='left')
            logging.info(f"Merged traffic counts. DF shape: {df.shape}")

        # --- Census Tracts Features ---
        # Ensure 'borough' column exists for merging census data
        if 'borough' not in df.columns:
            df['borough'] = np.nan # Create it if not already present from other merges
        
        census_tracts_df = load_data(os.path.join(aux_data_dir, 'nyc_census_tracts.csv'), 'Census Tracts')
        if not census_tracts_df.empty:
            census_borough_agg = census_tracts_df.groupby('Borough').agg(
                total_population_borough=('Total Population', 'sum'),
                median_household_income_borough=('Median Household Income', 'mean'),
                poverty_rate_borough=('Poverty Rate', 'mean')
            ).reset_index()
            df = pd.merge(df, census_borough_agg, on='Borough', how='left')
            logging.info(f"Merged census tracts. DF shape: {df.shape}")
        else:
            logging.warning("Census tracts data not available or empty.")

        logging.info("Finished adding auxiliary features.")
        return df

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations for 2023 using RandomForestRegressor.")
    parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Optional: Path to the 2023 test/evaluation data CSV. If provided, predictions will be generated.")
    parser.add_argument("--aux-data-dir", type=str, default="./input",
                        help="Directory containing auxiliary data CSV files.")
    
    args = parser.parse_args()

    logging.info(f"Starting prediction pipeline with train_path: {args.train_path}")

    # Load 2022 training data
    train_2022_raw = load_data(args.train_path, '2022 Training Data')
    if train_2022_raw.empty:
        logging.error("Training data is empty or could not be loaded. Exiting.")
        return

    # Initialize Feature Engineer
    fe = FeatureEngineer()

    # Fit feature engineer on the full 2022 data and get processed features and target
    X_full_2022, y_full_2022 = fe.fit(train_2022_raw, args.aux_data_dir)
    
    # Split 2022 data into training and validation sets for development evaluation
    X_train, X_val, y_train, y_val = train_test_split(
        X_full_2022, y_full_2022, test_size=0.2, random_state=42
    )
    
    logging.info(f"Training data shape: {X_train.shape}, Validation data shape: {X_val.shape}")

    # --- Model Training ---
    logging.info("Training RandomForestRegressor model...")
    # Using parameters from the model description example
    rf_model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1, min_samples_leaf=5)
    rf_model.fit(X_train, y_train)
    logging.info("Model training complete.")

    # --- Validation Prediction and Evaluation ---
    val_predictions = rf_model.predict(X_val)
    val_predictions[val_predictions < 0] = 0 # Ensure predictions are non-negative
    val_predictions = np.round(val_predictions).astype(int) # Round to nearest integer

    val_rmse = np.sqrt(mean_squared_error(y_val, val_predictions))
    print(f"Final Validation Performance: {val_rmse:.4f}")

    # --- 2023 Prediction if test-path is provided ---
    if args.test_path:
        logging.info(f"Processing test data from {args.test_path} for 2023 predictions.")
        test_2023_raw = load_data(args.test_path, '2023 Test Data')
        if test_2023_raw.empty:
            logging.warning("Test data is empty or not found. Skipping 2023 predictions.")
            return

        # Keep original key columns for submission output
        submission_keys_raw = test_2023_raw[['Street Name', 'Violation Description']].copy()
        
        # Transform test data using the *fitted* feature engineer
        X_test = fe.transform(test_2023_raw.copy(), args.aux_data_dir)

        # Report unseen key pairs in the test set
        test_street_violation_pairs = set(
            submission_keys_raw.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1)
        )
        unseen_pairs_count = len(test_street_violation_pairs - fe.trained_street_violation_pairs)
        logging.info(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_pairs_count}")
        # Handling of unseen pairs: LabelEncoder maps unseen categories to -1, which RandomForest treats as a distinct numerical value.
        # This allows the model to make predictions even for completely new street/violation combinations.

        # Make predictions on the transformed test data
        predictions_2023 = rf_model.predict(X_test)
        predictions_2023[predictions_2023 < 0] = 0 # Ensure non-negative counts
        predictions_2023 = np.round(predictions_2023).astype(int) # Round to integer counts

        # Create submission file
        submission_df = submission_keys_raw
        submission_df.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type'
        }, inplace=True)
        submission_df['predicted_count'] = predictions_2023
        submission_df.to_csv('submission.csv', index=False)
        logging.info("Generated submission.csv with 2023 predictions.")

        # Evaluate if actual counts are present in the provided test/eval file
        # Check if 'actual_violation_count' was stored during _process_core_data or transform
        if 'actual_violation_count' in test_2023_raw.columns:
            test_rmse = np.sqrt(mean_squared_error(test_2023_raw['actual_violation_count'], predictions_2023))
            print(f"RMSE on provided test/eval data: {test_rmse:.4f}")
            
    else:
        logging.info("No test-path provided. Skipping 2023 predictions and submission file generation.")

if __name__ == '__main__':
    main()
