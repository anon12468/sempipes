
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
from catboost import CatBoostRegressor, Pool
import logging
import os

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def rmse(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))

def load_data(file_path, columns=None, dtypes=None):
    """Loads data from a CSV file."""
    if not os.path.exists(file_path):
        logging.error(f"File not found: {file_path}")
        raise FileNotFoundError(f"File not found: {file_path}")
    logging.info(f"Loading data from {file_path}")
    df = pd.read_csv(file_path, usecols=columns, dtype=dtypes)
    logging.info(f"Loaded {len(df)} rows from {file_path}")
    return df

def preprocess_data(df, street_encoder, violation_encoder, is_training=True):
    """Encodes categorical features."""
    if is_training:
        df['Street Name Encoded'] = street_encoder.fit_transform(df['Street Name'])
        df['Violation Description Encoded'] = violation_encoder.fit_transform(df['Violation Description'])
    else:
        # Handle unseen categories during prediction
        df['Street Name Encoded'] = df['Street Name'].map(lambda s: street_encoder.transform([s])[0] if s in street_encoder.classes_ else -1)
        df['Violation Description Encoded'] = df['Violation Description'].map(lambda s: violation_encoder.transform([s])[0] if s in violation_encoder.classes_ else -1)
        
        # For unseen values, CatBoost can handle them if they are represented by a specific value (e.g., -1)
        # or it can be configured to treat them as a new category. Here we map them to -1.
        logging.info(f"Mapped {df[df['Street Name Encoded'] == -1].shape[0]} unseen street names to -1.")
        logging.info(f"Mapped {df[df['Violation Description Encoded'] == -1].shape[0]} unseen violation descriptions to -1.")
    return df

def feature_engineer(df):
    """
    Augments the dataset with additional features.
    In a real scenario, this would involve joining with external tables.
    For this simplified example, we'll create some synthetic features
    or placeholder features that would typically come from augmentation.
    """
    logging.info("Starting feature engineering.")
    
    # Placeholder for 'time_of_day_category' (e.g., from violation_time if available)
    # Since we don't have a time column, we'll create a dummy one for demonstration.
    df['day_of_week_avg_violations'] = df.groupby(['Street Name', 'Violation Description'])['violation_count'].transform('mean')
    df['street_avg_violations'] = df.groupby('Street Name')['violation_count'].transform('mean')
    df['violation_type_avg_violations'] = df.groupby('Violation Description')['violation_count'].transform('mean')
    
    # Interaction features
    df['street_violation_interaction'] = df['street_avg_violations'] * df['violation_type_avg_violations']

    logging.info("Feature engineering completed.")
    return df

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations for 2023.")
    parser.add_argument("--train-path", type=str, default="input/violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Optional: Path to the 2023 test/evaluation data CSV. If provided, predictions will be generated and RMSE reported if 'violation_count' is present.")
    parser.add_argument("--validation-size", type=float, default=0.2,
                        help="Proportion of training data to use for validation.")
    parser.add_argument("--random-state", type=int, default=42,
                        help="Random state for reproducibility.")

    args = parser.parse_args()

    # Load training data
    try:
        train_df = load_data(args.train_path)
    except FileNotFoundError as e:
        logging.error(f"Training data file not found: {e}")
        return

    # Rename columns for easier access
    train_df = train_df.rename(columns={
        'Street Name': 'Street Name',
        'Violation Description': 'Violation Description',
        'violation_count': 'violation_count'
    })

    # Subsampling (if needed for large datasets, here for demonstration)
    # train_df = train_df.sample(frac=0.5, random_state=args.random_state).reset_index(drop=True)
    # logging.info(f"Subsampled training data to {len(train_df)} rows.")

    # Feature Engineering on training data to create aggregate features
    train_df_fe = feature_engineer(train_df.copy()) # Apply FE before splitting to calculate aggregates correctly

    # Encode categorical features
    street_encoder = LabelEncoder()
    violation_encoder = LabelEncoder()
    
    train_df_processed = preprocess_data(train_df_fe.copy(), street_encoder, violation_encoder, is_training=True)

    # Define features and target
    features = [
        'Street Name Encoded',
        'Violation Description Encoded',
        'day_of_week_avg_violations',
        'street_avg_violations',
        'violation_type_avg_violations',
        'street_violation_interaction'
    ]
    target = 'violation_count'

    # Split training data into training and validation sets
    X_train, X_val, y_train, y_val = train_test_split(
        train_df_processed[features],
        train_df_processed[target],
        test_size=args.validation_size,
        random_state=args.random_state
    )

    logging.info(f"Training data shape: {X_train.shape}")
    logging.info(f"Validation data shape: {X_val.shape}")

    # CatBoost model training
    cat_features = ['Street Name Encoded', 'Violation Description Encoded']
    
    # Initialize CatBoostRegressor with appropriate parameters
    # Using 'RMSE' as loss function for regression tasks
    # Increased iterations for potentially better performance, but balanced with early stopping
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=8,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=args.random_state,
        verbose=100,
        early_stopping_rounds=50,
        cat_features=cat_features,
        thread_count=-1 # Use all available CPU cores
    )

    logging.info("Starting model training.")
    model.fit(X_train, y_train, eval_set=(X_val, y_val), early_stopping_rounds=50)
    logging.info("Model training completed.")

    # Evaluate on validation set
    val_predictions = model.predict(X_val)
    # Ensure predictions are non-negative
    val_predictions[val_predictions < 0] = 0
    final_validation_score = rmse(y_val, val_predictions)
    logging.info(f"Final Validation Performance: {final_validation_score}")
    print(f"Final Validation Performance: {final_validation_score}")

    # If test-path is provided, generate predictions
    if args.test_path:
        logging.info(f"Processing test data from {args.test_path}")
        try:
            test_df = load_data(args.test_path)
        except FileNotFoundError as e:
            logging.error(f"Test data file not found: {e}")
            return

        original_test_columns = test_df.columns.tolist()
        test_has_target = 'violation_count' in original_test_columns

        test_df_copy = test_df.copy() # Work on a copy

        # Rename columns for consistency
        test_df_copy = test_df_copy.rename(columns={
            'Street Name': 'Street Name',
            'Violation Description': 'Violation Description'
        })
        
        # Calculate unseen key pairs
        train_keys = set(train_df_processed.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1))
        test_keys = set(test_df_copy.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1))
        unseen_keys = test_keys - train_keys
        num_unseen = len(unseen_keys)
        logging.info(f"Number of unseen (street_name, violation_type) pairs in test set: {num_unseen}")

        # To handle unseen keys gracefully, we need to ensure the feature engineering
        # and encoding steps can assign appropriate values (e.g., -1 for encoded features).
        # For aggregate features, a simple strategy is to fill NaNs (which would occur for unseen pairs)
        # with a default value like the overall mean or 0.

        # Create placeholder violation_count for feature engineering if not present
        if not test_has_target:
            test_df_copy['violation_count'] = np.nan # Temporarily add for FE if target is missing
        
        # Feature Engineering on test data
        test_df_fe = feature_engineer(test_df_copy)
        
        # If 'violation_count' was added temporarily for FE, remove it before encoding
        if not test_has_target:
            test_df_fe = test_df_fe.drop(columns=['violation_count'])
            
        # Fill NaN values that might arise from feature engineering (e.g., for unseen street/violation aggregates)
        for col in ['day_of_week_avg_violations', 'street_avg_violations', 'violation_type_avg_violations', 'street_violation_interaction']:
            if col in test_df_fe.columns:
                if col in train_df_processed.columns:
                    median_val = train_df_processed[col].median()
                    test_df_fe[col] = test_df_fe[col].fillna(median_val)
                else:
                    test_df_fe[col] = test_df_fe[col].fillna(0) # Fallback if col not in train (shouldn't happen with current FE)


        # Encode categorical features for test data
        test_df_processed = preprocess_data(test_df_fe, street_encoder, violation_encoder, is_training=False)

        # Predict on test data
        X_test = test_df_processed[features]
        test_predictions = model.predict(X_test)
        test_predictions[test_predictions < 0] = 0 # Ensure non-negative predictions

        # Create submission file
        submission_df = pd.DataFrame({
            'street_name': test_df_copy['Street Name'],
            'violation_type': test_df_copy['Violation Description'],
            'predicted_count': test_predictions.round().astype(int) # Round and convert to int for count
        })
        submission_df.to_csv("submission.csv", index=False)
        logging.info("Predictions saved to submission.csv")

        # If 'violation_count' is present in the test file, calculate RMSE
        if test_has_target:
            y_test_true = test_df['violation_count']
            test_rmse = rmse(y_test_true, test_predictions)
            logging.info(f"RMSE on test data: {test_rmse}")
        else:
            logging.info("Test file does not contain 'violation_count'. Skipping RMSE calculation for test data.")

    logging.info("Script finished.")

if __name__ == "__main__":
    main()
