
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import argparse
import os
import logging

# Set up logging for better visibility during execution
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Helper function to load data safely ---
def load_data(file_path, df_name="DataFrame"):
    """
    Loads a CSV file into a pandas DataFrame.
    Handles file not found errors and general exceptions during loading.
    """
    if not os.path.exists(file_path):
        logging.warning(f"File not found at {file_path} for {df_name}. Returning empty DataFrame.")
        return pd.DataFrame()
    try:
        df = pd.read_csv(file_path)
        logging.info(f"Successfully loaded {df_name} from {file_path} with {len(df)} rows.")
        return df
    except Exception as e:
        logging.error(f"Error loading {file_path} for {df_name}: {e}. Returning empty DataFrame.")
        return pd.DataFrame()

# --- Feature Engineering and Preprocessing Class ---
class FeatureEngineer:
    """
    Handles loading auxiliary data, creating new features, and imputing missing values
    for both training and prediction datasets.
    It prepares data suitable for RandomForest, which requires numerical input.
    """
    def __init__(self):
        self.trained_street_violation_pairs = None # To track unseen pairs in test
        self.feature_columns = [] # To store names of final features for the model
        
        # Label encoders for categorical features
        self.le_street = LabelEncoder()
        self.le_violation = LabelEncoder()
        self.le_borough = LabelEncoder()
        
    def fit(self, df_train_raw, aux_data_dir="./input"):
        """
        Fits the feature engineer on the raw training data.
        Performs feature creation, imputation, and prepares features for RandomForest.
        Returns processed features (X) and target (y) for training.
        """
        logging.info("Fitting FeatureEngineer...")
        
        df = df_train_raw.copy()
        # Rename core columns early for consistency throughout feature engineering
        df.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type'
        }, inplace=True)

        # Store unique (street_name, violation_type) pairs from training for unseen pair tracking
        self.trained_street_violation_pairs = set(
            df.apply(lambda row: (row['street_name'], row['violation_type']), axis=1)
        )
        
        # Process core data and add auxiliary features
        df = self._add_auxiliary_features(df, aux_data_dir)
        
        # Handle target column
        target_column_name = 'violation_count'
        y_train = df[target_column_name]
        df.drop(columns=[target_column_name], inplace=True) # Drop target from features

        # Identify categorical columns for encoding
        categorical_cols_to_encode = ['street_name', 'violation_type']
        if 'borough' in df.columns:
            categorical_cols_to_encode.append('borough')
        else:
            logging.warning("No 'borough' column found during feature engineering in train. 'borough' will not be used as an encoded feature.")

        # Fill NaNs for categorical columns before fitting LabelEncoders
        df['street_name'].fillna('UNKNOWN_STREET', inplace=True)
        df['violation_type'].fillna('UNKNOWN_VIOLATION', inplace=True)
        if 'borough' in df.columns:
            df['borough'].fillna('UNKNOWN_BOROUGH', inplace=True)
        
        # Fit LabelEncoders
        self.le_street.fit(df['street_name'])
        self.le_violation.fit(df['violation_type'])
        if 'borough' in df.columns:
            self.le_borough.fit(df['borough'])
        
        # Create encoded features
        df['street_name_encoded'] = self.le_street.transform(df['street_name'])
        df['violation_type_encoded'] = self.le_violation.transform(df['violation_type'])
        if 'borough' in df.columns:
            df['borough_encoded'] = self.le_borough.transform(df['borough'])
        else:
            # If borough was not in training (even after aux merge), assign a default encoded value
            df['borough_encoded'] = -1 

        # Impute missing numerical values
        # Exclude encoded columns from this imputation as they are explicitly assigned
        numerical_cols = df.select_dtypes(include=np.number).columns.tolist()
        for col in numerical_cols:
            if col not in ['street_name_encoded', 'violation_type_encoded', 'borough_encoded']:
                df[col].fillna(0, inplace=True) # Simple imputation with 0
        
        # Define the final feature columns for the model
        # Select all numerical columns, including the newly encoded ones.
        # Exclude the original string categorical columns as RandomForest needs numerical input.
        
        # Collect all numerical columns after imputation and encoding
        self.feature_columns = [
            col for col in df.select_dtypes(include=np.number).columns.tolist()
            if col not in [target_column_name] # Ensure target is not in features if it was passed through
        ]
        
        self.feature_columns.sort() # Sort to ensure consistent order
        logging.info(f"Identified {len(self.feature_columns)} numerical features for RandomForestRegressor: {self.feature_columns}")
        return df[self.feature_columns], y_train

    def transform(self, df_data_raw, aux_data_dir="./input"):
        """
        Transforms new raw data (e.g., test/evaluation data) using the fitted feature engineer.
        Applies feature creation and imputation based on training data.
        """
        logging.info("Transforming data using fitted FeatureEngineer...")
        
        df = df_data_raw.copy()

        # Rename core columns early for consistency
        df.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type'
        }, inplace=True)

        df = self._add_auxiliary_features(df, aux_data_dir)
        
        # Fill NaNs for categorical columns before encoding
        df['street_name'].fillna('UNKNOWN_STREET', inplace=True)
        df['violation_type'].fillna('UNKNOWN_VIOLATION', inplace=True)
        
        # Ensure 'borough' column exists for consistent encoding, even if it wasn't merged from aux data
        if 'borough' not in df.columns:
             df['borough'] = 'UNKNOWN_BOROUGH' # Provide a default string value for consistency
        df['borough'].fillna('UNKNOWN_BOROUGH', inplace=True)

        # Apply LabelEncoders, handling unseen categories with -1
        # It's crucial that self.le_street/violation/borough are fitted on 'UNKNOWN_STREET'/'UNKNOWN_VIOLATION'/'UNKNOWN_BOROUGH'
        # so these values have a mapping.
        
        df['street_name_encoded'] = df['street_name'].apply(
            lambda x: self.le_street.transform([x])[0] if x in self.le_street.classes_ else -1
        )
        df['violation_type_encoded'] = df['violation_type'].apply(
            lambda x: self.le_violation.transform([x])[0] if x in self.le_violation.classes_ else -1
        )
        
        # Only apply borough encoding if the encoder was actually fitted during training
        if hasattr(self.le_borough, 'classes_') and len(self.le_borough.classes_) > 0: # check if it was fitted
            df['borough_encoded'] = df['borough'].apply(
                lambda x: self.le_borough.transform([x])[0] if x in self.le_borough.classes_ else -1
            )
        else:
            df['borough_encoded'] = -1

        # Impute missing numerical values
        numerical_cols = df.select_dtypes(include=np.number).columns.tolist()
        for col in numerical_cols:
            if col not in ['street_name_encoded', 'violation_type_encoded', 'borough_encoded']:
                df[col].fillna(0, inplace=True)
            
        # Ensure all feature columns from training are present and in order
        # Add missing features that were in training but not in test with a default value (e.g., 0)
        # Drop features in test that were not in training.
        
        # Create a list of columns that should be present for prediction
        expected_feature_cols = set(self.feature_columns)
        
        # Add missing features to df with default value 0
        for col in expected_feature_cols:
            if col not in df.columns:
                df[col] = 0
                logging.warning(f"Added missing feature '{col}' to test data with 0.")
        
        # Drop extra columns from test data that are not in the expected feature set
        # Keep original string columns if they are still present from initial data load for debugging/inspection,
        # but ensure they are not passed to the model.
        cols_to_drop = [col for col in df.columns if col not in expected_feature_cols and col not in ['street_name', 'violation_type', 'borough']]
        df.drop(columns=cols_to_drop, errors='ignore', inplace=True)

        return df[self.feature_columns] # Return only the features the model was trained on

    def _add_auxiliary_features(self, df, aux_data_dir):
        """
        Loads and merges auxiliary data to enrich the main DataFrame with additional features.
        Assumes 'street_name' and 'violation_type' are already present in df.
        """
        logging.info("Adding auxiliary features.")

        # --- Violation Codes Features ---
        violation_codes_df = load_data(os.path.join(aux_data_dir, 'violation_codes.csv'), 'Violation Codes')
        if not violation_codes_df.empty:
            violation_codes_df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
            violation_codes_df['fine_amount_avg'] = (
                violation_codes_df['Manhattan 96th St. & Below'].fillna(0) + 
                violation_codes_df['All Other Areas'].fillna(0)
            ) / 2
            violation_codes_df.drop(columns=['Violation Code', 'Manhattan 96th St. & Below', 'All Other Areas'], errors='ignore', inplace=True)
            df = pd.merge(df, violation_codes_df, on='violation_type', how='left')
            logging.info(f"Merged violation codes. DF shape: {df.shape}")
        
        # --- Street Segments Features ---
        street_segments_df = load_data(os.path.join(aux_data_dir, 'nyc_street_segments.csv'), 'Street Segments')
        if not street_segments_df.empty:
            street_segments_agg = street_segments_df.groupby('Street Name').agg(
                street_segment_length_sum=('Segment Length', 'sum'),
                street_speed_limit_mean=('Speed Limit', 'mean'),
                street_num_lanes_mean=('Number of Lanes', 'mean'),
                borough_ss=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            street_segments_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, street_segments_agg, on='street_name', how='left')
            logging.info(f"Merged street segments. DF shape: {df.shape}")
            
        # --- Parking Zones Features ---
        parking_zones_df = load_data(os.path.join(aux_data_dir, 'nyc_parking_zones.csv'), 'Parking Zones')
        if not parking_zones_df.empty:
            parking_zones_agg = parking_zones_df.groupby('Street Name').agg(
                num_parking_zones=('Parking Zone', 'count'),
                avg_max_duration_parking=('Max Duration', 'mean'),
                borough_pz=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            parking_zones_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, parking_zones_agg, on='street_name', how='left')

            # Consolidate borough information from street_segments and parking_zones
            if 'borough_ss' in df.columns and 'borough_pz' in df.columns:
                df['borough'] = df['borough_ss'].fillna(df['borough_pz'])
            elif 'borough_ss' in df.columns:
                 df['borough'] = df['borough_ss']
            elif 'borough_pz' in df.columns:
                 df['borough'] = df['borough_pz']
            # else: if no borough from aux data, it remains np.nan or non-existent for now
            
            df.drop(columns=['borough_ss', 'borough_pz'], errors='ignore', inplace=True)
            logging.info(f"Consolidated borough info. DF shape: {df.shape}")

        # --- Traffic Counts Features ---
        traffic_counts_df = load_data(os.path.join(aux_data_dir, 'traffic_counts_nyc.csv'), 'Traffic Counts')
        if not traffic_counts_df.empty:
            traffic_counts_agg = traffic_counts_df.groupby('Street Name').agg(
                avg_vehicle_count=('Vehicle Count', 'mean'),
                max_vehicle_count=('Vehicle Count', 'max'),
                std_vehicle_count=('Vehicle Count', 'std')
            ).reset_index()
            traffic_counts_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, traffic_counts_agg, on='street_name', how='left')
            logging.info(f"Merged traffic counts. DF shape: {df.shape}")

        # --- Census Tracts Features ---
        census_tracts_df = load_data(os.path.join(aux_data_dir, 'nyc_census_tracts.csv'), 'Census Tracts')
        if not census_tracts_df.empty:
            census_borough_agg = census_tracts_df.groupby('Borough').agg(
                total_population_borough=('Total Population', 'sum'),
                median_household_income_borough=('Median Household Income', 'mean'),
                poverty_rate_borough=('Poverty Rate', 'mean')
            ).reset_index()
            census_borough_agg.rename(columns={'Borough': 'borough'}, inplace=True) # Rename for merging
            df = pd.merge(df, census_borough_agg, on='borough', how='left')
            logging.info(f"Merged census tracts. DF shape: {df.shape}")
        else:
            logging.warning("Census tracts data not available or empty.")

        logging.info("Finished adding auxiliary features.")
        return df

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations for 2023 using RandomForestRegressor.")
    parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Optional: Path to the 2023 test/evaluation data CSV. If provided, predictions will be generated.")
    parser.add_argument("--aux-data-dir", type=str, default="./input",
                        help="Directory containing auxiliary data CSV files.")
    
    args = parser.parse_args()

    logging.info(f"Starting prediction pipeline with train_path: {args.train_path}")

    # Load 2022 training data
    train_2022_raw = load_data(args.train_path, '2022 Training Data')
    if train_2022_raw.empty:
        logging.error("Training data is empty or could not be loaded. Exiting.")
        return

    # Initialize Feature Engineer
    fe = FeatureEngineer()

    # Fit feature engineer on the full 2022 data and get processed features and target
    X_full_2022, y_full_2022 = fe.fit(train_2022_raw, args.aux_data_dir)
    
    # Split 2022 data into training and validation sets for development evaluation
    X_train, X_val, y_train, y_val = train_test_split(
        X_full_2022, y_full_2022, test_size=0.2, random_state=42
    )
    
    logging.info(f"Training data shape: {X_train.shape}, Validation data shape: {X_val.shape}")

    # --- Model Training ---
    logging.info("Training RandomForestRegressor model...")
    # Using parameters from the model description example
    rf_model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1, min_samples_leaf=5)
    rf_model.fit(X_train, y_train)
    logging.info("Model training complete.")

    # --- Validation Prediction and Evaluation ---
    val_predictions = rf_model.predict(X_val)
    val_predictions[val_predictions < 0] = 0 # Ensure predictions are non-negative
    val_predictions = np.round(val_predictions).astype(int) # Round to nearest integer

    val_rmse = np.sqrt(mean_squared_error(y_val, val_predictions))
    print(f"Final Validation Performance: {val_rmse:.4f}")

    # --- 2023 Prediction if test-path is provided ---
    if args.test_path:
        logging.info(f"Processing test data from {args.test_path} for 2023 predictions.")
        test_2023_raw = load_data(args.test_path, '2023 Test Data')
        if test_2023_raw.empty:
            logging.warning("Test data is empty or not found. Skipping 2023 predictions.")
            return

        # Store actual counts for evaluation if 'violation_count' is present in the test file
        actual_counts_for_eval = None
        if 'violation_count' in test_2023_raw.columns:
            actual_counts_for_eval = test_2023_raw['violation_count'].copy()
        
        # Keep original key columns for submission output before transformation
        submission_keys_raw = test_2023_raw[['Street Name', 'Violation Description']].copy()
        
        # Transform test data using the *fitted* feature engineer
        X_test = fe.transform(test_2023_raw.copy(), args.aux_data_dir)

        # Report unseen key pairs in the test set
        test_street_violation_pairs = set(
            submission_keys_raw.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1)
        )
        unseen_pairs_count = len(test_street_violation_pairs - fe.trained_street_violation_pairs)
        logging.info(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_pairs_count}")
        # Handling of unseen pairs: LabelEncoder maps unseen categories to -1 (if configured), 
        # which RandomForest treats as a distinct numerical value. This allows the model 
        # to make predictions even for completely new street/violation combinations.

        # Make predictions on the transformed test data
        predictions_2023 = rf_model.predict(X_test)
        predictions_2023[predictions_2023 < 0] = 0 # Ensure non-negative counts
        predictions_2023 = np.round(predictions_2023).astype(int) # Round to integer counts

        # Create submission file
        submission_df = submission_keys_raw
        submission_df.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type'
        }, inplace=True)
        submission_df['predicted_count'] = predictions_2023
        submission_df.to_csv('submission.csv', index=False)
        logging.info("Generated submission.csv with 2023 predictions.")

        # Evaluate if actual counts are present in the provided test/eval file
        if actual_counts_for_eval is not None:
            test_rmse = np.sqrt(mean_squared_error(actual_counts_for_eval, predictions_2023))
            print(f"RMSE on provided test/eval data: {test_rmse:.4f}")
            
    else:
        logging.info("No test-path provided. Skipping 2023 predictions and submission file generation.")

if __name__ == '__main__':
    main()
