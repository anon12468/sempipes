
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import catboost as cb # Although LightGBM is used, catboost is still imported
import argparse
import os
import lightgbm as lgb

# --- Configuration and Argument Parsing ---
def parse_args():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                        help="Path to the training data (2022 violations).")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Path to the test/evaluation data (optional).")
    return parser.parse_args()

# --- Feature Engineering and Data Loading ---
def load_and_engineer_features(df_path, is_training=True):
    df = pd.read_csv(df_path)

    # Standardize column names
    df.columns = [col.strip().replace(' ', '_').lower() for col in df.columns]

    # Handle missing street names
    df['street_name'] = df['street_name'].fillna('UNKNOWN')

    # Basic feature engineering
    df['violation_description_len'] = df['violation_description'].apply(len)
    df['street_name_len'] = df['street_name'].apply(len)

    # Interaction features
    df['street_violation_pair'] = df['street_name'] + '_' + df['violation_description']

    # Load augmentation tables
    # Assuming all augmentation tables are in the same directory as the main data
    input_dir = os.path.dirname(df_path)

    # Augmentation 1: street_attributes.csv
    try:
        street_attr_df = pd.read_csv(os.path.join(input_dir, 'street_attributes.csv'))
        street_attr_df.columns = [col.strip().replace(' ', '_').lower() for col in street_attr_df.columns]
        street_attr_df = street_attr_df.rename(columns={'street': 'street_name'})
        df = pd.merge(df, street_attr_df, on='street_name', how='left')
    except FileNotFoundError:
        print("Warning: street_attributes.csv not found. Skipping street attribute augmentation.")

    # Augmentation 2: violation_codes.csv
    try:
        violation_codes_df = pd.read_csv(os.path.join(input_dir, 'violation_codes.csv'))
        violation_codes_df.columns = [col.strip().replace(' ', '_').lower() for col in violation_codes_df.columns]
        violation_codes_df = violation_codes_df.rename(columns={'description': 'violation_description'})
        df = pd.merge(df, violation_codes_df, on='violation_description', how='left')
    except FileNotFoundError:
        print("Warning: violation_codes.csv not found. Skipping violation codes augmentation.")

    # Augmentation 3: census_data.csv (assuming it can be linked, e.g., by street or area)
    try:
        census_df = pd.read_csv(os.path.join(input_dir, 'census_data.csv'))
        census_df.columns = [col.strip().replace(' ', '_').lower() for col in census_df.columns]
        if 'street_name' in census_df.columns:
             df = pd.merge(df, census_df, on='street_name', how='left', suffixes=('', '_census'))
        else:
            print("Warning: 'street_name' not found in census_data.csv. Skipping direct merge.")
    except FileNotFoundError:
        print("Warning: census_data.csv not found. Skipping census data augmentation.")

    # Fill NaNs created by merges with appropriate values
    for col in df.columns:
        if df[col].dtype == 'object':
            df[col] = df[col].fillna('UNKNOWN')
        elif df[col].dtype in ['float64', 'int64']:
            df[col] = df[col].fillna(0) # Or median/mean, depending on distribution

    return df

# --- Model Training and Prediction ---
def train_predict(train_df_path, test_df_path=None):
    print("Loading and engineering features for training data...")
    train_df_full = load_and_engineer_features(train_df_path, is_training=True)

    # Define categorical features
    categorical_features = [
        'street_name',
        'violation_description',
        'street_violation_pair'
    ]
    # Add other categorical features if they resulted from merges
    for col in ['borough', 'violation_code', 'violation_group']: # Example columns from augmentations
        if col in train_df_full.columns and train_df_full[col].dtype == 'object':
            categorical_features.append(col)
    categorical_features = list(set(categorical_features)) # Remove duplicates

    # Features to use for the model
    # Initialize features with all columns except the target
    features = [col for col in train_df_full.columns if col not in ['violation_count']]
    
    # Ensure all identified categorical features are indeed in the features list
    # No need to explicitly remove 'street_violation_pair' if it's intended as a feature
    features = list(set(features)) # Remove duplicates that might arise from initial list + categorical_features
    
    # Remove target from features list if it was mistakenly included
    if 'violation_count' in features:
        features.remove('violation_count')

    # Convert categorical features to 'category' dtype for LightGBM
    for col in categorical_features:
        if col in train_df_full.columns:
            train_df_full[col] = train_df_full[col].astype('category')
            # Ensure it's in features list if it's a valid categorical feature
            if col not in features:
                features.append(col)
        else:
            print(f"Warning: Categorical feature '{col}' not found in training data. Skipping.")

    # Split 2022 data for validation
    X = train_df_full[features]
    y = train_df_full['violation_count']

    # Use grouped holdout to prevent data leakage for (street_name, violation_description) pairs
    # Create unique identifier for each group
    train_df_full['group_id'] = train_df_full['street_name'] + '_' + train_df_full['violation_description']
    unique_groups = train_df_full['group_id'].unique()
    train_groups, val_groups = train_test_split(unique_groups, test_size=0.2, random_state=42)

    X_train = train_df_full[train_df_full['group_id'].isin(train_groups)][features]
    y_train = train_df_full[train_df_full['group_id'].isin(train_groups)]['violation_count']
    X_val = train_df_full[train_df_full['group_id'].isin(val_groups)][features]
    y_val = train_df_full[train_df_full['group_id'].isin(val_groups)]['violation_count']

    # Ensure feature sets are consistent
    X_val = X_val[X_train.columns] # This aligns columns after group_id drop in previous lines

    print(f"Training data shape: {X_train.shape}")
    print(f"Validation data shape: {X_val.shape}")

    # LightGBM Regressor
    model = lgb.LGBMRegressor(
        objective='regression_l1', # MAE as objective, often more robust to outliers
        metric='rmse',
        n_estimators=1000, # Increased estimators for better learning
        learning_rate=0.05,
        num_leaves=64, # Increased complexity
        max_depth=-1, # No limit on depth
        min_child_samples=20,
        subsample=0.8,
        colsample_bytree=0.8,
        random_state=42,
        n_jobs=-1,
        reg_alpha=0.1, # L1 regularization
        reg_lambda=0.1, # L2 regularization
        verbose=-1 # Suppress verbose output
    )

    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              early_stopping_rounds=50,
              categorical_feature=[col for col in categorical_features if col in X_train.columns])


    val_preds = model.predict(X_val)
    val_preds = np.maximum(0, val_preds) # Ensure non-negative predictions
    final_validation_score = np.sqrt(mean_squared_error(y_val, val_preds))
    print(f"Final Validation Performance: {final_validation_score}")

    # --- Prediction on Test Data (if provided) ---
    if test_df_path:
        print("\nLoading and engineering features for test data...")
        test_df = load_and_engineer_features(test_df_path, is_training=False)

        original_test_keys = test_df[['street_name', 'violation_description']].copy()

        # Ensure all columns in X_train are present in test_df and have consistent types
        for col in X_train.columns:
            if col not in test_df.columns:
                # Add missing columns. Default numeric to 0. Default categorical to a known "unknown" value.
                if col in categorical_features:
                    test_df[col] = 'MISSING_IN_TEST'
                else:
                    test_df[col] = 0 # Default for numerical features
            
            # Ensure categorical features in test_df align with training categories
            if col in categorical_features:
                # Convert test_df[col] to categorical type, using the categories from X_train[col]
                # Any values in test_df[col] not found in X_train[col].cat.categories will become NaN.
                # LightGBM handles NaN as a separate category by default.
                test_df[col] = pd.Categorical(test_df[col], categories=X_train[col].cat.categories)
            # For non-categorical features, ensure type consistency if needed, though pd.read_csv usually infers.

        # Ensure the order of columns matches training data
        X_test = test_df[X_train.columns]

        test_preds = model.predict(X_test)
        test_preds = np.maximum(0, test_preds) # Ensure non-negative predictions

        # Report unseen key pairs
        train_keys = set(train_df_full['street_name'] + '_' + train_df_full['violation_description'])
        test_keys = set(original_test_keys['street_name'] + '_' + original_test_keys['violation_description'])
        unseen_keys_count = len(test_keys - train_keys)
        print(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_keys_count}")
        print("Unseen pairs were handled by aligning categories with training data and allowing LightGBM to process NaN for new categories.")

        submission_df = pd.DataFrame({
            'street_name': original_test_keys['street_name'],
            'violation_type': original_test_keys['violation_description'],
            'predicted_count': test_preds
        })
        submission_df.to_csv('submission.csv', index=False)
        print("Predictions saved to submission.csv")

        # If 'violation_count' is present in the test_df, calculate RMSE
        if 'violation_count' in test_df.columns:
            true_counts = test_df['violation_count'].values
            test_rmse = np.sqrt(mean_squared_error(true_counts, test_preds))
            print(f"Test RMSE: {test_rmse}")

    return final_validation_score

if __name__ == "__main__":
    args = parse_args()
    _ = train_predict(args.train_path, args.test_path)
