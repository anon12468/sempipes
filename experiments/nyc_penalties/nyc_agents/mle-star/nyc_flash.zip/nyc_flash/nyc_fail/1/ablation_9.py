
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import argparse
import os
import logging
import sys

# Set up logging for better visibility during execution
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Create Dummy Data Function ---
def create_dummy_data(base_dir="./input"):
    """
    Creates minimal dummy CSV files required for the script to run if they don't already exist.
    """
    os.makedirs(base_dir, exist_ok=True)
    logging.info(f"Creating dummy data in {base_dir}...")

    # violations_per_street_2022.csv - Primary training data
    df_train = pd.DataFrame({
        'Street Name': ['MAIN ST', 'OAK AVE', 'MAIN ST', 'PINE RD', 'ELM ST', 'MAIN ST', 'CEDAR BLVD', 'MAIN ST'],
        'Violation Description': ['PARKING VIOLATION', 'NO PARKING', 'DOUBLE PARKING', 'PARKING VIOLATION', 'NO PARKING', 'PARKING VIOLATION', 'STOPPING VIOLATION', 'NO PARKING'],
        'violation_count': [100, 50, 150, 75, 120, 90, 60, 110],
        'Borough': ['MANHATTAN', 'BROOKLYN', 'MANHATTAN', 'QUEENS', 'BRONX', 'MANHATTAN', 'STATEN ISLAND', 'MANHATTAN']
    })
    df_train.to_csv(os.path.join(base_dir, 'violations_per_street_2022.csv'), index=False)

    # violation_codes.csv
    df_vc = pd.DataFrame({
        'Violation Description': ['PARKING VIOLATION', 'NO PARKING', 'DOUBLE PARKING', 'STOPPING VIOLATION', 'STANDPIPE VIOLATION'],
        'Violation Code': [1, 2, 3, 4, 5],
        'Manhattan 96th St. & Below': [50, 75, 100, 60, 80],
        'All Other Areas': [30, 45, 60, 40, 50]
    })
    df_vc.to_csv(os.path.join(base_dir, 'violation_codes.csv'), index=False)

    # nyc_street_segments.csv
    df_ss = pd.DataFrame({
        'Street Name': ['MAIN ST', 'OAK AVE', 'PINE RD', 'ELM ST', 'CEDAR BLVD', 'BROADWAY'],
        'Segment Length': [1.2, 0.8, 1.5, 0.9, 1.1, 2.0],
        'Speed Limit': [25, 30, 20, 35, 30, 25],
        'Number of Lanes': [2, 1, 3, 2, 2, 4],
        'Borough': ['MANHATTAN', 'BROOKLYN', 'QUEENS', 'BRONX', 'STATEN ISLAND', 'MANHATTAN']
    })
    df_ss.to_csv(os.path.join(base_dir, 'nyc_street_segments.csv'), index=False)

    # nyc_parking_zones.csv
    df_pz = pd.DataFrame({
        'Street Name': ['MAIN ST', 'OAK AVE', 'PINE RD', 'CEDAR BLVD', 'BROADWAY'],
        'Parking Zone': ['PZ1', 'PZ2', 'PZ3', 'PZ4', 'PZ5'],
        'Max Duration': [2, 4, 3, 2, 6],
        'Borough': ['MANHATTAN', 'BROOKLYN', 'QUEENS', 'STATEN ISLAND', 'MANHATTAN']
    })
    df_pz.to_csv(os.path.join(base_dir, 'nyc_parking_zones.csv'), index=False)

    # traffic_counts_nyc.csv
    df_tc = pd.DataFrame({
        'Street Name': ['MAIN ST', 'OAK AVE', 'ELM ST', 'PINE RD', 'BROADWAY'],
        'Vehicle Count': [1000, 500, 700, 600, 1500]
    })
    df_tc.to_csv(os.path.join(base_dir, 'traffic_counts_nyc.csv'), index=False)

    # nyc_census_tracts.csv
    df_ct = pd.DataFrame({
        'Borough': ['MANHATTAN', 'BROOKLYN', 'QUEENS', 'BRONX', 'STATEN ISLAND'],
        'Total Population': [100000, 200000, 150000, 120000, 80000],
        'Median Household Income': [80000, 60000, 70000, 50000, 75000],
        'Poverty Rate': [0.1, 0.15, 0.12, 0.2, 0.08]
    })
    df_ct.to_csv(os.path.join(base_dir, 'nyc_census_tracts.csv'), index=False)
    logging.info("Dummy data creation complete.")
    return base_dir

# --- Helper function to load data safely ---
def load_data(file_path, df_name="DataFrame"):
    """
    Loads a CSV file into a pandas DataFrame.
    Handles file not found errors and general exceptions during loading.
    Standardizes 'Borough' column name to 'borough' and converts values to uppercase.
    """
    if not os.path.exists(file_path):
        logging.warning(f"File not found at {file_path} for {df_name}. Returning empty DataFrame.")
        return pd.DataFrame()
    try:
        df = pd.read_csv(file_path)
        # Standardize 'Borough' column name to lowercase for robustness
        if 'Borough' in df.columns:
            df.rename(columns={'Borough': 'borough'}, inplace=True)
        # Ensure borough values are consistent (e.g., uppercase) for merging
        if 'borough' in df.columns:
             df['borough'] = df['borough'].astype(str).str.upper()
        logging.info(f"Successfully loaded {df_name} from {file_path} with {len(df)} rows.")
        return df
    except Exception as e:
        logging.error(f"Error loading {file_path} for {df_name}: {e}. Returning empty DataFrame.")
        return pd.DataFrame()

# --- Feature Engineering and Preprocessing Class ---
class FeatureEngineer:
    """
    Handles loading auxiliary data, creating new features, and imputing missing values
    for both training and prediction datasets.
    It prepares data suitable for RandomForest, which requires numerical input.
    Modified to support ablation studies on numerical imputation strategy and categorical astype(str).
    """
    def __init__(self, numerical_imputation_strategy='zero', categorical_astype_str=True):
        self.trained_street_violation_pairs = None # To track unseen pairs in test
        self.feature_columns = [] # To store names of final features for the model
        
        # Label encoders for categorical features
        self.le_street = LabelEncoder()
        self.le_violation = LabelEncoder()
        self.le_borough = LabelEncoder()
        
        # Keep track of original categorical column names to process them
        self._original_categorical_cols = ['street_name', 'violation_type', 'borough']

        # Ablation parameters
        self.numerical_imputation_strategy = numerical_imputation_strategy
        self.categorical_astype_str = categorical_astype_str
        self.numerical_imputation_values = {} # To store means if strategy is 'mean'

    def fit(self, df_train_raw, aux_data_dir="./input"):
        """
        Fits the feature engineer on the raw training data.
        Performs feature creation, imputation, and fits LabelEncoders.
        Returns processed features (X) and target (y) for training.
        """
        logging.info("Fitting FeatureEngineer...")
        # Store unique (street_name, violation_type) pairs from training for unseen pair tracking
        self.trained_street_violation_pairs = set(
            df_train_raw.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1)
        )
        
        # Process core data and add auxiliary features
        df_train_features = self._add_auxiliary_features(df_train_raw.copy(), aux_data_dir)
        
        # Rename core columns to be consistent
        df_train_features.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type',
            'violation_count': 'violation_count'
        }, inplace=True)
        
        # Handle target column
        target = 'violation_count'
        y_train = df_train_features[target]
        df_train_features.drop(columns=[target], inplace=True) # Drop target from features

        # Fit LabelEncoders for categorical features
        # Ensure that 'street_name', 'violation_type', 'borough' columns exist before trying to encode them.
        # Fill NaN with a placeholder before fitting LabelEncoder to avoid errors.
        street_data = df_train_features['street_name'].fillna('UNKNOWN_STREET')
        violation_data = df_train_features['violation_type'].fillna('UNKNOWN_VIOLATION')
        
        if self.categorical_astype_str:
            df_train_features['street_name_encoded'] = self.le_street.fit_transform(street_data.astype(str))
            df_train_features['violation_type_encoded'] = self.le_violation.fit_transform(violation_data.astype(str))
        else:
            df_train_features['street_name_encoded'] = self.le_street.fit_transform(street_data)
            df_train_features['violation_type_encoded'] = self.le_violation.fit_transform(violation_data)

        if 'borough' in df_train_features.columns:
            borough_data = df_train_features['borough'].fillna('UNKNOWN_BOROUGH')
            if self.categorical_astype_str:
                df_train_features['borough_encoded'] = self.le_borough.fit_transform(borough_data.astype(str))
            else:
                df_train_features['borough_encoded'] = self.le_borough.fit_transform(borough_data)
        else:
            df_train_features['borough_encoded'] = -1 # Default for missing borough
            logging.warning("No 'borough' column found during feature engineering in train. Using -1 for encoded.")

        # Impute missing numerical values (after all joins and encodings)
        numerical_cols = df_train_features.select_dtypes(include=np.number).columns
        for col in numerical_cols:
            if self.numerical_imputation_strategy == 'mean':
                mean_val = df_train_features[col].mean()
                self.numerical_imputation_values[col] = mean_val if pd.notna(mean_val) else 0 # Store mean, fall back to 0 if all NaN
                df_train_features[col].fillna(self.numerical_imputation_values[col], inplace=True)
            else: # 'zero' strategy
                df_train_features[col].fillna(0, inplace=True)
        
        # Define the final feature columns for the model
        # Exclude original string columns, and any temporary columns
        self.feature_columns = [
            col for col in df_train_features.columns
            if col not in self._original_categorical_cols and col != 'actual_violation_count'
        ]
        
        logging.info(f"Identified {len(self.feature_columns)} features for RandomForest.")
        return df_train_features[self.feature_columns], y_train

    def transform(self, df_data_raw, aux_data_dir="./input"):
        """
        Transforms new raw data (e.g., test/evaluation data) using the fitted feature engineer.
        Applies feature creation and imputation based on training data.
        """
        logging.info("Transforming data using fitted FeatureEngineer...")
        df_data_features = self._add_auxiliary_features(df_data_raw.copy(), aux_data_dir)
        
        # Store actual_violation_count if present for later evaluation
        if 'violation_count' in df_data_features.columns:
            df_data_features['actual_violation_count'] = df_data_features['violation_count']
            df_data_features.drop(columns=['violation_count'], inplace=True)

        # Rename core columns
        df_data_features.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type'
        }, inplace=True)

        # Apply LabelEncoders, handling unseen categories with -1
        def get_encoded_value(le, value):
            val_processed = str(value) if self.categorical_astype_str else value
            # Handle potential NaN values gracefully by treating them as 'UNKNOWN'
            if pd.isna(val_processed):
                val_processed = 'UNKNOWN' # Placeholder for NaN in auxiliary data, which might not be in le.classes_
            
            # Check if the value is in the known classes; if not, return -1 (or handle as 'UNKNOWN')
            # For simplicity, if 'UNKNOWN_STREET'/'UNKNOWN_VIOLATION' etc. are in le.classes_,
            # we can map unknown values to their encoding. Otherwise, -1 is a safe choice.
            # Here, we ensure 'UNKNOWN_STREET', 'UNKNOWN_VIOLATION', 'UNKNOWN_BOROUGH' are part of classes_
            # during fit by fillingna, so we should map to their encodings.
            
            # If the value itself was NaN and filled with 'UNKNOWN_STREET' before encoding in fit,
            # then 'UNKNOWN_STREET' will be in le.classes_.
            # If a completely new, unknown string value appears, it won't be in le.classes_.
            
            if val_processed in le.classes_:
                return le.transform([val_processed])[0]
            else:
                # If a new, genuinely unseen category string appears, encode it as UNKNOWN (if present) or -1
                if 'UNKNOWN_STREET' in le.classes_ and le == self.le_street:
                     return le.transform(['UNKNOWN_STREET'])[0]
                elif 'UNKNOWN_VIOLATION' in le.classes_ and le == self.le_violation:
                     return le.transform(['UNKNOWN_VIOLATION'])[0]
                elif 'UNKNOWN_BOROUGH' in le.classes_ and le == self.le_borough:
                     return le.transform(['UNKNOWN_BOROUGH'])[0]
                return -1 # Fallback for truly unseen categories not handled by specific UNKNOWN placeholders


        df_data_features['street_name_encoded'] = df_data_features['street_name'].fillna('UNKNOWN_STREET').apply(lambda x: get_encoded_value(self.le_street, x))
        df_data_features['violation_type_encoded'] = df_data_features['violation_type'].fillna('UNKNOWN_VIOLATION').apply(lambda x: get_encoded_value(self.le_violation, x))
        
        if 'borough' in df_data_features.columns:
            df_data_features['borough_encoded'] = df_data_features['borough'].fillna('UNKNOWN_BOROUGH').apply(lambda x: get_encoded_value(self.le_borough, x))
        else:
            df_data_features['borough_encoded'] = -1 # Default for missing borough
            logging.warning("No 'borough' column found during feature engineering in test. Using -1 for encoded.")

        # Impute missing numerical values
        numerical_cols = df_data_features.select_dtypes(include=np.number).columns
        for col in numerical_cols:
            if self.numerical_imputation_strategy == 'mean':
                # Use stored mean, fall back to 0 if not found (e.g., if a new numerical col appears in test)
                df_data_features[col].fillna(self.numerical_imputation_values.get(col, 0), inplace=True)
            else: # 'zero' strategy
                df_data_features[col].fillna(0, inplace=True)
            
        # Ensure all feature columns from training are present and in order
        for col in self.feature_columns:
            if col not in df_data_features.columns:
                df_data_features[col] = 0 # Add missing features with a default value (e.g., 0)
                logging.warning(f"Added missing feature '{col}' to test data with 0.")
        
        # Filter to only the feature columns known from training, and maintain their order
        return df_data_features[self.feature_columns]

    def _add_auxiliary_features(self, df, aux_data_dir):
        """
        Loads and merges auxiliary data to enrich the main DataFrame with additional features.
        """
        logging.info("Adding auxiliary features...")

        # Standardize 'Street Name' to 'street_name' and 'Violation Description' to 'violation_type' for consistent merging
        if 'Street Name' in df.columns:
            df.rename(columns={'Street Name': 'street_name'}, inplace=True)
        if 'Violation Description' in df.columns:
            df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
        if 'Borough' in df.columns: # Standardize existing borough column in main df
            df.rename(columns={'Borough': 'borough'}, inplace=True)
        
        # Ensure borough column in main df is consistent (uppercase) before merging census data
        if 'borough' in df.columns:
            df['borough'] = df['borough'].astype(str).str.upper()
        else:
            df['borough'] = np.nan # Initialize if not present

        # --- Violation Codes Features ---
        violation_codes_df = load_data(os.path.join(aux_data_dir, 'violation_codes.csv'), 'Violation Codes')
        if not violation_codes_df.empty:
            # Ensure 'Violation Description' is consistently named for merge
            if 'Violation Description' in violation_codes_df.columns:
                violation_codes_df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
            violation_codes_df['fine_amount_avg'] = (
                violation_codes_df['Manhattan 96th St. & Below'].fillna(0) + 
                violation_codes_df['All Other Areas'].fillna(0)
            ) / 2
            violation_codes_df.drop(columns=['Violation Code', 'Manhattan 96th St. & Below', 'All Other Areas'], errors='ignore', inplace=True)
            df = pd.merge(df, violation_codes_df, on='violation_type', how='left')
            logging.info(f"Merged violation codes. DF shape: {df.shape}")
        
        # --- Street Segments Features ---
        street_segments_df = load_data(os.path.join(aux_data_dir, 'nyc_street_segments.csv'), 'Street Segments')
        if not street_segments_df.empty:
            # FIX: Rename 'Street Name' to 'street_name' for auxiliary dataframes as well
            if 'Street Name' in street_segments_df.columns:
                street_segments_df.rename(columns={'Street Name': 'street_name'}, inplace=True)
            
            # Ensure borough column from aux data is uppercase for consistency if used in mode
            if 'borough' in street_segments_df.columns:
                street_segments_df['borough'] = street_segments_df['borough'].astype(str).str.upper()
            
            street_segments_agg = street_segments_df.groupby('street_name').agg(
                street_segment_length_sum=('Segment Length', 'sum'),
                street_speed_limit_mean=('Speed Limit', 'mean'),
                street_num_lanes_mean=('Number of Lanes', 'mean'),
                borough_ss=('borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            df = pd.merge(df, street_segments_agg, on='street_name', how='left')
            logging.info(f"Merged street segments. DF shape: {df.shape}")
            
        # --- Parking Zones Features ---
        parking_zones_df = load_data(os.path.join(aux_data_dir, 'nyc_parking_zones.csv'), 'Parking Zones')
        if not parking_zones_df.empty:
            # FIX: Rename 'Street Name' to 'street_name' for auxiliary dataframes
            if 'Street Name' in parking_zones_df.columns:
                parking_zones_df.rename(columns={'Street Name': 'street_name'}, inplace=True)

            # Ensure borough column from aux data is uppercase for consistency if used in mode
            if 'borough' in parking_zones_df.columns:
                parking_zones_df['borough'] = parking_zones_df['borough'].astype(str).str.upper()
            parking_zones_agg = parking_zones_df.groupby('street_name').agg(
                num_parking_zones=('Parking Zone', 'count'),
                avg_max_duration_parking=('Max Duration', 'mean'),
                borough_pz=('borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            df = pd.merge(df, parking_zones_agg, on='street_name', how='left')

            # Consolidate borough information from main df and aux sources
            # Only fill NaN in df['borough'] if it exists, otherwise it might be created later
            if 'borough' in df.columns:
                if 'borough_ss' in df.columns:
                    df['borough'] = df['borough'].fillna(df['borough_ss'])
                if 'borough_pz' in df.columns:
                    df['borough'] = df['borough'].fillna(df['borough_pz'])
            
            df.drop(columns=['borough_ss', 'borough_pz'], errors='ignore', inplace=True)
            logging.info(f"Merged parking zones. DF shape: {df.shape}")

        # --- Traffic Counts Features ---
        traffic_counts_df = load_data(os.path.join(aux_data_dir, 'traffic_counts_nyc.csv'), 'Traffic Counts')
        if not traffic_counts_df.empty:
            # FIX: Rename 'Street Name' to 'street_name' for auxiliary dataframes
            if 'Street Name' in traffic_counts_df.columns:
                traffic_counts_df.rename(columns={'Street Name': 'street_name'}, inplace=True)

            traffic_counts_agg = traffic_counts_df.groupby('street_name').agg(
                avg_vehicle_count=('Vehicle Count', 'mean'),
                max_vehicle_count=('Vehicle Count', 'max'),
                std_vehicle_count=('Vehicle Count', 'std')
            ).reset_index()
            df = pd.merge(df, traffic_counts_agg, on='street_name', how='left')
            logging.info(f"Merged traffic counts. DF shape: {df.shape}")

        # --- Census Tracts Features ---
        census_tracts_df = load_data(os.path.join(aux_data_dir, 'nyc_census_tracts.csv'), 'Census Tracts')
        if not census_tracts_df.empty:
            census_borough_agg = census_tracts_df.groupby('borough').agg(
                total_population_borough=('Total Population', 'sum'),
                median_household_income_borough=('Median Household Income', 'mean'),
                poverty_rate_borough=('Poverty Rate', 'mean')
            ).reset_index()
            # Ensure df['borough'] is uppercase for consistent merge with census data
            if 'borough' in df.columns:
                df['borough'] = df['borough'].astype(str).str.upper()
            census_borough_agg['borough'] = census_borough_agg['borough'].astype(str).str.upper()
            df = pd.merge(df, census_borough_agg, on='borough', how='left')
            logging.info(f"Merged census tracts. DF shape: {df.shape}")
        else:
            logging.warning("Census tracts data not available or empty.")

        logging.info("Finished adding auxiliary features.")
        return df

def run_ablation_experiment(
    rf_n_jobs=-1,
    numerical_imputation_strategy='zero',
    categorical_astype_str=True,
    enable_post_processing=True # Controls clipping to 0 and rounding to int
):
    """
    Runs the full training and validation pipeline with specified ablation parameters.
    Returns the validation RMSE.
    """
    # Load 2022 training data
    train_2022_raw = load_data("./input/violations_per_street_2022.csv", '2022 Training Data')
    if train_2022_raw.empty:
        logging.error("Training data is empty or could not be loaded. Exiting experiment.")
        return np.nan

    fe = FeatureEngineer(
        numerical_imputation_strategy=numerical_imputation_strategy,
        categorical_astype_str=categorical_astype_str
    )

    X_full_2022, y_full_2022 = fe.fit(train_2022_raw, "./input")
    
    X_train, X_val, y_train, y_val = train_test_split(
        X_full_2022, y_full_2022, test_size=0.2, random_state=42
    )
    
    rf_model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=rf_n_jobs, min_samples_leaf=5)
    rf_model.fit(X_train, y_train)

    val_predictions = rf_model.predict(X_val)
    
    if enable_post_processing:
        val_predictions[val_predictions < 0] = 0 # Ensure predictions are non-negative
        val_predictions = np.round(val_predictions).astype(int) # Round to nearest integer
    # If enable_post_processing is False, predictions remain as raw floats (potentially negative)

    val_rmse = np.sqrt(mean_squared_error(y_val, val_predictions))
    return val_rmse

# --- Main function to orchestrate ablation study ---
if __name__ == '__main__':
    # Create dummy data before running any experiments
    create_dummy_data()

    results = {}

    # 1. Baseline Experiment (Original Configuration)
    logging.info("--- Running Baseline Experiment ---")
    baseline_rmse = run_ablation_experiment(
        rf_n_jobs=-1,
        numerical_imputation_strategy='zero',
        categorical_astype_str=True,
        enable_post_processing=True
    )
    results['Baseline (Original Config)'] = baseline_rmse
    print(f"Baseline (Original Config) Validation RMSE: {baseline_rmse:.4f}")

    # 2. Ablation 1: RandomForestRegressor n_jobs=1 (instead of -1 for all cores)
    logging.info("--- Running Ablation 1: RandomForestRegressor n_jobs=1 ---")
    ablation1_rmse = run_ablation_experiment(
        rf_n_jobs=1, # Changed from -1 to 1
        numerical_imputation_strategy='zero',
        categorical_astype_str=True,
        enable_post_processing=True
    )
    results['Ablation 1 (RF n_jobs=1)'] = ablation1_rmse
    print(f"Ablation 1 (RF n_jobs=1) Validation RMSE: {ablation1_rmse:.4f} (Change from Baseline: {ablation1_rmse - baseline_rmse:.4f})")

    # 3. Ablation 2: Numerical Imputation with Mean (instead of zero)
    logging.info("--- Running Ablation 2: Numerical Imputation with Mean ---")
    ablation2_rmse = run_ablation_experiment(
        rf_n_jobs=-1,
        numerical_imputation_strategy='mean', # Changed from 'zero' to 'mean'
        categorical_astype_str=True,
        enable_post_processing=True
    )
    results['Ablation 2 (Numerical Imputation: Mean)'] = ablation2_rmse
    print(f"Ablation 2 (Numerical Imputation: Mean) Validation RMSE: {ablation2_rmse:.4f} (Change from Baseline: {ablation2_rmse - baseline_rmse:.4f})")

    # 4. Ablation 3: Remove .astype(str) for categorical features before LabelEncoding
    logging.info("--- Running Ablation 3: Remove .astype(str) for categorical features ---")
    ablation3_rmse = run_ablation_experiment(
        rf_n_jobs=-1,
        numerical_imputation_strategy='zero',
        categorical_astype_str=False, # Changed from True to False
        enable_post_processing=True
    )
    results['Ablation 3 (No .astype(str) for categorical)'] = ablation3_rmse
    print(f"Ablation 3 (No .astype(str) for categorical) Validation RMSE: {ablation3_rmse:.4f} (Change from Baseline: {ablation3_rmse - baseline_rmse:.4f})")

    # Determine the most impactful part
    most_impactful_change = "None identified from these ablations"
    max_abs_change = 0
    
    # Calculate impact of each ablation relative to the baseline
    for ablation_name, rmse_val in results.items():
        if ablation_name == 'Baseline (Original Config)':
            continue
        change = abs(rmse_val - baseline_rmse)
        if change > max_abs_change:
            max_abs_change = change
            most_impactful_change = ablation_name
    
    if max_abs_change == 0:
        print("\nBased on this study, no single ablated part showed a significant change in performance.")
    else:
        print(f"\nBased on this study, the part of the code that contributed the most to the overall performance is: '{most_impactful_change}' (Absolute Change: {max_abs_change:.4f})")

    final_validation_score = baseline_rmse # Using baseline as the final reported score for this run
    print(f'Final Validation Performance: {final_validation_score}')
