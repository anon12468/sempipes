
import pandas as pd
import numpy as np
import argparse
import os
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import warnings

# Suppress warnings for cleaner output
warnings.filterwarnings('ignore')

class FeatureEngineer:
    """
    A class to handle feature engineering for the parking violation prediction task.
    It includes loading auxiliary data, creating new features, and encoding categorical variables.
    """
    def __init__(self):
        self.label_encoders = {}
        self.feature_cols = None # To store the list of feature columns after fitting
        self.original_train_keys = None # Store (street_name, violation_type) from training for unseen pair tracking

        # Determine the base directory of the script to resolve input file paths reliably.
        # This makes the script portable regardless of the current working directory.
        script_dir = os.path.dirname(os.path.abspath(__file__))
        self.input_dir = os.path.join(script_dir, "input")

        # Load and prepare auxiliary dataframes from the 'input' directory
        self.street_attributes_df = self._load_and_prepare_street_attributes()
        self.agency_codes_df = self._load_and_prepare_agency_codes()
        
        # Temporal data (holidays, weather) is loaded but currently not used for direct feature creation
        # due to the aggregated nature of the violations data (yearly counts without a date column).
        # These could be used if the core violations data had a time component (e.g., daily/monthly counts).
        self.holidays_2022_df = pd.read_csv(os.path.join(self.input_dir, "holidays_2022.csv"))
        self.holidays_2023_df = pd.read_csv(os.path.join(self.input_dir, "holidays_2023.csv"))
        self.weather_2022_df = pd.read_csv(os.path.join(self.input_dir, "weather_2022.csv"))
        self.weather_2023_df = pd.read_csv(os.path.join(self.input_dir, "weather_2023.csv"))

    def _load_and_prepare_street_attributes(self):
        """Loads and renames columns for street attributes data."""
        df = pd.read_csv(os.path.join(self.input_dir, "street_attributes.csv"))
        df = df.rename(columns={'Street Name': 'street_name'})
        return df

    def _load_and_prepare_agency_codes(self):
        """Loads and renames columns for agency codes data."""
        df = pd.read_csv(os.path.join(self.input_dir, "agency_code_description.csv"))
        # Rename 'description' to 'agency_description' to avoid collision
        # when merging with 'violation_type' from the main dataframe.
        df = df.rename(columns={'description': 'agency_description'})
        return df

    def fit(self, df: pd.DataFrame, y=None):
        """
        Fits the feature engineer on the training data.
        Processes features and learns encodings.
        This method updates the internal state (label_encoders, feature_cols)
         and does not return a transformed DataFrame.
        """
        # Rename columns to standardized names at the very beginning for consistency
        # This df is a copy, so modifying it here is fine.
        df = df.rename(columns={'Street Name': 'street_name', 'Violation Description': 'violation_type'})

        # Store original street_name and violation_type pairs for tracking unseen keys
        self.original_train_keys = df[['street_name', 'violation_type']].copy()

        df = self._add_auxiliary_features(df)
        df = self._add_temporal_features(df)
        df = self._add_categorical_features(df)

        # Identify feature columns, excluding the target variable
        # This assumes 'violation_count' is present in the dataframe used for fitting.
        self.feature_cols = [col for col in df.columns if col not in ['violation_count']]
        return self

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Transforms the input DataFrame using the learned encodings and feature logic.
        Returns a DataFrame containing only the feature columns.
        """
        # Rename columns to standardized names at the very beginning for consistency
        # This df is a copy, so modifying it here is fine.
        df = df.rename(columns={'Street Name': 'street_name', 'Violation Description': 'violation_type'})

        df = self._add_auxiliary_features(df)
        df = self._add_temporal_features(df)
        df = self._add_categorical_features(df)

        # Ensure all feature columns learned during fit are present in the transformed DataFrame.
        # This is crucial for consistency between training and inference data.
        for col in self.feature_cols:
            if col not in df.columns:
                # Add missing feature column with a default value (e.g., 0 for numerical features)
                # or a suitable placeholder for categorical if it wasn't handled by LabelEncoder.
                df[col] = 0 
        
        # Return only the feature columns that were identified during the fit process
        return df[self.feature_cols]

    def _add_auxiliary_features(self, violations_df: pd.DataFrame) -> pd.DataFrame:
        """
        Adds features by merging with auxiliary dataframes like street attributes and agency codes.
        """
        # Merge with street attributes based on 'street_name'
        violations_df = pd.merge(violations_df, self.street_attributes_df, on='street_name', how='left')

        # Merge with agency codes by joining 'violation_type' from violations_df
        # with 'agency_description' from agency_codes_df.
        violations_df = pd.merge(violations_df, self.agency_codes_df, left_on='violation_type', right_on='agency_description', how='left')
        
        # Drop the redundant 'agency_description' column after the merge
        if 'agency_description' in violations_df.columns:
            violations_df = violations_df.drop(columns=['agency_description'])

        # Fill NaN values introduced by left merges for numerical columns
        # (e.g., street attributes like length, width, num_lanes).
        # Using 0 as a placeholder for missing numerical attributes.
        numerical_cols_after_merge = ['length', 'width', 'num_lanes'] # Common street attributes
        for col in numerical_cols_after_merge:
            if col in violations_df.columns:
                violations_df[col] = violations_df[col].fillna(0)

        # Fill NaN for 'agency_code' before label encoding.
        # Assign 'UNKNOWN_AGENCY' string placeholder if an agency_code could not be found.
        if 'agency_code' in violations_df.columns:
            violations_df['agency_code'] = violations_df['agency_code'].fillna('UNKNOWN_AGENCY')
        else:
            # If 'agency_code' column was not created by the merge (e.g., no matches at all), create it.
            violations_df['agency_code'] = 'UNKNOWN_AGENCY'

        return violations_df

    def _add_temporal_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Placeholder method for adding temporal features.
        Currently, the input `violations_per_street_2022.csv` is yearly aggregated
        and lacks a 'date' column, preventing direct temporal joins with daily
        holiday or weather data.
        """
        # If granular (e.g., daily) violation data were available, this method
        # would join with holiday and weather data to create features like
        # 'is_holiday', 'day_of_week', 'avg_temp_day', etc.
        return df

    def _add_categorical_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Applies Label Encoding to specified categorical features.
        Handles unseen categories in the test set by mapping them to a special 'UNKNOWN_CATEGORY'.
        """
        # 'street_name', 'violation_type', and 'agency_code' are treated as categorical features.
        categorical_cols = ['street_name', 'violation_type', 'agency_code']

        for col in categorical_cols:
            # Ensure the column exists and fill any NaNs with a placeholder string
            df[col] = df[col].fillna('UNKNOWN_CATEGORY').astype(str)

            if col not in self.label_encoders:
                # If a LabelEncoder for this column doesn't exist, fit a new one.
                self.label_encoders[col] = LabelEncoder()
                # Fit on all unique values from the current (training) data for this column,
                # plus the 'UNKNOWN_CATEGORY' to ensure it's encoded.
                all_categories = df[col].unique().tolist()
                if 'UNKNOWN_CATEGORY' not in all_categories:
                    all_categories.append('UNKNOWN_CATEGORY')
                self.label_encoders[col].fit(all_categories)
            else:
                # For transforming new data (e.g., test set):
                # Map any categories not seen during fitting to 'UNKNOWN_CATEGORY'.
                df[col] = df[col].apply(lambda x: x if x in self.label_encoders[col].classes_ else 'UNKNOWN_CATEGORY')

            # Apply the learned (or newly fitted) LabelEncoder transformation
            df[col] = self.label_encoders[col].transform(df[col])
        return df

def rmse(y_true, y_pred):
    """Calculates the Root Mean Squared Error."""
    return np.sqrt(mean_squared_error(y_true, y_pred))

def main():
    # Determine the script's directory for robust path handling
    script_dir = os.path.dirname(os.path.abspath(__file__))
    input_dir = os.path.join(script_dir, "input")

    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument("--train-path", type=str, 
                        default=os.path.join(input_dir, "violations_per_street_2022.csv"), 
                        help="Path to the training data CSV file (e.g., violations_per_street_2022.csv).")
    parser.add_argument("--test-path", type=str, default=None, 
                        help="Optional path to the test data CSV file (e.g., violations_per_street_2023.csv).")
    args = parser.parse_args()

    # Load training data
    train_df = pd.read_csv(args.train_path)

    # Feature Engineering
    feature_engineer = FeatureEngineer()
    
    # Create a fully processed dataframe from train_df.
    # This dataframe will be used to derive both features (X) and the target (y)
    # to ensure perfect alignment after all transformations that might affect row structure or types.
    full_processed_train_df = train_df.copy()
    
    # Fit the feature engineer on a copy of this dataframe to learn encodings and identify feature columns.
    feature_engineer.fit(full_processed_train_df.copy()) 

    # Apply the full transformation pipeline to 'full_processed_train_df' using the internal methods.
    # We manually apply the intermediate steps to 'full_processed_train_df'
    # to keep the 'violation_count' column for splitting, as the 'transform' method
    # is designed to return *only* feature columns.
    full_processed_train_df = full_processed_train_df.rename(columns={'Street Name': 'street_name', 'Violation Description': 'violation_type'})
    full_processed_train_df = feature_engineer._add_auxiliary_features(full_processed_train_df)
    full_processed_train_df = feature_engineer._add_temporal_features(full_processed_train_df)
    full_processed_train_df = feature_engineer._add_categorical_features(full_processed_train_df)

    # Now, extract X and y from the *same* fully processed DataFrame
    X = full_processed_train_df[feature_engineer.feature_cols]
    y = full_processed_train_df['violation_count']

    # Split the 2022 training data into training and validation sets for model evaluation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    # Train RandomForestRegressor Model
    # n_jobs=-1 uses all available CPU cores for faster training
    model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
    model.fit(X_train, y_train)

    # Evaluate the model on the validation set
    y_pred_val = model.predict(X_val)
    # Ensure predictions are non-negative, as violation counts cannot be negative
    y_pred_val[y_pred_val < 0] = 0 
    rmse_val = rmse(y_val, y_pred_val)
    print(f"Final Validation Performance: {rmse_val}")

    # If a test-path is provided, generate predictions for that file
    if args.test_path:
        test_df = pd.read_csv(args.test_path)
        
        # Store original keys from the test set for the submission file and unseen key tracking
        test_df_original_keys = test_df[['Street Name', 'Violation Description']].copy().rename(
            columns={'Street Name': 'street_name', 'Violation Description': 'violation_type'}
        )

        # Identify and report the number of unseen (street_name, violation_type) pairs in the test set
        # This uses the original_train_keys stored during the fit process.
        # Perform a left merge and check for rows where the right side (from train_keys) is missing
        unseen_keys_count = test_df_original_keys.merge(
            feature_engineer.original_train_keys.drop_duplicates(), 
            on=['street_name', 'violation_type'], 
            how='left', 
            indicator=True
        ).query('_merge == "left_only"').shape[0]
        print(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_keys_count}")

        # Transform the test data using the fitted feature engineer
        X_test_transformed = feature_engineer.transform(test_df.copy()) 

        # Generate predictions for the test set
        predictions = model.predict(X_test_transformed)
        predictions[predictions < 0] = 0 # Ensure non-negative predictions

        # Create the submission file
        submission_df = pd.DataFrame({
            'street_name': test_df_original_keys['street_name'],
            'violation_type': test_df_original_keys['violation_type'],
            'predicted_count': predictions.round().astype(int) # Round to nearest integer as counts are discrete
        })
        submission_df.to_csv('submission.csv', index=False)
        print("Predictions saved to submission.csv")

        # If 'violation_count' is present in the test_df (i.e., it's an evaluation file),
        # calculate and report the RMSE for the test set.
        if 'violation_count' in test_df.columns:
            y_test_true = test_df['violation_count']
            rmse_test = rmse(y_test_true, predictions)
            print(f"Test Set RMSE: {rmse_test}")

if __name__ == "__main__":
    main()
