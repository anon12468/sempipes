
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import lightgbm as lgb
import argparse
import os
import glob # To discover auxiliary files

# Function to load and preprocess data
def load_and_preprocess_data(filepath, is_train_data=True):
    """
    Loads a CSV file and renames key columns for consistency.
    Ensures 'street_name' and 'violation_type' are present and of string type.
    """
    df = pd.read_csv(filepath)

    # Ensure consistent column names immediately after loading
    df.rename(columns={
        'Street Name': 'street_name',
        'Violation Description': 'violation_type',
        # Add other common renames from auxiliary files if they follow similar patterns
        # For example, if an aux file had 'Violation Type'
        'Violation Type': 'violation_type',
        'Street': 'street_name'
    }, inplace=True)

    # Ensure key columns are of string type to prevent merging issues
    if 'street_name' in df.columns:
        df['street_name'] = df['street_name'].astype(str)
    else:
        # This case indicates a problem with input data schema or renaming
        print(f"Warning: 'street_name' column not found in {filepath} after renaming.")
        # Create a placeholder to avoid immediate errors, though subsequent steps might fail
        df['street_name'] = 'UNKNOWN_STREET'

    if 'violation_type' in df.columns:
        df['violation_type'] = df['violation_type'].astype(str)
    else:
        # This is the original source of KeyError, ensuring it's handled here.
        print(f"Warning: 'violation_type' column not found in {filepath} after renaming.")
        df['violation_type'] = 'UNKNOWN_VIOLATION'


    # Handle missing values in violation_count for test data if present (optional column)
    if not is_train_data and 'violation_count' not in df.columns:
        df['violation_count'] = -1 # Placeholder for missing target in prediction mode

    return df

# Function to load and discover auxiliary data
def load_auxiliary_data(input_dir):
    """
    Discovers and loads all other CSVs in the input directory, standardizing their column names.
    """
    aux_dfs = {}
    # Discover all CSVs in the input directory except the main violation files
    all_csv_files = glob.glob(os.path.join(input_dir, '*.csv'))
    
    # Exclude files that are likely the main training/testing data
    main_files = ['violations_per_street_2022.csv', 'violations_per_street_2023.csv', 'submission.csv'] 
    
    for f_path in all_csv_files:
        f_name = os.path.basename(f_path)
        if f_name not in main_files:
            try:
                aux_df = pd.read_csv(f_path)
                # Standardize common column names in auxiliary data
                aux_df.rename(columns={
                    'Street Name': 'street_name',
                    'Violation Description': 'violation_type',
                    'Violation Type': 'violation_type', # Handle variations
                    'Street': 'street_name' # Handle variations
                    # Add other common renames for auxiliary files here
                }, inplace=True)
                aux_dfs[f_name.replace('.csv', '')] = aux_df
                print(f"Loaded auxiliary data: {f_name}")
            except Exception as e:
                print(f"Could not load or process auxiliary file {f_name}: {e}")
    return aux_dfs

# Function for feature engineering and merging auxiliary data
def feature_engineer(df, aux_dfs, is_train_data=True):
    """
    Applies feature engineering steps and merges auxiliary data.
    """
    # Create an interaction feature
    df['street_violation_pair'] = df['street_name'] + '_' + df['violation_type']

    # Example of merging auxiliary data.
    # We will simulate dummy auxiliary data if no real files are found
    # to ensure the feature engineering pipeline is robust.

    # Dummy street details (example if not found in aux_dfs)
    if 'street_details' not in aux_dfs:
        print("Creating dummy 'street_details' for demonstration as no explicit auxiliary file was found. In a real scenario, this would be loaded from ./input.")
        unique_streets = df['street_name'].unique()
        street_details_data = {
            'street_name': unique_streets,
            'street_length_miles': np.random.rand(len(unique_streets)) * 10,
            'num_lanes': np.random.randint(1, 6, len(unique_streets)),
            'is_commercial': np.random.choice([0, 1], len(unique_streets))
        }
        aux_dfs['street_details'] = pd.DataFrame(street_details_data)

    if 'street_details' in aux_dfs:
        street_details_df = aux_dfs['street_details']
        if 'street_name' in street_details_df.columns:
            street_details_df['street_name'] = street_details_df['street_name'].astype(str)
            df = pd.merge(df, street_details_df, on='street_name', how='left')
            print("Merged 'street_details' auxiliary data.")
        else:
            print("Warning: 'street_name' not found in 'street_details' auxiliary data. Skipping merge.")


    # Dummy violation type details (example if not found in aux_dfs)
    if 'violation_details' not in aux_dfs:
        print("Creating dummy 'violation_details' for demonstration as no explicit auxiliary file was found. In a real scenario, this would be loaded from ./input.")
        unique_violations = df['violation_type'].unique()
        violation_details_data = {
            'violation_type': unique_violations,
            'severity_score': np.random.randint(1, 10, len(unique_violations)),
            'is_moving_violation': np.random.choice([0, 1], len(unique_violations))
        }
        aux_dfs['violation_details'] = pd.DataFrame(violation_details_data)

    if 'violation_details' in aux_dfs:
        violation_details_df = aux_dfs['violation_details']
        if 'violation_type' in violation_details_df.columns:
            violation_details_df['violation_type'] = violation_details_df['violation_type'].astype(str)
            df = pd.merge(df, violation_details_df, on='violation_type', how='left')
            print("Merged 'violation_details' auxiliary data.")
        else:
            print("Warning: 'violation_type' not found in 'violation_details' auxiliary data. Skipping merge.")


    # Fill NaNs from merges - crucial for model training.
    # Impute missing numerical features with median (from train) or 0 (for test/unseen).
    # Categorical NaNs are handled by LightGBM as a separate category if column is 'category' dtype.
    numerical_cols_to_impute = ['street_length_miles', 'num_lanes', 'is_commercial', 'severity_score', 'is_moving_violation']
    for col in numerical_cols_to_impute:
        if col in df.columns:
            # Attempt to convert to numeric, coercing errors
            df[col] = pd.to_numeric(df[col], errors='coerce')
            if df[col].isnull().any():
                # For training, use median. For test, use 0 (or median from training data if available).
                # Here, we use 0 for simplicity on test data for features that might be completely new.
                fill_value = df[col].median() if is_train_data else 0
                df[col].fillna(fill_value, inplace=True)
                
    return df

def main():
    parser = argparse.ArgumentParser(description="NYC Parking Violation Predictor")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the training data CSV file.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Path to the test data CSV file for prediction.')
    args = parser.parse_args()

    # Load and preprocess training data
    train_df = load_and_preprocess_data(args.train_path, is_train_data=True)

    # Determine input directory for auxiliary files
    input_directory = os.path.dirname(args.train_path) if args.train_path else './input'
    if not os.path.exists(input_directory):
        print(f"Input directory '{input_directory}' not found. Creating it and proceeding, but auxiliary files might not be loaded.")
        os.makedirs(input_directory)
    
    # Load auxiliary data
    aux_dfs = load_auxiliary_data(input_directory)

    # Feature engineer training data
    train_df_fe = feature_engineer(train_df.copy(), aux_dfs, is_train_data=True)

    # Define target and features
    target = 'violation_count'
    # Exclude identifiers and the target itself from features
    features = [col for col in train_df_fe.columns if col not in [target, 'street_name', 'violation_type']]

    # Identify categorical features for LightGBM
    # These are typically object/string types, or specific IDs we want treated as categories
    categorical_features = [col for col in features if train_df_fe[col].dtype == 'object' or col == 'street_violation_pair']

    # Convert identified categorical features to 'category' dtype
    for col in categorical_features:
        if col in train_df_fe.columns:
            train_df_fe[col] = train_df_fe[col].astype('category')
        else:
            print(f"Warning: Categorical feature '{col}' not found in train_df_fe during type conversion.")

    # Split data for validation
    # Using a simple random split for development. A grouped or time-based split
    # would be more robust for this type of problem, but for initial development
    # and bug fixing, this is sufficient.
    X = train_df_fe[features]
    y = train_df_fe[target]

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    # Train LightGBM model
    # LightGBM handles categorical features natively if they are of 'category' dtype.
    model = lgb.LGBMRegressor(random_state=42, n_estimators=1000, learning_rate=0.05, num_leaves=31, n_jobs=-1)
    
    # Use 'callbacks' for early stopping instead of deprecated 'early_stopping_rounds'
    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)],
              categorical_feature=[f for f in categorical_features if f in X_train.columns] # Ensure features exist
             )

    # Evaluate on validation set
    val_preds = model.predict(X_val)
    val_preds[val_preds < 0] = 0 # Clip negative predictions
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    print(f'Final Validation Performance: {val_rmse}') # Required output format

    # --- Prediction on test data if provided ---
    if args.test_path:
        print(f"\nProcessing test data from: {args.test_path}")
        test_df_raw = load_and_preprocess_data(args.test_path, is_train_data=False)
        original_test_df_cols = test_df_raw.columns.tolist() # Keep original for RMSE calculation if target exists

        test_df_fe = feature_engineer(test_df_raw.copy(), aux_dfs, is_train_data=False)

        # Prepare test features to match training features
        # Ensure all features from training are present in test_X
        test_X = test_df_fe[features]

        # Align categorical features: ensure test set categories match training set categories
        for col in [f for f in categorical_features if f in X_train.columns]:
            if col in test_X.columns:
                # Convert to category type and set categories to be the same as in training data.
                # Categories in test_X not present in X_train[col].cat.categories will become NaN.
                # LightGBM treats NaN in categorical features as a distinct category.
                test_X[col] = test_X[col].astype('category').cat.set_categories(
                    X_train[col].cat.categories, rename=True
                )
            else:
                # If a categorical feature from training is missing in test_X, add it with all NaNs
                # and set its categories to match training.
                test_X[col] = pd.Categorical(values=[], categories=X_train[col].cat.categories)

        # Ensure all numerical features from X_train are present in test_X and in the same order
        for col in [f for f in features if f not in categorical_features]:
            if col not in test_X.columns:
                test_X[col] = 0.0 # Fill with a default numerical value, e.g., 0

        # Align columns order to match training data
        test_X = test_X[X_train.columns]

        # Make predictions
        predictions = model.predict(test_X)
        predictions[predictions < 0] = 0 # Clip negative predictions

        # Create submission file
        submission_df = pd.DataFrame({
            'street_name': test_df_raw['street_name'],
            'violation_type': test_df_raw['violation_type'],
            'predicted_count': predictions
        })
        submission_df.to_csv('submission.csv', index=False)
        print("Predictions saved to submission.csv")

        # If violation_count is present in the test file, calculate and report RMSE
        if target in original_test_df_cols and not (test_df_raw[target] == -1).all(): # Check if target is not just placeholders
            test_rmse = np.sqrt(mean_squared_error(test_df_raw[target], predictions))
            print(f'Test RMSE: {test_rmse}')

            # Report unseen key pairs
            train_keys = set(train_df_fe['street_violation_pair'].unique())
            test_keys = set(test_df_fe['street_violation_pair'].unique())
            unseen_keys = test_keys - train_keys
            print(f"Number of unseen (street_name, violation_type) pairs in test set: {len(unseen_keys)}")
            print(f"How unseen keys were handled: Unseen categorical feature values (including `street_violation_pair`) were treated as new categories by LightGBM, specifically when converting to 'category' dtype and aligning categories with the training set, any new categories become NaN, which LightGBM handles as a distinct category.")

if __name__ == "__main__":
    main()
