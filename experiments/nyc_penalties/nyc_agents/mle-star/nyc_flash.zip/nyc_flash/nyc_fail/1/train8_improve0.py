
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os
import logging
import sys

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s', stream=sys.stdout)

def load_data(filepath, **kwargs):
    """Loads a CSV file, handling potential FileNotFoundError."""
    try:
        df = pd.read_csv(filepath, **kwargs)
        logging.info(f"Successfully loaded data from {filepath}. Shape: {df.shape}")
        return df
    except FileNotFoundError:
        logging.error(f"Error: File not found at {filepath}. Please ensure the file exists.")
        # Re-raise to terminate execution if a core file is missing
        raise
    except Exception as e:
        logging.error(f"An error occurred while loading {filepath}: {e}")
        raise

def preprocess_data(df):
    """
    Preprocesses the data by cleaning street names and creating combined keys.
    """
    df.columns = [col.replace(' ', '_').lower() for col in df.columns]
    df = df.rename(columns={'violation_description': 'violation_type'})

    # Clean street names (example: remove common suffixes, standardize casing)
    if 'street_name' in df.columns:
        df['street_name'] = df['street_name'].astype(str).str.upper().str.strip()
        df['street_name'] = df['street_name'].replace({
            r'\bAVE\b': 'AVENUE', r'\bST\b': 'STREET', r'\bRD\b': 'ROAD',
            r'\bBLVD\b': 'BOULEVARD', r'\bPKWY\b': 'PARKWAY', r'\bPL\b': 'PLACE'
        }, regex=True)

    if 'violation_type' in df.columns:
        df['violation_type'] = df['violation_type'].astype(str).str.upper().str.strip()

    # Create a unique key for street_name and violation_type
    df['key_pair'] = df['street_name'] + '::' + df['violation_type']
    return df

def feature_engineer(df, additional_dfs=None, is_train=True, street_stats=None, violation_stats=None):
    """
    Performs feature engineering.
    - Integrates additional data (e.g., holidays, weather, street attributes).
    - Creates statistical features.
    """
    logging.info(f"Starting feature engineering for {'training' if is_train else 'prediction'} data.")

    # Convert object columns to category for memory efficiency and CatBoost
    for col in ['street_name', 'violation_type', 'key_pair']:
        if col in df.columns:
            df[col] = df[col].astype('category')

    # Basic features from existing columns
    df['street_name_len'] = df['street_name'].astype(str).apply(len)
    df['violation_type_len'] = df['violation_type'].astype(str).apply(len)
    df['key_pair_len'] = df['key_pair'].astype(str).apply(len)


    # Example of joining with augmentation data
    if additional_dfs:
        if 'street_attributes' in additional_dfs:
            street_attrs = additional_dfs['street_attributes'].copy()
            street_attrs.columns = [col.replace(' ', '_').lower() for col in street_attrs.columns]
            street_attrs = street_attrs.rename(columns={'street': 'street_name'})
            street_attrs['street_name'] = street_attrs['street_name'].astype(str).str.upper().str.strip()
            
            # Ensure attributes are numeric where appropriate and handle potential duplicates
            # Example: If 'boro' is a street attribute, ensure it's categorical
            if 'boro' in street_attrs.columns:
                street_attrs['boro'] = street_attrs['boro'].astype('category')
            
            # Merge, keeping only necessary columns and handling potential duplicates in street_attributes
            street_attrs = street_attrs.drop_duplicates(subset=['street_name'])
            df = pd.merge(df, street_attrs, on='street_name', how='left')
            logging.info(f"Merged with street_attributes. Shape: {df.shape}")

    # Aggregated features (target encoding like) - ONLY from training data
    if is_train:
        street_stats = df.groupby('street_name')['violation_count'].agg(['mean', 'median', 'std', 'max', 'min']).reset_index()
        street_stats.columns = ['street_name', 'street_mean_violation', 'street_median_violation', 'street_std_violation', 'street_max_violation', 'street_min_violation']
        
        violation_stats = df.groupby('violation_type')['violation_count'].agg(['mean', 'median', 'std', 'max', 'min']).reset_index()
        violation_stats.columns = ['violation_type', 'violation_type_mean_violation', 'violation_type_median_violation', 'violation_type_std_violation', 'violation_type_max_violation', 'violation_type_min_violation']
        
        df = pd.merge(df, street_stats, on='street_name', how='left')
        df = pd.merge(df, violation_stats, on='violation_type', how='left')
        logging.info(f"Created aggregate features for training data. Shape: {df.shape}")
    else:
        # For prediction, use the pre-computed means from the training data
        if street_stats is not None:
            df = pd.merge(df, street_stats, on='street_name', how='left')
            # Fill NaN for unseen streets with global mean or 0/median
            for col in ['street_mean_violation', 'street_median_violation', 'street_std_violation', 'street_max_violation', 'street_min_violation']:
                if col in df.columns:
                    df[col].fillna(street_stats[col].mean() if 'mean' in col else 0, inplace=True) # Use mean for mean, 0 for others as a fallback
        
        if violation_stats is not None:
            df = pd.merge(df, violation_stats, on='violation_type', how='left')
            for col in ['violation_type_mean_violation', 'violation_type_median_violation', 'violation_type_std_violation', 'violation_type_max_violation', 'violation_type_min_violation']:
                if col in df.columns:
                    df[col].fillna(violation_stats[col].mean() if 'mean' in col else 0, inplace=True)
            
        logging.info(f"Merged and filled aggregate features for prediction data. Shape: {df.shape}")
        
    # Handle NaN values for numerical features introduced by merges or feature creation
    numeric_cols = df.select_dtypes(include=np.number).columns
    for col in numeric_cols:
        if df[col].isnull().any():
            df[col] = df[col].fillna(0) # Simple imputation with 0 for numerical NaNs

    return df, street_stats, violation_stats

def calculate_rmse(y_true, y_pred):
    """Calculates the Root Mean Squared Error."""
    return np.sqrt(mean_squared_error(y_true, y_pred))

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='violations_per_street_2022.csv',
                        help='Path to the 2022 violations training data file.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional: Path to the test/evaluation data file for 2023. If provided, predictions are generated.')
    parser.add_argument('--input-dir', type=str, default='./input',
                        help='Directory containing all input CSV files.')

    args = parser.parse_args()

    # Construct full paths
    train_filepath = os.path.join(args.input_dir, args.train_path)
    test_filepath = os.path.join(args.input_dir, args.test_path) if args.test_path else None

    logging.info(f"Script initiated with train_path: {train_filepath}, test_path: {test_filepath}, input_dir: {args.input_dir}")

    # --- 1. Load Data ---
    logging.info("Loading training data...")
    train_df = load_data(train_filepath)

    # --- 2. Load Augmentation Data (Example) ---
    additional_dfs = {}
    street_attributes_path = os.path.join(args.input_dir, 'street_attributes.csv')
    if os.path.exists(street_attributes_path):
        try:
            additional_dfs['street_attributes'] = load_data(street_attributes_path)
        except Exception as e:
            logging.warning(f"Could not load street_attributes.csv: {e}")
    else:
        logging.info(f"street_attributes.csv not found at {street_attributes_path}. Skipping augmentation with it.")

    # --- 3. Preprocess and Feature Engineer Training Data ---
    logging.info("Preprocessing and feature engineering training data...")
    train_df = preprocess_data(train_df)
    train_df, street_stats_for_prediction, violation_stats_for_prediction = feature_engineer(train_df, additional_dfs=additional_dfs, is_train=True)

    # Define features and target
    # Exclude original IDs/keys and target variable from features
    features = [col for col in train_df.columns if col not in ['violation_count', 'key_pair']]
    target = 'violation_count'

    # Filter out features that might have been dropped or are not suitable
    features = [f for f in features if f in train_df.columns]

    # Ensure all categorical features are treated as such by CatBoost
    categorical_features = [col for col in features if train_df[col].dtype == 'category' or train_df[col].dtype == 'object']
    logging.info(f"Identified {len(categorical_features)} categorical features for CatBoost.")
    logging.debug(f"Categorical features: {categorical_features}")

    # --- 4. Validation Split ---
    # Stratified split by 'violation_type' and 'street_name' if possible, otherwise simple random split.
    # Grouped split is preferred to prevent data leakage of specific street-violation pairs
    # but a simple random split is used here for direct RMSE optimization as per problem statement
    # and to ensure the validation set has enough samples of various combinations.
    X = train_df[features]
    y = train_df[target]

    # Handle potential stratification issues if unique values are too many or too few
    # Simple split if stratification causes issues.
    try:
        X_train, X_val, y_train, y_val = train_test_split(
            X, y, test_size=0.2, random_state=42, 
            stratify=X['violation_type'] if 'violation_type' in X.columns and len(X['violation_type'].unique()) < 50 else None
        )
    except ValueError:
        logging.warning("Could not perform stratified split. Falling back to simple random split.")
        X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)


    logging.info(f"Training data shape: {X_train.shape}, Validation data shape: {X_val.shape}")

    # --- 5. Model Training (CatBoost) ---
    logging.info("Training CatBoost model...")
    model = CatBoostRegressor(
        iterations=1500, # Increased iterations for potentially better performance
        learning_rate=0.03, # Slightly reduced learning rate
        depth=7, # Adjusted depth
        l2_leaf_reg=3,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=100,
        early_stopping_rounds=100, # Increased early stopping rounds
        cat_features=categorical_features,
        # thread_count=-1, # Uncomment if using multi-threading
        # task_type='GPU' # Uncomment if GPU is available and needed
    )

    train_pool = Pool(X_train, y_train, cat_features=categorical_features)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features)

    model.fit(train_pool, eval_set=val_pool, plot=False)

    # --- 6. Evaluate on Validation Set ---
    val_preds = model.predict(X_val)
    val_preds = np.maximum(0, val_preds) # Ensure non-negative predictions
    validation_rmse = calculate_rmse(y_val, val_preds)
    logging.info(f"Final Validation Performance: {validation_rmse}")


    # --- 7. Handle Test/Evaluation Data ---
    if test_filepath:
        logging.info(f"Loading and processing test data from {test_filepath}...")
        test_df = load_data(test_filepath)
        original_test_df = test_df.copy() # Keep a copy for final output

        test_df = preprocess_data(test_df)
        test_df, _, _ = feature_engineer(test_df, additional_dfs=additional_dfs, is_train=False, 
                                          street_stats=street_stats_for_prediction, 
                                          violation_stats=violation_stats_for_prediction)

        # Identify unseen keys in test data
        train_keys = set(train_df['key_pair'].unique())
        test_keys = set(test_df['key_pair'].unique())
        unseen_keys = test_keys - train_keys
        logging.info(f"Found {len(unseen_keys)} unseen (street_name, violation_type) pairs in the test set out of {len(test_keys)} total pairs.")
        
        # Prepare test features
        # Ensure test_df has the same columns as X_train, fill missing with 0 or appropriate default
        X_test = test_df[features].copy() # Copy to avoid SettingWithCopyWarning
        
        missing_cols_in_test = set(X_train.columns) - set(X_test.columns)
        for col in missing_cols_in_test:
            X_test[col] = 0 # Default numeric fill
            if X_train[col].dtype == 'category' or X_train[col].dtype == 'object':
                X_test[col] = 'UNKNOWN' # Default categorical fill
            logging.warning(f"Added missing feature '{col}' to test set with default value.")

        # Ensure order of columns is the same as training data
        X_test = X_test[X_train.columns]

        test_preds = model.predict(X_test)
        test_preds = np.maximum(0, test_preds) # Ensure non-negative predictions

        # Create submission file
        submission_df = original_test_df[['street_name', 'violation_description']].copy()
        submission_df.columns = ['street_name', 'violation_type'] # Rename for consistency
        submission_df['predicted_count'] = test_preds.round().astype(int) # Round to nearest integer

        output_filename = 'submission.csv'
        submission_df.to_csv(output_filename, index=False)
        logging.info(f"Predictions saved to {output_filename}")

        # If test data has 'violation_count', calculate RMSE
        if 'violation_count' in original_test_df.columns:
            logging.info("Test set contains 'violation_count'. Calculating RMSE...")
            test_rmse = calculate_rmse(original_test_df['violation_count'], test_preds)
            logging.info(f"RMSE on test/evaluation data: {test_rmse}")
        else:
            logging.info("Test set does not contain 'violation_count'. Skipping RMSE calculation for test set.")

    logging.info("Script finished successfully.")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logging.exception("An unhandled error occurred during script execution:")

