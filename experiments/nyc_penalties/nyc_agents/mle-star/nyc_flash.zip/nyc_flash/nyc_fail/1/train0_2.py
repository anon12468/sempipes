
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import catboost as cb
import argparse
import os
import logging

# Set up logging for better visibility during execution
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Helper function to load data safely ---
def load_data(file_path, df_name="DataFrame"):
    """
    Loads a CSV file into a pandas DataFrame.
    Handles file not found errors and general exceptions during loading.
    """
    if not os.path.exists(file_path):
        logging.warning(f"File not found at {file_path} for {df_name}. Returning empty DataFrame.")
        return pd.DataFrame()
    try:
        df = pd.read_csv(file_path)
        logging.info(f"Successfully loaded {df_name} from {file_path} with {len(df)} rows.")
        return df
    except Exception as e:
        logging.error(f"Error loading {file_path} for {df_name}: {e}. Returning empty DataFrame.")
        return pd.DataFrame()

# --- Feature Engineering and Preprocessing Class ---
class FeatureEngineer:
    """
    Handles loading auxiliary data, creating new features, encoding categorical variables,
    and imputing missing values for both training and prediction datasets.
    It prepares data suitable for both RandomForest (numerical/encoded categoricals)
    and CatBoost (numerical and native string categoricals).
    """
    def __init__(self):
        self.le_street = LabelEncoder()
        self.le_violation = LabelEncoder()
        self.le_borough = LabelEncoder()
        
        self.trained_street_violation_pairs = None
        
        # Features that will be label-encoded for RF, and kept as strings for CatBoost
        # 'borough' is dynamically added if present
        self.string_categorical_base_features = ['street_name', 'violation_type']
        
        # Final feature sets to be used by the models, determined during fit()
        self.rf_model_features = [] # All numerical features for RandomForest (includes encoded categoricals)
        self.cb_numerical_features = [] # Numerical features for CatBoost (excludes encoded categoricals)
        self.cb_categorical_features = [] # String categorical features for CatBoost

    def fit(self, df_train_raw, aux_data_dir="./input"):
        """
        Fits the feature engineer on the raw training data.
        Performs feature creation, imputation, and fits LabelEncoders.
        Returns a DataFrame with all features (numerical, encoded, and string categoricals)
        and the target (y) for training.
        """
        logging.info("Fitting FeatureEngineer...")
        # Step 1: Process core data (rename, store target, fill NaNs in key string cols)
        df_train_processed = self._process_core_data(df_train_raw.copy(), is_train=True)
        y_train = df_train_processed['violation_count']
        df_train_processed.drop(columns=['violation_count'], inplace=True)

        # Step 2: Store key pairs for unseen tracking
        self.trained_street_violation_pairs = set(
            df_train_raw.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1)
        )
        
        # Step 3: Add auxiliary features (this will add numerical features and potentially 'borough' string column)
        df_train_features = self._add_auxiliary_features(df_train_processed.copy(), aux_data_dir)
        
        # Step 4: Handle 'borough' as a string categorical if it exists
        current_string_categorical_features = list(self.string_categorical_base_features) # Start with base ones
        if 'borough' in df_train_features.columns:
            df_train_features['borough'].fillna('UNKNOWN_BOROUGH', inplace=True) # Fill NaNs for CatBoost
            current_string_categorical_features.append('borough')
        else:
            logging.warning("No 'borough' column found after feature engineering.")
        
        # Filter string categorical features to only include those actually present in the DataFrame
        self.cb_categorical_features = [f for f in current_string_categorical_features if f in df_train_features.columns]

        # Step 5: Fit LabelEncoders for RandomForest (using string categoricals)
        self._fit_label_encoders(df_train_features)
        
        # Step 6: Apply LabelEncoders and create encoded columns for RandomForest
        df_train_features = self._apply_label_encoders(df_train_features)

        # Step 7: Impute remaining numerical NaNs
        numerical_cols_to_impute = df_train_features.select_dtypes(include=np.number).columns.tolist()
        # Exclude 'actual_violation_count' if it was temporarily added
        if 'actual_violation_count' in numerical_cols_to_impute:
            numerical_cols_to_impute.remove('actual_violation_count')
            
        for col in numerical_cols_to_impute:
            df_train_features[col].fillna(0, inplace=True)

        # Step 8: Identify feature sets for models
        self.rf_model_features = [
            col for col in df_train_features.select_dtypes(include=np.number).columns
            if col not in ['actual_violation_count'] # Exclude any temp evaluation columns
        ]
        
        # CatBoost numerical features are all numerical ones excluding the *encoded* categoricals
        self.cb_numerical_features = [
            col for col in self.rf_model_features
            if col not in ['street_name_encoded', 'violation_type_encoded', 'borough_encoded']
        ]
        
        # Ensure string categoricals are of 'str' dtype for CatBoost
        for col in self.cb_categorical_features:
            if col in df_train_features.columns:
                df_train_features[col] = df_train_features[col].astype(str)

        logging.info(f"RF Model Features: {len(self.rf_model_features)} features.")
        logging.info(f"CatBoost Numerical Features: {len(self.cb_numerical_features)} features.")
        logging.info(f"CatBoost Categorical Features (strings): {len(self.cb_categorical_features)} features.")
        return df_train_features, y_train # Return the full DataFrame with all features

    def transform(self, df_data_raw, aux_data_dir="./input"):
        """
        Transforms new raw data (e.g., test/evaluation data) using the fitted feature engineer.
        Applies feature creation and imputation based on training data.
        Returns a DataFrame with all features (numerical, encoded, and string categoricals).
        """
        logging.info("Transforming data using fitted FeatureEngineer...")
        df_data_processed = self._process_core_data(df_data_raw.copy(), is_train=False)
        df_data_features = self._add_auxiliary_features(df_data_processed.copy(), aux_data_dir)
        
        # Handle 'borough' as a string categorical
        if 'borough' in df_data_features.columns:
            df_data_features['borough'].fillna('UNKNOWN_BOROUGH', inplace=True)
        elif 'borough' in self.cb_categorical_features: # If borough was known from training but missing in test
            df_data_features['borough'] = 'UNKNOWN_BOROUGH'
            logging.warning("Added missing 'borough' column to test data with 'UNKNOWN_BOROUGH'.")

        # Apply LabelEncoders
        df_data_features = self._apply_label_encoders(df_data_features)

        # Impute numerical NaNs for test data
        numerical_cols_to_impute = df_data_features.select_dtypes(include=np.number).columns.tolist()
        if 'actual_violation_count' in numerical_cols_to_impute:
            numerical_cols_to_impute.remove('actual_violation_count')
            
        for col in numerical_cols_to_impute:
            df_data_features[col].fillna(0, inplace=True)

        # Ensure all RF model features are present and filled
        for col in self.rf_model_features:
            if col not in df_data_features.columns:
                df_data_features[col] = 0.0 # Default for numerical/encoded features
                logging.warning(f"Added missing RF model feature '{col}' to test data with 0.0.")
        
        # Ensure all CatBoost numerical features are present and filled
        for col in self.cb_numerical_features:
             if col not in df_data_features.columns:
                df_data_features[col] = 0.0
                logging.warning(f"Added missing CB numerical feature '{col}' to test data with 0.0.")

        # Ensure all CatBoost string categorical features are present and of type 'str'
        for col in self.cb_categorical_features:
            if col not in df_data_features.columns:
                df_data_features[col] = 'MISSING_CATEGORY' # Default for string categoricals
                logging.warning(f"Added missing CB categorical feature '{col}' to test data with 'MISSING_CATEGORY'.")
            else:
                df_data_features[col] = df_data_features[col].astype(str)
        
        return df_data_features # Return the full DataFrame with all features

    def _process_core_data(self, df, is_train=False):
        """Standardizes column names and handles target column for test data."""
        df.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type',
            'violation_count': 'violation_count'
        }, inplace=True)

        if not is_train and 'violation_count' in df.columns:
            df['actual_violation_count'] = df['violation_count']
            df.drop(columns=['violation_count'], inplace=True)
            
        df['street_name'] = df['street_name'].fillna('UNKNOWN_STREET').astype(str)
        df['violation_type'] = df['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str)
        return df

    def _fit_label_encoders(self, df):
        """Fits LabelEncoders on unique values from the processed training data."""
        logging.info("Fitting LabelEncoders...")
        self.le_street.fit(df['street_name'].unique())
        self.le_violation.fit(df['violation_type'].unique())
        
        if 'borough' in df.columns and not df['borough'].isnull().all():
            self.le_borough.fit(df['borough'].fillna('UNKNOWN_BOROUGH').unique())
        else:
            logging.warning("No valid 'borough' column found to fit LabelEncoder for borough.")

    def _apply_label_encoders(self, df):
        """Applies fitted LabelEncoders to categorical columns, mapping unseen categories to -1."""
        logging.info("Applying LabelEncoders...")
        df['street_name_encoded'] = df['street_name'].map(
            lambda x: self.le_street.transform([x])[0] if x in self.le_street.classes_ else -1
        ).fillna(-1).astype(int)

        df['violation_type_encoded'] = df['violation_type'].map(
            lambda x: self.le_violation.transform([x])[0] if x in self.le_violation.classes_ else -1
        ).fillna(-1).astype(int)
        
        if 'borough' in df.columns and hasattr(self.le_borough, 'classes_') and len(self.le_borough.classes_) > 0:
            df['borough_encoded'] = df['borough'].map(
                lambda x: self.le_borough.transform([x])[0] if x in self.le_borough.classes_ else -1
            ).fillna(-1).astype(int)
        else:
            df['borough_encoded'] = -1
            
        return df

    def _add_auxiliary_features(self, df, aux_data_dir):
        """
        Loads and merges auxiliary data to enrich the main DataFrame with additional features.
        """
        logging.info("Adding auxiliary features...")

        # --- Violation Codes Features ---
        violation_codes_df = load_data(os.path.join(aux_data_dir, 'violation_codes.csv'), 'Violation Codes')
        if not violation_codes_df.empty:
            violation_codes_df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
            violation_codes_df['fine_amount_avg'] = (
                violation_codes_df['Manhattan 96th St. & Below'].fillna(0) + 
                violation_codes_df['All Other Areas'].fillna(0)
            ) / 2
            violation_codes_df.drop(columns=['Violation Code', 'Manhattan 96th St. & Below', 'All Other Areas'], errors='ignore', inplace=True)
            df = pd.merge(df, violation_codes_df, on='violation_type', how='left')
            logging.info(f"Merged violation codes. DF shape: {df.shape}")
        
        # --- Street Segments Features ---
        street_segments_df = load_data(os.path.join(aux_data_dir, 'nyc_street_segments.csv'), 'Street Segments')
        if not street_segments_df.empty:
            street_segments_agg = street_segments_df.groupby('Street Name').agg(
                street_segment_length_sum=('Segment Length', 'sum'),
                street_speed_limit_mean=('Speed Limit', 'mean'),
                street_num_lanes_mean=('Number of Lanes', 'mean'),
                borough_ss=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            street_segments_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, street_segments_agg, on='street_name', how='left')
            logging.info(f"Merged street segments. DF shape: {df.shape}")
            
        # --- Parking Zones Features ---
        parking_zones_df = load_data(os.path.join(aux_data_dir, 'nyc_parking_zones.csv'), 'Parking Zones')
        if not parking_zones_df.empty:
            parking_zones_agg = parking_zones_df.groupby('Street Name').agg(
                num_parking_zones=('Parking Zone', 'count'),
                avg_max_duration_parking=('Max Duration', 'mean'),
                borough_pz=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            parking_zones_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, parking_zones_agg, on='street_name', how='left')

            # Consolidate borough information
            if 'borough_ss' in df.columns and 'borough_pz' in df.columns:
                df['borough'] = df['borough_ss'].fillna(df['borough_pz'])
                df.drop(columns=['borough_ss', 'borough_pz'], errors='ignore', inplace=True)
            elif 'borough_ss' in df.columns:
                 df.rename(columns={'borough_ss': 'borough'}, inplace=True)
            elif 'borough_pz' in df.columns:
                 df.rename(columns={'borough_pz': 'borough'}, inplace=True)
            else: # If no borough from aux data, initialize
                df['borough'] = np.nan
            logging.info(f"Merged parking zones. DF shape: {df.shape}")

        # --- Traffic Counts Features ---
        traffic_counts_df = load_data(os.path.join(aux_data_dir, 'traffic_counts_nyc.csv'), 'Traffic Counts')
        if not traffic_counts_df.empty:
            traffic_counts_agg = traffic_counts_df.groupby('Street Name').agg(
                avg_vehicle_count=('Vehicle Count', 'mean'),
                max_vehicle_count=('Vehicle Count', 'max'),
                std_vehicle_count=('Vehicle Count', 'std')
            ).reset_index()
            traffic_counts_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, traffic_counts_agg, on='street_name', how='left')
            logging.info(f"Merged traffic counts. DF shape: {df.shape}")

        # --- Census Tracts Features ---
        # Ensure 'borough' column exists for merging census data
        if 'borough' not in df.columns:
            df['borough'] = np.nan
        
        # Create a temporary 'Borough' column for merging census data, filled for consistency
        df['Borough'] = df['borough'].fillna('UNKNOWN_BOROUGH').astype(str)

        census_tracts_df = load_data(os.path.join(aux_data_dir, 'nyc_census_tracts.csv'), 'Census Tracts')
        if not census_tracts_df.empty:
            census_borough_agg = census_tracts_df.groupby('Borough').agg(
                total_population_borough=('Total Population', 'sum'),
                median_household_income_borough=('Median Household Income', 'mean'),
                poverty_rate_borough=('Poverty Rate', 'mean')
            ).reset_index()
            df = pd.merge(df, census_borough_agg, on='Borough', how='left')
            logging.info(f"Merged census tracts. DF shape: {df.shape}")
        else:
            logging.warning("Census tracts data not available or empty.")
        
        df.drop(columns=['Borough'], errors='ignore', inplace=True) # Drop temporary merge column

        logging.info("Finished adding auxiliary features.")
        return df

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations for 2023 using RandomForest and CatBoost.")
    parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Optional: Path to the 2023 test/evaluation data CSV. If provided, predictions will be generated.")
    parser.add_argument("--aux-data-dir", type=str, default="./input",
                        help="Directory containing auxiliary data CSV files.")
    
    args = parser.parse_args()

    logging.info(f"Starting prediction pipeline with train_path: {args.train_path}")

    # Load 2022 training data
    train_2022_raw = load_data(args.train_path, '2022 Training Data')
    if train_2022_raw.empty:
        logging.error("Training data is empty or could not be loaded. Returning.")
        return

    # Initialize Feature Engineer
    fe = FeatureEngineer()

    # Fit feature engineer on the full 2022 data and get processed features and target
    X_full_2022_df, y_full_2022 = fe.fit(train_2022_raw, args.aux_data_dir)
    
    # Split 2022 data into training and validation sets for development evaluation
    X_train_all, X_val_all, y_train, y_val = train_test_split(
        X_full_2022_df, y_full_2022, test_size=0.2, random_state=42
    )
    
    logging.info(f"Training data shape: {X_train_all.shape}, Validation data shape: {X_val_all.shape}")

    # --- Model Training: RandomForestRegressor ---
    logging.info("Training RandomForestRegressor model...")
    rf_model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1, min_samples_leaf=5)
    
    # Select features for RandomForest
    X_train_rf = X_train_all[fe.rf_model_features]
    X_val_rf = X_val_all[fe.rf_model_features]
    
    rf_model.fit(X_train_rf, y_train)
    logging.info("RandomForestRegressor model training complete.")

    # --- Model Training: CatBoostRegressor ---
    logging.info("Training CatBoostRegressor model...")
    # Select features for CatBoost
    X_train_cb = X_train_all[fe.cb_numerical_features + fe.cb_categorical_features]
    X_val_cb = X_val_all[fe.cb_numerical_features + fe.cb_categorical_features]
    
    # Identify categorical feature indices for CatBoost
    cat_features_indices = [X_train_cb.columns.get_loc(col) for col in fe.cb_categorical_features if col in X_train_cb.columns]

    cat_model = cb.CatBoostRegressor(
        iterations=500,
        learning_rate=0.05,
        depth=6,
        loss_function='Poisson', # Suitable for count data
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Suppress verbose output
        cat_features=cat_features_indices
    )
    
    cat_model.fit(
        X_train_cb, y_train, 
        eval_set=(X_val_cb, y_val),
        early_stopping_rounds=50, # Early stopping to prevent overfitting
        verbose_eval=0 # Suppress verbose output during evaluation
    )
    logging.info("CatBoostRegressor model training complete.")

    # --- Validation Prediction and Evaluation ---
    # RandomForest predictions
    val_predictions_rf = rf_model.predict(X_val_rf)
    val_predictions_rf[val_predictions_rf < 0] = 0 # Ensure predictions are non-negative

    # CatBoost predictions
    val_predictions_cb = cat_model.predict(X_val_cb)
    val_predictions_cb[val_predictions_cb < 0] = 0 # Ensure predictions are non-negative

    # Ensemble predictions (simple average)
    val_predictions_ensemble = (val_predictions_rf + val_predictions_cb) / 2
    val_predictions_ensemble = np.round(val_predictions_ensemble).astype(int) # Round to nearest integer

    val_rmse = np.sqrt(mean_squared_error(y_val, val_predictions_ensemble))
    print(f"Final Validation Performance: {val_rmse:.4f}")

    # --- 2023 Prediction if test-path is provided ---
    if args.test_path:
        logging.info(f"Processing test data from {args.test_path} for 2023 predictions.")
        test_2023_raw = load_data(args.test_path, '2023 Test Data')
        if test_2023_raw.empty:
            logging.warning("Test data is empty or not found. Skipping 2023 predictions.")
            return

        # Keep original key columns for submission output
        submission_keys_raw = test_2023_raw[['Street Name', 'Violation Description']].copy()

        # Store target for evaluation if present before feature engineering
        y_test_actual = None
        if 'violation_count' in test_2023_raw.columns:
            y_test_actual = test_2023_raw['violation_count'].copy()
        
        # Transform test data using the *fitted* feature engineer
        X_test_all = fe.transform(test_2023_raw.copy(), args.aux_data_dir)

        # Report unseen key pairs in the test set
        test_street_violation_pairs = set(
            submission_keys_raw.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1)
        )
        unseen_pairs_count = len(test_street_violation_pairs - fe.trained_street_violation_pairs)
        logging.info(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_pairs_count}")

        # Make predictions on the transformed test data with both models
        X_test_rf = X_test_all[fe.rf_model_features]
        X_test_cb = X_test_all[fe.cb_numerical_features + fe.cb_categorical_features]

        predictions_2023_rf = rf_model.predict(X_test_rf)
        predictions_2023_rf[predictions_2023_rf < 0] = 0 # Ensure non-negative counts

        predictions_2023_cb = cat_model.predict(X_test_cb)
        predictions_2023_cb[predictions_2023_cb < 0] = 0 # Ensure non-negative counts

        # Ensemble test predictions
        predictions_2023_ensemble = (predictions_2023_rf + predictions_2023_cb) / 2
        predictions_2023_ensemble = np.round(predictions_2023_ensemble).astype(int) # Round to integer counts

        # Create submission file
        submission_df = submission_keys_raw
        submission_df.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type'
        }, inplace=True)
        submission_df['predicted_count'] = predictions_2023_ensemble
        submission_df.to_csv('submission.csv', index=False)
        logging.info("Generated submission.csv with 2023 predictions.")

        # Evaluate if actual counts are present in the provided test/eval file
        if y_test_actual is not None:
            test_rmse = np.sqrt(mean_squared_error(y_test_actual, predictions_2023_ensemble))
            print(f"RMSE on provided test/eval data: {test_rmse:.4f}")
        else:
            logging.info("No 'violation_count' column found in test data for evaluation.")
            
    else:
        logging.info("No test-path provided. Skipping 2023 predictions and submission file generation.")

if __name__ == '__main__':
    main()
