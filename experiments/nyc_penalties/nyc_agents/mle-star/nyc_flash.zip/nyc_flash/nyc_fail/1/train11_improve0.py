
import pandas as pd
import numpy as np
import argparse
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Constants for column names
STREET_NAME_COL = 'street_name'
VIOLATION_TYPE_COL = 'violation_type'
VIOLATION_COUNT_COL = 'violation_count'
ORIGINAL_STREET_NAME_COL = 'Street Name'
ORIGINAL_VIOLATION_DESC_COL = 'Violation Description'

class FeatureEngineer:
    def __init__(self, data_dir='./input'):
        self.data_dir = data_dir
        self.street_features = None
        self.violation_features = None
        self._load_augmentation_data()

    def _load_augmentation_data(self):
        # Example: Street-specific features
        try:
            street_data_path = os.path.join(self.data_dir, 'nyc_street_data.csv')
            if os.path.exists(street_data_path):
                self.street_features = pd.read_csv(street_data_path)
                self.street_features.rename(columns={ORIGINAL_STREET_NAME_COL: STREET_NAME_COL}, inplace=True)
                # Ensure the key column is string type
                self.street_features[STREET_NAME_COL] = self.street_features[STREET_NAME_COL].astype(str)
                logging.info(f"Loaded street features from {street_data_path}.")
            else:
                logging.warning(f"Street data not found at {street_data_path}. Creating dummy street features.")
                self.street_features = pd.DataFrame({
                    STREET_NAME_COL: ['BROADWAY', 'MAIN ST', 'PARK AVE', 'LEXINGTON AVE', 'FLUSHING AVE', 'UNKNOWN_STREET'],
                    'borough': ['Manhattan', 'Manhattan', 'Manhattan', 'Manhattan', 'Brooklyn', 'Unknown'],
                    'street_length_km': [21, 5, 8, 10, 15, 0],
                    'num_lanes': [6, 4, 6, 4, 6, 0]
                })
                self.street_features[STREET_NAME_COL] = self.street_features[STREET_NAME_COL].astype(str)
        except Exception as e:
            logging.error(f"Error loading street data: {e}")
            logging.warning("Proceeding with dummy street features.")
            self.street_features = pd.DataFrame({
                STREET_NAME_COL: ['BROADWAY', 'MAIN ST', 'PARK AVE', 'LEXINGTON AVE', 'FLUSHING AVE', 'UNKNOWN_STREET'],
                'borough': ['Manhattan', 'Manhattan', 'Manhattan', 'Manhattan', 'Brooklyn', 'Unknown'],
                'street_length_km': [21, 5, 8, 10, 15, 0],
                'num_lanes': [6, 4, 6, 4, 6, 0]
            })
            self.street_features[STREET_NAME_COL] = self.street_features[STREET_NAME_COL].astype(str)

        # Example: Violation type specific features
        try:
            violation_data_path = os.path.join(self.data_dir, 'violation_codes.csv')
            if os.path.exists(violation_data_path):
                self.violation_features = pd.read_csv(violation_data_path)
                self.violation_features.rename(columns={ORIGINAL_VIOLATION_DESC_COL: VIOLATION_TYPE_COL}, inplace=True)
                # Ensure the key column is string type
                self.violation_features[VIOLATION_TYPE_COL] = self.violation_features[VIOLATION_TYPE_COL].astype(str)
                logging.info(f"Loaded violation features from {violation_data_path}.")
            else:
                logging.warning(f"Violation data not found at {violation_data_path}. Creating dummy violation features.")
                self.violation_features = pd.DataFrame({
                    VIOLATION_TYPE_COL: ['NO PARKING', 'METER EXPIRED', 'DOUBLE PARKING', 'HYDRANT', 'NO STANDING', 'UNKNOWN_VIOLATION'],
                    'fine_amount': [65, 35, 115, 180, 115, 0],
                    'severity': [2, 1, 3, 4, 3, 0],
                    'is_moving_violation': [0, 0, 0, 0, 0, 0]
                })
                self.violation_features[VIOLATION_TYPE_COL] = self.violation_features[VIOLATION_TYPE_COL].astype(str)
        except Exception as e:
            logging.error(f"Error loading violation data: {e}")
            logging.warning("Proceeding with dummy violation features.")
            self.violation_features = pd.DataFrame({
                VIOLATION_TYPE_COL: ['NO PARKING', 'METER EXPIRED', 'DOUBLE PARKING', 'HYDRANT', 'NO STANDING', 'UNKNOWN_VIOLATION'],
                'fine_amount': [65, 35, 115, 180, 115, 0],
                'severity': [2, 1, 3, 4, 3, 0],
                'is_moving_violation': [0, 0, 0, 0, 0, 0]
            })
            self.violation_features[VIOLATION_TYPE_COL] = self.violation_features[VIOLATION_TYPE_COL].astype(str)

    def transform(self, df):
        # Standardize column names
        df.rename(columns={
            ORIGINAL_STREET_NAME_COL: STREET_NAME_COL,
            ORIGINAL_VIOLATION_DESC_COL: VIOLATION_TYPE_COL
        }, inplace=True)

        # Ensure all street_name and violation_type are strings for consistency in merging
        df[STREET_NAME_COL] = df[STREET_NAME_COL].astype(str)
        df[VIOLATION_TYPE_COL] = df[VIOLATION_TYPE_COL].astype(str)

        # Merge with street features
        if self.street_features is not None:
            df = pd.merge(df, self.street_features, on=STREET_NAME_COL, how='left')
            logging.info(f"Merged with street features. New shape: {df.shape}")

        # Merge with violation features
        if self.violation_features is not None:
            df = pd.merge(df, self.violation_features, on=VIOLATION_TYPE_COL, how='left')
            logging.info(f"Merged with violation features. New shape: {df.shape}")

        # Feature Engineering: Example features
        df['street_violation_interaction'] = df[STREET_NAME_COL] + '_' + df[VIOLATION_TYPE_COL]
        
        if 'fine_amount' in df.columns and 'street_length_km' in df.columns:
            # Handle potential division by zero for street_length_km
            df['fine_per_km'] = df['fine_amount'] / df['street_length_km'].replace(0, 0.1) 
            df['fine_per_km'] = df['fine_per_km'].replace([np.inf, -np.inf], np.nan).fillna(0) # Handle inf values
        if 'num_lanes' in df.columns:
            df['num_lanes_squared'] = df['num_lanes']**2

        # Fill NaN values that might result from left joins for new (street, violation) pairs
        # For numerical features, fill with 0
        numerical_cols = df.select_dtypes(include=np.number).columns.tolist()
        if VIOLATION_COUNT_COL in numerical_cols: # Don't fill target column if it exists
             numerical_cols.remove(VIOLATION_COUNT_COL)
        for col in numerical_cols:
            if df[col].isnull().any():
                df[col] = df[col].fillna(0)

        # For categorical features, fill with 'UNKNOWN'
        categorical_cols = df.select_dtypes(include='object').columns.tolist()
        for col in categorical_cols:
            if df[col].isnull().any():
                df[col] = df[col].fillna('UNKNOWN')
        
        return df

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional path to the 2023 test/evaluation data CSV.')
    parser.add_argument('--data-dir', type=str, default='./input',
                        help='Directory containing auxiliary data files.')
    args = parser.parse_args()

    # --- Create dummy auxiliary data files if they don't exist ---
    if not os.path.exists(args.data_dir):
        os.makedirs(args.data_dir)

    dummy_street_data_path = os.path.join(args.data_dir, 'nyc_street_data.csv')
    if not os.path.exists(dummy_street_data_path):
        dummy_street_data = pd.DataFrame({
            ORIGINAL_STREET_NAME_COL: ['BROADWAY', 'MAIN ST', 'PARK AVE', 'LEXINGTON AVE', 'FLUSHING AVE', 'UNKNOWN_STREET'],
            'borough': ['Manhattan', 'Manhattan', 'Manhattan', 'Manhattan', 'Brooklyn', 'Unknown'],
            'street_length_km': [21, 5, 8, 10, 15, 0],
            'num_lanes': [6, 4, 6, 4, 6, 0]
        })
        dummy_street_data.to_csv(dummy_street_data_path, index=False)
        logging.info(f"Created dummy street data at {dummy_street_data_path}")

    dummy_violation_data_path = os.path.join(args.data_dir, 'violation_codes.csv')
    if not os.path.exists(dummy_violation_data_path):
        dummy_violation_data = pd.DataFrame({
            ORIGINAL_VIOLATION_DESC_COL: ['NO PARKING', 'METER EXPIRED', 'DOUBLE PARKING', 'HYDRANT', 'NO STANDING', 'UNKNOWN_VIOLATION'],
            'fine_amount': [65, 35, 115, 180, 115, 0],
            'severity': [2, 1, 3, 4, 3, 0],
            'is_moving_violation': [0, 0, 0, 0, 0, 0]
        })
        dummy_violation_data.to_csv(dummy_violation_data_path, index=False)
        logging.info(f"Created dummy violation data at {dummy_violation_data_path}")

    # Create a dummy train file if it doesn't exist for initial testing
    if not os.path.exists(args.train_path):
        logging.warning(f"Training data not found at {args.train_path}. Creating a dummy training file.")
        dummy_train_data = pd.DataFrame({
            ORIGINAL_STREET_NAME_COL: ['BROADWAY', 'MAIN ST', 'PARK AVE', 'BROADWAY', 'MAIN ST', 'FLUSHING AVE', 'NEW STREET'],
            ORIGINAL_VIOLATION_DESC_COL: ['NO PARKING', 'METER EXPIRED', 'DOUBLE PARKING', 'HYDRANT', 'NO STANDING', 'NO PARKING', 'IDLING'],
            VIOLATION_COUNT_COL: [1200, 800, 300, 50, 400, 700, 150]
        })
        dummy_train_data.to_csv(args.train_path, index=False)

    # --- Load and preprocess training data ---
    logging.info(f"Loading training data from {args.train_path}")
    train_df = pd.read_csv(args.train_path)

    fe = FeatureEngineer(data_dir=args.data_dir)
    train_df_fe = fe.transform(train_df.copy()) # Use a copy to avoid modifying original df if it's passed around

    # Define features (X) and target (y)
    # Exclude the original street_name and violation_type columns if their transformed versions are used,
    # or if 'street_violation_interaction' replaces their direct use.
    # Keep them if CatBoost should use them directly as categorical features.
    features = [col for col in train_df_fe.columns if col not in [VIOLATION_COUNT_COL]]

    # Identify categorical features for CatBoost
    # Ensure only object type columns are passed as categorical features
    categorical_features_names = [col for col in features if train_df_fe[col].dtype == 'object']
    # CatBoost expects indices or names. Using names is safer if column order changes.
    logging.info(f"Categorical features for CatBoost: {categorical_features_names}")

    # Remove the target column from features if it was accidentally included
    if VIOLATION_COUNT_COL in features:
        features.remove(VIOLATION_COUNT_COL)

    target = VIOLATION_COUNT_COL

    # Split 2022 data into training and validation sets
    X_train, X_val, y_train, y_val = train_test_split(
        train_df_fe[features], train_df_fe[target], test_size=0.2, random_state=42
    )
    logging.info(f"Training data shape: {X_train.shape}, Validation data shape: {X_val.shape}")

    # Initialize and train CatBoost Regressor
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Set to True for verbose output during training
        early_stopping_rounds=50,
        cat_features=categorical_features_names, # Pass names directly
        # thread_count=-1, # Use all available CPU cores (uncomment if desired)
        # devices='0:1' # For GPU training, if available (uncomment and configure if GPU is present)
    )

    logging.info("Starting model training...")
    model.fit(X_train, y_train, eval_set=(X_val, y_val), early_stopping_rounds=50)
    logging.info("Model training complete.")

    # Validate model
    val_preds = model.predict(X_val)
    val_preds[val_preds < 0] = 0 # Ensure non-negative predictions
    final_validation_score = np.sqrt(mean_squared_error(y_val, val_preds))
    print(f"Final Validation Performance: {final_validation_score}")

    # --- Prediction for test-path if provided ---
    if args.test_path:
        logging.info(f"Loading test data from {args.test_path}")
        test_df = pd.read_csv(args.test_path)

        original_test_keys = test_df[[ORIGINAL_STREET_NAME_COL, ORIGINAL_VIOLATION_DESC_COL]].copy()

        # Apply feature engineering to test data
        test_df_fe = fe.transform(test_df.copy())

        # Identify unseen key pairs
        train_key_pairs = set(train_df_fe.set_index([STREET_NAME_COL, VIOLATION_TYPE_COL]).index)
        test_key_pairs = set(test_df_fe.set_index([STREET_NAME_COL, VIOLATION_TYPE_COL]).index)
        unseen_key_pairs = test_key_pairs - train_key_pairs
        num_unseen = len(unseen_key_pairs)
        logging.info(f"Number of unseen (street_name, violation_type) pairs in test set: {num_unseen}")

        # Ensure all feature columns from training are present in test_df_fe and in the same order
        for col in features:
            if col not in test_df_fe.columns:
                if col in categorical_features_names:
                    test_df_fe[col] = 'UNKNOWN'
                else:
                    test_df_fe[col] = 0
                logging.warning(f"Feature '{col}' missing in test data, filled with default.")

        # Reorder test features to match training order
        X_test = test_df_fe[features]

        # Make predictions
        test_preds = model.predict(X_test)
        test_preds[test_preds < 0] = 0 # Ensure non-negative predictions
        test_preds = np.round(test_preds).astype(int) # Round to nearest integer count

        # Create submission file
        submission_df = original_test_keys.copy()
        submission_df.rename(columns={
            ORIGINAL_STREET_NAME_COL: STREET_NAME_COL,
            ORIGINAL_VIOLATION_DESC_COL: VIOLATION_TYPE_COL
        }, inplace=True)
        submission_df[VIOLATION_COUNT_COL] = test_preds

        # Save submission
        submission_output_path = 'submission.csv'
        submission_df.to_csv(submission_output_path, index=False)
        logging.info(f"Predictions saved to {submission_output_path}")

        # If 'violation_count' exists in the test file, calculate RMSE
        if VIOLATION_COUNT_COL in test_df.columns:
            actual_counts = test_df[VIOLATION_COUNT_COL]
            test_rmse = np.sqrt(mean_squared_error(actual_counts, test_preds))
            logging.info(f"RMSE on test data (with ground truth): {test_rmse}")
            print(f"Test data RMSE: {test_rmse}")
        else:
            logging.info("Test file does not contain 'violation_count' for RMSE calculation.")

    logging.info("Script finished.")

if __name__ == '__main__':
    main()
