
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import logging
import os
import glob
from sklearn.preprocessing import LabelEncoder

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def load_data(file_path):
    """
    Loads data from a CSV file.
    """
    try:
        df = pd.read_csv(file_path)
        logging.info(f"Successfully loaded data from {file_path}. Shape: {df.shape}")
        return df
    except FileNotFoundError:
        logging.error(f"File not found: {file_path}")
        return None
    except Exception as e:
        logging.error(f"Error loading {file_path}: {e}")
        return None

def _add_auxiliary_features(df, auxiliary_data_dir="./input", is_test_data=False):
    """
    Adds auxiliary features to the main DataFrame.
    This function now handles renaming 'Street Name' and 'Violation Description'
    to 'street_name' and 'violation_type' at the very beginning.
    """
    logging.info("Adding auxiliary features...")

    # Rename core columns to standardized names at the very beginning
    df = df.rename(columns={
        'Street Name': 'street_name',
        'Violation Description': 'violation_type'
    })
    logging.info("Renamed 'Street Name' to 'street_name' and 'Violation Description' to 'violation_type'.")

    # Load and merge violation codes data
    violation_codes_path = os.path.join(auxiliary_data_dir, "nyc_parking_violation_codes.csv")
    if os.path.exists(violation_codes_path):
        violation_codes_df = pd.read_csv(violation_codes_path)
        violation_codes_df = violation_codes_df.rename(columns={
            'VIOLATION CODE': 'violation_code',
            'VIOLATION DESCRIPTION': 'violation_type',
            'FINE AMOUNT': 'fine_amount',
            'DAYS PARKING IN EFFECT': 'days_parking_in_effect',
            'TIME PARKING IN EFFECT': 'time_parking_in_effect'
        })
        # Ensure violation_type is consistent for merging
        violation_codes_df['violation_type'] = violation_codes_df['violation_type'].str.strip().str.upper()
        df['violation_type'] = df['violation_type'].str.strip().str.upper()
        
        df = pd.merge(df, violation_codes_df[['violation_type', 'fine_amount', 'days_parking_in_effect']], 
                      on='violation_type', how='left')
        logging.info("Merged with violation_codes_df.")
    else:
        logging.warning(f"Violation codes file not found at {violation_codes_path}. Skipping merge.")

    # Load and merge street data (example: street type)
    street_data_path = os.path.join(auxiliary_data_dir, "nyc_street_data.csv")
    if os.path.exists(street_data_path):
        street_data_df = pd.read_csv(street_data_path)
        street_data_df = street_data_df.rename(columns={'street_name': 'street_name', 'street_type': 'street_type'})
        # Ensure street_name is consistent for merging
        street_data_df['street_name'] = street_data_df['street_name'].str.strip().str.upper()
        df['street_name'] = df['street_name'].str.strip().str.upper()

        df = pd.merge(df, street_data_df, on='street_name', how='left')
        logging.info("Merged with street_data_df.")
    else:
        logging.warning(f"Street data file not found at {street_data_path}. Skipping merge.")

    # Time-based features (if date/time info were available, but for now we create dummy ones for structure)
    # Since violation_count is an aggregate, we can't directly use 'month' or 'day_of_week' from a single record.
    # However, if the aggregate data itself contained a 'period' or 'quarter' column, we could use that.
    # For now, let's assume we can derive some general temporal trends or simply add a dummy feature.
    # For this task, we will add a 'day_count' if we had a start and end date for the aggregation.
    # As the input is already aggregated by year, we can't create day-level features from this specific dataset.
    # We can, however, add a 'data_year' feature which could potentially capture yearly trends if multiple years were present.
    # For a 2022 dataset, this would just be a constant.
    df['data_year'] = 2022 # Placeholder for the year from which the data originates. This could be passed as an argument.

    # Interaction features
    df['street_violation_interaction'] = df['street_name'].astype(str) + '_' + df['violation_type'].astype(str)

    logging.info(f"Finished adding auxiliary features. Shape: {df.shape}")
    return df

def preprocess_data(df, mode='train', encoders=None):
    """
    Preprocesses the data, including handling categorical features and missing values.
    """
    logging.info(f"Preprocessing data in {mode} mode...")
    if encoders is None:
        encoders = {}

    # Handle missing values
    for col in ['fine_amount', 'days_parking_in_effect', 'street_type']:
        if col in df.columns:
            if df[col].isnull().any():
                if df[col].dtype == 'object':
                    df[col] = df[col].fillna('Unknown')
                else:
                    df[col] = df[col].fillna(df[col].median())
                logging.info(f"Filled missing values in {col}.")

    # Label encode categorical features
    categorical_features = ['violation_type', 'street_name', 'days_parking_in_effect', 'street_type', 'street_violation_interaction']
    for col in categorical_features:
        if col in df.columns:
            if mode == 'train':
                # Create a new encoder for each categorical column if in training mode
                encoders[col] = LabelEncoder()
                df[col] = encoders[col].fit_transform(df[col].astype(str))
            elif mode == 'predict':
                # Use existing encoders in prediction mode
                # Handle unseen categories by transforming them to -1 or a specific 'unseen' label
                # For LabelEncoder, unseen labels will raise an error, so we need a workaround.
                # A common approach is to add the unseen labels to the encoder's classes
                # or use a default value if not found (e.g., -1 for CatBoost)
                df[col] = df[col].astype(str).apply(lambda x: encoders[col].transform([x])[0] if x in encoders[col].classes_ else -1)
            logging.info(f"Label encoded column: {col}")
        else:
            logging.warning(f"Categorical feature {col} not found in DataFrame.")

    logging.info(f"Finished preprocessing data. Shape: {df.shape}")
    return df, encoders

def train_model(X_train, y_train, X_val, y_val, cat_features_indices):
    """
    Trains a CatBoost Regressor model.
    """
    logging.info("Starting model training...")
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=10,
        eval_metric='RMSE',
        random_seed=42,
        verbose=100,
        early_stopping_rounds=50,
        cat_features=cat_features_indices,
        allow_writing_files=False  # Prevent CatBoost from writing files to disk
    )

    model.fit(X_train, y_train, eval_set=(X_val, y_val))
    logging.info("Model training finished.")
    return model

def predict_violations(model, X_predict):
    """
    Makes predictions using the trained model.
    """
    logging.info("Generating predictions...")
    predictions = model.predict(X_predict)
    # Ensure predictions are non-negative
    predictions[predictions < 0] = 0
    logging.info("Predictions generated.")
    return predictions

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                        help="Path to the training data CSV file (2022 violations).")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Optional: Path to the test/evaluation data CSV file (e.g., 2023 violations).")
    parser.add_argument("--auxiliary-data-dir", type=str, default="./input",
                        help="Directory containing auxiliary data files.")
    
    args = parser.parse_args()

    # Load training data
    train_2022_raw = load_data(args.train_path)
    if train_2022_raw is None:
        return

    # Add auxiliary features for training data
    train_2022_features = _add_auxiliary_features(train_2022_raw.copy(), args.auxiliary_data_dir)

    # Prepare data for training
    # Ensure all columns are present before defining features
    expected_features = ['street_name', 'violation_type', 'fine_amount', 'days_parking_in_effect', 'street_type', 'data_year', 'street_violation_interaction']
    for feature in expected_features:
        if feature not in train_2022_features.columns:
            # Add missing feature with a placeholder, this might indicate a missing auxiliary file
            logging.warning(f"Feature '{feature}' not found in training data after augmentation. Adding as NaN/Unknown.")
            if feature in ['fine_amount', 'data_year']:
                train_2022_features[feature] = np.nan
            else:
                train_2022_features[feature] = 'Unknown' # For categorical

    X = train_2022_features[expected_features]
    y = train_2022_features['violation_count']

    # Split training data for validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    logging.info(f"Training data split: Train={X_train.shape}, Validation={X_val.shape}")

    # Preprocess training and validation data
    X_train_processed, encoders = preprocess_data(X_train.copy(), mode='train')
    X_val_processed, _ = preprocess_data(X_val.copy(), mode='predict', encoders=encoders) # Use same encoders

    # Identify categorical features for CatBoost
    cat_features = ['violation_type', 'street_name', 'days_parking_in_effect', 'street_type', 'street_violation_interaction']
    cat_features_indices = [X_train_processed.columns.get_loc(col) for col in cat_features if col in X_train_processed.columns]

    # Train the model
    model = train_model(X_train_processed, y_train, X_val_processed, y_val, cat_features_indices)

    # Report validation RMSE
    val_predictions = predict_violations(model, X_val_processed)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_predictions))
    logging.info(f"Validation RMSE on 2022 holdout data: {val_rmse:.4f}")
    print(f"Final Validation Performance: {val_rmse:.4f}")

    # If a test-path is provided, make predictions for it
    if args.test_path:
        logging.info(f"Processing test data from {args.test_path}...")
        test_2023_raw = load_data(args.test_path)
        if test_2023_raw is None:
            return

        # Keep original street_name and violation_type for submission file
        submission_keys = test_2023_raw[['Street Name', 'Violation Description']].copy()

        # Add auxiliary features to test data
        test_2023_features = _add_auxiliary_features(test_2023_raw.copy(), args.auxiliary_data_dir, is_test_data=True)

        # Ensure all expected features are present in test data, handle missing ones like in training
        for feature in expected_features:
            if feature not in test_2023_features.columns:
                logging.warning(f"Feature '{feature}' not found in test data after augmentation. Adding as NaN/Unknown.")
                if feature in ['fine_amount', 'data_year']:
                    test_2023_features[feature] = np.nan
                else:
                    test_2023_features[feature] = 'Unknown'
        
        X_predict_final = test_2023_features[expected_features]
        
        # Preprocess test data using encoders fitted on training data
        X_predict_processed, _ = preprocess_data(X_predict_final.copy(), mode='predict', encoders=encoders)

        # Identify unseen keys in test data
        train_keys = set(X['street_violation_interaction'].unique())
        test_keys = set(X_predict_final['street_violation_interaction'].unique())
        unseen_keys_count = len(test_keys - train_keys)
        logging.info(f"Number of (street_name, violation_type) pairs in test set unseen in training: {unseen_keys_count}")

        # Generate final predictions
        predictions_2023 = predict_violations(model, X_predict_processed)

        # Create submission file
        submission_df = pd.DataFrame({
            'street_name': submission_keys['Street Name'],
            'violation_type': submission_keys['Violation Description'],
            'predicted_count': predictions_2023.round().astype(int)
        })
        submission_df.to_csv('submission.csv', index=False)
        logging.info("Submission file 'submission.csv' created.")

        # If violation_count is present in the test file, calculate RMSE
        if 'violation_count' in test_2023_raw.columns:
            test_rmse = np.sqrt(mean_squared_error(test_2023_raw['violation_count'], predictions_2023))
            logging.info(f"RMSE on provided test set: {test_rmse:.4f}")
            print(f"RMSE on provided test set: {test_rmse:.4f}")
        else:
            logging.info("Test file does not contain 'violation_count' for RMSE calculation.")

if __name__ == "__main__":
    main()

