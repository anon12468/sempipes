
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import argparse
import os
import logging
import sys

# Suppress warnings for cleaner output in the console
import warnings
warnings.filterwarnings('ignore')

# Set up logging for better visibility during execution, direct to stdout
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s', stream=sys.stdout)

# --- Helper function to load data safely ---
def load_data(file_path, df_name="DataFrame"):
    """
    Loads a CSV file into a pandas DataFrame.
    Handles file not found errors and general exceptions during loading.
    Minimal logging to avoid cluttering ablation output.
    """
    if not os.path.exists(file_path):
        # logging.warning(f"File not found at {file_path} for {df_name}. Returning empty DataFrame.")
        return pd.DataFrame()
    try:
        df = pd.read_csv(file_path)
        # logging.info(f"Successfully loaded {df_name} from {file_path} with {len(df)} rows.")
        return df
    except Exception as e:
        # logging.error(f"Error loading {file_path} for {df_name}: {e}. Returning empty DataFrame.")
        return pd.DataFrame()

# --- Feature Engineering and Preprocessing Class (Modified for Ablation Study) ---
class FeatureEngineerAblation:
    """
    Handles loading auxiliary data, creating new features, and imputing missing values.
    Modified to allow ablation of auxiliary features and core categorical encoding.
    """
    def __init__(self, use_aux_features=True, use_label_encoding_core=True):
        self.trained_street_violation_pairs = None 
        self.feature_columns = [] 
        
        self.use_aux_features = use_aux_features
        self.use_label_encoding_core = use_label_encoding_core # For street_name, violation_type
        
        self.le_street = LabelEncoder()
        self.le_violation = LabelEncoder()
        self.le_borough = LabelEncoder()
        
        self._original_categorical_cols = ['street_name', 'violation_type', 'borough']

    def fit(self, df_train_raw, aux_data_dir="./input"):
        """
        Fits the feature engineer on the raw training data.
        Performs feature creation, imputation, and fits LabelEncoders based on ablation settings.
        """
        self.trained_street_violation_pairs = set(
            df_train_raw.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1)
        )
        
        df_train_features = self._add_auxiliary_features(df_train_raw.copy(), aux_data_dir)
        
        df_train_features.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type',
            'violation_count': 'violation_count'
        }, inplace=True)
        
        target = 'violation_count'
        y_train = df_train_features[target]
        df_train_features.drop(columns=[target], inplace=True)

        if self.use_label_encoding_core:
            df_train_features['street_name_encoded'] = self.le_street.fit_transform(
                df_train_features['street_name'].fillna('UNKNOWN_STREET').astype(str)
            )
            df_train_features['violation_type_encoded'] = self.le_violation.fit_transform(
                df_train_features['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str)
            )
        else:
            # If not using label encoding for core features, drop them
            df_train_features.drop(columns=['street_name', 'violation_type'], errors='ignore', inplace=True)

        # Borough encoding is generally useful and less central to "core" ablation for this study
        if 'borough' in df_train_features.columns:
            df_train_features['borough_encoded'] = self.le_borough.fit_transform(
                df_train_features['borough'].fillna('UNKNOWN_BOROUGH').astype(str)
            )
        else:
            df_train_features['borough_encoded'] = -1 

        numerical_cols = df_train_features.select_dtypes(include=np.number).columns
        for col in numerical_cols:
            df_train_features[col].fillna(0, inplace=True) 
        
        # Define final features: Exclude original string columns and 'actual_violation_count'
        self.feature_columns = [
            col for col in df_train_features.columns
            if col not in self._original_categorical_cols and col != 'actual_violation_count'
        ]
        
        return df_train_features[self.feature_columns], y_train

    def transform(self, df_data_raw, aux_data_dir="./input"):
        """
        Transforms new raw data using the fitted feature engineer based on ablation settings.
        """
        df_data_features = self._add_auxiliary_features(df_data_raw.copy(), aux_data_dir)
        
        if 'violation_count' in df_data_features.columns:
            df_data_features['actual_violation_count'] = df_data_features['violation_count']
            df_data_features.drop(columns=['violation_count'], inplace=True)

        df_data_features.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type'
        }, inplace=True)

        if self.use_label_encoding_core:
            df_data_features['street_name_encoded'] = df_data_features['street_name'].fillna('UNKNOWN_STREET').astype(str).map(
                lambda x: self.le_street.transform([x])[0] if x in self.le_street.classes_ else -1
            )
            df_data_features['violation_type_encoded'] = df_data_features['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str).map(
                lambda x: self.le_violation.transform([x])[0] if x in self.le_violation.classes_ else -1
            )
        else:
            df_data_features.drop(columns=['street_name', 'violation_type'], errors='ignore', inplace=True)
        
        if 'borough' in df_data_features.columns:
            df_data_features['borough_encoded'] = df_data_features['borough'].fillna('UNKNOWN_BOROUGH').astype(str).map(
                lambda x: self.le_borough.transform([x])[0] if x in self.le_borough.classes_ else -1
            )
        else:
            df_data_features['borough_encoded'] = -1 

        numerical_cols = df_data_features.select_dtypes(include=np.number).columns
        for col in numerical_cols:
            df_data_features[col].fillna(0, inplace=True) 
            
        for col in self.feature_columns:
            if col not in df_data_features.columns:
                df_data_features[col] = 0 

        return df_data_features[self.feature_columns]

    def _add_auxiliary_features(self, df, aux_data_dir):
        """
        Loads and merges auxiliary data. Can be skipped based on self.use_aux_features.
        """
        if not self.use_aux_features:
            return df 
            
        violation_codes_df = load_data(os.path.join(aux_data_dir, 'violation_codes.csv'), 'Violation Codes')
        if not violation_codes_df.empty:
            violation_codes_df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
            violation_codes_df['fine_amount_avg'] = (
                violation_codes_df['Manhattan 96th St. & Below'].fillna(0) + 
                violation_codes_df['All Other Areas'].fillna(0)
            ) / 2
            violation_codes_df.drop(columns=['Violation Code', 'Manhattan 96th St. & Below', 'All Other Areas'], errors='ignore', inplace=True)
            df = pd.merge(df, violation_codes_df, on='violation_type', how='left')
        
        street_segments_df = load_data(os.path.join(aux_data_dir, 'nyc_street_segments.csv'), 'Street Segments')
        if not street_segments_df.empty:
            street_segments_agg = street_segments_df.groupby('Street Name').agg(
                street_segment_length_sum=('Segment Length', 'sum'),
                street_speed_limit_mean=('Speed Limit', 'mean'),
                street_num_lanes_mean=('Number of Lanes', 'mean'),
                borough_ss=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            street_segments_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, street_segments_agg, on='street_name', how='left')
            
        parking_zones_df = load_data(os.path.join(aux_data_dir, 'nyc_parking_zones.csv'), 'Parking Zones')
        if not parking_zones_df.empty:
            parking_zones_agg = parking_zones_df.groupby('Street Name').agg(
                num_parking_zones=('Parking Zone', 'count'),
                avg_max_duration_parking=('Max Duration', 'mean'),
                borough_pz=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            parking_zones_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, parking_zones_agg, on='street_name', how='left')

            if 'borough_ss' in df.columns and 'borough_pz' in df.columns:
                df['borough'] = df['borough_ss'].fillna(df['borough_pz'])
            elif 'borough_ss' in df.columns:
                 df['borough'] = df['borough_ss']
            elif 'borough_pz' in df.columns:
                 df['borough'] = df['borough_pz']
            else: 
                df['borough'] = np.nan
            
            df.drop(columns=['borough_ss', 'borough_pz'], errors='ignore', inplace=True)

        traffic_counts_df = load_data(os.path.join(aux_data_dir, 'traffic_counts_nyc.csv'), 'Traffic Counts')
        if not traffic_counts_df.empty:
            traffic_counts_agg = traffic_counts_df.groupby('Street Name').agg(
                avg_vehicle_count=('Vehicle Count', 'mean'),
                max_vehicle_count=('Vehicle Count', 'max'),
                std_vehicle_count=('Vehicle Count', 'std')
            ).reset_index()
            traffic_counts_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, traffic_counts_agg, on='street_name', how='left')

        if 'borough' not in df.columns:
            df['borough'] = np.nan 
        
        census_tracts_df = load_data(os.path.join(aux_data_dir, 'nyc_census_tracts.csv'), 'Census Tracts')
        if not census_tracts_df.empty:
            census_borough_agg = census_tracts_df.groupby('Borough').agg(
                total_population_borough=('Total Population', 'sum'),
                median_household_income_borough=('Median Household Income', 'mean'),
                poverty_rate_borough=('Poverty Rate', 'mean')
            ).reset_index()
            df = pd.merge(df, census_borough_agg, on='Borough', how='left')

        return df

def run_ablation_scenario(name, train_path, aux_data_dir, use_aux_features, use_label_encoding_core):
    """
    Runs a single ablation scenario for training and validation, returning validation RMSE.
    """
    logging.info(f"\n--- Running Scenario: {name} ---")

    train_2022_raw = load_data(train_path, '2022 Training Data')
    if train_2022_raw.empty:
        logging.error("Training data is empty or could not be loaded. Skipping scenario.")
        return name, float('inf')

    fe = FeatureEngineerAblation(use_aux_features=use_aux_features, use_label_encoding_core=use_label_encoding_core)

    X_full_2022, y_full_2022 = fe.fit(train_2022_raw, aux_data_dir)
    
    if X_full_2022.empty or X_full_2022.shape[1] == 0:
        logging.warning(f"No features available for scenario '{name}'. Returning infinite RMSE.")
        return name, float('inf')

    X_train, X_val, y_train, y_val = train_test_split(
        X_full_2022, y_full_2022, test_size=0.2, random_state=42
    )
    
    rf_model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1, min_samples_leaf=5)
    rf_model.fit(X_train, y_train)

    val_predictions = rf_model.predict(X_val)
    val_predictions[val_predictions < 0] = 0
    val_predictions = np.round(val_predictions).astype(int)

    val_rmse = np.sqrt(mean_squared_error(y_val, val_predictions))
    print(f"Validation RMSE for '{name}': {val_rmse:.4f}")
    
    return name, val_rmse

def main_ablation_study():
    parser = argparse.ArgumentParser(description="Perform an ablation study on the NYC parking violations prediction model.")
    parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--aux-data-dir", type=str, default="./input",
                        help="Directory containing auxiliary data CSV files.")
    
    args = parser.parse_args()

    results = []

    # Scenario 1: Baseline (Full model with all features and encoding)
    results.append(run_ablation_scenario(
        "Baseline: All Features & Encoding", 
        args.train_path, 
        args.aux_data_dir, 
        use_aux_features=True, 
        use_label_encoding_core=True
    ))

    # Scenario 2: Ablation - No Auxiliary Features
    results.append(run_ablation_scenario(
        "Ablation: No Auxiliary Features", 
        args.train_path, 
        args.aux_data_dir, 
        use_aux_features=False, 
        use_label_encoding_core=True # Keep label encoding for core features (street, violation)
    ))

    # Scenario 3: Ablation - No Label Encoding for core features (drop original street/violation)
    results.append(run_ablation_scenario(
        "Ablation: No Label Encoding for Street/Violation", 
        args.train_path, 
        args.aux_data_dir, 
        use_aux_features=True, # Keep auxiliary features
        use_label_encoding_core=False # Drop street_name, violation_type instead of encoding
    ))

    print("\n--- Ablation Study Summary ---")
    
    baseline_rmse = None
    for name, rmse in results:
        print(f"{name}: RMSE = {rmse:.4f}")
        if "Baseline" in name:
            baseline_rmse = rmse
            
    if baseline_rmse is not None:
        print(f"\nBaseline RMSE: {baseline_rmse:.4f}")
        impacts = []
        for name, rmse in results:
            if name != "Baseline: All Features & Encoding" and rmse != float('inf'):
                impact = rmse - baseline_rmse
                impacts.append((name, impact))
                print(f"'{name}' change vs. baseline: {'+' if impact > 0 else ''}{impact:.4f} RMSE.")
            elif rmse == float('inf'):
                print(f"'{name}' resulted in no features and could not be evaluated.")
        
        if impacts:
            most_impactful_ablation = max(impacts, key=lambda item: item[1])
            print(f"\nConclusion: The part that contributes the most to the overall performance (based on the largest RMSE increase when removed) is: '{most_impactful_ablation[0]}' (worsened performance by {most_impactful_ablation[1]:.4f} RMSE when ablated).")
        else:
            print("\nCould not determine the most impactful part as no valid ablations led to a measurable change from baseline.")
    else:
        print("\nBaseline scenario failed or could not be evaluated.")


if __name__ == '__main__':
    main_ablation_study()
