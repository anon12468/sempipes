
import pandas as pd
import numpy as np
import catboost as cb
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import argparse
import os
import logging

# Set up logging for better visibility during execution
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Helper function to load data safely ---
def load_data(file_path, df_name="DataFrame"):
    """
    Loads a CSV file into a pandas DataFrame.
    Handles file not found errors and general exceptions during loading.
    """
    if not os.path.exists(file_path):
        logging.warning(f"File not found at {file_path} for {df_name}. Returning empty DataFrame.")
        return pd.DataFrame()
    try:
        df = pd.read_csv(file_path)
        logging.info(f"Successfully loaded {df_name} from {file_path} with {len(df)} rows.")
        return df
    except Exception as e:
        logging.error(f"Error loading {file_path} for {df_name}: {e}. Returning empty DataFrame.")
        return pd.DataFrame()

# --- Feature Engineering and Preprocessing Class ---
class FeatureEngineer:
    """
    Handles loading auxiliary data, creating new features, and imputing missing values
    for both training and prediction datasets.
    It prepares data suitable for CatBoost, which can handle string categorical features directly.
    """
    def __init__(self):
        self.trained_street_violation_pairs = None # To track unseen pairs in test
        self.numerical_features = [] # To store names of numerical features
        self.categorical_features = [] # To store names of categorical features (string columns for CatBoost)
        self.all_features = [] # To store the combined list of all features

    def fit(self, df_train_raw, aux_data_dir="./input"):
        """
        Fits the feature engineer on the raw training data.
        Performs feature creation, imputation, and identifies feature types.
        Returns processed features (X) and target (y) for training.
        """
        logging.info("Fitting FeatureEngineer...")
        # Store unique (street_name, violation_type) pairs from training for unseen pair tracking
        self.trained_street_violation_pairs = set(
            df_train_raw.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1)
        )
        
        # Process core data
        df_train_processed = self._process_core_data(df_train_raw.copy(), is_train=True)
        
        # Add auxiliary features and handle imputations
        df_train_features = self._add_auxiliary_features(df_train_processed.copy(), aux_data_dir)
        
        # Define feature sets after all transformations
        # Exclude original string columns used as keys, and target column
        # and 'actual_violation_count' if it was temporarily added.
        all_potential_features = [
            col for col in df_train_features.columns 
            if col not in ['violation_count', 'actual_violation_count']
        ]

        # Explicitly define categorical features CatBoost will handle as strings
        self.categorical_features = ['street_name', 'violation_type']
        # 'borough' is conditional based on availability from auxiliary data
        if 'borough' in df_train_features.columns:
            self.categorical_features.append('borough')
            # Fill NaN for borough if it exists after merges, so CatBoost treats them as 'UNKNOWN' category
            df_train_features['borough'].fillna('UNKNOWN_BOROUGH', inplace=True)
        else:
            logging.warning("No 'borough' column found after feature engineering.")

        # Identify numerical features
        self.numerical_features = [
            col for col in all_potential_features 
            if df_train_features[col].dtype in ['int64', 'float64'] 
            and col not in self.categorical_features # Ensure not to include if it's already categorical
        ]
        
        # Combine all features for the model
        self.all_features = self.numerical_features + self.categorical_features
        # Ensure all features actually exist in the DataFrame
        self.all_features = [f for f in self.all_features if f in df_train_features.columns]
        
        # Convert all categorical features to 'object' dtype to ensure CatBoost recognizes them as strings
        for cat_col in self.categorical_features:
            if cat_col in df_train_features.columns:
                df_train_features[cat_col] = df_train_features[cat_col].astype(str)

        logging.info(f"Identified {len(self.numerical_features)} numerical features and {len(self.categorical_features)} categorical features.")
        return df_train_features[self.all_features], df_train_features['violation_count']

    def transform(self, df_data_raw, aux_data_dir="./input"):
        """
        Transforms new raw data (e.g., test/evaluation data) using the fitted feature engineer.
        Applies feature creation and imputation based on training data.
        """
        logging.info("Transforming data using fitted FeatureEngineer...")
        df_data_processed = self._process_core_data(df_data_raw.copy(), is_train=False)
        df_data_features = self._add_auxiliary_features(df_data_processed.copy(), aux_data_dir)
        
        # Ensure 'borough' is treated as categorical and filled if it exists
        if 'borough' in df_data_features.columns:
            df_data_features['borough'].fillna('UNKNOWN_BOROUGH', inplace=True)
        
        # Convert all categorical features to 'object' dtype to ensure CatBoost recognizes them as strings
        for cat_col in self.categorical_features:
            if cat_col in df_data_features.columns:
                df_data_features[cat_col] = df_data_features[cat_col].astype(str)
            else: # If a categorical feature from training is missing in test, add it with a placeholder
                df_data_features[cat_col] = 'MISSING_CATEGORY'
                logging.warning(f"Added missing categorical feature '{cat_col}' to test data with 'MISSING_CATEGORY'.")

        # Ensure all numerical features are present and filled
        for num_col in self.numerical_features:
            if num_col not in df_data_features.columns:
                df_data_features[num_col] = 0.0 # Fill missing numerical features with 0
                logging.warning(f"Added missing numerical feature '{num_col}' to test data with 0.0.")
            else:
                df_data_features[num_col].fillna(0.0, inplace=True) # Fill NaNs for existing numerical features

        return df_data_features[self.all_features]

    def _process_core_data(self, df, is_train=False):
        """Standardizes column names and handles target column for test data."""
        df.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type',
            'violation_count': 'violation_count'
        }, inplace=True)

        # Fill any initial NaNs in key columns before joins/encoding to prevent errors
        # CatBoost handles NaNs in string features as a separate category, but for consistency we'll fill.
        df['street_name'] = df['street_name'].fillna('UNKNOWN_STREET').astype(str)
        df['violation_type'] = df['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str)

        if not is_train and 'violation_count' in df.columns:
            # If 'violation_count' is present in test data, it's for evaluation; store it and drop from features
            df['actual_violation_count'] = df['violation_count']
            df.drop(columns=['violation_count'], inplace=True)
            
        return df

    def _add_auxiliary_features(self, df, aux_data_dir):
        """
        Loads and merges auxiliary data to enrich the main DataFrame with additional features.
        Performs aggregations and imputation for newly added numerical columns.
        """
        logging.info("Adding auxiliary features...")

        # --- Violation Codes Features ---
        violation_codes_df = load_data(os.path.join(aux_data_dir, 'violation_codes.csv'), 'Violation Codes')
        if not violation_codes_df.empty:
            violation_codes_df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
            # Create an average fine amount feature
            violation_codes_df['fine_amount_avg'] = (
                violation_codes_df['Manhattan 96th St. & Below'].fillna(0) + 
                violation_codes_df['All Other Areas'].fillna(0)
            ) / 2
            violation_codes_df.drop(columns=['Violation Code', 'Manhattan 96th St. & Below', 'All Other Areas'], errors='ignore', inplace=True)
            df = pd.merge(df, violation_codes_df, on='violation_type', how='left')
            logging.info(f"Merged violation codes. DF shape: {df.shape}")
        
        # --- Street Segments Features ---
        street_segments_df = load_data(os.path.join(aux_data_dir, 'nyc_street_segments.csv'), 'Street Segments')
        if not street_segments_df.empty:
            street_segments_agg = street_segments_df.groupby('Street Name').agg(
                street_segment_length_sum=('Segment Length', 'sum'),
                street_speed_limit_mean=('Speed Limit', 'mean'),
                street_num_lanes_mean=('Number of Lanes', 'mean'),
                borough_ss=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan) # Most frequent borough for the street
            ).reset_index()
            street_segments_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, street_segments_agg, on='street_name', how='left')
            logging.info(f"Merged street segments. DF shape: {df.shape}")
            
        # --- Parking Zones Features ---
        parking_zones_df = load_data(os.path.join(aux_data_dir, 'nyc_parking_zones.csv'), 'Parking Zones')
        if not parking_zones_df.empty:
            parking_zones_agg = parking_zones_df.groupby('Street Name').agg(
                num_parking_zones=('Parking Zone', 'count'),
                avg_max_duration_parking=('Max Duration', 'mean'),
                borough_pz=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            parking_zones_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, parking_zones_agg, on='street_name', how='left')
            # Consolidate borough information from multiple sources
            if 'borough_ss' in df.columns and 'borough_pz' in df.columns:
                df['borough'] = df['borough_ss'].fillna(df['borough_pz'])
                df.drop(columns=['borough_ss', 'borough_pz'], errors='ignore', inplace=True)
            elif 'borough_ss' in df.columns: # Only street segments has borough
                 df.rename(columns={'borough_ss': 'borough'}, inplace=True)
            elif 'borough_pz' in df.columns: # Only parking zones has borough
                 df.rename(columns={'borough_pz': 'borough'}, inplace=True)
            logging.info(f"Merged parking zones. DF shape: {df.shape}")

        # --- Traffic Counts Features ---
        traffic_counts_df = load_data(os.path.join(aux_data_dir, 'traffic_counts_nyc.csv'), 'Traffic Counts')
        if not traffic_counts_df.empty:
            traffic_counts_agg = traffic_counts_df.groupby('Street Name').agg(
                avg_vehicle_count=('Vehicle Count', 'mean'),
                max_vehicle_count=('Vehicle Count', 'max'),
                std_vehicle_count=('Vehicle Count', 'std')
            ).reset_index()
            traffic_counts_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, traffic_counts_agg, on='street_name', how='left')
            logging.info(f"Merged traffic counts. DF shape: {df.shape}")

        # --- Census Tracts Features (Requires consolidated Borough info) ---
        # Ensure 'borough' column exists for merging census data
        if 'borough' not in df.columns:
            df['borough'] = np.nan # Create it if not already present from other merges
        
        # Fill NaN for borough with a placeholder string before merging if it's going to be a categorical feature
        df['borough'] = df['borough'].fillna('UNKNOWN_BOROUGH').astype(str)

        census_tracts_df = load_data(os.path.join(aux_data_dir, 'nyc_census_tracts.csv'), 'Census Tracts')
        if not census_tracts_df.empty:
            # Aggregate census data to borough level
            census_borough_agg = census_tracts_df.groupby('Borough').agg(
                total_population_borough=('Total Population', 'sum'),
                median_household_income_borough=('Median Household Income', 'mean'),
                poverty_rate_borough=('Poverty Rate', 'mean')
            ).reset_index()
            df = pd.merge(df, census_borough_agg, on='Borough', how='left')
            logging.info(f"Merged census tracts. DF shape: {df.shape}")
        else:
            logging.warning("Census tracts data not available or empty.")

        # Impute missing numerical values after all joins.
        # Fill with 0 as a simple strategy for initial solution.
        numerical_cols_to_impute = df.select_dtypes(include=np.number).columns.tolist()
        for col in ['violation_count', 'actual_violation_count']: # Exclude target columns
            if col in numerical_cols_to_impute:
                numerical_cols_to_impute.remove(col)
            
        for col in numerical_cols_to_impute:
            if df[col].isnull().any():
                df[col].fillna(0, inplace=True) # Simple imputation with 0 for missing numbers
        
        logging.info("Finished adding auxiliary features and imputing NaNs.")
        return df

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations for 2023 using CatBoost.")
    parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Optional: Path to the 2023 test/evaluation data CSV. If provided, predictions will be generated.")
    parser.add_argument("--aux-data-dir", type=str, default="./input",
                        help="Directory containing auxiliary data CSV files.")
    
    args = parser.parse_args()

    logging.info(f"Starting prediction pipeline with train_path: {args.train_path}")

    # Load 2022 training data
    train_2022_raw = load_data(args.train_path, '2022 Training Data')
    if train_2022_raw.empty:
        logging.error("Training data is empty or could not be loaded. Exiting.")
        return

    # Initialize Feature Engineer
    fe = FeatureEngineer()

    # Fit feature engineer on the full 2022 data and get processed features and target
    X_full_2022, y_full_2022 = fe.fit(train_2022_raw, args.aux_data_dir)
    
    # Split 2022 data into training and validation sets for development evaluation
    X_train, X_val, y_train, y_val = train_test_split(
        X_full_2022, y_full_2022, test_size=0.2, random_state=42
    )
    
    logging.info(f"Training data shape: {X_train.shape}, Validation data shape: {X_val.shape}")
    logging.info(f"Categorical features for CatBoost: {fe.categorical_features}")
    logging.info(f"Numerical features for CatBoost: {fe.numerical_features}")

    # --- Model Training ---
    logging.info("Training CatBoostRegressor model...")
    # Using parameters from the example model description
    cat_model = cb.CatBoostRegressor(
        iterations=500,
        learning_rate=0.05,
        depth=6,
        loss_function='Poisson', # Suitable for count data
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Suppress verbose output
        cat_features=[col for col in fe.categorical_features if col in X_train.columns] # Specify actual categorical features present
    )
    
    cat_model.fit(
        X_train, y_train, 
        eval_set=(X_val, y_val),
        early_stopping_rounds=50, # Early stopping to prevent overfitting
        verbose_eval=0 # Suppress verbose output during evaluation
    )
    logging.info("Model training complete.")

    # --- Validation Prediction and Evaluation ---
    val_predictions = cat_model.predict(X_val)
    val_predictions[val_predictions < 0] = 0 # Ensure predictions are non-negative
    val_predictions = np.round(val_predictions).astype(int) # Round to nearest integer

    val_rmse = np.sqrt(mean_squared_error(y_val, val_predictions))
    print(f"Final Validation Performance: {val_rmse:.4f}")

    # --- 2023 Prediction if test-path is provided ---
    if args.test_path:
        logging.info(f"Processing test data from {args.test_path} for 2023 predictions.")
        test_2023_raw = load_data(args.test_path, '2023 Test Data')
        if test_2023_raw.empty:
            logging.warning("Test data is empty or not found. Skipping 2023 predictions.")
            return

        # Keep original key columns for submission output
        # It's important to create a copy before any modifications to test_2023_raw
        submission_keys_raw = test_2023_raw[['Street Name', 'Violation Description']].copy()
        
        # Transform test data using the *fitted* feature engineer
        X_test = fe.transform(test_2023_raw.copy(), args.aux_data_dir)

        # Report unseen key pairs in the test set
        test_street_violation_pairs = set(
            submission_keys_raw.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1)
        )
        unseen_pairs_count = len(test_street_violation_pairs - fe.trained_street_violation_pairs)
        logging.info(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_pairs_count}")
        # How these were handled: CatBoost will treat unseen categorical values as a new category
        # (if not present in training data, it will assign a default internal representation).
        # For 'street_name', 'violation_type', 'borough', 'UNKNOWN_STREET'/'UNKNOWN_VIOLATION'/'UNKNOWN_BOROUGH'
        # are handled in _process_core_data and _add_auxiliary_features, giving CatBoost a specific category for NaNs.
        # If a category is seen during transform but not during fit, CatBoost handles it internally.

        # Make predictions on the transformed test data
        predictions_2023 = cat_model.predict(X_test)
        predictions_2023[predictions_2023 < 0] = 0 # Ensure non-negative counts
        predictions_2023 = np.round(predictions_2023).astype(int) # Round to integer counts

        # Create submission file
        submission_df = submission_keys_raw
        submission_df.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type'
        }, inplace=True)
        submission_df['predicted_count'] = predictions_2023
        submission_df.to_csv('submission.csv', index=False)
        logging.info("Generated submission.csv with 2023 predictions.")

        # Evaluate if actual counts are present in the provided test/eval file
        # Check if 'actual_violation_count' was stored during _process_core_data
        if 'actual_violation_count' in test_2023_raw.columns:
            test_rmse = np.sqrt(mean_squared_error(test_2023_raw['actual_violation_count'], predictions_2023))
            print(f"RMSE on provided test/eval data: {test_rmse:.4f}")
            
    else:
        logging.info("No test-path provided. Skipping 2023 predictions and submission file generation.")

if __name__ == '__main__':
    main()
