
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import os
import logging

# Suppress all logging for cleaner ablation output
logging.basicConfig(level=logging.CRITICAL, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Helper function to load data safely ---
def load_data(file_path, df_name="DataFrame"):
    """
    Loads a CSV file into a pandas DataFrame.
    Handles file not found errors and general exceptions during loading.
    """
    if not os.path.exists(file_path):
        return pd.DataFrame()
    try:
        df = pd.read_csv(file_path)
        return df
    except Exception:
        return pd.DataFrame()

# --- Feature Engineering and Preprocessing Class ---
class FeatureEngineer:
    """
    Handles loading auxiliary data, creating new features, and imputing missing values
    for both training and prediction datasets.
    It prepares data suitable for RandomForest, which requires numerical input.
    """
    def __init__(self, include_census_tracts=True, include_parking_zones=True):
        self.trained_street_violation_pairs = None # To track unseen pairs in test
        self.feature_columns = [] # To store names of final features for the model
        
        # Label encoders for categorical features
        self.le_street = LabelEncoder()
        self.le_violation = LabelEncoder()
        self.le_borough = LabelEncoder()
        
        # Ablation flags
        self.include_census_tracts = include_census_tracts
        self.include_parking_zones = include_parking_zones

    def fit(self, df_train_raw, aux_data_dir="./input"):
        """
        Fits the feature engineer on the raw training data.
        Performs feature creation, imputation, and prepares features for RandomForest.
        Returns processed features (X) and target (y) for training.
        """
        df = df_train_raw.copy()
        # Rename core columns early for consistency throughout feature engineering
        df.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type'
        }, inplace=True)

        # Store unique (street_name, violation_type) pairs from training for unseen pair tracking
        self.trained_street_violation_pairs = set(
            df.apply(lambda row: (row['street_name'], row['violation_type']), axis=1)
        )
        
        # Process core data and add auxiliary features
        df = self._add_auxiliary_features(df, aux_data_dir)
        
        # Handle target column
        target_column_name = 'violation_count'
        y_train = df[target_column_name]
        df.drop(columns=[target_column_name], inplace=True) # Drop target from features

        # Fill NaNs for categorical columns before fitting LabelEncoders
        df['street_name'].fillna('UNKNOWN_STREET', inplace=True)
        df['violation_type'].fillna('UNKNOWN_VIOLATION', inplace=True)
        if 'borough' in df.columns:
            df['borough'].fillna('UNKNOWN_BOROUGH', inplace=True)
        
        # Fit LabelEncoders
        self.le_street.fit(df['street_name'])
        self.le_violation.fit(df['violation_type'])
        if 'borough' in df.columns:
            # Check if there are unique borough values to fit on, including 'UNKNOWN_BOROUGH'
            if len(df['borough'].dropna().unique()) > 1 or 'UNKNOWN_BOROUGH' in df['borough'].unique():
                self.le_borough.fit(df['borough'])
            else:
                self.le_borough = LabelEncoder() # Re-initialize if no meaningful categories to fit
        
        # Create encoded features
        df['street_name_encoded'] = self.le_street.transform(df['street_name'])
        df['violation_type_encoded'] = self.le_violation.transform(df['violation_type'])
        if 'borough' in df.columns and hasattr(self.le_borough, 'classes_') and len(self.le_borough.classes_) > 0:
            df['borough_encoded'] = self.le_borough.transform(df['borough'])
        else:
            df['borough_encoded'] = -1 

        # Impute missing numerical values
        numerical_cols = df.select_dtypes(include=np.number).columns.tolist()
        for col in numerical_cols:
            if col not in ['street_name_encoded', 'violation_type_encoded', 'borough_encoded']:
                df[col].fillna(0, inplace=True) # Simple imputation with 0
        
        # Define the final feature columns for the model
        self.feature_columns = [
            col for col in df.select_dtypes(include=np.number).columns.tolist()
            if col != target_column_name # Ensure target is not in features
        ]
        
        self.feature_columns.sort() # Sort to ensure consistent order
        return df[self.feature_columns], y_train

    def _add_auxiliary_features(self, df, aux_data_dir):
        """
        Loads and merges auxiliary data to enrich the main DataFrame with additional features.
        Assumes 'street_name' and 'violation_type' are already present in df.
        """
        # --- Violation Codes Features ---
        violation_codes_df = load_data(os.path.join(aux_data_dir, 'violation_codes.csv'), 'Violation Codes')
        if not violation_codes_df.empty:
            violation_codes_df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
            violation_codes_df['fine_amount_avg'] = (
                violation_codes_df['Manhattan 96th St. & Below'].fillna(0) + 
                violation_codes_df['All Other Areas'].fillna(0)
            ) / 2
            violation_codes_df.drop(columns=['Violation Code', 'Manhattan 96th St. & Below', 'All Other Areas'], errors='ignore', inplace=True)
            df = pd.merge(df, violation_codes_df, on='violation_type', how='left')
        
        # --- Street Segments Features ---
        street_segments_df = load_data(os.path.join(aux_data_dir, 'nyc_street_segments.csv'), 'Street Segments')
        if not street_segments_df.empty:
            street_segments_agg = street_segments_df.groupby('Street Name').agg(
                street_segment_length_sum=('Segment Length', 'sum'),
                street_speed_limit_mean=('Speed Limit', 'mean'),
                street_num_lanes_mean=('Number of Lanes', 'mean'),
                borough_ss=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            street_segments_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, street_segments_agg, on='street_name', how='left')
            
        # --- Parking Zones Features ---
        if self.include_parking_zones: # Ablation flag
            parking_zones_df = load_data(os.path.join(aux_data_dir, 'nyc_parking_zones.csv'), 'Parking Zones')
            if not parking_zones_df.empty:
                parking_zones_agg = parking_zones_df.groupby('Street Name').agg(
                    num_parking_zones=('Parking Zone', 'count'),
                    avg_max_duration_parking=('Max Duration', 'mean'),
                    borough_pz=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
                ).reset_index()
                parking_zones_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
                df = pd.merge(df, parking_zones_agg, on='street_name', how='left')

        # Consolidate borough information from street_segments and parking_zones
        df['borough'] = np.nan # Ensure 'borough' column exists initially

        if 'borough_ss' in df.columns:
            df['borough'] = df['borough_ss']

        if self.include_parking_zones and 'borough_pz' in df.columns:
            df['borough'] = df['borough'].fillna(df['borough_pz']) # Fill from parking zones if available and enabled

        df.drop(columns=['borough_ss', 'borough_pz'], errors='ignore', inplace=True)

        # --- Traffic Counts Features ---
        traffic_counts_df = load_data(os.path.join(aux_data_dir, 'traffic_counts_nyc.csv'), 'Traffic Counts')
        if not traffic_counts_df.empty:
            traffic_counts_agg = traffic_counts_df.groupby('Street Name').agg(
                avg_vehicle_count=('Vehicle Count', 'mean'),
                max_vehicle_count=('Vehicle Count', 'max'),
                std_vehicle_count=('Vehicle Count', 'std')
            ).reset_index()
            traffic_counts_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, traffic_counts_agg, on='street_name', how='left')

        # --- Census Tracts Features ---
        if self.include_census_tracts: # Ablation flag
            census_tracts_df = load_data(os.path.join(aux_data_dir, 'nyc_census_tracts.csv'), 'Census Tracts')
            if not census_tracts_df.empty:
                census_borough_agg = census_tracts_df.groupby('Borough').agg(
                    total_population_borough=('Total Population', 'sum'),
                    median_household_income_borough=('Median Household Income', 'mean'),
                    poverty_rate_borough=('Poverty Rate', 'mean')
                ).reset_index()
                census_borough_agg.rename(columns={'Borough': 'borough'}, inplace=True) # Rename for merging
                df = pd.merge(df, census_borough_agg, on='borough', how='left')
        return df

def run_ablation_experiment(
    train_path="./input/violations_per_street_2022.csv",
    aux_data_dir="./input",
    min_samples_leaf_param=5,
    include_census_tracts_param=True,
    include_parking_zones_param=True
):
    """
    Runs a single experiment with specified ablation parameters and returns the validation RMSE.
    """
    
    # Load training data
    train_2022_raw = load_data(train_path, '2022 Training Data')
    if train_2022_raw.empty:
        return float('inf') # Return a very high RMSE to indicate failure

    # Initialize Feature Engineer with ablation flags
    fe = FeatureEngineer(
        include_census_tracts=include_census_tracts_param,
        include_parking_zones=include_parking_zones_param
    )

    # Fit feature engineer on the full 2022 data and get processed features and target
    X_full_2022, y_full_2022 = fe.fit(train_2022_raw, aux_data_dir)
    
    # Split 2022 data into training and validation sets for development evaluation
    X_train, X_val, y_train, y_val = train_test_split(
        X_full_2022, y_full_2022, test_size=0.2, random_state=42
    )
    
    # --- Model Training ---
    rf_model = RandomForestRegressor(
        n_estimators=100, 
        random_state=42, 
        n_jobs=-1, 
        min_samples_leaf=min_samples_leaf_param
    )
    rf_model.fit(X_train, y_train)

    # --- Validation Prediction and Evaluation ---
    val_predictions = rf_model.predict(X_val)
    val_predictions[val_predictions < 0] = 0 # Ensure predictions are non-negative
    val_predictions = np.round(val_predictions).astype(int) # Round to nearest integer

    val_rmse = np.sqrt(mean_squared_error(y_val, val_predictions))
    return val_rmse

if __name__ == '__main__':
    # Define baseline parameters
    baseline_params = {
        "min_samples_leaf_param": 5,
        "include_census_tracts_param": True,
        "include_parking_zones_param": True
    }

    # Store results
    results = {}

    # --- Baseline ---
    baseline_rmse = run_ablation_experiment(**baseline_params)
    results['Baseline'] = baseline_rmse
    print(f"Baseline RMSE: {baseline_rmse:.4f}")

    # --- Ablation 1: Remove min_samples_leaf=5 (defaults to 1) ---
    ablation1_params = baseline_params.copy()
    ablation1_params["min_samples_leaf_param"] = 1 # Default value for RandomForestRegressor
    ablation1_rmse = run_ablation_experiment(**ablation1_params)
    results['Ablation 1 (min_samples_leaf=1):'] = ablation1_rmse
    print(f"Ablation 1 (min_samples_leaf=1): {ablation1_rmse:.4f} (Change: {ablation1_rmse - baseline_rmse:.4f})")

    # --- Ablation 2: Remove Census Tracts Features ---
    ablation2_params = baseline_params.copy()
    ablation2_params["include_census_tracts_param"] = False
    ablation2_rmse = run_ablation_experiment(**ablation2_params)
    results['Ablation 2 (No Census Tracts Features):'] = ablation2_rmse
    print(f"Ablation 2 (No Census Tracts Features): {ablation2_rmse:.4f} (Change: {ablation2_rmse - baseline_rmse:.4f})")

    # --- Ablation 3: Remove Parking Zones Features ---
    ablation3_params = baseline_params.copy()
    ablation3_params["include_parking_zones_param"] = False
    ablation3_rmse = run_ablation_experiment(**ablation3_params)
    results['Ablation 3 (No Parking Zones Features):'] = ablation3_rmse
    print(f"Ablation 3 (No Parking Zones Features): {ablation3_rmse:.4f} (Change: {ablation3_rmse - baseline_rmse:.4f})")

    # Determine the most impactful change
    most_impactful_change_name = "None"
    max_abs_change = 0.0
    
    for ablation_name, rmse in results.items():
        if ablation_name == 'Baseline':
            continue
        change = abs(rmse - baseline_rmse)
        if change > max_abs_change:
            max_abs_change = change
            most_impactful_change_name = ablation_name
            
    if most_impactful_change_name != "None" and max_abs_change > 0.001: # Small threshold for "significant" change
        print(f"\nThe part of the code that contributed the most to the overall performance is: {most_impactful_change_name}.")
    else:
        print("\nNo significant single ablation had a large impact on performance, or all changes were negligible.")
