

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import argparse
import os
import logging

# Set up logging for better visibility during execution
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Helper function to load data safely ---
def load_data(file_path, df_name="DataFrame"):
    """
    Loads a CSV file into a pandas DataFrame.
    Handles file not found errors and general exceptions during loading.
    """
    if not os.path.exists(file_path):
        logging.warning(f"File not found at {file_path} for {df_name}. Returning empty DataFrame.")
        return pd.DataFrame()
    try:
        df = pd.read_csv(file_path)
        logging.info(f"Successfully loaded {df_name} from {file_path} with {len(df)} rows.")
        return df
    except Exception as e:
        logging.error(f"Error loading {file_path} for {df_name}: {e}. Returning empty DataFrame.")
        return pd.DataFrame()

# --- Feature Engineering and Preprocessing Class ---
class FeatureEngineer:
    """
    Handles loading auxiliary data, creating new features, and imputing missing values
    for both training and prediction datasets.
    It prepares data suitable for RandomForest, which requires numerical input.
    """
    def __init__(self, include_violation_codes=True, include_street_segments=True, include_parking_zones=True,
                 include_traffic_counts=True, include_census_tracts=True):
        self.trained_street_violation_pairs = None # To track unseen pairs in test
        self.feature_columns = [] # To store names of final features for the model
        
        # Label encoders for categorical features
        self.le_street = LabelEncoder()
        self.le_violation = LabelEncoder()
        self.le_borough = LabelEncoder()
        
        # Keep track of original categorical column names to process them
        self._original_categorical_cols = ['street_name', 'violation_type', 'borough']

        # Ablation flags for auxiliary features
        self.include_violation_codes = include_violation_codes
        self.include_street_segments = include_street_segments
        self.include_parking_zones = include_parking_zones
        self.include_traffic_counts = include_traffic_counts
        self.include_census_tracts = include_census_tracts

    def fit(self, df_train_raw, aux_data_dir="./input"):
        """
        Fits the feature engineer on the raw training data.
        Performs feature creation, imputation, and fits LabelEncoders.
        Returns processed features (X) and target (y) for training.
        """
        logging.info("Fitting FeatureEngineer...")
        # Store unique (street_name, violation_type) pairs from training for unseen pair tracking
        self.trained_street_violation_pairs = set(
            df_train_raw.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1)
        )
        
        # Process core data and add auxiliary features
        df_train_features = self._add_auxiliary_features(df_train_raw.copy(), aux_data_dir)
        
        # Rename core columns to be consistent
        df_train_features.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type',
            'violation_count': 'violation_count'
        }, inplace=True)
        
        # Handle target column
        target = 'violation_count'
        y_train = df_train_features[target]
        df_train_features.drop(columns=[target], inplace=True) # Drop target from features

        # Fit LabelEncoders for categorical features
        df_train_features['street_name_encoded'] = self.le_street.fit_transform(
            df_train_features['street_name'].fillna('UNKNOWN_STREET').astype(str)
        )
        df_train_features['violation_type_encoded'] = self.le_violation.fit_transform(
            df_train_features['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str)
        )
        # Borough might not always be present or fully filled, ensure it's handled
        if 'borough' in df_train_features.columns:
            df_train_features['borough_encoded'] = self.le_borough.fit_transform(
                df_train_features['borough'].fillna('UNKNOWN_BOROUGH').astype(str)
            )
        else:
            df_train_features['borough_encoded'] = -1 # Default for missing borough
            logging.warning("No 'borough' column found during feature engineering in train. Using -1 for encoded.")

        # Impute missing numerical values (after all joins and encodings)
        numerical_cols = df_train_features.select_dtypes(include=np.number).columns
        for col in numerical_cols:
            df_train_features[col].fillna(0, inplace=True) # Simple imputation with 0
        
        # Define the final feature columns for the model
        # Exclude original string columns, and any temporary columns
        self.feature_columns = [
            col for col in df_train_features.columns
            if col not in self._original_categorical_cols and col != 'actual_violation_count'
        ]
        
        logging.info(f"Identified {len(self.feature_columns)} features for RandomForest.")
        return df_train_features[self.feature_columns], y_train

    def transform(self, df_data_raw, aux_data_dir="./input"):
        """
        Transforms new raw data (e.g., test/evaluation data) using the fitted feature engineer.
        Applies feature creation and imputation based on training data.
        """
        logging.info("Transforming data using fitted FeatureEngineer...")
        df_data_features = self._add_auxiliary_features(df_data_raw.copy(), aux_data_dir)
        
        # Store actual_violation_count if present for later evaluation
        if 'violation_count' in df_data_features.columns:
            df_data_features['actual_violation_count'] = df_data_features['violation_count']
            df_data_features.drop(columns=['violation_count'], inplace=True)

        # Rename core columns
        df_data_features.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type'
        }, inplace=True)

        # Apply LabelEncoders, handling unseen categories with -1
        df_data_features['street_name_encoded'] = df_data_features['street_name'].fillna('UNKNOWN_STREET').astype(str).map(
            lambda x: self.le_street.transform([x])[0] if x in self.le_street.classes_ else -1
        )
        df_data_features['violation_type_encoded'] = df_data_features['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str).map(
            lambda x: self.le_violation.transform([x])[0] if x in self.le_violation.classes_ else -1
        )
        
        if 'borough' in df_data_features.columns:
            df_data_features['borough_encoded'] = df_data_features['borough'].fillna('UNKNOWN_BOROUGH').astype(str).map(
                lambda x: self.le_borough.transform([x])[0] if x in self.le_borough.classes_ else -1
            )
        else:
            df_data_features['borough_encoded'] = -1 # Default for missing borough
            logging.warning("No 'borough' column found during feature engineering in test. Using -1 for encoded.")

        # Impute missing numerical values
        numerical_cols = df_data_features.select_dtypes(include=np.number).columns
        for col in numerical_cols:
            df_data_features[col].fillna(0, inplace=True)
            
        # Ensure all feature columns from training are present and in order
        for col in self.feature_columns:
            if col not in df_data_features.columns:
                df_data_features[col] = 0 # Add missing features with a default value (e.g., 0)
                logging.warning(f"Added missing feature '{col}' to test data with 0.")

        return df_data_features[self.feature_columns]

    def _add_auxiliary_features(self, df, aux_data_dir):
        """
        Loads and merges auxiliary data to enrich the main DataFrame with additional features.
        """
        logging.info("Adding auxiliary features...")

        # --- Violation Codes Features ---
        if self.include_violation_codes:
            violation_codes_df = load_data(os.path.join(aux_data_dir, 'violation_codes.csv'), 'Violation Codes')
            if not violation_codes_df.empty:
                violation_codes_df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
                violation_codes_df['fine_amount_avg'] = (
                    violation_codes_df['Manhattan 96th St. & Below'].fillna(0) + 
                    violation_codes_df['All Other Areas'].fillna(0)
                ) / 2
                violation_codes_df.drop(columns=['Violation Code', 'Manhattan 96th St. & Below', 'All Other Areas'], errors='ignore', inplace=True)
                df = pd.merge(df, violation_codes_df, on='violation_type', how='left')
                logging.info(f"Merged violation codes. DF shape: {df.shape}")
            else:
                logging.warning("Skipping Violation Codes features due to empty DataFrame or missing file.")
        else:
            logging.info("Ablated: Skipping Violation Codes features.")
        
        # --- Street Segments Features ---
        if self.include_street_segments:
            street_segments_df = load_data(os.path.join(aux_data_dir, 'nyc_street_segments.csv'), 'Street Segments')
            if not street_segments_df.empty:
                street_segments_agg = street_segments_df.groupby('Street Name').agg(
                    street_segment_length_sum=('Segment Length', 'sum'),
                    street_speed_limit_mean=('Speed Limit', 'mean'),
                    street_num_lanes_mean=('Number of Lanes', 'mean'),
                    borough_ss=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
                ).reset_index()
                street_segments_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
                df = pd.merge(df, street_segments_agg, on='street_name', how='left')
                logging.info(f"Merged street segments. DF shape: {df.shape}")
            else:
                logging.warning("Skipping Street Segments features due to empty DataFrame or missing file.")
        else:
            logging.info("Ablated: Skipping Street Segments features.")
            
        # --- Parking Zones Features ---
        if self.include_parking_zones:
            parking_zones_df = load_data(os.path.join(aux_data_dir, 'nyc_parking_zones.csv'), 'Parking Zones')
            if not parking_zones_df.empty:
                parking_zones_agg = parking_zones_df.groupby('Street Name').agg(
                    num_parking_zones=('Parking Zone', 'count'),
                    avg_max_duration_parking=('Max Duration', 'mean'),
                    borough_pz=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
                ).reset_index()
                parking_zones_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
                df = pd.merge(df, parking_zones_agg, on='street_name', how='left')

                # Consolidate borough information
                if 'borough_ss' in df.columns and 'borough_pz' in df.columns:
                    df['borough'] = df['borough_ss'].fillna(df['borough_pz'])
                elif 'borough_ss' in df.columns:
                     df['borough'] = df['borough_ss']
                elif 'borough_pz' in df.columns:
                     df['borough'] = df['borough_pz']
                else: # If no borough from aux data, initialize
                    df['borough'] = np.nan
                
                df.drop(columns=['borough_ss', 'borough_pz'], errors='ignore', inplace=True)
                logging.info(f"Merged parking zones. DF shape: {df.shape}")
            else:
                logging.warning("Skipping Parking Zones features due to empty DataFrame or missing file.")
        else:
            logging.info("Ablated: Skipping Parking Zones features.")

        # --- Traffic Counts Features ---
        if self.include_traffic_counts:
            traffic_counts_df = load_data(os.path.join(aux_data_dir, 'traffic_counts_nyc.csv'), 'Traffic Counts')
            if not traffic_counts_df.empty:
                traffic_counts_agg = traffic_counts_df.groupby('Street Name').agg(
                    avg_vehicle_count=('Vehicle Count', 'mean'),
                    max_vehicle_count=('Vehicle Count', 'max'),
                    std_vehicle_count=('Vehicle Count', 'std')
                ).reset_index()
                traffic_counts_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
                df = pd.merge(df, traffic_counts_agg, on='street_name', how='left')
                logging.info(f"Merged traffic counts. DF shape: {df.shape}")
            else:
                logging.warning("Skipping Traffic Counts features due to empty DataFrame or missing file.")
        else:
            logging.info("Ablated: Skipping Traffic Counts features.")

        # --- Census Tracts Features ---
        if self.include_census_tracts:
            # Ensure 'borough' column (lowercase) is established from previous merges or initialized.
            # This 'borough' column is what the LabelEncoder will use.
            if 'borough' not in df.columns:
                df['borough'] = np.nan

            # To merge with census data, we need a 'Borough' (capital B) column in df
            # as census_borough_agg contains 'Borough'. Use the lowercase 'borough' for this.
            df['Borough'] = df['borough'] # Create the capital 'Borough' column

            census_tracts_df = load_data(os.path.join(aux_data_dir, 'nyc_census_tracts.csv'), 'Census Tracts')
            if not census_tracts_df.empty:
                census_borough_agg = census_tracts_df.groupby('Borough').agg(
                    total_population_borough=('Total Population', 'sum'),
                    median_household_income_borough=('Median Household Income', 'mean'),
                    poverty_rate_borough=('Poverty Rate', 'mean')
                ).reset_index()
                df = pd.merge(df, census_borough_agg, on='Borough', how='left')
                logging.info(f"Merged census tracts. DF shape: {df.shape}")
            else:
                logging.warning("Skipping Census Tracts features due to empty DataFrame or missing file.")
        else:
            logging.info("Ablated: Skipping Census Tracts features.")

        logging.info("Finished adding auxiliary features.")
        return df

def run_ablation_experiment(description,
                            include_violation_codes,
                            include_street_segments,
                            include_census_tracts,
                            train_path="./input/violations_per_street_2022.csv",
                            aux_data_dir="./input"):
    """
    Runs a single experiment with specified FeatureEngineer configurations and returns validation RMSE.
    """
    logging.info(f"\n--- Running Experiment: {description} ---")

    # Load 2022 training data
    train_2022_raw = load_data(train_path, '2022 Training Data')
    if train_2022_raw.empty:
        logging.error("Training data is empty or could not be loaded. Exiting experiment.")
        return float('inf') # Return a high RMSE for failed runs

    # Initialize Feature Engineer with ablation flags
    fe = FeatureEngineer(
        include_violation_codes=include_violation_codes,
        include_street_segments=include_street_segments,
        include_parking_zones=True, # Always include for this study, not an ablation target
        include_traffic_counts=True, # Always include for this study, not an ablation target
        include_census_tracts=include_census_tracts
    )

    # Fit feature engineer on the full 2022 data and get processed features and target
    X_full_2022, y_full_2022 = fe.fit(train_2022_raw, aux_data_dir)
    
    # Split 2022 data into training and validation sets for development evaluation
    X_train, X_val, y_train, y_val = train_test_split(
        X_full_2022, y_full_2022, test_size=0.2, random_state=42
    )
    
    logging.info(f"Training data shape: {X_train.shape}, Validation data shape: {X_val.shape}")

    # --- Model Training ---
    logging.info("Training RandomForestRegressor model...")
    rf_model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1, min_samples_leaf=5)
    rf_model.fit(X_train, y_train)
    logging.info("Model training complete.")

    # --- Validation Prediction and Evaluation ---
    val_predictions = rf_model.predict(X_val)
    val_predictions[val_predictions < 0] = 0 # Ensure predictions are non-negative
    val_predictions = np.round(val_predictions).astype(int) # Round to nearest integer

    val_rmse = np.sqrt(mean_squared_error(y_val, val_predictions))
    print(f"Validation Performance ({description}): {val_rmse:.4f}")
    return val_rmse


if __name__ == '__main__':
    # Define common arguments for the ablation study
    parser = argparse.ArgumentParser(description="Ablation study for NYC parking violations prediction.")
    parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--aux-data-dir", type=str, default="./input",
                        help="Directory containing auxiliary data CSV files.")
    args = parser.parse_args()

    results = {}

    # 1. Baseline: All selected auxiliary features included
    baseline_rmse = run_ablation_experiment(
        "Baseline (All Auxiliary Features)",
        include_violation_codes=True,
        include_street_segments=True,
        include_census_tracts=True,
        train_path=args.train_path,
        aux_data_dir=args.aux_data_dir
    )
    results["Baseline"] = baseline_rmse

    # 2. Ablation: No Violation Codes Features
    no_violation_codes_rmse = run_ablation_experiment(
        "Ablation: No Violation Codes Features",
        include_violation_codes=False,
        include_street_segments=True,
        include_census_tracts=True,
        train_path=args.train_path,
        aux_data_dir=args.aux_data_dir
    )
    results["No Violation Codes Features"] = no_violation_codes_rmse

    # 3. Ablation: No Street Segments Features
    no_street_segments_rmse = run_ablation_experiment(
        "Ablation: No Street Segments Features",
        include_violation_codes=True,
        include_street_segments=False,
        include_census_tracts=True,
        train_path=args.train_path,
        aux_data_dir=args.aux_data_dir
    )
    results["No Street Segments Features"] = no_street_segments_rmse

    # 4. Ablation: No Census Tracts Features
    no_census_tracts_rmse = run_ablation_experiment(
        "Ablation: No Census Tracts Features",
        include_violation_codes=True,
        include_street_segments=True,
        include_census_tracts=False,
        train_path=args.train_path,
        aux_data_dir=args.aux_data_dir
    )
    results["No Census Tracts Features"] = no_census_tracts_rmse

    print("\n--- Ablation Study Results Summary ---")
    for name, rmse in results.items():
        print(f"{name}: RMSE = {rmse:.4f}")

    # Determine which part contributed the most
    # Contribution is inverse: higher RMSE when ablated means more contribution.
    max_degradation = 0
    most_contributing_part = "None (or all contribute equally minimally)"

    for name, rmse in results.items():
        if name == "Baseline":
            continue
        degradation = rmse - baseline_rmse
        print(f"  {name} (change from baseline): {degradation:.4f}")
        if degradation > max_degradation:
            max_degradation = degradation
            most_contributing_part = name

    if max_degradation > 0.0001: # Check for a meaningful degradation
        print(f"\nConclusion: The part that contributed the most to the overall performance was '{most_contributing_part}' (its removal degraded performance by {max_degradation:.4f} RMSE).")
    else:
        print("\nConclusion: None of the ablated components showed a significant positive contribution (or caused degradation) to the model's performance in this study.")
        print("This suggests that these auxiliary features, even when correctly loaded, might be redundant or not highly predictive for this model configuration.")

