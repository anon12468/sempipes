
import argparse
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import numpy as np
from catboost import CatBoostRegressor
import os

# Function to calculate RMSE
def rmse(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations for 2023.") # cite: 3, 6, 8, 10, 12
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional: Path to the 2023 test data CSV for prediction.') # cite: 3, 6, 8, 10, 12
    args = parser.parse_args()

    train_file_path = args.train_path
    test_file_path = args.test_path

    # --- Load Data ---
    print(f"Loading training data from {train_file_path}")
    try:
        df_train = pd.read_csv(train_file_path)
    except FileNotFoundError:
        print(f"Error: Training file not found at {train_file_path}")
        return

    # Load augmentation tables
    print("Loading augmentation data...")
    try:
        violation_codes_df = pd.read_csv('./input/violation_codes.csv')
        nyc_census_tract_data_df = pd.read_csv('./input/nyc_census_tract_data.csv')
        nyc_street_data_df = pd.read_csv('./input/nyc_street_data.csv')
    except FileNotFoundError as e:
        print(f"Error loading augmentation file: {e}. Please ensure all input files are in the './input/' directory.")
        return

    # --- Preprocessing and Feature Engineering for Training Data ---
    print("Preprocessing training data...")
    df_train.rename(columns={
        'Street Name': 'street_name',
        'Violation Description': 'violation_type',
        'violation_count': 'violation_count'
    }, inplace=True)

    # Convert street names and violation types to lowercase for consistent merging
    df_train['street_name'] = df_train['street_name'].str.lower()
    df_train['violation_type'] = df_train['violation_type'].str.lower()

    # Feature: Length of street name
    df_train['street_name_len'] = df_train['street_name'].apply(lambda x: len(str(x)) if pd.notna(x) else 0)

    # --- Preprocessing for Augmentation Tables ---
    # violation_codes_df: Assuming it has 'Violation Description' and other violation-related info
    # This is where the KeyError was expected. Ensure consistent column naming.
    if 'Violation Description' in violation_codes_df.columns:
        violation_codes_df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
    # Convert violation_type to lowercase for consistent merging
    if 'violation_type' in violation_codes_df.columns:
        violation_codes_df['violation_type'] = violation_codes_df['violation_type'].str.lower()
    else:
        print("Warning: 'Violation Description' or 'violation_type' not found in violation_codes.csv. This might affect merging.")
        # If 'violation_type' is truly missing, create an empty one to avoid downstream errors
        violation_codes_df['violation_type'] = '' # Placeholder to allow merge to proceed if column was just missing

    # nyc_street_data_df: Assuming it has 'Street Name' and street-related info
    if 'Street Name' in nyc_street_data_df.columns:
        nyc_street_data_df.rename(columns={'Street Name': 'street_name'}, inplace=True)
    # Convert street_name to lowercase for consistent merging
    if 'street_name' in nyc_street_data_df.columns:
        nyc_street_data_df['street_name'] = nyc_street_data_df['street_name'].str.lower()
    else:
        print("Warning: 'Street Name' or 'street_name' not found in nyc_street_data.csv. This might affect merging.")
        nyc_street_data_df['street_name'] = '' # Placeholder

    # nyc_census_tract_data_df: This table might need more complex joining or feature engineering
    if 'Street Name' in nyc_census_tract_data_df.columns:
        nyc_census_tract_data_df.rename(columns={'Street Name': 'street_name'}, inplace=True)
    if 'street_name' in nyc_census_tract_data_df.columns:
        nyc_census_tract_data_df['street_name'] = nyc_census_tract_data_df['street_name'].str.lower()
    else:
        print("Warning: 'Street Name' or 'street_name' not found in nyc_census_tract_data.csv. This might affect merging.")
        nyc_census_tract_data_df['street_name'] = '' # Placeholder


    # --- Feature Augmentation (Merges) ---
    print("Augmenting training data with external datasets...")
    # Merge violation_codes_df
    if 'violation_type' in df_train.columns and 'violation_type' in violation_codes_df.columns:
        # Select relevant columns from violation_codes_df, excluding 'violation_type' if it's the only one left after initial filter
        # Ensure only unique 'violation_type' rows from violation_codes_df to avoid duplicating rows after merge
        violation_codes_unique = violation_codes_df.drop_duplicates(subset=['violation_type'])
        df_train = pd.merge(df_train, violation_codes_unique, on='violation_type', how='left', suffixes=('', '_violation_code'))
        # Fill NaN values introduced by the merge for the new columns
        for col in violation_codes_unique.columns:
            if col != 'violation_type' and col in df_train.columns:
                if df_train[col].dtype == 'object' or df_train[col].dtype.name == 'category':
                    df_train[col] = df_train[col].fillna('unknown')
                else:
                    df_train[col] = df_train[col].fillna(df_train[col].median() if not df_train[col].empty else 0)
    else:
        print("Skipping merge with violation_codes_df due to missing 'violation_type' in one of the dataframes.")


    # Merge nyc_street_data_df
    if 'street_name' in df_train.columns and 'street_name' in nyc_street_data_df.columns:
        # Ensure unique 'street_name' rows from nyc_street_data_df
        nyc_street_data_unique = nyc_street_data_df.drop_duplicates(subset=['street_name'])
        df_train = pd.merge(df_train, nyc_street_data_unique, on='street_name', how='left', suffixes=('', '_street'))
        for col in nyc_street_data_unique.columns:
            if col != 'street_name' and col in df_train.columns:
                if df_train[col].dtype == 'object' or df_train[col].dtype.name == 'category':
                    df_train[col] = df_train[col].fillna('unknown')
                else:
                    df_train[col] = df_train[col].fillna(df_train[col].median() if not df_train[col].empty else 0)
    else:
        print("Skipping merge with nyc_street_data_df due to missing 'street_name' in one of the dataframes.")
    
    # Merge nyc_census_tract_data_df
    if 'street_name' in df_train.columns and 'street_name' in nyc_census_tract_data_df.columns:
        # Ensure unique 'street_name' rows from nyc_census_tract_data_df
        nyc_census_tract_data_unique = nyc_census_tract_data_df.drop_duplicates(subset=['street_name'])
        df_train = pd.merge(df_train, nyc_census_tract_data_unique, on='street_name', how='left', suffixes=('', '_census'))
        for col in nyc_census_tract_data_unique.columns:
            if col != 'street_name' and col in df_train.columns:
                if df_train[col].dtype == 'object' or df_train[col].dtype.name == 'category':
                    df_train[col] = df_train[col].fillna('unknown')
                else:
                    df_train[col] = df_train[col].fillna(df_train[col].median() if not df_train[col].empty else 0)
    else:
        print("Skipping merge with nyc_census_tract_data_df due to missing 'street_name' in one of the dataframes or complex join logic needed.")


    # --- Define Features (X) and Target (y) ---
    # Identify categorical and numerical features
    # Exclude 'violation_count' from features as it's the target
    # Ensure no duplicate columns in features
    
    # Start with base features
    categorical_features = ['street_name', 'violation_type']
    numerical_features = ['street_name_len']

    # Add columns from merged dataframes, excluding keys and target
    for df_aug in [violation_codes_df, nyc_street_data_df, nyc_census_tract_data_df]:
        for col in df_aug.columns:
            if col not in ['street_name', 'violation_type', 'violation_count'] and col in df_train.columns:
                if df_train[col].dtype == 'object' or df_train[col].dtype.name == 'category':
                    if col not in categorical_features:
                        categorical_features.append(col)
                elif df_train[col].dtype in ['int64', 'float64']:
                    if col not in numerical_features:
                        numerical_features.append(col)

    # Remove duplicates from feature lists if any
    categorical_features = list(dict.fromkeys(categorical_features))
    numerical_features = list(dict.fromkeys(numerical_features))
    
    # Convert categorical features to 'category' dtype for CatBoost
    for col in categorical_features:
        if col in df_train.columns:
            df_train[col] = df_train[col].astype(str) # Convert to string first to handle mixed types
            df_train[col] = df_train[col].str.lower() # Ensure consistent casing
            df_train[col] = df_train[col].astype('category')
            # Add a special category for unseen values during prediction
            if 'unseen_category' not in df_train[col].cat.categories:
                df_train[col] = df_train[col].cat.add_categories('unseen_category')
            df_train[col] = df_train[col].fillna('unseen_category') # fill any NaNs with unseen
        else:
            print(f"Warning: Categorical feature '{col}' not found in df_train. Skipping.")


    # Ensure all numerical features are filled (e.g., with median or mean)
    for col in numerical_features:
        if col in df_train.columns:
            if df_train[col].isnull().any():
                df_train[col] = df_train[col].fillna(df_train[col].median())
        else:
            print(f"Warning: Numerical feature '{col}' not found in df_train. Skipping.")

    # Filter features to only include those present in df_train
    final_categorical_features = [col for col in categorical_features if col in df_train.columns]
    final_numerical_features = [col for col in numerical_features if col in df_train.columns]

    X = df_train[final_categorical_features + final_numerical_features]
    y = df_train['violation_count']

    # --- Train/Validation Split ---
    # Using a simple random split for validation from 2022 data
    print("Splitting training data for validation...")
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    # --- Model Training ---
    print("Training CatBoostRegressor model...")
    # Get indices of categorical features in X_train
    cat_features_indices = [X_train.columns.get_loc(col) for col in final_categorical_features if col in X_train.columns]
    
    # Initialize CatBoostRegressor # cite: 2, 4, 5, 7, 11
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=8,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=100,
        early_stopping_rounds=50,
        cat_features=cat_features_indices,
        thread_count=-1, # Use all available threads
        # subsample=0.7, # Can be added if OOM issues arise
        # one_hot_max_size=50, # Consider for high cardinality features
        # l2_leaf_reg=3, # Regularization
    )
    
    model.fit(X_train, y_train, eval_set=(X_val, y_val), plot=False)

    # --- Validation Performance ---
    val_preds = model.predict(X_val)
    # Clip predictions to be non-negative and round to nearest integer
    val_rmse = rmse(y_val, val_preds.clip(min=0).round())
    print(f"Final Validation Performance: {val_rmse}")

    # --- Prediction on Test Data (if provided) ---
    if test_file_path:
        print(f"\nLoading test data from {test_file_path}")
        try:
            df_test = pd.read_csv(test_file_path)
        except FileNotFoundError:
            print(f"Error: Test file not found at {test_file_path}")
            return

        print("Preprocessing test data...")
        # Store original keys for submission
        submission_keys = df_test[['Street Name', 'Violation Description']].copy()

        df_test.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type'
        }, inplace=True)

        df_test['street_name'] = df_test['street_name'].str.lower()
        df_test['violation_type'] = df_test['violation_type'].str.lower()
        
        # Feature: Length of street name for test data
        df_test['street_name_len'] = df_test['street_name'].apply(lambda x: len(str(x)) if pd.notna(x) else 0)

        # Augment test data (same steps as training)
        print("Augmenting test data with external datasets...")
        if 'violation_type' in df_test.columns and 'violation_type' in violation_codes_df.columns:
            violation_codes_unique = violation_codes_df.drop_duplicates(subset=['violation_type'])
            df_test = pd.merge(df_test, violation_codes_unique, on='violation_type', how='left', suffixes=('', '_violation_code'))
            for col in violation_codes_unique.columns:
                if col != 'violation_type' and col in df_test.columns:
                    if df_test[col].dtype == 'object' or df_test[col].dtype.name == 'category':
                        df_test[col] = df_test[col].fillna('unknown')
                    else:
                        # Use training data median for consistency if column exists in training and is numeric
                        if col in df_train.columns and df_train[col].dtype in ['int64', 'float64']:
                            df_test[col] = df_test[col].fillna(df_train[col].median())
                        else:
                            df_test[col] = df_test[col].fillna(0) # Default for new numeric
        
        if 'street_name' in df_test.columns and 'street_name' in nyc_street_data_df.columns:
            nyc_street_data_unique = nyc_street_data_df.drop_duplicates(subset=['street_name'])
            df_test = pd.merge(df_test, nyc_street_data_unique, on='street_name', how='left', suffixes=('', '_street'))
            for col in nyc_street_data_unique.columns:
                if col != 'street_name' and col in df_test.columns:
                    if df_test[col].dtype == 'object' or df_test[col].dtype.name == 'category':
                        df_test[col] = df_test[col].fillna('unknown')
                    else:
                        if col in df_train.columns and df_train[col].dtype in ['int64', 'float64']:
                            df_test[col] = df_test[col].fillna(df_train[col].median())
                        else:
                            df_test[col] = df_test[col].fillna(0)
        
        if 'street_name' in df_test.columns and 'street_name' in nyc_census_tract_data_df.columns:
            nyc_census_tract_data_unique = nyc_census_tract_data_df.drop_duplicates(subset=['street_name'])
            df_test = pd.merge(df_test, nyc_census_tract_data_unique, on='street_name', how='left', suffixes=('', '_census'))
            for col in nyc_census_tract_data_unique.columns:
                if col != 'street_name' and col in df_test.columns:
                    if df_test[col].dtype == 'object' or df_test[col].dtype.name == 'category':
                        df_test[col] = df_test[col].fillna('unknown')
                    else:
                        if col in df_train.columns and df_train[col].dtype in ['int64', 'float64']:
                            df_test[col] = df_test[col].fillna(df_train[col].median())
                        else:
                            df_test[col] = df_test[col].fillna(0)

        # Ensure all columns in X_test match X_train
        X_test_processed = pd.DataFrame(index=df_test.index) # Initialize with test index

        for col in X_train.columns:
            if col in final_categorical_features:
                if col in df_test.columns:
                    df_test[col] = df_test[col].astype(str).str.lower()
                    # Get known categories from training data
                    known_categories = X[col].cat.categories.tolist()
                    # Assign 'unseen_category' to anything not in known_categories
                    df_test[col] = df_test[col].apply(lambda x: x if x in known_categories else 'unseen_category')
                    # Ensure 'unseen_category' is in the categories for this column in test set
                    if 'unseen_category' not in known_categories:
                        known_categories.append('unseen_category')
                    df_test[col] = pd.Categorical(df_test[col], categories=known_categories)
                    df_test[col] = df_test[col].fillna('unseen_category') # fill any NaNs with unseen
                    X_test_processed[col] = df_test[col]
                else:
                    # If a categorical column from training is missing in test, fill with 'unseen_category'
                    known_categories = X[col].cat.categories.tolist()
                    if 'unseen_category' not in known_categories:
                        known_categories.append('unseen_category')
                    X_test_processed[col] = pd.Categorical(['unseen_category'] * len(df_test), categories=known_categories)
            elif col in final_numerical_features:
                if col in df_test.columns:
                    # Impute missing numerical values in test set with the median from the training set
                    df_test[col] = df_test[col].fillna(X_train[col].median())
                    X_test_processed[col] = df_test[col]
                else:
                    # If a numerical column from training is missing in test, fill with training median
                    X_test_processed[col] = X_train[col].median()

        # Final check to ensure all columns in X_test_processed match X_train and are in the same order
        X_test = X_test_processed[X_train.columns]

        # Identify unseen key pairs for reporting
        train_keys = df_train[['street_name', 'violation_type']].drop_duplicates()
        test_keys = df_test[['street_name', 'violation_type']].drop_duplicates()
        
        merged_keys = pd.merge(test_keys, train_keys, on=['street_name', 'violation_type'], how='left', indicator=True)
        unseen_pairs_count = (merged_keys['_merge'] == 'left_only').sum()
        print(f"Number of (street_name, violation_type) pairs in test set unseen in training: {unseen_pairs_count}")

        # Make predictions
        test_preds = model.predict(X_test)
        
        # Ensure predictions are non-negative and integer-like
        predicted_counts = test_preds.clip(min=0).round().astype(int)

        # Create submission file
        submission_df = pd.DataFrame({
            'street_name': submission_keys['Street Name'],
            'violation_type': submission_keys['Violation Description'],
            'predicted_count': predicted_counts
        })
        submission_df.to_csv('submission.csv', index=False)
        print("Predictions saved to submission.csv")

        # If 'violation_count' is present in test_file_path, calculate test RMSE
        if 'violation_count' in df_test.columns:
            y_test = df_test['violation_count']
            test_rmse = rmse(y_test, predicted_counts)
            print(f"Test RMSE: {test_rmse}")
        else:
            print("Test file does not contain 'violation_count' for RMSE calculation.")

if __name__ == "__main__":
    main()
