
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder, OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import PoissonRegressor
import argparse
import os
import logging
import warnings
import sys
import subprocess

# Suppress warnings for cleaner output
warnings.filterwarnings('ignore')

# --- Install necessary libraries if not present ---
# This block should be at the very top to ensure dependencies are met before code execution.
try:
    import pandas
    import numpy
    import sklearn
    # Check for specific models/modules used
    # PoissonRegressor, OneHotEncoder, StandardScaler, ColumnTransformer are part of scikit-learn
except ImportError as e:
    print(f"Missing essential library: {e}. Attempting to install...", file=sys.stderr)
    try:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'pandas', 'numpy', 'scikit-learn'])
        print("Successfully installed pandas, numpy, scikit-learn.")
    except Exception as install_e:
        print(f"Failed to install necessary libraries: {install_e}", file=sys.stderr)
        print("Please ensure pip is installed and accessible, and try installing them manually.", file=sys.stderr)
        # Re-raise the error to halt execution if critical dependencies cannot be met
        raise

# Set up logging for better visibility during execution
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Helper function to load data safely ---
def load_data(file_path, df_name="DataFrame", column_mapping=None):
    """
    Loads a CSV file into a pandas DataFrame.
    Handles file not found errors and general exceptions during loading.
    Can also rename columns during loading.
    """
    if not os.path.exists(file_path):
        logging.warning(f"File not found at {file_path} for {df_name}. Returning empty DataFrame.")
        return pd.DataFrame()
    try:
        df = pd.read_csv(file_path)
        if column_mapping:
            df.rename(columns=column_mapping, inplace=True)
        logging.info(f"Successfully loaded {df_name} from {file_path} with {len(df)} rows.")
        return df
    except Exception as e:
        logging.error(f"Error loading {file_path} for {df_name}: {e}. Returning empty DataFrame.")
        return pd.DataFrame()

# --- Feature Engineering and Preprocessing Class ---
class FeatureEngineer:
    """
    Handles loading auxiliary data, creating new features, encoding categorical variables,
    and imputing missing values for both training and prediction datasets.
    Prepares data for RandomForest (numerical/encoded categoricals) and
    PoissonRegressor (numerical and OneHotEncoded categoricals).
    """
    def __init__(self):
        # For RandomForest LabelEncoding
        self.le_street = LabelEncoder()
        self.le_violation = LabelEncoder()
        self.le_borough = LabelEncoder()
        
        self.trained_street_violation_pairs = None # To track unseen pairs in test
        
        # For Grouped Categories (Reference Solution)
        self.top_streets = []
        self.top_violations = []

        # For PoissonRegressor ColumnTransformer
        self.poisson_preprocessor = None
        self.poisson_cat_cols = []
        self.poisson_num_cols = []

        # For RandomForest (final features determined during fit)
        self.rf_feature_cols = [] 

    def fit(self, df_train_raw, aux_data_dir="./input"):
        """
        Fits the feature engineer on the raw training data.
        Performs feature creation, imputation, and fits LabelEncoders and ColumnTransformer.
        Returns a DataFrame with all features (for both models) and the target (y) for training.
        """
        logging.info("Fitting FeatureEngineer...")

        # Step 1: Process core data (rename, store target, fill NaNs in key string cols)
        # Note: df_train_raw at this point already has columns renamed by main's load_data call
        df_train_processed = self._process_core_data(df_train_raw.copy(), is_train=True)
        y_train = df_train_processed['violation_count']
        # 'violation_count' is dropped if it accidentally remained after target separation
        df_train_processed.drop(columns=['violation_count'], errors='ignore', inplace=True) 

        # Step 2: Store key pairs for unseen tracking
        # Use the already renamed columns from df_train_raw as it's passed with renamed columns from main
        self.trained_street_violation_pairs = set(
            df_train_raw.apply(lambda row: (row['street_name'], row['violation_type']), axis=1) # Bug fix: Changed 'Street Name' to 'street_name' and 'Violation Description' to 'violation_type'
        )
        
        # Step 3: Add auxiliary features, basic derived features, and consolidate 'borough'
        df_train_features = self._add_auxiliary_features(df_train_processed.copy(), aux_data_dir)
        
        # Step 4: Create grouped categories (for PoissonRegressor)
        df_train_features = self._create_grouped_categories(df_train_features, is_train=True)
        
        # Step 5: Fit LabelEncoders (for RandomForest)
        self._fit_label_encoders(df_train_features)
        df_train_features = self._apply_label_encoders(df_train_features) # Adds _encoded columns

        # Step 6: Identify and prepare features for PoissonRegressor
        # Categorical features for PoissonRegressor (OHE)
        self.poisson_cat_cols = ['street_name_grouped', 'violation_type_grouped']
        if 'borough' in df_train_features.columns:
            self.poisson_cat_cols.append('borough')
        
        # Numerical features for PoissonRegressor (StandardScaler)
        # Include length features and other aux numerical features
        self.poisson_num_cols = [
            'street_name_len', 'violation_type_len', 'fine_amount_avg',
            'street_segment_length_sum', 'street_speed_limit_mean', 'street_num_lanes_mean',
            'num_parking_zones', 'avg_max_duration_parking',
            'avg_vehicle_count', 'max_vehicle_count', 'std_vehicle_count',
            'total_population_borough', 'median_household_income_borough', 'poverty_rate_borough'
        ]
        # Filter for columns that actually exist in the DataFrame to avoid errors
        self.poisson_num_cols = [col for col in self.poisson_num_cols if col in df_train_features.columns]
        
        # Ensure 'Unknown' for categorical and 0 for numerical for Poisson features
        for col in self.poisson_cat_cols:
            if col in df_train_features.columns:
                df_train_features[col] = df_train_features[col].fillna('Unknown').astype(str)
            else:
                df_train_features[col] = 'Unknown' # Add if missing
        for col in self.poisson_num_cols:
            if col in df_train_features.columns:
                df_train_features[col] = df_train_features[col].fillna(0)
            else:
                df_train_features[col] = 0.0 # Add if missing


        # Step 7: Create and fit ColumnTransformer for PoissonRegressor
        self.poisson_preprocessor = ColumnTransformer(
            transformers=[
                ('cat', OneHotEncoder(handle_unknown='ignore'), self.poisson_cat_cols),
                ('num', StandardScaler(), self.poisson_num_cols)
            ],
            remainder='passthrough' # Keep other columns for now, though they will be filtered later for actual model input
        )
        # Only fit on the relevant feature subset
        self.poisson_preprocessor.fit(df_train_features[self.poisson_cat_cols + self.poisson_num_cols])
        logging.info("PoissonRegressor preprocessor (ColumnTransformer) fitted.")

        # Step 8: Identify RandomForest features and impute remaining NaNs
        # RF uses all numerical features, including label-encoded ones
        self.rf_feature_cols = [
            col for col in df_train_features.select_dtypes(include=np.number).columns
            if col not in ['actual_violation_count'] # Exclude temp evaluation columns
        ]
        # Ensure all RF numerical features have no NaNs
        for col in self.rf_feature_cols:
            df_train_features[col].fillna(0, inplace=True)
            
        logging.info(f"Identified {len(self.rf_feature_cols)} features for RandomForest.")
        logging.info(f"Identified {len(self.poisson_cat_cols) + len(self.poisson_num_cols)} features for PoissonRegressor preprocessor.")
        
        return df_train_features, y_train

    def transform(self, df_data_raw, aux_data_dir="./input"):
        """
        Transforms new raw data (e.g., test/evaluation data) using the fitted feature engineer.
        Applies feature creation and imputation based on training data.
        Returns a DataFrame with all features (for both models).
        """
        logging.info("Transforming data using fitted FeatureEngineer...")
        df_data_processed = self._process_core_data(df_data_raw.copy(), is_train=False)
        df_data_features = self._add_auxiliary_features(df_data_processed.copy(), aux_data_dir)
        
        # Create grouped categories
        df_data_features = self._create_grouped_categories(df_data_features, is_train=False)
        
        # Apply LabelEncoders
        df_data_features = self._apply_label_encoders(df_data_features)

        # Ensure all PoissonRegressor features are present and filled for transformation
        for col in self.poisson_cat_cols:
            if col not in df_data_features.columns:
                df_data_features[col] = 'Unknown'
                logging.warning(f"Added missing Poisson categorical feature '{col}' to test data with 'Unknown'.")
            else:
                df_data_features[col] = df_data_features[col].fillna('Unknown').astype(str)

        for col in self.poisson_num_cols:
            if col not in df_data_features.columns:
                df_data_features[col] = 0.0
                logging.warning(f"Added missing Poisson numerical feature '{col}' to test data with 0.0.")
            else:
                df_data_features[col] = df_data_features[col].fillna(0)

        # Ensure all RandomForest features are present and filled for transformation
        for col in self.rf_feature_cols:
            if col not in df_data_features.columns:
                df_data_features[col] = 0.0 # Add missing features with a default value (e.g., 0)
                logging.warning(f"Added missing RF feature '{col}' to test data with 0.0.")
            else:
                df_data_features[col].fillna(0, inplace=True) # Fill NaNs for existing columns

        return df_data_features

    def _process_core_data(self, df, is_train=False):
        """Standardizes column names and handles target column for test data."""
        # This function renames columns, if they haven't been renamed already.
        # It handles the case where raw data might still have original names.
        df.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type',
            'violation_count': 'violation_count'
        }, inplace=True)

        if not is_train and 'violation_count' in df.columns:
            df['actual_violation_count'] = df['violation_count'] # Store actual counts for evaluation
            df.drop(columns=['violation_count'], inplace=True)
            
        df['street_name'] = df['street_name'].fillna('UNKNOWN_STREET').astype(str)
        df['violation_type'] = df['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str)
        return df

    def _add_auxiliary_features(self, df, aux_data_dir):
        """
        Loads and merges auxiliary data to enrich the main DataFrame with additional features.
        Also adds basic derived features like length.
        """
        logging.info("Adding auxiliary features and derived features...")

        # Add basic length features from reference solution
        df['street_name_len'] = df['street_name'].apply(lambda x: len(str(x)) if pd.notna(x) else 0)
        df['violation_type_len'] = df['violation_type'].apply(lambda x: len(str(x)) if pd.notna(x) else 0)

        # Merge nyc_borough_data.csv (from reference solution, handled here for consistency)
        nyc_borough_df = load_data(os.path.join(aux_data_dir, 'nyc_borough_data.csv'), 'NYC Borough Data')
        if not nyc_borough_df.empty:
            nyc_borough_df.rename(columns={'Street Name': 'street_name'}, inplace=True)
            # Use left merge to keep all original rows, and add 'Borough' if matching street name exists
            df = pd.merge(df, nyc_borough_df[['street_name', 'Borough']], on='street_name', how='left', suffixes=('', '_nyc_borough'))
            
            # Consolidate 'borough' column from this merge with potentially existing 'borough'
            if 'borough_nyc_borough' in df.columns:
                # If a 'borough' column already exists from previous merges, fill its NaNs with this new source
                if 'borough' in df.columns:
                    df['borough'] = df['borough'].fillna(df['borough_nyc_borough'])
                else: # Otherwise, this is the first 'borough' source
                    df['borough'] = df['borough_nyc_borough']
                df.drop(columns=['borough_nyc_borough'], inplace=True)
            logging.info(f"Merged NYC Borough data. DF shape: {df.shape}")
        
        # --- Violation Codes Features ---
        violation_codes_df = load_data(os.path.join(aux_data_dir, 'violation_codes.csv'), 'Violation Codes')
        if not violation_codes_df.empty:
            violation_codes_df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
            violation_codes_df['fine_amount_avg'] = (
                violation_codes_df['Manhattan 96th St. & Below'].fillna(0) + 
                violation_codes_df['All Other Areas'].fillna(0)
            ) / 2
            violation_codes_df.drop(columns=['Violation Code', 'Manhattan 96th St. & Below', 'All Other Areas'], errors='ignore', inplace=True)
            df = pd.merge(df, violation_codes_df, on='violation_type', how='left')
            logging.info(f"Merged violation codes. DF shape: {df.shape}")
        
        # --- Street Segments Features ---
        street_segments_df = load_data(os.path.join(aux_data_dir, 'nyc_street_segments.csv'), 'Street Segments')
        if not street_segments_df.empty:
            street_segments_agg = street_segments_df.groupby('Street Name').agg(
                street_segment_length_sum=('Segment Length', 'sum'),
                street_speed_limit_mean=('Speed Limit', 'mean'),
                street_num_lanes_mean=('Number of Lanes', 'mean'),
                borough_ss=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            street_segments_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, street_segments_agg, on='street_name', how='left')
            logging.info(f"Merged street segments. DF shape: {df.shape}")
            
        # --- Parking Zones Features ---
        parking_zones_df = load_data(os.path.join(aux_data_dir, 'nyc_parking_zones.csv'), 'Parking Zones')
        if not parking_zones_df.empty:
            parking_zones_agg = parking_zones_df.groupby('Street Name').agg(
                num_parking_zones=('Parking Zone', 'count'),
                avg_max_duration_parking=('Max Duration', 'mean'),
                borough_pz=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            parking_zones_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, parking_zones_agg, on='street_name', how='left')

            # Consolidate borough information (Base solution's logic for multiple borough sources)
            # If 'borough' column exists (from nyc_borough_data.csv merge or initialized)
            if 'borough' not in df.columns:
                df['borough'] = np.nan

            if 'borough_ss' in df.columns:
                df['borough'] = df['borough'].fillna(df['borough_ss'])
            if 'borough_pz' in df.columns:
                df['borough'] = df['borough'].fillna(df['borough_pz'])
            
            df.drop(columns=['borough_ss', 'borough_pz'], errors='ignore', inplace=True)
            logging.info(f"Merged parking zones. DF shape: {df.shape}")

        # --- Traffic Counts Features ---
        traffic_counts_df = load_data(os.path.join(aux_data_dir, 'traffic_counts_nyc.csv'), 'Traffic Counts')
        if not traffic_counts_df.empty:
            traffic_counts_agg = traffic_counts_df.groupby('Street Name').agg(
                avg_vehicle_count=('Vehicle Count', 'mean'),
                max_vehicle_count=('Vehicle Count', 'max'),
                std_vehicle_count=('Vehicle Count', 'std')
            ).reset_index()
            traffic_counts_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, traffic_counts_agg, on='street_name', how='left')
            logging.info(f"Merged traffic counts. DF shape: {df.shape}")

        # --- Census Tracts Features ---
        # Ensure 'borough' column exists for merging census data
        if 'borough' not in df.columns:
            df['borough'] = np.nan
        
        # Create a temporary 'Borough' column for merging census data, filled for consistency
        # Census data uses 'Borough' as the key, so use that for merging, then drop
        # Make a copy to avoid SettingWithCopyWarning if df is a slice
        temp_borough_for_census = df[['borough']].copy() 
        temp_borough_for_census.rename(columns={'borough': 'Borough'}, inplace=True)
        temp_borough_for_census['Borough'] = temp_borough_for_census['Borough'].fillna('UNKNOWN_BOROUGH').astype(str)
        
        # Merge census data
        census_tracts_df = load_data(os.path.join(aux_data_dir, 'nyc_census_tracts.csv'), 'Census Tracts')
        if not census_tracts_df.empty:
            census_borough_agg = census_tracts_df.groupby('Borough').agg(
                total_population_borough=('Total Population', 'sum'),
                median_household_income_borough=('Median Household Income', 'mean'),
                poverty_rate_borough=('Poverty Rate', 'mean')
            ).reset_index()
            # Merge with the main df using the temporary 'Borough' column
            df = pd.merge(df, census_borough_agg, on='Borough', how='left')
            logging.info(f"Merged census tracts. DF shape: {df.shape}")
        else:
            logging.warning("Census tracts data not available or empty.")
        
        df.drop(columns=['Borough'], errors='ignore', inplace=True) # Drop temporary merge column

        logging.info("Finished adding auxiliary features.")
        return df

    def _create_grouped_categories(self, df, is_train=False):
        """
        Creates grouped categorical features based on frequency for high-cardinality columns.
        Uses top categories learned from training data.
        """
        N_top_streets = 100
        N_top_violations = 50

        if is_train:
            self.top_streets = df['street_name'].value_counts().nlargest(N_top_streets).index.tolist()
            self.top_violations = df['violation_type'].value_counts().nlargest(N_top_violations).index.tolist()

        df['street_name_grouped'] = np.where(df['street_name'].isin(self.top_streets), df['street_name'], 'Other_Street')
        df['violation_type_grouped'] = np.where(df['violation_type'].isin(self.top_violations), df['violation_type'], 'Other_Violation')

        # Ensure 'borough' is string type for OHE and filled. It might be NaN from aux merges.
        if 'borough' in df.columns:
            df['borough'] = df['borough'].fillna('UNKNOWN_BOROUGH').astype(str)
        else: # If 'borough' didn't come from any merge or was not initialized, add it for consistency
            df['borough'] = 'UNKNOWN_BOROUGH'
            logging.warning("Borough column not found after aux merges, initialized to 'UNKNOWN_BOROUGH'.")

        logging.info("Created grouped categorical features.")
        return df

    def _fit_label_encoders(self, df):
        """Fits LabelEncoders on unique values from the processed training data."""
        logging.info("Fitting LabelEncoders...")
        self.le_street.fit(df['street_name'].unique())
        self.le_violation.fit(df['violation_type'].unique())
        
        # Fit borough LE only if it exists and has non-null values
        if 'borough' in df.columns and not df['borough'].isnull().all():
            self.le_borough.fit(df['borough'].unique()) # .fillna('UNKNOWN_BOROUGH') already done in _create_grouped_categories
        else:
            logging.warning("No valid 'borough' column found to fit LabelEncoder for borough.")

    def _apply_label_encoders(self, df):
        """Applies fitted LabelEncoders to categorical columns, mapping unseen categories to -1."""
        logging.info("Applying LabelEncoders...")
        
        df['street_name_encoded'] = df['street_name'].map(
            lambda x: self.le_street.transform([x])[0] if x in self.le_street.classes_ else -1
        ).fillna(-1).astype(int)

        df['violation_type_encoded'] = df['violation_type'].map(
            lambda x: self.le_violation.transform([x])[0] if x in self.le_violation.classes_ else -1
        ).fillna(-1).astype(int)
        
        # Apply borough LE only if it was fitted
        if hasattr(self.le_borough, 'classes_') and len(self.le_borough.classes_) > 0:
            df['borough_encoded'] = df['borough'].map(
                lambda x: self.le_borough.transform([x])[0] if x in self.le_borough.classes_ else -1
            ).fillna(-1).astype(int)
        else:
            df['borough_encoded'] = -1
            
        return df

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations for 2023 using RandomForest and PoissonRegressor.")
    parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Optional: Path to the 2023 test/evaluation data CSV. If provided, predictions will be generated.")
    parser.add_argument("--aux-data-dir", type=str, default="./input",
                        help="Directory containing auxiliary data CSV files.")
    
    args = parser.parse_args()

    logging.info(f"Starting prediction pipeline with train_path: {args.train_path}")

    # Load 2022 training data
    # Use column_mapping as introduced in the reference solution for main dataframes
    train_2022_raw = load_data(args.train_path, '2022 Training Data',
                               column_mapping={'Street Name': 'street_name',
                                               'Violation Description': 'violation_type',
                                               'violation_count': 'violation_count'})
    if train_2022_raw.empty:
        logging.error("Training data is empty or could not be loaded. Exiting.")
        return

    # Initialize Feature Engineer
    fe = FeatureEngineer()

    # Fit feature engineer on the full 2022 data and get processed features and target
    X_full_2022_df_all_features, y_full_2022 = fe.fit(train_2022_raw, args.aux_data_dir)
    
    # Split 2022 data into training and validation sets for development evaluation
    X_train_all_features, X_val_all_features, y_train, y_val = train_test_split(
        X_full_2022_df_all_features, y_full_2022, test_size=0.2, random_state=42
    )
    
    logging.info(f"Training data shape: {X_train_all_features.shape}, Validation data shape: {X_val_all_features.shape}")

    # --- Model Training: RandomForestRegressor ---
    logging.info("Training RandomForestRegressor model...")
    rf_model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1, min_samples_leaf=5)
    
    # Select features for RandomForest
    X_train_rf = X_train_all_features[fe.rf_feature_cols]
    rf_model.fit(X_train_rf, y_train)
    logging.info("RandomForestRegressor model training complete.")

    # --- Model Training: PoissonRegressor ---
    logging.info("Training PoissonRegressor model...")
    # Prepare data for PoissonRegressor using the fitted preprocessor
    X_train_poisson_raw = X_train_all_features[fe.poisson_cat_cols + fe.poisson_num_cols]
    X_train_poisson_processed = fe.poisson_preprocessor.transform(X_train_poisson_raw)
    
    # PoissonRegressor requires non-negative integers. Ensure y_train is int.
    y_train_poisson_clipped = y_train.clip(lower=0).astype(int)
    
    poisson_model = PoissonRegressor(alpha=1.0, max_iter=2000, tol=1e-3)
    poisson_model.fit(X_train_poisson_processed, y_train_poisson_clipped)
    logging.info("PoissonRegressor model training complete.")

    # --- Validation Prediction and Evaluation ---
    logging.info("Generating validation predictions...")
    # RandomForest predictions
    X_val_rf = X_val_all_features[fe.rf_feature_cols]
    val_predictions_rf = rf_model.predict(X_val_rf)
    val_predictions_rf[val_predictions_rf < 0] = 0 # Ensure predictions are non-negative

    # PoissonRegressor predictions
    X_val_poisson_raw = X_val_all_features[fe.poisson_cat_cols + fe.poisson_num_cols]
    X_val_poisson_processed = fe.poisson_preprocessor.transform(X_val_poisson_raw)
    val_predictions_poisson = poisson_model.predict(X_val_poisson_processed)
    val_predictions_poisson[val_predictions_poisson < 0] = 0 # Ensure predictions are non-negative

    # Ensemble predictions (simple average)
    val_predictions_ensemble = (val_predictions_rf + val_predictions_poisson) / 2
    val_predictions_ensemble = np.round(val_predictions_ensemble).astype(int) # Round to nearest integer

    val_rmse = np.sqrt(mean_squared_error(y_val, val_predictions_ensemble))
    print(f"Final Validation Performance: {val_rmse:.4f}")

    # --- 2023 Prediction if test-path is provided ---
    if args.test_path:
        logging.info(f"Processing test data from {args.test_path} for 2023 predictions.")
        test_2023_raw = load_data(args.test_path, '2023 Test Data',
                                  column_mapping={'Street Name': 'street_name',
                                                  'Violation Description': 'violation_type',
                                                  'violation_count': 'violation_count'}) # Use same mapping
        if test_2023_raw.empty:
            logging.warning("Test data is empty or not found. Skipping 2023 predictions.")
            return

        # Keep original key columns for submission output (using renamed columns)
        submission_keys_raw = test_2023_raw[['street_name', 'violation_type']].copy()

        # Store target for evaluation if present before feature engineering
        y_test_actual = None
        if 'violation_count' in test_2023_raw.columns:
            y_test_actual = test_2023_raw['violation_count'].copy()
        
        # Transform test data using the *fitted* feature engineer
        X_test_all_features = fe.transform(test_2023_raw.copy(), args.aux_data_dir)

        # Report unseen key pairs in the test set
        test_street_violation_pairs = set(
            submission_keys_raw.apply(lambda row: (row['street_name'], row['violation_type']), axis=1)
        )
        unseen_pairs_count = len(test_street_violation_pairs - fe.trained_street_violation_pairs)
        logging.info(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_pairs_count}")

        # Make predictions on the transformed test data with both models
        X_test_rf = X_test_all_features[fe.rf_feature_cols]
        predictions_2023_rf = rf_model.predict(X_test_rf)
        predictions_2023_rf[predictions_2023_rf < 0] = 0 # Ensure non-negative counts

        X_test_poisson_raw = X_test_all_features[fe.poisson_cat_cols + fe.poisson_num_cols]
        X_test_poisson_processed = fe.poisson_preprocessor.transform(X_test_poisson_raw)
        predictions_2023_poisson = poisson_model.predict(X_test_poisson_processed)
        predictions_2023_poisson[predictions_2023_poisson < 0] = 0 # Ensure non-negative counts

        # Ensemble test predictions
        predictions_2023_ensemble = (predictions_2023_rf + predictions_2023_poisson) / 2
        predictions_2023_ensemble = np.round(predictions_2023_ensemble).astype(int) # Round to integer counts

        # Create submission file
        submission_df = submission_keys_raw
        submission_df['predicted_count'] = predictions_2023_ensemble
        submission_df.to_csv('submission.csv', index=False)
        logging.info("Generated submission.csv with 2023 predictions.")

        # Evaluate if actual counts are present in the provided test/eval file
        if y_test_actual is not None:
            test_rmse = np.sqrt(mean_squared_error(y_test_actual, predictions_2023_ensemble))
            print(f"RMSE on provided test/eval data: {test_rmse:.4f}")
        else:
            logging.info("No 'violation_count' column found in test data for evaluation.")
            
    else:
        logging.info("No test-path provided. Skipping 2023 predictions and submission file generation.")

if __name__ == '__main__':
    main()
