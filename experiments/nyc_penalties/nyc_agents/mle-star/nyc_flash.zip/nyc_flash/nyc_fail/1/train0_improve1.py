
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import argparse
import os
import logging

# Set up logging for better visibility during execution
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Helper function to load data safely ---
def load_data(file_path, df_name="DataFrame"):
    """
    Loads a CSV file into a pandas DataFrame.
    Handles file not found errors and general exceptions during loading.
    """
    if not os.path.exists(file_path):
        logging.warning(f"File not found at {file_path} for {df_name}. Returning empty DataFrame.")
        return pd.DataFrame()
    try:
        df = pd.read_csv(file_path)
        logging.info(f"Successfully loaded {df_name} from {file_path} with {len(df)} rows.")
        return df
    except Exception as e:
        logging.error(f"Error loading {file_path} for {df_name}: {e}. Returning empty DataFrame.")
        return pd.DataFrame()

# --- Feature Engineering and Preprocessing Class ---
class FeatureEngineer:
    """
    Handles loading auxiliary data, creating new features, and imputing missing values
    for both training and prediction datasets.
    It prepares data suitable for RandomForest, which requires numerical input.
    """
    def __init__(self):
        self.trained_street_violation_pairs = None # To track unseen pairs in test
        self.feature_columns = [] # To store names of final features for the model
        
        # Label encoders for categorical features
        self.le_street = LabelEncoder()
        self.le_violation = LabelEncoder()
        self.le_borough = LabelEncoder()
        
        # Keep track of original categorical column names to process them
        self._original_categorical_cols = ['street_name', 'violation_type', 'borough']

    def fit(self, df_train_raw, aux_data_dir="./input"):
        """
        Fits the feature engineer on the raw training data.
        Performs feature creation, imputation, and fits LabelEncoders.
        Returns processed features (X) and target (y) for training.
        """
        logging.info("Fitting FeatureEngineer...")
        # Store unique (street_name, violation_type) pairs from training for unseen pair tracking
        self.trained_street_violation_pairs = set(
            df_train_raw.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1)
        )
        
        # Process core data and add auxiliary features
        df_train_features = self._add_auxiliary_features(df_train_raw.copy(), aux_data_dir)
        
        # Rename core columns to be consistent
        df_train_features.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type',
            'violation_count': 'violation_count'
        }, inplace=True)
        
        # Handle target column
        target = 'violation_count'
        y_train = df_train_features[target]
        df_train_features.drop(columns=[target], inplace=True) # Drop target from features

        # Fit LabelEncoders for categorical features
        df_train_features['street_name_encoded'] = self.le_street.fit_transform(
            df_train_features['street_name'].fillna('UNKNOWN_STREET').astype(str)
        )
        df_train_features['violation_type_encoded'] = self.le_violation.fit_transform(
            df_train_features['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str)
        )
        # Borough might not always be present or fully filled, ensure it's handled
        if 'borough' in df_train_features.columns:
            df_train_features['borough_encoded'] = self.le_borough.fit_transform(
                df_train_features['borough'].fillna('UNKNOWN_BOROUGH').astype(str)
            )
        else:
            df_train_features['borough_encoded'] = -1 # Default for missing borough
            logging.warning("No 'borough' column found during feature engineering in train. Using -1 for encoded.")

        # Impute missing numerical values (after all joins and encodings)
        numerical_cols = df_train_features.select_dtypes(include=np.number).columns
        for col in numerical_cols:
            df_train_features[col].fillna(0, inplace=True) # Simple imputation with 0
        
        # Define the final feature columns for the model
        # Exclude original string columns, and any temporary columns
        self.feature_columns = [
            col for col in df_train_features.columns
            if col not in self._original_categorical_cols and col != 'actual_violation_count'
        ]
        
        logging.info(f"Identified {len(self.feature_columns)} features for RandomForest.")
        return df_train_features[self.feature_columns], y_train

    def transform(self, df_data_raw, aux_data_dir="./input"):
        """
        Transforms new raw data (e.g., test/evaluation data) using the fitted feature engineer.
        Applies feature creation and imputation based on training data.
        """
        logging.info("Transforming data using fitted FeatureEngineer...")
        df_data_features = self._add_auxiliary_features(df_data_raw.copy(), aux_data_dir)
        
        # Store actual_violation_count if present for later evaluation
        if 'violation_count' in df_data_features.columns:
            df_data_features['actual_violation_count'] = df_data_features['violation_count']
            df_data_features.drop(columns=['violation_count'], inplace=True)

        # Rename core columns
        df_data_features.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type'
        }, inplace=True)

        # Apply LabelEncoders, handling unseen categories with -1
        df_data_features['street_name_encoded'] = df_data_features['street_name'].fillna('UNKNOWN_STREET').astype(str).map(
            lambda x: self.le_street.transform([x])[0] if x in self.le_street.classes_ else -1
        )
        df_data_features['violation_type_encoded'] = df_data_features['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str).map(
            lambda x: self.le_violation.transform([x])[0] if x in self.le_violation.classes_ else -1
        )
        
        if 'borough' in df_data_features.columns:
            df_data_features['borough_encoded'] = df_data_features['borough'].fillna('UNKNOWN_BOROUGH').astype(str).map(
                lambda x: self.le_borough.transform([x])[0] if x in self.le_borough.classes_ else -1
            )
        else:
            df_data_features['borough_encoded'] = -1 # Default for missing borough
            logging.warning("No 'borough' column found during feature engineering in test. Using -1 for encoded.")

        # Impute missing numerical values
        numerical_cols = df_data_features.select_dtypes(include=np.number).columns
        for col in numerical_cols:
            df_data_features[col].fillna(0, inplace=True) # Simple imputation with 0
            
        # Ensure all feature columns from training are present and in order
        for col in self.feature_columns:
            if col not in df_data_features.columns:
                df_data_features[col] = 0 # Add missing features with a default value (e.g., 0)
                logging.warning(f"Added missing feature '{col}' to test data with 0.")

        return df_data_features[self.feature_columns]

    def _add_auxiliary_features(self, df, aux_data_dir):
        """
        Loads and merges auxiliary data to enrich the main DataFrame with additional features.
        Standardizes merge keys, extracts broader aggregations, and adds missing value indicators.
        """
        logging.info("Adding auxiliary features...")

        # --- Violation Codes Features ---
        logging.info("Processing Violation Codes...")
        violation_codes_df = load_data(os.path.join(aux_data_dir, 'violation_codes.csv'), 'Violation Codes')
        if not violation_codes_df.empty:
            violation_codes_df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
            
            # Ensure consistency and calculate broader aggregations for fine amounts
            manhattan_fines = violation_codes_df['Manhattan 96th St. & Below'].fillna(0)
            other_fines = violation_codes_df['All Other Areas'].fillna(0)
            
            violation_codes_df['fine_amount_avg'] = (manhattan_fines + other_fines) / 2
            violation_codes_df['fine_amount_min'] = pd.concat([manhattan_fines, other_fines], axis=1).min(axis=1)
            violation_codes_df['fine_amount_max'] = pd.concat([manhattan_fines, other_fines], axis=1).max(axis=1)
            violation_codes_df['fine_amount_diff'] = abs(manhattan_fines - other_fines) # Interaction term
            
            # Drop original columns after aggregation
            violation_codes_df.drop(columns=['Violation Code', 'Manhattan 96th St. & Below', 'All Other Areas'], errors='ignore', inplace=True)
            
            # Perform merge and add indicator columns for non-matches
            new_cols_before_merge = set(df.columns)
            df = pd.merge(df, violation_codes_df, on='violation_type', how='left')
            added_cols = set(df.columns) - new_cols_before_merge
            for col in ['fine_amount_avg', 'fine_amount_min', 'fine_amount_max', 'fine_amount_diff']:
                if col in added_cols: # Check if the column was actually added
                    df[f'{col}_is_null'] = df[col].isnull().astype(int)
            logging.info(f"Merged violation codes. DF shape: {df.shape}")
        
        # --- Street Segments Features ---
        logging.info("Processing Street Segments...")
        street_segments_df = load_data(os.path.join(aux_data_dir, 'nyc_street_segments.csv'), 'Street Segments')
        if not street_segments_df.empty:
            # Standardize 'Street Name' to 'street_name' before aggregation
            street_segments_df.rename(columns={'Street Name': 'street_name'}, inplace=True)
            
            street_segments_agg = street_segments_df.groupby('street_name').agg(
                street_segment_length_sum=('Segment Length', 'sum'),
                street_segment_length_min=('Segment Length', 'min'),
                street_segment_length_max=('Segment Length', 'max'),
                street_segment_length_std=('Segment Length', 'std'),
                street_segment_count=('Segment Length', 'count'), # Add count
                street_speed_limit_mean=('Speed Limit', 'mean'),
                street_speed_limit_min=('Speed Limit', 'min'),
                street_speed_limit_max=('Speed Limit', 'max'),
                street_speed_limit_std=('Speed Limit', 'std'),
                street_num_lanes_mean=('Number of Lanes', 'mean'),
                street_num_lanes_min=('Number of Lanes', 'min'),
                street_num_lanes_max=('Number of Lanes', 'max'),
                street_num_lanes_std=('Number of Lanes', 'std'),
                borough_ss=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            
            # Perform merge and add indicator columns
            new_cols_before_merge = set(df.columns)
            df = pd.merge(df, street_segments_agg, on='street_name', how='left')
            added_cols = set(df.columns) - new_cols_before_merge
            for col in [
                'street_segment_length_sum', 'street_segment_length_min', 'street_segment_length_max', 
                'street_segment_length_std', 'street_segment_count',
                'street_speed_limit_mean', 'street_speed_limit_min', 'street_speed_limit_max', 
                'street_speed_limit_std',
                'street_num_lanes_mean', 'street_num_lanes_min', 'street_num_lanes_max', 
                'street_num_lanes_std'
            ]:
                if col in added_cols:
                    df[f'{col}_is_null'] = df[col].isnull().astype(int)
            logging.info(f"Merged street segments. DF shape: {df.shape}")
            
        # --- Parking Zones Features ---
        logging.info("Processing Parking Zones...")
        parking_zones_df = load_data(os.path.join(aux_data_dir, 'nyc_parking_zones.csv'), 'Parking Zones')
        if not parking_zones_df.empty:
            # Standardize 'Street Name' to 'street_name' before aggregation
            parking_zones_df.rename(columns={'Street Name': 'street_name'}, inplace=True)

            parking_zones_agg = parking_zones_df.groupby('street_name').agg(
                num_parking_zones=('Parking Zone', 'count'),
                avg_max_duration_parking=('Max Duration', 'mean'),
                min_max_duration_parking=('Max Duration', 'min'), # Added
                max_max_duration_parking=('Max Duration', 'max'), # Added
                std_max_duration_parking=('Max Duration', 'std'), # Added
                borough_pz=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            
            # Perform merge and add indicator columns
            new_cols_before_merge = set(df.columns)
            df = pd.merge(df, parking_zones_agg, on='street_name', how='left')
            added_cols = set(df.columns) - new_cols_before_merge
            for col in [
                'num_parking_zones', 'avg_max_duration_parking', 'min_max_duration_parking', 
                'max_max_duration_parking', 'std_max_duration_parking'
            ]:
                if col in added_cols:
                    df[f'{col}_is_null'] = df[col].isnull().astype(int)

            # Consolidate borough information
            if 'borough_ss' in df.columns and 'borough_pz' in df.columns:
                df['borough'] = df['borough_ss'].fillna(df['borough_pz'])
            elif 'borough_ss' in df.columns:
                 df['borough'] = df['borough_ss']
            elif 'borough_pz' in df.columns:
                 df['borough'] = df['borough_pz']
            else: # If no borough from aux data, initialize
                df['borough'] = np.nan
            
            # Add indicator for the consolidated borough column
            if 'borough' in df.columns:
                df['borough_is_null'] = df['borough'].isnull().astype(int) # Indicator for the final consolidated borough
            
            df.drop(columns=['borough_ss', 'borough_pz'], errors='ignore', inplace=True)
            logging.info(f"Merged parking zones. DF shape: {df.shape}")

        # --- Traffic Counts Features ---
        logging.info("Processing Traffic Counts...")
        traffic_counts_df = load_data(os.path.join(aux_data_dir, 'traffic_counts_nyc.csv'), 'Traffic Counts')
        if not traffic_counts_df.empty:
            # Standardize 'Street Name' to 'street_name' before aggregation
            traffic_counts_df.rename(columns={'Street Name': 'street_name'}, inplace=True)

            traffic_counts_agg = traffic_counts_df.groupby('street_name').agg(
                avg_vehicle_count=('Vehicle Count', 'mean'),
                min_vehicle_count=('Vehicle Count', 'min'), # Added
                max_vehicle_count=('Vehicle Count', 'max'),
                std_vehicle_count=('Vehicle Count', 'std'),
                total_vehicle_count=('Vehicle Count', 'sum'), # Added sum
                num_traffic_counts=('Vehicle Count', 'count') # Added count
            ).reset_index()
            
            # Perform merge and add indicator columns
            new_cols_before_merge = set(df.columns)
            df = pd.merge(df, traffic_counts_agg, on='street_name', how='left')
            added_cols = set(df.columns) - new_cols_before_merge
            for col in [
                'avg_vehicle_count', 'min_vehicle_count', 'max_vehicle_count', 
                'std_vehicle_count', 'total_vehicle_count', 'num_traffic_counts'
            ]:
                if col in added_cols:
                    df[f'{col}_is_null'] = df[col].isnull().astype(int)
            logging.info(f"Merged traffic counts. DF shape: {df.shape}")

        # --- Census Tracts Features ---
        logging.info("Processing Census Tracts...")
        # Ensure 'borough' column exists for merging census data
        if 'borough' not in df.columns:
            df['borough'] = np.nan # Create it if not already present from other merges
            # Add indicator if this was newly created as all NaN
            df['borough_is_null'] = 1 # Mark all as null if borough was just created and is all NaN
        
        census_tracts_df = load_data(os.path.join(aux_data_dir, 'nyc_census_tracts.csv'), 'Census Tracts')
        if not census_tracts_df.empty:
            # Standardize 'Borough' to 'borough' before aggregation
            census_tracts_df.rename(columns={'Borough': 'borough'}, inplace=True)

            census_borough_agg = census_tracts_df.groupby('borough').agg(
                total_population_borough=('Total Population', 'sum'),
                total_population_borough_min=('Total Population', 'min'), # Added
                total_population_borough_max=('Total Population', 'max'), # Added
                total_population_borough_std=('Total Population', 'std'), # Added
                num_census_tracts=('Total Population', 'count'), # Count of tracts per borough
                median_household_income_borough=('Median Household Income', 'mean'),
                median_household_income_borough_min=('Median Household Income', 'min'), # Added
                median_household_income_borough_max=('Median Household Income', 'max'), # Added
                median_household_income_borough_std=('Median Household Income', 'std'), # Added
                poverty_rate_borough=('Poverty Rate', 'mean'),
                poverty_rate_borough_min=('Poverty Rate', 'min'), # Added
                poverty_rate_borough_max=('Poverty Rate', 'max'), # Added
                poverty_rate_borough_std=('Poverty Rate', 'std') # Added
            ).reset_index()
            
            # Perform merge and add indicator columns
            new_cols_before_merge = set(df.columns)
            df = pd.merge(df, census_borough_agg, on='borough', how='left')
            added_cols = set(df.columns) - new_cols_before_merge
            for col in [
                'total_population_borough', 'total_population_borough_min', 'total_population_borough_max', 
                'total_population_borough_std', 'num_census_tracts',
                'median_household_income_borough', 'median_household_income_borough_min', 
                'median_household_income_borough_max', 'median_household_income_borough_std',
                'poverty_rate_borough', 'poverty_rate_borough_min', 'poverty_rate_borough_max', 
                'poverty_rate_borough_std'
            ]:
                if col in added_cols:
                    df[f'{col}_is_null'] = df[col].isnull().astype(int)
            logging.info(f"Merged census tracts. DF shape: {df.shape}")
        else:
            logging.warning("Census tracts data not available or empty.")

        logging.info("Finished adding auxiliary features.")
        return df

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations for 2023 using RandomForestRegressor.")
    parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Optional: Path to the 2023 test/evaluation data CSV. If provided, predictions will be generated.")
    parser.add_argument("--aux-data-dir", type=str, default="./input",
                        help="Directory containing auxiliary data CSV files.")
    
    args = parser.parse_args()

    logging.info(f"Starting prediction pipeline with train_path: {args.train_path}")

    # Load 2022 training data
    train_2022_raw = load_data(args.train_path, '2022 Training Data')
    if train_2022_raw.empty:
        logging.error("Training data is empty or could not be loaded. Exiting.")
        return

    # Initialize Feature Engineer
    fe = FeatureEngineer()

    # Fit feature engineer on the full 2022 data and get processed features and target
    X_full_2022, y_full_2022 = fe.fit(train_2022_raw, args.aux_data_dir)
    
    # Split 2022 data into training and validation sets for development evaluation
    X_train, X_val, y_train, y_val = train_test_split(
        X_full_2022, y_full_2022, test_size=0.2, random_state=42
    )
    
    logging.info(f"Training data shape: {X_train.shape}, Validation data shape: {X_val.shape}")

    # --- Model Training ---
    logging.info("Training RandomForestRegressor model...")
    # Using parameters from the model description example
    rf_model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1, min_samples_leaf=5)
    rf_model.fit(X_train, y_train)
    logging.info("Model training complete.")

    # --- Validation Prediction and Evaluation ---
    val_predictions = rf_model.predict(X_val)
    val_predictions[val_predictions < 0] = 0 # Ensure predictions are non-negative
    val_predictions = np.round(val_predictions).astype(int) # Round to nearest integer

    val_rmse = np.sqrt(mean_squared_error(y_val, val_predictions))
    print(f"Final Validation Performance: {val_rmse:.4f}")

    # --- 2023 Prediction if test-path is provided ---
    if args.test_path:
        logging.info(f"Processing test data from {args.test_path} for 2023 predictions.")
        test_2023_raw = load_data(args.test_path, '2023 Test Data')
        if test_2023_raw.empty:
            logging.warning("Test data is empty or not found. Skipping 2023 predictions.")
            return

        # Keep original key columns for submission output
        submission_keys_raw = test_2023_raw[['Street Name', 'Violation Description']].copy()
        
        # Transform test data using the *fitted* feature engineer
        X_test = fe.transform(test_2023_raw.copy(), args.aux_data_dir)

        # Report unseen key pairs in the test set
        test_street_violation_pairs = set(
            submission_keys_raw.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1)
        )
        unseen_pairs_count = len(test_street_violation_pairs - fe.trained_street_violation_pairs)
        logging.info(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_pairs_count}")
        # Handling of unseen pairs: LabelEncoder maps unseen categories to -1, which RandomForest treats as a distinct numerical value.
        # This allows the model to make predictions even for completely new street/violation combinations.

        # Make predictions on the transformed test data
        predictions_2023 = rf_model.predict(X_test)
        predictions_2023[predictions_2023 < 0] = 0 # Ensure non-negative counts
        predictions_2023 = np.round(predictions_2023).astype(int) # Round to integer counts

        # Create submission file
        submission_df = submission_keys_raw
        submission_df.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type'
        }, inplace=True)
        submission_df['predicted_count'] = predictions_2023
        submission_df.to_csv('submission.csv', index=False)
        logging.info("Generated submission.csv with 2023 predictions.")

        # Evaluate if actual counts are present in the provided test/eval file
        # Check if 'actual_violation_count' was stored during _process_core_data or transform
        if 'actual_violation_count' in test_2023_raw.columns:
            test_rmse = np.sqrt(mean_squared_error(test_2023_raw['actual_violation_count'], predictions_2023))
            print(f"RMSE on provided test/eval data: {test_rmse:.4f}")
            
    else:
        logging.info("No test-path provided. Skipping 2023 predictions and submission file generation.")

if __name__ == '__main__':
    main()
