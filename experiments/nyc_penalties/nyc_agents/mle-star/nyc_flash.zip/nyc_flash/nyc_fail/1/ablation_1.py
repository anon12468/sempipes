
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import argparse
import os
import logging
import copy # Used for deep copying objects for clean ablation runs

# Set up logging for better visibility during execution
# Temporarily disable logging during the ablation study to keep the output clean.
# It will be re-enabled at the end.
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logging.disable(logging.CRITICAL)

# --- Helper function to load data safely ---
def load_data(file_path, df_name="DataFrame"):
    """
    Loads a CSV file into a pandas DataFrame.
    Handles file not found errors and general exceptions during loading.
    """
    if not os.path.exists(file_path):
        # logging.warning(f"File not found at {file_path} for {df_name}. Returning empty DataFrame.")
        return pd.DataFrame()
    try:
        df = pd.read_csv(file_path)
        # logging.info(f"Successfully loaded {df_name} from {file_path} with {len(df)} rows.")
        return df
    except Exception as e:
        # logging.error(f"Error loading {file_path} for {df_name}: {e}. Returning empty DataFrame.")
        return pd.DataFrame()

# --- Feature Engineering and Preprocessing Class ---
class FeatureEngineer:
    """
    Handles loading auxiliary data, creating new features, and imputing missing values
    for both training and prediction datasets.
    It prepares data suitable for RandomForest, which requires numerical input.
    """
    def __init__(self):
        self.trained_street_violation_pairs = None # To track unseen pairs in test
        self.feature_columns = [] # To store names of final features for the model
        
        # Label encoders for categorical features
        self.le_street = LabelEncoder()
        self.le_violation = LabelEncoder()
        self.le_borough = LabelEncoder()
        
        # Keep track of original categorical column names to process them
        self._original_categorical_cols = ['street_name', 'violation_type', 'borough']

        # Ablation parameters, initialized to default values
        self.imputation_strategy = 'zero' # 'zero' or 'median'
        self.exclude_borough = False      # Whether to exclude 'borough' as a feature
        self.numerical_imputation_values = {} # To store median values for consistent imputation

    def fit(self, df_train_raw, aux_data_dir="./input", imputation_strategy='zero', exclude_borough=False):
        """
        Fits the feature engineer on the raw training data.
        Performs feature creation, imputation, and fits LabelEncoders.
        Returns processed features (X) and target (y) for training.
        """
        # logging.info("Fitting FeatureEngineer...")
        self.imputation_strategy = imputation_strategy
        self.exclude_borough = exclude_borough

        # Store unique (street_name, violation_type) pairs from training for unseen pair tracking
        self.trained_street_violation_pairs = set(
            df_train_raw.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1)
        )
        
        # Process core data and add auxiliary features
        df_train_features = self._add_auxiliary_features(df_train_raw.copy(), aux_data_dir)
        
        # Rename core columns to be consistent
        df_train_features.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type',
            'violation_count': 'violation_count'
        }, inplace=True)
        
        # Handle target column
        target = 'violation_count'
        y_train = df_train_features[target]
        df_train_features.drop(columns=[target], inplace=True) # Drop target from features

        # Fit LabelEncoders for categorical features
        df_train_features['street_name_encoded'] = self.le_street.fit_transform(
            df_train_features['street_name'].fillna('UNKNOWN_STREET').astype(str)
        )
        df_train_features['violation_type_encoded'] = self.le_violation.fit_transform(
            df_train_features['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str)
        )
        # Borough might not always be present or fully filled, ensure it's handled
        if 'borough' in df_train_features.columns and not self.exclude_borough: # Only encode if not excluded
            df_train_features['borough_encoded'] = self.le_borough.fit_transform(
                df_train_features['borough'].fillna('UNKNOWN_BOROUGH').astype(str)
            )
        else:
            df_train_features['borough_encoded'] = -1 # Default for missing borough or if excluded
            # logging.warning("No 'borough' column found during feature engineering in train. Using -1 for encoded.")

        # Impute missing numerical values (after all joins and encodings)
        numerical_cols = df_train_features.select_dtypes(include=np.number).columns
        self.numerical_imputation_values = {} # Reset for current fit
        for col in numerical_cols:
            if self.imputation_strategy == 'zero':
                df_train_features[col].fillna(0, inplace=True) # Simple imputation with 0
            elif self.imputation_strategy == 'median':
                median_val = df_train_features[col].median()
                if pd.isna(median_val): # If all values are NaN, median is NaN, use 0
                    median_val = 0
                self.numerical_imputation_values[col] = median_val
                df_train_features[col].fillna(median_val, inplace=True)
        
        # Define the final feature columns for the model
        # Exclude original string columns, and any temporary columns
        self.feature_columns = [
            col for col in df_train_features.columns
            if col not in self._original_categorical_cols and col != 'actual_violation_count'
        ]
        
        # If borough is excluded, ensure its encoded version is not in feature_columns
        if self.exclude_borough and 'borough_encoded' in self.feature_columns:
            self.feature_columns.remove('borough_encoded')

        # logging.info(f"Identified {len(self.feature_columns)} features for RandomForest.")
        return df_train_features[self.feature_columns], y_train

    def transform(self, df_data_raw, aux_data_dir="./input"):
        """
        Transforms new raw data (e.g., test/evaluation data) using the fitted feature engineer.
        Applies feature creation and imputation based on training data.
        """
        # logging.info("Transforming data using fitted FeatureEngineer...")
        df_data_features = self._add_auxiliary_features(df_data_raw.copy(), aux_data_dir)
        
        # Store actual_violation_count if present for later evaluation
        if 'violation_count' in df_data_features.columns:
            df_data_features['actual_violation_count'] = df_data_features['violation_count']
            df_data_features.drop(columns=['violation_count'], inplace=True)

        # Rename core columns
        df_data_features.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type'
        }, inplace=True)

        # Apply LabelEncoders, handling unseen categories with -1
        df_data_features['street_name_encoded'] = df_data_features['street_name'].fillna('UNKNOWN_STREET').astype(str).map(
            lambda x: self.le_street.transform([x])[0] if x in self.le_street.classes_ else -1
        )
        df_data_features['violation_type_encoded'] = df_data_features['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str).map(
            lambda x: self.le_violation.transform([x])[0] if x in self.le_violation.classes_ else -1
        )
        
        if 'borough' in df_data_features.columns and not self.exclude_borough:
            df_data_features['borough_encoded'] = df_data_features['borough'].fillna('UNKNOWN_BOROUGH').astype(str).map(
                lambda x: self.le_borough.transform([x])[0] if x in self.le_borough.classes_ else -1
            )
        else:
            df_data_features['borough_encoded'] = -1 # Default for missing borough or if excluded
            # logging.warning("No 'borough' column found during feature engineering in test. Using -1 for encoded.")

        # Impute missing numerical values
        numerical_cols = df_data_features.select_dtypes(include=np.number).columns
        for col in numerical_cols:
            if self.imputation_strategy == 'zero':
                df_data_features[col].fillna(0, inplace=True) # Simple imputation with 0
            elif self.imputation_strategy == 'median':
                impute_val = self.numerical_imputation_values.get(col, 0) # Use 0 if median not computed for this column
                df_data_features[col].fillna(impute_val, inplace=True)
            
        # Ensure all feature columns from training are present and in order
        for col in self.feature_columns:
            if col not in df_data_features.columns:
                df_data_features[col] = 0 # Add missing features with a default value (e.g., 0)
                # logging.warning(f"Added missing feature '{col}' to test data with 0.")

        return df_data_features[self.feature_columns]

    def _add_auxiliary_features(self, df, aux_data_dir):
        """
        Loads and merges auxiliary data to enrich the main DataFrame with additional features.
        """
        # logging.info("Adding auxiliary features...")

        # --- Violation Codes Features ---
        violation_codes_df = load_data(os.path.join(aux_data_dir, 'violation_codes.csv'), 'Violation Codes')
        if not violation_codes_df.empty:
            violation_codes_df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
            violation_codes_df['fine_amount_avg'] = (
                violation_codes_df['Manhattan 96th St. & Below'].fillna(0) + 
                violation_codes_df['All Other Areas'].fillna(0)
            ) / 2
            violation_codes_df.drop(columns=['Violation Code', 'Manhattan 96th St. & Below', 'All Other Areas'], errors='ignore', inplace=True)
            df = pd.merge(df, violation_codes_df, on='violation_type', how='left')
            # logging.info(f"Merged violation codes. DF shape: {df.shape}")
        
        # --- Street Segments Features ---
        street_segments_df = load_data(os.path.join(aux_data_dir, 'nyc_street_segments.csv'), 'Street Segments')
        if not street_segments_df.empty:
            street_segments_agg = street_segments_df.groupby('Street Name').agg(
                street_segment_length_sum=('Segment Length', 'sum'),
                street_speed_limit_mean=('Speed Limit', 'mean'),
                street_num_lanes_mean=('Number of Lanes', 'mean'),
                borough_ss=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            street_segments_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, street_segments_agg, on='street_name', how='left')
            # logging.info(f"Merged street segments. DF shape: {df.shape}")
            
        # --- Parking Zones Features ---
        parking_zones_df = load_data(os.path.join(aux_data_dir, 'nyc_parking_zones.csv'), 'Parking Zones')
        if not parking_zones_df.empty:
            parking_zones_agg = parking_zones_df.groupby('Street Name').agg(
                num_parking_zones=('Parking Zone', 'count'),
                avg_max_duration_parking=('Max Duration', 'mean'),
                borough_pz=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            parking_zones_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, parking_zones_agg, on='street_name', how='left')

            # Consolidate borough information
            if 'borough_ss' in df.columns and 'borough_pz' in df.columns:
                df['borough'] = df['borough_ss'].fillna(df['borough_pz'])
            elif 'borough_ss' in df.columns:
                 df['borough'] = df['borough_ss']
            elif 'borough_pz' in df.columns:
                 df['borough'] = df['borough_pz']
            else: # If no borough from aux data, initialize
                df['borough'] = np.nan
            
            df.drop(columns=['borough_ss', 'borough_pz'], errors='ignore', inplace=True)
            # logging.info(f"Merged parking zones. DF shape: {df.shape}")

        # --- Traffic Counts Features ---
        traffic_counts_df = load_data(os.path.join(aux_data_dir, 'traffic_counts_nyc.csv'), 'Traffic Counts')
        if not traffic_counts_df.empty:
            traffic_counts_agg = traffic_counts_df.groupby('Street Name').agg(
                avg_vehicle_count=('Vehicle Count', 'mean'),
                max_vehicle_count=('Vehicle Count', 'max'),
                std_vehicle_count=('Vehicle Count', 'std')
            ).reset_index()
            traffic_counts_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, traffic_counts_agg, on='street_name', how='left')
            # logging.info(f"Merged traffic counts. DF shape: {df.shape}")

        # --- Census Tracts Features ---
        # Ensure 'borough' column exists for merging census data
        if 'borough' not in df.columns:
            df['borough'] = np.nan # Create it if not already present from other merges
        
        census_tracts_df = load_data(os.path.join(aux_data_dir, 'nyc_census_tracts.csv'), 'Census Tracts')
        if not census_tracts_df.empty:
            census_borough_agg = census_tracts_df.groupby('Borough').agg(
                total_population_borough=('Total Population', 'sum'),
                median_household_income_borough=('Median Household Income', 'mean'),
                poverty_rate_borough=('Poverty Rate', 'mean')
            ).reset_index()
            df = pd.merge(df, census_borough_agg, on='Borough', how='left')
            # logging.info(f"Merged census tracts. DF shape: {df.shape}")
        # else:
            # logging.warning("Census tracts data not available or empty.")

        # logging.info("Finished adding auxiliary features.")
        return df

def run_experiment(
    train_path: str,
    aux_data_dir: str,
    imputation_strategy: str = 'zero', # 'zero' or 'median'
    rf_n_estimators: int = 100,
    rf_min_samples_leaf: int = 5,
    exclude_borough_feature: bool = False
) -> float:
    """
    Runs a single experiment with specified parameters and returns validation RMSE.
    """
    train_2022_raw = load_data(train_path, '2022 Training Data')
    if train_2022_raw.empty:
        return np.nan

    fe = FeatureEngineer()

    X_full_2022, y_full_2022 = fe.fit(train_2022_raw, aux_data_dir, 
                                     imputation_strategy=imputation_strategy, 
                                     exclude_borough=exclude_borough_feature)
    
    X_train, X_val, y_train, y_val = train_test_split(
        X_full_2022, y_full_2022, test_size=0.2, random_state=42
    )
    
    rf_model = RandomForestRegressor(n_estimators=rf_n_estimators, random_state=42, n_jobs=-1, min_samples_leaf=rf_min_samples_leaf)
    rf_model.fit(X_train, y_train)

    val_predictions = rf_model.predict(X_val)
    val_predictions[val_predictions < 0] = 0 # Ensure predictions are non-negative
    val_predictions = np.round(val_predictions).astype(int) # Round to nearest integer

    val_rmse = np.sqrt(mean_squared_error(y_val, val_predictions))
    return val_rmse

if __name__ == '__main__':
    # Define paths for data
    train_path = "./input/violations_per_street_2022.csv"
    aux_data_dir = "./input"

    results = {}

    # --- Baseline Experiment ---
    results['Baseline (Current setup)'] = run_experiment(
        train_path=train_path,
        aux_data_dir=aux_data_dir,
        imputation_strategy='zero',
        rf_n_estimators=100,
        rf_min_samples_leaf=5,
        exclude_borough_feature=False
    )

    # --- Ablation 1: Numerical Imputation Method (Median instead of Zero) ---
    results['Ablation 1: Imputation with Median'] = run_experiment(
        train_path=train_path,
        aux_data_dir=aux_data_dir,
        imputation_strategy='median',
        rf_n_estimators=100,
        rf_min_samples_leaf=5,
        exclude_borough_feature=False
    )

    # --- Ablation 2: RandomForest Hyperparameters (More complex model) ---
    # Increasing estimators and allowing deeper trees (min_samples_leaf=1)
    results['Ablation 2: RF Hyperparameters (n_estimators=200, min_samples_leaf=1)'] = run_experiment(
        train_path=train_path,
        aux_data_dir=aux_data_dir,
        imputation_strategy='zero',
        rf_n_estimators=200,
        rf_min_samples_leaf=1,
        exclude_borough_feature=False
    )
    
    # --- Ablation 3: Exclude 'borough' Feature ---
    # The 'borough' feature is consolidated from multiple auxiliary sources and encoded.
    # We check its individual contribution by excluding it.
    results['Ablation 3: Exclude Borough Feature'] = run_experiment(
        train_path=train_path,
        aux_data_dir=aux_data_dir,
        imputation_strategy='zero',
        rf_n_estimators=100,
        rf_min_samples_leaf=5,
        exclude_borough_feature=True
    )

    print("Ablation Study Results (Validation RMSE):")
    for name, rmse in results.items():
        print(f"- {name}: {rmse:.4f}")

    print("\nAblation Study Conclusion:")
    baseline_rmse = results['Baseline (Current setup)']
    if pd.isna(baseline_rmse):
        print("Baseline experiment failed, cannot determine contribution.")
    else:
        performance_changes = {
            name: rmse - baseline_rmse for name, rmse in results.items() if name != 'Baseline (Current setup)' and not pd.isna(rmse)
        }

        if not performance_changes:
            print("No valid ablation results to compare against baseline.")
        else:
            # Find the ablation that caused the largest increase in RMSE (most detrimental change).
            # This indicates the original component contributed most positively to performance.
            most_contributing_part = None
            max_degradation = 0

            for name, change in performance_changes.items():
                if change > max_degradation:
                    max_degradation = change
                    most_contributing_part = name

            if most_contributing_part:
                print(f"The part of the code whose original configuration contributed most significantly to the overall performance, as evidenced by the largest performance degradation when modified, is related to '{most_contributing_part}' (RMSE increased by {max_degradation:.4f}).")
            else:
                print("No ablation significantly degraded performance. All ablations either improved performance or kept it similar.")

            # Optionally, mention if any ablation improved performance
            min_improvement = 0
            most_improving_part = None
            for name, change in performance_changes.items():
                if change < min_improvement:
                    min_improvement = change
                    most_improving_part = name
            
            if most_improving_part:
                print(f"Conversely, the setup '{most_improving_part}' showed the largest performance improvement, decreasing RMSE by {-min_improvement:.4f}.")
                print("This suggests that the original configuration of this part might be suboptimal and further optimization could be beneficial.")

# Re-enable logging after the ablation study
logging.disable(logging.NOTSET)
