
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import argparse
import os
import logging

# Set up logging for better visibility during execution
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Helper function to load data safely ---
def load_data(file_path, df_name="DataFrame"):
    """
    Loads a CSV file into a pandas DataFrame.
    Handles file not found errors and general exceptions during loading.
    """
    if not os.path.exists(file_path):
        logging.warning(f"File not found at {file_path} for {df_name}. Returning empty DataFrame.")
        return pd.DataFrame()
    try:
        df = pd.read_csv(file_path)
        logging.info(f"Successfully loaded {df_name} from {file_path} with {len(df)} rows.")
        return df
    except Exception as e:
        logging.error(f"Error loading {file_path} for {df_name}: {e}. Returning empty DataFrame.")
        return pd.DataFrame()

# --- Feature Engineering and Preprocessing Class ---
class FeatureEngineer:
    """
    Handles loading auxiliary data, creating new features, encoding categorical variables,
    and imputing missing values for both training and prediction datasets.
    """
    def __init__(self):
        self.le_street = LabelEncoder()
        self.le_violation = LabelEncoder()
        self.le_borough = LabelEncoder() # For encoding the derived 'borough' feature
        self.trained_street_violation_pairs = None # To track unseen pairs in test
        self.numerical_features = [] # To store names of numerical features
        self.categorical_features_lgbm = [] # To store names of encoded categorical features for LGBM

    def fit(self, df_train_raw, aux_data_dir="./input"):
        """
        Fits the feature engineer on the raw training data.
        Performs feature creation, imputation, and fits LabelEncoders.
        Returns processed features (X) and target (y) for training.
        """
        logging.info("Fitting FeatureEngineer...")
        # Store unique (street_name, violation_type) pairs from training for unseen pair tracking
        self.trained_street_violation_pairs = set(
            df_train_raw.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1)
        )
        
        # Process core data (rename, handle target if any)
        df_train_processed = self._process_core_data(df_train_raw.copy(), is_train=True)
        
        # Add auxiliary features and handle their initial imputation
        df_train_features = self._add_auxiliary_features(df_train_processed.copy(), aux_data_dir)
        
        # Fit LabelEncoders after all merges and potential 'borough' column creation
        self._fit_encoders(df_train_features)
        
        # Apply encoding to the training data itself
        df_train_features = self._apply_encoders(df_train_features)

        # Define feature sets after all transformations
        # Exclude original string columns, target, and any temporary columns
        all_feature_cols = [
            col for col in df_train_features.columns 
            if col not in ['street_name', 'violation_type', 'violation_count', 'borough', 'actual_violation_count']
        ]
        
        # Separate numerical and categorical features for LGBM, also useful for general tracking
        self.numerical_features = [
            col for col in all_feature_cols 
            if df_train_features[col].dtype in ['int64', 'float64'] 
            and col not in ['street_name_encoded', 'violation_type_encoded', 'borough_encoded']
        ]
        self.categorical_features_lgbm = ['street_name_encoded', 'violation_type_encoded', 'borough_encoded']
        # Filter for features that actually exist after processing
        self.categorical_features_lgbm = [f for f in self.categorical_features_lgbm if f in df_train_features.columns]
        
        # Final set of features to be used by the models
        final_model_features = self.numerical_features + self.categorical_features_lgbm
        
        logging.info(f"Identified {len(self.numerical_features)} numerical features and {len(self.categorical_features_lgbm)} categorical features for models.")
        return df_train_features[final_model_features], df_train_features['violation_count']

    def transform(self, df_data_raw, aux_data_dir="./input"):
        """
        Transforms new raw data (e.g., test/evaluation data) using the fitted feature engineer.
        Applies feature creation and imputation based on training data.
        """
        logging.info("Transforming data using fitted FeatureEngineer...")
        
        df_data_processed = self._process_core_data(df_data_raw.copy(), is_train=False)
        df_data_features = self._add_auxiliary_features(df_data_processed.copy(), aux_data_dir)
        
        # Apply encoding using the already fitted encoders
        df_data_features = self._apply_encoders(df_data_features)
        
        # Ensure that the test set has all the features expected by the model.
        # Fill missing features with a default (e.g., -1 for encoded categoricals, 0 for numerical).
        all_expected_features = self.numerical_features + self.categorical_features_lgbm
        for feature in all_expected_features:
            if feature not in df_data_features.columns:
                logging.warning(f"Feature '{feature}' not found in transformed data. Adding with default fill value.")
                if feature in self.categorical_features_lgbm:
                    df_data_features[feature] = -1 # Unseen category encoding
                else:
                    df_data_features[feature] = 0.0 # Default for numerical
        
        return df_data_features[all_expected_features]

    def _process_core_data(self, df, is_train=False):
        """Standardizes column names and handles target column for test data."""
        df.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type',
            'violation_count': 'violation_count'
        }, inplace=True)

        if not is_train and 'violation_count' in df.columns:
            # If 'violation_count' is present in test data, it's for evaluation; store it and drop from features
            df['actual_violation_count'] = df['violation_count']
            df.drop(columns=['violation_count'], inplace=True)
            
        # Fill any initial NaNs in key columns before joins/encoding to prevent errors
        df['street_name'] = df['street_name'].fillna('UNKNOWN_STREET').astype(str)
        df['violation_type'] = df['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str)
        return df

    def _fit_encoders(self, df_processed):
        """Fits LabelEncoders on unique values from the processed training data."""
        logging.info("Fitting LabelEncoders...")
        self.le_street.fit(df_processed['street_name'].unique())
        self.le_violation.fit(df_processed['violation_type'].unique())
        
        # Fit borough encoder only if the 'borough' column was successfully created and has non-null values
        if 'borough' in df_processed.columns and not df_processed['borough'].isnull().all():
            self.le_borough.fit(df_processed['borough'].fillna('UNKNOWN_BOROUGH').unique())
        else:
             logging.warning("No valid 'borough' column found to fit LabelEncoder for borough.")

    def _apply_encoders(self, df):
        """Applies fitted LabelEncoders to categorical columns, mapping unseen categories to -1."""
        logging.info("Applying LabelEncoders...")
        # Map street_name
        df['street_name_encoded'] = df['street_name'].map(
            lambda x: self.le_street.transform([x])[0] if x in self.le_street.classes_ else -1
        ).fillna(-1).astype(int)

        # Map violation_type
        df['violation_type_encoded'] = df['violation_type'].map(
            lambda x: self.le_violation.transform([x])[0] if x in self.le_violation.classes_ else -1
        ).fillna(-1).astype(int)

        # Map borough if the encoder was fitted
        if 'borough' in df.columns and len(self.le_borough.classes_) > 0:
            df['borough_encoded'] = df['borough'].map(
                lambda x: self.le_borough.transform([x])[0] if x in self.le_borough.classes_ else -1
            ).fillna(-1).astype(int)
        else:
            # If borough wasn't derived or encoder not fitted, create a dummy column
            df['borough_encoded'] = -1
            
        return df

    def _add_auxiliary_features(self, df, aux_data_dir):
        """
        Loads and merges auxiliary data to enrich the main DataFrame with additional features.
        Performs aggregations and imputation for newly added numerical columns.
        """
        logging.info("Adding auxiliary features...")

        # --- Violation Codes Features ---
        violation_codes_df = load_data(os.path.join(aux_data_dir, 'violation_codes.csv'), 'Violation Codes')
        if not violation_codes_df.empty:
            violation_codes_df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
            # Create an average fine amount feature
            violation_codes_df['fine_amount_avg'] = (
                violation_codes_df['Manhattan 96th St. & Below'].fillna(0) + 
                violation_codes_df['All Other Areas'].fillna(0)
            ) / 2
            violation_codes_df.drop(columns=['Violation Code', 'Manhattan 96th St. & Below', 'All Other Areas'], errors='ignore', inplace=True)
            df = pd.merge(df, violation_codes_df, on='violation_type', how='left')
            logging.info(f"Merged violation codes. DF shape: {df.shape}")
        
        # --- Street Segments Features ---
        street_segments_df = load_data(os.path.join(aux_data_dir, 'nyc_street_segments.csv'), 'Street Segments')
        if not street_segments_df.empty:
            street_segments_agg = street_segments_df.groupby('Street Name').agg(
                street_segment_length_sum=('Segment Length', 'sum'),
                street_speed_limit_mean=('Speed Limit', 'mean'),
                street_num_lanes_mean=('Number of Lanes', 'mean'),
                borough_ss=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan) # Most frequent borough for the street
            ).reset_index()
            street_segments_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, street_segments_agg, on='street_name', how='left')
            logging.info(f"Merged street segments. DF shape: {df.shape}")
            
        # --- Parking Zones Features ---
        parking_zones_df = load_data(os.path.join(aux_data_dir, 'nyc_parking_zones.csv'), 'Parking Zones')
        if not parking_zones_df.empty:
            parking_zones_agg = parking_zones_df.groupby('Street Name').agg(
                num_parking_zones=('Parking Zone', 'count'),
                avg_max_duration_parking=('Max Duration', 'mean'),
                borough_pz=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            parking_zones_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, parking_zones_agg, on='street_name', how='left')
            # Consolidate borough information from multiple sources
            # Priority: borough_ss (from street segments) then borough_pz (from parking zones)
            if 'borough_ss' in df.columns and 'borough_pz' in df.columns:
                df['borough'] = df['borough_ss'].fillna(df['borough_pz'])
                df.drop(columns=['borough_ss', 'borough_pz'], errors='ignore', inplace=True)
            elif 'borough_ss' in df.columns: # Only street segments has borough
                 df.rename(columns={'borough_ss': 'borough'}, inplace=True)
            elif 'borough_pz' in df.columns: # Only parking zones has borough
                 df.rename(columns={'borough_pz': 'borough'}, inplace=True)
            else: # If no borough from aux data, initialize
                df['borough'] = np.nan
            logging.info(f"Merged parking zones. DF shape: {df.shape}")

        # --- Traffic Counts Features ---
        traffic_counts_df = load_data(os.path.join(aux_data_dir, 'traffic_counts_nyc.csv'), 'Traffic Counts')
        if not traffic_counts_df.empty:
            traffic_counts_agg = traffic_counts_df.groupby('Street Name').agg(
                avg_vehicle_count=('Vehicle Count', 'mean'),
                max_vehicle_count=('Vehicle Count', 'max'),
                std_vehicle_count=('Vehicle Count', 'std')
            ).reset_index()
            traffic_counts_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, traffic_counts_agg, on='street_name', how='left')
            logging.info(f"Merged traffic counts. DF shape: {df.shape}")

        # --- Census Tracts Features (Requires consolidated Borough info) ---
        if 'borough' in df.columns:
            # Ensure 'borough' is string type before filling NaNs for consistency with LabelEncoder fit
            df['borough'] = df['borough'].fillna('UNKNOWN_BOROUGH').astype(str)
            census_tracts_df = load_data(os.path.join(aux_data_dir, 'nyc_census_tracts.csv'), 'Census Tracts')
            if not census_tracts_df.empty:
                # Aggregate census data to borough level
                census_borough_agg = census_tracts_df.groupby('Borough').agg(
                    total_population_borough=('Total Population', 'sum'),
                    median_household_income_borough=('Median Household Income', 'mean'),
                    poverty_rate_borough=('Poverty Rate', 'mean')
                ).reset_index()
                # Merge on the consolidated 'borough' column
                df = pd.merge(df, census_borough_agg, on='Borough', how='left')
                logging.info(f"Merged census tracts. DF shape: {df.shape}")
        else:
            logging.warning("Borough information not sufficiently derived for merging census tracts. Skipping this merge.")
        
        # Impute missing numerical values after all joins.
        # Fill with 0 as a simple strategy for initial solution.
        numerical_cols_to_impute = df.select_dtypes(include=np.number).columns.tolist()
        # Exclude target columns if they are still present in df (shouldn't be after _process_core_data for test)
        for col in ['violation_count', 'actual_violation_count']: 
            if col in numerical_cols_to_impute:
                numerical_cols_to_impute.remove(col)
            
        for col in numerical_cols_to_impute:
            if df[col].isnull().any():
                df[col].fillna(0, inplace=True) # Simple imputation with 0 for missing numbers
        
        logging.info("Finished adding auxiliary features and imputing NaNs.")
        return df

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations for 2023.")
    parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Optional: Path to the 2023 test/evaluation data CSV. If provided, predictions will be generated.")
    parser.add_argument("--aux-data-dir", type=str, default="./input",
                        help="Directory containing auxiliary data CSV files.")
    
    args = parser.parse_args()

    logging.info(f"Starting prediction pipeline with train_path: {args.train_path}")

    # Load 2022 training data
    train_2022_raw = load_data(args.train_path, '2022 Training Data')
    if train_2022_raw.empty:
        logging.error("Training data is empty or could not be loaded. Returning.")
        return

    # Initialize Feature Engineer
    fe = FeatureEngineer()

    # Fit feature engineer on the full 2022 data and get processed features and target
    X_full_2022, y_full_2022 = fe.fit(train_2022_raw, args.aux_data_dir)
    
    # Split 2022 data into training and validation sets for development evaluation
    X_train, X_val, y_train, y_val = train_test_split(
        X_full_2022, y_full_2022, test_size=0.2, random_state=42
    )
    
    logging.info(f"Training data shape: {X_train.shape}, Validation data shape: {X_val.shape}")

    # --- Model Training: RandomForestRegressor ---
    logging.info("Training RandomForestRegressor model...")
    rf_model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1, min_samples_leaf=5)
    rf_model.fit(X_train, y_train)
    logging.info("RandomForestRegressor model training complete.")

    # --- Model Training: LightGBM ---
    logging.info("Training LightGBM model...")
    lgb_model = lgb.LGBMRegressor(
        objective='poisson',           # Objective suitable for count data
        metric='rmse',                 # Evaluation metric
        random_state=42,               # For reproducibility
        n_estimators=1000,             # Number of boosting rounds
        learning_rate=0.05,            # Step size shrinkage
        num_leaves=31,                 # Max number of leaves in one tree
        max_depth=-1,                  # No limit on tree depth
        n_jobs=-1                      # Use all available CPU cores
    )
    
    # Identify categorical features by their names for LGBM
    categorical_features_for_lgbm = fe.categorical_features_lgbm if fe.categorical_features_lgbm else None
    
    lgb_model.fit(
        X_train, y_train, 
        categorical_feature=categorical_features_for_lgbm, # Inform LGBM about categorical features
        eval_set=[(X_val, y_val)],
        eval_metric='rmse',
        callbacks=[lgb.early_stopping(100, verbose=False)] # Stop if validation RMSE doesn't improve for 100 rounds
    )
    logging.info("LightGBM model training complete.")

    # --- Validation Prediction and Evaluation ---
    # RandomForest predictions
    val_predictions_rf = rf_model.predict(X_val)
    val_predictions_rf[val_predictions_rf < 0] = 0 # Ensure predictions are non-negative

    # LightGBM predictions
    val_predictions_lgbm = lgb_model.predict(X_val)
    val_predictions_lgbm[val_predictions_lgbm < 0] = 0 # Ensure predictions are non-negative

    # Ensemble predictions (simple average)
    val_predictions_ensemble = (val_predictions_rf + val_predictions_lgbm) / 2
    val_predictions_ensemble = np.round(val_predictions_ensemble).astype(int) # Round to nearest integer

    val_rmse = np.sqrt(mean_squared_error(y_val, val_predictions_ensemble))
    print(f"Final Validation Performance: {val_rmse:.4f}")

    # --- 2023 Prediction if test-path is provided ---
    if args.test_path:
        logging.info(f"Processing test data from {args.test_path} for 2023 predictions.")
        test_2023_raw = load_data(args.test_path, '2023 Test Data')
        if test_2023_raw.empty:
            logging.warning("Test data is empty or not found. Skipping 2023 predictions.")
            return

        # Keep original key columns for submission output
        submission_keys_raw = test_2023_raw[['Street Name', 'Violation Description']].copy()

        # Store target for evaluation if present before feature engineering
        y_test_actual = None
        if 'violation_count' in test_2023_raw.columns:
            y_test_actual = test_2023_raw['violation_count'].copy()
        
        # Transform test data using the *fitted* feature engineer
        X_test = fe.transform(test_2023_raw.copy(), args.aux_data_dir)

        # Report unseen key pairs in the test set
        test_street_violation_pairs = set(
            submission_keys_raw.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1)
        )
        unseen_pairs_count = len(test_street_violation_pairs - fe.trained_street_violation_pairs)
        logging.info(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_pairs_count}")

        # Make predictions on the transformed test data with both models
        predictions_2023_rf = rf_model.predict(X_test)
        predictions_2023_rf[predictions_2023_rf < 0] = 0 # Ensure non-negative counts

        predictions_2023_lgbm = lgb_model.predict(X_test)
        predictions_2023_lgbm[predictions_2023_lgbm < 0] = 0 # Ensure non-negative counts

        # Ensemble test predictions
        predictions_2023_ensemble = (predictions_2023_rf + predictions_2023_lgbm) / 2
        predictions_2023_ensemble = np.round(predictions_2023_ensemble).astype(int) # Round to integer counts

        # Create submission file
        submission_df = submission_keys_raw
        submission_df.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type'
        }, inplace=True)
        submission_df['predicted_count'] = predictions_2023_ensemble
        submission_df.to_csv('submission.csv', index=False)
        logging.info("Generated submission.csv with 2023 predictions.")

        # Evaluate if actual counts are present in the provided test/eval file
        if y_test_actual is not None:
            test_rmse = np.sqrt(mean_squared_error(y_test_actual, predictions_2023_ensemble))
            print(f"RMSE on provided test/eval data: {test_rmse:.4f}")
        else:
            logging.info("No 'violation_count' column found in test data for evaluation.")
            
    else:
        logging.info("No test-path provided. Skipping 2023 predictions and submission file generation.")

if __name__ == '__main__':
    main()
