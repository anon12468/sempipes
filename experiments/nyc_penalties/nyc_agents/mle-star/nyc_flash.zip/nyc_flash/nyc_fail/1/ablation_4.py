

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import argparse
import os
import logging
import sys

# Set up logging for better visibility during execution
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s', stream=sys.stdout)

# --- Helper function to load data safely ---
def load_data(file_path, df_name="DataFrame"):
    """
    Loads a CSV file into a pandas DataFrame.
    Handles file not found errors and general exceptions during loading.
    """
    if not os.path.exists(file_path):
        logging.warning(f"File not found at {file_path} for {df_name}. Returning empty DataFrame.")
        return pd.DataFrame()
    try:
        df = pd.read_csv(file_path)
        logging.info(f"Successfully loaded {df_name} from {file_path} with {len(df)} rows.")
        return df
    except Exception as e:
        logging.error(f"Error loading {file_path} for {df_name}: {e}. Returning empty DataFrame.")
        return pd.DataFrame()

# --- Feature Engineering and Preprocessing Class ---
class FeatureEngineer:
    """
    Handles loading auxiliary data, creating new features, and imputing missing values
    for both training and prediction datasets.
    It prepares data suitable for RandomForest, which requires numerical input.
    """
    def __init__(self, use_target_encoding=False, include_traffic_counts=True, include_census_tracts=True):
        self.trained_street_violation_pairs = None # To track unseen pairs in test
        self.feature_columns = [] # To store names of final features for the model
        
        self.use_target_encoding = use_target_encoding
        self.include_traffic_counts = include_traffic_counts
        self.include_census_tracts = include_census_tracts

        # Label encoders or Target encoders for categorical features
        if self.use_target_encoding:
            self.target_encoder_street = None
            self.target_encoder_violation = None
            self.target_encoder_borough = None
        else:
            self.le_street = LabelEncoder()
            self.le_violation = LabelEncoder()
            self.le_borough = LabelEncoder()
        
        # Keep track of original categorical column names to process them
        self._original_categorical_cols = ['street_name', 'violation_type', 'borough']

    def fit(self, df_train_raw, aux_data_dir="./input"):
        """
        Fits the feature engineer on the raw training data.
        Performs feature creation, imputation, and fits LabelEncoders/TargetEncoders.
        Returns processed features (X) and target (y) for training.
        """
        logging.info("Fitting FeatureEngineer...")
        # Store unique (street_name, violation_type) pairs from training for unseen pair tracking
        self.trained_street_violation_pairs = set(
            df_train_raw.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1)
        )
        
        # Process core data and add auxiliary features
        df_train_features = self._add_auxiliary_features(df_train_raw.copy(), aux_data_dir)
        
        # Rename core columns to be consistent
        df_train_features.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type',
            'violation_count': 'violation_count'
        }, inplace=True)
        
        # Handle target column
        target = 'violation_count'
        y_train = df_train_features[target]
        df_train_features.drop(columns=[target], inplace=True) # Drop target from features

        if self.use_target_encoding:
            self._fit_target_encoders(df_train_features, y_train)
        else:
            self._fit_label_encoders(df_train_features)
        
        # Impute missing numerical values (after all joins and encodings)
        numerical_cols = df_train_features.select_dtypes(include=np.number).columns
        for col in numerical_cols:
            df_train_features[col].fillna(0, inplace=True) # Simple imputation with 0
        
        # Define the final feature columns for the model
        # Exclude original string columns, and any temporary columns
        self.feature_columns = [
            col for col in df_train_features.columns
            if col not in self._original_categorical_cols and col != 'actual_violation_count'
        ]
        
        logging.info(f"Identified {len(self.feature_columns)} features for RandomForest.")
        return df_train_features[self.feature_columns], y_train

    def transform(self, df_data_raw, aux_data_dir="./input"):
        """
        Transforms new raw data (e.g., test/evaluation data) using the fitted feature engineer.
        Applies feature creation and imputation based on training data.
        """
        logging.info("Transforming data using fitted FeatureEngineer...")
        df_data_features = self._add_auxiliary_features(df_data_raw.copy(), aux_data_dir)
        
        # Store actual_violation_count if present for later evaluation
        if 'violation_count' in df_data_features.columns:
            df_data_features['actual_violation_count'] = df_data_features['violation_count']
            df_data_features.drop(columns=['violation_count'], inplace=True)

        # Rename core columns
        df_data_features.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type'
        }, inplace=True)

        if self.use_target_encoding:
            self._transform_target_encoders(df_data_features)
        else:
            self._transform_label_encoders(df_data_features)

        # Impute missing numerical values
        numerical_cols = df_data_features.select_dtypes(include=np.number).columns
        for col in numerical_cols:
            df_data_features[col].fillna(0, inplace=True) # Simple imputation with 0
            
        # Ensure all feature columns from training are present and in order
        for col in self.feature_columns:
            if col not in df_data_features.columns:
                df_data_features[col] = 0 # Add missing features with a default value (e.g., 0)
                logging.warning(f"Added missing feature '{col}' to test data with 0.")

        return df_data_features[self.feature_columns]

    def _fit_label_encoders(self, df):
        df['street_name_encoded'] = self.le_street.fit_transform(
            df['street_name'].fillna('UNKNOWN_STREET').astype(str)
        )
        df['violation_type_encoded'] = self.le_violation.fit_transform(
            df['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str)
        )
        if 'borough' in df.columns:
            df['borough_encoded'] = self.le_borough.fit_transform(
                df['borough'].fillna('UNKNOWN_BOROUGH').astype(str)
            )
        else:
            df['borough_encoded'] = -1 # Default for missing borough
            logging.warning("No 'borough' column found during feature engineering in train. Using -1 for encoded.")

    def _transform_label_encoders(self, df):
        df['street_name_encoded'] = df['street_name'].fillna('UNKNOWN_STREET').astype(str).map(
            lambda x: self.le_street.transform([x])[0] if x in self.le_street.classes_ else -1
        )
        df['violation_type_encoded'] = df['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str).map(
            lambda x: self.le_violation.transform([x])[0] if x in self.le_violation.classes_ else -1
        )
        
        if 'borough' in df.columns:
            df['borough_encoded'] = df['borough'].fillna('UNKNOWN_BOROUGH').astype(str).map(
                lambda x: self.le_borough.transform([x])[0] if x in self.le_borough.classes_ else -1
            )
        else:
            df['borough_encoded'] = -1 # Default for missing borough
            logging.warning("No 'borough' column found during feature engineering in test. Using -1 for encoded.")

    def _fit_target_encoders(self, df_train_features, y_train):
        # Define a common smoothing factor for all target encoders
        smoothing_factor = 100 # This value can be tuned based on data characteristics

        # Calculate the global target mean once, assuming 'y_train' is the target series
        global_mean_target = y_train.mean()

        # Smoothed Target Encoding for 'street_name'
        street_name_processed = df_train_features['street_name'].fillna('UNKNOWN_STREET').astype(str)
        
        # Calculate counts and means of the target for each street name category
        temp_df_street = street_name_processed.to_frame(name='street_name_temp').assign(target=y_train)
        agg_street = temp_df_street.groupby('street_name_temp')['target'].agg(['count', 'mean'])
        
        counts_street = agg_street['count']
        means_street = agg_street['mean']
        
        # Apply smoothing to the category means
        smoothed_means_street = (counts_street * means_street + smoothing_factor * global_mean_target) / (counts_street + smoothing_factor)
        
        # Store the mapping and global mean for later transformation (e.g., test set)
        self.target_encoder_street = {'mapping': smoothed_means_street.to_dict(), 'global_mean': global_mean_target}
        
        # Apply the encoding to the training data. Use global mean for unseen categories during transformation.
        df_train_features['street_name_encoded'] = street_name_processed.map(self.target_encoder_street['mapping']).fillna(self.target_encoder_street['global_mean'])

        # Smoothed Target Encoding for 'violation_type'
        violation_type_processed = df_train_features['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str)
        
        # Calculate counts and means of the target for each violation type category
        temp_df_violation = violation_type_processed.to_frame(name='violation_type_temp').assign(target=y_train)
        agg_violation = temp_df_violation.groupby('violation_type_temp')['target'].agg(['count', 'mean'])
        
        counts_violation = agg_violation['count']
        means_violation = agg_violation['mean']
        
        # Apply smoothing
        smoothed_means_violation = (counts_violation * means_violation + smoothing_factor * global_mean_target) / (counts_violation + smoothing_factor)
        
        # Store the mapping and global mean
        self.target_encoder_violation = {'mapping': smoothed_means_violation.to_dict(), 'global_mean': global_mean_target}
        
        # Apply the encoding
        df_train_features['violation_type_encoded'] = violation_type_processed.map(self.target_encoder_violation['mapping']).fillna(self.target_encoder_violation['global_mean'])

        # Smoothed Target Encoding for 'borough'
        if 'borough' in df_train_features.columns:
            borough_processed = df_train_features['borough'].fillna('UNKNOWN_BOROUGH').astype(str)
            
            # Calculate counts and means of the target for each borough category
            temp_df_borough = borough_processed.to_frame(name='borough_temp').assign(target=y_train)
            agg_borough = temp_df_borough.groupby('borough_temp')['target'].agg(['count', 'mean'])
            
            counts_borough = agg_borough['count']
            means_borough = agg_borough['mean']
            
            # Apply smoothing
            smoothed_means_borough = (counts_borough * means_borough + smoothing_factor * global_mean_target) / (counts_borough + smoothing_factor)
            
            # Store the mapping and global mean
            self.target_encoder_borough = {'mapping': smoothed_means_borough.to_dict(), 'global_mean': global_mean_target}
            
            # Apply the encoding
            df_train_features['borough_encoded'] = borough_processed.map(self.target_encoder_borough['mapping']).fillna(self.target_encoder_borough['global_mean'])
        else:
            # If 'borough' column is missing, encode with the global target mean
            df_train_features['borough_encoded'] = global_mean_target 
            # Store the global mean in the encoder for consistency during transformation
            self.target_encoder_borough = {'mapping': {}, 'global_mean': global_mean_target} 
            logging.warning("No 'borough' column found during feature engineering in train. Using global target mean for encoded.")

    def _transform_target_encoders(self, df_data_features):
        # Apply the encoding to the test data. Use global mean for unseen categories.
        # Ensure 'street_name', 'violation_type', 'borough' are present for mapping
        df_data_features['street_name_encoded'] = df_data_features['street_name'].fillna('UNKNOWN_STREET').astype(str).map(
            self.target_encoder_street['mapping']
        ).fillna(self.target_encoder_street['global_mean'])

        df_data_features['violation_type_encoded'] = df_data_features['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str).map(
            self.target_encoder_violation['mapping']
        ).fillna(self.target_encoder_violation['global_mean'])
        
        if 'borough' in df_data_features.columns:
            df_data_features['borough_encoded'] = df_data_features['borough'].fillna('UNKNOWN_BOROUGH').astype(str).map(
                self.target_encoder_borough['mapping']
            ).fillna(self.target_encoder_borough['global_mean'])
        else:
            df_data_features['borough_encoded'] = self.target_encoder_borough['global_mean']
            logging.warning("No 'borough' column found during feature engineering in test. Using global target mean for encoded.")

    def _add_auxiliary_features(self, df, aux_data_dir):
        """
        Loads and merges auxiliary data to enrich the main DataFrame with additional features.
        """
        logging.info("Adding auxiliary features...")

        # --- Violation Codes Features ---
        violation_codes_df = load_data(os.path.join(aux_data_dir, 'violation_codes.csv'), 'Violation Codes')
        if not violation_codes_df.empty:
            violation_codes_df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
            violation_codes_df['fine_amount_avg'] = (
                violation_codes_df['Manhattan 96th St. & Below'].fillna(0) + 
                violation_codes_df['All Other Areas'].fillna(0)
            ) / 2
            violation_codes_df.drop(columns=['Violation Code', 'Manhattan 96th St. & Below', 'All Other Areas'], errors='ignore', inplace=True)
            df = pd.merge(df, violation_codes_df, on='violation_type', how='left')
            logging.info(f"Merged violation codes. DF shape: {df.shape}")
        
        # --- Street Segments Features ---
        street_segments_df = load_data(os.path.join(aux_data_dir, 'nyc_street_segments.csv'), 'Street Segments')
        if not street_segments_df.empty:
            street_segments_agg = street_segments_df.groupby('Street Name').agg(
                street_segment_length_sum=('Segment Length', 'sum'),
                street_speed_limit_mean=('Speed Limit', 'mean'),
                street_num_lanes_mean=('Number of Lanes', 'mean'),
                borough_ss=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            street_segments_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, street_segments_agg, on='street_name', how='left')
            logging.info(f"Merged street segments. DF shape: {df.shape}")
            
        # --- Parking Zones Features ---
        parking_zones_df = load_data(os.path.join(aux_data_dir, 'nyc_parking_zones.csv'), 'Parking Zones')
        if not parking_zones_df.empty:
            parking_zones_agg = parking_zones_df.groupby('Street Name').agg(
                num_parking_zones=('Parking Zone', 'count'),
                avg_max_duration_parking=('Max Duration', 'mean'),
                borough_pz=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            parking_zones_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, parking_zones_agg, on='street_name', how='left')

            # Consolidate borough information
            if 'borough_ss' in df.columns and 'borough_pz' in df.columns:
                df['borough'] = df['borough_ss'].fillna(df['borough_pz'])
            elif 'borough_ss' in df.columns:
                 df['borough'] = df['borough_ss']
            elif 'borough_pz' in df.columns:
                 df['borough'] = df['borough_pz']
            else: # If no borough from aux data, initialize
                df['borough'] = np.nan
            
            df.drop(columns=['borough_ss', 'borough_pz'], errors='ignore', inplace=True)
            logging.info(f"Merged parking zones. DF shape: {df.shape}")

        # --- Traffic Counts Features ---
        if self.include_traffic_counts:
            traffic_counts_df = load_data(os.path.join(aux_data_dir, 'traffic_counts_nyc.csv'), 'Traffic Counts')
            if not traffic_counts_df.empty:
                traffic_counts_agg = traffic_counts_df.groupby('Street Name').agg(
                    avg_vehicle_count=('Vehicle Count', 'mean'),
                    max_vehicle_count=('Vehicle Count', 'max'),
                    std_vehicle_count=('Vehicle Count', 'std')
                ).reset_index()
                traffic_counts_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
                df = pd.merge(df, traffic_counts_agg, on='street_name', how='left')
                logging.info(f"Merged traffic counts. DF shape: {df.shape}")
            else:
                logging.warning("Traffic counts data not available or empty.")
        else:
            logging.info("Traffic counts features are excluded.")

        # --- Census Tracts Features ---
        if self.include_census_tracts:
            # Ensure 'borough' column exists for merging census data
            if 'borough' not in df.columns:
                df['borough'] = np.nan # Create it if not already present from other merges
            
            census_tracts_df = load_data(os.path.join(aux_data_dir, 'nyc_census_tracts.csv'), 'Census Tracts')
            if not census_tracts_df.empty:
                census_borough_agg = census_tracts_df.groupby('Borough').agg(
                    total_population_borough=('Total Population', 'sum'),
                    median_household_income_borough=('Median Household Income', 'mean'),
                    poverty_rate_borough=('Poverty Rate', 'mean')
                ).reset_index()
                df = pd.merge(df, census_borough_agg, on='Borough', how='left')
                logging.info(f"Merged census tracts. DF shape: {df.shape}")
            else:
                logging.warning("Census tracts data not available or empty.")
        else:
            logging.info("Census tracts features are excluded.")

        logging.info("Finished adding auxiliary features.")
        return df

def run_experiment(fe_instance, scenario_name, train_path, aux_data_dir):
    logging.info(f"\n--- Running scenario: {scenario_name} ---")

    train_2022_raw = load_data(train_path, '2022 Training Data')
    if train_2022_raw.empty:
        logging.error(f"Training data for {scenario_name} is empty or could not be loaded. Skipping.")
        return None, None

    X_full_2022, y_full_2022 = fe_instance.fit(train_2022_raw, aux_data_dir)
    
    X_train, X_val, y_train, y_val = train_test_split(
        X_full_2022, y_full_2022, test_size=0.2, random_state=42
    )
    
    logging.info(f"Training data shape for {scenario_name}: {X_train.shape}, Validation data shape: {X_val.shape}")

    rf_model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1, min_samples_leaf=5)
    rf_model.fit(X_train, y_train)

    val_predictions = rf_model.predict(X_val)
    val_predictions[val_predictions < 0] = 0
    val_predictions = np.round(val_predictions).astype(int)

    val_rmse = np.sqrt(mean_squared_error(y_val, val_predictions))
    logging.info(f"Validation Performance for {scenario_name}: {val_rmse:.4f}")
    return val_rmse, scenario_name

def main():
    parser = argparse.ArgumentParser(description="Ablation study for NYC parking violations prediction.")
    parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--aux-data-dir", type=str, default="./input",
                        help="Directory containing auxiliary data CSV files.")
    
    args = parser.parse_args()

    results = {}

    # --- Baseline Scenario: Original FeatureEngineer (LabelEncoder, all aux features) ---
    fe_baseline = FeatureEngineer(use_target_encoding=False, include_traffic_counts=True, include_census_tracts=True)
    baseline_rmse, _ = run_experiment(fe_baseline, "Baseline (LabelEncoder, All Aux Features)", args.train_path, args.aux_data_dir)
    results["Baseline"] = baseline_rmse

    # --- Ablation 1: Using Smoothed Target Encoding ---
    fe_ablation_target_encoding = FeatureEngineer(use_target_encoding=True, include_traffic_counts=True, include_census_tracts=True)
    target_encoding_rmse, _ = run_experiment(fe_ablation_target_encoding, "Ablation: Smoothed Target Encoding", args.train_path, args.aux_data_dir)
    results["Smoothed Target Encoding"] = target_encoding_rmse

    # --- Ablation 2: Removing Traffic Counts Auxiliary Features ---
    fe_ablation_no_traffic = FeatureEngineer(use_target_encoding=False, include_traffic_counts=False, include_census_tracts=True)
    no_traffic_rmse, _ = run_experiment(fe_ablation_no_traffic, "Ablation: No Traffic Counts Features", args.train_path, args.aux_data_dir)
    results["No Traffic Counts Features"] = no_traffic_rmse

    # --- Ablation 3: Removing Census Tracts Auxiliary Features ---
    fe_ablation_no_census = FeatureEngineer(use_target_encoding=False, include_traffic_counts=True, include_census_tracts=False)
    no_census_rmse, _ = run_experiment(fe_ablation_no_census, "Ablation: No Census Tracts Features", args.train_path, args.aux_data_dir)
    results["No Census Tracts Features"] = no_census_rmse

    print("\n--- Ablation Study Results ---")
    if baseline_rmse is not None:
        print(f"Baseline (LabelEncoder, All Aux Features) RMSE: {baseline_rmse:.4f}")
    
    most_impactful_component = ""
    smallest_rmse_diff = float('inf')
    best_scenario = "Baseline"
    
    # Calculate differences and print
    for scenario, rmse in results.items():
        if scenario == "Baseline" or rmse is None or baseline_rmse is None:
            continue
        
        diff = rmse - baseline_rmse
        change_type = "degradation" if diff > 0 else "improvement" if diff < 0 else "no change"
        print(f"{scenario} RMSE: {rmse:.4f} (Difference from Baseline: {diff:+.4f}, {change_type})")
        
        # Determine the most impactful component (largest absolute difference from baseline)
        if abs(diff) > smallest_rmse_diff: # This logic seems inverted for "most impactful"
             # The instruction was "contributes the most to overall performance".
             # A *positive* contribution means making RMSE *smaller*.
             # A *negative* contribution (or detrimental effect) means making RMSE *larger*.
             # The most impactful is the one that causes the largest *change* (absolute difference).
             # However, if we assume "contributes" means *improves*, then it's the one that causes the largest *negative* diff (smaller RMSE).
             # If "contributes" means "without which performance is worst", then it's the largest *positive* diff.
             # Given the phrasing "which parts of the code contribute the most to the overall performance", it usually refers to positive contributions.
             # So, the one that makes RMSE lowest.
             pass # Will re-evaluate "most impactful" at the end.
    
    # Re-evaluating "most impactful" based on lowest RMSE, implying positive contribution
    if baseline_rmse is not None:
        best_rmse = baseline_rmse
        best_scenario = "Baseline"

        for scenario, rmse in results.items():
            if rmse is not None and rmse < best_rmse:
                best_rmse = rmse
                best_scenario = scenario
        
        if best_scenario == "Baseline":
            most_impactful_component = "The original configuration's (LabelEncoder + All Aux Features) setup for categorical encoding and auxiliary feature inclusion"
        elif best_scenario == "Smoothed Target Encoding":
            most_impactful_component = "The use of Smoothed Target Encoding for categorical features"
        elif best_scenario == "No Traffic Counts Features":
            most_impactful_component = "The presence of Traffic Counts features (as their removal degraded performance)" # Assuming RMSE increased
        elif best_scenario == "No Census Tracts Features":
            most_impactful_component = "The presence of Census Tracts features (as their removal degraded performance)" # Assuming RMSE increased
            
        print(f"\nBased on this ablation study, the part of the code that contributed the most to the overall performance (resulting in the lowest RMSE) is: {most_impactful_component}.")

if __name__ == '__main__':
    main()

