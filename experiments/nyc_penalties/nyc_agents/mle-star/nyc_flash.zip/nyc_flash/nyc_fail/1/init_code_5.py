
import argparse
import pandas as pd
import numpy as np
import os
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import mean_squared_error
import warnings
import sys
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import traceback

# Suppress warnings for cleaner output
warnings.filterwarnings('ignore')

# --- Check for essential libraries ---
try:
    import pandas
    import numpy
    import sklearn
    import torch
except ImportError as e:
    print(f"Missing essential library: {e}. Please ensure it is installed.", file=sys.stderr)
    raise # Re-raise the error to halt execution if critical dependencies cannot be met

# Global objects for preprocessing to be fitted on training data
label_encoders = {}
scaler = None
fitted_categorical_cols = []
fitted_numerical_cols = []
top_streets = []
top_violations = []

# Define the PyTorch MLP model
class MLP(nn.Module):
    def __init__(self, input_dim, hidden_sizes=(100, 50)):
        super(MLP, self).__init__()
        layers = []
        prev_dim = input_dim
        for h_dim in hidden_sizes:
            layers.append(nn.Linear(prev_dim, h_dim))
            layers.append(nn.ReLU())
            prev_dim = h_dim
        layers.append(nn.Linear(prev_dim, 1)) # Output layer for regression
        self.network = nn.Sequential(*layers)

    def forward(self, x):
        return self.network(x)

def load_data_from_input_dir(input_dir, filename, column_mapping=None):
    """Loads a CSV file from the input directory, handling potential FileNotFoundError."""
    filepath = os.path.join(input_dir, filename)
    try:
        df = pd.read_csv(filepath)
        print(f"Successfully loaded {filepath} with {len(df)} rows.")
        if column_mapping:
            df.rename(columns=column_mapping, inplace=True)
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {filepath}. Please ensure it exists.", file=sys.stderr)
        raise # Re-raise to indicate a critical failure
    except Exception as e:
        print(f"Error loading {filepath}: {e}", file=sys.stderr)
        raise

def apply_feature_engineering(df, is_train=True):
    """
    Applies common feature engineering steps to the dataframe.
    Groups high cardinality categorical features.
    """
    df_processed = df.copy()

    # Create simple length features
    df_processed['street_name_len'] = df_processed['street_name'].apply(lambda x: len(str(x)) if pd.notna(x) else 0)
    df_processed['violation_type_len'] = df_processed['violation_type'].apply(lambda x: len(str(x)) if pd.notna(x) else 0)

    # Handle high cardinality for street_name and violation_type by grouping
    N_top_streets = 100
    N_top_violations = 50

    global top_streets, top_violations
    if is_train:
        # Fit on training data to determine top categories
        top_streets = df_processed['street_name'].value_counts().nlargest(N_top_streets).index.tolist()
        top_violations = df_processed['violation_type'].value_counts().nlargest(N_top_violations).index.tolist()

    df_processed['street_name_grouped'] = np.where(df_processed['street_name'].isin(top_streets), df_processed['street_name'], 'Other_Street')
    df_processed['violation_type_grouped'] = np.where(df_processed['violation_type'].isin(top_violations), df_processed['violation_type'], 'Other_Violation')

    return df_processed

def prepare_features(df, categorical_cols_to_encode, numerical_cols_to_scale, is_train=True):
    """
    Prepares features for the MLP model:
    - Creates an empty DataFrame to build features consistently.
    - Adds original numerical features, handling missing columns.
    - Label-encodes specified categorical features, handling unseen categories.
    - Ensures consistent column order for scaling.
    - Applies StandardScaler.
    Updates global label_encoders, scaler, fitted_categorical_cols, and fitted_numerical_cols if is_train is True.
    """
    global label_encoders, scaler, fitted_categorical_cols, fitted_numerical_cols

    X_feats = pd.DataFrame(index=df.index) # Create an empty DataFrame to build features consistently

    # Add original numerical features
    for col in numerical_cols_to_scale:
        if col in df.columns:
            X_feats[col] = df[col]
        else:
            X_feats[col] = 0.0 # Fill missing numerical column with default
            print(f"Warning: Numerical feature '{col}' missing in current df. Added with 0.0.", file=sys.stderr)

    # Handle categorical features using LabelEncoder
    current_encoded_categorical_names = []
    for col in categorical_cols_to_encode:
        encoded_col_name = f'_encoded_{col}'
        current_encoded_categorical_names.append(encoded_col_name)

        if col in df.columns:
            if is_train:
                le = LabelEncoder()
                X_feats[encoded_col_name] = le.fit_transform(df[col].astype(str)) # Ensure string type for LE
                label_encoders[col] = le
            else:
                le = label_encoders.get(col)
                if le:
                    # Apply transform with unseen handling, map to -1
                    X_feats[encoded_col_name] = df[col].astype(str).map(lambda x: le.transform([x])[0] if x in le.classes_ else -1)
                else:
                    print(f"Warning: LabelEncoder for '{col}' not found for test data. Filling with -1.", file=sys.stderr)
                    X_feats[encoded_col_name] = -1 # Default for unseen/missing encoder
        else:
            # If original categorical column is missing, its encoded counterpart should still exist, filled with default
            X_feats[encoded_col_name] = -1
            print(f"Warning: Categorical feature '{col}' not found in DataFrame. Encoded column '{encoded_col_name}' filled with -1.", file=sys.stderr)

    # Establish the global feature order (numerical first, then encoded categoricals)
    if is_train:
        fitted_numerical_cols = numerical_cols_to_scale
        fitted_categorical_cols = current_encoded_categorical_names
        global_features_order = fitted_numerical_cols + fitted_categorical_cols
    else:
        # Use the order established during training
        global_features_order = fitted_numerical_cols + fitted_categorical_cols
        # Ensure all columns in global_features_order exist in X_feats for test set
        for fcol in global_features_order:
            if fcol not in X_feats.columns:
                default_val = -1.0 if fcol.startswith('_encoded_') else 0.0 # Default for missing
                X_feats[fcol] = default_val
                print(f"Warning: Feature '{fcol}' was in training set but missing in current df. Added with default '{default_val}'.", file=sys.stderr)

    X_final = X_feats[global_features_order].copy() # Ensure consistent column order

    # Apply StandardScaler
    if is_train:
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X_final)
    else:
        if scaler is None:
            raise ValueError("StandardScaler not fitted during training.")
        X_scaled = scaler.transform(X_final)

    return X_scaled, X_final.columns.tolist() # Return scaled features and feature names (for input_dim)

def run_pipeline(args):
    global label_encoders, scaler, fitted_categorical_cols, fitted_numerical_cols, top_streets, top_violations

    # Use device for PyTorch
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    try:
        # --- 1. Load Data ---
        print("\n--- Loading Data ---")
        input_dir = args.input_dir
        train_df_raw = load_data_from_input_dir(input_dir, args.train_path,
                                                column_mapping={'Street Name': 'street_name',
                                                                'Violation Description': 'violation_type',
                                                                'violation_count': 'violation_count'})

        # Load augmentation tables
        violation_codes_df = load_data_from_input_dir(input_dir, 'violation_codes.csv')
        nyc_borough_df = load_data_from_input_dir(input_dir, 'nyc_borough_data.csv')

        # --- 2. Feature Engineering (Training Data) ---
        print("\n--- Feature Engineering for Training Data ---")
        train_df = train_df_raw.copy()

        # Merge augmentation tables
        if 'Violation Description' in violation_codes_df.columns:
            violation_codes_df_renamed = violation_codes_df.rename(columns={'Violation Description': 'violation_type'})
            train_df = pd.merge(train_df, violation_codes_df_renamed.drop(columns=['violation_type'], errors='ignore'), on='violation_type', how='left')
        else:
            print("Warning: 'Violation Description' column not found in violation_codes.csv. Skipping merge.", file=sys.stderr)

        if 'Street Name' in nyc_borough_df.columns and 'Borough' in nyc_borough_df.columns:
            nyc_borough_df_renamed = nyc_borough_df.rename(columns={'Street Name': 'street_name'})
            train_df = pd.merge(train_df, nyc_borough_df_renamed[['street_name', 'Borough']], on='street_name', how='left')
        else:
            print("Warning: 'Street Name' or 'Borough' columns not found in nyc_borough_data.csv. Skipping merge.", file=sys.stderr)

        # Apply common feature engineering
        train_df = apply_feature_engineering(train_df, is_train=True)

        # Define features and target
        TARGET = 'violation_count'
        KEYS = ['street_name', 'violation_type'] # Original keys for output and unseen handling

        # Categorical features to be label-encoded and then scaled
        categorical_features_for_encoding = ['street_name_grouped', 'violation_type_grouped']
        if 'Borough' in train_df.columns:
            categorical_features_for_encoding.append('Borough')
        else:
             print("Warning: 'Borough' column not found in training data after merges. It will not be used as a feature.", file=sys.stderr)

        # Numerical features (will be scaled)
        numerical_features_for_scaling = ['street_name_len', 'violation_type_len']
        # You can add other numerical features from augmentation tables here if needed, e.g., 'fine_amount'

        # Ensure all defined categorical/numerical features for FE exist, or handle gracefully
        for col in categorical_features_for_encoding:
            if col not in train_df.columns:
                print(f"Warning: Categorical feature '{col}' is missing from train_df after merges. It will be added as 'Unknown' for robustness.", file=sys.stderr)
                train_df[col] = 'Unknown'
        for col in numerical_features_for_scaling:
            if col not in train_df.columns:
                print(f"Warning: Numerical feature '{col}' is missing from train_df after merges. It will be added as 0.0 for robustness.", file=sys.stderr)
                train_df[col] = 0.0
                
        # --- 3. Split Data (Train/Validation) ---
        print("\n--- Splitting Data ---")
        
        # Split features and target
        X_train_val_df = train_df.drop(columns=[TARGET], errors='ignore').copy()
        y_train_val = train_df[TARGET].copy()

        # Grouped split (if possible, otherwise random)
        X_train_df, X_val_df, y_train, y_val = train_test_split(
            X_train_val_df, y_train_val, test_size=0.2, random_state=42,
            stratify=train_df['violation_type_grouped'] if len(train_df['violation_type_grouped'].unique()) > 1 else None
        )
        print(f"Training data size: {len(X_train_df)}")
        print(f"Validation data size: {len(X_val_df)}")

        # --- 4. Preprocess Data (Fit on Train, Transform Train/Val) ---
        print("\n--- Preprocessing Training and Validation Data ---")
        
        X_train_scaled, feature_names = prepare_features(X_train_df, categorical_features_for_encoding, numerical_features_for_scaling, is_train=True)
        X_val_scaled, _ = prepare_features(X_val_df, categorical_features_for_encoding, numerical_features_for_scaling, is_train=False)

        # Convert to PyTorch tensors
        X_train_tensor = torch.tensor(X_train_scaled, dtype=torch.float32).to(device)
        y_train_tensor = torch.tensor(y_train.values, dtype=torch.float32).unsqueeze(1).to(device)
        X_val_tensor = torch.tensor(X_val_scaled, dtype=torch.float32).to(device)
        y_val_tensor = torch.tensor(y_val.values, dtype=torch.float32).unsqueeze(1).to(device)
        
        # Create DataLoaders
        train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
        train_loader = DataLoader(train_dataset, batch_size=128, shuffle=True)
        val_dataset = TensorDataset(X_val_tensor, y_val_tensor)
        val_loader = DataLoader(val_dataset, batch_size=128, shuffle=False)

        # --- 5. Model Training ---
        print("\n--- Model Training ---")
        input_dim = X_train_scaled.shape[1]
        model = MLP(input_dim=input_dim).to(device)
        optimizer = optim.Adam(model.parameters(), lr=1e-3)
        criterion = nn.MSELoss() # For regression, standard for MLPRegressor equivalent

        num_epochs = 200 # Roughly equivalent to max_iter in sklearn's MLPRegressor for a simple setup
        for epoch in range(num_epochs):
            model.train()
            train_loss = 0
            for batch_X, batch_y in train_loader:
                optimizer.zero_grad()
                outputs = model(batch_X)
                loss = criterion(outputs, batch_y)
                loss.backward()
                optimizer.step()
                train_loss += loss.item()
            
            # Optional: print training loss periodically
            # if (epoch + 1) % 50 == 0:
            #     print(f"Epoch {epoch+1}/{num_epochs}, Train Loss: {train_loss/len(train_loader):.4f}")

        print("Model training complete.")

        # --- 6. Validation ---
        print("\n--- Validation ---")
        model.eval()
        val_predictions_list = []
        with torch.no_grad():
            for batch_X_val, _ in val_loader:
                outputs = model(batch_X_val)
                val_predictions_list.append(outputs.cpu().numpy())
        
        val_predictions = np.vstack(val_predictions_list).flatten()
        val_predictions[val_predictions < 0] = 0 # Clip negative predictions
        val_predictions_rounded = np.round(val_predictions).astype(int) # Round as per example for RMSE

        rmse_val = np.sqrt(mean_squared_error(y_val, val_predictions_rounded))
        print(f"Final Validation Performance: {rmse_val}") # Required print statement

        # --- 7. Test Prediction (if test_path is provided) ---
        if args.test_path:
            print("\n--- Generating Test Predictions ---")
            test_df_raw = load_data_from_input_dir(input_dir, args.test_path,
                                                    column_mapping={'Street Name': 'street_name',
                                                                    'Violation Description': 'violation_type',
                                                                    'violation_count': 'violation_count'})

            # Preserve original keys for submission and unseen tracking
            test_original_keys = test_df_raw[KEYS].copy()

            # --- Feature Engineering (Test Data) ---
            test_df = test_df_raw.copy()

            # Merge violation_codes_df
            if 'Violation Description' in violation_codes_df.columns:
                violation_codes_df_renamed = violation_codes_df.rename(columns={'Violation Description': 'violation_type'})
                test_df = pd.merge(test_df, violation_codes_df_renamed.drop(columns=['violation_type'], errors='ignore'), on='violation_type', how='left')
            
            # Merge nyc_borough_data.csv
            if 'Street Name' in nyc_borough_df.columns and 'Borough' in nyc_borough_df.columns:
                nyc_borough_df_renamed = nyc_borough_df.rename(columns={'Street Name': 'street_name'})
                test_df = pd.merge(test_df, nyc_borough_df_renamed[['street_name', 'Borough']], on='street_name', how='left')
            
            # Apply common feature engineering
            test_df = apply_feature_engineering(test_df, is_train=False)

            # Ensure all defined categorical/numerical features for FE exist in test_df, or handle gracefully
            for col in categorical_features_for_encoding:
                if col not in test_df.columns:
                    print(f"Warning: Categorical feature '{col}' is missing from test_df after merges. It will be added as 'Unknown' for robustness.", file=sys.stderr)
                    test_df[col] = 'Unknown'
            for col in numerical_features_for_scaling:
                if col not in test_df.columns:
                    print(f"Warning: Numerical feature '{col}' is missing from test_df after merges. It will be added as 0.0 for robustness.", file=sys.stderr)
                    test_df[col] = 0.0

            # Preprocess test data using the *fitted* encoders and scaler
            X_test_scaled, _ = prepare_features(test_df, categorical_features_for_encoding, numerical_features_for_scaling, is_train=False)

            # Convert to PyTorch tensor
            X_test_tensor = torch.tensor(X_test_scaled, dtype=torch.float32).to(device)
            test_dataset = TensorDataset(X_test_tensor) # Only features, no target
            test_loader = DataLoader(test_dataset, batch_size=128, shuffle=False)

            model.eval()
            test_predictions_list = []
            with torch.no_grad():
                for batch_X_test in test_loader:
                    outputs = model(batch_X_test[0]) # batch_X_test is a tuple (X,)
                    test_predictions_list.append(outputs.cpu().numpy())
            
            test_predictions = np.vstack(test_predictions_list).flatten()
            test_predictions[test_predictions < 0] = 0 # Clip negative predictions
            test_predictions_rounded = np.round(test_predictions).astype(int)

            # Handle unseen key pairs in test set
            train_key_pairs = set(train_df_raw[KEYS].apply(lambda row: (row['street_name'], row['violation_type']), axis=1))
            test_key_pairs = test_original_keys.apply(lambda row: (row['street_name'], row['violation_type']), axis=1)

            unseen_mask = ~test_key_pairs.isin(train_key_pairs)
            num_unseen = unseen_mask.sum()
            print(f"Number of unseen (street_name, violation_type) pairs in test set: {num_unseen}")

            # Create submission file
            submission_df = pd.DataFrame({
                'street_name': test_original_keys['street_name'],
                'violation_type': test_original_keys['violation_type'],
                'predicted_count': test_predictions_rounded
            })
            submission_df.to_csv('submission.csv', index=False)
            print("Submission file 'submission.csv' generated successfully.")

            # Report RMSE if ground truth is available in the test file
            if TARGET in test_df_raw.columns and test_df_raw[TARGET].notna().any():
                y_test_ground_truth = test_df_raw[TARGET].copy()
                print("\n--- Test Set Evaluation ---")
                rmse_test = np.sqrt(mean_squared_error(y_test_ground_truth, test_predictions_rounded))
                print(f"Test Set RMSE: {rmse_test}")
            else:
                print("\nNo ground truth in test file. Skipping Test Set RMSE calculation.")

        print("\n--- Pipeline execution complete ---")

    except Exception as e:
        print(f"An unexpected error occurred during pipeline execution: {e}", file=sys.stderr)
        traceback.print_exc(file=sys.stderr)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='violations_per_street_2022.csv',
                        help='Path to the training data CSV file relative to input_dir.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional path to the test data CSV file relative to input_dir. If provided, predictions will be generated.')
    parser.add_argument('--input-dir', type=str, default='./input',
                        help='Directory containing all input CSV files.')

    args = parser.parse_args()

    run_pipeline(args)
