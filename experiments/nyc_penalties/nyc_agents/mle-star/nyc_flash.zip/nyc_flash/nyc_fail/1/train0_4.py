
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder, StandardScaler
import argparse
import os
import logging
import warnings

# PyTorch imports
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset

# Suppress warnings for cleaner output
warnings.filterwarnings('ignore')

# Set up logging for better visibility during execution
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Helper function to load data safely ---
def load_data(file_path, df_name="DataFrame", column_mapping=None):
    """
    Loads a CSV file into a pandas DataFrame.
    Handles file not found errors and general exceptions during loading.
    Can also rename columns during loading.
    """
    if not os.path.exists(file_path):
        logging.warning(f"File not found at {file_path} for {df_name}. Returning empty DataFrame.")
        return pd.DataFrame()
    try:
        df = pd.read_csv(file_path)
        if column_mapping:
            df.rename(columns=column_mapping, inplace=True)
        logging.info(f"Successfully loaded {df_name} from {file_path} with {len(df)} rows.")
        return df
    except Exception as e:
        logging.error(f"Error loading {file_path} for {df_name}: {e}. Returning empty DataFrame.")
        return pd.DataFrame()

# --- Define the PyTorch MLP model ---
class MLP(nn.Module):
    def __init__(self, input_dim, hidden_sizes=(100, 50)):
        super(MLP, self).__init__()
        layers = []
        prev_dim = input_dim
        for h_dim in hidden_sizes:
            layers.append(nn.Linear(prev_dim, h_dim))
            layers.append(nn.ReLU())
            prev_dim = h_dim
        layers.append(nn.Linear(prev_dim, 1)) # Output layer for regression
        self.network = nn.Sequential(*layers)

    def forward(self, x):
        return self.network(x)

# --- Feature Engineering and Preprocessing Class ---
class FeatureEngineer:
    """
    Handles loading auxiliary data, creating new features, encoding categorical variables,
    and imputing missing values for both training and prediction datasets.
    Prepares data for RandomForest (numerical/encoded categoricals) and MLP.
    """
    def __init__(self):
        # For RandomForest LabelEncoding (on original street/violation/borough)
        self.le_street = LabelEncoder()
        self.le_violation = LabelEncoder()
        self.le_borough = LabelEncoder() # For base solution's borough

        # For MLP's grouped/encoded features
        self.top_streets = [] # To track top categories for grouping
        self.top_violations = [] # To track top categories for grouping
        self.mlp_le_grouped_street = LabelEncoder()
        self.mlp_le_grouped_violation = LabelEncoder()
        self.mlp_le_borough = LabelEncoder() # For MLP's borough feature
        self.mlp_scaler = StandardScaler()

        self.trained_street_violation_pairs = None # To track unseen pairs in test
        
        # Lists to store final feature names for each model after fit
        self.rf_feature_columns = []
        self.mlp_numerical_feature_columns = []
        self.mlp_categorical_feature_columns = [] # Will store names of grouped/borough columns

    def fit(self, df_train_raw, aux_data_dir="./input"):
        """
        Fits the feature engineer on the raw training data.
        Performs feature creation, imputation, and fits all LabelEncoders and StandardScaler.
        Returns a DataFrame with all raw and encoded features (before model-specific selection/scaling)
        and the target (y) for training.
        """
        logging.info("Fitting FeatureEngineer...")

        # Step 1: Process core data (rename, store target, fill NaNs in key string cols)
        df_train_processed = self._process_core_data(df_train_raw.copy(), is_train=True)
        y_train = df_train_processed['violation_count']
        df_train_processed.drop(columns=['violation_count'], errors='ignore', inplace=True) 

        # Step 2: Store key pairs for unseen tracking
        self.trained_street_violation_pairs = set(
            df_train_processed.apply(lambda row: (row['street_name'], row['violation_type']), axis=1)
        )
        
        # Step 3: Add auxiliary features and basic derived features
        df_features = self._add_auxiliary_features(df_train_processed.copy(), aux_data_dir)
        
        # Step 4: Create grouped categories (for MLP) and ensure 'borough' is consistent
        df_features = self._create_grouped_categories(df_features, is_train=True)
        
        # Step 5: Fit and apply LabelEncoders for RandomForest (on original/raw categorical columns)
        self._fit_rf_label_encoders(df_features)
        df_features = self._apply_rf_label_encoders(df_features) # Adds 'street_name_encoded', 'violation_type_encoded', 'borough_encoded'
        
        # Step 6: Identify RandomForest features (all numerical, including LE ones)
        self.rf_feature_columns = [
            col for col in df_features.select_dtypes(include=np.number).columns
            if col not in ['violation_count', 'actual_violation_count'] # Exclude target/temp evaluation columns
        ]
        
        # Step 7: Define MLP features and fit their specific preprocessors
        self.mlp_categorical_feature_columns = ['street_name_grouped', 'violation_type_grouped', 'borough_mlp']
        self.mlp_numerical_feature_columns = [
            'street_name_len', 'violation_type_len', 'fine_amount_avg',
            'street_segment_length_sum', 'street_speed_limit_mean', 'street_num_lanes_mean',
            'num_parking_zones', 'avg_max_duration_parking',
            'avg_vehicle_count', 'max_vehicle_count', 'std_vehicle_count',
            'total_population_borough', 'median_household_income_borough', 'poverty_rate_borough'
        ]
        # Filter for columns that actually exist in the DataFrame to avoid errors
        self.mlp_numerical_feature_columns = [col for col in self.mlp_numerical_feature_columns if col in df_features.columns]
        self.mlp_categorical_feature_columns = [col for col in self.mlp_categorical_feature_columns if col in df_features.columns]

        # Ensure all MLP numerical features are filled (0) for scaler fit
        for col in self.mlp_numerical_feature_columns:
            df_features[col] = df_features[col].fillna(0)
        
        # Fit MLP LabelEncoders
        if 'street_name_grouped' in df_features.columns:
            self.mlp_le_grouped_street.fit(df_features['street_name_grouped'].unique())
        if 'violation_type_grouped' in df_features.columns:
            self.mlp_le_grouped_violation.fit(df_features['violation_type_grouped'].unique())
        if 'borough_mlp' in df_features.columns:
            self.mlp_le_borough.fit(df_features['borough_mlp'].unique())

        # Fit MLP StandardScaler on numerical features
        self.mlp_scaler.fit(df_features[self.mlp_numerical_feature_columns])

        # Step 8: Impute any remaining NaNs across all feature columns (for robustness)
        for col in df_features.select_dtypes(include=np.number).columns:
            df_features[col].fillna(0, inplace=True)
        
        logging.info(f"Identified {len(self.rf_feature_columns)} features for RandomForest.")
        logging.info(f"Identified {len(self.mlp_numerical_feature_columns) + len(self.mlp_categorical_feature_columns)} features for MLP.")
        
        return df_features, y_train

    def transform(self, df_data_raw, aux_data_dir="./input"):
        """
        Transforms new raw data (e.g., test/evaluation data) using the fitted feature engineer.
        Applies feature creation and imputation based on training data.
        Returns a DataFrame with all raw and encoded features (before model-specific selection/scaling).
        """
        logging.info("Transforming data using fitted FeatureEngineer...")
        df_processed = self._process_core_data(df_data_raw.copy(), is_train=False)
        df_features = self._add_auxiliary_features(df_processed.copy(), aux_data_dir)
        
        # Create grouped categories
        df_features = self._create_grouped_categories(df_features, is_train=False)
        
        # Apply RandomForest LabelEncoders
        df_features = self._apply_rf_label_encoders(df_features)

        # Ensure all necessary MLP numerical features are present and filled
        for col in self.mlp_numerical_feature_columns:
            if col not in df_features.columns:
                df_features[col] = 0.0
                logging.warning(f"Added missing MLP numerical feature '{col}' to test data with 0.0.")
            else:
                df_features[col].fillna(0, inplace=True) # Fill NaNs for existing columns

        # Ensure all necessary MLP categorical features are present and filled
        for col in self.mlp_categorical_feature_columns:
            if col not in df_features.columns:
                # Add with a default 'unknown' category that will be mapped by LE
                df_features[col] = 'UNKNOWN_CATEGORY' 
                logging.warning(f"Added missing MLP categorical feature '{col}' to test data with 'UNKNOWN_CATEGORY'.")
            else:
                df_features[col] = df_features[col].fillna('UNKNOWN_CATEGORY').astype(str)

        # Impute any remaining NaNs across all feature columns (for robustness)
        for col in df_features.select_dtypes(include=np.number).columns:
            df_features[col].fillna(0, inplace=True)
            
        # Ensure all RF feature columns are present and in order
        for col in self.rf_feature_columns:
            if col not in df_features.columns:
                df_features[col] = 0.0 # Add missing features with a default value
                logging.warning(f"Added missing RF feature '{col}' to test data with 0.")

        return df_features

    def _process_core_data(self, df, is_train=False):
        """Standardizes column names and handles target column for test data."""
        df.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type',
            'violation_count': 'violation_count'
        }, inplace=True)

        if not is_train and 'violation_count' in df.columns:
            df['actual_violation_count'] = df['violation_count'] # Store actual counts for evaluation
            df.drop(columns=['violation_count'], inplace=True)
            
        df['street_name'] = df['street_name'].fillna('UNKNOWN_STREET').astype(str)
        df['violation_type'] = df['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str)
        return df

    def _add_auxiliary_features(self, df, aux_data_dir):
        """
        Loads and merges auxiliary data to enrich the main DataFrame with additional features.
        Also adds basic derived features like length.
        """
        logging.info("Adding auxiliary features and derived features...")

        # Add basic length features from reference solution
        df['street_name_len'] = df['street_name'].apply(lambda x: len(str(x)) if pd.notna(x) else 0)
        df['violation_type_len'] = df['violation_type'].apply(lambda x: len(str(x)) if pd.notna(x) else 0)

        # Initialize 'borough' column which will be consolidated
        df['borough'] = np.nan

        # --- NYC Borough Data (Reference Solution Source) ---
        nyc_borough_df = load_data(os.path.join(aux_data_dir, 'nyc_borough_data.csv'), 'NYC Borough Data')
        if not nyc_borough_df.empty:
            nyc_borough_df.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, nyc_borough_df[['street_name', 'Borough']], on='street_name', how='left')
            df['borough'] = df['borough'].fillna(df['Borough']) # Consolidate
            df.drop(columns=['Borough'], errors='ignore', inplace=True)
            logging.info(f"Merged NYC Borough data. DF shape: {df.shape}")
        
        # --- Violation Codes Features ---
        violation_codes_df = load_data(os.path.join(aux_data_dir, 'violation_codes.csv'), 'Violation Codes')
        if not violation_codes_df.empty:
            violation_codes_df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
            violation_codes_df['fine_amount_avg'] = (
                violation_codes_df['Manhattan 96th St. & Below'].fillna(0) + 
                violation_codes_df['All Other Areas'].fillna(0)
            ) / 2
            violation_codes_df.drop(columns=['Violation Code', 'Manhattan 96th St. & Below', 'All Other Areas'], errors='ignore', inplace=True)
            df = pd.merge(df, violation_codes_df, on='violation_type', how='left')
            logging.info(f"Merged violation codes. DF shape: {df.shape}")
        
        # --- Street Segments Features ---
        street_segments_df = load_data(os.path.join(aux_data_dir, 'nyc_street_segments.csv'), 'Street Segments')
        if not street_segments_df.empty:
            street_segments_agg = street_segments_df.groupby('Street Name').agg(
                street_segment_length_sum=('Segment Length', 'sum'),
                street_speed_limit_mean=('Speed Limit', 'mean'),
                street_num_lanes_mean=('Number of Lanes', 'mean'),
                borough_ss=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            street_segments_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, street_segments_agg, on='street_name', how='left')
            # Fill 'borough' NaNs with borough_ss if available
            df['borough'] = df['borough'].fillna(df['borough_ss'])
            df.drop(columns=['borough_ss'], errors='ignore', inplace=True)
            logging.info(f"Merged street segments. DF shape: {df.shape}")
            
        # --- Parking Zones Features ---
        parking_zones_df = load_data(os.path.join(aux_data_dir, 'nyc_parking_zones.csv'), 'Parking Zones')
        if not parking_zones_df.empty:
            parking_zones_agg = parking_zones_df.groupby('Street Name').agg(
                num_parking_zones=('Parking Zone', 'count'),
                avg_max_duration_parking=('Max Duration', 'mean'),
                borough_pz=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            parking_zones_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, parking_zones_agg, on='street_name', how='left')
            # Fill 'borough' NaNs with borough_pz if available
            df['borough'] = df['borough'].fillna(df['borough_pz'])
            df.drop(columns=['borough_pz'], errors='ignore', inplace=True)
            logging.info(f"Merged parking zones. DF shape: {df.shape}")

        # --- Traffic Counts Features ---
        traffic_counts_df = load_data(os.path.join(aux_data_dir, 'traffic_counts_nyc.csv'), 'Traffic Counts')
        if not traffic_counts_df.empty:
            traffic_counts_agg = traffic_counts_df.groupby('Street Name').agg(
                avg_vehicle_count=('Vehicle Count', 'mean'),
                max_vehicle_count=('Vehicle Count', 'max'),
                std_vehicle_count=('Vehicle Count', 'std')
            ).reset_index()
            traffic_counts_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, traffic_counts_agg, on='street_name', how='left')
            logging.info(f"Merged traffic counts. DF shape: {df.shape}")

        # --- Census Tracts Features ---
        # Create a temporary 'Borough_for_census_merge' column, filled from 'borough'
        df['Borough_for_census_merge'] = df['borough'].fillna('UNKNOWN_BOROUGH').astype(str)
        
        census_tracts_df = load_data(os.path.join(aux_data_dir, 'nyc_census_tracts.csv'), 'Census Tracts')
        if not census_tracts_df.empty:
            census_borough_agg = census_tracts_df.groupby('Borough').agg(
                total_population_borough=('Total Population', 'sum'),
                median_household_income_borough=('Median Household Income', 'mean'),
                poverty_rate_borough=('Poverty Rate', 'mean')
            ).reset_index()
            df = pd.merge(df, census_borough_agg, left_on='Borough_for_census_merge', right_on='Borough', how='left')
            df.drop(columns=['Borough_for_census_merge', 'Borough'], errors='ignore', inplace=True) # Drop temporary merge column and original Borough from census
            logging.info(f"Merged census tracts. DF shape: {df.shape}")
        else:
            logging.warning("Census tracts data not available or empty.")
        
        # Create a specific 'borough' column for MLP to ensure consistency, filled as string
        df['borough_mlp'] = df['borough'].copy().fillna('UNKNOWN_BOROUGH').astype(str)

        logging.info("Finished adding auxiliary features.")
        return df

    def _create_grouped_categories(self, df, is_train=False):
        """
        Creates grouped categorical features based on frequency for high-cardinality columns.
        Uses top categories learned from training data.
        Also ensures 'borough' features (both for RF and MLP) are consistently string-typed and filled.
        """
        N_top_streets = 100
        N_top_violations = 50

        if is_train:
            self.top_streets = df['street_name'].value_counts().nlargest(N_top_streets).index.tolist()
            self.top_violations = df['violation_type'].value_counts().nlargest(N_top_violations).index.tolist()

        df['street_name_grouped'] = np.where(df['street_name'].isin(self.top_streets), df['street_name'], 'Other_Street')
        df['violation_type_grouped'] = np.where(df['violation_type'].isin(self.top_violations), df['violation_type'], 'Other_Violation')

        # Ensure 'borough' and 'borough_mlp' are string type and filled for encoding
        df['borough'] = df['borough'].fillna('UNKNOWN_BOROUGH').astype(str)
        df['borough_mlp'] = df['borough_mlp'].fillna('UNKNOWN_BOROUGH').astype(str)

        logging.info("Created grouped categorical features.")
        return df

    def _fit_rf_label_encoders(self, df_train):
        """Fits LabelEncoders for RandomForest on original street/violation/borough columns."""
        logging.info("Fitting RandomForest LabelEncoders...")
        self.le_street.fit(df_train['street_name'].unique())
        self.le_violation.fit(df_train['violation_type'].unique())
        self.le_borough.fit(df_train['borough'].unique())

    def _apply_rf_label_encoders(self, df):
        """Applies fitted LabelEncoders for RandomForest to categorical columns, mapping unseen categories to -1."""
        df['street_name_encoded'] = df['street_name'].map(
            lambda x: self.le_street.transform([x])[0] if x in self.le_street.classes_ else -1
        ).fillna(-1).astype(int)

        df['violation_type_encoded'] = df['violation_type'].map(
            lambda x: self.le_violation.transform([x])[0] if x in self.le_violation.classes_ else -1
        ).fillna(-1).astype(int)
        
        df['borough_encoded'] = df['borough'].map(
            lambda x: self.le_borough.transform([x])[0] if x in self.le_borough.classes_ else -1
        ).fillna(-1).astype(int)
            
        return df

    def get_rf_features(self, df):
        """Returns the feature DataFrame suitable for RandomForest."""
        # Ensure selected columns exist, if not, add with 0.0 default
        df_rf_features = df[self.rf_feature_columns].copy()
        for col in self.rf_feature_columns:
            if col not in df_rf_features.columns:
                df_rf_features[col] = 0.0
        return df_rf_features

    def get_mlp_features_scaled(self, df):
        """
        Applies LabelEncoding to MLP categorical features and StandardScaler to numerical features,
        then concatenates them into a single scaled numpy array.
        """
        mlp_features_list = []

        # Process categorical features for MLP
        for col in self.mlp_categorical_feature_columns:
            le = None
            if col == 'street_name_grouped':
                le = self.mlp_le_grouped_street
            elif col == 'violation_type_grouped':
                le = self.mlp_le_grouped_violation
            elif col == 'borough_mlp':
                le = self.mlp_le_borough
            
            if le is not None:
                # Map values, handling unseen categories with -1
                encoded_col = df[col].astype(str).map(
                    lambda x: le.transform([x])[0] if x in le.classes_ else -1
                ).fillna(-1).values.reshape(-1, 1) # Reshape for concatenation
                mlp_features_list.append(encoded_col)
            else:
                logging.warning(f"LabelEncoder for MLP categorical column '{col}' not found. Using default -1.")
                mlp_features_list.append(np.full((len(df), 1), -1))


        # Scale numerical features for MLP
        numerical_data = df[self.mlp_numerical_feature_columns].values
        scaled_numerical_data = self.mlp_scaler.transform(numerical_data)
        mlp_features_list.append(scaled_numerical_data)

        # Concatenate all processed features
        return np.hstack(mlp_features_list)

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations for 2023 using RandomForestRegressor and MLP.")
    parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Optional: Path to the 2023 test/evaluation data CSV. If provided, predictions will be generated.")
    parser.add_argument("--aux-data-dir", type=str, default="./input",
                        help="Directory containing auxiliary data CSV files.")
    
    args = parser.parse_args()

    logging.info(f"Starting prediction pipeline with train_path: {args.train_path}")

    # Use device for PyTorch
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logging.info(f"Using device for MLP: {device}")

    # Load 2022 training data
    train_2022_raw = load_data(args.train_path, '2022 Training Data',
                               column_mapping={'Street Name': 'street_name',
                                               'Violation Description': 'violation_type',
                                               'violation_count': 'violation_count'})
    if train_2022_raw.empty:
        logging.error("Training data is empty or could not be loaded. Exiting.")
        return

    # Initialize Feature Engineer
    fe = FeatureEngineer()

    # Fit feature engineer on the full 2022 data and get processed features and target
    X_full_2022_df, y_full_2022 = fe.fit(train_2022_raw, args.aux_data_dir)
    
    # Split 2022 data into training and validation sets for development evaluation
    # X_train_df, X_val_df will be DataFrames with all raw and encoded features (before model-specific scaling/selection)
    X_train_df, X_val_df, y_train, y_val = train_test_split(
        X_full_2022_df, y_full_2022, test_size=0.2, random_state=42
    )
    
    logging.info(f"Training data shape (full DF): {X_train_df.shape}, Validation data shape (full DF): {X_val_df.shape}")

    # --- Model Training: RandomForestRegressor ---
    logging.info("Training RandomForestRegressor model...")
    rf_model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1, min_samples_leaf=5)
    
    X_train_rf = fe.get_rf_features(X_train_df)
    rf_model.fit(X_train_rf, y_train)
    logging.info("RandomForestRegressor model training complete.")

    # --- Model Training: PyTorch MLP ---
    logging.info("Training PyTorch MLP model...")
    X_train_mlp_scaled = fe.get_mlp_features_scaled(X_train_df)
    
    # Convert to PyTorch tensors
    X_train_mlp_tensor = torch.tensor(X_train_mlp_scaled, dtype=torch.float32).to(device)
    y_train_mlp_tensor = torch.tensor(y_train.values, dtype=torch.float32).unsqueeze(1).to(device)
    
    # Create DataLoaders
    train_dataset = TensorDataset(X_train_mlp_tensor, y_train_mlp_tensor)
    train_loader = DataLoader(train_dataset, batch_size=128, shuffle=True)

    input_dim_mlp = X_train_mlp_scaled.shape[1]
    mlp_model = MLP(input_dim=input_dim_mlp).to(device)
    mlp_optimizer = optim.Adam(mlp_model.parameters(), lr=1e-3)
    mlp_criterion = nn.MSELoss()

    num_epochs_mlp = 200
    for epoch in range(num_epochs_mlp):
        mlp_model.train()
        train_loss_mlp = 0
        for batch_X, batch_y in train_loader:
            mlp_optimizer.zero_grad()
            outputs = mlp_model(batch_X)
            loss = mlp_criterion(outputs, batch_y)
            loss.backward()
            mlp_optimizer.step()
            train_loss_mlp += loss.item()
    logging.info("PyTorch MLP model training complete.")

    # --- Validation Prediction and Evaluation ---
    logging.info("Generating validation predictions...")
    
    # RandomForest predictions
    X_val_rf = fe.get_rf_features(X_val_df)
    val_predictions_rf = rf_model.predict(X_val_rf)
    val_predictions_rf[val_predictions_rf < 0] = 0 # Ensure predictions are non-negative

    # MLP predictions
    X_val_mlp_scaled = fe.get_mlp_features_scaled(X_val_df)
    X_val_mlp_tensor = torch.tensor(X_val_mlp_scaled, dtype=torch.float32).to(device)
    val_mlp_dataset = TensorDataset(X_val_mlp_tensor)
    val_mlp_loader = DataLoader(val_mlp_dataset, batch_size=128, shuffle=False)

    mlp_model.eval()
    val_predictions_mlp_list = []
    with torch.no_grad():
        for batch_X_val in val_mlp_loader:
            outputs = mlp_model(batch_X_val[0])
            val_predictions_mlp_list.append(outputs.cpu().numpy())
    
    val_predictions_mlp = np.vstack(val_predictions_mlp_list).flatten()
    val_predictions_mlp[val_predictions_mlp < 0] = 0 # Clip negative predictions

    # Ensemble predictions (simple average)
    val_predictions_ensemble = (val_predictions_rf + val_predictions_mlp) / 2
    val_predictions_ensemble = np.round(val_predictions_ensemble).astype(int) # Round to nearest integer

    val_rmse = np.sqrt(mean_squared_error(y_val, val_predictions_ensemble))
    print(f"Final Validation Performance: {val_rmse:.4f}")

    # --- 2023 Prediction if test-path is provided ---
    if args.test_path:
        logging.info(f"Processing test data from {args.test_path} for 2023 predictions.")
        test_2023_raw = load_data(args.test_path, '2023 Test Data',
                                  column_mapping={'Street Name': 'street_name',
                                                  'Violation Description': 'violation_type',
                                                  'violation_count': 'violation_count'})
        if test_2023_raw.empty:
            logging.warning("Test data is empty or not found. Skipping 2023 predictions.")
            return

        # Keep original key columns for submission output
        submission_keys_raw = test_2023_raw[['street_name', 'violation_type']].copy()
        
        # Transform test data using the *fitted* feature engineer
        X_test_df = fe.transform(test_2023_raw.copy(), args.aux_data_dir)

        # Report unseen key pairs in the test set
        test_street_violation_pairs = set(
            submission_keys_raw.apply(lambda row: (row['street_name'], row['violation_type']), axis=1)
        )
        unseen_pairs_count = len(test_street_violation_pairs - fe.trained_street_violation_pairs)
        logging.info(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_pairs_count}")

        # Make predictions on the transformed test data with both models
        X_test_rf = fe.get_rf_features(X_test_df)
        predictions_2023_rf = rf_model.predict(X_test_rf)
        predictions_2023_rf[predictions_2023_rf < 0] = 0 # Ensure non-negative counts

        X_test_mlp_scaled = fe.get_mlp_features_scaled(X_test_df)
        X_test_mlp_tensor = torch.tensor(X_test_mlp_scaled, dtype=torch.float32).to(device)
        test_mlp_dataset = TensorDataset(X_test_mlp_tensor)
        test_mlp_loader = DataLoader(test_mlp_dataset, batch_size=128, shuffle=False)

        mlp_model.eval()
        predictions_2023_mlp_list = []
        with torch.no_grad():
            for batch_X_test in test_mlp_loader:
                outputs = mlp_model(batch_X_test[0])
                predictions_2023_mlp_list.append(outputs.cpu().numpy())
        
        predictions_2023_mlp = np.vstack(predictions_2023_mlp_list).flatten()
        predictions_2023_mlp[predictions_2023_mlp < 0] = 0 # Clip negative predictions

        # Ensemble test predictions
        predictions_2023_ensemble = (predictions_2023_rf + predictions_2023_mlp) / 2
        predictions_2023_ensemble = np.round(predictions_2023_ensemble).astype(int) # Round to integer counts

        # Create submission file
        submission_df = submission_keys_raw
        submission_df['predicted_count'] = predictions_2023_ensemble
        submission_df.to_csv('submission.csv', index=False)
        logging.info("Generated submission.csv with 2023 predictions.")

        # Evaluate if actual counts are present in the provided test/eval file
        if 'actual_violation_count' in X_test_df.columns:
            actual_counts_for_eval = X_test_df['actual_violation_count']
            test_rmse = np.sqrt(mean_squared_error(actual_counts_for_eval, predictions_2023_ensemble))
            print(f"RMSE on provided test/eval data: {test_rmse:.4f}")
        else:
            logging.info("No 'actual_violation_count' column found in test data for evaluation.")
            
    else:
        logging.info("No test-path provided. Skipping 2023 predictions and submission file generation.")

if __name__ == '__main__':
    main()

