
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os
import glob
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def normalize_column_names(df):
    """
    Normalizes column names by lowercasing and replacing spaces with underscores.
    Also specifically renames 'Street Name' to 'street_name' and
    'Violation Description' to 'violation_type' (case-insensitive).
    """
    new_columns = []
    for col in df.columns:
        if col.lower() == 'street name':
            new_columns.append('street_name')
        elif col.lower() == 'violation description':
            new_columns.append('violation_type')
        else:
            new_columns.append(col.lower().replace(' ', '_'))
    df.columns = new_columns
    return df

def rmse(y_true, y_pred):
    """Calculates the Root Mean Squared Error."""
    return np.sqrt(mean_squared_error(y_true, y_pred))

def main():
    parser = argparse.ArgumentParser(description="Predict parking violations for 2023.")
    parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Optional: Path to the 2023 test data CSV for prediction/evaluation.")
    args = parser.parse_args()

    # --- Load and preprocess training data ---
    logging.info(f"Loading training data from: {args.train_path}")
    try:
        train_df = pd.read_csv(args.train_path)
        train_df = normalize_column_names(train_df)
        required_train_cols = ['street_name', 'violation_type', 'violation_count']
        if not all(col in train_df.columns for col in required_train_cols):
            missing_cols = [col for col in required_train_cols if col not in train_df.columns]
            logging.error(f"Training data is missing required columns: {missing_cols}. Found: {train_df.columns.tolist()}")
            raise KeyError(f"Missing required columns in training data: {missing_cols}")
        logging.info("Training data loaded and columns normalized.")
    except FileNotFoundError:
        logging.error(f"Training data file not found at {args.train_path}. Please check the path.")
        return
    except Exception as e:
        logging.error(f"Error loading or processing training data: {e}")
        return

    # --- Data Augmentation ---
    input_dir = os.path.dirname(args.train_path)
    if not input_dir: # If train-path was just a filename, assume current dir or relative input dir
        input_dir = './input'
    
    augmentation_files = glob.glob(os.path.join(input_dir, '*.csv'))
    augmentation_dfs = {}

    logging.info(f"Attempting to load augmentation datasets from {input_dir}...")
    for f_path in augmentation_files:
        file_name = os.path.basename(f_path)
        # Skip the primary training file itself
        if file_name == os.path.basename(args.train_path):
            continue 

        try:
            aug_df = pd.read_csv(f_path)
            aug_df = normalize_column_names(aug_df) # Normalize augmentation dataframe columns too
            augmentation_dfs[file_name] = aug_df
            logging.info(f"Loaded augmentation file: {file_name} with columns: {aug_df.columns.tolist()}")
        except Exception as e:
            logging.warning(f"Could not load or process augmentation file {file_name}: {e}")

    # Example augmentation: merging a hypothetical 'street_attributes.csv'
    if 'street_attributes.csv' in augmentation_dfs: # Assuming this file and structure
        street_attrs_df = augmentation_dfs['street_attributes.csv']
        if 'street_name' in street_attrs_df.columns:
            # Drop duplicates in case street_attributes has non-unique street names per street_name
            street_attrs_df = street_attrs_df.drop_duplicates(subset=['street_name'])
            # Ensure 'street_name' is string type in both DFs before merging to avoid type inconsistencies
            train_df['street_name'] = train_df['street_name'].astype(str)
            street_attrs_df['street_name'] = street_attrs_df['street_name'].astype(str)
            
            train_df = pd.merge(train_df, street_attrs_df, on='street_name', how='left')
            logging.info("Merged 'street_attributes.csv' with training data on 'street_name'.")
        else:
            logging.warning("'street_attributes.csv' does not contain 'street_name' for merging. Skipping merge.")

    # --- Feature Engineering for Training Data ---
    logging.info("Starting feature engineering for training data...")
    # Create frequency features for street_name and violation_type
    train_df['street_name_freq'] = train_df.groupby('street_name')['street_name'].transform('count')
    train_df['violation_type_freq'] = train_df.groupby('violation_type')['violation_type'].transform('count')

    # Interaction feature frequency
    train_df['street_violation_pair'] = train_df['street_name'] + '_' + train_df['violation_type']
    train_df['pair_freq'] = train_df.groupby('street_violation_pair')['street_violation_pair'].transform('count')
    train_df = train_df.drop(columns=['street_violation_pair']) # Drop temporary column

    logging.info("Feature engineering completed for training data.")

    # Store frequency maps for use in test data to prevent leakage
    street_name_freq_map = train_df.groupby('street_name')['street_name'].count().to_dict()
    violation_type_freq_map = train_df.groupby('violation_type')['violation_type'].count().to_dict()
    # Create a Series of tuples (street_name, violation_type) for pair_freq_map
    pair_freq_series = train_df.groupby(['street_name', 'violation_type']).size()
    pair_freq_map = {idx: val for idx, val in pair_freq_series.items()}


    # --- Prepare data for CatBoost ---
    X = train_df.drop(columns=['violation_count'])
    y = train_df['violation_count']

    # Identify categorical features for CatBoost (before filling NaNs for indices consistency)
    categorical_features_names = [col for col in X.columns if X[col].dtype == 'object']

    # FIX: Fill NaN values in identified categorical features with a placeholder string
    # This must be done on X BEFORE splitting into X_train/X_val
    for col in categorical_features_names:
        if X[col].isnull().any():
            X[col] = X[col].fillna('missing_category').astype(str)
        else:
            # Even if no NaNs, ensure the column is string type for CatBoost if identified as categorical
            X[col] = X[col].astype(str) 
    
    # Convert categorical feature names to indices for CatBoost Pool
    # This must be done AFTER all column operations on X, including fillna and astype,
    # so that the indices correctly reflect the final column order and types.
    categorical_features_indices = [X.columns.get_loc(col) for col in categorical_features_names]

    logging.info(f"Categorical features identified (names): {categorical_features_names}")

    # Split training data for validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    logging.info(f"Training data split into {len(X_train)} training and {len(X_val)} validation samples.")

    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices)

    # --- CatBoost Model Training ---
    logging.info("Starting CatBoost model training...")
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=8,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=100,
        early_stopping_rounds=50,
        l2_leaf_reg=3, # Regularization to prevent overfitting
        thread_count=-1 # Use all available CPU cores
    )

    model.fit(train_pool, eval_set=val_pool, plot=False)
    logging.info("CatBoost model training completed.")

    val_predictions = model.predict(X_val)
    # Ensure predictions are non-negative for RMSE calculation
    val_predictions[val_predictions < 0] = 0
    validation_rmse = rmse(y_val, val_predictions)
    logging.info(f"Final Validation Performance: {validation_rmse}")
    print(f"Final Validation Performance: {validation_rmse}") # Required print for performance parsing

    # --- Prediction on Test Data (if provided) ---
    if args.test_path:
        logging.info(f"Loading test data from: {args.test_path}")
        try:
            test_df = pd.read_csv(args.test_path)
            original_test_df = test_df.copy() # Keep a copy for final output with original column names
            test_df = normalize_column_names(test_df)

            required_test_keys = ['street_name', 'violation_type']
            if not all(col in test_df.columns for col in required_test_keys):
                missing_cols = [col for col in required_test_keys if col not in test_df.columns]
                logging.error(f"Test data is missing required key columns: {missing_cols}. Found: {test_df.columns.tolist()}")
                raise KeyError(f"Missing required key columns in test data: {missing_cols}")

            # Check if violation_count is present in the test set (for evaluation)
            has_ground_truth = 'violation_count' in test_df.columns
            if has_ground_truth:
                y_test_true = test_df['violation_count']
                X_test = test_df.drop(columns=['violation_count'])
                logging.info("Test data loaded with ground truth 'violation_count'.")
            else:
                X_test = test_df.copy()
                logging.info("Test data loaded without ground truth 'violation_count'.")

            # --- Augment test data with same augmentation files (if applicable) ---
            if 'street_attributes.csv' in augmentation_dfs:
                street_attrs_df = augmentation_dfs['street_attributes.csv']
                if 'street_name' in street_attrs_df.columns:
                    # Ensure 'street_name' is string type in X_test before merging
                    X_test['street_name'] = X_test['street_name'].astype(str)
                    # street_attrs_df['street_name'] was already converted to string during its loading
                    
                    X_test = pd.merge(X_test, street_attrs_df, on='street_name', how='left')
                    logging.info("Merged 'street_attributes.csv' with test data on 'street_name'.")
                else:
                    logging.warning("'street_attributes.csv' does not contain 'street_name' for merging with test data. Skipping merge.")

            # --- Feature Engineering for Test Data (consistent with training) ---
            logging.info("Starting feature engineering for test data...")
            X_test['street_name_freq'] = X_test['street_name'].map(street_name_freq_map).fillna(0)
            X_test['violation_type_freq'] = X_test['violation_type'].map(violation_type_freq_map).fillna(0)

            def get_pair_freq_test(row):
                return pair_freq_map.get((row['street_name'], row['violation_type']), 0)
            X_test['pair_freq'] = X_test.apply(get_pair_freq_test, axis=1)

            # Ensure X_test has all the columns from X (training features)
            # and handle NaNs and types consistently with the training data X.
            for col in X.columns: # Iterate through the columns of the fully processed training set X
                if col not in X_test.columns:
                    if col in categorical_features_names:
                        X_test[col] = 'missing_category' # Default for new categorical columns
                    else:
                        X_test[col] = 0 # Default for new numerical columns
            
            # Handle NaNs and ensure types for all features in X_test based on training X's definitions
            for col in X.columns: # Iterate again to ensure type consistency and NaN handling for existing columns too
                if col in categorical_features_names:
                    X_test[col] = X_test[col].fillna('missing_category').astype(str)
                else: # Assume other columns should be numeric based on training data X
                    # Convert to numeric, coercing errors (e.g., non-numeric strings to NaN), then fill NaNs with 0.
                    X_test[col] = pd.to_numeric(X_test[col], errors='coerce').fillna(0)

            # Now, align columns order to match training set
            X_test = X_test[X.columns]

            # Identify unseen key pairs
            train_keys = set(train_df.apply(lambda row: (row['street_name'], row['violation_type']), axis=1))
            test_keys_current = set(X_test.apply(lambda row: (row['street_name'], row['violation_type']), axis=1))
            unseen_keys_in_test = test_keys_current - train_keys
            num_unseen_keys = len(unseen_keys_in_test)
            logging.info(f"Number of (street_name, violation_type) pairs in test set unseen in training: {num_unseen_keys}")
            logging.info(f"These unseen pairs are handled by CatBoost's native categorical feature handling and feature engineering with default values (e.g., 0 for frequencies, 'missing_category' for unseen categories).")

            # Create a Pool for the test data for prediction
            # categorical_features_indices derived from X (training) are directly applicable here
            # because X_test columns are now aligned with X in order and type.
            test_pool = Pool(X_test, cat_features=categorical_features_indices)

            # Predict on the test set
            test_predictions = model.predict(test_pool)
            # Ensure predictions are non-negative
            test_predictions[test_predictions < 0] = 0
            logging.info("Predictions generated for test data.")

            # Create submission DataFrame
            submission_df = pd.DataFrame({
                'street_name': original_test_df['Street Name'], # Use original columns for output as requested
                'violation_type': original_test_df['Violation Description'],
                'predicted_count': test_predictions.round().astype(int) # Round to nearest integer and convert to int
            })
            
            submission_df.to_csv('submission.csv', index=False)
            logging.info("Submission file 'submission.csv' created.")

            if has_ground_truth:
                test_rmse = rmse(y_test_true, test_predictions)
                logging.info(f"RMSE on provided test data: {test_rmse}")
                print(f"RMSE on provided test data: {test_rmse}")

        except FileNotFoundError:
            logging.error(f"Test data file not found at {args.test_path}. Please check the path.")
            return
        except Exception as e:
            logging.error(f"Error processing test data or generating predictions: {e}")
            return
    else:
        logging.info("No test-path provided. Skipping prediction on external test data.")

if __name__ == "__main__":
    main()
