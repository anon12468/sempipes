

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import lightgbm as lgb
import os
import glob
import logging

# Set up logging for better visibility during execution
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Helper function to load data safely ---
def load_data(file_path, df_name="DataFrame"):
    """
    Loads a CSV file into a pandas DataFrame.
    Handles file not found errors and general exceptions during loading.
    """
    if not os.path.exists(file_path):
        logging.warning(f"File not found at {file_path} for {df_name}. Returning empty DataFrame.")
        return pd.DataFrame()
    try:
        df = pd.read_csv(file_path)
        logging.info(f"Successfully loaded {df_name} from {file_path} with {len(df)} rows.")
        return df
    except Exception as e:
        logging.error(f"Error loading {file_path} for {df_name}: {e}. Returning empty DataFrame.")
        return pd.DataFrame()

# Function to load and preprocess data (from original train.py)
def load_and_preprocess_data(filepath, is_train_data=True):
    """
    Loads a CSV file and renames key columns for consistency.
    Ensures 'street_name' and 'violation_type' are present and of string type.
    """
    df = load_data(filepath) # Use safe load_data helper

    if df.empty:
        return df # Return empty if loading failed

    # Ensure consistent column names immediately after loading
    df.rename(columns={
        'Street Name': 'street_name',
        'Violation Description': 'violation_type',
        'Violation Type': 'violation_type',
        'Street': 'street_name'
    }, inplace=True)

    # Ensure key columns are of string type to prevent merging issues
    if 'street_name' in df.columns:
        df['street_name'] = df['street_name'].astype(str)
    else:
        logging.warning(f"Warning: 'street_name' column not found in {filepath} after renaming. Creating placeholder.")
        df['street_name'] = 'UNKNOWN_STREET'

    if 'violation_type' in df.columns:
        df['violation_type'] = df['violation_type'].astype(str)
    else:
        logging.warning(f"Warning: 'violation_type' column not found in {filepath} after renaming. Creating placeholder.")
        df['violation_type'] = 'UNKNOWN_VIOLATION'

    if not is_train_data and 'violation_count' not in df.columns:
        df['violation_count'] = -1

    return df

# Function to load and discover auxiliary data (from original train.py with typo fix)
def load_auxiliary_data(input_dir):
    """
    Discovers and loads all other CSVs in the input directory, standardizing their column names.
    """
    aux_dfs = {}
    all_csv_files = glob.glob(os.path.join(input_dir, '*.csv'))
    
    main_files = ['violations_per_street_2022.csv', 'violations_per_street_2023.csv', 'submission.csv'] 
    
    for f_path in all_csv_files:
        f_name = os.path.basename(f_path)
        if f_name not in main_files:
            try:
                aux_df = pd.read_csv(f_path)
                aux_df.rename(columns={
                    'Street Name': 'street_name',
                    'Violation Description': 'violation_type',
                    'Violation Type': 'violation_type', # Corrected typo from original plan_implement_debug_agent_1
                    'Street': 'street_name'
                }, inplace=True)
                aux_dfs[f_name.replace('.csv', '')] = aux_df
                logging.info(f"Loaded auxiliary data: {f_name}")
            except Exception as e:
                logging.error(f"Could not load or process auxiliary file {f_name}: {e}")
    return aux_dfs

# Function for feature engineering and merging auxiliary data (MODIFIED FOR ABLATION)
def feature_engineer(df, aux_dfs, is_train_data=True, include_street_violation_pair=True, numerical_imputation_strategy='median_for_train_zero_for_test'):
    """
    Applies feature engineering steps and merges auxiliary data.
    Modified to include ablation points.
    """
    if include_street_violation_pair:
        df['street_violation_pair'] = df['street_name'] + '_' + df['violation_type']

    # --- Auxiliary data merging logic (from original train.py, with dummy data fallback) ---
    # Dummy street details (example if not found in aux_dfs)
    if 'street_details' not in aux_dfs:
        logging.info("Creating dummy 'street_details' as no explicit auxiliary file was found.")
        unique_streets = df['street_name'].unique()
        street_details_data = {
            'street_name': unique_streets,
            'street_length_miles': np.random.rand(len(unique_streets)) * 10,
            'num_lanes': np.random.randint(1, 6, len(unique_streets)),
            'is_commercial': np.random.choice([0, 1], len(unique_streets))
        }
        aux_dfs['street_details'] = pd.DataFrame(street_details_data)

    if 'street_details' in aux_dfs:
        street_details_df = aux_dfs['street_details']
        if 'street_name' in street_details_df.columns:
            street_details_df['street_name'] = street_details_df['street_name'].astype(str)
            df = pd.merge(df, street_details_df, on='street_name', how='left')
            logging.info("Merged 'street_details' auxiliary data.")
        else:
            logging.warning("Warning: 'street_name' not found in 'street_details' auxiliary data. Skipping merge.")


    # Dummy violation type details (example if not found in aux_dfs)
    if 'violation_details' not in aux_dfs:
        logging.info("Creating dummy 'violation_details' as no explicit auxiliary file was found.")
        unique_violations = df['violation_type'].unique()
        violation_details_data = {
            'violation_type': unique_violations,
            'severity_score': np.random.randint(1, 10, len(unique_violations)),
            'is_moving_violation': np.random.choice([0, 1], len(unique_violations))
        }
        aux_dfs['violation_details'] = pd.DataFrame(violation_details_data)

    if 'violation_details' in aux_dfs:
        violation_details_df = aux_dfs['violation_details']
        if 'violation_type' in violation_details_df.columns:
            violation_details_df['violation_type'] = violation_details_df['violation_type'].astype(str)
            df = pd.merge(df, violation_details_df, on='violation_type', how='left')
            logging.info("Merged 'violation_details' auxiliary data.")
        else:
            logging.warning("Warning: 'violation_type' not found in 'violation_details' auxiliary data. Skipping merge.")

    # --- Numerical Imputation (Ablation Point 2) ---
    numerical_cols_to_impute = ['street_length_miles', 'num_lanes', 'is_commercial', 'severity_score', 'is_moving_violation']
    for col in numerical_cols_to_impute:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce') # Ensure numeric type
            if df[col].isnull().any():
                fill_value = 0 # Default for 'zero' strategy
                if numerical_imputation_strategy == 'median_for_train_zero_for_test' and is_train_data:
                    fill_value = df[col].median()
                
                df[col].fillna(fill_value, inplace=True)
                
    return df

# --- Main ablation study logic ---
def run_ablation_scenario(scenario_name, train_path,
                           include_street_violation_pair=True,
                           numerical_imputation_strategy='median_for_train_zero_for_test',
                           lgbm_num_leaves=31):
    
    logging.info(f"\n--- Running scenario: {scenario_name} ---")

    train_df = load_and_preprocess_data(train_path, is_train_data=True)
    if train_df.empty:
        logging.error(f"Could not load training data for scenario {scenario_name}. Skipping.")
        return scenario_name, None

    input_directory = os.path.dirname(train_path) if train_path else './input'
    if not os.path.exists(input_directory):
        os.makedirs(input_directory)
        logging.warning(f"Input directory '{input_directory}' created. No auxiliary files found.")
    
    aux_dfs = load_auxiliary_data(input_directory)

    # Feature engineer training data with scenario-specific parameters
    train_df_fe = feature_engineer(train_df.copy(), aux_dfs, is_train_data=True,
                                   include_street_violation_pair=include_street_violation_pair,
                                   numerical_imputation_strategy=numerical_imputation_strategy)

    target = 'violation_count'
    
    # Dynamically adjust features based on whether 'street_violation_pair' is included
    features = [col for col in train_df_fe.columns if col not in [target, 'street_name', 'violation_type']]
    if not include_street_violation_pair and 'street_violation_pair' in features:
        features.remove('street_violation_pair')

    categorical_features = [col for col in features if train_df_fe[col].dtype == 'object' or col == 'street_violation_pair']
    if not include_street_violation_pair and 'street_violation_pair' in categorical_features:
        categorical_features.remove('street_violation_pair')


    for col in categorical_features:
        if col in train_df_fe.columns:
            train_df_fe[col] = train_df_fe[col].astype('category')
        else:
            logging.warning(f"Categorical feature '{col}' not found in train_df_fe during type conversion for scenario {scenario_name}.")

    X = train_df_fe[features]
    y = train_df_fe[target]

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    model = lgb.LGBMRegressor(random_state=42, n_estimators=1000, learning_rate=0.05, num_leaves=lgbm_num_leaves, n_jobs=-1)
    
    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=False)],
              categorical_feature=[f for f in categorical_features if f in X_train.columns]
             )

    val_preds = model.predict(X_val)
    val_preds[val_preds < 0] = 0
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    logging.info(f"Scenario '{scenario_name}' Validation RMSE: {val_rmse}")
    return scenario_name, val_rmse

def main_ablation_study():
    train_path = './input/violations_per_street_2022.csv'
    
    # Ensure the input directory exists for dummy data generation
    input_directory = './input'
    if not os.path.exists(input_directory):
        os.makedirs(input_directory)
        logging.info(f"Created input directory: {input_directory}")
    
    # Create a dummy violations_per_street_2022.csv if it doesn't exist for testing the script
    if not os.path.exists(train_path):
        logging.warning(f"Dummy training data '{train_path}' not found. Creating a minimal dummy file.")
        dummy_data = {
            'Street Name': ['MAIN ST', 'OAK AVE', 'MAIN ST', 'ELM ST', 'OAK AVE', 'PINE RD'],
            'Violation Description': ['PARKING METER', 'NO PARKING', 'SPEEDING', 'PARKING METER', 'NO PARKING', 'DOUBLE PARKING'],
            'violation_count': [100, 50, 200, 120, 60, 150]
        }
        pd.DataFrame(dummy_data).to_csv(train_path, index=False)
    
    results = {}

    # Baseline Scenario
    _, baseline_rmse = run_ablation_scenario("Baseline (All features, default imputation, num_leaves=31)", train_path)
    results["Baseline"] = baseline_rmse

    # Ablation 1: Remove `street_violation_pair` (Interaction Feature)
    _, rmse_no_interaction = run_ablation_scenario("Ablation 1: No 'street_violation_pair' feature", train_path,
                                                  include_street_violation_pair=False)
    results["No 'street_violation_pair'"] = rmse_no_interaction

    # Ablation 2: Simplify numerical imputation (always 0, no median for train)
    _, rmse_zero_imputation = run_ablation_scenario("Ablation 2: Numerical imputation always 0", train_path,
                                                   numerical_imputation_strategy='always_zero')
    results["Numerical imputation always 0"] = rmse_zero_imputation

    # Ablation 3: Reduce `num_leaves` for LightGBM (e.g., to 7)
    _, rmse_lgbm_num_leaves_7 = run_ablation_scenario("Ablation 3: LightGBM num_leaves=7", train_path,
                                                      lgbm_num_leaves=7)
    results["LightGBM num_leaves=7"] = rmse_lgbm_num_leaves_7

    print("\n--- Ablation Study Results ---")
    for scenario, rmse in results.items():
        if rmse is not None:
            print(f"{scenario}: RMSE = {rmse:.4f}")
        else:
            print(f"{scenario}: Failed to compute RMSE.")

    # Determine the most impactful part
    if baseline_rmse is not None:
        impacts = {}
        # Store original component name, its ablated RMSE, and difference from baseline
        if results["No 'street_violation_pair'"] is not None:
            impacts["'street_violation_pair' feature"] = {
                'rmse': results["No 'street_violation_pair'"],
                'diff': results["No 'street_violation_pair'"] - baseline_rmse
            }
        if results["Numerical imputation always 0"] is not None:
            impacts["numerical imputation strategy (median for train, zero for test)"] = {
                'rmse': results["Numerical imputation always 0"],
                'diff': results["Numerical imputation always 0"] - baseline_rmse
            }
        if results["LightGBM num_leaves=7"] is not None:
            impacts["LightGBM 'num_leaves' parameter (value 31)"] = {
                'rmse': results["LightGBM num_leaves=7"],
                'diff': results["LightGBM num_leaves=7"] - baseline_rmse
            }
        
        if impacts:
            # Find the component with the largest absolute difference
            most_impactful_component = max(impacts, key=lambda k: abs(impacts[k]['diff']))
            impact_details = impacts[most_impactful_component]
            
            absolute_change = abs(impact_details['diff'])
            
            contribution_type = ""
            if impact_details['diff'] > 0:
                contribution_type = "positive (its presence improved performance by avoiding an RMSE increase)"
            elif impact_details['diff'] < 0:
                contribution_type = "negative (its presence degraded performance, and its removal/modification improved RMSE)"
            else:
                contribution_type = "neutral (no measurable impact)"

            print(f"\nConclusion: The part of the code that contributed the most to the overall performance (i.e., had the largest absolute impact on RMSE) is: '{most_impactful_component}'.")
            print(f"Ablating/modifying this component resulted in a change of {impact_details['diff']:.4f} in RMSE (absolute change: {absolute_change:.4f}).")
            print(f"This indicates the original configuration of '{most_impactful_component}' had a {contribution_type}.")
        else:
            print("\nConclusion: No impacts could be calculated, likely due to errors in ablation runs.")
    else:
        print("\nConclusion: Baseline RMSE could not be computed, cannot determine most impactful part.")


if __name__ == '__main__':
    main_ablation_study()

