
import pandas as pd
import numpy as np
import argparse
import os
import glob
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Helper functions ---
def load_data(file_path):
    """Loads a CSV file and renames core columns if they exist."""
    try:
        df = pd.read_csv(file_path)
        logging.info(f"Successfully loaded data from {file_path}. Shape: {df.shape}")

        # Rename columns for consistency
        if 'Street Name' in df.columns:
            df.rename(columns={'Street Name': 'street_name'}, inplace=True)
        if 'Violation Description' in df.columns:
            df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
        # Ensure 'violation_count' is always named consistently, no change if already correct
        if 'violation_count' in df.columns:
            df.rename(columns={'violation_count': 'violation_count'}, inplace=True)
        logging.info(f"Columns after renaming: {df.columns.tolist()}")
        return df
    except FileNotFoundError:
        logging.error(f"File not found: {file_path}")
        raise
    except Exception as e:
        logging.error(f"Error loading data from {file_path}: {e}")
        raise

def add_auxiliary_features(df, input_dir):
    """
    Loads and merges auxiliary data from the input directory.
    Identifies common keys for merging and performs aggregations.
    """
    logging.info("Starting auxiliary feature engineering.")
    original_shape_cols = df.shape[1]

    # Discover and load all other CSVs in the input directory
    aux_files = glob.glob(os.path.join(input_dir, "*.csv"))
    # Exclude the main training data file itself from auxiliary files
    main_train_file_name = os.path.basename(os.path.abspath(args.train_path))
    aux_files = [f for f in aux_files if os.path.basename(f) != main_train_file_name]

    for aux_file in aux_files:
        try:
            aux_df = pd.read_csv(aux_file)
            aux_name = os.path.basename(aux_file).replace('.csv', '')
            logging.info(f"Loading auxiliary file: {aux_name}. Shape: {aux_df.shape}")

            # General approach to merging: try common keys
            merge_key = None
            if 'street_name' in df.columns and 'Street Name' in aux_df.columns:
                aux_df.rename(columns={'Street Name': 'street_name'}, inplace=True)
                merge_key = 'street_name'
            elif 'violation_type' in df.columns and 'Violation Description' in aux_df.columns:
                aux_df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
                merge_key = 'violation_type'
            elif 'violation_type' in df.columns and 'Violation Type' in aux_df.columns:
                 aux_df.rename(columns={'Violation Type': 'violation_type'}, inplace=True)
                 merge_key = 'violation_type'
            # Add more specific logic for known aux files if needed, ensuring string types for merging
            elif 'Violation Code' in aux_df.columns and 'violation_type' in df.columns:
                # Attempt to convert to string for robust merging on violation code/type
                df['violation_type_str_temp'] = df['violation_type'].astype(str)
                aux_df['Violation Code_str_temp'] = aux_df['Violation Code'].astype(str)
                if 'Violation Code_str_temp' in aux_df.columns and 'violation_type_str_temp' in df.columns:
                    # Drop original Violation Code from aux_df if it clashes with another column
                    if 'violation_type' in aux_df.columns and 'violation_type' != 'Violation Code':
                        aux_df.drop(columns=['violation_type'], inplace=True, errors='ignore')
                    
                    df = pd.merge(df, aux_df.drop_duplicates(subset=['Violation Code_str_temp']),
                                  left_on='violation_type_str_temp', right_on='Violation Code_str_temp',
                                  how='left', suffixes=('', f'_{aux_name}'))
                    df.drop(columns=['violation_type_str_temp'], inplace=True)
                    # Clean up temp column from aux_df before next merge iteration if it was used
                    aux_df.drop(columns=['Violation Code_str_temp'], inplace=True)
                    continue # Skip the generic merge below as this was a specific merge
            
            if merge_key and merge_key in df.columns and merge_key in aux_df.columns:
                # Drop duplicate columns from aux_df that are already in df, except the merge_key
                cols_to_drop = [col for col in aux_df.columns if col in df.columns and col != merge_key]
                if cols_to_drop:
                    logging.info(f"Dropping duplicate columns from {aux_name} before merge: {cols_to_drop}")
                    aux_df.drop(columns=cols_to_drop, inplace=True)
                
                # Ensure the merge key has consistent type for merging (e.g., string)
                df[merge_key] = df[merge_key].astype(str)
                aux_df[merge_key] = aux_df[merge_key].astype(str)

                # Merge and handle potential suffix if a column name clashes
                df = pd.merge(df, aux_df.drop_duplicates(subset=[merge_key]), on=merge_key, how='left', suffixes=('', f'_{aux_name}'))
                logging.info(f"Merged with {aux_name} on {merge_key}. New shape: {df.shape}")
            else:
                logging.warning(f"Could not find a suitable common merge key or keys missing for {aux_name}. Skipping merge for this file.")

        except Exception as e:
            logging.error(f"Error processing auxiliary file {aux_file}: {e}")
            continue

    # Add aggregated features from the main dataset
    logging.info("Adding aggregated features from main dataset.")
    if 'violation_count' in df.columns: # Only proceed if target column exists
        if 'street_name' in df.columns:
            street_agg = df.groupby('street_name')['violation_count'].agg(['mean', 'median', 'std', 'max', 'min']).add_prefix('street_').reset_index()
            df = pd.merge(df, street_agg, on='street_name', how='left')
        if 'violation_type' in df.columns:
            violation_agg = df.groupby('violation_type')['violation_count'].agg(['mean', 'median', 'std', 'max', 'min']).add_prefix('violation_type_').reset_index()
            df = pd.merge(df, violation_agg, on='violation_type', how='left')
    else:
        logging.warning("Skipping aggregation features as 'violation_count' column is not available in the dataframe.")


    logging.info(f"Finished auxiliary feature engineering. Added {df.shape[1] - original_shape_cols} new features.")
    return df

def preprocess_features(train_df, test_df=None):
    """
    Identifies categorical and numerical features, handles NaNs, and applies encoding.
    Ensures consistent feature sets between train and test.
    """
    logging.info("Starting feature preprocessing.")

    # Identify categorical and numerical features
    # Start with core features, then add others
    categorical_features = []
    if 'street_name' in train_df.columns: categorical_features.append('street_name')
    if 'violation_type' in train_df.columns: categorical_features.append('violation_type')

    # Dynamically find other categorical features
    for col in train_df.columns:
        if train_df[col].dtype == 'object' or pd.api.types.is_categorical_dtype(train_df[col]):
            if col not in categorical_features and col != 'violation_count':
                categorical_features.append(col)

    numeric_features = [col for col in train_df.columns if pd.api.types.is_numeric_dtype(train_df[col]) and col != 'violation_count']

    # Handle NaNs in numeric features (using median from training data)
    logging.info("Handling NaNs in numeric features.")
    for col in numeric_features:
        if train_df[col].isnull().any():
            median_val = train_df[col].median()
            train_df[col].fillna(median_val, inplace=True)
            if test_df is not None and col in test_df.columns:
                test_df[col].fillna(median_val, inplace=True)
        # Specifically handle cases where std might be NaN from aggregations (e.g., single-item groups)
        if 'std' in col and train_df[col].isnull().any():
            train_df[col].fillna(0, inplace=True)
            if test_df is not None and col in test_df.columns:
                test_df[col].fillna(0, inplace=True)


    # Handle NaNs in categorical features and encode
    logging.info("Handling NaNs and encoding categorical features.")
    for col in categorical_features:
        # Fill NaN with a placeholder string for consistency
        train_df[col] = train_df[col].fillna('UNKNOWN_CATEGORY').astype(str)
        if test_df is not None and col in test_df.columns:
            test_df[col] = test_df[col].fillna('UNKNOWN_CATEGORY').astype(str)
        elif test_df is not None: # If column missing in test, add it and fill
            test_df[col] = 'UNKNOWN_CATEGORY'

        # Create a combined set of unique categories for consistent mapping
        all_categories = pd.concat([train_df[col], test_df[col] if test_df is not None else pd.Series([])]).unique()
        # Add 'UNKNOWN_CATEGORY' explicitly if not present to ensure it gets an ID
        if 'UNKNOWN_CATEGORY' not in all_categories:
            all_categories = np.append(all_categories, 'UNKNOWN_CATEGORY')

        category_map = {cat: i for i, cat in enumerate(all_categories)}
        
        train_df[col] = train_df[col].map(category_map).fillna(category_map['UNKNOWN_CATEGORY']).astype(int)
        if test_df is not None and col in test_df.columns:
            test_df[col] = test_df[col].map(category_map).fillna(category_map['UNKNOWN_CATEGORY']).astype(int)
        elif test_df is not None: # If column was added to test_df, map it
            test_df[col] = test_df[col].map(category_map).fillna(category_map['UNKNOWN_CATEGORY']).astype(int)

    # Align columns between train and test
    if test_df is not None:
        train_cols_for_features = [col for col in train_df.columns if col != 'violation_count']
        test_cols_for_features = [col for col in test_df.columns if col != 'violation_count']

        missing_in_test = set(train_cols_for_features) - set(test_cols_for_features)
        for col in missing_in_test:
            if pd.api.types.is_numeric_dtype(train_df[col]):
                # Fill with median from training data for numeric features
                median_val = train_df[col].median()
                test_df[col] = median_val
                logging.info(f"Added missing numeric feature '{col}' to test_df, filled with median: {median_val}")
            elif col in categorical_features: # Must be a categorical feature (encoded to int)
                # Use the ID for 'UNKNOWN_CATEGORY' from the map
                test_df[col] = category_map.get('UNKNOWN_CATEGORY', -1) # Default to -1 if somehow not in map
                logging.info(f"Added missing categorical feature '{col}' to test_df, filled with UNKNOWN_CATEGORY ID.")
            else:
                # Fallback for other types, e.g., boolean or unexpected
                test_df[col] = train_df[col].mode()[0] if not train_df[col].empty else None # Or a reasonable default
                logging.warning(f"Added missing feature '{col}' to test_df with mode/default value.")


        extra_in_test = set(test_cols_for_features) - set(train_cols_for_features)
        if extra_in_test:
            test_df.drop(columns=list(extra_in_test), inplace=True)
            logging.info(f"Dropped extra features from test_df not in train: {list(extra_in_test)}")

        # Ensure order of columns is the same for CatBoost
        test_df = test_df[[col for col in train_cols_for_features if col in test_df.columns]]
        logging.info("Aligned train and test feature columns.")

    logging.info("Finished feature preprocessing.")
    return train_df, test_df, categorical_features, numeric_features


def train_predict_model(train_path, test_path, input_dir):
    """Main function to load data, train model, predict, and evaluate."""
    logging.info(f"Starting model training and prediction pipeline. Train path: {train_path}")

    # 1. Load Data
    train_df = load_data(train_path)

    # Store original keys for test data submission
    test_original_keys = None
    test_ground_truth = None

    test_df = None
    if test_path:
        test_df = load_data(test_path)
        test_original_keys = test_df[['street_name', 'violation_type']].copy()
        if 'violation_count' in test_df.columns:
            test_ground_truth = test_df['violation_count'].copy()
            logging.info("Test file contains 'violation_count' for scoring.")
        else:
            logging.info("Test file does not contain 'violation_count' for scoring.")
    else:
        logging.info("No test path provided. Will only perform development validation.")

    # 2. Feature Engineering
    # Create copies to prevent unintended modifications during feature engineering
    train_df_fe = add_auxiliary_features(train_df.copy(), input_dir)
    test_df_fe = add_auxiliary_features(test_df.copy(), input_dir) if test_df is not None else None

    # Handle `violation_count` potentially becoming NaN due to merges if not in original table.
    if 'violation_count' in train_df_fe.columns and train_df_fe['violation_count'].isnull().any():
        logging.warning("NaNs found in 'violation_count' after feature engineering in train_df. Dropping rows with NaN target.")
        train_df_fe.dropna(subset=['violation_count'], inplace=True)
    elif 'violation_count' not in train_df_fe.columns:
         logging.critical("Training data must contain 'violation_count' column. Exiting.")
         raise ValueError("Missing 'violation_count' in training data.")


    # 3. Preprocess Features (NaN handling, encoding, aligning)
    train_df_processed, test_df_processed, categorical_features, numeric_features = preprocess_features(
        train_df_fe.copy(), test_df_fe.copy()
    )

    # Define features and target
    target = 'violation_count'
    features = [col for col in train_df_processed.columns if col != target]

    # Filter `categorical_features` to only include those present in `features`
    # and ensure they are of integer type for CatBoost
    cat_features_for_model = [col for col in categorical_features if col in features]
    for col in cat_features_for_model:
        if col in train_df_processed.columns:
            train_df_processed[col] = train_df_processed[col].astype(int)
        if test_df_processed is not None and col in test_df_processed.columns:
            test_df_processed[col] = test_df_processed[col].astype(int)

    # 4. Model Training (Development Validation)
    X = train_df_processed[features]
    y = train_df_processed[target]

    # Use a simple random split for validation from 2022 data.
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    logging.info(f"Training data split: Train {X_train.shape}, Validation {X_val.shape}")

    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=8,
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Set to 0 to suppress console output during training
        early_stopping_rounds=50,
        cat_features=cat_features_for_model
    )

    logging.info("Training CatBoost model...")
    # Use Pool for better CatBoost handling of categorical features and verbose callback
    train_pool = Pool(X_train, y_train, cat_features=cat_features_for_model)
    val_pool = Pool(X_val, y_val, cat_features=cat_features_for_model)
    
    model.fit(train_pool, eval_set=val_pool, verbose=False)

    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds.clip(min=0).round()))
    logging.info(f"Development Validation RMSE: {val_rmse:.4f}")
    print(f"Final Validation Performance: {val_rmse:.4f}")


    # 5. Prediction for Test File
    if test_df_processed is not None:
        logging.info("Generating predictions for the test file.")
        
        # Ensure test_df_processed has the same columns and order as X_train
        # This was already handled in preprocess_features, but a final check for robustness
        test_df_for_prediction = test_df_processed[features]

        test_preds = model.predict(test_df_for_prediction)
        test_preds = test_preds.clip(min=0).round().astype(int)

        submission_df = test_original_keys.copy()
        submission_df['predicted_count'] = test_preds

        # Save submission file
        submission_df.to_csv('submission.csv', index=False)
        logging.info("Submission file 'submission.csv' generated.")

        # Evaluate if ground truth is available
        if test_ground_truth is not None:
            test_rmse = np.sqrt(mean_squared_error(test_ground_truth, test_preds))
            logging.info(f"Test Set RMSE: {test_rmse:.4f}")

            # Report unseen key pairs in test set
            train_keys = train_df[['street_name', 'violation_type']].drop_duplicates()
            test_keys = test_original_keys.drop_duplicates()

            # Merge to find which test keys are not in train keys
            merged_keys = pd.merge(test_keys.assign(in_test=1), train_keys.assign(in_train=1),
                                   on=['street_name', 'violation_type'], how='left')
            unseen_pairs_count = merged_keys[merged_keys['in_train'].isnull()].shape[0]
            logging.info(f"Number of (street_name, violation_type) pairs in test set unseen in training: {unseen_pairs_count}")
            logging.info(f"These unseen pairs were handled by CatBoost's internal mechanisms for new categories and feature alignment logic.")
    else:
        logging.info("No test file provided, skipping prediction and submission generation.")

    logging.info("Pipeline finished.")


# --- Main execution block ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Predict NYC parking violations for 2023.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional path to the 2023 test data CSV for prediction and evaluation.')
    parser.add_argument('--input-dir', type=str, default='./input',
                        help='Directory containing auxiliary data files.')

    args = parser.parse_args()

    # Create dummy auxiliary files for testing if they don't exist
    input_dir = args.input_dir
    os.makedirs(input_dir, exist_ok=True)

    # Dummy train file (if not present)
    if not os.path.exists(args.train_path):
        logging.warning(f"Training file {args.train_path} not found. Creating a dummy one.")
        dummy_train_data = {
            'Street Name': ['MAIN ST', 'ELM ST', 'OAK AVE', 'MAIN ST', 'ELM ST', 'MAPLE DR', 'ELM ST'],
            'Violation Description': ['PARKING METER', 'NO PARKING', 'OVERTIME PARKING', 'DOUBLE PARKING', 'PARKING METER', 'NO STANDING', 'NO PARKING'],
            'violation_count': [100, 50, 75, 120, 60, 30, 55]
        }
        pd.DataFrame(dummy_train_data).to_csv(args.train_path, index=False)
        
    # Dummy test file (if test-path is provided and file not present)
    if args.test_path and not os.path.exists(args.test_path):
        logging.warning(f"Test file {args.test_path} not found. Creating a dummy one.")
        dummy_test_data = {
            'Street Name': ['MAIN ST', 'NEW BLVD', 'ELM ST', 'BROADWAY'],
            'Violation Description': ['PARKING METER', 'NO PARKING', 'NO STANDING', 'TRUCK PARKING'],
            'violation_count': [110, 45, 35, 20] # Optional ground truth
        }
        pd.DataFrame(dummy_test_data).to_csv(args.test_path, index=False)


    # Dummy auxiliary files
    aux_files_to_create = {
        'violation_codes.csv': pd.DataFrame({
            'Violation Description': ['PARKING METER', 'NO PARKING', 'OVERTIME PARKING', 'DOUBLE PARKING', 'NO STANDING', 'FIRE HYDRANT'],
            'Violation Category': ['Meter', 'Prohibited', 'Time Limit', 'Prohibited', 'Prohibited', 'Safety'],
            'Severity': [3, 5, 4, 5, 4, 5]
        }),
        'street_attributes.csv': pd.DataFrame({
            'Street Name': ['MAIN ST', 'ELM ST', 'OAK AVE', 'MAPLE DR', 'NEW BLVD'],
            'Borough': ['Manhattan', 'Brooklyn', 'Queens', 'Bronx', 'Manhattan'],
            'Zip Code': [10001, 11201, 11101, 10451, 10010],
            'Street Length': [1.5, 2.1, 0.8, 1.2, 0.7]
        }),
        # Another potential auxiliary table that might have a different name for Violation Description
        'violation_types_details.csv': pd.DataFrame({
            'Violation Type': ['PARKING METER', 'NO PARKING', 'OVERTIME PARKING', 'TRUCK PARKING'],
            'Fine Amount': [65, 115, 80, 100]
        })
    }

    for fname, df_content in aux_files_to_create.items():
        fpath = os.path.join(input_dir, fname)
        if not os.path.exists(fpath):
            logging.warning(f"Auxiliary file {fpath} not found. Creating a dummy one.")
            df_content.to_csv(fpath, index=False)

    try:
        train_predict_model(args.train_path, args.test_path, args.input_dir)
    except Exception as e:
        logging.critical(f"An unhandled error occurred during pipeline execution: {e}", exc_info=True)

