
import pandas as pd
import numpy as np
import argparse
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor
import os
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def rmse(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))

class ParkingViolationPredictor:
    def __init__(self, data_dir="./input"):
        self.data_dir = data_dir
        self.model = None
        self.categorical_features = []
        self.numerical_features = []
        self.features = [] # Combined list of features used by the model
        self.target = 'violation_count'
        self.training_keys = set() # To store (street_name, violation_type) from training data

    def _load_data(self, file_path):
        """Loads data from a CSV file and standardizes column names."""
        logging.info(f"Loading data from {file_path}")
        df = pd.read_csv(file_path)
        
        # Standardize column names for consistency
        df.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type',
            self.target: self.target # Ensure target column name is consistent
        }, inplace=True)

        # Handle cases where target column might be missing in test/eval files
        if self.target not in df.columns:
            logging.warning(f"Target column '{self.target}' not found in {file_path}. Setting to 0 for consistency.")
            df[self.target] = 0 # Placeholder for prediction or to prevent errors
        
        # Ensure street_name and violation_type are object/category types for CatBoost
        df['street_name'] = df['street_name'].astype('category')
        df['violation_type'] = df['violation_type'].astype('category')

        return df

    def _add_auxiliary_features(self, df, is_training=True):
        """Adds auxiliary features by merging with external datasets."""
        logging.info("Adding auxiliary features...")

        # Load auxiliary data and merge
        # nyc_census_demographics.csv
        try:
            census_df = pd.read_csv(os.path.join(self.data_dir, 'nyc_census_demographics.csv'))
            census_df.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, census_df, on='street_name', how='left')
            logging.info("Merged with nyc_census_demographics.csv (population, median_income)")
        except FileNotFoundError:
            logging.warning("nyc_census_demographics.csv not found, skipping merge.")
        
        # violation_codes.csv - Fix for 'KeyError: 'violation_type'' is handled here by ensuring
        # 'Violation Description' is already renamed to 'violation_type' in the main DF by _load_data,
        # and then aligning 'Description' from violation_codes_df to 'violation_type' for merging.
        try:
            violation_codes_df = pd.read_csv(os.path.join(self.data_dir, 'violation_codes.csv'))
            # Assume 'Description' in violation_codes.csv maps to 'violation_type'
            if 'Description' in violation_codes_df.columns:
                violation_codes_df.rename(columns={'Description': 'violation_type'}, inplace=True)
                # Select relevant columns for merge
                merge_cols = ['violation_type']
                if 'Fine Amount' in violation_codes_df.columns:
                    violation_codes_df.rename(columns={'Fine Amount': 'fine_amount'}, inplace=True)
                    merge_cols.append('fine_amount')
                
                df = pd.merge(df, violation_codes_df[merge_cols], on='violation_type', how='left', suffixes=('', '_code'))
                logging.info("Merged with violation_codes.csv (fine_amount)")
            else:
                logging.warning("violation_codes.csv does not have a 'Description' column for merging with 'violation_type'. Skipping.")
        except FileNotFoundError:
            logging.warning("violation_codes.csv not found, skipping merge.")

        # parking_meter_locations.csv
        try:
            meter_df = pd.read_csv(os.path.join(self.data_dir, 'parking_meter_locations.csv'))
            meter_df.rename(columns={'Street Name': 'street_name'}, inplace=True)
            meter_counts = meter_df.groupby('street_name').size().reset_index(name='num_parking_meters')
            df = pd.merge(df, meter_counts, on='street_name', how='left')
            logging.info("Merged with parking_meter_locations.csv (num_parking_meters)")
        except FileNotFoundError:
            logging.warning("parking_meter_locations.csv not found, skipping merge.")

        # traffic_patterns.csv (example augmentation)
        try:
            traffic_df = pd.read_csv(os.path.join(self.data_dir, 'traffic_patterns.csv'))
            traffic_df.rename(columns={'Street Name': 'street_name', 'Average Daily Traffic': 'avg_daily_traffic'}, inplace=True)
            df = pd.merge(df, traffic_df[['street_name', 'avg_daily_traffic']], on='street_name', how='left')
            logging.info("Merged with traffic_patterns.csv (avg_daily_traffic)")
        except FileNotFoundError:
            logging.warning("traffic_patterns.csv not found, skipping merge.")

        # Define features based on available columns
        current_categorical_features = ['street_name', 'violation_type']
        current_numerical_features = [
            'population', 'median_income', 'num_parking_meters', 'fine_amount', 'avg_daily_traffic'
        ]

        if is_training:
            self.categorical_features = [f for f in current_categorical_features if f in df.columns]
            self.numerical_features = [f for f in current_numerical_features if f in df.columns]
            self.features = self.categorical_features + self.numerical_features
        else:
            # For prediction, ensure test/eval data has all the features the model was trained on
            for col in self.categorical_features:
                if col not in df.columns:
                    df[col] = 'UNKNOWN_CATEGORY' # Handle missing categorical columns in test
                df[col] = df[col].astype('category') # Ensure consistent type
            for col in self.numerical_features:
                if col not in df.columns:
                    df[col] = 0 # Fill missing numerical columns with a default
                df[col] = df[col].fillna(0) # Fill NaNs for numerical features

        # Fill any remaining NaNs for numerical columns for both train/test
        for col in self.numerical_features:
            if col in df.columns:
                df[col] = df[col].fillna(0)

        logging.info(f"Features selected for model: Categorical: {self.categorical_features}, Numerical: {self.numerical_features}")
        return df

    def train(self, train_file_path, eval_ratio=0.2):
        """Trains the CatBoost model."""
        df_train = self._load_data(train_file_path)
        df_train = self._add_auxiliary_features(df_train, is_training=True)

        # Store training keys for unseen handling during prediction
        self.training_keys = set(zip(df_train['street_name'].values, df_train['violation_type'].values))

        X = df_train[self.features]
        y = df_train[self.target]
        
        # Determine CatBoost categorical feature indices
        cat_feature_indices = [X.columns.get_loc(col) for col in self.categorical_features if col in X.columns]

        X_train, X_eval, y_train, y_eval = train_test_split(X, y, test_size=eval_ratio, random_state=42)

        logging.info(f"Training data shape: {X_train.shape}, Eval data shape: {X_eval.shape}")

        self.model = CatBoostRegressor(
            iterations=1000,
            learning_rate=0.05,
            depth=10,
            loss_function='RMSE',
            eval_metric='RMSE',
            random_seed=42,
            verbose=100,
            early_stopping_rounds=50,
            cat_features=cat_feature_indices
        )

        self.model.fit(X_train, y_train, eval_set=(X_eval, y_eval), early_stopping_rounds=50, verbose=100)

        val_preds = self.model.predict(X_eval)
        val_rmse = rmse(y_eval, val_preds)
        logging.info(f"Development Validation RMSE: {val_rmse:.4f}")
        print(f"Final Validation Performance: {val_rmse:.4f}")

    def predict(self, test_file_path=None):
        """Generates predictions for the test data."""
        if self.model is None:
            raise RuntimeError("Model has not been trained yet. Call .train() first.")

        if not test_file_path:
            logging.warning("No test_file_path provided for prediction. Skipping prediction step.")
            return

        df_test = self._load_data(test_file_path)
        # Keep a copy of original columns for output and potential scoring
        original_test_df = df_test[['street_name', 'violation_type', self.target]].copy() 
        df_test = self._add_auxiliary_features(df_test, is_training=False)

        # Handle unseen keys (street_name, violation_type)
        unseen_pairs_count = 0
        for index, row in df_test.iterrows():
            key = (row['street_name'], row['violation_type'])
            if key not in self.training_keys:
                unseen_pairs_count += 1
        
        logging.info(f"Found {unseen_pairs_count} unseen (street_name, violation_type) pairs in test/eval set out of {len(df_test)}.")
        print(f"Number of unseen (street_name, violation_type) pairs in test/eval set: {unseen_pairs_count} out of {len(df_test)}.")

        # Prepare for prediction
        X_test = df_test[self.features]

        predictions = self.model.predict(X_test)
        predictions[predictions < 0] = 0 # Ensure non-negative predictions

        # Prepare submission
        submission_df = original_test_df[['street_name', 'violation_type']].copy()
        submission_df['predicted_count'] = predictions.round().astype(int)

        output_path = 'submission.csv'
        submission_df.to_csv(output_path, index=False)
        logging.info(f"Predictions saved to {output_path}")

        # If violation_count is present in the test file and not all zeros, calculate RMSE
        if self.target in original_test_df.columns and original_test_df[self.target].sum() > 0:
            actual_counts = original_test_df[self.target]
            test_rmse = rmse(actual_counts, predictions)
            logging.info(f"RMSE on provided test/eval set: {test_rmse:.4f}")
            print(f"RMSE on provided test/eval set: {test_rmse:.4f}")

        return submission_df

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help="Path to the 2022 training data CSV.")
    parser.add_argument('--test-path', type=str, default=None,
                        help="Optional path to the test/evaluation data CSV for prediction.")
    parser.add_argument('--data-dir', type=str, default='./input',
                        help="Directory containing auxiliary data files.")

    args = parser.parse_args()

    # Ensure input directory exists, create dummy files if not for local testing
    if not os.path.exists(args.data_dir):
        logging.error(f"Data directory '{args.data_dir}' not found. Creating dummy files for local testing.")
        os.makedirs(args.data_dir, exist_ok=True)
        
        # Create dummy violations_per_street_2022.csv
        dummy_train_data = {
            'Street Name': ['MAIN ST', 'ELM AVE', 'OAK BLVD', 'MAIN ST', 'ELM AVE', 'MAPLE DR'],
            'Violation Description': ['PARKING METER EXPIRED', 'NO PARKING', 'DOUBLE PARKING', 'STOPPING - STANDING', 'PARKING METER EXPIRED', 'NO STANDING'],
            'violation_count': [100, 50, 20, 80, 40, 15]
        }
        pd.DataFrame(dummy_train_data).to_csv(os.path.join(args.data_dir, 'violations_per_street_2022.csv'), index=False)

        # Create dummy violation_codes.csv
        dummy_violation_codes = {
            'Violation Code': [1, 2, 3, 4, 5, 6],
            'Description': ['PARKING METER EXPIRED', 'NO PARKING', 'DOUBLE PARKING', 'STOPPING - STANDING', 'NO STANDING', 'CROSSWALK'],
            'Fine Amount': [65, 115, 115, 115, 115, 115]
        }
        pd.DataFrame(dummy_violation_codes).to_csv(os.path.join(args.data_dir, 'violation_codes.csv'), index=False)

        # Create dummy nyc_census_demographics.csv
        dummy_census_data = {
            'Street Name': ['MAIN ST', 'ELM AVE', 'OAK BLVD', 'MAPLE DR', 'PINE ST'],
            'population': [5000, 3000, 1500, 2000, 1000],
            'median_income': [75000, 60000, 45000, 55000, 40000]
        }
        pd.DataFrame(dummy_census_data).to_csv(os.path.join(args.data_dir, 'nyc_census_demographics.csv'), index=False)

        # Create dummy parking_meter_locations.csv
        dummy_meter_data = {
            'Street Name': ['MAIN ST', 'MAIN ST', 'ELM AVE', 'OAK BLVD', 'MAIN ST'],
            'Location': ['loc1', 'loc2', 'loc3', 'loc4', 'loc5']
        }
        pd.DataFrame(dummy_meter_data).to_csv(os.path.join(args.data_dir, 'parking_meter_locations.csv'), index=False)

        # Create dummy traffic_patterns.csv
        dummy_traffic_data = {
            'Street Name': ['MAIN ST', 'ELM AVE', 'OAK BLVD', 'MAPLE DR'],
            'Average Daily Traffic': [10000, 5000, 2000, 3000]
        }
        pd.DataFrame(dummy_traffic_data).to_csv(os.path.join(args.data_dir, 'traffic_patterns.csv'), index=False)

        # Create a dummy test file for demonstration
        dummy_test_data = {
            'Street Name': ['MAIN ST', 'PINE ST', 'ELM AVE', 'NEW ST', 'OAK BLVD'],
            'Violation Description': ['PARKING METER EXPIRED', 'NO PARKING', 'DOUBLE PARKING', 'JAYWALKING', 'PARKING METER EXPIRED'],
            'violation_count': [110, 60, 25, 0, 45] # 0 for JAYWALKING as it might be unseen, and a new street
        }
        pd.DataFrame(dummy_test_data).to_csv(os.path.join(args.data_dir, 'violations_per_street_2023_test.csv'), index=False)
        
        # Set test path to dummy if it wasn't provided
        if not args.test_path: 
            args.test_path = os.path.join(args.data_dir, 'violations_per_street_2023_test.csv')


    predictor = ParkingViolationPredictor(data_dir=args.data_dir)
    predictor.train(args.train_path)

    if args.test_path:
        predictor.predict(args.test_path)
    else:
        logging.info("No test path provided. Skipping final prediction step.")

if __name__ == "__main__":
    main()
