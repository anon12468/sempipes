
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool
import os

def load_and_preprocess_data(file_path, street_info_path, violation_codes_path, is_training=True):
    """
    Loads the main dataset and augments it with street information and violation codes.
    """
    df = pd.read_csv(file_path)

    # Rename columns for easier access
    df = df.rename(columns={
        'Street Name': 'street_name',
        'Violation Description': 'violation_type',
        'violation_count': 'violation_count'
    })

    # Load augmentation tables
    try:
        street_info_df = pd.read_csv(street_info_path)
        street_info_df = street_info_df.rename(columns={'Street Name': 'street_name'})
        df = pd.merge(df, street_info_df, on='street_name', how='left')
    except FileNotFoundError:
        print(f"Warning: Street info file not found at {street_info_path}. Skipping street info augmentation.")
    except Exception as e:
        print(f"Warning: Error loading or merging street info: {e}. Skipping street info augmentation.")

    try:
        violation_codes_df = pd.read_csv(violation_codes_path)
        violation_codes_df = violation_codes_df.rename(columns={'Violation Description': 'violation_type'})
        df = pd.merge(df, violation_codes_df, on='violation_type', how='left')
    except FileNotFoundError:
        print(f"Warning: Violation codes file not found at {violation_codes_path}. Skipping violation codes augmentation.")
    except Exception as e:
        print(f"Warning: Error loading or merging violation codes: {e}. Skipping violation codes augmentation.")

    # Feature Engineering (example: can be expanded)
    df['street_name_len'] = df['street_name'].apply(lambda x: len(str(x)) if pd.notna(x) else 0)
    df['violation_type_len'] = df['violation_type'].apply(lambda x: len(str(x)) if pd.notna(x) else 0)

    # Fill NaN for categorical features to ensure CatBoost handles them correctly
    for col in ['street_name', 'violation_type']:
        df[col] = df[col].fillna('UNKNOWN_CATEGORY')

    # Identify categorical features for CatBoost
    categorical_features = ['street_name', 'violation_type']
    # Add other categorical features from augmentation tables if they exist
    if 'Borough' in df.columns:
        df['Borough'] = df['Borough'].fillna('UNKNOWN_BOROUGH')
        categorical_features.append('Borough')
    if 'Violation Category' in df.columns: # Example column name
        df['Violation Category'] = df['Violation Category'].fillna('UNKNOWN_V_CATEGORY')
        categorical_features.append('Violation Category')

    # Convert violation_count to numeric if it exists and is not already
    if is_training or 'violation_count' in df.columns:
        df['violation_count'] = pd.to_numeric(df['violation_count'], errors='coerce')
        df['violation_count'] = df['violation_count'].fillna(0).astype(int) # Fill NaN with 0 for target

    return df, categorical_features

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional: Path to the 2023 test/evaluation data CSV.')
    args = parser.parse_args()

    input_dir = os.path.dirname(args.train_path) if os.path.dirname(args.train_path) else './input'
    street_info_path = os.path.join(input_dir, 'nyc_street_info.csv') # Assuming a name for street info
    violation_codes_path = os.path.join(input_dir, 'nyc_violation_codes.csv') # Assuming a name for violation codes

    print(f"Loading training data from: {args.train_path}")
    train_df, categorical_features = load_and_preprocess_data(
        args.train_path, street_info_path, violation_codes_path, is_training=True
    )

    # Define features (X) and target (y)
    features = [col for col in train_df.columns if col not in ['violation_count']]
    target = 'violation_count'

    # Filter out features that might not exist after augmentation
    # Keep only common features between train_df and what CatBoost can handle
    # This list will be used for both training and prediction
    model_features = [f for f in features if f in train_df.columns and f not in ['street_name_original', 'violation_type_original']] # Exclude original if renamed
    
    # Ensure categorical features are indeed in the model_features list
    categorical_features_for_model = [f for f in categorical_features if f in model_features]

    X = train_df[model_features]
    y = train_df[target]

    # Use a grouped KFold or a simple train_test_split.
    # For initial development and given the task, a simple split on 2022 data is sufficient.
    # Stratifying by (street_name, violation_type) is not directly supported by train_test_split,
    # but we can try to get a representative sample.
    # For time-series like data, it's common to split chronologically, but here we don't have explicit time.
    # A random split, or a split based on unique (street, violation) pairs, is reasonable.
    X_train, X_val, y_train, y_val = train_test_split(
        X, y, test_size=0.2, random_state=42, shuffle=True
    )

    print(f"Training data shape: {X_train.shape}")
    print(f"Validation data shape: {X_val.shape}")

    # CatBoost Model Training
    # Adjust parameters to prevent OOM if data is large.
    # 'max_bytes_per_value' can help with large string features, but CatBoost usually handles it.
    # 'train_dir' for logging if needed.
    model = CatBoostRegressor(
        iterations=500, # Increased iterations for better learning
        learning_rate=0.05,
        depth=8,
        eval_metric='RMSE',
        random_seed=42,
        verbose=100,
        early_stopping_rounds=50, # Early stopping to prevent overfitting
        cat_features=categorical_features_for_model,
        # thread_count=-1 # Use all available threads
    )

    train_pool = Pool(X_train, y_train, cat_features=categorical_features_for_model)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_for_model)

    model.fit(train_pool, eval_set=val_pool, plot=False)

    val_preds = model.predict(X_val)
    # Ensure predictions are non-negative
    val_preds[val_preds < 0] = 0
    validation_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    print(f'Final Validation Performance: {validation_rmse}') # Required output for parsing

    # Handle test/evaluation file if provided
    if args.test_path:
        print(f"\nLoading test data from: {args.test_path}")
        test_df_original = pd.read_csv(args.test_path)
        test_df_processed, _ = load_and_preprocess_data(
            args.test_path, street_info_path, violation_codes_path, is_training=False
        )

        # Identify unseen pairs
        train_keys = set(train_df.apply(lambda row: (row['street_name'], row['violation_type']), axis=1))
        test_keys = set(test_df_processed.apply(lambda row: (row['street_name'], row['violation_type']), axis=1))
        unseen_keys = test_keys - train_keys
        num_unseen_keys = len(unseen_keys)
        print(f"Number of (street_name, violation_type) pairs in test set not seen in training: {num_unseen_keys}")

        # Align columns of test data with training data
        test_X = test_df_processed[model_features]

        # Predict on test data
        test_predictions = model.predict(test_X)
        test_predictions[test_predictions < 0] = 0
        test_predictions_rounded = np.round(test_predictions).astype(int)

        # Create submission file
        submission_df = pd.DataFrame({
            'street_name': test_df_original['Street Name'],
            'violation_type': test_df_original['Violation Description'],
            'predicted_count': test_predictions_rounded
        })
        submission_df.to_csv('submission.csv', index=False)
        print("Submission file 'submission.csv' generated.")

        # If test file contains actual violation_count, calculate RMSE
        if 'violation_count' in test_df_original.columns:
            actual_counts = pd.to_numeric(test_df_original['violation_count'], errors='coerce').fillna(0)
            test_rmse = np.sqrt(mean_squared_error(actual_counts, test_predictions_rounded))
            print(f"RMSE on provided test/evaluation data: {test_rmse}")
        else:
            print("Test file does not contain 'violation_count' column. Skipping RMSE calculation for test set.")
    else:
        print("\nNo test-path provided. Skipping final prediction and submission generation.")

if __name__ == "__main__":
    main()
