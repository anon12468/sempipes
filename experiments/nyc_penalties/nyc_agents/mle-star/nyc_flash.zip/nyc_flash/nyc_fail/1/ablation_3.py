
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import argparse
import os
import logging

# Set up logging to suppress verbose output during ablation runs, only show warnings/errors.
# We will use explicit print statements for results.
logging.basicConfig(level=logging.WARNING, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Helper function to load data safely ---
def load_data(file_path, df_name="DataFrame"):
    """
    Loads a CSV file into a pandas DataFrame.
    Handles file not found errors and general exceptions during loading.
    """
    if not os.path.exists(file_path):
        # logging.warning(f"File not found at {file_path} for {df_name}. Returning empty DataFrame.")
        return pd.DataFrame()
    try:
        df = pd.read_csv(file_path)
        # logging.info(f"Successfully loaded {df_name} from {file_path} with {len(df)} rows.")
        return df
    except Exception as e:
        logging.error(f"Error loading {file_path} for {df_name}: {e}. Returning empty DataFrame.")
        return pd.DataFrame()

# --- Feature Engineering and Preprocessing Class ---
class FeatureEngineer:
    """
    Handles loading auxiliary data, creating new features, and imputing missing values
    for both training and prediction datasets.
    It prepares data suitable for RandomForest, which requires numerical input.
    """
    def __init__(self, use_feature_selection=True, imputation_strategy='zero'):
        self.trained_street_violation_pairs = None # To track unseen pairs in test
        self.feature_columns = [] # To store names of final features for the model
        
        # Label encoders for categorical features
        self.le_street = LabelEncoder()
        self.le_violation = LabelEncoder()
        self.le_borough = LabelEncoder()
        
        # Keep track of original categorical column names to process them
        self._original_categorical_cols = ['street_name', 'violation_type', 'borough']

        # Ablation flags
        self.use_feature_selection = use_feature_selection
        self.imputation_strategy = imputation_strategy # 'zero' or 'mean'
        self.numerical_means = {} # To store means for imputation (for 'mean' strategy)

    def fit(self, df_train_raw, aux_data_dir="./input"):
        """
        Fits the feature engineer on the raw training data.
        Performs feature creation, imputation, and fits LabelEncoders.
        Returns processed features (X) and target (y) for training.
        """
        # Store unique (street_name, violation_type) pairs from training for unseen pair tracking
        self.trained_street_violation_pairs = set(
            df_train_raw.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1)
        )
        
        # Process core data and add auxiliary features
        df_train_features = self._add_auxiliary_features(df_train_raw.copy(), aux_data_dir)
        
        # Rename core columns to be consistent
        df_train_features.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type',
            'violation_count': 'violation_count'
        }, inplace=True)
        
        # Handle target column
        target = 'violation_count'
        y_train = df_train_features[target]
        df_train_features.drop(columns=[target], inplace=True) # Drop target from features

        # Fit LabelEncoders for categorical features
        df_train_features['street_name_encoded'] = self.le_street.fit_transform(
            df_train_features['street_name'].fillna('UNKNOWN_STREET').astype(str)
        )
        df_train_features['violation_type_encoded'] = self.le_violation.fit_transform(
            df_train_features['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str)
        )
        if 'borough' in df_train_features.columns:
            df_train_features['borough_encoded'] = self.le_borough.fit_transform(
                df_train_features['borough'].fillna('UNKNOWN_BOROUGH').astype(str)
            )
        else:
            df_train_features['borough_encoded'] = -1 # Default for missing borough

        # Impute missing numerical values (after all joins and encodings)
        numerical_cols = df_train_features.select_dtypes(include=np.number).columns
        for col in numerical_cols:
            if self.imputation_strategy == 'mean':
                self.numerical_means[col] = df_train_features[col].mean()
                df_train_features[col].fillna(self.numerical_means[col], inplace=True)
            else: # Default 'zero'
                df_train_features[col].fillna(0, inplace=True)
        
        # Define the final feature columns for the model (before potential feature selection)
        initial_candidate_features = [
            col for col in df_train_features.columns
            if col not in self._original_categorical_cols and col != 'actual_violation_count'
        ]

        # --- Feature Importance based Feature Selection ---
        if self.use_feature_selection:
            # Prepare data for initial Random Forest training
            X_train_initial = df_train_features[initial_candidate_features]
            y_train_initial = y_train # Use the already extracted target

            # Initialize and train a Random Forest Regressor to get feature importances
            rf_initial = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
            rf_initial.fit(X_train_initial, y_train_initial)

            # Get feature importances
            feature_importances = rf_initial.feature_importances_
            
            importance_df = pd.DataFrame({
                'feature': initial_candidate_features,
                'importance': feature_importances
            })
            importance_df = importance_df.sort_values(by='importance', ascending=False)

            # Determine a feature importance threshold
            mean_importance = importance_df['importance'].mean()
            if mean_importance > 0:
                importance_threshold = mean_importance * 0.5 # Select features with importance > 50% of the average
            else:
                importance_threshold = 0

            # Select features based on the calculated threshold
            selected_features = importance_df[importance_df['importance'] > importance_threshold]['feature'].tolist()

            # Fallback mechanism: if no features meet the threshold or initial set is empty
            if not selected_features and len(initial_candidate_features) > 0:
                top_n_fallback = 10
                selected_features = importance_df.head(min(top_n_fallback, len(initial_candidate_features)))['feature'].tolist()
                
                if not selected_features and len(initial_candidate_features) > 0:
                    selected_features = initial_candidate_features
                elif not selected_features and len(initial_candidate_features) == 0:
                    selected_features = []
            self.feature_columns = selected_features
        else: # If feature selection is disabled, use all initial candidate features
            self.feature_columns = initial_candidate_features
        
        return df_train_features[self.feature_columns], y_train

    def transform(self, df_data_raw, aux_data_dir="./input"):
        """
        Transforms new raw data (e.g., test/evaluation data) using the fitted feature engineer.
        Applies feature creation and imputation based on training data.
        """
        df_data_features = self._add_auxiliary_features(df_data_raw.copy(), aux_data_dir)
        
        # Store actual_violation_count if present for later evaluation
        if 'violation_count' in df_data_features.columns:
            df_data_features['actual_violation_count'] = df_data_features['violation_count']
            df_data_features.drop(columns=['violation_count'], inplace=True)

        # Rename core columns
        df_data_features.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type'
        }, inplace=True)

        # Apply LabelEncoders, handling unseen categories with -1
        df_data_features['street_name_encoded'] = df_data_features['street_name'].fillna('UNKNOWN_STREET').astype(str).map(
            lambda x: self.le_street.transform([x])[0] if x in self.le_street.classes_ else -1
        )
        df_data_features['violation_type_encoded'] = df_data_features['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str).map(
            lambda x: self.le_violation.transform([x])[0] if x in self.le_violation.classes_ else -1
        )
        
        if 'borough' in df_data_features.columns:
            df_data_features['borough_encoded'] = df_data_features['borough'].fillna('UNKNOWN_BOROUGH').astype(str).map(
                lambda x: self.le_borough.transform([x])[0] if x in self.le_borough.classes_ else -1
            )
        else:
            df_data_features['borough_encoded'] = -1 # Default for missing borough

        # Impute missing numerical values
        numerical_cols = df_data_features.select_dtypes(include=np.number).columns
        for col in numerical_cols:
            if self.imputation_strategy == 'mean' and col in self.numerical_means:
                df_data_features[col].fillna(self.numerical_means[col], inplace=True)
            else: # Default 'zero' or if mean not available from training
                df_data_features[col].fillna(0, inplace=True)
            
        # Ensure all feature columns from training are present and in order
        for col in self.feature_columns:
            if col not in df_data_features.columns:
                df_data_features[col] = 0 # Add missing features with a default value (e.g., 0)

        return df_data_features[self.feature_columns]

    def _add_auxiliary_features(self, df, aux_data_dir):
        """
        Loads and merges auxiliary data to enrich the main DataFrame with additional features.
        This method remains as-is from the original code, as previous ablation studies
        suggested that the overall auxiliary features did not significantly impact performance,
        and this ablation focuses on other new aspects.
        """
        # Standardize column names for merging
        df.rename(columns={'Street Name': 'street_name', 'Violation Description': 'violation_type'}, inplace=True)

        # --- Violation Codes Features ---
        violation_codes_df = load_data(os.path.join(aux_data_dir, 'violation_codes.csv'), 'Violation Codes')
        if not violation_codes_df.empty:
            violation_codes_df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
            violation_codes_df['fine_amount_avg'] = (
                violation_codes_df['Manhattan 96th St. & Below'].fillna(0) + 
                violation_codes_df['All Other Areas'].fillna(0)
            ) / 2
            violation_codes_df.drop(columns=['Violation Code', 'Manhattan 96th St. & Below', 'All Other Areas'], errors='ignore', inplace=True)
            df = pd.merge(df, violation_codes_df, on='violation_type', how='left')
        
        # --- Street Segments Features ---
        street_segments_df = load_data(os.path.join(aux_data_dir, 'nyc_street_segments.csv'), 'Street Segments')
        if not street_segments_df.empty:
            street_segments_agg = street_segments_df.groupby('Street Name').agg(
                street_segment_length_sum=('Segment Length', 'sum'),
                street_speed_limit_mean=('Speed Limit', 'mean'),
                street_num_lanes_mean=('Number of Lanes', 'mean'),
                borough_ss=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            street_segments_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, street_segments_agg, on='street_name', how='left')
            
        # --- Parking Zones Features ---
        parking_zones_df = load_data(os.path.join(aux_data_dir, 'nyc_parking_zones.csv'), 'Parking Zones')
        if not parking_zones_df.empty:
            parking_zones_agg = parking_zones_df.groupby('Street Name').agg(
                num_parking_zones=('Parking Zone', 'count'),
                avg_max_duration_parking=('Max Duration', 'mean'),
                borough_pz=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            parking_zones_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, parking_zones_agg, on='street_name', how='left')

            # Consolidate borough information
            if 'borough_ss' in df.columns and 'borough_pz' in df.columns:
                df['borough'] = df['borough_ss'].fillna(df['borough_pz'])
            elif 'borough_ss' in df.columns:
                 df['borough'] = df['borough_ss']
            elif 'borough_pz' in df.columns:
                 df['borough'] = df['borough_pz']
            else:
                df['borough'] = np.nan
            
            df.drop(columns=['borough_ss', 'borough_pz'], errors='ignore', inplace=True)

        # --- Traffic Counts Features ---
        traffic_counts_df = load_data(os.path.join(aux_data_dir, 'traffic_counts_nyc.csv'), 'Traffic Counts')
        if not traffic_counts_df.empty:
            traffic_counts_agg = traffic_counts_df.groupby('Street Name').agg(
                avg_vehicle_count=('Vehicle Count', 'mean'),
                max_vehicle_count=('Vehicle Count', 'max'),
                std_vehicle_count=('Vehicle Count', 'std')
            ).reset_index()
            traffic_counts_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, traffic_counts_agg, on='street_name', how='left')

        # --- Census Tracts Features ---
        if 'borough' not in df.columns:
            df['borough'] = np.nan
        
        census_tracts_df = load_data(os.path.join(aux_data_dir, 'nyc_census_tracts.csv'), 'Census Tracts')
        if not census_tracts_df.empty:
            census_borough_agg = census_tracts_df.groupby('Borough').agg(
                total_population_borough=('Total Population', 'sum'),
                median_household_income_borough=('Median Household Income', 'mean'),
                poverty_rate_borough=('Poverty Rate', 'mean')
            ).reset_index()
            df = pd.merge(df, census_borough_agg, on='borough', how='left')

        return df

def run_experiment(name, train_path, aux_data_dir,
                   use_feature_selection=True, imputation_strategy='zero',
                   postprocess_predictions=True):
    """
    Runs a single experiment with specified ablation settings and returns its validation RMSE.
    """
    print(f"\n--- Running experiment: {name} ---")

    # Load 2022 training data
    train_2022_raw = load_data(train_path, '2022 Training Data')
    if train_2022_raw.empty:
        print(f"ERROR: Training data is empty or could not be loaded for '{name}'. Skipping.")
        return name, None

    # Initialize Feature Engineer with ablation parameters
    fe = FeatureEngineer(
        use_feature_selection=use_feature_selection,
        imputation_strategy=imputation_strategy
    )

    # Fit feature engineer on the full 2022 data and get processed features and target
    X_full_2022, y_full_2022 = fe.fit(train_2022_raw, aux_data_dir)
    
    # Split 2022 data into training and validation sets
    X_train, X_val, y_train, y_val = train_test_split(
        X_full_2022, y_full_2022, test_size=0.2, random_state=42
    )
    
    # --- Model Training ---
    rf_model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1, min_samples_leaf=5)
    rf_model.fit(X_train, y_train)

    # --- Validation Prediction and Evaluation ---
    val_predictions = rf_model.predict(X_val)
    
    if postprocess_predictions:
        val_predictions[val_predictions < 0] = 0 # Ensure predictions are non-negative
        val_predictions = np.round(val_predictions).astype(int) # Round to nearest integer

    val_rmse = np.sqrt(mean_squared_error(y_val, val_predictions))
    print(f"Result for '{name}': Validation RMSE = {val_rmse:.4f}")
    return name, val_rmse

def main_ablation_study():
    # Hardcode paths for ablation study as per instructions
    train_path = "./input/violations_per_street_2022.csv"
    aux_data_dir = "./input"

    results = {}

    # 0. Baseline (original configuration)
    name, rmse = run_experiment("Baseline (Original Config)", train_path, aux_data_dir,
                                use_feature_selection=True, imputation_strategy='zero',
                                postprocess_predictions=True)
    results[name] = rmse

    # 1. Ablation: Disable Feature Importance-based Feature Selection
    name, rmse = run_experiment("Ablation 1: No Feature Selection", train_path, aux_data_dir,
                                use_feature_selection=False)
    results[name] = rmse

    # 2. Ablation: Disable Post-processing of Predictions (Clipping to 0 and Rounding)
    name, rmse = run_experiment("Ablation 2: No Post-processing (raw floats)", train_path, aux_data_dir,
                                postprocess_predictions=False)
    results[name] = rmse

    # 3. Ablation: Change Numerical Imputation from 0 to Mean
    name, rmse = run_experiment("Ablation 3: Mean Imputation", train_path, aux_data_dir,
                                imputation_strategy='mean')
    results[name] = rmse

    print("\n--- Ablation Study Summary ---")
    baseline_rmse = results.get("Baseline (Original Config)")
    if baseline_rmse is None:
        print("Baseline experiment failed, cannot compare other results.")
        return

    # Sort results by RMSE for easy comparison
    sorted_results = sorted([item for item in results.items() if item[1] is not None], key=lambda item: item[1])
    
    for name, rmse in sorted_results:
        diff = rmse - baseline_rmse
        print(f"{name}: RMSE = {rmse:.4f} (Difference from Baseline: {diff:+.4f})")
    
    # Determine the most contributing part:
    # A component contributes most if its removal/change causes the largest INCREASE in RMSE.
    most_contributing_component = None
    max_degradation_from_baseline = 0.0

    # Consider the effects of each ablation relative to the baseline
    # Ablation 1: No Feature Selection (if worse, Feature Selection is good)
    if results.get("Ablation 1: No Feature Selection") is not None:
        degradation = results["Ablation 1: No Feature Selection"] - baseline_rmse
        if degradation > max_degradation_from_baseline:
            max_degradation_from_baseline = degradation
            most_contributing_component = "Feature Importance-based Feature Selection"
    
    # Ablation 2: No Post-processing (if worse, Post-processing is good)
    if results.get("Ablation 2: No Post-processing (raw floats)") is not None:
        degradation = results["Ablation 2: No Post-processing (raw floats)"] - baseline_rmse
        if degradation > max_degradation_from_baseline:
            max_degradation_from_baseline = degradation
            most_contributing_component = "Post-processing of Predictions (Clipping to 0 and Rounding)"

    # Ablation 3: Mean Imputation (if worse than baseline, then Zero Imputation (baseline) is good)
    if results.get("Ablation 3: Mean Imputation") is not None:
        degradation = results["Ablation 3: Mean Imputation"] - baseline_rmse
        if degradation > max_degradation_from_baseline:
            max_degradation_from_baseline = degradation
            most_contributing_component = "Zero Imputation for Missing Numerical Values"

    print("\nConclusion:")
    if most_contributing_component and max_degradation_from_baseline > 0.001: # Threshold for 'significant' contribution
        print(f"The part of the code that contributes the most to the overall performance (i.e., its absence or change causes the largest degradation) is: '{most_contributing_component}' (causing an RMSE increase of +{max_degradation_from_baseline:.4f} when ablated).")
    elif most_contributing_component:
         print(f"Based on this study, '{most_contributing_component}' showed the largest impact, but the effect was negligible (RMSE increase of +{max_degradation_from_baseline:.4f}).")
    else:
        print("Based on this ablation study, none of the ablated components significantly degraded performance, or all ablations improved performance (which would imply the baseline components were not contributing positively).")


if __name__ == '__main__':
    main_ablation_study()
