
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
import os
import glob

class ParkingViolationPredictor:
    def __init__(self, random_state=42):
        # Increased n_estimators for potentially better performance, added max_depth and min_samples_leaf
        # to control model complexity and prevent potential OOM if a more complex model like CatBoost were used,
        # and to generally make RandomForest more robust.
        self.model = RandomForestRegressor(random_state=random_state, n_estimators=150, n_jobs=-1, max_depth=15, min_samples_leaf=5)
        self.street_violation_avg_counts = None
        self.street_avg_counts = None
        self.violation_avg_counts = None
        self.violation_type_mapping = {}
        self.street_name_mapping = {}
        self.max_violation_count = 0 # To store the max count for scaling, if needed.
        self.unseen_handling_strategy = 'impute_zero' # Example: how unseen aggregated features are handled.
        self.aux_data_path = './input' # Default path for auxiliary data

    def _load_data(self, file_path):
        """
        Loads data from a CSV file and performs initial cleaning/renaming.
        Ensures consistent column names ('street_name', 'violation_type').
        """
        df = pd.read_csv(file_path)

        # BUG FIX: Rename 'Violation Description' to 'violation_type' and 'Street Name' to 'street_name' early
        # This ensures these columns are present and consistently named before _add_auxiliary_features is called.
        if 'Violation Description' in df.columns:
            df = df.rename(columns={'Violation Description': 'violation_type'})
        if 'Street Name' in df.columns:
            df = df.rename(columns={'Street Name': 'street_name'})
        
        return df

    def _add_auxiliary_features(self, df):
        """
        Augments the DataFrame with additional features from auxiliary tables.
        This method assumes 'street_name' and 'violation_type' columns are present in the input df.
        Handles missing auxiliary files gracefully.
        """
        original_cols = df.columns.tolist()
        
        aux_files = {
            'street_attributes': 'street_attributes.csv',
            'violation_codes': 'violation_codes.csv',
            'street_zip_mapping': 'street_zip_mapping.csv'
        }

        for key, filename in aux_files.items():
            full_path = os.path.join(self.aux_data_path, filename)
            if not os.path.exists(full_path):
                print(f"Warning: Auxiliary file not found: {full_path}. Skipping augmentation with {key} data.")
                continue

            aux_df = pd.read_csv(full_path)

            if key == 'street_attributes':
                if 'Street Name' in aux_df.columns:
                    aux_df = aux_df.rename(columns={'Street Name': 'street_name'})
                if 'street_name' in aux_df.columns and 'street_name' in df.columns:
                    df = pd.merge(df, aux_df, on='street_name', how='left', suffixes=('', '_aux_street'))
                else:
                    print(f"Warning: Cannot merge {key} data. 'street_name' column not found in both dataframes.")

            elif key == 'violation_codes':
                if 'Violation Description' in aux_df.columns: # Aux data might have original name
                    aux_df = aux_df.rename(columns={'Violation Description': 'violation_type'})
                if 'violation_type' in aux_df.columns and 'violation_type' in df.columns: # Ensure both have the column
                    df = pd.merge(df, aux_df, on='violation_type', how='left', suffixes=('', '_aux_violation'))
                else:
                    print(f"Warning: Cannot merge {key} data. 'violation_type' column not found in both dataframes.")

            elif key == 'street_zip_mapping':
                if 'Street Name' in aux_df.columns:
                    aux_df = aux_df.rename(columns={'Street Name': 'street_name'})
                if 'street_name' in aux_df.columns and 'street_name' in df.columns:
                    df = pd.merge(df, aux_df, on='street_name', how='left', suffixes=('', '_aux_zip'))
                else:
                    print(f"Warning: Cannot merge {key} data. 'street_name' column not found in both dataframes.")

        # Identify newly added columns from merges and process them
        new_cols = [col for col in df.columns if col not in original_cols and col not in ['street_name', 'violation_type', 'violation_count']]
        for col in new_cols:
            if df[col].dtype == 'object':
                # Convert object types (categorical) to numerical
                df[col] = df[col].astype('category').cat.codes
                df[col] = df[col].replace(-1, np.nan) # -1 is typically used by cat.codes for NaN values
            # Impute any remaining NaNs after merging (e.g., for streets/violations not in aux data)
            df[col] = df[col].fillna(0) # Simple imputation strategy

        return df

    def _generate_features(self, df):
        """
        Generates numerical features from the DataFrame suitable for model training/prediction.
        Applies previously learned encodings and aggregated features.
        """
        # Add auxiliary features (ensures 'street_name' and 'violation_type' are already processed)
        df_processed = self._add_auxiliary_features(df.copy())
        
        # Encode categorical features ('street_name', 'violation_type')
        # Use learned mappings if available (for transform/test), otherwise create new ones (for fit/train)
        if self.street_name_mapping: 
            df_processed['street_name_encoded'] = df_processed['street_name'].map(self.street_name_mapping).fillna(-1).astype(int)
        else: 
            df_processed['street_name_encoded'] = df_processed['street_name'].astype('category').cat.codes
            self.street_name_mapping = dict(zip(df_processed['street_name'], df_processed['street_name_encoded']))

        if self.violation_type_mapping:
            df_processed['violation_type_encoded'] = df_processed['violation_type'].map(self.violation_type_mapping).fillna(-1).astype(int)
        else:
            df_processed['violation_type_encoded'] = df_processed['violation_type'].astype('category').cat.codes
            self.violation_type_mapping = dict(zip(df_processed['violation_type'], df_processed['violation_type_encoded']))

        # Add aggregated features (computed during fit)
        # For unseen (street_name, violation_type) pairs, fillna(0) effectively imputes 0 or the global average if implemented.
        if self.street_violation_avg_counts is not None:
            # Create a combined key for mapping
            df_processed['street_violation_key'] = list(zip(df_processed['street_name'], df_processed['violation_type']))
            df_processed['street_violation_avg_count'] = df_processed['street_violation_key'].map(self.street_violation_avg_counts).fillna(0)
            df_processed.drop(columns=['street_violation_key'], inplace=True) # Drop temporary key

            df_processed['street_avg_count'] = df_processed['street_name'].map(self.street_avg_counts).fillna(0)
            df_processed['violation_avg_count'] = df_processed['violation_type'].map(self.violation_avg_counts).fillna(0)
        else:
            # During the first call (fit), these will be None, so initialize with 0
            df_processed['street_violation_avg_count'] = 0
            df_processed['street_avg_count'] = 0
            df_processed['violation_avg_count'] = 0


        # Select features for the model (all numerical columns except original keys and target)
        feature_cols = [col for col in df_processed.columns if col not in ['street_name', 'violation_type', 'violation_count']]
        numeric_feature_cols = df_processed[feature_cols].select_dtypes(include=np.number).columns.tolist()
        
        return df_processed[numeric_feature_cols], df_processed[['street_name', 'violation_type']]

    def fit(self, train_df_path, validation_split=0.2):
        """
        Trains the RandomForestRegressor model using the provided training data.
        Splits a portion of the training data for validation and reports RMSE.
        """
        df = self._load_data(train_df_path)

        self.max_violation_count = df['violation_count'].max()

        # Calculate aggregated features using the entire training data BEFORE splitting
        # These will be used for both training and validation sets, and later for test.
        self.street_violation_avg_counts = df.groupby(['street_name', 'violation_type'])['violation_count'].mean().to_dict()
        self.street_avg_counts = df.groupby('street_name')['violation_count'].mean().to_dict()
        self.violation_avg_counts = df.groupby('violation_type')['violation_count'].mean().to_dict()

        # Split data for validation
        # Stratify by violation_type if possible, to ensure representation.
        # If 'violation_type' has too many unique values, stratify might fail.
        # Fallback to simple split if stratification fails or is not appropriate.
        try:
            train_df, val_df = train_test_split(df, test_size=validation_split, random_state=42, stratify=df['violation_type'])
        except ValueError:
            print("Warning: Stratification by violation_type failed (e.g., too many unique values or too few samples per class). Performing simple train_test_split.")
            train_df, val_df = train_test_split(df, test_size=validation_split, random_state=42)

        X_train, _ = self._generate_features(train_df)
        y_train = train_df['violation_count']

        print(f"Training model with {len(X_train)} samples...")
        self.model.fit(X_train, y_train)
        print("Model training complete.")

        # Evaluate on validation set
        X_val, val_keys = self._generate_features(val_df)
        y_val_pred = self.model.predict(X_val)
        y_val_pred = np.maximum(0, y_val_pred) # Ensure non-negative predictions

        val_rmse = np.sqrt(mean_squared_error(val_df['violation_count'], y_val_pred))
        print(f"Validation RMSE: {val_rmse:.4f}")
        print(f"Final Validation Performance: {val_rmse:.4f}") # Required print for parsing

        # Report unseen keys in validation set relative to training set (train_df)
        train_keys_for_unseen_check = set(zip(train_df['street_name'], train_df['violation_type']))
        val_unseen_keys_count = 0
        for _, row in val_keys.iterrows():
            if (row['street_name'], row['violation_type']) not in train_keys_for_unseen_check:
                val_unseen_keys_count += 1
        print(f"Number of unseen (street_name, violation_type) pairs in validation set: {val_unseen_keys_count} out of {len(val_keys)}")
        print(f"Unseen handling strategy: {self.unseen_handling_strategy} (for aggregated features, encoded categories map to -1)")
        

    def transform(self, test_df_path):
        """
        Generates predictions for the given test data.
        Applies feature engineering consistent with training and handles unseen keys.
        """
        df = self._load_data(test_df_path)
        
        # Store original keys for submission file
        original_keys = df[['street_name', 'violation_type']].copy()
        
        X_test, _ = self._generate_features(df)
        
        # Check if the test file contains 'violation_count' for evaluation
        has_ground_truth = 'violation_count' in df.columns
        y_true = None
        if has_ground_truth:
            y_true = df['violation_count']

        # Predict
        print(f"Generating predictions for {len(X_test)} samples...")
        predictions = self.model.predict(X_test)
        predictions = np.maximum(0, predictions) # Ensure non-negative predictions

        # Report unseen keys in test set relative to the entire training set (used for `fit`)
        train_keys_set = set(self.street_violation_avg_counts.keys())
        test_unseen_keys_count = 0
        for _, row in original_keys.iterrows():
            if (row['street_name'], row['violation_type']) not in train_keys_set:
                test_unseen_keys_count += 1
        print(f"Number of unseen (street_name, violation_type) pairs in test set: {test_unseen_keys_count} out of {len(original_keys)}")
        
        results = original_keys
        results['predicted_count'] = predictions

        if has_ground_truth:
            test_rmse = np.sqrt(mean_squared_error(y_true, predictions))
            print(f"Test RMSE: {test_rmse:.4f}")
        
        return results

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='./input/violations_per_street_2022.csv',
                        help='Path to the training data CSV file (e.g., 2022 data).')
    parser.add_argument('--test-path', type=str, default=None,
                        help='Optional: Path to the test data CSV file (e.g., 2023 data or evaluation set). '
                             'If provided, predictions will be generated and saved to submission.csv.')
    parser.add_argument('--output-dir', type=str, default='./',
                        help='Directory to save the submission.csv file.')
    parser.add_argument('--aux-data-path', type=str, default='./input',
                        help='Path to the directory containing auxiliary data files (e.g., street_attributes.csv).')

    args = parser.parse_args()

    # Ensure output directory exists
    os.makedirs(args.output_dir, exist_ok=True)

    predictor = ParkingViolationPredictor()
    predictor.aux_data_path = args.aux_data_path # Set auxiliary data path for the predictor instance

    print(f"Starting model training with data from: {args.train_path}")
    predictor.fit(args.train_path)

    if args.test_path:
        print(f"Generating predictions for data from: {args.test_path}")
        predictions_df = predictor.transform(args.test_path)
        output_filepath = os.path.join(args.output_dir, 'submission.csv')
        predictions_df.to_csv(output_filepath, index=False)
        print(f"Predictions saved to {output_filepath}")
    else:
        print("No test-path provided. Skipping prediction generation.")

if __name__ == "__main__":
    main()
