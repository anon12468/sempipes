

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import argparse
import os
import logging
import copy # Used to create deep copies of FeatureEngineer for isolated ablations

# Set up logging for better visibility during execution
# We will temporarily suppress INFO logs during ablation runs for cleaner output
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Helper function to load data safely ---
def load_data(file_path, df_name="DataFrame"):
    """
    Loads a CSV file into a pandas DataFrame.
    Handles file not found errors and general exceptions during loading.
    """
    if not os.path.exists(file_path):
        logging.warning(f"File not found at {file_path} for {df_name}. Returning empty DataFrame.")
        return pd.DataFrame()
    try:
        df = pd.read_csv(file_path)
        logging.info(f"Successfully loaded {df_name} from {file_path} with {len(df)} rows.")
        return df
    except Exception as e:
        logging.error(f"Error loading {file_path} for {df_name}: {e}. Returning empty DataFrame.")
        return pd.DataFrame()

# --- Feature Engineering and Preprocessing Class ---
class FeatureEngineer:
    """
    Handles loading auxiliary data, creating new features, and imputing missing values
    for both training and prediction datasets.
    It prepares data suitable for RandomForest, which requires numerical input.
    Ablation flags allow modification of feature generation for study.
    """
    def __init__(self, include_street_segments_std_agg=True, include_full_census_tracts_agg=True):
        self.trained_street_violation_pairs = None # To track unseen pairs in test
        self.feature_columns = [] # To store names of final features for the model
        
        # Label encoders for categorical features
        self.le_street = LabelEncoder()
        self.le_violation = LabelEncoder()
        self.le_borough = LabelEncoder()
        
        # Keep track of original categorical column names to process them
        self._original_categorical_cols = ['street_name', 'violation_type', 'borough']

        # Ablation flags
        self.include_street_segments_std_agg = include_street_segments_std_agg
        self.include_full_census_tracts_agg = include_full_census_tracts_agg

    def fit(self, df_train_raw, aux_data_dir="./input"):
        """
        Fits the feature engineer on the raw training data.
        Performs feature creation, imputation, and fits LabelEncoders.
        Returns processed features (X) and target (y) for training.
        """
        # Store unique (street_name, violation_type) pairs from training for unseen pair tracking
        self.trained_street_violation_pairs = set(
            df_train_raw.apply(lambda row: (row['Street Name'], row['Violation Description']), axis=1)
        )
        
        # Process core data and add auxiliary features
        df_train_features = self._add_auxiliary_features(df_train_raw.copy(), aux_data_dir)
        
        # Rename core columns to be consistent
        df_train_features.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type',
            'violation_count': 'violation_count'
        }, inplace=True)
        
        # Handle target column
        target = 'violation_count'
        y_train = df_train_features[target]
        df_train_features.drop(columns=[target], inplace=True) # Drop target from features

        # Fit LabelEncoders for categorical features
        df_train_features['street_name_encoded'] = self.le_street.fit_transform(
            df_train_features['street_name'].fillna('UNKNOWN_STREET').astype(str)
        )
        df_train_features['violation_type_encoded'] = self.le_violation.fit_transform(
            df_train_features['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str)
        )
        # Borough might not always be present or fully filled, ensure it's handled
        if 'borough' in df_train_features.columns:
            df_train_features['borough_encoded'] = self.le_borough.fit_transform(
                df_train_features['borough'].fillna('UNKNOWN_BOROUGH').astype(str)
            )
        else:
            df_train_features['borough_encoded'] = -1 # Default for missing borough
            logging.warning("No 'borough' column found during feature engineering in train. Using -1 for encoded.")

        # Impute missing numerical values (after all joins and encodings)
        numerical_cols = df_train_features.select_dtypes(include=np.number).columns
        for col in numerical_cols:
            df_train_features[col].fillna(0, inplace=True) # Simple imputation with 0
        
        # Define the final feature columns for the model
        # Exclude original string columns, and any temporary columns
        self.feature_columns = [
            col for col in df_train_features.columns
            if col not in self._original_categorical_cols and col != 'actual_violation_count'
        ]
        
        return df_train_features[self.feature_columns], y_train

    def transform(self, df_data_raw, aux_data_dir="./input"):
        """
        Transforms new raw data (e.g., test/evaluation data) using the fitted feature engineer.
        Applies feature creation and imputation based on training data.
        """
        df_data_features = self._add_auxiliary_features(df_data_raw.copy(), aux_data_dir)
        
        # Store actual_violation_count if present for later evaluation
        if 'violation_count' in df_data_features.columns:
            df_data_features['actual_violation_count'] = df_data_features['violation_count']
            df_data_features.drop(columns=['violation_count'], inplace=True)

        # Rename core columns
        df_data_features.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_type'
        }, inplace=True)

        # Apply LabelEncoders, handling unseen categories with -1
        df_data_features['street_name_encoded'] = df_data_features['street_name'].fillna('UNKNOWN_STREET').astype(str).map(
            lambda x: self.le_street.transform([x])[0] if x in self.le_street.classes_ else -1
        )
        df_data_features['violation_type_encoded'] = df_data_features['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str).map(
            lambda x: self.le_violation.transform([x])[0] if x in self.le_violation.classes_ else -1
        )
        
        if 'borough' in df_data_features.columns:
            df_data_features['borough_encoded'] = df_data_features['borough'].fillna('UNKNOWN_BOROUGH').astype(str).map(
                lambda x: self.le_borough.transform([x])[0] if x in self.le_borough.classes_ else -1
            )
        else:
            df_data_features['borough_encoded'] = -1 # Default for missing borough
            logging.warning("No 'borough' column found during feature engineering in test. Using -1 for encoded.")

        # Impute missing numerical values
        numerical_cols = df_data_features.select_dtypes(include=np.number).columns
        for col in numerical_cols:
            df_data_features[col].fillna(0, inplace=True) # Simple imputation with 0
            
        # Ensure all feature columns from training are present and in order
        for col in self.feature_columns:
            if col not in df_data_features.columns:
                df_data_features[col] = 0 # Add missing features with a default value (e.g., 0)
                logging.warning(f"Added missing feature '{col}' to test data with 0.")

        return df_data_features[self.feature_columns]

    def _add_auxiliary_features(self, df, aux_data_dir):
        """
        Loads and merges auxiliary data to enrich the main DataFrame with additional features.
        Ablation flags control which specific aggregations are included.
        """
        # --- Violation Codes Features ---
        violation_codes_df = load_data(os.path.join(aux_data_dir, 'violation_codes.csv'), 'Violation Codes')
        if not violation_codes_df.empty:
            violation_codes_df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
            violation_codes_df['fine_amount_avg'] = (
                violation_codes_df['Manhattan 96th St. & Below'].fillna(0) + 
                violation_codes_df['All Other Areas'].fillna(0)
            ) / 2
            violation_codes_df.drop(columns=['Violation Code', 'Manhattan 96th St. & Below', 'All Other Areas'], errors='ignore', inplace=True)
            df = pd.merge(df, violation_codes_df, on='violation_type', how='left')
        
        # --- Street Segments Features ---
        street_segments_df = load_data(os.path.join(aux_data_dir, 'nyc_street_segments.csv'), 'Street Segments')
        if not street_segments_df.empty:
            agg_dict_ss = {
                'street_segment_length_sum': ('Segment Length', 'sum'),
                'street_speed_limit_mean': ('Speed Limit', 'mean'),
                'street_num_lanes_mean': ('Number of Lanes', 'mean'),
                'borough_ss': ('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            }
            if self.include_street_segments_std_agg:
                agg_dict_ss['street_speed_limit_std'] = ('Speed Limit', 'std')
                agg_dict_ss['street_num_lanes_std'] = ('Number of Lanes', 'std')

            street_segments_agg = street_segments_df.groupby('Street Name').agg(**agg_dict_ss).reset_index()
            street_segments_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, street_segments_agg, on='street_name', how='left')
            
        # --- Parking Zones Features ---
        parking_zones_df = load_data(os.path.join(aux_data_dir, 'nyc_parking_zones.csv'), 'Parking Zones')
        if not parking_zones_df.empty:
            parking_zones_agg = parking_zones_df.groupby('Street Name').agg(
                num_parking_zones=('Parking Zone', 'count'),
                avg_max_duration_parking=('Max Duration', 'mean'),
                borough_pz=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            parking_zones_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, parking_zones_agg, on='street_name', how='left')

            # Consolidate borough information
            if 'borough_ss' in df.columns and 'borough_pz' in df.columns:
                df['borough'] = df['borough_ss'].fillna(df['borough_pz'])
            elif 'borough_ss' in df.columns:
                 df['borough'] = df['borough_ss']
            elif 'borough_pz' in df.columns:
                 df['borough'] = df['borough_pz']
            else: # If no borough from aux data, initialize
                df['borough'] = np.nan
            
            df.drop(columns=['borough_ss', 'borough_pz'], errors='ignore', inplace=True)

        # --- Traffic Counts Features ---
        traffic_counts_df = load_data(os.path.join(aux_data_dir, 'traffic_counts_nyc.csv'), 'Traffic Counts')
        if not traffic_counts_df.empty:
            traffic_counts_agg = traffic_counts_df.groupby('Street Name').agg(
                avg_vehicle_count=('Vehicle Count', 'mean'),
                max_vehicle_count=('Vehicle Count', 'max'),
                std_vehicle_count=('Vehicle Count', 'std')
            ).reset_index()
            traffic_counts_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, traffic_counts_agg, on='street_name', how='left')

        # --- Census Tracts Features ---
        # Ensure 'borough' column exists for merging census data
        if 'borough' not in df.columns:
            df['borough'] = np.nan # Create it if not already present from other merges
        
        census_tracts_df = load_data(os.path.join(aux_data_dir, 'nyc_census_tracts.csv'), 'Census Tracts')
        if not census_tracts_df.empty:
            agg_dict_census = {
                'total_population_borough': ('Total Population', 'sum'),
                'median_household_income_borough_mean': ('Median Household Income', 'mean'),
                'poverty_rate_borough_mean': ('Poverty Rate', 'mean')
            }
            if self.include_full_census_tracts_agg:
                agg_dict_census.update({
                    'median_household_income_borough_median': ('Median Household Income', 'median'),
                    'median_household_income_borough_std': ('Median Household Income', 'std'),
                    'median_household_income_borough_min': ('Median Household Income', 'min'),
                    'median_household_income_borough_max': ('Median Household Income', 'max'),
                    'poverty_rate_borough_median': ('Poverty Rate', 'median'),
                    'poverty_rate_borough_std': ('Poverty Rate', 'std'),
                    'poverty_rate_borough_min': ('Poverty Rate', 'min'),
                    'poverty_rate_borough_max': ('Poverty Rate', 'max')
                })

            census_borough_agg = census_tracts_df.groupby('Borough').agg(**agg_dict_census).reset_index()
            df = pd.merge(df, census_borough_agg, on='Borough', how='left')

        return df

# Main experiment running function for ablation study
def run_ablation_experiment(
    train_path,
    aux_data_dir,
    include_street_segments_std_agg=True,
    include_full_census_tracts_agg=True,
    rf_n_estimators=100
):
    # Temporarily set logging level to WARNING to suppress verbose output during experiment runs
    original_level = logging.root.level
    logging.root.setLevel(logging.WARNING)

    # Load 2022 training data
    train_2022_raw = load_data(train_path, '2022 Training Data')
    if train_2022_raw.empty:
        logging.error("Training data is empty or could not be loaded. Exiting.")
        logging.root.setLevel(original_level) # Restore logging level
        return None

    # Initialize Feature Engineer with ablation flags
    fe = FeatureEngineer(
        include_street_segments_std_agg=include_street_segments_std_agg,
        include_full_census_tracts_agg=include_full_census_tracts_agg
    )

    # Fit feature engineer on the full 2022 data and get processed features and target
    X_full_2022, y_full_2022 = fe.fit(train_2022_raw, aux_data_dir)
    
    # Split 2022 data into training and validation sets for development evaluation
    X_train, X_val, y_train, y_val = train_test_split(
        X_full_2022, y_full_2022, test_size=0.2, random_state=42
    )
    
    # --- Model Training ---
    rf_model = RandomForestRegressor(n_estimators=rf_n_estimators, random_state=42, n_jobs=-1, min_samples_leaf=5)
    rf_model.fit(X_train, y_train)

    # --- Validation Prediction and Evaluation ---
    val_predictions = rf_model.predict(X_val)
    val_predictions[val_predictions < 0] = 0 # Ensure predictions are non-negative
    val_predictions = np.round(val_predictions).astype(int) # Round to nearest integer

    val_rmse = np.sqrt(mean_squared_error(y_val, val_predictions))
    
    logging.root.setLevel(original_level) # Restore logging level
    return val_rmse

if __name__ == '__main__':
    # Define paths - assuming 'input' directory exists in the same location as this script
    TRAIN_PATH = "./input/violations_per_street_2022.csv"
    AUX_DATA_DIR = "./input"

    results = {}

    # --- Baseline ---
    print("Running Baseline (current setup)...")
    baseline_rmse = run_ablation_experiment(TRAIN_PATH, AUX_DATA_DIR)
    results['Baseline'] = baseline_rmse
    print(f"Baseline Validation RMSE: {baseline_rmse:.4f}\n")

    # --- Ablation 1: No Street Segments standard deviation aggregations ---
    # This removes 'street_speed_limit_std' and 'street_num_lanes_std' features.
    print("Running Ablation 1: No Street Segments std aggregations...")
    ablation1_rmse = run_ablation_experiment(TRAIN_PATH, AUX_DATA_DIR, include_street_segments_std_agg=False)
    results['No Street Segments std aggregations'] = ablation1_rmse
    print(f"Ablation 1 (No Street Segments std aggregations) Validation RMSE: {ablation1_rmse:.4f} (Diff: {ablation1_rmse - baseline_rmse:.4f})\n")

    # --- Ablation 2: Simplified Census Tracts aggregations (mean only) ---
    # This keeps only 'mean' aggregations for income and poverty rate, removing 'median', 'std', 'min', 'max'.
    print("Running Ablation 2: Simplified Census Tracts aggregations (mean only)...")
    ablation2_rmse = run_ablation_experiment(TRAIN_PATH, AUX_DATA_DIR, include_full_census_tracts_agg=False)
    results['Simplified Census Tracts aggregations'] = ablation2_rmse
    print(f"Ablation 2 (Simplified Census Tracts aggregations) Validation RMSE: {ablation2_rmse:.4f} (Diff: {ablation2_rmse - baseline_rmse:.4f})\n")

    # --- Ablation 3: RandomForest n_estimators = 50 ---
    # This reduces the number of trees in the RandomForest model from 100 to 50.
    print("Running Ablation 3: RandomForest n_estimators = 50...")
    ablation3_rmse = run_ablation_experiment(TRAIN_PATH, AUX_DATA_DIR, rf_n_estimators=50)
    results['RandomForest n_estimators = 50'] = ablation3_rmse
    print(f"Ablation 3 (RandomForest n_estimators = 50) Validation RMSE: {ablation3_rmse:.4f} (Diff: {ablation3_rmse - baseline_rmse:.4f})\n")

    print("\n--- Ablation Study Summary ---")
    
    # Determine the most impactful part of the code based on the largest absolute change in RMSE.
    # A larger absolute difference indicates a greater impact, regardless of whether it improved or degraded performance.
    largest_impact_diff = 0
    largest_impact_part = "None of the tested ablations showed a significant impact on performance."

    for name, rmse in results.items():
        if name == 'Baseline':
            continue
        diff = rmse - baseline_rmse
        if abs(diff) > abs(largest_impact_diff):
            largest_impact_diff = diff
            largest_impact_part = name

    if largest_impact_part != "None of the tested ablations showed a significant impact on performance.":
        impact_description = "degraded" if largest_impact_diff > 0 else "improved"
        print(f"The part of the code that contributed the most to the overall performance (had the largest absolute impact on RMSE) is: '{largest_impact_part}'. Its removal {impact_description} RMSE by {abs(largest_impact_diff):.4f}.")
    else:
        print("No single ablated component showed a significant impact on performance.")

