
import argparse
import pandas as pd
import numpy as np
import os
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from catboost import CatBoostRegressor, Pool

# Function to create dummy data if files don't exist
def create_dummy_data(directory="./input"):
    """
    Creates dummy CSV files for training and testing data if they do not already exist.
    This ensures the script is runnable for demonstration or testing purposes without
    requiring actual input files.
    """
    if not os.path.exists(directory):
        os.makedirs(directory)

    train_file = os.path.join(directory, "violations_per_street_2022.csv")
    test_file_keys_only = os.path.join(directory, "violations_test_keys_only_2023.csv")
    test_file_with_target = os.path.join(directory, "violations_test_with_target_2023.csv")

    if not os.path.exists(train_file):
        print(f"Creating dummy training data at {train_file}")
        data = {
            'Street Name': ['MAIN ST', 'ELM AVE', 'OAK LANE', 'MAIN ST', 'ELM AVE', 'PINE DR', 'MAPLE RD', 'MAIN ST', 'RIVER RD', 'ELM AVE'],
            'Violation Description': ['PARKING METER', 'NO STANDING', 'FIRE HYDRANT', 'PARKING METER', 'OVERTIME PARKING', 'DOUBLE PARKING', 'BUS LANE', 'NO STANDING', 'COMMERCIAL PARKING', 'PARKING METER'],
            'violation_count': [100, 50, 20, 110, 60, 30, 40, 55, 75, 45]
        }
        df = pd.DataFrame(data)
        df.to_csv(train_file, index=False)

    if not os.path.exists(test_file_keys_only):
        print(f"Creating dummy test data (keys only) at {test_file_keys_only}")
        data = {
            'Street Name': ['MAIN ST', 'ELM AVE', 'CEDAR BLVD', 'MAIN ST', 'NEW ST', 'OAK LANE', 'MAIN ST'],
            'Violation Description': ['PARKING METER', 'NO STANDING', 'FIRE HYDRANT', 'NO STANDING', 'UNKNOWN VIOLATION', 'DOUBLE PARKING', 'PARKING METER']
        }
        df = pd.DataFrame(data)
        df.to_csv(test_file_keys_only, index=False)

    if not os.path.exists(test_file_with_target):
        print(f"Creating dummy test data (with target) at {test_file_with_target}")
        data = {
            'Street Name': ['MAIN ST', 'ELM AVE', 'CEDAR BLVD', 'MAIN ST', 'NEW ST', 'OAK LANE', 'MAIN ST'],
            'Violation Description': ['PARKING METER', 'NO STANDING', 'FIRE HYDRANT', 'NO STANDING', 'UNKNOWN VIOLATION', 'DOUBLE PARKING', 'PARKING METER'],
            'violation_count': [120, 65, 25, 60, 10, 35, 115] # Example target counts for evaluation
        }
        df = pd.DataFrame(data)
        df.to_csv(test_file_with_target, index=False)


def run_pipeline():
    """
    Main function to run the parking violation prediction pipeline.
    Parses arguments, loads data, trains a CatBoost model,
    evaluates it, and generates predictions for a test set if provided.
    """
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default="./input/violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV file.")
    parser.add_argument('--test-path', type=str, default=None,
                        help="Optional path to the test/evaluation data CSV file for prediction.")
    args = parser.parse_args()

    # Create dummy data if files don't exist in the specified input directory
    input_dir = os.path.dirname(args.train_path)
    if not input_dir: # Handle case where train_path is just a filename (e.g., "file.csv")
        input_dir = "./input"
    create_dummy_data(input_dir)


    print(f"Loading training data from: {args.train_path}")
    try:
        train_df = pd.read_csv(args.train_path)
    except FileNotFoundError:
        print(f"Error: Training file not found at {args.train_path}. Please check the path or ensure dummy data creation worked.")
        return # Exit gracefully if the training file is essential

    # Rename columns for consistency and easier access
    train_df.rename(columns={
        'Street Name': 'street_name',
        'Violation Description': 'violation_description',
        'violation_count': 'violation_count'
    }, inplace=True)

    # Define features and target
    features = ['street_name', 'violation_description']
    target = 'violation_count'

    # Handle potential missing values in categorical features
    # CatBoost can handle NaNs for numeric features but for string it's better to fill.
    for col in features:
        if train_df[col].dtype == 'object':
            train_df[col] = train_df[col].fillna('UNKNOWN_CATEGORY_FILL')
        # For numeric features, CatBoost handles NaNs by default or a specific strategy can be applied
        # For this dataset, all features are designed to be categorical strings.

    # Split 2022 data for validation during development
    X = train_df[features]
    y = train_df[target]

    # Perform a train-validation split.
    # For robustness, a grouped or stratified split might be considered, but a simple split works for illustration.
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    print(f"Training data size: {len(X_train)} records.")
    print(f"Validation data size: {len(X_val)} records.")

    # Identify categorical features for CatBoost
    categorical_features_indices = [X_train.columns.get_loc(col) for col in features if X_train[col].dtype == 'object']

    # Initialize and train CatBoostRegressor
    print("Training CatBoost model...")
    model = CatBoostRegressor(
        iterations=1000,
        learning_rate=0.05,
        depth=6,
        loss_function='RMSE',
        eval_metric='RMSE',
        random_seed=42,
        verbose=0, # Suppress verbose output during training
        early_stopping_rounds=50, # Stop if validation RMSE doesn't improve for 50 rounds
        thread_count=-1 # Use all available CPU cores to prevent OOM on large datasets
    )

    train_pool = Pool(X_train, y_train, cat_features=categorical_features_indices)
    val_pool = Pool(X_val, y_val, cat_features=categorical_features_indices)

    model.fit(train_pool, eval_set=val_pool, early_stopping_rounds=50, verbose=False)

    # Evaluate on validation set
    val_preds = model.predict(X_val)
    val_preds = np.maximum(0, val_preds) # Ensure predictions are non-negative
    validation_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    print(f"Validation RMSE: {validation_rmse:.4f}")
    # Required print statement for performance parsing
    print(f'Final Validation Performance: {validation_rmse}')


    # Handle test-path if provided for final predictions
    if args.test_path:
        print(f"\nLoading test data from: {args.test_path}")
        try:
            test_df = pd.read_csv(args.test_path)
        except FileNotFoundError:
            print(f"Error: Test file not found at {args.test_path}. Skipping prediction.")
            return # Exit gracefully if test file is crucial

        # Rename columns in test data for consistency
        test_df.rename(columns={
            'Street Name': 'street_name',
            'Violation Description': 'violation_description'
        }, inplace=True)

        # Handle potential missing values in test data categorical features
        for col in features:
            if col in test_df.columns:
                if test_df[col].dtype == 'object':
                    test_df[col] = test_df[col].fillna('UNKNOWN_CATEGORY_FILL')

        # Identify unseen key pairs (street_name, violation_description)
        train_key_pairs = set(train_df.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
        test_key_pairs = set(test_df.apply(lambda row: (row['street_name'], row['violation_description']), axis=1))
        unseen_keys_count = len(test_key_pairs - train_key_pairs)
        print(f"Number of (street_name, violation_description) pairs in test set unseen in training: {unseen_keys_count}")
        print(f"These unseen pairs are handled by CatBoost's internal mechanism for unknown categorical features, which typically assigns them to a default category or learns an embedding for them during training.")

        # Make predictions on the test set
        X_test = test_df[features]
        test_preds = model.predict(X_test)
        test_preds = np.maximum(0, test_preds) # Ensure predictions are non-negative

        # Create submission file
        submission_df = pd.DataFrame({
            'street_name': test_df['street_name'],
            'violation_type': test_df['violation_description'],
            'predicted_count': test_preds.round().astype(int) # Round to nearest integer and convert to int
        })
        submission_output_path = "submission.csv"
        submission_df.to_csv(submission_output_path, index=False)
        print(f"Predictions saved to {submission_output_path}")

        # If 'violation_count' is present in the test file, calculate RMSE against ground truth
        if 'violation_count' in test_df.columns:
            y_test = test_df['violation_count']
            test_rmse = np.sqrt(mean_squared_error(y_test, test_preds))
            print(f"Test Set RMSE (against ground truth): {test_rmse:.4f}")
        else:
            print("Test file does not contain 'violation_count' column. Skipping test RMSE calculation.")

    else:
        print("\nNo --test-path provided. Skipping final predictions.")

if __name__ == "__main__":
    run_pipeline()
