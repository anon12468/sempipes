

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import argparse
import os
import logging

# Set up logging for better visibility during execution
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Helper function to load data safely ---
def load_data(file_path, df_name="DataFrame"):
    """
    Loads a CSV file into a pandas DataFrame.
    Handles file not found errors and general exceptions during loading.
    """
    if not os.path.exists(file_path):
        logging.warning(f"File not found at {file_path} for {df_name}. Returning empty DataFrame.")
        return pd.DataFrame()
    try:
        df = pd.read_csv(file_path)
        logging.info(f"Successfully loaded {df_name} from {file_path} with {len(df)} rows.")
        return df
    except Exception as e:
        logging.error(f"Error loading {file_path} for {df_name}: {e}. Returning empty DataFrame.")
        return pd.DataFrame()

# --- Feature Engineering and Preprocessing Class ---
class FeatureEngineer:
    """
    Handles loading auxiliary data, creating new features, and imputing missing values
    for both training and prediction datasets.
    It prepares data suitable for RandomForest, which requires numerical input.
    """
    def __init__(self, disable_aggregate_stats=False, disable_borough_features=False):
        self.trained_street_violation_pairs = None # To track unseen pairs in test
        self.feature_columns = [] # To store names of final features for the model
        
        # Label encoders for categorical features
        self.le_street = LabelEncoder()
        self.le_violation = LabelEncoder()
        self.le_borough = LabelEncoder()
        
        # Keep track of original categorical column names to process them
        self._original_categorical_cols = ['street_name', 'violation_type', 'borough']

        # Ablation flags
        self.disable_aggregate_stats = disable_aggregate_stats
        self.disable_borough_features = disable_borough_features
        
        # Store statistics calculated during fit for use in transform
        self.street_stats = None
        self.violation_type_stats = None
        self.global_mean_violation_count = 0
        self.global_median_violation_count = 0
        self.global_std_violation_count = 0

    def fit(self, df_train_raw, aux_data_dir="./input"):
        """
        Fits the feature engineer on the raw training data.
        Performs feature creation, imputation, and fits LabelEncoders.
        Returns processed features (X) and target (y) for training.
        """
        logging.info("Fitting FeatureEngineer...")
        # Create a temporary df to standardize names for tracking pairs before aux features
        df_train_temp_for_pairs = df_train_raw.copy()
        if 'Street Name' in df_train_temp_for_pairs.columns:
            df_train_temp_for_pairs.rename(columns={'Street Name': 'street_name'}, inplace=True)
        if 'Violation Description' in df_train_temp_for_pairs.columns:
            df_train_temp_for_pairs.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
        self.trained_street_violation_pairs = set(
            df_train_temp_for_pairs.apply(lambda row: (row['street_name'], row['violation_type']), axis=1)
        )
        
        # Process core data and add auxiliary features
        df_train_features = self._add_auxiliary_features(df_train_raw.copy(), aux_data_dir)
        
        target = 'violation_count'
        y_train = df_train_features[target].copy() # Make a copy to avoid SettingWithCopyWarning
        df_train_features.drop(columns=[target], inplace=True) # Drop target from features

        # Fit LabelEncoders for categorical features
        df_train_features['street_name_encoded'] = self.le_street.fit_transform(
            df_train_features['street_name'].fillna('UNKNOWN_STREET').astype(str)
        )
        df_train_features['violation_type_encoded'] = self.le_violation.fit_transform(
            df_train_features['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str)
        )
        
        # Borough might not always be present or fully filled, ensure it's handled
        if not self.disable_borough_features and 'borough' in df_train_features.columns:
            df_train_features['borough_encoded'] = self.le_borough.fit_transform(
                df_train_features['borough'].fillna('UNKNOWN_BOROUGH').astype(str)
            )
        else:
            df_train_features['borough_encoded'] = -1 # Default for missing borough or if disabled
            if not self.disable_borough_features: # Only warn if not intentionally disabled
                logging.warning("No 'borough' column found during feature engineering in train. Using -1 for encoded.")
            else:
                logging.info("Ablation: Borough features are disabled, setting 'borough_encoded' to -1.")


        # Impute missing numerical values (after all joins and encodings)
        numerical_cols = df_train_features.select_dtypes(include=np.number).columns
        for col in numerical_cols:
            df_train_features[col].fillna(0, inplace=True) # Simple imputation with 0
        
        # Calculate and merge aggregate features for training data. Stores stats internally.
        if not self.disable_aggregate_stats:
            df_train_features = self._calculate_and_merge_aggregate_features(df_train_features, y_train, is_training_data=True)
        else:
            logging.info("Ablation: Skipping aggregate statistics features.")
        
        # Define the final feature columns for the model
        # Exclude original string columns, and any temporary columns
        self.feature_columns = [
            col for col in df_train_features.columns
            if col not in self._original_categorical_cols and col != 'actual_violation_count'
        ]

        # Filter out borough-related columns if disabled
        if self.disable_borough_features:
            borough_related_cols = [
                'borough', 'borough_encoded',
                'total_population_borough', 'median_household_income_borough', 'poverty_rate_borough'
            ]
            self.feature_columns = [col for col in self.feature_columns if col not in borough_related_cols]
            logging.info("Ablation: Removed borough-related features from final feature set.")
        
        logging.info(f"Identified {len(self.feature_columns)} features for RandomForest.")
        # Final check: ensure all features are numerical
        non_numeric_final = df_train_features[self.feature_columns].select_dtypes(include=['object', 'category']).columns
        if not non_numeric_final.empty:
            logging.error(f"ERROR: Non-numeric columns still present in final features: {list(non_numeric_final)}. These will be dropped for model training.")
            df_train_features.drop(columns=non_numeric_final, inplace=True, errors='ignore')
            self.feature_columns = [col for col in self.feature_columns if col not in non_numeric_final]

        return df_train_features[self.feature_columns], y_train

    def transform(self, df_data_raw, aux_data_dir="./input"):
        """
        Transforms new raw data (e.g., test/evaluation data) using the fitted feature engineer.
        Applies feature creation and imputation based on training data.
        """
        logging.info("Transforming data using fitted FeatureEngineer...")
        df_data_features = self._add_auxiliary_features(df_data_raw.copy(), aux_data_dir)
        
        # Apply LabelEncoders, handling unseen categories with -1
        df_data_features['street_name_encoded'] = df_data_features['street_name'].fillna('UNKNOWN_STREET').astype(str).map(
            lambda x: self.le_street.transform([x])[0] if x in self.le_street.classes_ else -1
        )
        df_data_features['violation_type_encoded'] = df_data_features['violation_type'].fillna('UNKNOWN_VIOLATION').astype(str).map(
            lambda x: self.le_violation.transform([x])[0] if x in self.le_violation.classes_ else -1
        )
        
        if not self.disable_borough_features and 'borough' in df_data_features.columns:
            df_data_features['borough_encoded'] = df_data_features['borough'].fillna('UNKNOWN_BOROUGH').astype(str).map(
                lambda x: self.le_borough.transform([x])[0] if x in self.le_borough.classes_ else -1
            )
        else:
            df_data_features['borough_encoded'] = -1 # Default for missing borough or if disabled
            if not self.disable_borough_features: # Only warn if not intentionally disabled
                logging.warning("No 'borough' column found during feature engineering in test. Using -1 for encoded.")
            else:
                logging.info("Ablation: Borough features are disabled in transform, setting 'borough_encoded' to -1.")


        # Impute missing numerical values
        numerical_cols = df_data_features.select_dtypes(include=np.number).columns
        for col in numerical_cols:
            df_data_features[col].fillna(0, inplace=True)
            
        # Merge aggregate features for test data using stored statistics
        if not self.disable_aggregate_stats:
            df_data_features = self._calculate_and_merge_aggregate_features(df_data_features, None, is_training_data=False)
        else:
            logging.info("Ablation: Skipping aggregate statistics features in transform.")

        # Ensure all feature columns from training are present and in order
        for col in self.feature_columns: # self.feature_columns is determined during fit
            if col not in df_data_features.columns:
                df_data_features[col] = 0 # Add missing features with a default value (e.g., 0)
                logging.warning(f"Added missing feature '{col}' to test data with 0.")

        return df_data_features[self.feature_columns]

    def _add_auxiliary_features(self, df, aux_data_dir):
        """
        Loads and merges auxiliary data to enrich the main DataFrame with additional features.
        Standardizes 'Street Name' and 'Violation Description' to 'street_name' and 'violation_type'.
        """
        logging.info("Adding auxiliary features...")

        # Standardize core column names at the beginning for consistent merging
        if 'Street Name' in df.columns:
            df.rename(columns={'Street Name': 'street_name'}, inplace=True)
        if 'Violation Description' in df.columns:
            df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)

        # --- Violation Codes Features ---
        violation_codes_df = load_data(os.path.join(aux_data_dir, 'violation_codes.csv'), 'Violation Codes')
        if not violation_codes_df.empty:
            violation_codes_df.rename(columns={'Violation Description': 'violation_type'}, inplace=True)
            violation_codes_df['fine_amount_avg'] = (
                violation_codes_df['Manhattan 96th St. & Below'].fillna(0) + 
                violation_codes_df['All Other Areas'].fillna(0)
            ) / 2
            violation_codes_df.drop(columns=['Violation Code', 'Manhattan 96th St. & Below', 'All Other Areas'], errors='ignore', inplace=True)
            df = pd.merge(df, violation_codes_df, on='violation_type', how='left')
            logging.info(f"Merged violation codes. DF shape: {df.shape}")
        
        # --- Street Segments Features ---
        street_segments_df = load_data(os.path.join(aux_data_dir, 'nyc_street_segments.csv'), 'Street Segments')
        if not street_segments_df.empty:
            street_segments_agg = street_segments_df.groupby('Street Name').agg(
                street_segment_length_sum=('Segment Length', 'sum'),
                street_speed_limit_mean=('Speed Limit', 'mean'),
                street_num_lanes_mean=('Number of Lanes', 'mean'),
                borough_ss=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            street_segments_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, street_segments_agg, on='street_name', how='left')
            logging.info(f"Merged street segments. DF shape: {df.shape}")
            
        # --- Parking Zones Features ---
        parking_zones_df = load_data(os.path.join(aux_data_dir, 'nyc_parking_zones.csv'), 'Parking Zones')
        if not parking_zones_df.empty:
            parking_zones_agg = parking_zones_df.groupby('Street Name').agg(
                num_parking_zones=('Parking Zone', 'count'),
                avg_max_duration_parking=('Max Duration', 'mean'),
                borough_pz=('Borough', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
            ).reset_index()
            parking_zones_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, parking_zones_agg, on='street_name', how='left')

            # Consolidate borough information
            if not self.disable_borough_features:
                if 'borough_ss' in df.columns and 'borough_pz' in df.columns:
                    df['borough'] = df['borough_ss'].fillna(df['borough_pz'])
                elif 'borough_ss' in df.columns:
                     df['borough'] = df['borough_ss']
                elif 'borough_pz' in df.columns:
                     df['borough'] = df['borough_pz']
                else: # If no borough from aux data, initialize
                    df['borough'] = np.nan
            else:
                logging.info("Ablation: Skipping borough consolidation from street segments/parking zones.")
                df['borough'] = np.nan # Ensure it exists but is empty/NaN for consistency
            
            df.drop(columns=['borough_ss', 'borough_pz'], errors='ignore', inplace=True)
            logging.info(f"Merged parking zones. DF shape: {df.shape}")

        # --- Traffic Counts Features ---
        traffic_counts_df = load_data(os.path.join(aux_data_dir, 'traffic_counts_nyc.csv'), 'Traffic Counts')
        if not traffic_counts_df.empty:
            traffic_counts_agg = traffic_counts_df.groupby('Street Name').agg(
                avg_vehicle_count=('Vehicle Count', 'mean'),
                max_vehicle_count=('Vehicle Count', 'max'),
                std_vehicle_count=('Vehicle Count', 'std')
            ).reset_index()
            traffic_counts_agg.rename(columns={'Street Name': 'street_name'}, inplace=True)
            df = pd.merge(df, traffic_counts_agg, on='street_name', how='left')
            logging.info(f"Merged traffic counts. DF shape: {df.shape}")

        # --- Census Tracts Features ---
        # Ensure 'borough' column exists for merging census data
        if 'borough' not in df.columns:
            df['borough'] = np.nan # Create it if not already present from other merges
        
        if not self.disable_borough_features:
            census_tracts_df = load_data(os.path.join(aux_data_dir, 'nyc_census_tracts.csv'), 'Census Tracts')
            if not census_tracts_df.empty:
                census_borough_agg = census_tracts_df.groupby('Borough').agg(
                    total_population_borough=('Total Population', 'sum'),
                    median_household_income_borough=('Median Household Income', 'mean'),
                    poverty_rate_borough=('Poverty Rate', 'mean')
                ).reset_index()
                # Merge on the 'borough' column which might have been populated from other auxiliary data
                if 'borough' in df.columns:
                    df = pd.merge(df, census_borough_agg, left_on='borough', right_on='Borough', how='left')
                    df.drop(columns=['Borough'], errors='ignore', inplace=True) # Drop the original 'Borough' column from census
                else:
                    logging.warning("No 'borough' column in main DF to merge with census data. Census data for borough-level stats might be missed.")
                logging.info(f"Merged census tracts. DF shape: {df.shape}")
            else:
                logging.warning("Census tracts data not available or empty.")
        else:
            logging.info("Ablation: Skipping census tracts features due to borough disablement.")


        logging.info("Finished adding auxiliary features.")
        return df

    def _calculate_and_merge_aggregate_features(self, df, y=None, is_training_data=True):
        """
        Calculates and merges aggregate statistics (mean, median, std of violation count)
        per street and violation type. Stores statistics during training for use in prediction.
        """
        logging.info("Generating aggregate statistics features...")
        df_enhanced = df.copy()

        # Use encoded columns for grouping for statistics calculation
        group_col_street = 'street_name_encoded'
        group_col_violation = 'violation_type_encoded'

        if is_training_data:
            # Calculate global averages of violation_count for imputation of unseen categories
            self.global_mean_violation_count = y.mean()
            self.global_median_violation_count = y.median()
            self.global_std_violation_count = y.std()
            if pd.isna(self.global_std_violation_count) or self.global_std_violation_count < 1e-6:
                self.global_std_violation_count = 0.0

            # Combine features and target to calculate statistics
            # Ensure the required encoded columns are present before proceeding
            temp_df_for_stats = df_enhanced[[group_col_street, group_col_violation]].copy()
            temp_df_for_stats['violation_count'] = y

            # Calculate statistics for 'street_name_encoded'
            self.street_stats = temp_df_for_stats.groupby(group_col_street)['violation_count'].agg(
                street_mean_violation=('mean'),
                street_median_violation=('median'),
                street_std_violation=('std')
            )
            self.street_stats['street_std_violation'].fillna(0.0, inplace=True)

            # Calculate statistics for 'violation_type_encoded'
            self.violation_type_stats = temp_df_for_stats.groupby(group_col_violation)['violation_count'].agg(
                type_mean_violation=('mean'),
                type_median_violation=('median'),
                type_std_violation=('std')
            )
            self.violation_type_stats['type_std_violation'].fillna(0.0, inplace=True)

        # Merge statistics
        df_enhanced = self._merge_stats(df_enhanced, self.street_stats, group_col_street, 'street',
                                        self.global_mean_violation_count, self.global_median_violation_count, self.global_std_violation_count)
        df_enhanced = self._merge_stats(df_enhanced, self.violation_type_stats, group_col_violation, 'type',
                                        self.global_mean_violation_count, self.global_median_violation_count, self.global_std_violation_count)

        logging.info("Aggregate statistics features generated and merged.")
        return df_enhanced

    def _merge_stats(self, df, stats_df, feature_col, prefix, global_mean, global_median, global_std):
        """Helper to merge statistics and impute missing values for unseen categories."""
        df_merged = df.copy()
        if stats_df is not None:
            df_merged = df_merged.merge(stats_df, left_on=feature_col, right_index=True, how='left')
            df_merged[f'{prefix}_mean_violation'].fillna(global_mean, inplace=True)
            df_merged[f'{prefix}_median_violation'].fillna(global_median, inplace=True)
            df_merged[f'{prefix}_std_violation'].fillna(global_std, inplace=True)
        else: # Fallback if stats_df was not fitted (shouldn't happen in normal flow)
            df_merged[f'{prefix}_mean_violation'] = global_mean
            df_merged[f'{prefix}_median_violation'] = global_median
            df_merged[f'{prefix}_std_violation'] = global_std
            logging.warning(f"Statistics for '{feature_col}' not available, using global defaults.")
        return df_merged

# Refactor main into a run_experiment function for easy ablation testing
def run_experiment(train_path, aux_data_dir,
                   ablation_no_aggregate_stats=False,
                   ablation_no_borough_features=False,
                   rf_min_samples_split=2): # Default RandomForest parameter
    
    logging.info(f"\n--- Running Experiment: "
                 f"NoAggStats={ablation_no_aggregate_stats}, "
                 f"NoBoroughFeatures={ablation_no_borough_features}, "
                 f"RF_MinSamplesSplit={rf_min_samples_split} ---")

    train_2022_raw = load_data(train_path, '2022 Training Data')
    if train_2022_raw.empty:
        logging.error("Training data is empty or could not be loaded. Exiting experiment.")
        return None

    # Initialize Feature Engineer with ablation flags
    fe = FeatureEngineer(
        disable_aggregate_stats=ablation_no_aggregate_stats,
        disable_borough_features=ablation_no_borough_features
    )

    X_full_2022, y_full_2022 = fe.fit(train_2022_raw, aux_data_dir)

    if X_full_2022.empty or X_full_2022.shape[1] == 0:
        logging.error("Feature engineering resulted in an empty feature set. Exiting experiment.")
        return None

    X_train, X_val, y_train, y_val = train_test_split(
        X_full_2022, y_full_2022, test_size=0.2, random_state=42
    )

    logging.info(f"Training data shape: {X_train.shape}, Validation data shape: {X_val.shape}")

    # --- Model Training ---
    logging.info("Training RandomForestRegressor model...")
    rf_model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1,
                                     min_samples_leaf=5, min_samples_split=rf_min_samples_split)
    rf_model.fit(X_train, y_train)
    logging.info("Model training complete.")

    # --- Validation Prediction and Evaluation ---
    val_predictions = rf_model.predict(X_val)
    val_predictions[val_predictions < 0] = 0 # Ensure predictions are non-negative
    val_predictions = np.round(val_predictions).astype(int) # Round to nearest integer

    val_rmse = np.sqrt(mean_squared_error(y_val, val_predictions))
    logging.info(f"Validation RMSE: {val_rmse:.4f}")
    return val_rmse

# Main block for running ablations
if __name__ == '__main__':
    # Use argparse for default paths, but ignore test_path for this ablation script
    parser = argparse.ArgumentParser(description="Ablation study for parking violation prediction.")
    parser.add_argument("--train-path", type=str, default="./input/violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--aux-data-dir", type=str, default="./input",
                        help="Directory containing auxiliary data CSV files.")
    
    args = parser.parse_args()

    results = {}

    # --- Baseline Run ---
    print("\n--- Running Baseline Experiment ---")
    baseline_rmse = run_experiment(args.train_path, args.aux_data_dir)
    results['Baseline'] = baseline_rmse
    print(f"Baseline Validation RMSE: {baseline_rmse:.4f}\n")

    # --- Ablation 1: No Aggregate Statistics Features ---
    print("\n--- Running Ablation: No Aggregate Statistics Features ---")
    ablation1_rmse = run_experiment(args.train_path, args.aux_data_dir,
                                    ablation_no_aggregate_stats=True)
    results['No Aggregate Stats Features'] = ablation1_rmse
    if baseline_rmse is not None and ablation1_rmse is not None:
        print(f"Ablation (No Aggregate Stats Features) RMSE: {ablation1_rmse:.4f} (Change: {ablation1_rmse - baseline_rmse:+.4f})\n")
    else:
        print(f"Ablation (No Aggregate Stats Features) RMSE: {ablation1_rmse}\n")


    # --- Ablation 2: No Borough-related Features ---
    print("\n--- Running Ablation: No Borough-related Features ---")
    ablation2_rmse = run_experiment(args.train_path, args.aux_data_dir,
                                    ablation_no_borough_features=True)
    results['No Borough Features'] = ablation2_rmse
    if baseline_rmse is not None and ablation2_rmse is not None:
        print(f"Ablation (No Borough Features) RMSE: {ablation2_rmse:.4f} (Change: {ablation2_rmse - baseline_rmse:+.4f})\n")
    else:
        print(f"Ablation (No Borough Features) RMSE: {ablation2_rmse}\n")

    # --- Ablation 3: RandomForest min_samples_split=10 ---
    print("\n--- Running Ablation: RandomForest min_samples_split=10 ---")
    ablation3_rmse = run_experiment(args.train_path, args.aux_data_dir,
                                    rf_min_samples_split=10)
    results['RF min_samples_split=10'] = ablation3_rmse
    if baseline_rmse is not None and ablation3_rmse is not None:
        print(f"Ablation (RF min_samples_split=10) RMSE: {ablation3_rmse:.4f} (Change: {ablation3_rmse - baseline_rmse:+.4f})\n")
    else:
        print(f"Ablation (RF min_samples_split=10) RMSE: {ablation3_rmse}\n")


    print("\n--- Ablation Study Summary ---")
    if baseline_rmse is not None:
        print(f"Baseline RMSE: {baseline_rmse:.4f}")
    else:
        print(f"Baseline RMSE: {baseline_rmse}")
        
    most_impactful_name = "None"
    max_abs_change = 0.0
    
    for name, rmse in results.items():
        if name == 'Baseline' or rmse is None or baseline_rmse is None:
            continue
        change = rmse - baseline_rmse
        print(f"- {name}: RMSE {rmse:.4f} (Change: {change:+.4f})")
        
        if abs(change) > max_abs_change:
            max_abs_change = abs(change)
            most_impactful_name = name
    
    if most_impactful_name != "None" and max_abs_change > 1e-6: # Check for non-negligible change
        print(f"\nThe part of the code that contributed the most to the overall performance (largest absolute change in RMSE) is: '{most_impactful_name}'.")
    else:
        print("\nAll ablations had negligible or no observable impact on performance.")

