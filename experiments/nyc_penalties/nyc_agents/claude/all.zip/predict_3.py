#!/usr/bin/env python3
"""
NYC Parking Violations — Prediction Pipeline
=============================================
Predicts future violation counts per (street_name, violation_type) from 2022 data
and corpus feature augmentation.

Usage:
  python predict.py
  python predict.py --test-path violations_per_street_2023.csv
  python predict.py --train-path custom.csv --test-path test.csv --output out.csv

Test/eval file schema:
  Street Name, Violation Description[, violation_count]
  If violation_count is present → score RMSE; otherwise → pure prediction.
"""

import argparse
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import GroupShuffleSplit

warnings.filterwarnings("ignore")

# ──────────────────────────────────────────────────────────────────────────────
# Default paths (relative to this script)
# ──────────────────────────────────────────────────────────────────────────────
_HERE = Path(__file__).parent
DEFAULT_TRAIN_PATH = _HERE / "violations_per_street_2022.csv"
DEFAULT_TEST_PATH = "../../violations_per_street_2023.csv"   # set to e.g. _HERE / "violations_per_street_2023.csv" when available
DEFAULT_CORPUS_DIR = _HERE / "corpus"
DEFAULT_OUTPUT = "submission.csv"


# ──────────────────────────────────────────────────────────────────────────────
# Data loading
# ──────────────────────────────────────────────────────────────────────────────
def load_core(path) -> pd.DataFrame:
    """Load violations CSV; normalises column names."""
    df = pd.read_csv(path)
    df.columns = df.columns.str.strip()
    rename = {}
    for c in df.columns:
        lc = c.lower().replace(" ", "_").strip("_")
        if lc == "street_name" or ("street" in lc and "name" in lc):
            rename[c] = "street_name"
        elif lc in ("violation_description", "violation_type", "violation_desc") or (
            "violation" in lc and ("desc" in lc or "type" in lc)
        ):
            rename[c] = "violation_type"
        elif lc == "violation_count" or ("violation" in lc and "count" in lc):
            rename[c] = "violation_count"
    df = df.rename(columns=rename)
    df["street_name"] = df["street_name"].str.strip().str.upper()
    df["violation_type"] = df["violation_type"].str.strip()
    return df


# ──────────────────────────────────────────────────────────────────────────────
# Corpus loaders — each returns a DataFrame indexed by street_name
# ──────────────────────────────────────────────────────────────────────────────
def _parquet(path: Path, cols=None) -> pd.DataFrame | None:
    if not path.exists():
        return None
    try:
        return pd.read_parquet(path, columns=cols)
    except Exception as e:
        print(f"  [warn] {path.name}: {e}")
        return None


def _norm_street(s: pd.Series) -> pd.Series:
    return s.str.strip().str.upper()


def corpus_parking_meters(d: Path) -> pd.DataFrame | None:
    df = _parquet(
        d / "parking_meters_locations_and_status__693u-uax6.parquet",
        cols=["On_Street", "Status"],
    )
    if df is None:
        return None
    df["street_name"] = _norm_street(df["On_Street"])
    return df.groupby("street_name").agg(
        meter_count=("On_Street", "count"),
        active_meter_frac=("Status", lambda x: (x == "Active").mean()),
    )


def corpus_street_ratings(d: Path) -> pd.DataFrame | None:
    df = _parquet(
        d / "street_pavement_ratings__6yyb-pb25.parquet",
        cols=["OnStreetName", "SystemRating"],
    )
    if df is None:
        return None
    df["street_name"] = _norm_street(df["OnStreetName"])
    return (
        df.groupby("street_name")["SystemRating"]
        .agg(pavement_mean="mean", pavement_min="min")
    )


def corpus_pluto(d: Path) -> pd.DataFrame | None:
    want = ["address", "assesstot", "numbldgs", "numfloors",
            "landuse", "lotarea", "unitsres", "unitstotal"]
    df = _parquet(
        d / "primary_land_use_tax_lot_output_pluto__64uk-42ks.parquet",
        cols=want,
    )
    if df is None:
        return None
    # Strip house number from "NUMBER STREETNAME" address format
    df["street_name"] = (
        df["address"]
        .str.replace(r"^\d+[\-\d]*\s+", "", regex=True)
        .str.strip()
        .str.upper()
    )
    for col in ["assesstot", "numbldgs", "numfloors", "lotarea", "unitsres", "unitstotal"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    return df.groupby("street_name").agg(
        pluto_assesstot=("assesstot", "mean"),
        pluto_bldgs=("numbldgs", "sum"),
        pluto_floors=("numfloors", "mean"),
        pluto_parcels=("address", "count"),
        pluto_landuses=("landuse", "nunique"),
        pluto_unitsres=("unitsres", "sum"),
    )


def corpus_dob(d: Path) -> pd.DataFrame | None:
    df = _parquet(d / "dob_violations__3h2n-5cm9.parquet", cols=["STREET"])
    if df is None:
        return None
    df["street_name"] = _norm_street(df["STREET"])
    return df.groupby("street_name").size().rename("dob_viols").to_frame()


def corpus_dob_safety(d: Path) -> pd.DataFrame | None:
    df = _parquet(d / "dob_safety_violations__855j-jady.parquet", cols=["Street"])
    if df is None:
        return None
    df["street_name"] = _norm_street(df["Street"])
    return df.groupby("street_name").size().rename("dob_safety_viols").to_frame()


def corpus_speed_limits(d: Path) -> pd.DataFrame | None:
    df = _parquet(
        d / "vzv_speed_limits__5mad-ntua.parquet",
        cols=["street", "postvz_sl"],
    )
    if df is None:
        return None
    df["street_name"] = _norm_street(df["street"])
    df["postvz_sl"] = pd.to_numeric(df["postvz_sl"], errors="coerce")
    return df.groupby("street_name")["postvz_sl"].agg(
        speed_limit_mean="mean",
        speed_limit_min="min",
    )


def load_corpus(corpus_dir: Path) -> pd.DataFrame | None:
    """Load and outer-join all corpus feature tables on street_name."""
    sources = [
        ("parking meters",    corpus_parking_meters(corpus_dir)),
        ("street ratings",    corpus_street_ratings(corpus_dir)),
        ("PLUTO",             corpus_pluto(corpus_dir)),
        ("DOB violations",    corpus_dob(corpus_dir)),
        ("DOB safety",        corpus_dob_safety(corpus_dir)),
        ("speed limits",      corpus_speed_limits(corpus_dir)),
    ]
    merged = None
    for label, src in sources:
        if src is not None:
            print(f"  [corpus] {label}: {len(src):,} streets")
            merged = src if merged is None else merged.join(src, how="outer")
    return merged


# ──────────────────────────────────────────────────────────────────────────────
# Training statistics
# ──────────────────────────────────────────────────────────────────────────────
def compute_stats(df: pd.DataFrame) -> dict:
    """Compute per-street, per-vtype, and per-key statistics from df."""

    street = df.groupby("street_name")["violation_count"].agg(
        street_total="sum",
        street_mean="mean",
        street_median="median",
        street_max="max",
        street_std="std",
        street_vtype_n="count",
    )

    vtype = df.groupby("violation_type")["violation_count"].agg(
        vtype_total="sum",
        vtype_mean="mean",
        vtype_median="median",
        vtype_std="std",
        vtype_street_n="count",
    )

    # Actual count for each (street, vtype) key in training
    key = (
        df.groupby(["street_name", "violation_type"])["violation_count"]
        .sum()
        .rename("key_count")
    )

    # Fraction this vtype makes up on each street
    vtype_frac = (
        key
        / key.index.get_level_values("street_name").map(street["street_total"])
    ).rename("vtype_frac")

    # Global share per vtype (fallback for unseen streets)
    vtot = vtype["vtype_total"]
    vtype_global_frac = (vtot / vtot.sum()).rename("vtype_global_frac")

    return dict(
        street=street,
        vtype=vtype,
        key=key,
        vtype_frac=vtype_frac,
        vtype_global_frac=vtype_global_frac,
    )


# ──────────────────────────────────────────────────────────────────────────────
# Feature engineering
# ──────────────────────────────────────────────────────────────────────────────
_VTYPE_ID = {
    "14-No Standing": 0,
    "20A-No Parking (Non-COM)": 1,
    "40-Fire Hydrant": 2,
    "70A-Reg. Sticker Expired (NYS)": 3,
    "21-No Parking (street clean)": 4,
    "71A-Insp Sticker Expired (NYS)": 5,
    "38-Failure to Dsplay Meter Rec": 6,
    "FAILURE TO STOP AT RED LIGHT": 7,
    "BUS LANE VIOLATION": 8,
    "PHTO SCHOOL ZN SPEED VIOLATION": 9,
}

ALL_FEAT_COLS = [
    "vtype_id",
    "street_total", "street_mean", "street_median", "street_max", "street_std", "street_vtype_n",
    "vtype_total", "vtype_mean", "vtype_median", "vtype_std", "vtype_street_n",
    "vtype_frac", "vtype_global_frac",
    "prior_count", "log_street_total", "log_vtype_mean", "log_prior", "street_cv",
    # corpus
    "meter_count", "active_meter_frac",
    "pavement_mean", "pavement_min",
    "pluto_assesstot", "pluto_bldgs", "pluto_floors", "pluto_parcels",
    "pluto_landuses", "pluto_unitsres",
    "dob_viols",
    "dob_safety_viols",
    "speed_limit_mean", "speed_limit_min",
]


def featurize(
    df: pd.DataFrame,
    stats: dict,
    corpus: pd.DataFrame | None,
) -> pd.DataFrame:
    """
    Build model-ready feature matrix for df using pre-computed stats.
    df must have: street_name, violation_type.
    Crucially: all statistics come from stats (training data only) — no leakage.
    """
    f = df[["street_name", "violation_type"]].copy().reset_index(drop=True)

    f["vtype_id"] = (
        f["violation_type"].map(_VTYPE_ID).fillna(len(_VTYPE_ID)).astype(int)
    )

    # Street- and vtype-level aggregates (left join)
    f = f.merge(
        stats["street"].reset_index(), on="street_name", how="left"
    )
    f = f.merge(
        stats["vtype"].reset_index(), on="violation_type", how="left"
    )

    # Per-key fraction (NaN for unseen keys)
    f = f.merge(
        stats["vtype_frac"].reset_index(), on=["street_name", "violation_type"], how="left"
    )

    # Global vtype fraction (always available for known violation types)
    f = f.merge(
        stats["vtype_global_frac"].reset_index(), on="violation_type", how="left"
    )

    # Prior count:
    #   seen key → vtype_frac × street_total
    #   unseen key on known street → vtype_global_frac × street_total
    #   unknown street → vtype_mean (global average for this vtype)
    frac = f["vtype_frac"].fillna(f["vtype_global_frac"])
    total = f["street_total"].fillna(f["vtype_mean"])
    f["prior_count"] = (frac * total).clip(lower=0)

    # Log transforms
    f["log_street_total"] = np.log1p(f["street_total"].fillna(0))
    f["log_vtype_mean"] = np.log1p(f["vtype_mean"].fillna(0))
    f["log_prior"] = np.log1p(f["prior_count"].fillna(0))

    # Street coefficient of variation
    f["street_cv"] = (
        f["street_std"].fillna(0) / f["street_mean"].replace(0, np.nan)
    ).fillna(0)

    # Corpus features
    if corpus is not None:
        f = f.merge(corpus.reset_index(), on="street_name", how="left")

    return f


def available_cols(df: pd.DataFrame) -> list[str]:
    return [c for c in ALL_FEAT_COLS if c in df.columns]


# ──────────────────────────────────────────────────────────────────────────────
# Model
# ──────────────────────────────────────────────────────────────────────────────
def train_model(feat_df: pd.DataFrame, target: np.ndarray):
    """Train LightGBM regressor; returns (model, feature_column_list)."""
    try:
        import lightgbm as lgb
    except ImportError:
        raise ImportError("lightgbm required: pip install lightgbm")

    cols = available_cols(feat_df)
    X = feat_df[cols].fillna(-1).astype(float)

    model = lgb.LGBMRegressor(
        objective="regression_l2",
        n_estimators=1500,
        learning_rate=0.02,
        num_leaves=255,
        min_child_samples=5,
        subsample=0.8,
        subsample_freq=1,
        colsample_bytree=0.8,
        reg_alpha=0.1,
        reg_lambda=0.5,
        n_jobs=-1,
        random_state=42,
        verbose=-1,
    )
    model.fit(X, target)
    return model, cols


def predict(model, cols: list[str], feat_df: pd.DataFrame) -> np.ndarray:
    X = feat_df[cols].fillna(-1).astype(float)
    return np.maximum(np.round(model.predict(X)), 0).astype(int)


# ──────────────────────────────────────────────────────────────────────────────
# Diagnostics
# ──────────────────────────────────────────────────────────────────────────────
def unseen_report(train_df: pd.DataFrame, eval_df: pd.DataFrame) -> dict:
    train_keys = set(zip(train_df["street_name"], train_df["violation_type"]))
    train_streets = set(train_df["street_name"])
    train_vtypes = set(train_df["violation_type"])
    n = len(eval_df)
    uk = sum(1 for k in zip(eval_df["street_name"], eval_df["violation_type"]) if k not in train_keys)
    us = sum(1 for s in eval_df["street_name"] if s not in train_streets)
    uv = sum(1 for v in eval_df["violation_type"] if v not in train_vtypes)
    return {"total": n, "unseen_key": uk, "unseen_street": us, "unseen_vtype": uv}


# ──────────────────────────────────────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        description="NYC Parking Violations — predict future counts per (street_name, violation_type).",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python predict.py
  python predict.py --test-path violations_per_street_2023.csv
  python predict.py --train-path violations_per_street_2022.csv \\
                    --test-path test.csv --output submission.csv
        """,
    )
    parser.add_argument(
        "--train-path",
        default=str(DEFAULT_TRAIN_PATH),
        help="Training CSV (default: violations_per_street_2022.csv)",
    )
    parser.add_argument(
        "--test-path",
        default=str(DEFAULT_TEST_PATH) if DEFAULT_TEST_PATH is not None else None,
        help="Test/eval CSV — Street Name, Violation Description[, violation_count]",
    )
    parser.add_argument(
        "--corpus-dir",
        default=str(DEFAULT_CORPUS_DIR),
        help="Directory with augmentation parquets (default: ./corpus/)",
    )
    parser.add_argument(
        "--output",
        default=DEFAULT_OUTPUT,
        help="Output submission CSV (default: submission.csv)",
    )
    args = parser.parse_args()

    corpus_dir = Path(args.corpus_dir)
    SEP = "=" * 62

    print(f"\n{SEP}")
    print("  NYC Parking Violations — Prediction Pipeline")
    print(SEP)

    # ── 1. Training data ──────────────────────────────────────────────────────
    print(f"\n[1] Training data: {args.train_path}")
    train = load_core(args.train_path)
    print(
        f"    {len(train):,} rows | "
        f"{train['street_name'].nunique():,} streets | "
        f"{train['violation_type'].nunique()} violation types"
    )

    # ── 2. Corpus features ────────────────────────────────────────────────────
    print(f"\n[2] Corpus features from: {corpus_dir}")
    corpus = load_corpus(corpus_dir)

    # ── 3. Development validation (grouped holdout by street) ─────────────────
    print("\n[3] Development validation — grouped holdout (80 / 20 by street_name)")
    gss = GroupShuffleSplit(n_splits=1, test_size=0.20, random_state=42)
    idx_tr, idx_val = next(gss.split(train, groups=train["street_name"]))
    df_tr = train.iloc[idx_tr].reset_index(drop=True)
    df_val = train.iloc[idx_val].reset_index(drop=True)

    stats_tr = compute_stats(df_tr)
    feat_tr = featurize(df_tr, stats_tr, corpus)
    feat_val = featurize(df_val, stats_tr, corpus)

    val_model, val_cols = train_model(feat_tr, df_tr["violation_count"].values)
    val_preds = predict(val_model, val_cols, feat_val)

    val_rmse = np.sqrt(mean_squared_error(df_val["violation_count"].values, val_preds))
    rpt = unseen_report(df_tr, df_val)
    pct = 100 * rpt["unseen_key"] / rpt["total"]

    print(f"    Val RMSE        : {val_rmse:.2f}")
    print(f"    Unseen keys     : {rpt['unseen_key']}/{rpt['total']} ({pct:.1f}%)")
    print(f"    Unseen streets  : {rpt['unseen_street']}")
    print(f"    Fallback used   : vtype_global_frac × street_total (or vtype_mean for unknown streets)")

    # ── 4. Final model (full 2022 data) ───────────────────────────────────────
    print(f"\n[4] Training final model on full {len(train):,} rows")
    stats_full = compute_stats(train)
    feat_full = featurize(train, stats_full, corpus)
    final_model, final_cols = train_model(feat_full, train["violation_count"].values)
    print("    Done.")

    # ── 5. Test / eval file ───────────────────────────────────────────────────
    if args.test_path:
        print(f"\n[5] Test/eval: {args.test_path}")
        test_raw = load_core(args.test_path)

        has_gt = (
            "violation_count" in test_raw.columns
            and test_raw["violation_count"].notna().any()
        )
        print(
            f"    {len(test_raw):,} rows | "
            f"{test_raw['street_name'].nunique():,} streets | "
            f"mode: {'score (ground-truth present)' if has_gt else 'predict (keys only)'}"
        )

        rpt_t = unseen_report(train, test_raw)
        pct_t = 100 * rpt_t["unseen_key"] / rpt_t["total"]
        print(f"    Unseen keys     : {rpt_t['unseen_key']}/{rpt_t['total']} ({pct_t:.1f}%)")
        print(f"    Unseen streets  : {rpt_t['unseen_street']}")
        print(f"    Unseen vtypes   : {rpt_t['unseen_vtype']}")
        print(f"    Fallback used   : vtype_global_frac × street_total (or vtype_mean for unknown streets)")

        test_feat = featurize(test_raw, stats_full, corpus)
        test_preds = predict(final_model, final_cols, test_feat)

        if has_gt:
            gt = test_raw["violation_count"].fillna(0).values
            test_rmse = np.sqrt(mean_squared_error(gt, test_preds))
            print(f"    Test RMSE       : {test_rmse:.2f}")

        submission = pd.DataFrame({
            "street_name": test_raw["street_name"].values,
            "violation_type": test_raw["violation_type"].values,
            "predicted_count": test_preds,
        })
    else:
        # No test file: emit predictions for the 2022 key space as a reference
        print("\n[5] No --test-path provided — emitting predictions for 2022 key space.")
        ref_preds = predict(final_model, final_cols, feat_full)
        submission = pd.DataFrame({
            "street_name": train["street_name"].values,
            "violation_type": train["violation_type"].values,
            "predicted_count": ref_preds,
        })

    submission.to_csv(args.output, index=False)
    print(f"\n    Saved → {args.output}  ({len(submission):,} rows)")
    print(f"{SEP}\n")


if __name__ == "__main__":
    main()
