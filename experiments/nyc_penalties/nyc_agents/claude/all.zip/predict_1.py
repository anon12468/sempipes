#!/usr/bin/env python3
"""
NYC Parking Violation Count Predictor
======================================
Predicts 2023 parking violation counts per (street_name, violation_type) pair
using 2022 counts as the primary signal and corpus augmentation features.

Usage
-----
# Dev mode (train + validate on 2022 data only):
    python predict.py

# Predict on a test file (keys only, no ground truth):
    python predict.py --test-path /path/to/test.csv

# Predict + score (test file includes violation_count ground truth):
    python predict.py --test-path /path/to/eval.csv

# Custom paths:
    python predict.py --train-path violations_per_street_2022.csv \\
                      --test-path  violations_per_street_2023.csv \\
                      --corpus-path corpus/ \\
                      --output-path submission.csv

Environment variables (fallbacks for CLI args):
    TRAIN_PATH, TEST_PATH, CORPUS_PATH, OUTPUT_PATH
"""

import argparse
import math
import os
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import GroupShuffleSplit
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder

warnings.filterwarnings("ignore")

# ─── Defaults ─────────────────────────────────────────────────────────────────

SCRIPT_DIR = Path(__file__).parent
DEFAULT_TRAIN  = str(SCRIPT_DIR / "violations_per_street_2022.csv")
DEFAULT_CORPUS = str(SCRIPT_DIR / "corpus")
DEFAULT_OUTPUT = "submission.csv"

# ─── CLI ──────────────────────────────────────────────────────────────────────

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="NYC Parking Violation Predictor")
    p.add_argument("--train-path",  default=os.environ.get("TRAIN_PATH",  DEFAULT_TRAIN))
    p.add_argument("--test-path",   default=os.environ.get("TEST_PATH",   "../../violations_per_street_2023.csv"))
    p.add_argument("--corpus-path", default=os.environ.get("CORPUS_PATH", DEFAULT_CORPUS))
    p.add_argument("--output-path", default=os.environ.get("OUTPUT_PATH", DEFAULT_OUTPUT))
    p.add_argument("--val-size",    default=0.20, type=float,
                   help="Fraction of streets held out for development validation (default 0.20)")
    p.add_argument("--seed",        default=42, type=int)
    return p.parse_args()

# ─── Data I/O ─────────────────────────────────────────────────────────────────

def load_training_data(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df.columns = ["street_name", "violation_type", "violation_count"]
    df["street_name"]   = df["street_name"].str.strip().str.upper()
    df["violation_type"] = df["violation_type"].str.strip()
    df["violation_count"] = df["violation_count"].astype(float)
    return df


def load_test_data(path: str) -> tuple[pd.DataFrame, bool]:
    """
    Load test/eval file.
    Returns (df, has_ground_truth).
    has_ground_truth is True when violation_count is present and non-null.
    """
    raw = pd.read_csv(path)
    raw.columns = raw.columns.str.strip()

    # Accept either the original column names or normalised snake_case
    rename = {}
    for c in raw.columns:
        cl = c.lower().replace(" ", "_")
        if cl in ("street_name", "street name"):
            rename[c] = "street_name"
        elif cl in ("violation_description", "violation_type",
                    "violation description", "violation type"):
            rename[c] = "violation_type"
        elif cl in ("violation_count", "violation count"):
            rename[c] = "violation_count"
    df = raw.rename(columns=rename)

    df["street_name"]   = df["street_name"].str.strip().str.upper()
    df["violation_type"] = df["violation_type"].str.strip()

    has_gt = (
        "violation_count" in df.columns
        and df["violation_count"].notna().all()
        and df["violation_count"].ne("").all()
    )
    if has_gt:
        df["violation_count"] = df["violation_count"].astype(float)
    return df, has_gt

# ─── Street-name normalisation (for corpus joins) ─────────────────────────────

_SUFFIX_MAP = [
    (" STREET", " ST"), (" AVENUE", " AVE"), (" BOULEVARD", " BLVD"),
    (" DRIVE", " DR"), (" ROAD", " RD"), (" PLACE", " PL"),
    (" LANE", " LN"), (" COURT", " CT"), (" TERRACE", " TER"),
]

def _norm(s) -> str:
    if pd.isna(s):
        return ""
    s = str(s).strip().upper()
    for old, new in _SUFFIX_MAP:
        s = s.replace(old, new)
    return s

# ─── Feature engineering ──────────────────────────────────────────────────────

def build_street_stats(df: pd.DataFrame) -> pd.DataFrame:
    stats = df.groupby("street_name").agg(
        street_total   = ("violation_count", "sum"),
        street_mean    = ("violation_count", "mean"),
        street_n_types = ("violation_type",  "nunique"),
        street_max     = ("violation_count", "max"),
    ).reset_index()
    stats["street_log_total"] = np.log1p(stats["street_total"])
    return stats


def build_vtype_stats(df: pd.DataFrame) -> pd.DataFrame:
    stats = df.groupby("violation_type").agg(
        vtype_total    = ("violation_count", "sum"),
        vtype_mean     = ("violation_count", "mean"),
        vtype_n_streets= ("street_name",     "nunique"),
        vtype_median   = ("violation_count", "median"),
        vtype_p75      = ("violation_count", lambda x: x.quantile(0.75)),
        vtype_p90      = ("violation_count", lambda x: x.quantile(0.90)),
    ).reset_index()
    stats["vtype_log_total"] = np.log1p(stats["vtype_total"])
    return stats


def load_corpus_features(corpus_path: str) -> dict:
    """Load and aggregate each relevant corpus file into street-level lookup tables."""
    corpus = Path(corpus_path)
    features: dict[str, pd.DataFrame] = {}

    # 1. Parking meters — count per street
    f = corpus / "parking_meters_locations_and_status__693u-uax6.parquet"
    if f.exists():
        try:
            m = pd.read_parquet(f)
            m["street_norm"] = m["On_Street"].apply(_norm)
            tbl = m.groupby("street_norm").size().rename("n_meters").reset_index()
            features["meters"] = tbl
            print(f"  [corpus] parking meters: {len(tbl):,} streets")
        except Exception as e:
            print(f"  [corpus] parking meters load error: {e}")

    # 2. Speed limits — average posted speed per street
    f = corpus / "vzv_speed_limits__5mad-ntua.parquet"
    if f.exists():
        try:
            s = pd.read_parquet(f)
            s["street_norm"] = s["street"].apply(_norm)
            tbl = s.groupby("street_norm").agg(
                avg_speed_limit = ("postvz_sl", "mean"),
                min_speed_limit = ("postvz_sl", "min"),
            ).reset_index()
            features["speed"] = tbl
            print(f"  [corpus] speed limits: {len(tbl):,} streets")
        except Exception as e:
            print(f"  [corpus] speed limits load error: {e}")

    # 3. Pavement ratings — average condition score per street
    f = corpus / "street_pavement_ratings__6yyb-pb25.parquet"
    if f.exists():
        try:
            p = pd.read_parquet(f)
            p["street_norm"] = p["OnStreetName"].apply(_norm)
            tbl = p.groupby("street_norm").agg(
                avg_pavement = ("SystemRating", "mean"),
                min_pavement = ("SystemRating", "min"),
            ).reset_index()
            features["pavement"] = tbl
            print(f"  [corpus] pavement ratings: {len(tbl):,} streets")
        except Exception as e:
            print(f"  [corpus] pavement ratings load error: {e}")

    # 4. Traffic volume — aggregate hourly counts across all years as a relative rank
    f = corpus / "vehicle_classification_counts_2011_2025__96ay-ea4r.parquet"
    if f.exists():
        try:
            t = pd.read_parquet(f)
            t["street_norm"] = t["Roadway Name"].apply(_norm)
            # All time-of-day columns are after the first 6 metadata cols
            hour_cols = [c for c in t.columns if "AM" in c or "PM" in c]
            t["daily_total"] = t[hour_cols].apply(pd.to_numeric, errors="coerce").sum(axis=1)
            tbl = t.groupby("street_norm").agg(
                traffic_total = ("daily_total", "sum"),
                traffic_mean  = ("daily_total", "mean"),
            ).reset_index()
            tbl["log_traffic"] = np.log1p(tbl["traffic_total"])
            features["traffic"] = tbl
            print(f"  [corpus] traffic volume: {len(tbl):,} streets")
        except Exception as e:
            print(f"  [corpus] traffic volume load error: {e}")

    return features


def attach_all_features(
    df: pd.DataFrame,
    street_stats: pd.DataFrame,
    vtype_stats: pd.DataFrame,
    vtype_enc: LabelEncoder,
    corpus: dict,
    count_lookup: dict,          # {(street, vtype): count_2022} from full train
    global_vtype_mean: dict,     # {vtype: mean_count}
    global_mean: float,
) -> pd.DataFrame:
    """
    Attach all features to df (which must have street_name, violation_type columns).
    count_lookup maps (street_name, violation_type) → 2022 count; use 0 if missing.
    """
    result = df[["street_name", "violation_type"]].copy()

    # Direct 2022 count feature (0 for unseen pairs)
    result["count_2022"] = result.apply(
        lambda r: count_lookup.get((r["street_name"], r["violation_type"]), 0.0),
        axis=1,
    )
    result["log_count_2022"] = np.log1p(result["count_2022"])
    result["is_seen"]         = (result["count_2022"] > 0).astype(int)

    # Street-level aggregates
    result = result.merge(street_stats, on="street_name", how="left")

    # Violation-type aggregates
    result = result.merge(vtype_stats, on="violation_type", how="left")

    # Violation-type integer encoding (0–9; unknown → -1)
    known_mask = result["violation_type"].isin(vtype_enc.classes_)
    result["vtype_enc"] = -1
    result.loc[known_mask, "vtype_enc"] = vtype_enc.transform(
        result.loc[known_mask, "violation_type"]
    )

    # Corpus features (join on normalised street name)
    result["street_norm"] = result["street_name"].apply(_norm)

    if "meters" in corpus:
        result = result.merge(corpus["meters"], on="street_norm", how="left")
    if "speed" in corpus:
        result = result.merge(corpus["speed"], on="street_norm", how="left")
    if "pavement" in corpus:
        result = result.merge(corpus["pavement"], on="street_norm", how="left")
    if "traffic" in corpus:
        result = result.merge(corpus["traffic"][["street_norm","log_traffic"]], on="street_norm", how="left")

    return result


FEATURE_COLS = [
    "log_count_2022",
    "is_seen",
    "street_log_total",
    "street_mean",
    "street_n_types",
    "vtype_log_total",
    "vtype_mean",
    "vtype_n_streets",
    "vtype_median",
    "vtype_p75",
    "vtype_p90",
    "vtype_enc",
    # corpus (present only when join succeeds; NaN → filled later)
    "n_meters",
    "avg_speed_limit",
    "min_speed_limit",
    "avg_pavement",
    "min_pavement",
    "log_traffic",
]

def get_X(feat_df: pd.DataFrame) -> np.ndarray:
    cols = [c for c in FEATURE_COLS if c in feat_df.columns]
    return feat_df[cols].fillna(-1).values

# ─── Model ────────────────────────────────────────────────────────────────────

def train_model(X_train: np.ndarray, y_train: np.ndarray, seed: int,
                X_val=None, y_val=None, n_iter: int = 0, verbose_name: str = ""):
    """
    Train LightGBM (falls back to sklearn GBT if lightgbm not installed).

    X_val / y_val : optional held-out set for early stopping.
    n_iter        : when > 0, use this fixed n_estimators (no early stopping).
                    Useful for the final model trained on the full dataset.
    """
    try:
        import lightgbm as lgb  # type: ignore

        fixed = n_iter > 0
        model = lgb.LGBMRegressor(
            n_estimators       = n_iter if fixed else 3000,
            learning_rate      = 0.02,
            num_leaves         = 127,
            min_child_samples  = 10,
            subsample          = 0.8,
            colsample_bytree   = 0.8,
            reg_alpha          = 0.1,
            reg_lambda         = 1.0,
            random_state       = seed,
            n_jobs             = -1,
            verbose            = -1,
        )

        if fixed:
            model.fit(X_train, y_train)
            print(f"  Model: LightGBM {verbose_name}  (fixed n_iter={n_iter})")
        else:
            es_set = [(X_val, y_val)] if X_val is not None else None
            callbacks = [lgb.log_evaluation(-1)]
            if es_set:
                callbacks.insert(0, lgb.early_stopping(100, verbose=False))
            model.fit(X_train, y_train, eval_set=es_set, callbacks=callbacks)
            best = getattr(model, "best_iteration_", model.n_estimators)
            print(f"  Model: LightGBM {verbose_name}  (best iter={best})")
        return model, True

    except ImportError:
        from sklearn.ensemble import GradientBoostingRegressor  # type: ignore

        n = n_iter if n_iter > 0 else 500
        model = GradientBoostingRegressor(
            n_estimators=n, learning_rate=0.05,
            max_depth=6, subsample=0.8, random_state=seed,
        )
        model.fit(X_train, y_train)
        print("  Model: sklearn GradientBoostingRegressor (lightgbm not found)")
        return model, False


def feature_importances(model, feat_df: pd.DataFrame) -> None:
    """Print top feature importances if model supports it."""
    try:
        cols = [c for c in FEATURE_COLS if c in feat_df.columns]
        imp  = model.feature_importances_
        pairs = sorted(zip(cols, imp), key=lambda x: -x[1])
        print("\n      Feature importances (gain):")
        for name, score in pairs[:15]:
            bar = "█" * int(score / max(imp) * 20)
            print(f"        {name:<25s} {bar}")
    except Exception:
        pass


def rmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return math.sqrt(mean_squared_error(y_true, y_pred))


def clip_predict(model, X: np.ndarray) -> np.ndarray:
    """Predict log-scale, back-transform, clip negatives."""
    log_pred = model.predict(X)
    return np.maximum(np.expm1(log_pred), 0.0)

# ─── Main ─────────────────────────────────────────────────────────────────────

def main() -> None:
    args = parse_args()
    np.random.seed(args.seed)

    sep = "=" * 62
    print(sep)
    print("  NYC Parking Violation Count Predictor")
    print(sep)

    # ── 1. Load training data ──────────────────────────────────────
    print(f"\n[1/5] Training data: {args.train_path}")
    train = load_training_data(args.train_path)
    print(f"      Rows: {len(train):,}  |  Streets: {train['street_name'].nunique():,}"
          f"  |  Violation types: {train['violation_type'].nunique()}")
    print(f"      violation_count  mean={train['violation_count'].mean():.1f}"
          f"  median={train['violation_count'].median():.0f}"
          f"  max={train['violation_count'].max():.0f}")

    # ── 2. Build aggregate statistics ─────────────────────────────
    print("\n[2/5] Building aggregate features …")
    street_stats    = build_street_stats(train)
    vtype_stats     = build_vtype_stats(train)
    global_mean     = float(train["violation_count"].mean())
    global_median   = float(train["violation_count"].median())

    # Violation-type label encoder (fit on full training set)
    vtype_enc = LabelEncoder().fit(train["violation_type"])

    # Per-type mean (used in fallback predictions)
    global_vtype_mean = train.groupby("violation_type")["violation_count"].mean().to_dict()

    # Full (street, vtype) → count_2022 lookup
    count_lookup: dict = dict(
        zip(zip(train["street_name"], train["violation_type"]),
            train["violation_count"])
    )

    # ── 3. Load corpus augmentation ───────────────────────────────
    print("\n[3/5] Loading corpus augmentation …")
    corpus = load_corpus_features(args.corpus_path)

    # ── 4. Train & validate ───────────────────────────────────────
    print("\n[4/5] Training model …")

    feat = attach_all_features(
        train, street_stats, vtype_stats, vtype_enc,
        corpus, count_lookup, global_vtype_mean, global_mean,
    )

    y_log  = np.log1p(train["violation_count"].values)
    X_full = get_X(feat)

    used_cols = [c for c in FEATURE_COLS if c in feat.columns]
    print(f"      Feature columns ({len(used_cols)}): {used_cols}")

    # ── Validation A: hold out 20 % of streets ─────────────────────
    # Worst-case scenario: predicting entirely NEW streets in 2023.
    # log_count_2022 is masked to 0 for these streets.
    print(f"\n      Val-A (new streets): {int((1-args.val_size)*100)}/{int(args.val_size*100)}"
          f" street-group split …")
    gss = GroupShuffleSplit(n_splits=1, test_size=args.val_size, random_state=args.seed)
    tr_idx, val_idx = next(gss.split(X_full, y_log, groups=train["street_name"]))

    X_tr, X_val_a   = X_full[tr_idx], X_full[val_idx]
    y_tr            = y_log[tr_idx]
    y_val_a_log     = y_log[val_idx]
    y_val_a_raw     = train["violation_count"].values[val_idx]

    # Mask the direct-count feature for held-out streets (new-street simulation)
    X_val_a_masked = X_val_a.copy()
    X_val_a_masked[:, 0] = 0.0   # log_count_2022 → 0
    X_val_a_masked[:, 1] = 0.0   # is_seen        → 0

    model_a, _ = train_model(X_tr, y_tr, args.seed,
                              X_val=X_val_a, y_val=y_val_a_log,
                              verbose_name="(Val-A)")

    pred_a    = clip_predict(model_a, X_val_a_masked)
    rmse_a    = rmse(y_val_a_raw, pred_a)
    rmse_mean = rmse(y_val_a_raw, np.full_like(y_val_a_raw, global_mean))
    rmse_med  = rmse(y_val_a_raw, np.full_like(y_val_a_raw, global_median))

    # ── Validation B: random 20 % pair holdout ─────────────────────
    # Best-case scenario: all test pairs were seen in 2022 (most realistic for
    # year-over-year prediction).  log_count_2022 is available for training pairs;
    # for val pairs we build count_lookup from the 80% training split only.
    print(f"\n      Val-B (seen-pair YoY): random 80/20 split …")
    rng = np.random.default_rng(args.seed)
    rand_perm = rng.permutation(len(train))
    n_val_b   = int(args.val_size * len(train))
    val_b_idx, tr_b_idx = rand_perm[:n_val_b], rand_perm[n_val_b:]

    train_b = train.iloc[tr_b_idx].reset_index(drop=True)
    val_b   = train.iloc[val_b_idx].reset_index(drop=True)

    street_stats_b = build_street_stats(train_b)
    vtype_stats_b  = build_vtype_stats(train_b)
    count_lookup_b = dict(
        zip(zip(train_b["street_name"], train_b["violation_type"]),
            train_b["violation_count"])
    )
    global_vtype_mean_b = train_b.groupby("violation_type")["violation_count"].mean().to_dict()
    global_mean_b       = float(train_b["violation_count"].mean())

    feat_tr_b  = attach_all_features(
        train_b, street_stats_b, vtype_stats_b, vtype_enc,
        corpus, count_lookup_b, global_vtype_mean_b, global_mean_b,
    )
    feat_val_b = attach_all_features(
        val_b, street_stats_b, vtype_stats_b, vtype_enc,
        corpus, count_lookup_b, global_vtype_mean_b, global_mean_b,
    )
    X_tr_b   = get_X(feat_tr_b)
    X_val_b  = get_X(feat_val_b)
    y_tr_b   = np.log1p(train_b["violation_count"].values)
    y_val_b_log = np.log1p(val_b["violation_count"].values)
    y_val_b_raw = val_b["violation_count"].values

    model_b, _ = train_model(X_tr_b, y_tr_b, args.seed,
                              X_val=X_val_b, y_val=y_val_b_log,
                              verbose_name="(Val-B)")

    pred_b = clip_predict(model_b, X_val_b)
    rmse_b = rmse(y_val_b_raw, pred_b)
    # Identity baseline for Val-B: predict the 2022 count directly
    pred_b_identity = val_b.apply(
        lambda r: count_lookup_b.get((r["street_name"], r["violation_type"]),
                                      global_vtype_mean_b.get(r["violation_type"], global_mean_b)),
        axis=1,
    ).values
    rmse_b_identity = rmse(y_val_b_raw, pred_b_identity)

    # ── Print combined validation report ──────────────────────────
    print(f"\n      ╔══════════════════════════════════════════════════╗")
    print(f"      ║         Development Validation Results           ║")
    print(f"      ╠══════════════════════════════════════════════════╣")
    print(f"      ║ Val-A: NEW streets (20% street holdout)          ║")
    print(f"      ║   simulates: streets in 2023 not seen in 2022    ║")
    print(f"      ║   Model RMSE      : {rmse_a:>10.3f}                ║")
    print(f"      ║   Baseline (mean) : {rmse_mean:>10.3f}                ║")
    print(f"      ║   Baseline (med.) : {rmse_med:>10.3f}                ║")
    print(f"      ╠══════════════════════════════════════════════════╣")
    print(f"      ║ Val-B: SEEN pairs YoY (random 80/20 by pair)    ║")
    print(f"      ║   simulates: 2022 → 2023 for known pairs         ║")
    print(f"      ║   Model RMSE      : {rmse_b:>10.3f}                ║")
    print(f"      ║   Identity (2022) : {rmse_b_identity:>10.3f}                ║")
    print(f"      ╚══════════════════════════════════════════════════╝")
    print(f"\n      Interpretation:")
    print(f"        Val-B RMSE ({rmse_b:.0f}) is the YoY variation floor; the real 2023")
    print(f"        RMSE depends on how much counts change year-over-year.")

    feature_importances(model_b, feat_tr_b)

    # Re-train final model on all 2022 data for production inference.
    # Use the max best_iteration from Val-A and Val-B as the fixed iteration
    # count so we don't need a held-out set (avoids eval-on-train collapse).
    def _best_iter(m):
        return getattr(m, "best_iteration_", None) or getattr(m, "n_estimators_", 500)
    final_n_iter = max(_best_iter(model_a), _best_iter(model_b), 50)
    print(f"\n      Re-training final model on full 2022 data (n_iter={final_n_iter}) …")
    final_model, _ = train_model(X_full, y_log, args.seed,
                                  n_iter=final_n_iter, verbose_name="(final)")

    # ── 5. Test / eval prediction ─────────────────────────────────
    if args.test_path:
        print(f"\n[5/5] Generating predictions for: {args.test_path}")
        test_df, has_gt = load_test_data(args.test_path)
        print(f"      Test rows: {len(test_df):,}")

        # Report unseen-key statistics
        train_keys = set(zip(train["street_name"], train["violation_type"]))
        test_keys  = list(zip(test_df["street_name"], test_df["violation_type"]))
        n_unseen   = sum(1 for k in test_keys if k not in train_keys)
        pct_unseen = n_unseen / len(test_keys) * 100 if test_keys else 0.0

        train_streets = set(train["street_name"])
        n_new_streets = sum(
            1 for sn, _ in test_keys
            if sn not in train_streets
        )

        print(f"      Unseen (street, vtype) pairs : {n_unseen:,} / {len(test_keys):,}"
              f" ({pct_unseen:.1f}%)")
        print(f"      Streets not in 2022 training : {n_new_streets:,}")
        print(f"      Fallback for unseen pairs     : "
              "violation-type mean from 2022; global median if type also new")

        # Build features for test set
        test_feat = attach_all_features(
            test_df, street_stats, vtype_stats, vtype_enc,
            corpus, count_lookup, global_vtype_mean, global_mean,
        )
        X_test = get_X(test_feat)

        test_pred = clip_predict(final_model, X_test)
        test_pred_rounded = np.round(test_pred).astype(int)

        # Build submission
        submission = pd.DataFrame({
            "street_name"     : test_df["street_name"],
            "violation_type"  : test_df["violation_type"],
            "predicted_count" : test_pred_rounded,
        })
        submission.to_csv(args.output_path, index=False)
        print(f"\n      Saved: {args.output_path}  ({len(submission):,} rows)")

        # Score if ground truth present
        if has_gt:
            test_rmse = rmse(test_df["violation_count"].values, test_pred)
            print(f"\n      ── Test / Eval RMSE ──")
            print(f"      Test RMSE : {test_rmse:>10.3f}")

        print("\n      Sample predictions (first 10 rows):")
        print(submission.head(10).to_string(index=False))

    else:
        print("\n[5/5] No --test-path provided — skipping test prediction.")
        print("      Run with --test-path <file> to generate submission.csv.")

    print(f"\n{sep}")
    print("  Done.")
    print(sep)


if __name__ == "__main__":
    main()
