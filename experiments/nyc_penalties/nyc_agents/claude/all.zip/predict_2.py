#!/usr/bin/env python3
"""NYC Parking Violations Prediction Pipeline.

Predicts 2023 (street_name, violation_type) parking violation counts
using 2022 data and corpus augmentation features.

Design
──────
Two prediction regimes, handled by a single LightGBM model:

  Known pairs (street, vtype) present in 2022:
      log_count_2022 (log1p of 2022 count) is populated from the training
      lookup table.  The model relies heavily on this year-over-year signal.

  Unknown pairs not present in 2022:
      log_count_2022 = 0.  Model falls back to violation-type global statistics
      and corpus features (meter density, pavement quality, etc.) plus
      street-name-derived features (directional prefix, intersection marker).

Validation
──────────
Street-based 80/20 holdout, 100% cold-start (val streets never seen in training).
The validation model is trained WITHOUT log_count_2022 to avoid distribution
shift (all training rows have log_count_2022 > 0; all val rows would have 0).
The production model adds log_count_2022 for known-pair lookups at test time.

The reported RMSE is therefore a conservative lower bound on production performance
because the majority of 2023 pairs will be in 2022 training data.

Usage
─────
  python train.py                                      # validation only
  python train.py --test-path test.csv                 # keys-only → submission.csv
  python train.py --test-path eval.csv                 # with ground truth → RMSE
"""
import argparse
import re
import warnings
from pathlib import Path

import lightgbm as lgb
import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder

warnings.filterwarnings("ignore")


# ──────────────────────────────────────────────────────────────────────────────
# Configuration
# ──────────────────────────────────────────────────────────────────────────────

CORPUS_FILES = {
    "meters":   "parking_meters_locations_and_status__693u-uax6.parquet",
    "pavement": "street_pavement_ratings__6yyb-pb25.parquet",
    "sidewalk": "sidewalk_management_database_violations__6kbp-uz6m.parquet",
    "bicycle":  "bicycle_parking__592z-n7dk.parquet",
}

# Features available at COLD-START (no pair-level 2022 lookup)
FEATURE_COLS_BASE = [
    # Street-name-derived (always available)
    "is_directional_street",  # WB/EB/NB/SB prefix → highway/camera corridor
    "has_intersection",        # '@' in name → intersection camera
    "street_name_len",
    # Violation type
    "violation_type_enc",
    "vtype_mean", "vtype_median", "vtype_total", "vtype_std", "vtype_max",
    "log_vtype_mean",
    # Street aggregates (from 2022 training; 0 for unseen streets)
    "street_total", "street_mean", "street_max", "street_n_vtypes",
    "log_street_total",
    # Corpus: parking meters
    "meter_count", "meter_active_count",
    # Corpus: pavement condition
    "mean_pavement_rating", "min_pavement_rating", "n_pavement_segments",
    # Corpus: sidewalk violations (infrastructure stress proxy)
    "sidewalk_violation_count",
    # Corpus: bicycle parking (commercial activity proxy)
    "bike_parking_count",
]

# Additional feature added only in the PRODUCTION model
FEATURE_COLS_PROD = ["log_count_2022"] + FEATURE_COLS_BASE

LGBM_PARAMS = {
    "objective":         "regression_l2",
    "n_estimators":      2000,
    "learning_rate":     0.04,
    "num_leaves":        127,
    "feature_fraction":  0.8,
    "bagging_fraction":  0.8,
    "bagging_freq":      5,
    "min_child_samples": 10,
    "reg_alpha":         0.1,
    "reg_lambda":        1.0,
    "random_state":      42,
    "verbose":           -1,
    "n_jobs":            -1,
}

_DIRECTIONAL_RE = re.compile(r"^(WB|EB|NB|SB)\b", re.IGNORECASE)


# ──────────────────────────────────────────────────────────────────────────────
# Utilities
# ──────────────────────────────────────────────────────────────────────────────

def norm_street(s: pd.Series) -> pd.Series:
    return s.str.upper().str.strip()


def rmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.sqrt(np.mean((np.asarray(y_true) - np.asarray(y_pred)) ** 2)))


# ──────────────────────────────────────────────────────────────────────────────
# Corpus feature building
# ──────────────────────────────────────────────────────────────────────────────

def _safe_parquet(path: Path) -> pd.DataFrame | None:
    try:
        return pd.read_parquet(path)
    except Exception as exc:
        print(f"    Warning — skipping {path.name}: {exc}")
        return None


def build_corpus_features(corpus_dir: Path) -> pd.DataFrame:
    """Aggregate corpus parquets to one row per normalized street name."""
    parts: list[pd.DataFrame] = []

    df = _safe_parquet(corpus_dir / CORPUS_FILES["meters"])
    if df is not None:
        df["street_key"] = norm_street(df["On_Street"])
        agg = (
            df.groupby("street_key")
            .agg(meter_count=("Status", "count"),
                 meter_active_count=("Status", lambda x: (x == "Active").sum()))
            .reset_index()
        )
        parts.append(agg)
        print(f"    Parking meters:    {len(agg):,} streets")

    df = _safe_parquet(corpus_dir / CORPUS_FILES["pavement"])
    if df is not None:
        df["street_key"] = norm_street(df["OnStreetName"])
        agg = (
            df.groupby("street_key")["SystemRating"]
            .agg(mean_pavement_rating="mean",
                 min_pavement_rating="min",
                 n_pavement_segments="count")
            .reset_index()
        )
        parts.append(agg)
        print(f"    Pavement ratings:  {len(agg):,} streets")

    df = _safe_parquet(corpus_dir / CORPUS_FILES["sidewalk"])
    if df is not None:
        df["street_key"] = norm_street(df["ONSTNAME"])
        agg = (
            df.groupby("street_key").size()
            .rename("sidewalk_violation_count").reset_index()
        )
        parts.append(agg)
        print(f"    Sidewalk viol.:    {len(agg):,} streets")

    df = _safe_parquet(corpus_dir / CORPUS_FILES["bicycle"])
    if df is not None:
        df["street_key"] = norm_street(df["OnStreet"])
        agg = (
            df.groupby("street_key").size()
            .rename("bike_parking_count").reset_index()
        )
        parts.append(agg)
        print(f"    Bicycle parking:   {len(agg):,} streets")

    if not parts:
        return pd.DataFrame(columns=["street_key"])

    corpus = parts[0]
    for part in parts[1:]:
        corpus = corpus.merge(part, on="street_key", how="outer")

    for col in ["meter_count", "meter_active_count",
                "sidewalk_violation_count", "bike_parking_count"]:
        if col in corpus.columns:
            corpus[col] = corpus[col].fillna(0.0)

    return corpus


# ──────────────────────────────────────────────────────────────────────────────
# Feature engineering
# ──────────────────────────────────────────────────────────────────────────────

def _street_name_features(df: pd.DataFrame) -> pd.DataFrame:
    """Derive features from the street name string itself."""
    raw = df["Street Name"].fillna("")
    df = df.copy()
    df["is_directional_street"] = raw.str.match(_DIRECTIONAL_RE).astype(np.float32)
    df["has_intersection"]      = raw.str.contains("@", regex=False).astype(np.float32)
    df["street_name_len"]       = raw.str.len().astype(np.float32)
    return df


def _encode_vtypes(s: pd.Series, le: LabelEncoder, fit: bool) -> pd.Series:
    if fit:
        le.fit(s.astype(str))
    known = set(le.classes_)
    return s.astype(str).map(lambda x: int(le.transform([x])[0]) if x in known else -1)


def compute_vtype_agg(df: pd.DataFrame) -> pd.DataFrame:
    return (
        df.groupby("Violation Description")["violation_count"]
        .agg(vtype_mean="mean", vtype_median="median",
             vtype_total="sum", vtype_std="std", vtype_max="max")
        .reset_index()
    )


def compute_street_agg(df: pd.DataFrame) -> pd.DataFrame:
    tmp = df.copy()
    tmp["street_key"] = norm_street(tmp["Street Name"])
    return (
        tmp.groupby("street_key")["violation_count"]
        .agg(street_total="sum", street_mean="mean",
             street_max="max", street_n_vtypes="count")
        .reset_index()
    )


def build_pair_lookup(df: pd.DataFrame) -> dict[tuple, float]:
    """(normed_street, vtype) → log1p(count) for all rows in df."""
    keys = list(zip(norm_street(df["Street Name"]), df["Violation Description"]))
    vals = np.log1p(df["violation_count"].to_numpy(np.float32))
    return dict(zip(keys, vals))


def attach_features(
    df: pd.DataFrame,
    vtype_agg:   pd.DataFrame,
    street_agg:  pd.DataFrame,
    corpus:      pd.DataFrame,
    le:          LabelEncoder,
    fit_encoder: bool,
    pair_lookup: dict | None = None,  # None → log_count_2022 = 0 (cold-start)
) -> pd.DataFrame:
    out = _street_name_features(df.copy())
    out["street_key"]        = norm_street(out["Street Name"])
    out["violation_type_enc"] = _encode_vtypes(out["Violation Description"], le, fit=fit_encoder)

    # Primary signal: 2022 count for this exact (street, vtype) pair
    if pair_lookup is not None:
        keys = list(zip(out["street_key"], out["Violation Description"]))
        out["log_count_2022"] = np.array(
            [pair_lookup.get(k, 0.0) for k in keys], dtype=np.float32
        )
    else:
        out["log_count_2022"] = np.float32(0.0)

    # Violation-type aggregates
    out = out.merge(vtype_agg, on="Violation Description", how="left")
    out["log_vtype_mean"] = np.log1p(out["vtype_mean"].fillna(0.0).astype(np.float32))

    # Street aggregates
    out = out.merge(street_agg, on="street_key", how="left")
    out["log_street_total"] = np.log1p(out["street_total"].fillna(0.0).astype(np.float32))
    for col in ["street_total", "street_mean", "street_max", "street_n_vtypes"]:
        if col in out.columns:
            out[col] = out[col].fillna(0.0)

    # Corpus
    out = out.merge(corpus, on="street_key", how="left")
    if "mean_pavement_rating" in out.columns:
        out["mean_pavement_rating"] = out["mean_pavement_rating"].fillna(
            out["mean_pavement_rating"].median()
        )
        out["min_pavement_rating"]  = out["min_pavement_rating"].fillna(
            out["min_pavement_rating"].median()
        )
        out["n_pavement_segments"]  = out["n_pavement_segments"].fillna(0.0)

    return out


def get_X(df: pd.DataFrame, feature_cols: list[str]) -> np.ndarray:
    cols = [c for c in feature_cols if c in df.columns]
    return df[cols].fillna(0.0).to_numpy(dtype=np.float32)


# ──────────────────────────────────────────────────────────────────────────────
# Model helpers
# ──────────────────────────────────────────────────────────────────────────────

def fit_lgbm(
    X_train: np.ndarray, y_train: np.ndarray,
    X_val:   np.ndarray | None = None,
    y_val:   np.ndarray | None = None,
) -> lgb.LGBMRegressor:
    model = lgb.LGBMRegressor(**LGBM_PARAMS)
    cbs = [lgb.log_evaluation(period=200)]
    if X_val is not None:
        cbs.append(lgb.early_stopping(stopping_rounds=75, verbose=False))
    model.fit(
        X_train, y_train,
        eval_set=[(X_val, y_val)] if X_val is not None else None,
        callbacks=cbs,
    )
    return model


def predict(model: lgb.LGBMRegressor, X: np.ndarray) -> np.ndarray:
    return np.clip(np.expm1(model.predict(X)), 0.0, None)


# ──────────────────────────────────────────────────────────────────────────────
# Pipeline
# ──────────────────────────────────────────────────────────────────────────────

def run(
    train_path: Path,
    corpus_dir: Path,
    output_dir: Path,
    test_path:  Path | None = None,
    val_frac:   float = 0.20,
    seed:       int   = 42,
) -> None:

    # 1. Load ─────────────────────────────────────────────────────────────────
    print(f"\n[1/5] Loading training data: {train_path}")
    train_df = pd.read_csv(train_path)
    train_df.columns = ["Street Name", "Violation Description", "violation_count"]
    print(f"      {len(train_df):,} rows | "
          f"{train_df['Street Name'].nunique():,} streets | "
          f"{train_df['Violation Description'].nunique()} violation types")

    # 2. Corpus ───────────────────────────────────────────────────────────────
    print(f"\n[2/5] Building corpus features: {corpus_dir}")
    corpus = build_corpus_features(corpus_dir)
    print(f"      {len(corpus):,} streets × {corpus.shape[1]-1} corpus feature cols")

    # 3. Validation split (street-based, 100% cold-start) ─────────────────────
    print(f"\n[3/5] Street holdout split ({val_frac:.0%} val) ...")
    rng = np.random.default_rng(seed)
    all_streets = train_df["Street Name"].unique()
    val_streets = set(rng.choice(all_streets,
                                  size=int(len(all_streets) * val_frac),
                                  replace=False))
    tr = train_df[~train_df["Street Name"].isin(val_streets)].copy()
    va = train_df[train_df["Street Name"].isin(val_streets)].copy()
    print(f"      Train: {len(tr):,} rows ({tr['Street Name'].nunique():,} streets)")
    print(f"      Val:   {len(va):,} rows ({va['Street Name'].nunique():,} streets) — all cold-start")

    le = LabelEncoder()
    tr_vtype_agg  = compute_vtype_agg(tr)
    tr_street_agg = compute_street_agg(tr)

    # Validation model uses NO pair lookup (simulates pure cold-start)
    tr_feat = attach_features(tr, tr_vtype_agg, tr_street_agg, corpus, le,
                               fit_encoder=True, pair_lookup=None)
    va_feat = attach_features(va, tr_vtype_agg, tr_street_agg, corpus, le,
                               fit_encoder=False, pair_lookup=None)

    feat_used = [c for c in FEATURE_COLS_BASE if c in tr_feat.columns]
    print(f"      Validation features ({len(feat_used)}): {feat_used}")

    X_tr = get_X(tr_feat, FEATURE_COLS_BASE)
    y_tr = np.log1p(tr["violation_count"].to_numpy(np.float32))
    X_va = get_X(va_feat, FEATURE_COLS_BASE)
    y_va = va["violation_count"].to_numpy(np.float32)

    # 4. Train validation model, report RMSE ───────────────────────────────────
    print(f"\n[4/5] Training LightGBM (log1p target, cold-start validation) ...")
    val_model = fit_lgbm(X_tr, y_tr, X_va, np.log1p(y_va))

    va_pred    = predict(val_model, X_va)
    val_rmse   = rmse(y_va, va_pred)
    naive_rmse = rmse(y_va, np.full_like(y_va, y_va.mean()))
    vtype_pred = (
        va["Violation Description"]
        .map(tr_vtype_agg.set_index("Violation Description")["vtype_mean"])
        .fillna(y_va.mean())
        .to_numpy(np.float32)
    )
    vtype_rmse = rmse(y_va, vtype_pred)

    print(f"\n  ── Validation Results (2022 cold-start streets) ─────────────")
    print(f"  Model RMSE:                   {val_rmse:>10,.2f}")
    print(f"  Vtype-mean baseline RMSE:     {vtype_rmse:>10,.2f}")
    print(f"  Global-mean baseline RMSE:    {naive_rmse:>10,.2f}")
    print(f"  Val rows: {len(y_va):,}  |  Val streets: {va['Street Name'].nunique():,}")
    print(f"  Note: all val streets are UNSEEN (worst-case cold-start).")
    print(f"  Production RMSE will be lower — most 2023 pairs will be in 2022 data.")

    # 4b. Production model — retrain on ALL 2022 data with pair lookup ─────────
    print(f"\n  Retraining production model on full 2022 data (with pair lookup) ...")
    full_vtype_agg   = compute_vtype_agg(train_df)
    full_street_agg  = compute_street_agg(train_df)
    full_pair_lookup = build_pair_lookup(train_df)

    full_feat = attach_features(train_df, full_vtype_agg, full_street_agg, corpus, le,
                                 fit_encoder=True, pair_lookup=full_pair_lookup)
    X_full = get_X(full_feat, FEATURE_COLS_PROD)
    y_full = np.log1p(train_df["violation_count"].to_numpy(np.float32))
    final_model = fit_lgbm(X_full, y_full)

    # 5. Inference ─────────────────────────────────────────────────────────────
    print(f"\n[5/5] Generating predictions ...")
    if test_path is None:
        print("  No --test-path supplied. Rerun with --test-path <csv> to generate submission.csv.")
        return

    print(f"  Loading: {test_path}")
    test_df = pd.read_csv(test_path)

    # Flexible column name normalisation
    rename = {}
    for col in test_df.columns:
        lc = col.lower().strip()
        if lc in ("street name", "street_name") and col != "Street Name":
            rename[col] = "Street Name"
        elif lc in ("violation description", "violation_description") and col != "Violation Description":
            rename[col] = "Violation Description"
    if rename:
        test_df = test_df.rename(columns=rename)

    has_gt = "violation_count" in test_df.columns
    if has_gt:
        print("  Ground-truth column detected — will compute RMSE.")
        y_gt = test_df["violation_count"].to_numpy(np.float32)
    else:
        print("  Keys-only — pure prediction mode.")

    # Coverage report
    train_pair_set   = set(zip(norm_street(train_df["Street Name"]),
                               train_df["Violation Description"]))
    train_street_set = set(norm_street(train_df["Street Name"]))
    test_sk          = list(zip(norm_street(test_df["Street Name"]),
                                test_df["Violation Description"]))
    n_unseen_pairs   = sum(1 for k in test_sk if k not in train_pair_set)
    n_unseen_streets = sum(
        1 for s in norm_street(test_df["Street Name"]) if s not in train_street_set
    )

    print(f"\n  ── Test Key Coverage ────────────────────────────────────────")
    print(f"  Test rows:                   {len(test_df):>8,}")
    print(f"  Unseen (street, vtype):      {n_unseen_pairs:>8,}  "
          f"({n_unseen_pairs/len(test_df)*100:.1f}%)")
    print(f"  Completely new streets:      {n_unseen_streets:>8,}  "
          f"({n_unseen_streets/len(test_df)*100:.1f}%)")
    print(f"  Strategy: known → log_count_2022 from 2022 lookup;")
    print(f"            unknown → log_count_2022=0, vtype means as fallback")

    test_feat = attach_features(
        test_df, full_vtype_agg, full_street_agg, corpus, le,
        fit_encoder=False, pair_lookup=full_pair_lookup,
    )
    X_test    = get_X(test_feat, FEATURE_COLS_PROD)
    test_pred = predict(final_model, X_test)

    if has_gt:
        overall = rmse(y_gt, test_pred)
        known_mask = np.array([k in train_pair_set for k in test_sk])
        print(f"\n  ── Test RMSE ────────────────────────────────────────────────")
        print(f"  Overall RMSE:              {overall:>10,.2f}")
        if known_mask.sum():
            print(f"  Known pairs ({known_mask.sum():,}):       "
                  f"{rmse(y_gt[known_mask], test_pred[known_mask]):>10,.2f}")
        if (~known_mask).sum():
            print(f"  Unknown pairs ({(~known_mask).sum():,}):     "
                  f"{rmse(y_gt[~known_mask], test_pred[~known_mask]):>10,.2f}")

    # Write submission
    output_dir.mkdir(parents=True, exist_ok=True)
    sub = pd.DataFrame({
        "street_name":     test_df["Street Name"],
        "violation_type":  test_df["Violation Description"],
        "predicted_count": np.maximum(np.round(test_pred).astype(int), 0),
    })
    out_path = output_dir / "submission.csv"
    sub.to_csv(out_path, index=False)
    print(f"\n  Submission → {out_path}  ({len(sub):,} rows)")


# ──────────────────────────────────────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────────────────────────────────────

def _parse() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="NYC Parking Violations Prediction",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument("--train-path", default="all_data/violations_per_street_2022.csv",
                   help="2022 training CSV (Street Name, Violation Description, violation_count)")
    p.add_argument("--test-path",  default="../violations_per_street_2023.csv",
                   help="Test/eval CSV. violation_count optional; if present, reports RMSE.")
    p.add_argument("--corpus-dir", default="all_data/corpus",
                   help="Directory with corpus .parquet files")
    p.add_argument("--output-dir", default=".", help="Output directory for submission.csv")
    p.add_argument("--val-frac",   type=float, default=0.20)
    p.add_argument("--seed",       type=int,   default=42)
    return p.parse_args()


if __name__ == "__main__":
    args = _parse()
    run(
        train_path = Path(args.train_path),
        corpus_dir = Path(args.corpus_dir),
        output_dir = Path(args.output_dir),
        test_path  = Path(args.test_path) if args.test_path else None,
        val_frac   = args.val_frac,
        seed       = args.seed,
    )
