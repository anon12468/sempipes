import argparse
import pandas as pd
import numpy as np
import lightgbm as lgb
from sklearn.model_selection import GroupKFold
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import os
import re
import warnings

warnings.filterwarnings("ignore", category=UserWarning)

# --- Global constants ---
ROOT_INPUT_DIR = "./input"
WORKING_DIR = "./working"
SUBMISSION_FILE = os.path.join(WORKING_DIR, "submission.csv")
DEFAULT_TRAIN_PATH = os.path.join(ROOT_INPUT_DIR, "violations_per_street_2022.csv")
TREE_CENSUS_PATH = os.path.join(
    ROOT_INPUT_DIR, "corpus", "2005_street_tree_census__29bw-z7pj.parquet"
)


# --- Helper Functions ---
def normalize_street_name(name):
    """
    Standardizes street names for robust joining.
    Converts to uppercase, strips whitespace, and standardizes common suffixes.
    """
    if not isinstance(name, str):
        return ""
    name = name.upper().strip()
    name = re.sub(r"\s+", " ", name)
    replacements = {
        r"\bSTREET\b": "ST",
        r"\bAVENUE\b": "AVE",
        r"\bBOULEVARD\b": "BLVD",
        r"\bROAD\b": "RD",
        r"\bPLACE\b": "PL",
        r"\bLANE\b": "LN",
        r"\bDRIVE\b": "DR",
        r"\bPARKWAY\b": "PKWY",
        r"\bEXPRESSWAY\b": "EXPY",
    }
    for old, new in replacements.items():
        name = re.sub(old, new, name)
    return name


def get_tree_features():
    """
    Loads and preprocesses the Street Tree Census data to create street-level features.
    Caches the result for efficiency.
    """
    if hasattr(get_tree_features, "cached_df"):
        return get_tree_features.cached_df

    try:
        tree_df = pd.read_parquet(
            TREE_CENSUS_PATH, columns=["address", "spc_common", "steward", "tree_dbh"]
        )
        tree_df["Street Name"] = tree_df["address"].apply(
            lambda x: re.sub(r"^\d+\-*\d*\s+", "", x) if isinstance(x, str) else ""
        )
        tree_df["Street Name Norm"] = tree_df["Street Name"].apply(
            normalize_street_name
        )
        tree_features = (
            tree_df.groupby("Street Name Norm")
            .agg(
                tree_count=("Street Name Norm", "count"),
                unique_species_count=("spc_common", "nunique"),
                steward_count=("steward", "count"),
                avg_tree_dbh=("tree_dbh", "mean"),
            )
            .reset_index()
        )
        get_tree_features.cached_df = tree_features
        return tree_features
    except FileNotFoundError:
        print("Warning: Tree census data not found. Skipping tree features.")
        get_tree_features.cached_df = None
        return None


# --- Bugfix: Refactored Feature Engineering ---
def build_feature_aggregators(source_df):
    """
    Calculates aggregation feature dataframes from a source dataframe.
    This function isolates the calculation of statistics to prevent leakage.
    """
    street_agg = (
        source_df.groupby("Street Name")["violation_count"]
        .agg(["sum", "mean", "count", "std"])
        .reset_index()
    )
    street_agg.columns = [
        "Street Name",
        "street_total_violations",
        "street_mean_violations",
        "street_unique_violation_types",
        "street_std_violations",
    ]

    violation_agg = (
        source_df.groupby("Violation Description")["violation_count"]
        .agg(["sum", "mean", "count", "std"])
        .reset_index()
    )
    violation_agg.columns = [
        "Violation Description",
        "violation_type_total",
        "violation_type_mean",
        "violation_type_num_streets",
        "violation_type_std",
    ]

    return {"street": street_agg, "violation": violation_agg}


def apply_features(df, aggregators, tree_features):
    """
    Applies pre-computed aggregation and external features to a dataframe.
    """
    # Merge pre-computed aggregation features
    df = df.merge(aggregators["street"], on="Street Name", how="left")
    df = df.merge(aggregators["violation"], on="Violation Description", how="left")

    # Merge external data (tree census)
    if tree_features is not None:
        df["Street Name Norm"] = df["Street Name"].apply(normalize_street_name)
        df = df.merge(tree_features, on="Street Name Norm", how="left")
        df = df.drop(columns=["Street Name Norm"])
        tree_cols = [
            "tree_count",
            "unique_species_count",
            "steward_count",
            "avg_tree_dbh",
        ]
        df[tree_cols] = df[tree_cols].fillna(0)

    return df


# --- Main script logic ---
def main(train_path, test_path=None):
    # Load and preprocess training data
    df_train = pd.read_csv(train_path)
    df_train.rename(
        columns={
            "Street Name": "Street Name",
            "Violation Description": "Violation Description",
            "violation_count": "violation_count",
        },
        inplace=True,
    )
    df_train["violation_count"] = pd.to_numeric(
        df_train["violation_count"], errors="coerce"
    ).fillna(0)
    df_train.dropna(subset=["Street Name", "Violation Description"], inplace=True)
    df_train = df_train[df_train["violation_count"] > 0].copy()

    df_train["target"] = np.log1p(df_train["violation_count"])

    # Load external features once
    tree_features = get_tree_features()

    print("Starting 5-fold group cross-validation...")

    street_encoder = LabelEncoder().fit(df_train["Street Name"])
    violation_encoder = LabelEncoder().fit(df_train["Violation Description"])
    df_train["Street Name Encoded"] = street_encoder.transform(df_train["Street Name"])
    df_train["Violation Description Encoded"] = violation_encoder.transform(
        df_train["Violation Description"]
    )

    gkf = GroupKFold(n_splits=5)
    oof_preds = np.zeros(len(df_train))
    models = []

    categorical_features_encoded = [
        "Street Name Encoded",
        "Violation Description Encoded",
    ]

    for fold, (train_idx, val_idx) in enumerate(
        gkf.split(df_train, groups=df_train["Street Name Encoded"])
    ):
        print(f"--- Fold {fold+1}/5 ---")
        train_fold, val_fold = df_train.iloc[train_idx], df_train.iloc[val_idx]

        # Bugfix: create features without leakage
        # 1. Build aggregators from training data ONLY
        aggregators = build_feature_aggregators(train_fold)
        # 2. Apply aggregators to both train and validation sets
        train_fold_featured = apply_features(
            train_fold.copy(), aggregators, tree_features
        )
        val_fold_featured = apply_features(val_fold.copy(), aggregators, tree_features)

        feature_cols = [
            col
            for col in train_fold_featured.columns
            if col
            not in ["Street Name", "Violation Description", "violation_count", "target"]
        ]
        numeric_features = list(
            train_fold_featured[feature_cols].select_dtypes(include=np.number).columns
        )

        X_train, y_train = train_fold_featured[numeric_features], train_fold["target"]
        X_val, y_val = val_fold_featured[numeric_features], val_fold["target"]

        model = lgb.LGBMRegressor(
            random_state=42 + fold,
            n_estimators=1000,
            learning_rate=0.05,
            num_leaves=31,
            n_jobs=-1,
            colsample_bytree=0.8,
            subsample=0.8,
        )
        model.fit(
            X_train,
            y_train,
            eval_set=[(X_val, y_val)],
            eval_metric="rmse",
            callbacks=[lgb.early_stopping(100, verbose=False)],
            categorical_feature=[
                f for f in categorical_features_encoded if f in numeric_features
            ],
        )

        oof_preds[val_idx] = model.predict(X_val)

    oof_preds_exp = np.expm1(oof_preds)
    oof_preds_exp[oof_preds_exp < 0] = 0
    val_rmse = np.sqrt(mean_squared_error(df_train["violation_count"], oof_preds_exp))
    print(f"\nOverall Validation RMSE (from OOF predictions): {val_rmse:.4f}")

    if test_path:
        print("\n--- Training final model on all data and running inference ---")

        # 1. Build aggregators on FULL training data
        final_aggregators = build_feature_aggregators(df_train)
        df_train_full_featured = apply_features(
            df_train.copy(), final_aggregators, tree_features
        )

        final_feature_cols = [
            col
            for col in df_train_full_featured.columns
            if col
            not in ["Street Name", "Violation Description", "violation_count", "target"]
        ]
        final_feature_cols = list(
            df_train_full_featured[final_feature_cols]
            .select_dtypes(include=np.number)
            .columns
        )
        X_full_train = df_train_full_featured[final_feature_cols]
        y_full_train = df_train_full_featured["target"]

        # 2. Train final model on all data
        final_model = lgb.LGBMRegressor(
            random_state=42,
            n_estimators=1500,
            learning_rate=0.05,
            num_leaves=31,
            n_jobs=-1,
            colsample_bytree=0.8,
            subsample=0.8,
        )
        final_model.fit(
            X_full_train,
            y_full_train,
            categorical_feature=[
                f for f in categorical_features_encoded if f in final_feature_cols
            ],
        )

        # 3. Load and process test data
        df_test = pd.read_csv(test_path)
        test_keys = df_test[["Street Name", "Violation Description"]].copy()

        street_map = {label: i for i, label in enumerate(street_encoder.classes_)}
        df_test["Street Name Encoded"] = (
            df_test["Street Name"].map(street_map).fillna(-1).astype(int)
        )

        violation_map = {label: i for i, label in enumerate(violation_encoder.classes_)}
        df_test["Violation Description Encoded"] = (
            df_test["Violation Description"].map(violation_map).fillna(-1).astype(int)
        )

        # 4. Apply features using the aggregators built from the full training set
        df_test_featured = apply_features(
            df_test.copy(), final_aggregators, tree_features
        )
        X_test = df_test_featured[final_feature_cols]

        unseen_streets = df_test[
            ~df_test["Street Name"].isin(df_train["Street Name"])
        ].shape[0]
        unseen_violations = df_test[
            ~df_test["Violation Description"].isin(df_train["Violation Description"])
        ].shape[0]
        print(
            f"Test data has {unseen_streets} rows with unseen street names and {unseen_violations} rows with unseen violation types."
        )
        print(
            "These are handled by NaNs in aggregation features and an encoded value of -1."
        )

        # 5. Predict and post-process
        test_predictions_log = final_model.predict(X_test)
        test_predictions = np.expm1(test_predictions_log)
        test_predictions[test_predictions < 0] = 0

        submission_df = test_keys
        submission_df["predicted_count"] = test_predictions

        os.makedirs(WORKING_DIR, exist_ok=True)
        submission_df.to_csv(SUBMISSION_FILE, index=False)
        print(f"Submission file created at: {SUBMISSION_FILE}")

        if "violation_count" in df_test.columns:
            df_test["violation_count"] = pd.to_numeric(
                df_test["violation_count"], errors="coerce"
            ).fillna(0)
            test_rmse = np.sqrt(
                mean_squared_error(df_test["violation_count"], test_predictions)
            )
            print(f"RMSE on provided test set: {test_rmse:.4f}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="NYC Parking Violation Prediction Model"
    )
    parser.add_argument(
        "--train-path",
        type=str,
        default=DEFAULT_TRAIN_PATH,
        help="Path to the training CSV file.",
    )
    parser.add_argument(
        "--test-path",
        type=str,
        default=None,
        help="(Optional) Path to the test/evaluation CSV file.",
    )
    args = parser.parse_args()

    # Create dummy test file if none provided to demonstrate full pipeline
    if not args.test_path and os.path.exists(args.train_path):
        print(
            "No --test-path provided. Creating a dummy test file from training data to demonstrate the full pipeline."
        )
        temp_df = pd.read_csv(args.train_path)
        dummy_test = pd.concat(
            [
                temp_df.sample(n=500, random_state=123),
                pd.DataFrame(
                    {
                        "Street Name": ["Unknown Street 1"] * 3
                        + temp_df["Street Name"].tail(2).tolist(),
                        "Violation Description": temp_df["Violation Description"]
                        .head(3)
                        .tolist()
                        + ["New Violation Type"] * 2,
                        "violation_count": [5, 10, 15, 20, 25],
                    }
                ),
            ],
            ignore_index=True,
        )
        os.makedirs(WORKING_DIR, exist_ok=True)
        dummy_test_path = os.path.join(WORKING_DIR, "dummy_eval_set.csv")
        dummy_test.to_csv(dummy_test_path, index=False)
        args.test_path = dummy_test_path

    main(args.train_path, args.test_path)
