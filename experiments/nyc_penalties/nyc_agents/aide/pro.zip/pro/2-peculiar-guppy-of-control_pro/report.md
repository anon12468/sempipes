# Technical Report: NYC Parking Violation Prediction

## Introduction

This report details the methodology and empirical results for predicting NYC parking violation counts. The objective was to build a regression model that accurately forecasts the number of violations for a given `(street_name, violation_type)` pair. Using 2022 violation data as the primary training set, we developed a predictive pipeline that leverages both historical aggregates and external data sources. The model's performance was evaluated using Root Mean Squared Error (RMSE). The final selected model achieved a cross-validation RMSE of 18.52.

## Preprocessing

The preprocessing pipeline focused on standardizing inputs and preparing data for the model.

-   **Street Name Standardization:** A cleaning function was applied to all street name fields to ensure consistency for joins. This involved converting names to uppercase and removing leading/trailing whitespace.
-   **Target Transformation:** The target variable, `violation_count`, exhibited a highly skewed distribution. A logarithm transform, `np.log1p`, was applied to normalize the target, which improved model training stability and performance.
-   **Categorical Encoding:** The `street_name` and `violation_type` features were converted to numerical representations using `sklearn.preprocessing.LabelEncoder`.

## Modelling Methods

### Feature Engineering

An iterative feature engineering process was undertaken to enrich the dataset.

1.  **Historical Aggregates (Baseline):** The initial feature set was derived from the 2022 training data. Statistical aggregates (mean, sum, standard deviation, count) of `violation_count` were calculated for each `street_name` and `violation_type`.

2.  **External Data Augmentation:** To provide additional context, two external datasets were incorporated:
    *   **NYC Tree Census:** This dataset provided street-level counts of trees (`tree_count`) and the average tree diameter (`mean_tree_dbh`).
    *   **Street Centerline Data:** This proved to be the most impactful external source. The shape length (`shp_lng`) for all street segments was aggregated to create a `total_street_length` feature for each unique street name. This serves as a proxy for the street's size and capacity for parking.

3.  **Interaction Features:** Further experiments were conducted to create more complex interaction and density features (e.g., `violation_density` as total violations divided by street length). However, these features did not improve performance over the simpler features and were excluded from the final model.

### Model and Validation

-   **Model:** A LightGBM gradient boosting model (`LGBMRegressor`) was chosen for its performance and efficiency. It was configured with a regression objective (`regression_l1`) and trained with early stopping to prevent overfitting.
-   **Validation Strategy:** A robust 5-fold `GroupKFold` cross-validation strategy was employed. Folds were grouped by `street_name` to ensure that all data for a given street was contained within a single fold (either train or validation). This prevents data leakage and provides a more realistic estimate of the model's ability to generalize to unseen streets.
-   **Handling Unseen Keys:** For `street_name` or `violation_type` keys present in the test set but not in the training data, the corresponding aggregated features were imputed using the global mean calculated from the training set.

## Results Discussion

The model's performance was tracked through several iterations of feature engineering.

| Model Iteration                                         | Cross-Validation RMSE |
| ------------------------------------------------------- | --------------------- |
| 1. Baseline (Historical Aggregates + Tree Data)         | 24.96                 |
| 2. **Added Street Length Feature**                      | **18.52**             |
| 3. Added Complex Interaction/Density Features           | 25.63                 |

The baseline model, using only historical violation statistics and tree data, achieved an RMSE of 24.96. The most significant improvement came from incorporating the `total_street_length` feature, which reduced the RMSE by over 25% to **18.52**. This highlights the importance of normalizing for a street's physical size. Subsequent attempts to create more complex density and ratio features did not yield further gains, indicating that `total_street_length` directly captured the most valuable signal. The final model is therefore the one incorporating historical aggregates, tree data, and total street length.

## Future Work

Several avenues exist for potential model improvement:

-   **Temporal Features:** Incorporating violation data from previous years (e.g., 2020, 2021) would enable the creation of trend-based features, such as year-over-year growth.
-   **Geospatial Features:** The street centerline data contains geographic information that could be used to engineer features related to a street's proximity to points of interest, commercial zones, or different boroughs.
-   **Hyperparameter Optimization:** A systematic hyperparameter tuning process (e.g., using Bayesian optimization or grid search) could further refine the LightGBM model's performance.
-   **Advanced Categorical Encoding:** Techniques like target encoding could be explored to create a more powerful representation of the categorical features.