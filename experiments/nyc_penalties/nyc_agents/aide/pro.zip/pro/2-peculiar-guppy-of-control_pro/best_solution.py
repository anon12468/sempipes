import argparse
import os
import warnings
import pandas as pd
import numpy as np
import lightgbm as lgb
from sklearn.model_selection import GroupKFold
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import mean_squared_error

# Suppress warnings for cleaner output
warnings.filterwarnings("ignore")


def clean_street_name(street_name_series):
    """Standardizes street names for consistent joining."""
    return street_name_series.str.upper().str.strip()


def load_and_preprocess_tree_data(path):
    """Loads and preprocesses the tree census data to create street-level features."""
    try:
        df_trees = pd.read_parquet(path)
        # Standardize street name column if it exists
        if "st_name" in df_trees.columns:
            df_trees["street_name_clean"] = clean_street_name(df_trees["st_name"])

            # Aggregate to get features per street
            tree_features = (
                df_trees.groupby("street_name_clean")
                .agg(
                    tree_count=("tree_dbh", "count"), mean_tree_dbh=("tree_dbh", "mean")
                )
                .reset_index()
            )

            return tree_features
        else:
            print(
                "Warning: 'st_name' column not found in tree data. Skipping tree features."
            )
            return None
    except Exception as e:
        print(
            f"Warning: Could not load or process tree data from {path}. Error: {e}. Skipping tree features."
        )
        return None


def load_and_preprocess_street_centerline_data(path):
    """Loads and preprocesses the street centerline data to get total street length."""
    try:
        df_centerline = pd.read_parquet(path)
        if "full_stree" in df_centerline.columns and "shp_lng" in df_centerline.columns:
            df_centerline["street_name_clean"] = clean_street_name(
                df_centerline["full_stree"]
            )

            # Aggregate to get total length for each street
            centerline_features = (
                df_centerline.groupby("street_name_clean")
                .agg(total_street_length=("shp_lng", "sum"))
                .reset_index()
            )

            return centerline_features
        else:
            print(
                "Warning: Required columns ('full_stree', 'shp_lng') not found in centerline data. Skipping centerline features."
            )
            return None
    except Exception as e:
        print(
            f"Warning: Could not load or process centerline data from {path}. Error: {e}. Skipping centerline features."
        )
        return None


def create_features(df, train_df=None):
    """
    Engineers features for the model.
    If train_df is provided, it calculates aggregates from train_df and applies to df.
    Otherwise, it calculates aggregates from df itself (for the initial training set).
    """
    source_df = train_df if train_df is not None else df

    # Street-level aggregates
    street_agg = source_df.groupby("street_name")["violation_count"].agg(
        ["mean", "sum", "std", "count"]
    )
    street_agg.columns = [
        "street_mean_viol",
        "street_sum_viol",
        "street_std_viol",
        "street_key_count",
    ]
    df = pd.merge(df, street_agg, on="street_name", how="left")

    # Violation-type-level aggregates
    violation_agg = source_df.groupby("violation_type")["violation_count"].agg(
        ["mean", "sum", "std", "count"]
    )
    violation_agg.columns = [
        "viol_type_mean_viol",
        "viol_type_sum_viol",
        "viol_type_std_viol",
        "viol_type_key_count",
    ]
    df = pd.merge(df, violation_agg, on="violation_type", how="left")

    # Fill NaNs created by merges (for keys not in source_df)
    if train_df is not None:
        global_mean = train_df["violation_count"].mean()
        for col in street_agg.columns:
            df[col] = df[col].fillna(
                global_mean
            )  # Impute with global mean for unseen streets
        for col in violation_agg.columns:
            df[col] = df[col].fillna(
                global_mean
            )  # Impute with global mean for unseen types

    df.fillna(
        0, inplace=True
    )  # Fill any remaining NaNs (e.g., std for single-entry groups)

    return df


def main(args):
    # Define paths
    train_path = args.train_path
    test_path = args.test_path
    tree_data_path = "./input/corpus/2005_street_tree_census__29bw-z7pj.parquet"
    centerline_data_path = "./input/corpus/street-centerline-cscl.parquet"
    output_path = "./working/submission.csv"

    # --- 1. Load and Prepare Training Data ---
    print("Loading and preparing training data...")
    train_df = pd.read_csv(train_path)
    train_df.columns = ["street_name", "violation_type", "violation_count"]
    train_df["street_name"] = clean_street_name(train_df["street_name"])

    # --- 2. Augment with External Data ---
    print("Augmenting data with tree census features...")
    tree_features = load_and_preprocess_tree_data(tree_data_path)
    if tree_features is not None:
        train_df = pd.merge(
            train_df,
            tree_features,
            left_on="street_name",
            right_on="street_name_clean",
            how="left",
        )
        train_df.drop(columns=["street_name_clean"], inplace=True)
        train_df[["tree_count", "mean_tree_dbh"]] = train_df[
            ["tree_count", "mean_tree_dbh"]
        ].fillna(0)

    print("Augmenting data with street centerline features...")
    centerline_features = load_and_preprocess_street_centerline_data(
        centerline_data_path
    )
    if centerline_features is not None:
        train_df = pd.merge(
            train_df,
            centerline_features,
            left_on="street_name",
            right_on="street_name_clean",
            how="left",
        )
        train_df.drop(columns=["street_name_clean"], inplace=True)
        train_df["total_street_length"] = train_df["total_street_length"].fillna(0)

    # --- 3. Feature Engineering & Categorical Encoding ---
    print("Engineering features...")
    # Initial features from the dataset itself
    train_df = create_features(train_df)

    # Label Encoding for categorical features
    categorical_features = ["street_name", "violation_type"]
    encoders = {col: LabelEncoder() for col in categorical_features}
    for col in categorical_features:
        train_df[col] = encoders[col].fit_transform(train_df[col])

    # Define features and target
    features = [col for col in train_df.columns if col not in ["violation_count"]]
    X_train = train_df[features]
    y_train_log = np.log1p(train_df["violation_count"])
    groups = train_df["street_name"]  # Use encoded street_name for grouping

    # --- 4. Cross-Validation ---
    print("Starting 5-fold group cross-validation...")
    gkf = GroupKFold(n_splits=5)
    oof_preds = np.zeros(len(train_df))
    oof_rmse_scores = []

    lgb_params = {
        "objective": "regression_l1",
        "metric": "rmse",
        "n_estimators": 2000,
        "learning_rate": 0.02,
        "feature_fraction": 0.8,
        "bagging_fraction": 0.8,
        "bagging_freq": 1,
        "lambda_l1": 0.1,
        "lambda_l2": 0.1,
        "num_leaves": 31,
        "verbose": -1,
        "n_jobs": -1,
        "seed": 42,
        "boosting_type": "gbdt",
    }

    for fold, (train_idx, val_idx) in enumerate(
        gkf.split(X_train, y_train_log, groups)
    ):
        print(f"--- Fold {fold+1}/5 ---")
        X_train_fold, X_val_fold = X_train.iloc[train_idx], X_train.iloc[val_idx]
        y_train_fold, y_val_fold = (
            y_train_log.iloc[train_idx],
            y_train_log.iloc[val_idx],
        )

        model = lgb.LGBMRegressor(**lgb_params)
        model.fit(
            X_train_fold,
            y_train_fold,
            eval_set=[(X_val_fold, y_val_fold)],
            eval_metric="rmse",
            callbacks=[lgb.early_stopping(100, verbose=False)],
        )

        val_preds_log = model.predict(X_val_fold)
        oof_preds[val_idx] = val_preds_log

        val_preds = np.expm1(val_preds_log)
        val_true = np.expm1(y_val_fold)
        rmse = np.sqrt(mean_squared_error(val_true, val_preds))
        oof_rmse_scores.append(rmse)
        print(f"Fold {fold+1} RMSE: {rmse:.4f}")

    overall_oof_rmse = np.sqrt(
        mean_squared_error(np.expm1(y_train_log), np.expm1(oof_preds))
    )
    print("\n---------------------------------")
    print(f"Overall OOF RMSE (2022 validation): {overall_oof_rmse:.4f}")
    print(
        f"Mean Fold RMSE: {np.mean(oof_rmse_scores):.4f} (+/- {np.std(oof_rmse_scores):.4f})"
    )
    print("---------------------------------")

    # --- 5. Final Model Training ---
    print("\nTraining final model on all 2022 data...")
    final_model = lgb.LGBMRegressor(**lgb_params)
    final_model.fit(X_train, y_train_log)

    # --- 6. Prediction on Test Data (if provided) ---
    if test_path:
        print(f"\nProcessing test file: {test_path}")
        try:
            test_df = pd.read_csv(test_path)
            # Check if target column exists for scoring
            has_target = "violation_count" in test_df.columns
            if has_target:
                test_truth = test_df["violation_count"]

            test_df.columns = [col.replace(" ", "_").lower() for col in test_df.columns]
            test_df.rename(
                columns={
                    "street_name": "street_name",
                    "violation_description": "violation_type",
                },
                inplace=True,
            )

            original_keys = test_df[["street_name", "violation_type"]].copy()
            test_df["street_name"] = clean_street_name(test_df["street_name"])

            # Augment test data
            if tree_features is not None:
                test_df = pd.merge(
                    test_df,
                    tree_features,
                    left_on="street_name",
                    right_on="street_name_clean",
                    how="left",
                )
                test_df.drop(columns=["street_name_clean"], inplace=True)
                test_df[["tree_count", "mean_tree_dbh"]] = test_df[
                    ["tree_count", "mean_tree_dbh"]
                ].fillna(0)

            if centerline_features is not None:
                test_df = pd.merge(
                    test_df,
                    centerline_features,
                    left_on="street_name",
                    right_on="street_name_clean",
                    how="left",
                )
                test_df.drop(columns=["street_name_clean"], inplace=True)
                test_df["total_street_length"] = test_df["total_street_length"].fillna(
                    0
                )

            # Feature Engineering using stats from the full training data
            test_df = create_features(
                test_df, train_df=train_df.assign(violation_count=np.expm1(y_train_log))
            )

            # Handle unseen categorical values
            unseen_streets = 0
            unseen_violations = 0
            for col in categorical_features:
                le = encoders[col]
                known_classes = list(le.classes_)
                unseen_mask = ~test_df[col].isin(known_classes)
                if col == "street_name":
                    unseen_streets = unseen_mask.sum()
                if col == "violation_type":
                    unseen_violations = unseen_mask.sum()

                if unseen_mask.any():
                    le.classes_ = np.append(le.classes_, "unseen")
                test_df[col] = test_df[col].map(
                    lambda s: s if s in known_classes else "unseen"
                )
                test_df[col] = le.transform(test_df[col])

            print(
                f"Found {unseen_streets} street names in test data not present in training data."
            )
            print(
                f"Found {unseen_violations} violation types in test data not present in training data."
            )
            print(
                "These were handled by imputing aggregated features with training set global means."
            )

            X_test = test_df[features]

            # Predict
            test_preds_log = final_model.predict(X_test)
            test_preds = np.expm1(test_preds_log)
            test_preds = np.maximum(0, test_preds)  # Ensure non-negativity

            # Create submission file
            submission_df = original_keys
            submission_df["predicted_count"] = test_preds
            submission_df.to_csv(output_path, index=False)
            print(f"\nSubmission file created at: {output_path}")

            # Score if ground truth is available
            if has_target:
                test_rmse = np.sqrt(mean_squared_error(test_truth, test_preds))
                print(f"RMSE on provided test file: {test_rmse:.4f}")

        except FileNotFoundError:
            print(f"Error: Test file not found at {test_path}")
        except Exception as e:
            print(f"An error occurred during test processing: {e}")
    else:
        print("\nNo test path provided. Skipping prediction.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Predict NYC Parking Violations.")
    parser.add_argument(
        "--train-path",
        type=str,
        default="./input/violations_per_street_2022.csv",
        help="Path to the training data CSV file.",
    )
    parser.add_argument(
        "--test-path",
        type=str,
        default=None,
        help="Optional. Path to the test/evaluation data CSV file.",
    )

    # Create a dummy test file for demonstration purposes if it doesn't exist
    if not os.path.exists("./input/dummy_test.csv"):
        if os.path.exists("./input/violations_per_street_2022.csv"):
            dummy_df = pd.read_csv("./input/violations_per_street_2022.csv").sample(
                n=10000, random_state=42
            )
            dummy_df.iloc[5000:, 0] = "A COMPLETELY NEW STREET"
            dummy_df.to_csv("./input/dummy_test.csv", index=False)
        else:
            print("Warning: Training file not found, cannot create dummy test file.")

    # Simulate command line arguments
    # Use the dummy test file to ensure the prediction pipeline runs
    args = parser.parse_args(
        [
            "--train-path",
            "./input/violations_per_street_2022.csv",
            "--test-path",
            "./input/dummy_test.csv",
        ]
    )

    main(args)
