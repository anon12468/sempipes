import pandas as pd
import numpy as np
import lightgbm as lgb
from sklearn.model_selection import KFold  # <-- IMPROVEMENT: Changed from GroupKFold
from sklearn.metrics import mean_squared_error
import argparse
import os

# --- Constants ---
SEED = 42
N_SPLITS = 5
WORKING_DIR = "./working"
DATA_ROOT = "/Users/USER/Documents/UNI/SS26/nyc_open_data"
INPUT_DIR = os.path.join(DATA_ROOT, "train", "all_data")
DEFAULT_TRAIN_PATH = os.path.join(INPUT_DIR, "violations_per_street_2022.csv")
DEFAULT_TEST_PATH = os.path.join(DATA_ROOT, "violations_per_street_2023.csv")


# --- Main Logic ---


def load_external_data(corpus_path):
    """Loads and preprocesses the street tree census data for feature augmentation."""
    # Adjusted path for corpus folder structure
    tree_census_path = os.path.join(
        corpus_path, "2005_street_tree_census__29bw-z7pj.parquet"
    )
    if not os.path.exists(tree_census_path):
        print(
            "Warning: Street tree census data not found. Proceeding without these features."
        )
        return None
    try:
        # Load the data and identify potential street name and tree diameter columns
        df_tree = pd.read_parquet(tree_census_path)

        # Heuristic to find the street name column
        st_name_col = None
        for col in ["st_name", "street", "street_name", "Street Name"]:
            if col in df_tree.columns:
                st_name_col = col
                break
        if not st_name_col:
            print(
                "Warning: Could not find a street name column in tree census data. Skipping."
            )
            return None

        # Heuristic to find tree diameter column
        diam_col = None
        for col in ["tree_diam", "diameter", "tree_dbh"]:
            if col in df_tree.columns:
                diam_col = col
                break

        # Normalize street names for joining
        df_tree["Street Name"] = df_tree[st_name_col].str.upper().str.strip()

        # Create features
        aggs = {"tree_count": pd.NamedAgg(column="Street Name", aggfunc="size")}
        if diam_col:
            # Ensure diameter column is numeric, coercing errors
            df_tree[diam_col] = pd.to_numeric(df_tree[diam_col], errors="coerce")
            aggs["avg_tree_diam"] = pd.NamedAgg(column=diam_col, aggfunc="mean")
            aggs["std_tree_diam"] = pd.NamedAgg(column=diam_col, aggfunc="std")

        tree_features = df_tree.groupby("Street Name").agg(**aggs).reset_index()

        print(
            f"Successfully generated {tree_features.shape[1]-1} features from street tree census data."
        )
        return tree_features

    except Exception as e:
        print(
            f"Warning: Failed to load or process street tree data. Error: {e}. Proceeding without these features."
        )
        return None


def feature_engineering(df_to_transform, df_for_aggs, external_features):
    """
    Generates and applies features. Aggregates are calculated from `df_for_aggs`
    and then applied to `df_to_transform`. This prevents data leakage in CV.
    """
    df_out = df_to_transform.copy()

    # Standardize key columns to ensure joins work
    df_out["Street Name"] = df_out["Street Name"].str.upper().str.strip()
    df_out["Violation Description"] = (
        df_out["Violation Description"].str.upper().str.strip()
    )

    df_for_aggs_copy = df_for_aggs.copy()
    df_for_aggs_copy["Street Name"] = (
        df_for_aggs_copy["Street Name"].str.upper().str.strip()
    )
    df_for_aggs_copy["Violation Description"] = (
        df_for_aggs_copy["Violation Description"].str.upper().str.strip()
    )

    # 1. Calculate aggregates from the source dataframe
    street_aggs = (
        df_for_aggs_copy.groupby("Street Name")["violation_count"]
        .agg(["mean", "sum", "std", "count"])
        .add_prefix("street_")
        .reset_index()
    )
    violation_aggs = (
        df_for_aggs_copy.groupby("Violation Description")["violation_count"]
        .agg(["mean", "sum", "std", "count"])
        .add_prefix("violation_")
        .reset_index()
    )

    # 2. Merge External Features
    if external_features is not None:
        df_out = pd.merge(df_out, external_features, on="Street Name", how="left")

    # 3. Merge Aggregate Features
    df_out = pd.merge(df_out, street_aggs, on="Street Name", how="left")
    df_out = pd.merge(df_out, violation_aggs, on="Violation Description", how="left")

    # Fill NaNs created from joins
    float_cols = df_out.select_dtypes(include="float64").columns
    df_out[float_cols] = df_out[float_cols].fillna(0)

    # The target column should not be a feature
    if "violation_count" in df_out.columns:
        df_out = df_out.drop(columns=["violation_count"])

    return df_out


def train_and_evaluate(train_path, external_features):
    """
    Trains the model using KFold CV with leakage-free feature engineering
    and evaluates it.
    """
    print("Loading training data...")
    train_df = pd.read_csv(train_path)

    # Using a simple KFold instead of GroupKFold
    kf = KFold(n_splits=N_SPLITS, shuffle=True, random_state=SEED)
    oof_preds = np.zeros(len(train_df))
    models = []

    print("Starting training with KFold cross-validation...")
    for fold, (train_idx, val_idx) in enumerate(kf.split(train_df)):
        print(f"--- Fold {fold+1}/{N_SPLITS} ---")
        train_fold_df = train_df.iloc[train_idx]
        val_fold_df = train_df.iloc[val_idx]

        # Crucial step: aggregates are computed on the train-fold data only
        X_train = feature_engineering(train_fold_df, train_fold_df, external_features)
        X_val = feature_engineering(val_fold_df, train_fold_df, external_features)

        y_train = np.log1p(train_fold_df["violation_count"])
        y_val = np.log1p(val_fold_df["violation_count"])

        # Ensure column order is the same
        X_val = X_val[X_train.columns]

        categorical_features = ["Street Name", "Violation Description"]
        for col in categorical_features:
            X_train[col] = X_train[col].astype("category")
            X_val[col] = X_val[col].astype("category")

        lgb_params = {
            "objective": "regression_l2",
            "metric": "rmse",
            "n_estimators": 2000,
            "learning_rate": 0.02,
            "feature_fraction": 0.8,
            "bagging_fraction": 0.8,
            "bagging_freq": 1,
            "lambda_l1": 0.1,
            "lambda_l2": 0.1,
            "num_leaves": 31,
            "verbose": -1,
            "n_jobs": -1,
            "seed": SEED,
            "boosting_type": "gbdt",
        }

        model = lgb.LGBMRegressor(**lgb_params)
        model.fit(
            X_train,
            y_train,
            eval_set=[(X_val, y_val)],
            eval_metric="rmse",
            callbacks=[lgb.early_stopping(100, verbose=False)],
            categorical_feature=categorical_features,
        )

        val_preds = model.predict(X_val)
        oof_preds[val_idx] = val_preds
        models.append(model)

    oof_preds_transformed = np.expm1(oof_preds)
    oof_preds_transformed[oof_preds_transformed < 0] = 0

    rmse_score = np.sqrt(
        mean_squared_error(train_df["violation_count"], oof_preds_transformed)
    )
    print("\n---------------------------------")
    print(f"Overall Validation RMSE: {rmse_score:.4f}")
    print("---------------------------------")

    return models, train_df


def predict(test_path, models, external_features, train_df_source):
    """
    Makes predictions on a test set using the trained models and full training
    data for feature aggregations.
    """
    print(f"Loading test data from {test_path}...")
    test_df = pd.read_csv(test_path)

    has_target = "violation_count" in test_df.columns
    if has_target:
        y_true = test_df["violation_count"]
        test_keys = test_df.drop(columns=["violation_count"])
    else:
        test_keys = test_df

    # --- Unseen Keys Analysis ---
    train_key_set = set(
        zip(
            train_df_source["Street Name"].str.upper().str.strip(),
            train_df_source["Violation Description"].str.upper().str.strip(),
        )
    )
    test_key_set = set(
        zip(
            test_keys["Street Name"].str.upper().str.strip(),
            test_keys["Violation Description"].str.upper().str.strip(),
        )
    )
    unseen_keys_count = len(test_key_set - train_key_set)
    print(
        f"Found {unseen_keys_count} (street_name, violation_type) pairs in test set not present in training set."
    )

    # Generate features for the test set using the FULL training data for aggs
    test_processed = feature_engineering(test_keys, train_df_source, external_features)

    # Prepare for prediction
    categorical_features = ["Street Name", "Violation Description"]
    for col in categorical_features:
        test_processed[col] = test_processed[col].astype("category")

    # Align test columns with model's expected feature order
    model_features = models[0].feature_name_
    test_processed = test_processed[model_features]

    test_preds_log = np.zeros(len(test_processed))
    for model in models:
        test_preds_log += model.predict(test_processed) / len(models)

    test_preds = np.expm1(test_preds_log)
    test_preds[test_preds < 0] = 0

    submission = test_keys.copy()
    submission["predicted_count"] = test_preds
    submission_path = os.path.join(WORKING_DIR, "submission.csv")
    submission.to_csv(submission_path, index=False)
    print(f"Submission file saved to {submission_path}")

    if has_target:
        test_rmse = np.sqrt(mean_squared_error(y_true, test_preds))
        print(f"Test RMSE: {test_rmse:.4f}")


def main():
    """Main execution function."""
    parser = argparse.ArgumentParser(description="NYC Parking Violation Prediction")
    parser.add_argument(
        "--train-path",
        type=str,
        default=DEFAULT_TRAIN_PATH,
        help="Path to the training data file.",
    )
    parser.add_argument(
        "--test-path",
        type=str,
        default=DEFAULT_TEST_PATH,
        help="(Optional) Path to the test/evaluation data file.",
    )
    args = parser.parse_args()

    if not os.path.exists(WORKING_DIR):
        os.makedirs(WORKING_DIR)

    # Load external features once
    external_features = load_external_data(os.path.join(INPUT_DIR, "corpus"))

    # Train model and get validation score
    models, train_df = train_and_evaluate(args.train_path, external_features)

    # Predict on test data if path is provided
    if args.test_path:
        if os.path.exists(args.test_path):
            predict(args.test_path, models, external_features, train_df)
        else:
            print(f"Warning: Test path '{args.test_path}' provided but file not found.")
    else:
        print("No test path provided. Skipping prediction.")


if __name__ == "__main__":
    main()
