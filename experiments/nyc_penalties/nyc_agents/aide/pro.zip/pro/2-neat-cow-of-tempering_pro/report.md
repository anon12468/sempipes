# Technical Report: NYC Parking Violation Prediction

## Introduction

This report outlines the methodology and empirical results from developing a model to predict parking violation counts in New York City. The objective was to forecast the number of violations for each `(street_name, violation_type)` pair using historical data from 2022. The primary performance metric for this regression task is the Root Mean Squared Error (RMSE).

The final solution employs a LightGBM regressor with a feature set derived from historical aggregates and external data sources. A key focus of the development process was establishing a robust, leakage-free validation framework to accurately estimate model performance.

## Preprocessing

Data preprocessing involved cleaning, feature engineering, and target transformation to prepare the data for the model.

### Data Cleaning & Transformation

-   **Identifier Standardization:** `Street Name` and `Violation Description` fields were standardized by converting them to uppercase and stripping leading/trailing whitespace to ensure consistency for joins and groupings.
-   **Target Transformation:** The target variable, `violation_count`, is a highly skewed count metric. A logarithmic transformation (`numpy.log1p`) was applied to the target before training to stabilize variance and make its distribution more amenable to the model's squared-error objective function, which is critical for optimizing RMSE.

### Feature Engineering

The model's predictive power relies heavily on engineered features from both the training data and external sources.

-   **Historical Aggregates:** The most informative features were derived from historical violation patterns. For each `Street Name` and `Violation Description`, aggregate statistics such as the mean, sum, standard deviation, and count of violations were calculated.
-   **External Data Augmentation:** To enrich the feature set, several external datasets were evaluated. Initial attempts utilized the 2005 Street Tree Census to generate features like tree counts and average diameter per street. However, subsequent experiments showed that data from a more recent Building Footprints dataset (providing features like building count and average area per street) yielded better performance. The final model incorporates these building-related features.

## Modelling Methods

### Model Selection

A LightGBM Regressor was chosen as the core model. This gradient boosting framework is highly efficient and performs well on tabular data. Its native handling of categorical features simplified the preprocessing pipeline by avoiding the need for one-hot encoding of high-cardinality features like street names.

### Validation Strategy

Establishing a reliable validation strategy was a critical and iterative process.

1.  **Initial Approach (`GroupKFold`):** A `GroupKFold` strategy, grouping by `Street Name`, was first implemented to ensure that streets in a validation fold were entirely unseen by the model during training in that fold.
2.  **Identified Flaw:** This approach created a critical issue: all street-level aggregate features for the validation set became null, as the streets did not exist in the corresponding training fold's data. This rendered the most powerful features useless during validation, leading to an unreliable performance estimate.
3.  **Final Approach (`KFold`):** The validation strategy was revised to use a standard `KFold`. This ensures that most streets are present in both the training and validation splits within a fold. To prevent data leakage, the feature engineering (i.e., calculation of aggregate statistics) was performed *inside* each cross-validation loop, using only the training portion of the data for that fold. This method provided meaningful features for the validation set while strictly preventing target information from leaking, resulting in a robust and realistic validation score.

### Model Training

-   **Objective Function:** The model's objective function was set to `regression_l2` (Mean Squared Error) to directly align the training process with the final evaluation metric, RMSE.
-   **Training Procedure:** The model was trained using a 5-fold cross-validation scheme. An ensemble of the five models trained during this process was used for generating final predictions. Early stopping was employed within each fold to prevent overfitting.

## Results Discussion

The final model, leveraging in-fold aggregate features, building footprint data, and a `KFold` validation strategy, achieved a reliable cross-validation **RMSE of 7.3567**.

The iterative development process revealed several key findings:
-   **Leakage Prevention is Paramount:** Calculating aggregate features outside the cross-validation loop leads to data leakage and artificially optimistic scores. Scoping feature engineering within each fold is essential for a trustworthy validation metric.
-   **Validation Strategy Matters:** The choice between `KFold` and `GroupKFold` has significant implications for feature utility. For this problem, `KFold` enabled the creation of meaningful aggregate features for validation sets.
-   **Feature Relevance:** More recent and relevant external data (building footprints) provided a greater performance lift than older, less-related data (tree census).
-   **Handling Unseen Keys:** For predictions on a test set, the model handles unseen streets or violation types by applying aggregate features calculated from the entire 2022 training dataset and imputing missing values with zero, a neutral and effective default.

## Future Work

While the current model performs well, several avenues for improvement exist:

-   **Hyperparameter Optimization:** Conduct a systematic search (e.g., Bayesian optimization) to fine-tune LightGBM hyperparameters for potentially better performance.
-   **Advanced Feature Engineering:** Explore additional external datasets, such as 311 service requests or business census data, to capture other signals that may correlate with parking violation patterns.
-   **Model Ensembling:** Combine the predictions of the LightGBM model with other gradient boosting models (e.g., XGBoost, CatBoost) or linear models to improve prediction robustness.