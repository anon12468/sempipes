# Technical Report: NYC Parking Violation Prediction

## Introduction
This report summarizes the experimental process of developing a model to predict parking violation counts for given `(street_name, violation_type)` pairs. The primary goal was to minimize the Root Mean Squared Error (RMSE) on future data. The methodology evolved through several iterations, focusing on robust feature engineering, external data enrichment, and sound validation practices to prevent common pitfalls like target leakage.

## Preprocessing

### Text Normalization
Street names and violation descriptions were standardized across all experiments to ensure consistent joins and feature creation. The standard procedure involved converting text to uppercase, stripping leading/trailing whitespace, and, in some cases, standardizing common street suffixes (e.g., `STREET` to `ST`).

### External Data Integration
Several external datasets from the provided corpus were evaluated for feature enrichment. Data was aggregated at the street-name level before being joined with the primary dataset.

- **Street Tree Census:** Provided counts of trees, average tree diameter, and the number of unique species per street.
- **311 Service Requests:** Used to calculate the total number of 311 requests per street, serving as a proxy for street activity or issues.
- **Street Centerline (CSCL) & PLUTO:** These datasets provided static physical attributes, such as the number of street segments, borough code, and building area statistics.

For unseen streets during inference, external features were imputed using global statistics (e.g., median segment count) calculated from the training set.

## Modelling Methods

### Model Selection
LightGBM was the primary model used, demonstrating strong performance on this tabular regression task. An early experiment with a Random Forest regressor also yielded a competitive baseline. Models were configured to optimize for an L1 loss (`regression_l1`) and evaluated using RMSE.

### Feature Engineering
The most significant improvements came from sophisticated feature engineering techniques.

- **Aggregate Features:** The core features were historical violation statistics (mean, sum, standard deviation, count) grouped by `street_name` and `violation_type`.
- **Target Leakage Prevention:** A critical finding was the risk of target leakage when generating aggregate features. The most effective solution was to generate these features using an out-of-fold (OOF) strategy. For each fold in a cross-validation setup, aggregate statistics were computed on the training portion and then merged onto the validation portion, ensuring a row's features were never influenced by its own target value.
- **SVD Embeddings:** To handle the high cardinality of street names and violation types, Truncated SVD was applied to the sparse `street_name` x `violation_type` interaction matrix. This created low-dimensional, dense vector representations (embeddings) for each street and violation type, capturing latent relationships.
- **Target Transformation:** The distribution of `violation_count` is highly skewed. An experiment was conducted to apply a `log1p` transformation to the target variable before training and feature creation. Predictions were then inverse-transformed using `expm1`.

### Validation Strategy
The validation approach evolved from a simple 80/20 train-test split to more robust cross-validation methods. `KFold` and `GroupKFold` (grouping by `street_name`) were used to generate more reliable performance estimates and mitigate the risk of an overly optimistic score from a single, lucky data split.

## Results Discussion
The experiments progressed from a baseline RMSE of **28.53** to a final, robustly validated RMSE of **15.55**.

- The most significant performance gain was achieved by implementing an out-of-fold strategy for creating aggregate features, which addressed a critical target leakage bug. This single change, combined with SVD embeddings and 311 data, improved the validation RMSE from over 24 to **15.55**.

- While various external datasets were tested, the 311 service requests consistently contributed to the best-performing models. The impact of other datasets like the Street Centerline was less clear, sometimes degrading performance, which suggests they may have introduced noise or required more sophisticated feature engineering.

- The GroupKFold validation strategy provided a more realistic performance estimate (RMSE of **21.37**) compared to a single holdout split, highlighting its importance for this dataset structure.

- The attempt to use a `log1p` target transformation resulted in a significantly worse RMSE of **238.81**. This indicates that while theoretically sound, this approach may interact poorly with the selected features, loss function, or hyperparameters and requires further investigation.

## Future Work
- **Hyperparameter Tuning:** Conduct systematic hyperparameter optimization for the LightGBM model, as default or lightly-tuned parameters were used throughout the experiments.
- **Feature Engineering:** Further explore interactions between features and investigate the poor performance of the Street Centerline data. Creating spatial features from geographic data could also be beneficial.
- **Ensembling:** Combine predictions from multiple models (e.g., LightGBM, Random Forest, neural networks) to improve prediction stability and accuracy.