import pandas as pd
import numpy as np
import lightgbm as lgb
from sklearn.model_selection import train_test_split, KFold
from sklearn.metrics import mean_squared_error
from sklearn.decomposition import TruncatedSVD
from scipy.sparse import csr_matrix
import argparse
import os
import warnings

# Suppress warnings for cleaner output
warnings.filterwarnings("ignore")

# Define constants
INPUT_DIR = "/Users/USER/Documents/UNI/SS26/nyc_open_data/train/all_data"
WORKING_DIR = "/Users/USER/Documents/UNI/SS26/nyc_open_data/train/all_data/working"
SVD_COMPONENTS = 20
RANDOM_STATE = 42
KFOLD_SPLITS = 5


def clean_col_names(df):
    """Cleans column names to be more programmer-friendly."""
    cols = df.columns
    new_cols = [c.replace(" ", "_").lower() for c in cols]
    df.columns = new_cols
    return df


class FeatureEngineer:
    """A class to handle feature engineering, fitting on train and transforming test."""

    def __init__(self, n_splits=KFOLD_SPLITS):
        self.transformers = {}
        self.n_splits = n_splits

    def fit_transform(self, df, external_df_path):
        """
        Fits transformers on the data and returns the transformed dataframe.
        Crucially, aggregate features are created using an out-of-fold strategy to prevent target leakage.
        """
        # --- Preprocessing ---
        df["street_name_orig"] = df["street_name"]
        df["violation_description_orig"] = df["violation_description"]
        df["street_name"] = df["street_name"].astype(str).str.upper().str.strip()
        df["violation_description"] = (
            df["violation_description"].astype(str).str.upper().str.strip()
        )

        # --- FIT TRANSFORMERS on FULL DATA (for later use on test set) ---

        # 1. External Features (311 Service Requests)
        df_311 = pd.read_parquet(external_df_path)
        if "Street Name" in df_311.columns:
            df_311["Street Name"] = (
                df_311["Street Name"].astype(str).str.upper().str.strip()
            )
            street_311_counts = (
                df_311.groupby("Street Name")
                .size()
                .reset_index(name="311_requests_count")
            )
            self.transformers["311_counts"] = street_311_counts
        else:
            self.transformers["311_counts"] = pd.DataFrame(
                columns=["Street Name", "311_requests_count"]
            )

        # 2. Aggregated Features (global transformers for test set)
        self.transformers["global_mean"] = df["violation_count"].mean()

        street_agg = (
            df.groupby("street_name")["violation_count"]
            .agg(["mean", "sum", "count"])
            .reset_index()
        )
        street_agg.columns = [
            "street_name",
            "street_mean",
            "street_sum",
            "street_count",
        ]
        self.transformers["street_agg"] = street_agg

        vio_agg = (
            df.groupby("violation_description")["violation_count"]
            .agg(["mean", "sum", "count"])
            .reset_index()
        )
        vio_agg.columns = ["violation_description", "vio_mean", "vio_sum", "vio_count"]
        self.transformers["vio_agg"] = vio_agg

        # 3. SVD Embeddings (global transformers for test set)
        street_map = {name: i for i, name in enumerate(df["street_name"].unique())}
        vio_map = {
            name: i for i, name in enumerate(df["violation_description"].unique())
        }
        self.transformers["street_map"] = street_map
        self.transformers["vio_map"] = vio_map

        rows = df["street_name"].map(street_map)
        cols = df["violation_description"].map(vio_map)
        sparse_matrix = csr_matrix(
            (df["violation_count"], (rows, cols)), shape=(len(street_map), len(vio_map))
        )

        svd = TruncatedSVD(n_components=SVD_COMPONENTS, random_state=RANDOM_STATE)
        street_features = svd.fit_transform(sparse_matrix)
        violation_features = svd.components_.T

        street_embeddings = pd.DataFrame(
            street_features, index=street_map.keys()
        ).add_prefix("street_svd_")
        vio_embeddings = pd.DataFrame(
            violation_features, index=vio_map.keys()
        ).add_prefix("vio_svd_")
        self.transformers["svd_street_embeddings"] = street_embeddings
        self.transformers["svd_vio_embeddings"] = vio_embeddings

        # --- GENERATE LEAK-FREE FEATURES for the provided training DataFrame ---

        # 1. External Features
        df = pd.merge(
            df,
            self.transformers["311_counts"],
            how="left",
            left_on="street_name",
            right_on="Street Name",
        )
        df.drop("Street Name", axis=1, inplace=True, errors="ignore")
        df["311_requests_count"].fillna(0, inplace=True)

        # 2. Aggregated Features (Out-of-Fold Generation to prevent leakage)
        kf = KFold(n_splits=self.n_splits, shuffle=True, random_state=RANDOM_STATE)
        agg_cols = [
            "street_mean",
            "street_sum",
            "street_count",
            "vio_mean",
            "vio_sum",
            "vio_count",
        ]
        for col in agg_cols:
            df[col] = np.nan

        for train_idx, val_idx in kf.split(df):
            df_train, df_val = df.iloc[train_idx], df.iloc[val_idx]

            # Street aggregations on the training part of the fold
            street_agg_fold = (
                df_train.groupby("street_name")["violation_count"]
                .agg(["mean", "sum", "count"])
                .rename(
                    columns={
                        "mean": "street_mean",
                        "sum": "street_sum",
                        "count": "street_count",
                    }
                )
            )
            # Violation aggregations on the training part of the fold
            vio_agg_fold = (
                df_train.groupby("violation_description")["violation_count"]
                .agg(["mean", "sum", "count"])
                .rename(
                    columns={"mean": "vio_mean", "sum": "vio_sum", "count": "vio_count"}
                )
            )

            # Merge fold-based aggregates onto the validation part of the fold
            val_street_agg = df_val[["street_name"]].merge(
                street_agg_fold, on="street_name", how="left"
            )
            val_vio_agg = df_val[["violation_description"]].merge(
                vio_agg_fold, on="violation_description", how="left"
            )

            # Assign computed features to the original dataframe's validation indices
            df.loc[df.index[val_idx], ["street_mean", "street_sum", "street_count"]] = (
                val_street_agg[["street_mean", "street_sum", "street_count"]].values
            )
            df.loc[df.index[val_idx], ["vio_mean", "vio_sum", "vio_count"]] = (
                val_vio_agg[["vio_mean", "vio_sum", "vio_count"]].values
            )

        # Fill any NaNs that might have occurred (e.g., a key only in one fold) with global stats
        global_mean = self.transformers["global_mean"]
        df["street_mean"].fillna(global_mean, inplace=True)
        df["street_sum"].fillna(global_mean, inplace=True)
        df["street_count"].fillna(0, inplace=True)
        df["vio_mean"].fillna(global_mean, inplace=True)
        df["vio_sum"].fillna(global_mean, inplace=True)
        df["vio_count"].fillna(0, inplace=True)

        # 3. SVD Embeddings (merging globally fitted ones)
        df = df.merge(
            street_embeddings, how="left", left_on="street_name", right_index=True
        )
        df = df.merge(
            vio_embeddings,
            how="left",
            left_on="violation_description",
            right_index=True,
        )
        for i in range(SVD_COMPONENTS):
            df[f"street_svd_{i}"].fillna(0, inplace=True)
            df[f"vio_svd_{i}"].fillna(0, inplace=True)

        return df

    def transform(self, df):
        """Transforms a new dataframe using the fitted transformers."""
        original_rows = len(df)

        df["street_name_orig"] = df["street_name"]
        df["violation_description_orig"] = df["violation_description"]
        df["street_name"] = df["street_name"].astype(str).str.upper().str.strip()
        df["violation_description"] = (
            df["violation_description"].astype(str).str.upper().str.strip()
        )

        # 1. External Features
        df = pd.merge(
            df,
            self.transformers["311_counts"],
            how="left",
            left_on="street_name",
            right_on="Street Name",
        )
        df.drop("Street Name", axis=1, inplace=True, errors="ignore")
        df["311_requests_count"].fillna(0, inplace=True)

        # 2. Aggregated Features
        global_mean = self.transformers["global_mean"]
        df = pd.merge(df, self.transformers["street_agg"], on="street_name", how="left")
        df["street_mean"].fillna(global_mean, inplace=True)
        df["street_sum"].fillna(global_mean, inplace=True)
        df["street_count"].fillna(0, inplace=True)
        df = pd.merge(
            df, self.transformers["vio_agg"], on="violation_description", how="left"
        )
        df["vio_mean"].fillna(global_mean, inplace=True)
        df["vio_sum"].fillna(global_mean, inplace=True)
        df["vio_count"].fillna(0, inplace=True)

        # 3. SVD Embeddings
        street_embeddings = self.transformers["svd_street_embeddings"]
        vio_embeddings = self.transformers["svd_vio_embeddings"]

        unseen_streets_df = df[~df["street_name"].isin(street_embeddings.index)]
        unseen_streets = (
            len(unseen_streets_df["street_name"].unique())
            if not unseen_streets_df.empty
            else 0
        )
        unseen_violations_df = df[
            ~df["violation_description"].isin(vio_embeddings.index)
        ]
        unseen_violations = (
            len(unseen_violations_df["violation_description"].unique())
            if not unseen_violations_df.empty
            else 0
        )

        print(f"Test data has {unseen_streets} unseen street names.")
        print(f"Test data has {unseen_violations} unseen violation types.")

        df = df.merge(
            street_embeddings, how="left", left_on="street_name", right_index=True
        )
        df = df.merge(
            vio_embeddings,
            how="left",
            left_on="violation_description",
            right_index=True,
        )

        for i in range(SVD_COMPONENTS):
            df[f"street_svd_{i}"].fillna(0, inplace=True)
            df[f"vio_svd_{i}"].fillna(0, inplace=True)

        assert (
            len(df) == original_rows
        ), "Rows were lost or added during feature engineering."
        return df


def main(args):
    train_df = pd.read_csv(args.train_path)
    train_df = clean_col_names(train_df)

    print("--- Development Phase: Training on 80% of 2022 data, validating on 20% ---")
    dev_train_df, dev_val_df = train_test_split(
        train_df, test_size=0.2, random_state=RANDOM_STATE
    )

    fe = FeatureEngineer()
    external_data_path = os.path.join(
        "/Users/USER/Documents/UNI/SS26/nyc_open_data/train/all_data/corpus", "311_service_requests_for_2022.parquet"
    )

    print("Processing training data (with OOF features)...")
    X_train_processed = fe.fit_transform(dev_train_df.copy(), external_data_path)
    y_train = X_train_processed["violation_count"]

    print("Processing validation data...")
    X_val_processed = fe.transform(dev_val_df.copy())
    y_val = X_val_processed["violation_count"]

    features = [
        c
        for c in X_train_processed.columns
        if c
        not in [
            "street_name",
            "violation_description",
            "violation_count",
            "street_name_orig",
            "violation_description_orig",
        ]
    ]

    lgb_params = {
        "objective": "regression_l1",
        "metric": "rmse",
        "n_estimators": 2000,
        "learning_rate": 0.02,
        "feature_fraction": 0.8,
        "bagging_fraction": 0.8,
        "bagging_freq": 1,
        "lambda_l1": 0.1,
        "lambda_l2": 0.1,
        "num_leaves": 31,
        "verbose": -1,
        "n_jobs": -1,
        "seed": RANDOM_STATE,
    }

    model = lgb.LGBMRegressor(**lgb_params)
    model.fit(
        X_train_processed[features],
        y_train,
        eval_set=[(X_val_processed[features], y_val)],
        eval_metric="rmse",
        callbacks=[lgb.early_stopping(100, verbose=False)],
    )

    val_preds = model.predict(X_val_processed[features])
    val_preds = np.maximum(0, val_preds)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    print(f"\nValidation Metric (RMSE on 2022 holdout): {val_rmse:.4f}")
    test_path = "/Users/USER/Documents/UNI/SS26/nyc_open_data/violations_per_street_2023.csv"
    if test_path:
        print(
            f"\n--- Inference Phase: Training on all 2022 data and predicting on {test_path} ---"
        )

        # 1. Retrain on full 2022 data
        fe_final = FeatureEngineer()
        print("Processing full training data (with OOF features)...")
        X_full_train = fe_final.fit_transform(train_df.copy(), external_data_path)
        y_full_train = X_full_train["violation_count"]

        final_model = lgb.LGBMRegressor(**lgb_params)
        final_model.fit(
            X_full_train[features], y_full_train
        )  # Train without early stopping on full data

        # 2. Load and process test data
        test_df = pd.read_csv(args.test_path)
        test_df = clean_col_names(test_df)
        is_eval = "violation_count" in test_df.columns
        if is_eval:
            y_test_true = test_df["violation_count"]

        print("Processing test data...")
        X_test_processed = fe_final.transform(test_df.copy())

        # 3. Predict and save
        test_preds = final_model.predict(X_test_processed[features])
        test_preds = np.maximum(0, test_preds)

        submission_df = pd.DataFrame(
            {
                "street_name": X_test_processed["street_name_orig"],
                "violation_type": X_test_processed["violation_description_orig"],
                "predicted_count": test_preds,
            }
        )

        if not os.path.exists(WORKING_DIR):
            os.makedirs(WORKING_DIR)
        submission_path = os.path.join(WORKING_DIR, "submission.csv")
        submission_df.to_csv(submission_path, index=False)
        print(f"Submission file saved to {submission_path}")

        # 4. Score if ground truth is available
        if is_eval:
            test_rmse = np.sqrt(mean_squared_error(y_test_true, test_preds))
            print(f"Test RMSE on {args.test_path}: {test_rmse:.4f}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Parking Violation Prediction")
    parser.add_argument(
        "--train-path",
        type=str,
        default=os.path.join(INPUT_DIR, "violations_per_street_2022.csv"),
        help="Path to the training data file.",
    )
    parser.add_argument(
        "--test-path",
        type=str,
        default=None,
        help="Path to the test/evaluation data file. (Optional)",
    )

    # To run inference as per the original script, we use the train file as a dummy test file.
    test_path_to_simulate = os.path.join(INPUT_DIR, "violations_per_street_2022.csv")

    cli_args = [f'--train-path={parser.get_default("train_path")}']
    if test_path_to_simulate:
        cli_args.append(f"--test-path={test_path_to_simulate}")

    simulated_args = parser.parse_args(cli_args)
    main(simulated_args)
