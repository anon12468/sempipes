# Technical Report: NYC Parking Violation Prediction

## Introduction

This report summarizes the empirical findings from developing a model to predict parking violation counts in New York City. The primary goal was to predict the number of violations for each (street, violation type) pair using 2022 aggregate data. The model's performance was evaluated based on the Root Mean Squared Error (RMSE). The development process involved iterative feature engineering, incorporating external datasets, and refining the validation methodology to prevent data leakage.

## Preprocessing

Data preprocessing was a critical first step to ensure consistency across different data sources.

*   **Street Name Standardization**: A cleaning function was applied to all street name fields across datasets. This function standardized names by converting them to uppercase, stripping leading/trailing whitespace, and normalizing multiple spaces. This was essential for accurate joins between the primary violation data and external corpus datasets.
*   **External Data Integration**: To enrich the feature set, two external datasets were incorporated:
    *   **2005 Street Tree Census**: This dataset was used to generate a `tree_count` feature for each street, providing a proxy for street characteristics.
    *   **311 Service Requests**: This dataset was filtered for parking-related complaints. Initially, a single feature for all "Illegal Parking" complaints was used. This was later refined to create granular, per-street counts for specific complaint types like "Blocked Driveway" and "Abandoned Vehicle".

## Modelling Methods

### Model and Target

A LightGBM gradient boosting model was selected for its performance and efficiency in handling categorical features. The target variable, `violation_count`, exhibited a highly skewed distribution typical of count data. To address this, a logarithmic transformation (`numpy.log1p`) was applied, and the model was trained to predict the transformed value. Predictions were then converted back to the original scale using `numpy.expm1` before calculating the RMSE. An alternative approach using a Tweedie Regressor also proved highly effective, particularly due to its suitability for count data with many zeros.

### Feature Engineering

The feature set was developed iteratively:

1.  **Baseline Statistical Features**: The initial model used statistical aggregates (mean, median, standard deviation, count) of violation counts, grouped by `Street Name` and `Violation Description`.
2.  **External Signal Integration**: Features from the 311 Service Requests and Tree Census datasets were added. The most significant performance gain came from using granular 311 complaint counts for different types of parking issues.
3.  **Interaction and Ratio Features**: Experiments were conducted to create features representing the interaction between street and violation type characteristics (e.g., ratio of a street's mean violations to the global mean). While conceptually sound, these features did not improve performance over the more direct signals from the granular 311 data.

### Validation and Leakage Prevention

A 5-fold cross-validation strategy was employed to ensure robust evaluation. A key technical challenge was preventing data leakage during feature creation. The final, most reliable models implemented a leak-proof feature generation process:

*   **Out-of-Fold Generation**: For each fold, statistical features for the validation set were calculated using only the data from the corresponding training set.
*   **Nested CV for Training Features**: To generate non-leaky features for the training set itself (a common source of bugs), a nested cross-validation loop was used, ensuring that a row's features were never influenced by its own target value.
*   **Handling Unseen Keys**: For keys (streets or violations) in a validation or test set not present in the training data, feature values were imputed using global average statistics calculated from the training set.

## Results Discussion

The model's performance improved significantly through iterative feature engineering and methodological refinement.

| Iteration Description                                        | 5-Fold CV RMSE |
| ------------------------------------------------------------ | -------------- |
| Baseline (Statistical Aggregates)                            | 239.52         |
| + 311 Complaint Counts (Single Feature)                      | 205.47         |
| + Granular 311 Complaint Features                            | 52.51          |
| + Bug Fix (Leak-Proof Target Encoding) with Tweedie Regressor | **7.37**       |

The baseline model using only historical aggregates established an initial RMSE of 239.52. Incorporating external data from 311 service requests provided a substantial improvement, lowering the RMSE to 205.47. The most impactful feature engineering step was disaggregating 311 complaints into specific types, which further reduced the RMSE to 52.51.

However, the largest performance gain resulted from a critical bug fix in the feature generation process. By implementing a fully leak-proof target encoding strategy and switching to a Tweedie Regressor, which is well-suited for this data distribution, the validation RMSE was drastically reduced to **7.37**. This highlights that a robust validation framework and careful prevention of data leakage were more critical to model performance than any single feature.

## Future Work

*   **Explore Additional External Data**: Incorporate other relevant datasets such as weather patterns, public holidays, or local business density, which may influence parking violation frequency.
*   **Hyperparameter Optimization**: Conduct systematic hyperparameter tuning for the LightGBM and Tweedie models to potentially achieve further performance gains.
*   **Advanced Feature Engineering**: Investigate more complex feature interactions and explore embedding techniques for the high-cardinality `Street Name` and `Violation Description` features.