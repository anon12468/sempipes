import pandas as pd
import numpy as np
import argparse
import os
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error
from sklearn.linear_model import TweedieRegressor
import sys
import warnings

# Suppress warnings for a cleaner output
warnings.filterwarnings("ignore")

# --- 1. Data Loading and Initial Preparation ---


def load_data(train_path, test_path=None, corpus_path="input/corpus"):
    """Loads train, optional test, and corpus data."""
    # Load core training data
    df_train = pd.read_csv(train_path)

    df_test = None
    if test_path and os.path.exists(test_path):
        df_test = pd.read_csv(test_path)

    # Load and process corpus data (Street Tree Census)
    tree_census_path = os.path.join(
        corpus_path, "2005_street_tree_census__29bw-z7pj.parquet"
    )
    if os.path.exists(tree_census_path):
        df_trees = pd.read_parquet(tree_census_path)
        # Standardize street names for joining
        df_trees["street_name_std"] = df_trees["address"].str.upper().str.strip()
        # Aggregate to get tree count per street
        street_tree_counts = (
            df_trees.groupby("street_name_std").size().reset_index(name="tree_count")
        )
    else:
        # Create a dummy dataframe if corpus file is not found
        street_tree_counts = pd.DataFrame(columns=["street_name_std", "tree_count"])

    return df_train, df_test, street_tree_counts


def preprocess(df, tree_data):
    """Prepares the main dataframe by cleaning columns and merging corpus data."""
    # Standardize column names
    new_cols = [c.lower().replace(" ", "_") for c in df.columns]
    df.columns = new_cols
    # Accommodate different column names for violation type
    if "violation_description" not in df.columns and "violation_type" in df.columns:
        df.rename(columns={"violation_type": "violation_description"}, inplace=True)

    # Standardize join key
    df["street_name_std"] = df["street_name"].str.upper().str.strip()

    # Merge with tree census data
    df = pd.merge(df, tree_data, on="street_name_std", how="left")
    df["tree_count"] = (
        df["tree_count"].fillna(0).astype(int)
    )  # Streets with no trees get 0

    return df


# --- 2. Model Training and Validation (Bugfix applied here) ---


def train_and_evaluate(df):
    """
    Trains models using 5-fold cross-validation with a leak-proof target encoding strategy.
    Returns trained models and their corresponding mappers.
    """
    features = ["street_mean_target", "violation_mean_target", "tree_count"]
    target = "violation_count"

    # Outer K-Fold for creating out-of-fold predictions and validation score
    outer_kf = KFold(n_splits=5, shuffle=True, random_state=42)
    oof_predictions = np.zeros(df.shape[0])
    models_and_mappers = []

    for fold, (train_idx, val_idx) in enumerate(outer_kf.split(df)):
        print(f"--- Fold {fold+1}/5 ---")
        train_fold, val_fold = df.iloc[train_idx].copy(), df.iloc[val_idx].copy()

        # 1. First, create mappers from the full train_fold.
        #    These will be used for the val_fold and for the final test set.
        overall_mean = train_fold[target].mean()
        street_map = train_fold.groupby("street_name")[target].mean()
        violation_map = train_fold.groupby("violation_description")[target].mean()

        # 2. Create features for the validation set using these mappers.
        val_fold["street_mean_target"] = (
            val_fold["street_name"].map(street_map).fillna(overall_mean)
        )
        val_fold["violation_mean_target"] = (
            val_fold["violation_description"].map(violation_map).fillna(overall_mean)
        )

        # 3. BUGFIX: Create LEAK-PROOF features for the training set using an inner CV loop.
        train_fold["street_mean_target"] = 0.0
        train_fold["violation_mean_target"] = 0.0

        inner_kf = KFold(n_splits=5, shuffle=False)
        for inner_train_idx, inner_val_idx in inner_kf.split(train_fold):
            # Use .iloc to get subsets of the train_fold DataFrame
            inner_train_set = train_fold.iloc[inner_train_idx]

            # Calculate means ONLY on the inner training part
            inner_street_map = inner_train_set.groupby("street_name")[target].mean()
            inner_violation_map = inner_train_set.groupby("violation_description")[
                target
            ].mean()

            # Apply to the inner validation part and update the main train_fold DataFrame
            inner_val_indices = train_fold.iloc[inner_val_idx].index
            train_fold.loc[inner_val_indices, "street_mean_target"] = train_fold.loc[
                inner_val_indices, "street_name"
            ].map(inner_street_map)
            train_fold.loc[inner_val_indices, "violation_mean_target"] = train_fold.loc[
                inner_val_indices, "violation_description"
            ].map(inner_violation_map)

        # Fill any NaNs that might have resulted from small groups with the fold's overall mean
        train_fold.fillna(
            {"street_mean_target": overall_mean, "violation_mean_target": overall_mean},
            inplace=True,
        )

        # 4. Define feature/target sets and train the model
        X_train, y_train = train_fold[features], train_fold[target]
        X_val = val_fold[features]

        model = TweedieRegressor(power=1.5, alpha=0.5, link="log", max_iter=500)
        model.fit(X_train, y_train)

        # 5. Predict on the validation set and store results
        preds = model.predict(X_val)
        oof_predictions[val_idx] = preds

        # Store the model and the mappers derived from the full training fold for test inference
        models_and_mappers.append((model, street_map, violation_map, overall_mean))

    # --- Final Validation Score ---
    oof_predictions[oof_predictions < 0] = 0
    val_rmse = np.sqrt(mean_squared_error(df[target], oof_predictions))
    print("\n--- Validation Results ---")
    print(f"5-Fold CV RMSE: {val_rmse:.4f}")

    return models_and_mappers


# --- 3. Inference on Test Data ---


def predict_on_test(test_df, models_and_mappers):
    """Predicts on the test set using an ensemble of models from cross-validation."""
    print("\n--- Generating Test Predictions ---")

    features = ["street_mean_target", "violation_mean_target", "tree_count"]
    test_predictions_all_folds = []

    all_seen_streets = set()
    all_seen_violations = set()

    for model, street_map, violation_map, overall_mean in models_and_mappers:
        # Update the sets of all seen keys across all folds
        all_seen_streets.update(street_map.index)
        all_seen_violations.update(violation_map.index)

        test_fold_df = test_df.copy()

        # Apply the maps from this specific fold
        test_fold_df["street_mean_target"] = (
            test_fold_df["street_name"].map(street_map).fillna(overall_mean)
        )
        test_fold_df["violation_mean_target"] = (
            test_fold_df["violation_description"]
            .map(violation_map)
            .fillna(overall_mean)
        )

        X_test = test_fold_df[features]

        # Predict
        fold_preds = model.predict(X_test)
        test_predictions_all_folds.append(fold_preds)

    # Averaging the predictions from all 5 models (ensembling)
    final_predictions = np.mean(test_predictions_all_folds, axis=0)
    final_predictions[final_predictions < 0] = 0  # Ensure non-negativity

    # Report unseen keys
    unseen_streets_mask = ~test_df["street_name"].isin(all_seen_streets)
    unseen_violations_mask = ~test_df["violation_description"].isin(all_seen_violations)

    unseen_rows_mask = unseen_streets_mask | unseen_violations_mask
    num_unseen_rows = unseen_rows_mask.sum()

    print(f"Test set has {len(test_df)} rows.")
    print(
        f"Found {num_unseen_rows} rows with at least one key (street or violation) not seen in any training fold."
    )
    print("These were handled by imputing with the fold-specific training data mean.")

    return final_predictions, test_df


# --- Main Execution ---


def main():
    parser = argparse.ArgumentParser(description="NYC Parking Violations Prediction")
    parser.add_argument(
        "--train-path", type=str, default="/Users/USER/Documents/UNI/SS26/nyc_open_data/train/all_data/violations_per_street_2022.csv"
    )
    parser.add_argument("--test-path", type=str, default="/Users/USER/Documents/UNI/SS26/nyc_open_data/violations_per_street_2023.csv")
    parser.add_argument("--corpus-path", type=str, default="input/corpus")

    # In some environments, arguments might not be passed; we parse known args.
    args, unknown = parser.parse_known_args()

    # Overwrite with a default test file if it exists and no test path is given
    default_test_path = "input/violations_per_street_2023_test_with_gt.csv"
    if args.test_path is None and os.path.exists(default_test_path):
        args.test_path = default_test_path
        print(f"Found default test file, using: {default_test_path}")

    print("--- Starting Pipeline ---")

    # Load and preprocess data
    df_train_raw, df_test_raw, tree_data = load_data(
        args.train_path, args.test_path, args.corpus_path
    )
    df_train = preprocess(df_train_raw.copy(), tree_data)

    # Train model and get validation score
    models_and_mappers = train_and_evaluate(df_train)

    # Handle test set if provided
    if args.test_path and df_test_raw is not None:
        has_truth = "violation_count" in df_test_raw.columns

        df_test = preprocess(df_test_raw.copy(), tree_data)

        predictions, df_test_processed = predict_on_test(
            df_test.copy(), models_and_mappers
        )

        # Prepare submission file
        submission_df = pd.DataFrame()
        submission_df["street_name"] = df_test_processed["street_name"]
        submission_df["violation_type"] = df_test_processed["violation_description"]
        submission_df["predicted_count"] = predictions.round()

        # Save submission file
        os.makedirs("./working", exist_ok=True)
        submission_df.to_csv("./working/submission.csv", index=False)
        print("\nSubmission file 'submission.csv' created in './working/'")

        # Report test score if ground truth is available
        if has_truth:
            # Drop rows with NaN in ground truth before scoring if any
            eval_df = df_test_processed.copy()
            eval_df["predictions"] = predictions
            eval_df.dropna(subset=["violation_count"], inplace=True)

            test_rmse = np.sqrt(
                mean_squared_error(eval_df["violation_count"], eval_df["predictions"])
            )
            print("\n--- Test Set Results ---")
            print(f"RMSE on provided test file: {test_rmse:.4f}")

    print("\n--- Pipeline Finished ---")


if __name__ == "__main__":
    main()
