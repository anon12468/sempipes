import pandas as pd
import numpy as np
import lightgbm as lgb
from sklearn.model_selection import KFold
from sklearn.preprocessing import OrdinalEncoder
from sklearn.metrics import mean_squared_error
import argparse
import os

# Define file paths
TRAIN_FILE = "./input/violations_per_street_2022.csv"
VIOLATION_CODES_FILE = "./input/corpus/dof_parking_violation_codes.csv"
WORKING_DIR = "./working"
SUBMISSION_FILE = os.path.join(WORKING_DIR, "submission.csv")


def run_solution():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument(
        "--train-path",
        type=str,
        default=TRAIN_FILE,
        help="Path to the 2022 training data CSV.",
    )
    parser.add_argument(
        "--test-path",
        type=str,
        default=None,
        help="Path to the test/evaluation data CSV (optional).",
    )
    args = parser.parse_args()

    # Create working directory if it doesn't exist
    os.makedirs(WORKING_DIR, exist_ok=True)

    # --- 1. Load Data ---
    print(f"Loading training data from {args.train_path}...")
    train_df = pd.read_csv(args.train_path)

    print(f"Loading augmentation data from {VIOLATION_CODES_FILE}...")
    violation_codes_df = pd.read_csv(VIOLATION_CODES_FILE)

    # Standardize column names for merging
    violation_codes_df = violation_codes_df.rename(
        columns={"VIOLATION DESCRIPTION": "Violation Description"}
    )

    # Select relevant columns from violation_codes_df for augmentation and handle duplicates
    violation_codes_df = violation_codes_df.drop_duplicates(
        subset=["Violation Description"]
    )

    # --- 2. Feature Engineering (Augmentation) ---
    print("Augmenting training data with violation codes...")
    train_df = pd.merge(
        train_df,
        violation_codes_df[
            ["Violation Description", "Violation Category", "Fine Amount"]
        ],
        on="Violation Description",
        how="left",
    )

    # Fill NaN values introduced by merge (for violation descriptions not found in codes file)
    train_df["Violation Category"] = train_df["Violation Category"].fillna(
        "UNKNOWN_CATEGORY"
    )
    # Use median fine amount from the available data. If all are NaN, use 0.
    train_df["Fine Amount"] = train_df["Fine Amount"].fillna(
        train_df["Fine Amount"].median()
        if not train_df["Fine Amount"].isnull().all()
        else 0
    )

    # Define features and target
    features = [
        "Street Name",
        "Violation Description",
        "Violation Category",
        "Fine Amount",
    ]
    target = "violation_count"

    # Store original target for validation metric calculation
    y_original = train_df[target].copy()

    # --- 3. Preprocessing: Ordinal Encoding for Categorical Features ---
    categorical_features = [
        "Street Name",
        "Violation Description",
        "Violation Category",
    ]

    # Initialize OrdinalEncoder. handle_unknown='use_encoded_value' is crucial for test data,
    # mapping unseen categories to `unknown_value` (-1 in this case).
    encoder = OrdinalEncoder(
        handle_unknown="use_encoded_value", unknown_value=-1, dtype=int
    )

    print("Fitting OrdinalEncoder on categorical features...")
    # Fit and transform training data
    train_df[categorical_features] = encoder.fit_transform(
        train_df[categorical_features]
    )

    X = train_df[features]

    # --- 4. Model Training and Validation (5-Fold Cross-Validation) ---
    print("Starting 5-fold cross-validation...")
    kf = KFold(n_splits=5, shuffle=True, random_state=42)

    fold_rmses = []

    # LightGBM parameters for a simple, robust model
    lgb_params = {
        "objective": "regression",  # Changed to L2 loss for direct RMSE optimization
        "metric": "rmse",
        "n_estimators": 1000,
        "learning_rate": 0.05,
        "feature_fraction": 0.8,
        "bagging_fraction": 0.8,
        "bagging_freq": 1,
        "lambda_l1": 0.1,
        "lambda_l2": 0.1,
        "num_leaves": 31,
        "verbose": -1,  # Suppress verbose output
        "n_jobs": -1,
        "seed": 42,
        "boosting_type": "gbdt",
    }

    for fold, (train_index, val_index) in enumerate(kf.split(X, y_original)):
        X_train, X_val = X.iloc[train_index], X.iloc[val_index]
        y_train_original, y_val_original = (
            y_original.iloc[train_index],
            y_original.iloc[val_index],
        )

        # Apply log1p transformation to the training target
        y_train_transformed = np.log1p(y_train_original)

        model = lgb.LGBMRegressor(**lgb_params)
        model.fit(
            X_train,
            y_train_transformed,  # Train on transformed target
            eval_set=[
                (X_val, np.log1p(y_val_original))
            ],  # Eval set also uses transformed target for early stopping
            eval_metric="rmse",
            callbacks=[lgb.early_stopping(100, verbose=False)],
        )  # Early stopping

        val_preds_transformed = model.predict(X_val)
        val_preds = np.expm1(val_preds_transformed)  # Inverse transform
        val_preds = np.maximum(0, val_preds)  # Clip predictions to non-negative

        fold_rmse = np.sqrt(
            mean_squared_error(y_val_original, val_preds)
        )  # Calculate RMSE on original scale
        fold_rmses.append(fold_rmse)
        print(f"Fold {fold+1} RMSE: {fold_rmse:.4f}")

    avg_rmse = np.mean(fold_rmses)
    print(f"\nAverage 5-Fold Validation RMSE: {avg_rmse:.4f}")

    # --- 5. Prediction for Test Data (if test_path provided) ---
    if args.test_path:
        print(f"\nLoading test data from {args.test_path} for prediction...")
        test_df = pd.read_csv(args.test_path)

        # Store original keys for submission and unseen key analysis
        submission_df_original_keys = test_df[
            ["Street Name", "Violation Description"]
        ].copy()

        # Augment test data using the same logic as training
        test_df = pd.merge(
            test_df,
            violation_codes_df[
                ["Violation Description", "Violation Category", "Fine Amount"]
            ],
            on="Violation Description",
            how="left",
        )
        test_df["Violation Category"] = test_df["Violation Category"].fillna(
            "UNKNOWN_CATEGORY"
        )
        # Use median fine amount from the training data for consistency
        test_df["Fine Amount"] = test_df["Fine Amount"].fillna(
            train_df["Fine Amount"].median()
        )

        # Preprocess test data using the *fitted* encoder
        print("Transforming test data with fitted OrdinalEncoder...")
        test_df[categorical_features] = encoder.transform(test_df[categorical_features])

        X_test = test_df[features]

        # Retrain a final model on the entire 2022 dataset for robust predictions
        print("Retraining final model on full 2022 data for submission...")
        final_model = lgb.LGBMRegressor(**lgb_params)
        # Train final model on transformed target using all data
        final_model.fit(
            X, np.log1p(y_original)
        )  # Train on all available 2022 data, transformed

        test_preds_transformed = final_model.predict(X_test)
        test_preds = np.expm1(test_preds_transformed)  # Inverse transform
        test_preds = np.maximum(0, test_preds)  # Clip predictions to non-negative

        # Create submission file
        submission_df = submission_df_original_keys
        submission_df["predicted_count"] = test_preds.round().astype(
            int
        )  # Round and convert to int for counts

        submission_df.to_csv(SUBMISSION_FILE, index=False)
        print(f"Submission file saved to {SUBMISSION_FILE}")

        # If test_df has 'violation_count', calculate and report RMSE on test data
        if (
            "violation_count" in test_df.columns
            and not test_df["violation_count"].isnull().all()
        ):
            test_ground_truth = test_df["violation_count"]
            test_rmse = np.sqrt(mean_squared_error(test_ground_truth, test_preds))
            print(f"RMSE on provided test/evaluation set: {test_rmse:.4f}")
        else:
            print(
                "Test file does not contain ground truth 'violation_count' for scoring."
            )

        # Report unseen key pairs
        # Re-load original train_df to get original string key pairs
        original_train_df = pd.read_csv(args.train_path)
        train_key_set = set(
            original_train_df.apply(
                lambda row: (row["Street Name"], row["Violation Description"]), axis=1
            )
        )

        test_key_set = set(
            submission_df_original_keys.apply(
                lambda row: (row["Street Name"], row["Violation Description"]), axis=1
            )
        )

        unseen_keys = test_key_set - train_key_set
        num_unseen_keys = len(unseen_keys)
        total_test_keys = len(test_key_set)

        print(
            f"Number of unique (street_name, violation_type) pairs in test/eval: {total_test_keys}"
        )
        print(
            f"Number of unseen (street_name, violation_type) pairs in test/eval (not in 2022 training): {num_unseen_keys}"
        )
        print(
            f"These unseen pairs were handled by OrdinalEncoder's `unknown_value` and the model's generalization capabilities."
        )

    print("\nSolution finished.")


if __name__ == "__main__":
    run_solution()
