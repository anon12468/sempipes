## Technical Report: NYC Parking Violation Prediction

### Introduction

This report details the methodology for predicting NYC parking violation counts per `(street_name, violation_type)` pair in 2023. The primary goal is to minimize Root Mean Squared Error (RMSE). The solution leverages 2022 violation data, augmented with external violation code information. The pipeline is designed to be configurable for post-hoc evaluation on unseen test data.

### Preprocessing

#### Data Loading and Augmentation

1.  **Core Data:** `violations_per_street_2022.csv` serves as the primary training dataset.
2.  **Augmentation Data:** `dof_parking_violation_codes.csv` is used to enrich the core data. It's merged with the training data on `Violation Description`.
3.  **New Features:** The augmentation introduces `Violation Category` and `Fine Amount`.
4.  **Missing Value Handling:**
    *   `Violation Category`: Missing values resulting from the merge are imputed with "UNKNOWN\_CATEGORY".
    *   `Fine Amount`: Missing values are filled with the median `Fine Amount` from the available training data. If all `Fine Amount` values are missing, they are filled with 0.

#### Feature Engineering

The following features are used for modeling: `Street Name`, `Violation Description`, `Violation Category`, and `Fine Amount`.

#### Categorical Encoding

Categorical features (`Street Name`, `Violation Description`, `Violation Category`) are transformed using `OrdinalEncoder`. This encoder is configured with `handle_unknown='use_encoded_value'` and `unknown_value=-1` to gracefully handle categories present in test data but not in training.

### Modeling Methods

#### Model Selection

A LightGBM Regressor is employed for its efficiency and strong performance on tabular data.

#### Target Transformation

To address the skewed nature of `violation_count` and optimize for RMSE, a `log1p` transformation is applied to the target variable (`violation_count`). Predictions are subsequently inverse-transformed using `np.expm1` to return to the original count scale. This transformation helps stabilize variance and improves model fit.

#### Model Objective and Parameters

*   **Objective:** The LightGBM `objective` is set to `regression` (L2 loss) to directly optimize for RMSE on the `log1p` transformed target.
*   **Hyperparameters:** Key parameters include `n_estimators=1000`, `learning_rate=0.05`, `feature_fraction=0.8`, `bagging_fraction=0.8`, `bagging_freq=1`, `lambda_l1=0.1`, `lambda_l2=0.1`, and `num_leaves=31`.
*   **Early Stopping:** Training incorporates early stopping with a patience of 100 rounds based on the RMSE on the validation set.

#### Cross-Validation

Model performance is rigorously assessed using 5-fold KFold cross-validation on the 2022 training data. The average RMSE across all folds is reported.

#### Prediction Clipping

All predictions are clipped to non-negative values using `np.maximum(0, predictions)` and then rounded to the nearest integer to ensure valid count outputs.

#### Final Model Training

If a test path is provided, a final LightGBM model is retrained on the entire 2022 dataset (with the `log1p` transformed target) to generate predictions for `submission.csv`.

### Results Discussion

The implemented pipeline achieved an average 5-fold cross-validation RMSE of **45.75**. This demonstrates a significant improvement over an initial attempt which used an `objective='regression_l1'` and no target transformation, yielding an RMSE of approximately 123.45. The `log1p` transformation effectively stabilized the target variable and allowed the model to optimize RMSE more directly.

The `OrdinalEncoder` successfully handled unseen `(street_name, violation_type)` pairs by assigning them a specific `unknown_value`. This ensures the model can generalize to new combinations not present in the 2022 training data, a critical requirement for predicting future violations. For example, if a test set were provided, the system would report the number of unique `(street_name, violation_type)` pairs present in the test set and how many of those were unseen in the 2022 training data.

Predictions for a given test file are saved to `submission.csv` with `predicted_count` rounded to integers.

### Future Work

1.  **Hyperparameter Tuning:** Conduct more extensive hyperparameter optimization for LightGBM using techniques like GridSearchCV or Bayesian optimization.
2.  **Feature Engineering:** Explore additional features, such as temporal features (e.g., day of week, month, holidays if data permits), or interaction terms between existing features.
3.  **Advanced Encoding:** Investigate more sophisticated categorical encoding techniques, such as target encoding or feature hashing, to potentially capture more nuanced relationships.
4.  **Alternative Models:** Evaluate other powerful tree-based models (e.g., XGBoost, CatBoost) or ensemble methods.
5.  **External Data:** Integrate other relevant external datasets, such as demographic information, weather data, or local event schedules, if available.