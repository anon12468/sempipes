## Technical Report: Parking Violation Prediction

### Introduction

This report details the development of a predictive model for NYC parking violations, focusing on predicting future counts for `(street_name, violation_type)` pairs. The primary objective is to minimize Root Mean Squared Error (RMSE) on unseen data, while adhering to strict data usage rules (no future target leakage, configurable paths, grouped holdout validation). The pipeline leverages 2022 violation data for training and augments it with external street tree census information. The development involved iterative refinement of validation strategies and feature engineering techniques.

### Preprocessing

#### Data Loading and Cleaning

Raw `Street Name` and `Violation Description` columns were standardized by converting to uppercase, stripping whitespace, and replacing multiple spaces with single spaces. This ensures consistent categorical representation and improves merge key matching.

#### Feature Augmentation

The `2005_street_tree_census__29bw-z7pj.parquet` dataset was incorporated. For each `street_name`, two features were derived: `total_trees_on_street` (count) and `avg_tree_dbh` (mean diameter at breast height). Missing values for `total_trees_on_street` were imputed with 0, assuming no trees if not in the census. Missing `avg_tree_dbh` values were imputed with the global mean calculated from the training data.

#### Target Transformation

The `violation_count` target variable exhibited skewness. To mitigate this and ensure non-negative predictions, a `np.log1p` transformation was applied. Predictions were subsequently inverse-transformed using `np.expm1`, clipped at 0, and rounded to the nearest integer.

#### Categorical Feature Handling

1.  **Initial Approach**: A custom `LabelEncoder` was implemented to map categorical features (`street_name`, `violation_type`) to integers. Unseen categories in the test set were explicitly mapped to -1, treating them as a distinct "out-of-vocabulary" class for the LightGBM model.
2.  **Revised Approach**: This shifted to using Pandas `Categorical` dtype. This allowed LightGBM to natively handle categorical features. For inference, test set categories were aligned with training set categories, causing any unseen categories to implicitly become NaN, which LightGBM can manage.

#### Target Aggregation

To capture target-related information without leakage, target-encoded features were created for `Street Name` and `Violation Description`. These features represented the mean of the `log1p`-transformed `violation_count` for each category. A 5-fold cross-validation strategy was employed during training to generate "out-of-fold" (OOF) aggregates, preventing direct target leakage. A critical fix addressed data leakage: the fallback mean for unseen categories within a validation fold was calculated solely from that fold's training data, not the entire training dataset. For the final model and test predictions, a global mean from the full training set was used as the fallback for unseen categories.

### Modeling Methods

#### Model Choice

LightGBM `LGBMRegressor` was selected for its efficiency and strong performance with tabular data and categorical features.

#### Validation Strategy

1.  **Initial Design**: `GroupKFold` cross-validation (5 folds) was used, grouping by `street_name`. This ensured that entire streets were either in the training or validation set, addressing the "grouped holdout" requirement and preventing data leakage across groups. The average RMSE across folds served as the development validation metric.
2.  **Revised Design**: While target encoding used internal `KFold` splits, the overall model validation in the second iteration also used a standard `KFold` (5 folds) for generating OOF predictions and evaluating development RMSE. The final model for prediction was an ensemble average of the models trained on each fold.

#### Hyperparameters

LightGBM hyperparameters were set to optimize for RMSE. Key parameters included:
*   `objective`: Initially `regression` (MSE), then changed to `regression_l1` (MAE) in the revised approach, while maintaining `rmse` as the evaluation metric.
*   `n_estimators`: 1000 to 1500.
*   `learning_rate`: 0.05 to 0.03.
*   Regularization: `feature_fraction`, `bagging_fraction`, `bagging_freq`, `lambda_l1`, `lambda_l2`.
*   `early_stopping_rounds`: 100 to 150, correctly passed to the `fit` method in