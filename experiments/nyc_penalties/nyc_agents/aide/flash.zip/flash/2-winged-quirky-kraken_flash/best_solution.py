import pandas as pd
import numpy as np
import argparse
import os
from sklearn.model_selection import GroupKFold
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import mean_squared_error
import lightgbm as lgb
import logging

# Set up logging for better visibility during execution
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)


class CustomLabelEncoder:
    """
    A LabelEncoder wrapper that handles unseen labels by mapping them to -1.
    This ensures that categories not present during training are treated as a distinct,
    out-of-vocabulary category by models like LightGBM.
    """

    def __init__(self):
        self.le = LabelEncoder()
        self.classes_ = None

    def fit(self, y):
        # Filter out NaN values before fitting, LabelEncoder can't handle them
        self.le.fit([x for x in y if pd.notna(x)])
        self.classes_ = self.le.classes_
        return self

    def transform(self, y):
        # Create a dictionary for quick lookup of existing classes
        class_mapping = {
            label: encoded_value
            for label, encoded_value in zip(
                self.le.classes_, self.le.transform(self.le.classes_)
            )
        }

        # Map values; if not in class_mapping or NaN, assign -1
        transformed_data = [class_mapping.get(x, -1) if pd.notna(x) else -1 for x in y]
        return np.array(transformed_data).astype(int)

    def fit_transform(self, y):
        return self.fit(y).transform(y)


def clean_and_standardize_text_column(df, column_name):
    """Standardizes text columns for consistent matching and feature creation."""
    return df[column_name].astype(str).str.upper().str.strip()


def run_prediction_pipeline(train_path, test_path=None):
    """
    Main function to run the prediction pipeline.

    Args:
        train_path (str): Path to the 2022 training data (violations_per_street_2022.csv).
        test_path (str, optional): Path to the 2023 test/evaluation data. Defaults to None.
    """

    # --- Configuration ---
    WORKING_DIR = "./working"
    INPUT_DIR = "./input"
    CORPUS_DIR = os.path.join(INPUT_DIR, "corpus")
    N_FOLDS = 5  # For GroupKFold cross-validation

    os.makedirs(WORKING_DIR, exist_ok=True)
    logging.info(f"Working directory created: {WORKING_DIR}")

    # --- Load Training Data ---
    logging.info(f"Loading training data from: {train_path}")
    df_train_raw = pd.read_csv(train_path)

    # Rename original columns to prevent confusion during processing
    df_train_raw.columns = [
        "original_street_name",
        "original_violation_type",
        "violation_count",
    ]
    df_train_processed = df_train_raw.copy()

    # Create cleaned versions of street_name and violation_type for consistent feature engineering
    df_train_processed["street_name"] = clean_and_standardize_text_column(
        df_train_raw, "original_street_name"
    )
    df_train_processed["violation_type"] = clean_and_standardize_text_column(
        df_train_raw, "original_violation_type"
    )
    logging.info(f"Training data loaded with {len(df_train_processed)} records.")

    # --- Augmentation: Load and process street tree census data ---
    tree_features = pd.DataFrame(
        columns=["street_name", "total_trees_on_street", "avg_tree_dbh"]
    )
    try:
        tree_census_file = os.path.join(
            CORPUS_DIR, "2005_street_tree_census__29bw-z7pj.parquet"
        )
        logging.info(f"Attempting to load augmentation data from: {tree_census_file}")

        df_trees = pd.read_parquet(
            tree_census_file, columns=["street_name", "tree_dbh"]
        )

        # Clean street_name in tree data for consistent merging
        df_trees["street_name"] = clean_and_standardize_text_column(
            df_trees, "street_name"
        )

        # Aggregate features from tree data
        tree_features = (
            df_trees.groupby("street_name")
            .agg(
                total_trees_on_street=("tree_dbh", "count"),
                avg_tree_dbh=("tree_dbh", "mean"),
            )
            .reset_index()
        )
        logging.info(
            f"Loaded and aggregated tree data for {len(tree_features)} unique streets from {tree_census_file}."
        )

    except FileNotFoundError:
        logging.warning(
            f"Tree census file not found at {tree_census_file}. Skipping tree-based augmentation."
        )
    except Exception as e:
        logging.error(
            f"Error loading or processing tree census data: {e}. Skipping augmentation."
        )

    # Merge with augmented features
    df_train_processed = df_train_processed.merge(
        tree_features, on="street_name", how="left"
    )

    # Handle NaNs from merge (streets not in tree census)
    df_train_processed["total_trees_on_street"] = df_train_processed[
        "total_trees_on_street"
    ].fillna(
        0
    )  # Assume 0 trees if not found

    mean_avg_tree_dbh_global = df_train_processed[
        "avg_tree_dbh"
    ].mean()  # Calculate global mean for filling NaNs
    df_train_processed["avg_tree_dbh"] = df_train_processed["avg_tree_dbh"].fillna(
        mean_avg_tree_dbh_global if pd.notna(mean_avg_tree_dbh_global) else 0
    )
    logging.info("Augmentation and NaN handling completed for training data.")

    # --- Feature Engineering & Encoding ---
    le_street = CustomLabelEncoder()
    df_train_processed["street_name_encoded"] = le_street.fit_transform(
        df_train_processed["street_name"]
    )

    le_violation = CustomLabelEncoder()
    df_train_processed["violation_type_encoded"] = le_violation.fit_transform(
        df_train_processed["violation_type"]
    )

    logging.info("Categorical features encoded for training data.")

    # Define features and target
    features = [
        "street_name_encoded",
        "violation_type_encoded",
        "total_trees_on_street",
        "avg_tree_dbh",
    ]
    target = "violation_count"

    X = df_train_processed[features]
    y = df_train_processed[target]

    # Groups for GroupKFold validation (using cleaned street names to ensure full streets are in train or val)
    # This addresses the "grouped holdout" requirement for validation.
    groups = df_train_processed["street_name"]

    # --- Model Training (LightGBM) with GroupKFold Validation ---
    lgb_params = {
        "objective": "regression",  # Changed to 'regression' to optimize for RMSE
        "metric": "rmse",
        "n_estimators": 1000,
        "learning_rate": 0.05,
        "feature_fraction": 0.8,
        "bagging_fraction": 0.8,
        "bagging_freq": 1,
        "verbose": -1,  # Suppress verbose output during training
        "n_jobs": -1,  # Use all available cores
        "seed": 42,
        "boosting_type": "gbdt",
        "max_depth": 10,
    }

    categorical_features_lgbm = [
        f
        for f in [
            "street_name_encoded",
            "violation_type_encoded",
        ]
        if f in X.columns
    ]

    kf = GroupKFold(n_splits=N_FOLDS)
    rmse_scores = []

    logging.info(f"Starting {N_FOLDS}-fold GroupKFold cross-validation on 2022 data...")
    for fold, (train_index, val_index) in enumerate(kf.split(X, y, groups)):
        X_train, X_val = X.iloc[train_index], X.iloc[val_index]
        y_train, y_val = y.iloc[train_index], y.iloc[val_index]

        model = lgb.LGBMRegressor(**lgb_params)
        model.fit(
            X_train,
            y_train,
            eval_set=[(X_val, y_val)],
            eval_metric="rmse",
            callbacks=[lgb.early_stopping(100, verbose=False)],
            categorical_feature=categorical_features_lgbm,
        )

        val_predictions = model.predict(X_val)
        val_predictions[val_predictions < 0] = 0  # Clip negative predictions to 0
        fold_rmse = np.sqrt(mean_squared_error(y_val, val_predictions))
        rmse_scores.append(fold_rmse)
        logging.info(f"Fold {fold+1} Development Validation RMSE: {fold_rmse:.4f}")

    avg_rmse = np.mean(rmse_scores)
    print(
        f"Average Development Validation RMSE (across {N_FOLDS} folds): {avg_rmse:.4f}"
    )
    logging.info(f"Cross-validation complete. Average RMSE: {avg_rmse:.4f}")

    # --- Final Model Training on ALL 2022 Data ---
    logging.info(
        "Training final LightGBM model on all 2022 training data for prediction."
    )
    final_model = lgb.LGBMRegressor(**lgb_params)
    final_model.fit(
        X,
        y,
        categorical_feature=categorical_features_lgbm,
    )
    logging.info("Final LightGBM model training complete.")

    # --- Test Prediction (if test_path is provided) ---
    if test_path:
        logging.info(f"\nProcessing test file for prediction: {test_path}")
        df_test_raw = pd.read_csv(test_path)
        original_test_columns = df_test_raw.columns.tolist()

        # Determine if test file includes ground truth
        has_true_target = False
        if len(original_test_columns) == 3:
            # Check if one of the columns (case-insensitive) is 'violation_count'
            lower_columns = [col.lower() for col in original_test_columns]
            if "violation_count" in lower_columns:
                target_col_idx = lower_columns.index("violation_count")
                # Rename the columns consistently for internal processing
                df_test_raw.columns = [
                    "original_street_name",
                    "original_violation_type",
                    "violation_count_true",
                ]
                # Adjust column order to move true_violation_count to the end for consistent feature extraction
                col_order = [0, 1]
                if target_col_idx == 0:  # If target was first
                    col_order = [1, 2]
                elif target_col_idx == 1:  # If target was second
                    col_order = [0, 2]
                # Reassign based on logical order if "Street Name", "Violation Description" are fixed keys
                df_test_raw.columns = [
                    "original_street_name",
                    "original_violation_type",
                    "violation_count_true",
                ]
                # df_test_raw = df_test_raw[[original_test_columns[col_order[0]], original_test_columns[col_order[1]], "violation_count_true"]]
                has_true_target = True
            else:  # If 3 columns but none is 'violation_count', treat it as keys only.
                df_test_raw.columns = [
                    "original_street_name",
                    "original_violation_type",
                    "extra_column",
                ]  # dummy name
        elif len(original_test_columns) == 2:
            df_test_raw.columns = ["original_street_name", "original_violation_type"]

        df_test_processed = df_test_raw.copy()
        df_test_processed["street_name"] = clean_and_standardize_text_column(
            df_test_raw, "original_street_name"
        )
        df_test_processed["violation_type"] = clean_and_standardize_text_column(
            df_test_raw, "original_violation_type"
        )

        # Augment test data with tree features (using global mean_avg_tree_dbh from training)
        df_test_processed = df_test_processed.merge(
            tree_features, on="street_name", how="left"
        )

        df_test_processed["total_trees_on_street"] = df_test_processed[
            "total_trees_on_street"
        ].fillna(0)
        df_test_processed["avg_tree_dbh"] = df_test_processed["avg_tree_dbh"].fillna(
            mean_avg_tree_dbh_global
        )
        logging.info("Augmentation and NaN handling completed for test data.")

        # Identify unseen key pairs (original_street_name, original_violation_type)
        test_street_violations_raw = set(
            zip(
                df_test_raw["original_street_name"],
                df_test_raw["original_violation_type"],
            )
        )
        train_street_violations_raw = set(
            zip(
                df_train_raw["original_street_name"],
                df_train_raw["original_violation_type"],
            )
        )
        unseen_pairs = test_street_violations_raw - train_street_violations_raw
        unseen_pairs_count = len(unseen_pairs)
        print(
            f"Number of (street_name, violation_type) pairs unseen in training data: {unseen_pairs_count}"
        )

        # Encode test features using mappings from training data
        df_test_processed["street_name_encoded"] = le_street.transform(
            df_test_processed["street_name"]
        )

        df_test_processed["violation_type_encoded"] = le_violation.transform(
            df_test_processed["violation_type"]
        )
        logging.info(
            "Categorical features encoded for test data, handling unseen labels."
        )

        # Ensure test data has the exact same feature columns as training data
        X_test = df_test_processed[features]

        # Predict on test data using the final model
        test_predictions = final_model.predict(X_test)
        test_predictions[test_predictions < 0] = 0  # Clip negative predictions

        # Create submission file with specified column names (lowercase street_name, violation_type)
        submission_df = df_test_raw[
            ["original_street_name", "original_violation_type"]
        ].copy()
        submission_df.columns = [
            "street_name",
            "violation_type",
        ]  # Renaming to lowercase for submission requirement
        submission_df["predicted_count"] = test_predictions.round().astype(int)

        submission_file_path = os.path.join(WORKING_DIR, "submission.csv")
        submission_df.to_csv(submission_file_path, index=False)
        logging.info(f"Submission file generated: {submission_file_path}")

        # If test_path has actual violation_count, calculate and report test RMSE
        if has_true_target:
            test_true_counts = df_test_processed["violation_count_true"]
            test_rmse = np.sqrt(mean_squared_error(test_true_counts, test_predictions))
            print(f"Test Set RMSE (ground truth available): {test_rmse:.4f}")

    logging.info("Prediction pipeline finished.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument(
        "--train-path",
        type=str,
        default="/Users/USER/Documents/UNI/SS26/nyc_open_data/train/all_data/violations_per_street_2022.csv",
        help="Path to the 2022 training data (violations_per_street_2022.csv).",
    )
    parser.add_argument(
        "--test-path",
        type=str,
        default="/Users/USER/Documents/UNI/SS26/nyc_open_data/violations_per_street_2023.csv",
        help="Path to the 2023 test/evaluation data (e.g., test.csv) (optional).",
    )

    args = parser.parse_args()

    run_prediction_pipeline(args.train_path, args.test_path)
