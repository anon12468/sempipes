import argparse
import pandas as pd
import numpy as np
import lightgbm as lgb
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error
import os


# --- 1. Argument Parsing ---
def parse_args():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument(
        "--train-path",
        type=str,
        default="/Users/USER/Documents/UNI/SS26/nyc_open_data/train/all_data/violations_per_street_2022.csv",
        help="Path to the 2022 training data CSV.",
    )
    parser.add_argument(
        "--test-path",
        type=str,
        default="/Users/USER/Documents/UNI/SS26/nyc_open_data/violations_per_street_2023.csv",
        help="Path to the 2023 test/evaluation data CSV (optional).",
    )
    return parser.parse_args()


def calculate_rmse(y_true, y_pred):
    """Calculates the Root Mean Squared Error."""
    return np.sqrt(mean_squared_error(y_true, y_pred))


def load_data(file_path):
    """Loads data from a CSV file."""
    try:
        if file_path.endswith(".csv"):
            return pd.read_csv(file_path)
        elif file_path.endswith(".parquet"):
            return pd.read_parquet(file_path)
        else:
            raise ValueError(f"Unsupported file format for {file_path}")
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return None


def clean_street_name(df, column_name="Street Name"):
    """Standardize street name column for merging and feature engineering."""
    # Convert to string and handle potential NaNs from non-string types gracefully
    # Ensure all strings are handled; fillna with empty string then convert to uppercase and strip

    # Check if the column actually exists before attempting to process it.
    # If not, return df as is; downstream fillna will handle the missing feature.
    if column_name not in df.columns:
        print(
            f"Warning: Column '{column_name}' not found in DataFrame for cleaning. This feature might be impacted."
        )
        # If the column doesn't exist, attempting to assign back to it would create a new column of NaNs.
        # This is typically undesired if 'clean_street_name' is used for aggregation keys.
        # However, the previous faulty logic did precisely this (creating 'on_street' as all NaNs),
        # so for consistency with bug fix intent, let's just make sure existing one is properly handled
        # and not introduce too much branching logic that might differ from problem.
        # The key is to fix the *name* so it exists. If it legitimately doesn't exist for some data source,
        # further parts of pipeline should default (e.g., fill with 0/mean)
        return df

    df[column_name] = df[column_name].fillna("").astype(str).str.upper().str.strip()
    return df


def process_features(df, encoding_maps, default_fill_value):
    """
    Applies feature engineering to the dataframe.
    This version expects the target to be 'violation_count' directly,
    as Poisson objective handles the internal transformation.
    """
    df_processed = df.copy()

    # Basic length features
    df_processed["street_name_len"] = df_processed["Street Name"].apply(len)
    df_processed["violation_desc_len"] = df_processed["Violation Description"].apply(
        len
    )

    # Target Encoding for 'Street Name' and 'Violation Description'
    df_processed["street_name_encoded"] = df_processed["Street Name"].map(
        encoding_maps.get("street_name_map", {})
    )
    df_processed["street_name_encoded"].fillna(default_fill_value, inplace=True)

    df_processed["violation_desc_encoded"] = df_processed["Violation Description"].map(
        encoding_maps.get("violation_desc_map", {})
    )
    df_processed["violation_desc_encoded"].fillna(default_fill_value, inplace=True)

    # Frequency features
    df_processed["street_name_freq"] = (
        df_processed["Street Name"]
        .map(encoding_maps.get("street_name_freq_map", {}))
        .fillna(0)
    )
    df_processed["violation_desc_freq"] = (
        df_processed["Violation Description"]
        .map(encoding_maps.get("violation_desc_freq_map", {}))
        .fillna(0)
    )

    # New feature from corpus: 'tree_count_per_street' and 'meter_count_per_street'
    # are already merged into df, no additional processing needed here if merges and fills
    # are done globally outside this function.

    return df_processed


if __name__ == "__main__":
    args = parse_args()
    OUTPUT_DIR = "working"
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    print("--- Loading training data ---")
    train_df_raw = load_data(args.train_path)
    if train_df_raw is None:
        exit("Failed to load training data. Exiting.")

    # Drop any rows with NaN in critical columns before feature engineering
    train_df_raw.dropna(
        subset=["Street Name", "Violation Description", "violation_count"], inplace=True
    )
    if train_df_raw.empty:
        exit("Training data is empty after dropping NaNs. Exiting.")

    # Clean street names for consistent merging and feature engineering
    train_df_raw = clean_street_name(train_df_raw, "Street Name")

    TARGET_COL = "violation_count"
    FEATURE_COLS = [
        "street_name_len",
        "violation_desc_len",
        "street_name_encoded",
        "violation_desc_encoded",
        "street_name_freq",
        "violation_desc_freq",
        "tree_count_per_street",
        # Added new feature: meter_count_per_street
        "meter_count_per_street",
    ]

    # --- Load and preprocess corpus data for feature augmentation (Tree Census) ---
    print("--- Loading and augmenting with corpus data (2005 Street Tree Census) ---")
    tree_census_path = "input/corpus/2005_street_tree_census__29bw-z7pj.parquet"
    tree_df = load_data(tree_census_path)

    tree_counts_per_street = pd.DataFrame(
        columns=["Street Name", "tree_count_per_street"]
    )
    global_mean_tree_count = 0.0

    if tree_df is None:
        print(
            f"Warning: Could not load tree census data from {tree_census_path}. Setting 'tree_count_per_street' to 0."
        )
        train_df_raw["tree_count_per_street"] = 0
    else:
        tree_df = clean_street_name(tree_df, "street")
        # Aggregate tree count per street
        tree_counts_per_street = (
            tree_df.groupby("street")["tree_id"].count().reset_index()
        )
        tree_counts_per_street.rename(
            columns={"street": "Street Name", "tree_id": "tree_count_per_street"},
            inplace=True,
        )

        if not tree_counts_per_street.empty:
            global_mean_tree_count = tree_counts_per_street[
                "tree_count_per_street"
            ].mean()

        # Merge tree count feature into training data
        train_df_raw = pd.merge(
            train_df_raw, tree_counts_per_street, on="Street Name", how="left"
        )
        # Impute missing tree counts (streets in violations data not in tree census)
        train_df_raw["tree_count_per_street"].fillna(
            global_mean_tree_count, inplace=True
        )

    # --- Load and preprocess corpus data for feature augmentation (Metered Parking) ---
    print("--- Loading and augmenting with corpus data (Metered Parking) ---")
    metered_parking_path = "input/corpus/metered_parking_kwhj-hsdg.parquet"
    meter_df = load_data(metered_parking_path)

    meter_counts_per_street = pd.DataFrame(
        columns=["Street Name", "meter_count_per_street"]
    )

    if meter_df is None:
        print(
            f"Warning: Could not load metered parking data from {metered_parking_path}. Setting 'meter_count_per_street' to 0."
        )
        train_df_raw["meter_count_per_street"] = 0
    else:
        # BUGFIX: Changed 'on_street' to 'On-Street' to correctly reference the column name
        meter_df = clean_street_name(meter_df, "On-Street")
        # Aggregate meter count per street
        meter_counts_per_street = (
            meter_df.groupby("On-Street")  # BUGFIX: Changed 'on_street' to 'On-Street'
            .size()
            .reset_index(name="meter_count_per_street")
        )
        meter_counts_per_street.rename(
            columns={
                "On-Street": "Street Name"
            },  # BUGFIX: Changed 'on_street' to 'On-Street'
            inplace=True,
        )

        # Merge meter count feature into training data
        train_df_raw = pd.merge(
            train_df_raw, meter_counts_per_street, on="Street Name", how="left"
        )
        # Impute missing meter counts (streets in violations data not in meter data)
        # Fill with 0 for streets not found, assuming they have no metered parking
        train_df_raw["meter_count_per_street"].fillna(0, inplace=True)

    # Store global target_encoding_maps and global_mean_target for final model training and test prediction
    global_encoding_maps = {}

    # Calculate global mean of the target from the entire training set for unseen category fallback
    global_mean_target_val = train_df_raw[TARGET_COL].mean()

    # Pre-calculate global target encodings (mean and frequency) on the full training data
    global_encoding_maps["street_name_map"] = (
        train_df_raw.groupby("Street Name")[TARGET_COL].mean().to_dict()
    )
    global_encoding_maps["violation_desc_map"] = (
        train_df_raw.groupby("Violation Description")[TARGET_COL].mean().to_dict()
    )
    global_encoding_maps["street_name_freq_map"] = (
        train_df_raw["Street Name"].value_counts().to_dict()
    )
    global_encoding_maps["violation_desc_freq_map"] = (
        train_df_raw["Violation Description"].value_counts().to_dict()
    )

    print("--- Starting 5-Fold Cross-Validation for Development RMSE ---")
    kf = KFold(n_splits=5, shuffle=True, random_state=42)
    oof_preds = np.zeros(train_df_raw.shape[0])  # Out-of-fold predictions

    fold_rmses = []

    lgb_params = {
        "objective": "poisson",  # Bugfix: Changed objective to Poisson for count data
        "metric": "rmse",  # LightGBM computes RMSE on original scale for poisson objective
        "n_estimators": 500,
        "learning_rate": 0.05,
        "feature_fraction": 0.8,
        "bagging_fraction": 0.8,
        "bagging_freq": 1,
        "verbose": -1,  # Suppress verbose output
        "n_jobs": -1,
        "seed": 42,
        "boosting_type": "gbdt",
    }

    for fold, (train_idx, val_idx) in enumerate(kf.split(train_df_raw)):
        print(f"--- Fold {fold+1}/5 ---")
        train_fold_df = train_df_raw.iloc[train_idx].copy()
        val_fold_df = train_df_raw.iloc[val_idx].copy()

        # Compute target encodings *only on the current training fold*
        fold_local_encoding_maps = {}
        fold_local_encoding_maps["street_name_map"] = (
            train_fold_df.groupby("Street Name")[TARGET_COL].mean().to_dict()
        )
        fold_local_encoding_maps["violation_desc_map"] = (
            train_fold_df.groupby("Violation Description")[TARGET_COL].mean().to_dict()
        )
        fold_local_encoding_maps["street_name_freq_map"] = (
            train_fold_df["Street Name"].value_counts().to_dict()
        )
        fold_local_encoding_maps["violation_desc_freq_map"] = (
            train_fold_df["Violation Description"].value_counts().to_dict()
        )

        # Get the mean target for this fold's training set as fallback for encodings
        fold_mean_target_val = train_fold_df[TARGET_COL].mean()

        # Process features for this fold's training and validation sets
        # 'tree_count_per_street' and 'meter_count_per_street' are already present due to global merge performed earlier
        X_train_processed = process_features(
            train_fold_df,
            fold_local_encoding_maps,
            fold_mean_target_val,
        )
        X_val_processed = process_features(
            val_fold_df,
            fold_local_encoding_maps,
            fold_mean_target_val,
        )

        # Bugfix: The target 'y' is directly 'violation_count' for Poisson objective
        X_train, y_train = (
            X_train_processed[FEATURE_COLS],
            X_train_processed[TARGET_COL],
        )
        X_val, y_val = (
            X_val_processed[FEATURE_COLS],
            X_val_processed[TARGET_COL],
        )

        model = lgb.LGBMRegressor(**lgb_params)
        model.fit(
            X_train,
            y_train,
            eval_set=[(X_val, y_val)],
            eval_metric="rmse",  # Metric still RMSE
            callbacks=[lgb.early_stopping(100, verbose=False)],
            # seed=42 + fold,
        )

        val_preds = model.predict(X_val)
        # Bugfix: Removed np.expm1, as Poisson objective predicts on original count scale
        val_preds = np.maximum(0, val_preds)  # Ensure non-negative predictions

        oof_preds[val_idx] = val_preds

        fold_rmse = calculate_rmse(val_fold_df[TARGET_COL], val_preds)
        fold_rmses.append(fold_rmse)
        print(f"Fold {fold+1} RMSE: {fold_rmse:.4f}")

    avg_rmse = np.mean(fold_rmses)
    print(f"\nAverage Cross-Validation RMSE (Development Metric): {avg_rmse:.4f}")

    # --- Training final model on the full 2022 dataset ---
    print("\n--- Training final model on full 2022 data ---")
    final_train_processed_df = process_features(
        train_df_raw, global_encoding_maps, global_mean_target_val
    )
    # Bugfix: Target is raw 'violation_count' for final model training as well
    X_final_train, y_final_train = (
        final_train_processed_df[FEATURE_COLS],
        final_train_processed_df[TARGET_COL],
    )

    final_model = lgb.LGBMRegressor(**lgb_params)
    final_model.fit(X_final_train, y_final_train)

    # --- Test Prediction if --test-path is provided ---
    if args.test_path:
        print(f"\n--- Generating predictions for test file: {args.test_path} ---")
        test_df_raw = load_data(args.test_path)
        if test_df_raw is None:
            print("Failed to load test data. Skipping submission file generation.")
        else:
            test_df_for_prediction = test_df_raw.copy()

            # Clean street names in test data for merging and feature engineering
            test_df_for_prediction = clean_street_name(
                test_df_for_prediction, "Street Name"
            )

            # Drop rows with NaN in key columns required for features;
            # this aligns with what happened in training
            initial_test_rows = test_df_for_prediction.shape[0]
            test_df_for_prediction.dropna(
                subset=["Street Name", "Violation Description"], inplace=True
            )
            if test_df_for_prediction.shape[0] != initial_test_rows:
                print(
                    f"Warning: Dropped {initial_test_rows - test_df_for_prediction.shape[0]} rows from test set due to missing 'Street Name' or 'Violation Description'."
                )

            # Merge tree count feature into test data using the globally computed map
            if tree_df is not None:
                test_df_for_prediction = pd.merge(
                    test_df_for_prediction,
                    tree_counts_per_street,
                    on="Street Name",
                    how="left",
                )
                test_df_for_prediction["tree_count_per_street"].fillna(
                    global_mean_tree_count, inplace=True
                )
            else:
                test_df_for_prediction["tree_count_per_street"] = (
                    0  # If corpus was never loaded
                )

            # Merge meter count feature into test data using the globally computed map
            if meter_df is not None:
                test_df_for_prediction = pd.merge(
                    test_df_for_prediction,
                    meter_counts_per_street,
                    on="Street Name",
                    how="left",
                )
                test_df_for_prediction["meter_count_per_street"].fillna(
                    0,
                    inplace=True,  # Fill with 0 for streets not found, matching training
                )
            else:
                test_df_for_prediction["meter_count_per_street"] = (
                    0  # If corpus was never loaded
                )

            submission_key_cols = ["Street Name", "Violation Description"]

            # Identify unseen key pairs for reporting
            train_key_pairs = set(
                train_df_raw.apply(
                    lambda row: (row["Street Name"], row["Violation Description"]),
                    axis=1,
                )
            )

            test_df_for_prediction["key_pair"] = test_df_for_prediction.apply(
                lambda row: (row["Street Name"], row["Violation Description"]), axis=1
            )
            test_unseen_count = 0
            for key_pair in test_df_for_prediction["key_pair"].unique():
                if key_pair not in train_key_pairs:
                    test_unseen_count += 1

            print(
                f"Number of (street_name, violation_type) pairs in test/eval unseen in training: {test_unseen_count}. These are handled by using global average counts for their categorical features as fallback."
            )

            # Process test features using globally trained encoders
            test_processed_df = process_features(
                test_df_for_prediction,
                global_encoding_maps,
                global_mean_target_val,
            )

            # Predict using the final trained model
            X_test = test_processed_df[FEATURE_COLS]
            test_preds = final_model.predict(X_test)
            # Bugfix: Removed np.expm1, as Poisson objective predicts on original count scale
            test_preds = np.maximum(0, test_preds)  # Ensure non-negative

            test_processed_df["predicted_count"] = test_preds

            # Prepare submission file
            # Note: The 'Street Name' and 'Violation Description' in submission_df will be cleaned (uppercase, stripped).
            submission_df = test_processed_df[submission_key_cols + ["predicted_count"]]
            submission_path = os.path.join(OUTPUT_DIR, "submission.csv")
            submission_df.to_csv(submission_path, index=False)
            print(f"Submission file saved to {submission_path}")

            # If 'violation_count' is present in test data and not all NaNs, report RMSE
            if (
                TARGET_COL in test_df_raw.columns
                and not test_df_raw[TARGET_COL].isnull().all()
            ):
                # Clean keys in test_df_raw as well for consistent merging and evaluation
                eval_test_df_raw = clean_street_name(test_df_raw.copy(), "Street Name")
                # Drop rows from raw data for evaluation if target itself is NaN
                eval_test_df_raw.dropna(
                    subset=submission_key_cols + [TARGET_COL], inplace=True
                )

                # Merge original ground truth with predictions to ensure alignment and use only valid ground truths
                eval_merged_df = pd.merge(
                    eval_test_df_raw[submission_key_cols + [TARGET_COL]],
                    submission_df,
                    on=submission_key_cols,
                    how="inner",  # Only evaluate where we have both keys and valid ground truth
                )

                if not eval_merged_df.empty:
                    eval_rmse = calculate_rmse(
                        eval_merged_df[TARGET_COL], eval_merged_df["predicted_count"]
                    )
                    print(f"RMSE on provided test/evaluation set: {eval_rmse:.4f}")
                else:
                    print(
                        "Could not compute RMSE on test/evaluation set as no valid ground truth rows remained after filtering."
                    )
            else:
                print(
                    "No 'violation_count' column found or all values are NaN in test file. Skipping RMSE calculation for test/eval."
                )
