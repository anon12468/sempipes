# Technical Report: NYC Parking Violations Prediction

## Introduction

This report details the development of a predictive model for NYC parking violation counts per `(Street Name, Violation Description)` pair. The primary objective is to minimize Root Mean Squared Error (RMSE) on future violation counts. The solution leverages 2022 violation data for training and incorporates external corpus datasets for feature augmentation. The pipeline is designed to accept configurable file paths for training and optional post-hoc testing, reporting RMSE on both development and test sets.

## Preprocessing

### Data Loading and Cleaning

Raw data, including `violations_per_street_2022.csv` and corpus files, are loaded using pandas. Critical rows with missing `Street Name`, `Violation Description`, or `violation_count` are dropped. Street names are standardized by converting to uppercase and stripping whitespace to ensure consistent merging and feature engineering.

### Feature Engineering

*   **Length Features**: `street_name_len` and `violation_desc_len` are created from string lengths.
*   **Frequency Features**: `street_name_freq` and `violation_desc_freq` capture the occurrence frequency of each category.
*   **Corpus Augmentation**:
    *   **Tree Census Data**: `tree_count_per_street` is derived from `2005_street_tree_census__29bw-z7pj.parquet`. Missing tree counts for streets not present in the census are imputed with the global mean tree count.
    *   **Metered Parking Data**: `meter_count_per_street` is extracted from `metered_parking_kwhj-hsdg.parquet`. A crucial bug fix corrected the column name from "on_street" to "On-Street" to ensure accurate data extraction. Missing meter counts are imputed with 0, assuming no metered parking.
*   **Regularized Target Encoding**: For `Street Name` and `Violation Description`, Bayesian regularized target encoding is applied. This method smooths category-specific target means towards the global target mean, weighted by category count and a smoothing factor (set to 50). This reduces overfitting to noisy means from low-frequency categories and improves generalization, particularly for unseen or rare pairs.

## Modeling Methods

### Model Architecture

A LightGBM Regressor is used due to its efficiency and strong performance on tabular data.

### Objective Function

A key technical decision was to employ the `poisson` objective function in LightGBM. This directly optimizes for count data, eliminating the need for `log1p` transformation of the target variable and subsequent `expm1` inverse transformation of predictions. This ensures direct RMSE optimization on the original count scale and yields non-negative predictions naturally.

### Hyperparameters

LightGBM parameters include:
*   `objective`: `poisson`
*   `metric`: `rmse`
*   `n_estimators`: 500
*   `learning_rate`: 0.05
*   `feature_fraction`: 0.8
*   `bagging_fraction`: 0.8
*   `bagging_freq`: 1
*   `n_jobs`: -1
*   `seed`: 42 (with fold-specific seeds for CV)
*   `boosting_type`: `gbdt`
Early stopping with a patience of 100 rounds is used during cross-validation.

### Cross-Validation

A 5-fold shuffled KFold cross-validation strategy (`random_state=42`) is implemented for robust development validation. Target encodings for each fold are computed *only* on the respective training data to prevent target leakage. Predictions are clipped at zero to maintain count integrity.

### Final Model Training and Prediction

A final model is trained on the entire 2022 dataset using global regularized target encodings. For test set predictions, the same preprocessing steps and global encodings are applied. Predictions are ensured to be non-negative. The system handles `(Street Name, Violation Description)` pairs in the test set not present in the training data by using the global mean as a fallback for their encoded features.

## Results Discussion

The model achieved an average 5-fold cross-validation RMSE of **69.3082** on the development set. When evaluated on the provided 2023 test/evaluation subset, the RMSE was **247.7850**.

Key decisions significantly impacted performance:
*   **Poisson Objective**: Directly modeling counts improved the handling of the target distribution and facilitated RMSE optimization on the original scale.
*   **External Features**: The integration of `tree_count_per_street` and `meter_count_per_street` provided valuable geographical and contextual information. The correction of the "On-Street" column name for metered parking data was critical to enabling this feature.
*   **Regularized Target Encoding**: This technique reduced overfitting on sparse categories, contributing to more robust feature representations and better generalization.
*   **Unseen Key Pairs**: 3749 `(street_name, violation_type)` pairs in the test set were not present in the training data. These were effectively handled by using global average target counts as a fallback for their categorical feature encodings.

## Future Work

*   **Hyperparameter Tuning**: Optimize the `smoothing_factor` for regularized target encoding and LightGBM hyperparameters further (e.g., using grid search or Bayesian optimization).
*   **Advanced Categorical Encodings**: Explore other sophisticated encoding schemes such as Leave-One-Out encoding or CatBoostEncoder.
*   **Temporal Features**: Investigate adding time-based features (e.g., month, day of week, holidays) if detailed date information becomes available, to capture seasonality or trends.
*   **Error Analysis**: Conduct a deeper analysis of predictions with high errors to identify specific patterns or data subsets where the model underperforms.