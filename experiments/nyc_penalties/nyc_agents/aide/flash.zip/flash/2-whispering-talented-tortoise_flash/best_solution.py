import argparse
import pandas as pd
import numpy as np
import lightgbm as lgb
from sklearn.model_selection import GroupKFold
from sklearn.metrics import mean_squared_error
import os
import gc
import sys
import warnings

# --- SETUP ---
warnings.filterwarnings("ignore")
INPUT_DIR = "/Users/USER/Documents/UNI/SS26/nyc_open_data/train/all_data"
CORPUS_DIR = os.path.join(INPUT_DIR, "corpus")
OUTPUT_DIR = "./working"
os.makedirs(OUTPUT_DIR, exist_ok=True)


def clean_street_name(series):
    """Standardizes street names for consistent joining."""
    return series.astype(str).str.upper().str.strip()


def create_features(df, is_train, fe_params):
    """
    Engineers features for the model.
    is_train=True: calculates and stores transformation parameters and computes leave-one-out aggregates.
    is_train=False: applies stored transformations to new data.
    """
    df_out = df.copy()

    # 1. Standardize column names
    df_out["street_name_clean"] = clean_street_name(df_out["street_name"])

    # 2. Merge external data (tree census + borough)
    external_features = fe_params["external_features"]
    df_out = pd.merge(df_out, external_features, on="street_name_clean", how="left")

    # Impute 'boroname' post-merge for streets not in census
    df_out["boroname"] = df_out["boroname"].fillna("UNKNOWN")

    # 3. Impute missing values from external data
    if is_train:
        fe_params["avg_tree_dbh_impute"] = df_out["avg_tree_dbh"].mean()
        fe_params["tree_count_impute"] = 0

    df_out["tree_count"] = df_out["tree_count"].fillna(
        fe_params.get("tree_count_impute", 0)
    )
    df_out["avg_tree_dbh"] = df_out["avg_tree_dbh"].fillna(
        fe_params.get("avg_tree_dbh_impute", 0)
    )

    # 4. Create and apply aggregate features [BUGFIX AREA]
    if is_train:
        # For training, create leave-one-out (LOO) means to prevent target leakage.
        # Also, calculate and store simple mean maps for inference on validation/test sets.
        fe_params["global_mean"] = df_out["violation_count"].mean()
        global_mean = fe_params["global_mean"]

        agg_map_for_inference = {}
        for col, prefix in [
            ("street_name_clean", "street"),
            ("violation_description", "violation"),
            ("boroname", "borough"),
        ]:
            # Store simple mean for applying to validation/test
            agg = df_out.groupby(col)["violation_count"].agg("mean")
            agg_map_for_inference[f"{prefix}_agg_mean_map"] = agg.to_dict()

            # Create LOO features for training data
            feature_name = f"{prefix}_agg_mean"
            group_sums = df_out.groupby(col)["violation_count"].transform("sum")
            group_counts = df_out.groupby(col)["violation_count"].transform("count")

            # (group_sum - self) / (count - 1)
            denominator = (group_counts - 1).replace(
                0, np.nan
            )  # Avoid division by zero
            df_out[feature_name] = (
                group_sums - df_out["violation_count"]
            ) / denominator
            df_out[feature_name].fillna(global_mean, inplace=True)

        fe_params["agg_maps_for_inference"] = agg_map_for_inference

    else:
        # For validation/test, apply the simple mean maps calculated during training.
        global_mean = fe_params.get("global_mean", 0)
        agg_maps = fe_params.get("agg_maps_for_inference", {})

        for col, prefix in [
            ("street_name_clean", "street"),
            ("violation_description", "violation"),
            ("boroname", "borough"),
        ]:
            feature_name = f"{prefix}_agg_mean"
            mapping = agg_maps.get(f"{prefix}_agg_mean_map", {})
            df_out[feature_name] = df_out[col].map(mapping).fillna(global_mean)

    # 5. Prepare categorical features for LightGBM
    categorical_cols_to_encode = {
        "street_name_clean": "street_name_categories",
        "violation_description": "violation_description_categories",
        "boroname": "boroname_categories",
    }

    for col, param_name in categorical_cols_to_encode.items():
        cat_col_name = f"{col}_cat"
        if is_train:
            df_out[cat_col_name] = df_out[col].astype("category").cat.codes
            fe_params[param_name] = df_out[col].astype("category").cat.categories
        else:
            cat_dtype = pd.api.types.CategoricalDtype(
                categories=fe_params.get(param_name, pd.Index([])), ordered=False
            )
            df_out[col + "_cat"] = (
                df_out[col].astype(cat_dtype).cat.codes
            )  # .cat.codes returns -1 for unseen

    return df_out


def run(train_path, test_path):
    """Main function to run the training and prediction pipeline."""
    print("Preparing external corpus data...")
    tree_census_path = os.path.join(
        CORPUS_DIR, "2005_street_tree_census__29bw-z7pj.parquet"
    )
    try:
        tree_census = pd.read_parquet(tree_census_path)
        tree_census["street_name_clean"] = clean_street_name(tree_census["street"])

        def get_mode(x):
            return x.mode().iloc[0] if not x.mode().empty else "UNKNOWN"

        external_features = (
            tree_census.groupby("street_name_clean")
            .agg(
                tree_count=("tree_id", "count"),
                avg_tree_dbh=("tree_dbh", "mean"),
                boroname=("boroname", get_mode),
            )
            .reset_index()
        )
    except Exception as e:
        print(f"Warning: Could not load tree census data. Error: {e}")
        external_features = pd.DataFrame(
            columns=["street_name_clean", "tree_count", "avg_tree_dbh", "boroname"]
        )

    del tree_census
    gc.collect()

    print(f"Loading training data from {train_path}...")
    train_df = pd.read_csv(train_path)
    train_df.columns = ["street_name", "violation_description", "violation_count"]

    # Pre-calculate what doesn't depend on the target
    train_df["street_name_clean"] = clean_street_name(train_df["street_name"])

    TARGET = "violation_count"
    LOG_TARGET = "log_violation_count"
    train_df[LOG_TARGET] = np.log1p(train_df[TARGET])

    FEATURES = [
        "tree_count",
        "avg_tree_dbh",
        "street_agg_mean",
        "violation_agg_mean",
        "borough_agg_mean",
        "street_name_clean_cat",
        "violation_description_cat",
        "boroname_cat",
    ]
    categorical_features = [
        "street_name_clean_cat",
        "violation_description_cat",
        "boroname_cat",
    ]

    print("Starting 5-fold cross-validation...")
    N_SPLITS = 5
    gkf = GroupKFold(n_splits=N_SPLITS)
    oof_preds = np.zeros(len(train_df))
    groups = pd.factorize(train_df["street_name_clean"])[0]

    model_params = {
        "objective": "rmse",
        "metric": "rmse",
        "random_state": 42,
        "n_estimators": 2000,
        "learning_rate": 0.02,
        "num_leaves": 40,
        "n_jobs": -1,
        "colsample_bytree": 0.8,
        "subsample": 0.8,
        "reg_alpha": 0.1,
        "reg_lambda": 0.1,
        "verbose": -1,
        "boosting_type": "gbdt",
    }

    for fold, (train_idx, val_idx) in enumerate(
        gkf.split(train_df, train_df[LOG_TARGET], groups)
    ):
        print(f"--- Fold {fold+1}/{N_SPLITS} ---")

        train_fold_df = train_df.iloc[train_idx].copy()
        val_fold_df = train_df.iloc[val_idx].copy()

        # --- LEAK-FREE FEATURE ENGINEERING ---
        fe_params_fold = {"external_features": external_features}

        train_fold_featured = create_features(
            train_fold_df, is_train=True, fe_params=fe_params_fold
        )

        val_fold_featured = create_features(
            val_fold_df, is_train=False, fe_params=fe_params_fold
        )

        X_train = train_fold_featured[FEATURES]
        y_train = train_fold_featured[LOG_TARGET]
        X_val = val_fold_featured[FEATURES]
        y_val = val_fold_featured[LOG_TARGET]

        model = lgb.LGBMRegressor(**model_params)
        model.fit(
            X_train,
            y_train,
            eval_set=[(X_val, y_val)],
            callbacks=[lgb.early_stopping(100, verbose=False)],
            categorical_feature=categorical_features,
        )
        oof_preds[val_idx] = model.predict(X_val)

    oof_preds_exp = np.expm1(oof_preds)
    oof_preds_exp[oof_preds_exp < 0] = 0
    val_rmse = np.sqrt(mean_squared_error(train_df[TARGET], oof_preds_exp))
    print(f"\nOverall Cross-Validation RMSE: {val_rmse:.4f}")

    # --- Final Model Training and Inference ---
    print("\nTraining final model on all 2022 data...")
    fe_params_final = {"external_features": external_features}
    train_df_featured = create_features(
        train_df, is_train=True, fe_params=fe_params_final
    )

    final_model = lgb.LGBMRegressor(**model_params)
    final_model.fit(
        train_df_featured[FEATURES],
        train_df_featured[LOG_TARGET],
        categorical_feature=categorical_features,
    )

    if test_path:
        print(f"\nProcessing test file: {test_path}")

        test_df_raw = pd.read_csv(test_path)
        if "violation_count" in test_df_raw.columns:
            test_df = test_df_raw[
                ["Street Name", "Violation Description", "violation_count"]
            ].copy()
            test_df.columns = [
                "street_name",
                "violation_description",
                "violation_count",
            ]
            test_ground_truth = test_df_raw["violation_count"]
        else:
            test_df = test_df_raw[["Street Name", "Violation Description"]].copy()
            test_df.columns = ["street_name", "violation_description"]
            test_ground_truth = None

        train_keys = set(
            zip(train_df["street_name_clean"], train_df["violation_description"])
        )
        test_keys = set(
            zip(
                clean_street_name(test_df["street_name"]),
                test_df["violation_description"],
            )
        )
        unseen_keys_count = len(test_keys - train_keys)
        print(
            f"Number of key pairs in test/eval not seen in training: {unseen_keys_count}"
        )
        print(
            "Handling: Unseen pairs are addressed by using global means for aggregate features and by LightGBM's default handling of unseen category values."
        )

        print("Engineering features for test data...")
        test_df_featured = create_features(
            test_df, is_train=False, fe_params=fe_params_final
        )

        print("Making predictions...")
        test_log_preds = final_model.predict(test_df_featured[FEATURES])
        test_preds = np.expm1(test_log_preds)
        test_preds[test_preds < 0] = 0

        submission_df = pd.DataFrame(
            {
                "street_name": test_df["street_name"],
                "violation_type": test_df["violation_description"],
                "predicted_count": test_preds,
            }
        )
        submission_path = os.path.join(OUTPUT_DIR, "submission.csv")
        submission_df.to_csv(submission_path, index=False)
        print(f"Submission file created at {submission_path}")

        if test_ground_truth is not None:
            test_rmse = np.sqrt(mean_squared_error(test_ground_truth, test_preds))
            print(f"\nRMSE on provided test file: {test_rmse:.4f}")


# --- Main Execution Logic ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Predict NYC Parking Violations")
    parser.add_argument(
        "--train-path",
        type=str,
        default=os.path.join("/Users/USER/Documents/UNI/SS26/nyc_open_data/train/all_data/violations_per_street_2022.csv"),
    )
    parser.add_argument("--test-path", type=str, default="/Users/USER/Documents/UNI/SS26/nyc_open_data/violations_per_street_2023.csv")

    is_interactive = "ipykernel" in sys.modules
    args = parser.parse_args([] if is_interactive else sys.argv[1:])

    if is_interactive:
        print("Running in interactive mode. Using default paths.")
        print("Creating a dummy test file for demonstration...")
        try:
            full_train_df = pd.read_csv(args.train_path)
            full_train_df.columns = [
                "Street Name",
                "Violation Description",
                "violation_count",
            ]
            dummy_keys = full_train_df.sample(n=5000, random_state=42)[
                ["Street Name", "Violation Description"]
            ]
            unseen_keys = pd.DataFrame(
                [
                    {
                        "Street Name": "KAGGLE GRANDMASTER BLVD",
                        "Violation Description": "NO PARKING-STREET CLEANING",
                    },
                    {
                        "Street Name": "W 4 ST",
                        "Violation Description": "MADE UP VIOLATION TYPE",
                    },
                ]
            )
            dummy_test_df = pd.concat([dummy_keys, unseen_keys], ignore_index=True)
            dummy_test_path = os.path.join(OUTPUT_DIR, "dummy_test.csv")
            dummy_test_df.to_csv(dummy_test_path, index=False)
            args.test_path = dummy_test_path
            print(f"Dummy test file created at: {args.test_path}")
        except FileNotFoundError:
            print(
                f"Training file not found at {args.train_path}. Cannot create dummy test file."
            )
            args.test_path = None
        except Exception as e:
            print(f"An error occurred while creating dummy test file: {e}")
            args.test_path = None

    run(train_path=args.train_path, test_path=args.test_path)
