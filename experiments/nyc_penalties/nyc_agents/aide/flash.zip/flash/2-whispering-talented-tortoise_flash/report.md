# Technical Report: NYC Parking Violation Prediction

## Introduction

This report summarizes the methods and findings for predicting NYC parking violation counts. The objective was to build a model that predicts the number of violations for a given `(street_name, violation_type)` pair using 2022 data, while allowing for post-hoc evaluation on new data. The primary challenges included handling a skewed target variable, engineering features without target leakage, and managing unseen data combinations during inference. The final solution is a LightGBM model that achieves a cross-validation Root Mean Squared Error (RMSE) of 30.45.

## Preprocessing

### Identifier Standardization
Street names and violation types serve as primary keys. To ensure consistent grouping and joins, street names were standardized by converting them to uppercase and removing leading/trailing whitespace. This was a critical step; initial inconsistencies between raw and cleaned identifiers for feature generation led to a high RMSE (115.43), which was reduced to 78.43 after correction.

### External Data Augmentation
The model was enriched with data from the 2005 NYC Street Tree Census. This external dataset provided two key features for each street:
1.  **Street-level attributes:** `tree_count` and the average tree diameter (`avg_tree_dbh`).
2.  **Geographical context:** The NYC `borough` associated with the street.

### Target Transformation
The target variable, `violation_count`, exhibited a highly skewed distribution common in count data. A logarithmic transformation (`log1p`) was applied to the target before training to stabilize variance and create a more normally distributed target for the model. Predictions were transformed back to the original scale using `expm1`.

## Modelling Methods

### Model Selection
A LightGBM regressor was selected as the final model. Early experiments confirmed that this gradient boosting framework significantly outperformed a simpler Ridge linear model (RMSE ~78 vs. 88), effectively capturing the complex, non-linear relationships in the data.

### Feature Engineering
The core of the model's predictive power comes from engineered aggregate features.

#### Target Leakage Mitigation
Preventing target leakage from these features was the central challenge. The methodology evolved through several stages:
1.  **Initial Leakage:** A naive approach of calculating aggregate statistics (e.g., mean violations per street) on the entire training set before cross-validation produced an overly optimistic and unreliable RMSE of ~35-43.
2.  **In-Fold Aggregation:** The leakage was first corrected by calculating aggregates *inside* each cross-validation fold, using only the fold's training data. This established a more realistic baseline RMSE of ~78.
3.  **Leave-One-Out (LOO) Encoding:** The final and most effective approach utilized leave-one-out target encoding. For each training sample, the mean violation count for its group (e.g., its street) was calculated using all *other* samples in that group. This provided a strong, leak-free signal and was the key driver in reducing the RMSE to 30.45. Standard deviation aggregates were removed as they were found to be less robust.

#### Feature Set
The final feature set included:
-   **External Features:** `tree_count`, `avg_tree_dbh`.
-   **Categorical Features:** Integer-encoded `street_name`, `violation_description`, and `boroname`.
-   **LOO-Encoded Features:** Leave-one-out mean of `violation_count` grouped by `street_name`, `violation_description`, and `boroname`.

### Validation Strategy
A 5-fold `GroupKFold` cross-validation, grouped by street name, was employed. This strategy ensures that the model is always validated on streets that were not seen during that fold's training, providing a robust estimate of its ability to generalize to new data.

## Results Discussion

The final model achieved a cross-validation RMSE of **30.45**.

The iterative process revealed several key insights:
-   **Leakage Prevention is Paramount:** The most significant improvements were directly tied to implementing a robust, leak-free feature engineering process. The final LOO encoding strategy proved superior to the in-fold aggregation method.
-   **Data Cleaning Impacts Performance:** Standardizing identifiers was a critical step, demonstrating that data consistency is fundamental to model performance.
-   **Geographical Features Add Value:** Incorporating borough-level information provided a consistent performance lift by capturing regional patterns in parking enforcement and density.
-   **Simple Interactions Are Sufficient:** An experiment to add explicit interaction features (e.g., `borough` + `violation_type`) did not improve upon the base model, suggesting the model could already capture these effects from the individual LOO-encoded features.

## Future Work

-   **Temporal Features:** If more granular timestamp data were available, features based on seasonality, month, or day of the week could capture temporal violation patterns.
-   **Geospatial Analysis:** Using street coordinates, we could engineer features based on proximity to points of interest (e.g., transit hubs, commercial zones) that influence parking behavior.
-   **Hyperparameter Optimization:** A structured hyperparameter tuning process, such as Bayesian optimization, could be applied to the LightGBM model to potentially yield further performance gains.