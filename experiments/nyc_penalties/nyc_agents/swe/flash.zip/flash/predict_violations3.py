import pandas as pd
import numpy as np
import argparse
import os
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
import joblib # To save/load encoders

# Define a constant for the corpus path
CORPUS_PATH = os.path.join(os.path.dirname(__file__), 'corpus')

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame."""
    try:
        df = pd.read_csv(file_path)
        # Standardize column names for easier access
        df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_')
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return None

def load_parquet_data(file_path):
    """Loads a parquet file into a pandas DataFrame."""
    try:
        df = pd.read_parquet(file_path, engine='pyarrow')
        # Standardize column names
        df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_')
        return df
    except FileNotFoundError:
        print(f"Error: Parquet file not found at {file_path}")
        return None
    except Exception as e:
        print(f"Error loading parquet file {file_path}: {e}")
        return None

def preprocess_data(df):
    """Basic preprocessing for parking violation data."""
    if df is None:
        return None
    # Ensure 'street_name' and 'violation_description' are strings and handle NaNs
    df['street_name'] = df['street_name'].astype(str).fillna('UNKNOWN_STREET')
    df['violation_description'] = df['violation_description'].astype(str).fillna('UNKNOWN_VIOLATION')
    return df

class FeatureEngineer:
    def __init__(self):
        self.street_to_mean = None
        self.violation_to_mean = None
        self.global_street_mean = 0
        self.global_violation_mean = 0
        self.street_pavement_ratings = None
        self.mean_pavement_rating = 0

    def fit(self, df):
        """Fits encoders and collects augmentation data for later transformation."""
        # Fit target encoders
        self.street_to_mean = df.groupby('street_name')['violation_count'].mean().to_dict()
        self.violation_to_mean = df.groupby('violation_description')['violation_count'].mean().to_dict()
        self.global_street_mean = df['violation_count'].mean() # Overall mean as fallback
        self.global_violation_mean = df['violation_count'].mean() # Overall mean as fallback
        
        # Load and process augmentation data
        pavement_path = os.path.join(CORPUS_PATH, 'street_pavement_ratings__6yyb-pb25.parquet')
        pavement_df = load_parquet_data(pavement_path)
        
        if pavement_df is not None:
            # Aggregate pavement ratings by street name
            # Take mean rating for each street
            pavement_df = pavement_df.rename(columns={'onstreetname': 'street_name'})
            self.street_pavement_ratings = pavement_df.groupby('street_name')['systemrating'].mean().to_dict()
            self.mean_pavement_rating = pavement_df['systemrating'].mean()
        else:
            print("Warning: Could not load street pavement ratings augmentation data.")

    def transform(self, df):
        """Applies feature engineering using fitted encoders and augmentation data."""
        if df is None:
            return None
        
        df_transformed = df.copy()

        # Apply target encoding, using global mean for unseen categories
        df_transformed['street_name_encoded'] = df_transformed['street_name'].map(self.street_to_mean).fillna(self.global_street_mean)
        df_transformed['violation_description_encoded'] = df_transformed['violation_description'].map(self.violation_to_mean).fillna(self.global_violation_mean)

        # Apply augmentation features
        if self.street_pavement_ratings is not None:
            df_transformed['pavement_rating'] = df_transformed['street_name'].map(self.street_pavement_ratings).fillna(self.mean_pavement_rating)
        else:
            df_transformed['pavement_rating'] = self.mean_pavement_rating # Fallback if augmentation data wasn't loaded

        return df_transformed
    
    def get_unseen_keys(self, df):
        """Identifies unseen street names and violation descriptions."""
        unseen_streets = df[~df['street_name'].isin(self.street_to_mean.keys())]['street_name'].nunique()
        unseen_violations = df[~df['violation_description'].isin(self.violation_to_mean.keys())]['vi_description'].nunique() # Check column name `vi_description` again
        return unseen_streets, unseen_violations


def train_model(train_df_fe, features_to_use):
    """Trains a RandomForestRegressor model."""
    if train_df_fe is None:
        return None
    
    target = 'violation_count'

    X = train_df_fe[features_to_use]
    y = train_df_fe[target]

    # Simple train-validation split for development
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
    model.fit(X_train, y_train)

    # Evaluate on validation set
    val_predictions = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_predictions))
    print(f"Development Validation RMSE: {val_rmse:.2f}")

    return model

def predict_violations(model, df_fe, features_to_use):
    """Generates predictions using the trained model."""
    if model is None or df_fe is None:
        return None
    
    # Ensure all required features are present
    # The transform method should handle missing features by filling with fallbacks.
    # Just need to make sure the DataFrame passed to predict contains these columns.
    
    original_street_names = df_fe['street_name']
    original_violation_descriptions = df_fe['violation_description']
    
    X_pred = df_fe[features_to_use]
    
    predictions = model.predict(X_pred)
    predictions[predictions < 0] = 0 # Clip negative predictions

    result_df = pd.DataFrame({
        'street_name': original_street_names,
        'violation_type': original_violation_descriptions,
        'predicted_count': predictions.round().astype(int)
    })
    return result_df

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument('--train-path', type=str, default='/Users/USER/Documents/UNI/SS26/nyc_open_data/train/all_data/violations_per_street_2022.csv',
                        help='Path to the 2022 training data CSV.')
    parser.add_argument('--test-path', type=str, default='/Users/USER/Documents/UNI/SS26/nyc_open_data/violations_per_street_2023.csv',
                        help='Optional: Path to the 2023 test/evaluation data CSV.')
    
    args = parser.parse_args()

    print(f"Loading training data from: {args.train_path}")
    train_df = load_data(args.train_path)
    train_df = preprocess_data(train_df)

    if train_df is None:
        print("Failed to load or preprocess training data. Exiting.")
        return

    # Initialize and fit the feature engineer
    feature_engineer_obj = FeatureEngineer()
    feature_engineer_obj.fit(train_df.copy()) # Pass a copy to avoid modifying original

    # Transform training data
    train_df_fe = feature_engineer_obj.transform(train_df)

    # Define features to use in the model (including new augmentation features)
    features_to_use = ['street_name_encoded', 'violation_description_encoded', 'pavement_rating']

    model = train_model(train_df_fe, features_to_use)

    if args.test_path:
        print(f"\nLoading test data from: {args.test_path}")
        test_df = load_data(args.test_path)
        test_df = preprocess_data(test_df)

        if test_df is None:
            print("Failed to load or preprocess test data. Exiting.")
            return

        # Transform test data using the fitted feature engineer
        # If 'violation_count' is not in test_df, the target encoding might try to use it.
        # However, the FeatureEngineer.transform only uses pre-fitted mappings.
        # So, the presence of 'violation_count' in test_df (for scoring) won't impact feature creation.
        
        test_df_fe = feature_engineer_obj.transform(test_df.copy())

        # Identify unseen keys in test data
        unseen_streets = test_df_fe[~test_df_fe['street_name'].isin(feature_engineer_obj.street_to_mean.keys())]['street_name'].nunique()
        unseen_violations = test_df_fe[~test_df_fe['violation_description'].isin(feature_engineer_obj.violation_to_mean.keys())]['violation_description'].nunique()

        print(f"Number of unseen streets in test data: {unseen_streets}")
        print(f"Number of unseen violation types in test data: {unseen_violations}")


        predictions_df = predict_violations(model, test_df_fe, features_to_use)
        
        output_filename = 'submission.csv'
        predictions_df.to_csv(output_filename, index=False)
        print(f"Predictions saved to {output_filename}")

        # If 'violation_count' is in the test_df, calculate RMSE
        if 'violation_count' in test_df.columns:
            true_counts = test_df['violation_count']
            pred_counts = predictions_df['predicted_count']
            test_rmse = np.sqrt(mean_squared_error(true_counts, pred_counts))
            print(f"Test RMSE: {test_rmse:.2f}")

    else:
        print("\nNo test-path provided. Skipping test prediction.")

if __name__ == "__main__":
    main()
