import argparse
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.ensemble import RandomForestRegressor
from lightgbm import LGBMRegressor
import numpy as np
import logging
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler # For scaling numerical features, good practice

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def load_and_preprocess_pavement_ratings(file_path):
    logging.info(f"Loading pavement ratings from: {file_path}")
    try:
        df = pd.read_parquet(file_path)
        df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_')
        
        # Aggregate ratings by street name, taking the mean
        df['onstreetname'] = df['onstreetname'].fillna('UNKNOWN_STREET_PAVEMENT').astype(str)
        
        pavement_ratings_agg = df.groupby('onstreetname')['systemrating'].mean().reset_index()
        pavement_ratings_agg.rename(columns={'onstreetname': 'street_name', 'systemrating': 'avg_pavement_rating'}, inplace=True)
        
        logging.info(f"Loaded and aggregated {len(pavement_ratings_agg)} unique street pavement ratings.")
        return pavement_ratings_agg
    except FileNotFoundError:
        logging.error(f"Pavement ratings file not found: {file_path}")
        return None
    except Exception as e:
        logging.error(f"Error loading or processing pavement ratings from {file_path}: {e}")
        return None

def load_and_preprocess_traffic_data(file_path, target_year=2022):
    logging.info(f"Loading traffic data from: {file_path} for target year {target_year}")
    try:
        df = pd.read_parquet(file_path)
        df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_')

        # Convert 'date' column
        df['date'] = pd.to_datetime(df['date'])
        
        # Filter for the target year
        df_year = df[df['date'].dt.year == target_year].copy()
        
        if df_year.empty:
            logging.warning(f"No traffic data found for year {target_year}.")
            return None

        # Identify non-numeric columns and columns to exclude from hourly sum
        exclude_cols = ['segmentid', 'roadway_name', 'from', 'to', 'direction', 'date', 'veh_class_type']
        
        # Select all columns that are not in exclude_cols and are numeric
        hourly_cols = [col for col in df_year.columns if col not in exclude_cols and pd.api.types.is_numeric_dtype(df_year[col])]
        
        # Ensure selected hourly columns are numeric
        df_year[hourly_cols] = df_year[hourly_cols].apply(pd.to_numeric, errors='coerce')
        logging.info(f"Dtypes of hourly columns after to_numeric: {df_year[hourly_cols].dtypes}")

        # Sum hourly counts to get total daily traffic, handling NaN values
        logging.info(f"Shape of hourly columns before sum: {df_year[hourly_cols].shape}")
        df_year['total_daily_traffic'] = df_year[hourly_cols].sum(axis=1, skipna=True)

        # Aggregate average daily traffic per roadway name
        df_year['roadway_name'] = df_year['roadway_name'].astype(str).fillna('UNKNOWN_ROADWAY')
        traffic_agg = df_year.groupby('roadway_name')['total_daily_traffic'].mean().reset_index()
        traffic_agg.rename(columns={'roadway_name': 'street_name', 'total_daily_traffic': 'avg_daily_traffic_2022'}, inplace=True)

        logging.info(f"Loaded and aggregated {len(traffic_agg)} unique street traffic records for {target_year}.")
        return traffic_agg
    except FileNotFoundError:
        logging.error(f"Traffic data file not found: {file_path}")
        return None
    except Exception as e:
        logging.error(f"Error loading or processing traffic data from {file_path}: {e}")
        return None

def add_external_features(df, pavement_ratings_df, traffic_data_df):
    """Adds external features to the main DataFrame."""
    logging.info("Adding external features...")
    
    if pavement_ratings_df is not None:
        df = df.merge(pavement_ratings_df, on='street_name', how='left')
        df['avg_pavement_rating'] = df['avg_pavement_rating'].fillna(df['avg_pavement_rating'].mean() if not df['avg_pavement_rating'].empty else 0)
        logging.info("Merged pavement ratings and imputed missing values.")
    else:
        logging.warning("Pavement ratings DataFrame not provided, skipping merge.")
        df['avg_pavement_rating'] = 0 # Default if no external data
        
    if traffic_data_df is not None:
        df = df.merge(traffic_data_df, on='street_name', how='left')
        df['avg_daily_traffic_2022'] = df['avg_daily_traffic_2022'].fillna(df['avg_daily_traffic_2022'].mean() if not df['avg_daily_traffic_2022'].empty else 0)
        logging.info("Merged traffic data and imputed missing values.")
    else:
        logging.warning("Traffic data DataFrame not provided, skipping merge.")
        df['avg_daily_traffic_2022'] = 0 # Default if no external data
        
    return df

def load_data(file_path):
    """Loads a CSV file into a pandas DataFrame."""
    logging.info(f"Loading data from: {file_path}")
    try:
        df = pd.read_csv(file_path)
        # Standardize column names
        df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_')
        logging.info(f"Successfully loaded {len(df)} rows.")
        return df
    except FileNotFoundError:
        logging.error(f"File not found: {file_path}")
        return None
    except Exception as e:
        logging.error(f"Error loading data from {file_path}: {e}")
        return None

def preprocess_data(df, is_train=True, label_encoder=None, feature_scaler=None, pavement_ratings_df=None, traffic_data_df=None):
    """
    Preprocesses the raw data and adds features.
    If is_train=False, uses provided label_encoder and feature_scaler.
    """
    logging.info("Preprocessing data...")
    if 'street_name' not in df.columns or 'violation_description' not in df.columns:
        logging.error("Missing 'street_name' or 'violation_description' in DataFrame.")
        return None, None, None # Return df, encoder, scaler

    # Combine street name and violation description into a single key
    df['key'] = df['street_name'].fillna('UNKNOWN_STREET').astype(str) + "_" + df['violation_description'].fillna('UNKNOWN_VIOLATION').astype(str)
    logging.info("Created 'key' column for (street_name, violation_description) pairs.")

    # Create frequency features (calculated only on the current dataframe)
    df["street_name_freq"] = df.groupby("street_name")["key"].transform("count")
    df["violation_description_freq"] = df.groupby("violation_description")["key"].transform("count")
    
    # Create length features
    df["street_name_len"] = df["street_name"].fillna("").astype(str).apply(len)
    df["violation_description_len"] = df["violation_description"].fillna("").astype(str).apply(len)

    # Add external features
    df = add_external_features(df, pavement_ratings_df, traffic_data_df)

    # Features to be used by the model
    numerical_features = ["street_name_freq", "violation_description_freq", "street_name_len", "violation_description_len", "avg_pavement_rating", "avg_daily_traffic_2022"]
    
    # Handle Label Encoding for 'key' and scaling of numerical features
    if is_train:
        label_encoder = LabelEncoder()
        label_encoder.fit(df['key'])
        # Also fit the scaler on training data
        feature_scaler = StandardScaler()
        df[numerical_features] = feature_scaler.fit_transform(df[numerical_features])
    else:
        # For validation/test, use the fitted label_encoder and feature_scaler
        # Ensure numerical features are present and handle potential NaNs before scaling
        for col in numerical_features:
            if col not in df.columns:
                df[col] = 0 # Or some other default if feature is missing in test
            df[col] = df[col].fillna(df[col].mean() if not df[col].empty else 0) # Fill NaNs for safety
        
        if feature_scaler is not None:
            df[numerical_features] = feature_scaler.transform(df[numerical_features])
        else:
            logging.warning("Feature scaler not provided for non-training data. Features not scaled.")

    return df, label_encoder, feature_scaler

def train_model(X_train_processed, y_train):
    """Trains a RandomForestRegressor model."""
    logging.info("Training model...")
    
    model = LGBMRegressor(n_estimators=200, random_state=42, n_jobs=-1)
    model.fit(X_train_processed, y_train)
    logging.info("Model training complete.")
    return model

def predict(model, label_encoder, feature_scaler, X_data_to_predict_preprocessed, X_original_for_output, known_train_keys_set, global_avg_prediction):
    """Generates predictions for the given data."""
    logging.info("Generating predictions...")
    
    predictions_df = X_original_for_output[['street_name', 'violation_description']].copy()
    predictions_df.rename(columns={'violation_description': 'violation_type'}, inplace=True)
    
    # Store predictions temporarily to align them correctly with original order
    temp_predictions = np.zeros(len(X_data_to_predict_preprocessed))
    
    numerical_features = ["street_name_freq", "violation_description_freq", "street_name_len", "violation_description_len", "avg_pavement_rating", "avg_daily_traffic_2022"]

    seen_indices = []
    seen_feature_matrix = []
    unseen_indices = []

    for i, row in X_data_to_predict_preprocessed.iterrows():
        key = X_original_for_output.loc[i, 'key'] # Get original key
        
        if key in known_train_keys_set:
            try:
                encoded_key = label_encoder.transform([key])[0]
                # Ensure all features are available for the model
                current_features = [encoded_key] + row[numerical_features].tolist()
                seen_feature_matrix.append(current_features)
                seen_indices.append(i)
            except ValueError:
                logging.warning(f"Key '{key}' in known_train_keys_set but not transformable by LabelEncoder. Using global average for index {i}.")
                temp_predictions[X_data_to_predict_preprocessed.index.get_loc(i)] = global_avg_prediction
                unseen_indices.append(i) # Treat as unseen
        else:
            temp_predictions[X_data_to_predict_preprocessed.index.get_loc(i)] = global_avg_prediction
            unseen_indices.append(i)
    
    # Predict for seen keys
    if seen_feature_matrix:
        seen_predictions = model.predict(np.array(seen_feature_matrix))
        for j, original_idx in enumerate(seen_indices):
            temp_predictions[X_data_to_predict_preprocessed.index.get_loc(original_idx)] = seen_predictions[j]
    
    predictions_df['predicted_count'] = np.maximum(0, temp_predictions).round(0)
    
    unseen_keys_count = len(unseen_indices) # This is approximate, depends on how many were truly unseen vs encoder error
    logging.info("Predictions generated.")
    return predictions_df, unseen_keys_count

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument("--train-path", default="/Users/USER/Documents/UNI/SS26/nyc_open_data/train/all_data/violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--test-path", default="/Users/USER/Documents/UNI/SS26/nyc_open_data/violations_per_street_2023.csv",
                        help="Optional path to the 2023 test/evaluation data CSV.")
    
    args = parser.parse_args()

    # Load external augmentation data
    pavement_ratings_df = load_and_preprocess_pavement_ratings("corpus/street_pavement_ratings__6yyb-pb25.parquet")
    if pavement_ratings_df is None:
        logging.warning("Could not load pavement ratings. Proceeding without this augmentation.")
    
    traffic_data_df = load_and_preprocess_traffic_data("corpus/vehicle_classification_counts_2011_2025__96ay-ea4r.parquet", target_year=2022)
    if traffic_data_df is None:
        logging.warning("Could not load traffic data. Proceeding without this augmentation.")

    # Load training data
    train_df = load_data(args.train_path)
    if train_df is None:
        return

    # Preprocess training data and fit encoders/scalers
    # This `preprocess_data` on the full train_df fits the global_label_encoder and global_feature_scaler
    train_df, global_label_encoder, global_feature_scaler = preprocess_data(train_df, is_train=True, pavement_ratings_df=pavement_ratings_df, traffic_data_df=traffic_data_df)
    if train_df is None:
        return

    # Store unique keys from the *entire* 2022 dataset for test set comparison
    all_train_keys_set = set(train_df['key'].unique())
    all_train_y_mean = train_df['violation_count'].mean()

    # Features used for the model
    numerical_features = ["street_name_freq", "violation_description_freq", "street_name_len", "violation_description_len", "avg_pavement_rating", "avg_daily_traffic_2022"]
    
    # X now includes 'key' and numerical features (scaled if `is_train=True`)
    X_full_df_for_split = train_df[['street_name', 'violation_description', 'key'] + numerical_features]
    y_full_df_for_split = train_df['violation_count']

    # Split training data for development validation
    X_train_raw, X_val_raw, y_train, y_val = train_test_split(X_full_df_for_split, y_full_df_for_split, test_size=0.2, random_state=42)

    # --- Validation Split Specific Processing ---
    # Create a *new* LabelEncoder and StandardScaler for the training split only (to prevent data leakage)
    le_train_split = LabelEncoder()
    le_train_split.fit(X_train_raw['key'])
    
    scaler_train_split = StandardScaler()
    X_train_processed_for_model = X_train_raw.copy()
    X_train_processed_for_model[numerical_features] = scaler_train_split.fit_transform(X_train_processed_for_model[numerical_features])

    # Add encoded_key to X_train_processed_for_model
    X_train_processed_for_model['encoded_key'] = le_train_split.transform(X_train_raw['key'])
    X_train_final_features = X_train_processed_for_model[['encoded_key'] + numerical_features]


    # Train model on the X_train split
    model_val = train_model(X_train_final_features, y_train)

    # Preprocess X_val using the scaler fitted on X_train
    X_val_processed_for_model = X_val_raw.copy()
    X_val_processed_for_model[numerical_features] = scaler_train_split.transform(X_val_processed_for_model[numerical_features])
    
    # Add a placeholder 'encoded_key' column to X_val_processed_for_model.
    # The actual encoding (or not) will happen inside the predict function for each key based on seen_train_keys_set.
    X_val_processed_for_model['encoded_key'] = -1 # Placeholder

    # Define known keys for the `model_val` (i.e., keys the model was trained on)
    known_keys_for_val_model_set = set(X_train_raw['key'].unique())
    y_train_split_mean = y_train.mean() # Mean for unseen keys during validation

    logging.info("Performing development validation...")
    val_predictions_df, unseen_keys_val_count = predict(
        model_val, # Model trained on X_train split
        le_train_split, # Label encoder fitted on X_train split
        scaler_train_split, # Scaler fitted on X_train split (not directly used by predict now, but kept for signature)
        X_val_processed_for_model[['encoded_key'] + numerical_features], # Preprocessed validation features
        X_val_raw[['street_name', 'violation_description', 'key']], # Original X_val for output
        known_keys_for_val_model_set, # Keys seen during the X_train split
        y_train_split_mean # Mean of y_train split
    )
    
    val_predictions_aligned = val_predictions_df['predicted_count'].values
    val_rmse = np.sqrt(mean_squared_error(y_val, val_predictions_aligned))
    logging.info(f"Development Validation RMSE: {val_rmse:.4f}")
    logging.info(f"Unseen key pairs in validation (relative to train split): {unseen_keys_val_count}")

    # --- Test/Evaluation Phase ---
    if args.test_path:
        test_df = load_data(args.test_path)
        if test_df is None:
            return

        # Preprocess test_df using the global encoder/scaler fitted on *all* train_df
        test_df, _, _ = preprocess_data(test_df, is_train=False, label_encoder=global_label_encoder, feature_scaler=global_feature_scaler, pavement_ratings_df=pavement_ratings_df, traffic_data_df=traffic_data_df)
        if test_df is None:
            return

        # Retrain model on *all* 2022 data for final predictions
        logging.info("Retraining model on full 2022 data for final predictions.")
        
        # Prepare full training data for the model
        full_X_train_processed_for_model = train_df.copy() # train_df already processed by global_scaler/encoder
        full_X_train_processed_for_model['encoded_key'] = global_label_encoder.transform(train_df['key'])
        full_X_train_final_features = full_X_train_processed_for_model[['encoded_key'] + numerical_features]
        full_y_train = train_df['violation_count']

        full_model = train_model(full_X_train_final_features, full_y_train)
        
        # Prepare test data for prediction
        test_X_processed_for_model = test_df.copy() # test_df already processed by global_scaler
        test_X_processed_for_model['encoded_key'] = -1 # Placeholder, actual encoding in predict func

        final_predictions_df, test_unseen_keys_count = predict(
            full_model, 
            global_label_encoder, 
            global_feature_scaler, # Not directly used by predict now, but kept for signature
            test_X_processed_for_model[['encoded_key'] + numerical_features], # Preprocessed test features
            test_df[['street_name', 'violation_description', 'key']], # Original test_df for output
            all_train_keys_set, 
            all_train_y_mean
        )

        # Save submission file
        final_predictions_df.to_csv("submission.csv", index=False)
        logging.info("Predictions saved to submission.csv")
        logging.info(f"Unseen key pairs in test set (relative to full 2022 data): {test_unseen_keys_count}")

        # If violation_count is present in test_df, calculate RMSE
        if 'violation_count' in test_df.columns:
            logging.info("Calculating RMSE for the test set (ground truth available)...")
            true_counts = test_df['violation_count']
            test_rmse = np.sqrt(mean_squared_error(true_counts, final_predictions_df['predicted_count']))
            logging.info(f"Test Set RMSE: {test_rmse:.4f}")
        else:
            logging.info("Test file does not contain 'violation_count'. Skipping RMSE calculation.")
    else:
        logging.info("No --test-path provided. Skipping final predictions.")

if __name__ == "__main__":
    main()
