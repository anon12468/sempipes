import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import LabelEncoder
import re

def load_and_preprocess_training_data(train_path):
    try:
        train_df = pd.read_csv(train_path)
    except FileNotFoundError:
        print(f"Error: Training file not found at {train_path}")
        exit(1)
    
    train_df.columns = ['street_name', 'violation_type', 'violation_count']

    train_df['violation_count'] = pd.to_numeric(train_df['violation_count'], errors='coerce').fillna(0)
    train_df = train_df.dropna(subset=['street_name', 'violation_type'])
    
    train_df['street_name'] = train_df['street_name'].str.upper().str.strip()
    train_df['violation_type'] = train_df['violation_type'].str.upper().str.strip()
    
    train_df['street_name_length'] = train_df['street_name'].apply(len)

    return train_df

def load_parking_meters_data(corpus_root="corpus/"):
    corpus_path = f"{corpus_root}parking_meters_locations_and_status__693u-uax6.parquet"
    try:
        meters_df = pd.read_parquet(corpus_path)
        print(f"Parking meters data loaded. Shape: {meters_df.shape}")
        return meters_df
    except FileNotFoundError:
        print(f"Warning: Parking meters data not found at {corpus_path}. Skipping this feature.")
        return pd.DataFrame()
    except Exception as e:
        print(f"Warning: Could not load parking meters data due to error: {e}. Skipping this feature.")
        return pd.DataFrame()

def load_pluto_data(corpus_root="corpus/"):
    corpus_path = f"{corpus_root}primary_land_use_tax_lot_output_pluto__64uk-42ks.parquet"
    try:
        pluto_df = pd.read_parquet(corpus_path)
        print(f"PLUTO data loaded. Shape: {pluto_df.shape}")
        
        # Standardize PLUTO borough names to full names
        borough_mapping_pluto = {
            'MN': 'MANHATTAN',
            'BX': 'BRONX',
            'BK': 'BROOKLYN',
            'QN': 'QUEENS',
            'SI': 'STATEN ISLAND'
        }
        if 'borough' in pluto_df.columns:
            pluto_df['borough'] = pluto_df['borough'].astype(str).str.upper().str.strip().replace(borough_mapping_pluto)

        return pluto_df
    except FileNotFoundError:
        print(f"Warning: PLUTO data not found at {corpus_path}. Skipping this feature.")
        return pd.DataFrame()
    except Exception as e:
        print(f"Warning: Could not load PLUTO data due to error: {e}. Skipping this feature.")
        return pd.DataFrame()

def extract_violation_features(df):
    df['is_no_standing'] = df['violation_type'].apply(lambda x: 1 if 'NO STANDING' in x else 0)
    df['is_no_parking'] = df['violation_type'].apply(lambda x: 1 if 'NO PARKING' in x else 0)
    df['is_fire_hydrant'] = df['violation_type'].apply(lambda x: 1 if 'FIRE HYDRANT' in x else 0)
    df['is_expired_meter'] = df['violation_type'].apply(lambda x: 1 if 'EXPIRED METER' in x else 0)
    df['is_registration_expired'] = df['violation_type'].apply(lambda x: 1 if 'REG. STICKER EXPIRED' in x else 0)
    
    df['violation_code'] = df['violation_type'].apply(lambda x: int(re.match(r'(\d+)', x).group(1)) if re.match(r'(\d+)', x) else -1)
    return df

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument("--train-path", type=str, default="/Users/USER/Documents/UNI/SS26/nyc_open_data/train/all_data/violations_per_street_2022.csv",
                        help="Path to the training data (2022 violations).")
    parser.add_argument("--test-path", type=str, default="/Users/USER/Documents/UNI/SS26/nyc_open_data/violations_per_street_2023.csv",
                        help="Path to the test/evaluation data (e.g., 2023 violations).")
    parser.add_argument("--corpus-root", type=str, default="/Users/USER/Documents/UNI/SS26/nyc_open_data/train/all_data/corpus",
                        help="Root directory for augmentation data.")
    args = parser.parse_args()

    train_df = load_and_preprocess_training_data(args.train_path)
    print(f"Training data loaded from {args.train_path}. Shape: {train_df.shape}")
    print(train_df.head())

    le_landuse = LabelEncoder()
    le_postcode = LabelEncoder()
    le_landuse.fit(['UNKNOWN'])
    le_postcode.fit(['UNKNOWN'])

    parking_meters_df = load_parking_meters_data(args.corpus_root)
    pluto_df = load_pluto_data(args.corpus_root) # PLUTO boroughs are now standardized

    train_df = extract_violation_features(train_df)

    # Add parking meter features AND infer borough
    if not parking_meters_df.empty and 'On_Street' in parking_meters_df.columns and 'Borough' in parking_meters_df.columns:
        parking_meters_df['On_Street'] = parking_meters_df['On_Street'].str.upper().str.strip()
        parking_meters_df['Borough'] = parking_meters_df['Borough'].str.upper().str.strip()
        
        street_to_borough_map = parking_meters_df.groupby('On_Street')['Borough'].agg(lambda x: x.mode()[0] if not x.mode().empty else np.nan).to_dict()
        train_df['borough'] = train_df['street_name'].map(street_to_borough_map)
        
        meters_per_street = parking_meters_df.groupby('On_Street').size().reset_index(name='num_parking_meters')
        train_df = pd.merge(train_df, meters_per_street, left_on='street_name', right_on='On_Street', how='left')
        train_df['num_parking_meters'] = train_df['num_parking_meters'].fillna(0)
        train_df.drop(columns=['On_Street'], inplace=True)
        print("Merged parking meter features (including inferred borough) into training data.")
    else:
        print("Parking meter features (and inferred borough) not added.")
        train_df['num_parking_meters'] = 0
        train_df['borough'] = np.nan
    
    if 'borough' not in train_df.columns:
        train_df['borough'] = 'UNKNOWN'
    train_df['borough'] = train_df['borough'].fillna('UNKNOWN') 
    
    print("\n--- Debugging Borough Merge ---")
    print("Unique boroughs in train_df (after inferring from parking meters):")
    print(train_df['borough'].value_counts(dropna=False))

    pluto_features_to_agg = [
        'assessland', 'assesstot', 'exempttot', 'yearbuilt', 'bldgarea', 'comarea', 'resarea',
        'numbldgs', 'numfloors', 'unitstotal', 'lotarea'
    ]

    if not pluto_df.empty and 'borough' in pluto_df.columns:
        # PLUTO boroughs are already standardized by load_pluto_data
        print("\nUnique boroughs in PLUTO data (after standardization):")
        print(pluto_df['borough'].value_counts(dropna=False))

        pluto_numeric_cols_for_agg = [col for col in pluto_features_to_agg if col in pluto_df.columns]
        for col in pluto_numeric_cols_for_agg:
            pluto_df[col] = pd.to_numeric(pluto_df[col], errors='coerce')
        
        pluto_agg = pluto_df.groupby('borough')[pluto_numeric_cols_for_agg].agg(['mean', 'sum', 'count']).reset_index()
        pluto_agg.columns = ['_'.join(col).strip() for col in pluto_agg.columns.values]
        pluto_agg.rename(columns={'borough_': 'borough'}, inplace=True)

        if 'landuse' in pluto_df.columns:
            pluto_landuse_mode = pluto_df.groupby('borough')['landuse'].agg(lambda x: x.mode()[0] if not x.mode().empty else np.nan).reset_index(name='most_common_landuse_borough')
            pluto_agg = pd.merge(pluto_agg, pluto_landuse_mode, on='borough', how='left')
        if 'postcode' in pluto_df.columns:
            pluto_postcode_mode = pluto_df.groupby('borough')['postcode'].agg(lambda x: x.mode()[0] if not x.mode().empty else np.nan).reset_index(name='most_common_postcode_borough')
            pluto_agg = pd.merge(pluto_agg, pluto_postcode_mode, on='borough', how='left')

        initial_train_rows = train_df.shape[0]
        train_df = pd.merge(train_df, pluto_agg, left_on='borough', right_on='borough', how='left')
        
        matched_pluto_borough_rows = (~train_df[f"{pluto_numeric_cols_for_agg[0]}_mean"].isna()).sum() if pluto_numeric_cols_for_agg else 0
        print(f"PLUTO merge (borough-level): {matched_pluto_borough_rows} out of {initial_train_rows} training rows matched PLUTO data.")

        for col in pluto_agg.columns:
            if col not in ['borough', 'most_common_landuse_borough', 'most_common_postcode_borough']:
                train_df[col] = train_df[col].fillna(0)
        
        if 'most_common_landuse_borough' in train_df.columns:
            train_df['most_common_landuse_borough'] = train_df['most_common_landuse_borough'].fillna('UNKNOWN')
            le_landuse.fit(list(le_landuse.classes_) + list(train_df['most_common_landuse_borough'].unique()))
            train_df['most_common_landuse_borough_encoded'] = le_landuse.transform(train_df['most_common_landuse_borough'].astype(str))
            train_df.drop(columns=['most_common_landuse_borough'], inplace=True)
        else:
            train_df['most_common_landuse_borough_encoded'] = le_landuse.transform(pd.Series(['UNKNOWN']))[0]

        if 'most_common_postcode_borough' in train_df.columns:
            train_df['most_common_postcode_borough'] = train_df['most_common_postcode_borough'].fillna('UNKNOWN')
            le_postcode.fit(list(le_postcode.classes_) + list(train_df['most_common_postcode_borough'].unique()))
            train_df['most_common_postcode_borough_encoded'] = le_postcode.transform(train_df['most_common_postcode_borough'].astype(str))
            train_df.drop(columns=['most_common_postcode_borough'], inplace=True)
        else:
            train_df['most_common_postcode_borough_encoded'] = le_postcode.transform(pd.Series(['UNKNOWN']))[0]

        print("Merged PLUTO features (borough-level) into training data.")
    else:
        print("PLUTO features not added (borough column not found or dataframe empty).")
        for col in pluto_features_to_agg:
            for agg_type in ['_mean', '_sum', '_count']:
                train_df[f"{col}{agg_type}"] = 0
        train_df['most_common_landuse_borough_encoded'] = le_landuse.transform(pd.Series(['UNKNOWN']))[0]
        train_df['most_common_postcode_borough_encoded'] = le_postcode.transform(pd.Series(['UNKNOWN']))[0]
    
    le_street = LabelEncoder()
    le_violation = LabelEncoder()
    le_borough = LabelEncoder()

    train_df['street_name_encoded'] = le_street.fit_transform(train_df['street_name'])
    train_df['violation_type_encoded'] = le_violation.fit_transform(train_df['violation_type'])
    train_df['borough_encoded'] = le_borough.fit_transform(train_df['borough'].astype(str))

    features = [
        'street_name_encoded', 'violation_type_encoded', 'num_parking_meters',
        'is_no_standing', 'is_no_parking', 'is_fire_hydrant', 'is_expired_meter',
        'is_registration_expired', 'violation_code', 'borough_encoded',
        'street_name_length'
    ]
    pluto_numeric_features_added = [col for col in train_df.columns if any(col.startswith(f"{f}_") for f in pluto_features_to_agg)]
    
    features.extend(pluto_numeric_features_added)
    
    if 'most_common_landuse_borough_encoded' in train_df.columns:
        features.append('most_common_landuse_borough_encoded')
    if 'most_common_postcode_borough_encoded' in train_df.columns:
        features.append('most_common_postcode_borough_encoded')
    
    target = 'violation_count'

    unique_keys = train_df[['street_name', 'violation_type']].drop_duplicates()
    train_keys, val_keys = train_test_split(unique_keys, test_size=0.2, random_state=42)

    train_val_df = pd.merge(train_df, train_keys, on=['street_name', 'violation_type'], how='inner')
    test_val_df = pd.merge(train_df, val_keys, on=['street_name', 'violation_type'], how='inner')

    if test_val_df.empty:
        print("Warning: Grouped split resulted in empty validation set. Falling back to random split.")
        train_val_df, test_val_df = train_test_split(train_df, test_size=0.2, random_state=42)
    
    X_train_val = train_val_df[features]
    y_train_val = train_val_df[target]
    X_test_val = test_val_df[features]
    y_test_val = test_val_df[target]

    model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1, max_depth=10, min_samples_leaf=5)
    model.fit(X_train_val, y_train_val)

    val_predictions = model.predict(X_test_val)
    val_predictions[val_predictions < 0] = 0
    rmse_val = np.sqrt(mean_squared_error(y_test_val, val_predictions))
    
    unseen_val_key_pairs_count = len(val_keys)
    print(f"Development Validation RMSE (RandomForest on 2022 grouped split): {rmse_val:.4f}")
    print(f"Number of unseen key pairs in development validation set: {unseen_val_key_pairs_count}")
    
    final_model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1, max_depth=10, min_samples_leaf=5)
    final_model.fit(train_df[features], train_df[target])

    if args.test_path:
        test_df = pd.read_csv(args.test_path)
        test_df.columns = ['street_name', 'violation_type', 'violation_count']
        test_df_original_cols = test_df.columns.tolist()
        
        test_df['street_name'] = test_df['street_name'].str.upper().str.strip()
        test_df['violation_type'] = test_df['violation_type'].str.upper().str.strip()
        test_df['street_name_length'] = test_df['street_name'].apply(len)

        test_df = extract_violation_features(test_df)

        if not parking_meters_df.empty and 'On_Street' in parking_meters_df.columns and 'Borough' in parking_meters_df.columns:
            test_df['borough'] = test_df['street_name'].map(street_to_borough_map)
            
            meters_per_street = parking_meters_df.groupby('On_Street').size().reset_index(name='num_parking_meters')
            test_df = pd.merge(test_df, meters_per_street, left_on='street_name', right_on='On_Street', how='left')
            test_df['num_parking_meters'] = test_df['num_parking_meters'].fillna(0)
            test_df.drop(columns=['On_Street'], inplace=True)
        else:
            test_df['num_parking_meters'] = 0
            test_df['borough'] = np.nan
        
        if 'borough' not in test_df.columns:
            test_df['borough'] = 'UNKNOWN'
        test_df['borough'] = test_df['borough'].fillna('UNKNOWN')

        if not pluto_df.empty and 'borough' in pluto_df.columns:
            pluto_df_for_test = pluto_df.copy() 
            # PLUTO boroughs are already standardized in load_pluto_data
            
            pluto_numeric_cols_for_agg_test = [col for col in pluto_features_to_agg if col in pluto_df_for_test.columns]
            for col in pluto_numeric_cols_for_agg_test:
                pluto_df_for_test[col] = pd.to_numeric(pluto_df_for_test[col], errors='coerce')
            
            pluto_agg_test = pluto_df_for_test.groupby('borough')[pluto_numeric_cols_for_agg_test].agg(['mean', 'sum', 'count']).reset_index()
            pluto_agg_test.columns = ['_'.join(col).strip() for col in pluto_agg_test.columns.values]
            pluto_agg_test.rename(columns={'borough_': 'borough'}, inplace=True)

            if 'landuse' in pluto_df_for_test.columns:
                pluto_landuse_mode_test = pluto_df_for_test.groupby('borough')['landuse'].agg(lambda x: x.mode()[0] if not x.mode().empty else np.nan).reset_index(name='most_common_landuse_borough')
                pluto_agg_test = pd.merge(pluto_agg_test, pluto_landuse_mode_test, on='borough', how='left')
            if 'postcode' in pluto_df_for_test.columns:
                pluto_postcode_mode_test = pluto_df_for_test.groupby('borough')['postcode'].agg(lambda x: x.mode()[0] if not x.mode().empty else np.nan).reset_index(name='most_common_postcode_borough')
                pluto_agg_test = pd.merge(pluto_agg_test, pluto_postcode_mode_test, on='borough', how='left')

            test_df = pd.merge(test_df, pluto_agg_test, left_on='borough', right_on='borough', how='left')

            for col in pluto_agg_test.columns:
                if col not in ['borough', 'most_common_landuse_borough', 'most_common_postcode_borough']:
                    test_df[col] = test_df[col].fillna(0)
            
            if 'most_common_landuse_borough' in test_df.columns:
                test_df['most_common_landuse_borough'] = test_df['most_common_landuse_borough'].fillna('UNKNOWN')
                test_df['most_common_landuse_borough_encoded'] = le_landuse.transform(test_df['most_common_landuse_borough'].astype(str))
                test_df.drop(columns=['most_common_landuse_borough'], inplace=True)
            else:
                test_df['most_common_landuse_borough_encoded'] = le_landuse.transform(pd.Series(['UNKNOWN']))[0]
            
            if 'most_common_postcode_borough' in test_df.columns:
                test_df['most_common_postcode_borough'] = test_df['most_common_postcode_borough'].fillna('UNKNOWN')
                test_df['most_common_postcode_borough_encoded'] = le_postcode.transform(test_df['most_common_postcode_borough'].astype(str))
                test_df.drop(columns=['most_common_postcode_borough'], inplace=True)
            else:
                test_df['most_common_postcode_borough_encoded'] = le_postcode.transform(pd.Series(['UNKNOWN']))[0]

            print("Merged PLUTO features (borough-level) into test data.")
        else:
            print("PLUTO features not added to test data (borough column not found or dataframe empty).")
            for col in pluto_features_to_agg:
                for agg_type in ['_mean', '_sum', '_count']:
                    test_df[f"{col}{agg_type}"] = 0
            test_df['most_common_landuse_borough_encoded'] = le_landuse.transform(pd.Series(['UNKNOWN']))[0]
            test_df['most_common_postcode_borough_encoded'] = le_postcode.transform(pd.Series(['UNKNOWN']))[0]
        
        street_mapping = {label: idx for idx, label in enumerate(le_street.classes_)}
        violation_mapping = {label: idx for idx, label in enumerate(le_violation.classes_)}
        borough_mapping = {label: idx for idx, label in enumerate(le_borough.classes_)}

        test_df['street_name_encoded'] = test_df['street_name'].map(street_mapping).fillna(-1).astype(int)
        test_df['violation_type_encoded'] = test_df['violation_type'].map(violation_mapping).fillna(-1).astype(int)
        test_df['borough_encoded'] = test_df['borough'].astype(str).map(borough_mapping).fillna(-1).astype(int)

        train_key_pairs = set(zip(train_df['street_name'], train_df['violation_type']))
        test_df['key_pair_tuple'] = list(zip(test_df['street_name'], test_df['violation_type']))
        test_df['is_unseen_key'] = ~test_df['key_pair_tuple'].isin(train_key_pairs)
        unseen_key_pairs_count = test_df['is_unseen_key'].sum()
        print(f"Total key pairs in test set: {len(test_df)}")
        print(f"Unseen key pairs in test set (not present in 2022 training data): {unseen_key_pairs_count}")

        for feature in features:
            if feature not in test_df.columns:
                test_df[feature] = 0

        X_test = test_df[features]
        
        predictions = final_model.predict(X_test)
        predictions[predictions < 0] = 0
        
        predictions[test_df['is_unseen_key'].values] = 0

        submission_df = test_df[['street_name', 'violation_type']].copy()
        submission_df['predicted_count'] = predictions.round().astype(int)

        submission_df.to_csv("submission.csv", index=False)
        print("Submission.csv generated.")

        if 'violation_count' in test_df_original_cols and test_df['violation_count'].notna().any():
            test_df['violation_count'] = pd.to_numeric(test_df['violation_count'], errors='coerce').fillna(0)
            
            eval_df = pd.merge(submission_df,
                               test_df[['street_name', 'violation_type', 'violation_count']],
                               on=['street_name', 'violation_type'],
                               how='inner')

            if not eval_df.empty:
                rmse = np.sqrt(mean_squared_error(eval_df['violation_count'], eval_df['predicted_count']))
                print(f"RMSE on test data: {rmse:.4f}")
            else:
                print("No overlapping keys with ground truth in test data to calculate RMSE.")
        else:
            print("Test file does not contain 'violation_count' or it's all NaN, skipping RMSE calculation.")
    else:
        print("\nNo test-path provided. Development validation performed.")

if __name__ == "__main__":
    main()
