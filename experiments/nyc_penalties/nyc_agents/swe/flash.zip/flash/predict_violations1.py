import pandas as pd
import argparse
import os
from sklearn.model_selection import GroupKFold
from sklearn.metrics import mean_squared_error
import numpy as np
import lightgbm as lgb
from sklearn.preprocessing import LabelEncoder
import joblib
import re

# Define the path to the corpus directory
# CORPUS_PATH is now handled by args.corpus_path

def load_data(file_path):
    """Loads a CSV file into a DataFrame."""
    try:
        df = pd.read_csv(file_path)
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return None

def load_parquet_from_corpus(filename, corpus_path):
    """Loads a parquet file from the corpus directory."""
    full_path = os.path.join(corpus_path, filename)
    try:
        df = pd.read_parquet(full_path)
        print(f"Loaded {filename} from corpus.")
        return df
    except FileNotFoundError:
        print(f"Error: Corpus file not found: {full_path}")
        return None
    except Exception as e:
        print(f"Error loading corpus file {full_path}: {e}")
        return None

def clean_street_name(street_name):
    """Standardize street names for joining."""
    if pd.isna(street_name):
        return street_name
    
    cleaned_name = str(street_name).upper().strip()
    
    cleaned_name = re.sub(r'\bAVE\b', 'AVENUE', cleaned_name)
    cleaned_name = re.sub(r'\bST\b', 'STREET', cleaned_name)
    cleaned_name = re.sub(r'\bPL\b', 'PLACE', cleaned_name)
    cleaned_name = re.sub(r'\bRD\b', 'ROAD', cleaned_name)
    cleaned_name = re.sub(r'\bBLVD\b', 'BOULEVARD', cleaned_name)
    cleaned_name = re.sub(r'\bPKWY\b', 'PARKWAY', cleaned_name)
    cleaned_name = re.sub(r'\bEXPWY\b', 'EXPRESSWAY', cleaned_name)
    
    cleaned_name = cleaned_name.replace('.', '').replace(',', '')
    cleaned_name = re.sub(r'\s+', ' ', cleaned_name)
    
    return cleaned_name

def preprocess_data(df, parking_meters_df, street_mean_lat, street_mean_lon, le_violation=None, is_train=True):
    """Applies preprocessing steps to the dataframe."""
    df['cleaned_street_name'] = df['Street Name'].apply(clean_street_name)

    # Merge parking meter features
    if parking_meters_df is not None:
        parking_meters_df['cleaned_on_street'] = parking_meters_df['On_Street'].apply(clean_street_name)
        street_meter_features = parking_meters_df.groupby('cleaned_on_street').agg(
            num_parking_meters=('Meter Number', 'count'),
            num_active_meters=('Status', lambda x: (x == 'Active').sum()),
            avg_latitude=('Latitude', 'mean'),
            avg_longitude=('Longitude', 'mean')
        ).reset_index()
        street_meter_features.rename(columns={'cleaned_on_street': 'cleaned_street_name'}, inplace=True)
        
        df = pd.merge(df, street_meter_features, on='cleaned_street_name', how='left')
        
        # Fill NaN values for new features
        df['num_parking_meters'].fillna(0, inplace=True)
        df['num_active_meters'].fillna(0, inplace=True)
        df['avg_latitude'].fillna(street_mean_lat, inplace=True)
        df['avg_longitude'].fillna(street_mean_lon, inplace=True)
    else: # If parking_meters_df is not available (e.g., in a minimal test environment)
        df['num_parking_meters'] = 0
        df['num_active_meters'] = 0
        df['avg_latitude'] = street_mean_lat
        df['avg_longitude'] = street_mean_lon


    # Label Encode 'Violation Description'
    if is_train:
        le_violation = LabelEncoder()
        df['violation_description_encoded'] = le_violation.fit_transform(df['Violation Description'])
        return df, le_violation
    else:
        # Handle unseen violation types in test set
        # Map known violations, assign -1 or a specific unknown category for unseen ones
        df['violation_description_encoded'] = df['Violation Description'].map(lambda s: le_violation.transform([s])[0] if s in le_violation.classes_ else -1)
        # If -1 is not desired for a tree model, map it to a specific value like 0 or the mode
        # For simplicity, using -1 as a distinct category for now, LightGBM can handle it
        return df

def main():
    parser = argparse.ArgumentParser(description="Predict NYC parking violations.")
    parser.add_argument("--train-path", type=str, default="/Users/USER/Documents/UNI/SS26/nyc_open_data/train/all_data/violations_per_street_2022.csv",
                        help="Path to the training data (2022 violations).")
    parser.add_argument("--test-path", type=str, default=None,
                        help="Path to the test/evaluation data (2023 violations).")
    parser.add_argument("--corpus-path", type=str, default="/Users/USER/Documents/UNI/SS26/nyc_open_data/train/all_data/corpus",
                        help="Path to the corpus directory for augmentation data.")
    args = parser.parse_args().parse_args()

    if args.corpus_path:
        global CORPUS_PATH
        CORPUS_PATH = args.corpus_path

    # Load training data
    train_df = load_data(args.train_path)
    if train_df is None:
        return
    print("Training data loaded successfully.")
    print("First 5 rows of training data (original):")
    print(train_df.head())

    # Load parking meter data from corpus
    parking_meters_df = load_parquet_from_corpus("parking_meters_locations_and_status__693u-uax6.parquet")
    
    # Calculate global mean lat/lon for imputation if needed
    global_avg_latitude = parking_meters_df['Latitude'].mean() if parking_meters_df is not None else 40.7
    global_avg_longitude = parking_meters_df['Longitude'].mean() if parking_meters_df is not None else -74.0

    # --- Preprocessing & Feature Engineering for Training Data ---
    print("\nStarting Preprocessing & Feature Engineering for Training Data...")
    train_df_processed, le_violation = preprocess_data(train_df.copy(), parking_meters_df, 
                                                       global_avg_latitude, global_avg_longitude, is_train=True)
    
    print("\nTraining data after preprocessing and feature engineering (first 5 rows):")
    print(train_df_processed.head())
    print(train_df_processed.info())

    # Define features and target
    features = ['num_parking_meters', 'num_active_meters', 'avg_latitude', 'avg_longitude',
                'violation_description_encoded']
    target = 'violation_count'

    X = train_df_processed[features]
    y = train_df_processed[target]
    groups = train_df_processed['cleaned_street_name'] # For GroupKFold

    # --- Model Training and Validation ---
    print("\nStarting Model Training and Validation...")
    
    model = lgb.LGBMRegressor(objective='poisson', random_state=42, n_estimators=1000, learning_rate=0.05, num_leaves=31)
    
    # Using GroupKFold for validation
    gkf = GroupKFold(n_splits=5)
    oof_preds = np.zeros(len(train_df_processed))
    models = []
    rms_scores = []
    
    for fold, (train_idx, val_idx) in enumerate(gkf.split(X, y, groups)):
        print(f"--- Fold {fold+1} ---")
        X_train, X_val = X.iloc[train_idx], X.iloc[val_idx]
        y_train, y_val = y.iloc[train_idx], y.iloc[val_idx]
        
        model.fit(X_train, y_train,
                  eval_set=[(X_val, y_val)],
                  eval_metric='rmse',
                  callbacks=[lgb.early_stopping(100, verbose=False)]) # Early stopping
        
        val_preds = model.predict(X_val)
        val_preds[val_preds < 0] = 0 # Clip negative predictions
        oof_preds[val_idx] = val_preds
        
        rmse = np.sqrt(mean_squared_error(y_val, val_preds))
        rms_scores.append(rmse)
        print(f"Fold {fold+1} RMSE: {rmse:.4f}")
        
        models.append(model) # Store models for ensembling or future use (e.g., test prediction)

    overall_rmse = np.sqrt(mean_squared_error(y, oof_preds))
    print(f"\nOverall OOF RMSE: {overall_rmse:.4f}")
    print(f"Average Fold RMSE: {np.mean(rms_scores):.4f} +/- {np.std(rms_scores):.4f}")

    # For simplicity, we'll use the last trained model or retrain on full data for submission
    # Retrain on full data for final model
    print("\nRetraining final model on full training data...")
    final_model = lgb.LGBMRegressor(objective='poisson', random_state=42, n_estimators=1000, learning_rate=0.05, num_leaves=31)
    final_model.fit(X, y)
    print("Final model trained.")

    # Save the final model and encoders
    joblib.dump(final_model, 'final_model.pkl')
    joblib.dump(le_violation, 'le_violation.pkl')
    print("Final model and LabelEncoder saved.")

    # --- Test/Evaluation path handling (future implementation) ---
    if args.test_path:
        print(f"\nTest path provided: {args.test_path}. Will generate predictions.")
        # Load test data
        test_df_raw = load_data(args.test_path)
        if test_df_raw is None:
            return

        print("Test data loaded successfully.")
        print(test_df_raw.head())

        # Preprocess test data
        test_df_processed = preprocess_data(test_df_raw.copy(), parking_meters_df, 
                                            global_avg_latitude, global_avg_longitude, 
                                            le_violation=le_violation, is_train=False)
        
        # Identify unseen keys in test set
        test_keys = test_df_processed[['cleaned_street_name', 'violation_description_encoded']].apply(tuple, axis=1)
        train_keys = train_df_processed[['cleaned_street_name', 'violation_description_encoded']].apply(tuple, axis=1)
        
        unseen_test_keys_count = len(test_keys[~test_keys.isin(train_keys)].unique())
        print(f"Number of unseen (street_name, violation_type) pairs in test set: {unseen_test_keys_count}")
        print(f"        - Unseen violation types are encoded as -1.")
        print(f"        - Unseen street names have parking meter features (count, active) imputed with 0, and latitude/longitude imputed with global averages from the training data.")
        # Make predictions
        X_test = test_df_processed[features]
        test_predictions = final_model.predict(X_test)
        test_predictions[test_predictions < 0] = 0
        test_predictions = np.round(test_predictions).astype(int) # Round and convert to int for counts

        # Generate submission file
        submission_df = pd.DataFrame({
            'street_name': test_df_raw['Street Name'],
            'violation_type': test_df_raw['Violation Description'],
            'predicted_count': test_predictions
        })
        submission_df.to_csv("submission.csv", index=False)
        print("\nSubmission file 'submission.csv' generated.")

        # If test file has 'violation_count', calculate RMSE
        if 'violation_count' in test_df_raw.columns:
            actual_counts = test_df_raw['violation_count']
            test_rmse = np.sqrt(mean_squared_error(actual_counts, test_predictions))
            print(f"RMSE on provided test/evaluation set: {test_rmse:.4f}")
        else:
            print("Test file does not contain 'violation_count' for evaluation.")


    print("\nScript execution complete.")

if __name__ == "__main__":
    main()
