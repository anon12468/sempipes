import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import os

def load_street_project_features(year, corpus_path="corpus/street_and_highway_capital_reconstruction_projects_intersect__97nd-ff3i.parquet"):
    """
    Loads street project data and generates features relevant for a given year.
    Features: count of projects, total cost, count of active projects.
    """
    if not os.path.exists(corpus_path):
        print(f"Corpus file not found for street projects: {corpus_path}. Skipping feature creation.")
        return pd.DataFrame()

    projects_df = pd.read_parquet(corpus_path)

    # Standardize street names for joining
    projects_df['ONSTREETNAME_CLEAN'] = projects_df['OnStreetName'].str.upper().str.strip()

    # Convert date columns, coerce errors will turn unparseable dates into NaT
    projects_df['DesignStartDate'] = pd.to_datetime(projects_df['DesignStartDate'], errors='coerce')
    projects_df['ConstructionEndDate'] = pd.to_datetime(projects_df['ConstructionEndDate'], errors='coerce')
    
    # Filter projects relevant up to the specified year (e.g., for predicting 2023, use projects completed by end of 2022)
    # Consider projects where ConstructionFY is <= year.
    relevant_projects = projects_df[
        (projects_df['ConstructionFY'] <= year)
    ].copy()
    
    if relevant_projects.empty:
        return pd.DataFrame()

    # Aggregate features per street
    street_project_features = relevant_projects.groupby('ONSTREETNAME_CLEAN').agg(
        project_count=('ProjectID', 'nunique'),
        total_project_cost=('ProjectCost', 'sum'),
        # Count projects marked as 'Active' or 'Ongoing' within the relevant year
        num_active_projects=('ProjectStatus', lambda x: (x == 'Active').sum() + (x == 'Ongoing').sum()),
    ).reset_index()

    street_project_features = street_project_features.rename(columns={'ONSTREETNAME_CLEAN': 'street_name'})
    return street_project_features

def main():
    parser = argparse.ArgumentParser(description="Predict parking violations.")
    parser.add_argument("--train-path", type=str, default="/Users/USER/Documents/UNI/SS26/nyc_open_data/train/all_data/violations_per_street_2022.csv",
                        help="Path to the 2022 training data CSV.")
    parser.add_argument("--test-path", type=str, default="/Users/USER/Documents/UNI/SS26/nyc_open_data/violations_per_street_2023.csv",
                        help="Optional path to the 2023 test/evaluation data CSV.")
    args = parser.parse_args()

    # --- Load and preprocess training data ---
    print(f"Loading training data from: {args.train_path}")
    train_df = pd.read_csv(args.train_path)
    print("Training data loaded.")

    # Normalize column names
    train_df.columns = ['street_name', 'violation_type', 'violation_count']
    train_df['street_name'] = train_df['street_name'].str.upper().str.strip()
    train_df['violation_type'] = train_df['violation_type'].str.upper().str.strip() # Standardize violation type too

    # Augment with street project features for 2022
    print("Loading street project features for 2022 (training)...")
    street_project_features_2022 = load_street_project_features(year=2022)
    if not street_project_features_2022.empty:
        train_df = train_df.merge(street_project_features_2022, on='street_name', how='left')
        print(f"Street project features added to training data. New shape: {train_df.shape}")
        # Fill NaNs for streets with no projects
        train_df['project_count'] = train_df['project_count'].fillna(0)
        train_df['total_project_cost'] = train_df['total_project_cost'].fillna(0)
        train_df['num_active_projects'] = train_df['num_active_projects'].fillna(0)
    else:
        print("No street project features loaded for 2022. Defaulting to 0 for features.")
        train_df['project_count'] = 0
        train_df['total_project_cost'] = 0
        train_df['num_active_projects'] = 0


    # Encode street_name and violation_type separately
    street_encoder = LabelEncoder()
    violation_encoder = LabelEncoder()

    train_df['encoded_street'] = street_encoder.fit_transform(train_df['street_name'])
    train_df['encoded_violation'] = violation_encoder.fit_transform(train_df['violation_type'])

    # Features for the model: encoded_street, encoded_violation and new augmentation features
    feature_cols = ['encoded_street', 'encoded_violation', 'project_count', 'total_project_cost', 'num_active_projects']
    
    # Split 2022 data into training and validation sets
    X = train_df[feature_cols]
    y = train_df['violation_count']

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    print(f"Training data shape: {X_train.shape}, Validation data shape: {X_val.shape}")

    # --- Model Training ---
    print("Training RandomForestRegressor model...")
    model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
    model.fit(X_train, y_train)
    print("Model training complete.")

    # --- Internal Validation ---
    print("Evaluating model on internal validation set...")
    val_predictions = model.predict(X_val)
    val_predictions[val_predictions < 0] = 0 # Clip negative predictions

    rmse_val = np.sqrt(mean_squared_error(y_val, val_predictions))
    print(f"Validation RMSE: {rmse_val:.4f}")

    # --- External Test Set Prediction ---
    if args.test_path:
        print(f"Loading test/evaluation data from: {args.test_path}")
        test_df = pd.read_csv(args.test_path)
        print("Test/Evaluation data loaded.")

        # Normalize column names
        test_df.columns = ['street_name', 'violation_type'] if 'violation_count' not in test_df.columns else ['street_name', 'violation_type', 'violation_count']
        test_df['street_name'] = test_df['street_name'].str.upper().str.strip()
        test_df['violation_type'] = test_df['violation_type'].str.upper().str.strip() # Standardize violation type too

        # Augment with street project features for 2023 (prediction)
        print("Loading street project features for 2022 (prediction context for 2023)...")
        street_project_features_2023_context = load_street_project_features(year=2022) # Using 2022 data for 2023 prediction
        if not street_project_features_2023_context.empty:
            test_df = test_df.merge(street_project_features_2023_context, on='street_name', how='left')
            print(f"Street project features added to test data. New shape: {test_df.shape}")
            # Fill NaNs for streets with no projects
            test_df['project_count'] = test_df['project_count'].fillna(0)
            test_df['total_project_cost'] = test_df['total_project_cost'].fillna(0)
            test_df['num_active_projects'] = test_df['num_active_projects'].fillna(0)
        else:
            print("No street project features loaded for 2023 context. Defaulting to 0 for features.")
            test_df['project_count'] = 0
            test_df['total_project_cost'] = 0
            test_df['num_active_projects'] = 0

        # Handle unseen streets and violation types
        # Map existing categories, use a default for unseen ones
        test_df['encoded_street'] = test_df['street_name'].map(lambda s: street_encoder.transform([s])[0] if s in street_encoder.classes_ else -1).astype(int)
        test_df['encoded_violation'] = test_df['violation_type'].map(lambda v: violation_encoder.transform([v])[0] if v in violation_encoder.classes_ else -1).astype(int)

        unseen_street_count = (test_df['encoded_street'] == -1).sum()
        unseen_violation_count = (test_df['encoded_violation'] == -1).sum()
        total_test_rows = len(test_df)
        print(f"{unseen_street_count} out of {total_test_rows} test streets were unseen in training.")
        print(f"{unseen_violation_count} out of {total_test_rows} test violation types were unseen in training.")

        # Prepare features for prediction
        test_feature_cols = ['encoded_street', 'encoded_violation', 'project_count', 'total_project_cost', 'num_active_projects']
        X_test_all = test_df[test_feature_cols]

        # Handle unseen categories for prediction:
        # A simple strategy: replace -1 with the mode or a placeholder value,
        # or predict a global average for rows with unseen categories.
        # For tree-based models, -1 might be treated as just another category.
        # Let's replace -1 with a value that is outside the range of actual encoded values,
        # but consistent. E.g., max_encoded_value + 1
        max_encoded_street = len(street_encoder.classes_)
        max_encoded_violation = len(violation_encoder.classes_)

        X_test_all['encoded_street'] = X_test_all['encoded_street'].replace(-1, max_encoded_street)
        X_test_all['encoded_violation'] = X_test_all['encoded_violation'].replace(-1, max_encoded_violation)

        test_predictions = model.predict(X_test_all)
        test_predictions[test_predictions < 0] = 0 # Ensure non-negative

        test_df['predicted_count'] = test_predictions

        # Generate submission.csv
        submission_df = test_df[['street_name', 'violation_type', 'predicted_count']]
        submission_df.to_csv("submission.csv", index=False)
        print("Submission file 'submission.csv' created.")

        # If violation_count is present in test_df, calculate RMSE
        if 'violation_count' in test_df.columns:
            print("Calculating RMSE for external test set...")
            test_rmse = np.sqrt(mean_squared_error(test_df['violation_count'], test_df['predicted_count']))
            print(f"External Test RMSE: {test_rmse:.4f}")
        else:
            print("Test-path provided without 'violation_count'. Skipping external RMSE calculation.")
    else:
        print("No test-path provided. Skipping external prediction and submission.")

    print("Script finished.")

if __name__ == "__main__":
    main()
