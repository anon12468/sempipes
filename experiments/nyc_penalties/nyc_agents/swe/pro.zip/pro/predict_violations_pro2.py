import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import GroupShuffleSplit
from sklearn.metrics import mean_squared_error
import lightgbm as lgb

def load_data(file_path):
    """Loads data from a CSV file."""
    try:
        return pd.read_csv(file_path)
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return None

def load_meter_features():
    """Loads and aggregates parking meter data."""
    try:
        meter_df = pd.read_parquet('corpus/parking_meters_locations_and_status__693u-uax6.parquet')
        meter_df['On_Street'] = meter_df['On_Street'].str.upper().str.strip()
        return meter_df.groupby('On_Street').size().reset_index(name='meter_count')
    except FileNotFoundError:
        print("Warning: Parking meter data not found.")
        return None

def load_tree_features():
    """Loads and aggregates street tree census data."""
    try:
        tree_df = pd.read_parquet('corpus/2005_street_tree_census__29bw-z7pj.parquet', columns=['address'])
        tree_df.dropna(subset=['address'], inplace=True)
        tree_df['street_name'] = tree_df['address'].str.replace(r'^\d+[^a-zA-Z]+', '', regex=True).str.upper().str.strip()
        return tree_df.groupby('street_name').size().reset_index(name='tree_count')
    except FileNotFoundError:
        print("Warning: Tree census data not found.")
        return None

def train_model(X_train, y_train, categorical_features):
    """Trains a LightGBM model."""
    lgb_params = {
        'objective': 'regression_l1', 'metric': 'rmse', 'n_estimators': 1000,
        'learning_rate': 0.05, 'feature_fraction': 0.8, 'bagging_fraction': 0.8,
        'bagging_freq': 1, 'verbose': -1, 'n_jobs': -1, 'seed': 42
    }
    model = lgb.LGBMRegressor(**lgb_params)
    model.fit(X_train, y_train, categorical_feature=categorical_features)
    return model

def main():
    parser = argparse.ArgumentParser(description='Predict parking violations.')
    parser.add_argument('--train-path', type=str, default='/Users/USER/Documents/UNI/SS26/nyc_open_data/train/all_data/violations_per_street_2022.csv', help='Path to training data.')
    parser.add_argument('--test-path', type=str, help='Path to test data.', default="/Users/USER/Documents/UNI/SS26/nyc_open_data/violations_per_street_2023.csv")
    args = parser.parse_args()

    train_df = load_data(args.train_path)
    if train_df is None: return

    train_df['Street Name'] = train_df['Street Name'].str.upper().str.strip()
    
    meter_features = load_meter_features()
    if meter_features is not None:
        train_df = pd.merge(train_df, meter_features, left_on='Street Name', right_on='On_Street', how='left').fillna({'meter_count': 0})
        train_df.drop(columns=['On_Street'], inplace=True, errors='ignore')

    tree_features = load_tree_features()
    if tree_features is not None:
        train_df = pd.merge(train_df, tree_features, left_on='Street Name', right_on='street_name', how='left').fillna({'tree_count': 0})
        train_df.drop(columns=['street_name'], inplace=True, errors='ignore')

    train_df['street_name_cat'] = train_df['Street Name'].astype('category')
    train_df['violation_type_cat'] = train_df['Violation Description'].astype('category')
    
    train_df['street_name_code'] = train_df['street_name_cat'].cat.codes
    train_df['violation_type_code'] = train_df['violation_type_cat'].cat.codes

    features = ['street_name_code', 'violation_type_code', 'meter_count', 'tree_count']
    features = [f for f in features if f in train_df.columns]
    target = 'violation_count'

    X = train_df[features]
    y = train_df[target]
    
    gss = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=42)
    train_idx, val_idx = next(gss.split(X, y, groups=train_df['Street Name']))
    
    X_train, X_val = X.iloc[train_idx], X.iloc[val_idx]
    y_train, y_val = y.iloc[train_idx], y.iloc[val_idx]

    model = train_model(X_train, y_train, categorical_features=['street_name_code', 'violation_type_code'])
    
    val_preds = model.predict(X_val)
    val_preds[val_preds < 0] = 0
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    print(f"Validation RMSE (2022 holdout): {val_rmse:.4f}")

    if args.test_path:
        test_df = load_data(args.test_path)
        if test_df is None: return

        test_df['Street Name'] = test_df['Street Name'].str.upper().str.strip()
        if meter_features is not None:
            test_df = pd.merge(test_df, meter_features, left_on='Street Name', right_on='On_Street', how='left').fillna({'meter_count': 0})
        if tree_features is not None:
            test_df = pd.merge(test_df, tree_features, left_on='Street Name', right_on='street_name', how='left').fillna({'tree_count': 0})
        
        test_df['street_name_code'] = pd.Categorical(test_df['Street Name'], categories=train_df['street_name_cat'].cat.categories).codes
        test_df['violation_type_code'] = pd.Categorical(test_df['Violation Description'], categories=train_df['violation_type_cat'].cat.categories).codes
        
        print(f"Found {(test_df['street_name_code'] == -1).sum()} key pairs with unseen streets in the test set.")
        
        X_test = test_df[features]
        predictions = model.predict(X_test)
        predictions[predictions < 0] = 0

        submission_df = pd.DataFrame({'street_name': test_df['Street Name'], 'violation_type': test_df['Violation Description'], 'predicted_count': predictions.round().astype(int)})
        submission_df.to_csv('submission.csv', index=False)
        print("Generated submission.csv")

        if 'violation_count' in test_df.columns:
            test_rmse = np.sqrt(mean_squared_error(test_df['violation_count'], predictions))
            print(f"Test RMSE: {test_rmse:.4f}")

if __name__ == '__main__':
    main()
