import pandas as pd
import numpy as np
import argparse
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import lightgbm as lgb
import warnings

warnings.filterwarnings('ignore')

def clean_street_name(street_name):
    if isinstance(street_name, str):
        return street_name.strip().upper()
    return street_name

def load_and_preprocess_data(file_path):
    df = pd.read_csv(file_path)
    df.columns = [col.replace(' ', '_').lower() for col in df.columns]
    df['street_name'] = df['street_name'].apply(clean_street_name)
    # Aggregate counts for duplicate (street, violation) pairs, if any
    df = df.groupby(['street_name', 'violation_description']).agg(violation_count=('violation_count', 'sum')).reset_index()
    return df

def feature_engineering(df, augmentation_dfs):
    # Basic features
    df['street_name_len'] = df['street_name'].str.len()

    # Augmentation features - restaurants
    if 'restaurants' in augmentation_dfs:
        restaurants_df = augmentation_dfs['restaurants']
        street_restaurant_counts = restaurants_df.groupby('STREET').size().reset_index(name='restaurant_count')
        df = pd.merge(df, street_restaurant_counts, left_on='street_name', right_on='STREET', how='left')
        df['restaurant_count'] = df['restaurant_count'].fillna(0)
        df.drop('STREET', axis=1, inplace=True)

    # Augmentation features - pavement ratings
    if 'pavement' in augmentation_dfs:
        pavement_df = augmentation_dfs['pavement']
        # Convert SystemRating to numeric, coercing errors
        pavement_df['SystemRating'] = pd.to_numeric(pavement_df['SystemRating'], errors='coerce')
        street_pavement_ratings = pavement_df.groupby('OnStreetName')['SystemRating'].mean().reset_index(name='avg_pavement_rating')
        df = pd.merge(df, street_pavement_ratings, left_on='street_name', right_on='OnStreetName', how='left')
        # Fill missing ratings with the median of the ratings
        df['avg_pavement_rating'] = df['avg_pavement_rating'].fillna(df['avg_pavement_rating'].median())
        df.drop('OnStreetName', axis=1, inplace=True)
        
    return df

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--train-path', type=str, default='violations_per_street_2022.csv')
    parser.add_argument('--test-path', type=str, default="/Users/USER/Documents/UNI/SS26/nyc_open_data/violations_per_street_2023.csv")
    args = parser.parse_args()

    print("Loading and preprocessing training data...")
    train_df = load_and_preprocess_data(args.train_path)

    print("Loading augmentation data...")
    augmentation_dfs = {}
    try:
        restaurants_df = pd.read_parquet('corpus/dohmh_new_york_city_restaurant_inspection_results__43nn-pn8j.parquet')
        restaurants_df['STREET'] = restaurants_df['STREET'].apply(clean_street_name)
        augmentation_dfs['restaurants'] = restaurants_df
    except Exception as e:
        print(f"Could not load restaurant data: {e}")

    try:
        pavement_df = pd.read_parquet('corpus/street_pavement_ratings__6yyb-pb25.parquet')
        pavement_df['OnStreetName'] = pavement_df['OnStreetName'].apply(clean_street_name)
        augmentation_dfs['pavement'] = pavement_df
    except Exception as e:
        print(f"Could not load pavement data: {e}")

    print("Performing feature engineering...")
    train_df = feature_engineering(train_df, augmentation_dfs)
    
    # Convert categorical features
    categorical_features = ['violation_description']
    for col in categorical_features:
        train_df[col] = train_df[col].astype('category')
    
    features = [col for col in train_df.columns if col not in ['street_name', 'violation_count']]
    target = 'violation_count'
    
    X = train_df[features]
    y = np.log1p(train_df[target]) # Use log transform for skewed target

    # Split 2022 data for validation
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

    print("Training LightGBM model...")
    lgb_params = {
        'objective': 'regression_l1',
        'metric': 'rmse',
        'n_estimators': 1000,
        'learning_rate': 0.05,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 1,
        'verbose': -1,
        'n_jobs': -1,
        'seed': 42
    }
    
    model = lgb.LGBMRegressor(**lgb_params)
    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='rmse',
              callbacks=[lgb.early_stopping(100, verbose=True)],
              categorical_feature=[col for col in categorical_features if col in X_train.columns])

    val_preds = model.predict(X_val)
    val_preds = np.expm1(val_preds) # Inverse transform
    val_preds[val_preds < 0] = 0 # Ensure non-negative predictions
    
    rmse = np.sqrt(mean_squared_error(np.expm1(y_val), val_preds))
    print(f"Validation RMSE on 2022 data: {rmse:.4f}")

    if args.test_path:
        print(f"\nProcessing test file: {args.test_path}...")
        try:
            test_df_orig = pd.read_csv(args.test_path)
            test_df_orig.columns = [col.replace(' ', '_').lower() for col in test_df_orig.columns]
            test_df = test_df_orig.copy()
            has_target = 'violation_count' in test_df.columns
        except FileNotFoundError:
            print(f"Test file not found at {args.test_path}")
            return

        test_df['street_name'] = test_df['street_name'].apply(clean_street_name)

        train_keys = set(zip(train_df['street_name'], train_df['violation_description']))
        test_keys = set(zip(test_df['street_name'], test_df['violation_description']))
        unseen_keys_count = len(test_keys - train_keys)
        print(f"Number of unseen (street, violation) pairs in test set: {unseen_keys_count}")

        test_df = feature_engineering(test_df, augmentation_dfs)
        
        for col in categorical_features:
             # Ensure test categories are known to the model
            test_df[col] = pd.Categorical(test_df[col], categories=train_df[col].cat.categories, ordered=False)


        # Align columns
        test_cols = test_df.columns
        train_cols = X_train.columns
        missing_in_test = set(train_cols) - set(test_cols)
        for c in missing_in_test:
            test_df[c] = 0
        test_df = test_df[train_cols] # ensure order and columns are the same
        
        test_preds = model.predict(test_df)
        test_preds = np.expm1(test_preds)
        test_preds[test_preds < 0] = 0
        
        submission_df = test_df_orig[['street_name', 'violation_description']].copy()
        submission_df['predicted_count'] = np.round(test_preds).astype(int)

        # A more robust way to handle unseen keys during prediction
        # Get predictions for all test rows first. Then, identify which ones were unseen.
        # Fallback for keys that were completely unseen in the training data (street and violation combo)
        violation_medians = train_df.groupby('violation_description')['violation_count'].median()
        global_median = train_df['violation_count'].median()
        
        # Create a helper series for mapping predictions
        train_key_str = train_df['street_name'].astype(str) + " | " + train_df['violation_description'].astype(str)
        test_key_str = submission_df['street_name'].astype(str) + " | " + submission_df['violation_description'].astype(str)
        
        unseen_mask = ~test_key_str.isin(train_key_str)
        
        unseen_violations = submission_df.loc[unseen_mask, 'violation_description']
        fallback_preds = unseen_violations.map(violation_medians).fillna(global_median)
        submission_df.loc[unseen_mask, 'predicted_count'] = fallback_preds.values.round().astype(int)

        print("Generating submission.csv...")
        submission_df.to_csv('submission.csv', index=False)
        
        if has_target:
            test_rmse = np.sqrt(mean_squared_error(test_df_orig['violation_count'], submission_df['predicted_count']))
            print(f"RMSE on test file '{args.test_path}': {test_rmse:.4f}")

if __name__ == '__main__':
    main()
