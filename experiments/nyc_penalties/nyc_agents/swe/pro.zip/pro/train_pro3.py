import argparse
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import numpy as np

def clean_street_name(street_name):
    """Standardizes street names."""
    if pd.isna(street_name):
        return ""
    street_name = str(street_name).upper().strip()
    replacements = {
        ' AV ': ' AVENUE ', ' AVE ': ' AVENUE ', ' AVE': ' AVENUE',
        ' ST ': ' STREET ', ' ST.': ' STREET', ' ST': ' STREET',
        ' RD ': ' ROAD ',
        ' BLVD ': ' BOULEVARD ',
        ' PKWY ': ' PARKWAY ',
        ' PL ': ' PLACE ',
        ' LN ': ' LANE ',
        ' DR ': ' DRIVE ',
    }
    street_name = f" {street_name} "
    for old, new in replacements.items():
        street_name = street_name.replace(old, new)
    return street_name.strip()

def load_and_preprocess_data(train_path):
    """Loads training data and augmentation data, then merges them."""
    df_train = pd.read_csv(train_path)
    df_train['Street Name'] = df_train['Street Name'].apply(clean_street_name)
    df_train.rename(columns={'Violation Description': 'violation_type', 'Street Name': 'street_name'}, inplace=True)
    
    try:
        df_meters = pd.read_parquet('corpus/parking_meters_locations_and_status__693u-uax6.parquet')
        df_meters['On_Street'] = df_meters['On_Street'].apply(clean_street_name)
        meter_counts = df_meters.groupby('On_Street').size().reset_index(name='meter_count')
        df_train = pd.merge(df_train, meter_counts, how='left', left_on='street_name', right_on='On_Street')
        df_train['meter_count'] = df_train['meter_count'].fillna(0)
        df_train.drop(columns=['On_Street'], inplace=True, errors='ignore')
    except Exception as e:
        print(f"Could not load or process augmentation data: {e}. Proceeding without it.")
        df_train['meter_count'] = 0

    return df_train

def main():
    parser = argparse.ArgumentParser(description="Parking Violation Prediction Model")
    parser.add_argument('--train-path', type=str, default='violations_per_street_2022.csv', help='Path to the training data CSV.')
    parser.add_argument('--test-path', type=str, default='/Users/USER/Documents/UNI/SS26/nyc_open_data/violations_per_street_2023.csv', help='(Optional) Path to the test data CSV.')
    args = parser.parse_args()

    df_train = load_and_preprocess_data(args.train_path)

    df_train['key'] = df_train['street_name'] + ' | ' + df_train['violation_type']

    le_key = LabelEncoder()
    df_train['key_encoded'] = le_key.fit_transform(df_train['key'])
    
    features = ['key_encoded', 'meter_count']
    target = 'violation_count'
    
    X = df_train[features]
    y = df_train[target]

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    
    model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1, min_samples_leaf=5)
    model.fit(X_train, y_train)
    
    val_preds = model.predict(X_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, val_preds))
    print(f"Validation RMSE on 2022 data: {val_rmse:.4f}")

    if args.test_path:
        df_test = pd.read_csv(args.test_path)
        
        df_test.rename(columns={'Violation Description': 'violation_type', 'Street Name': 'street_name'}, inplace=True)
        df_test['street_name'] = df_test['street_name'].apply(clean_street_name)
        
        try:
            df_meters = pd.read_parquet('corpus/parking_meters_locations_and_status__693u-uax6.parquet')
            df_meters['On_Street'] = df_meters['On_Street'].apply(clean_street_name)
            meter_counts = df_meters.groupby('On_Street').size().reset_index(name='meter_count')
            df_test = pd.merge(df_test, meter_counts, how='left', left_on='street_name', right_on='On_Street')
            df_test['meter_count'] = df_test['meter_count'].fillna(0)
            df_test.drop(columns=['On_Street'], inplace=True, errors='ignore')
        except Exception as e:
            print(f"Could not load augmentation data for test set: {e}. Proceeding without it.")
            df_test['meter_count'] = 0

        df_test['key'] = df_test['street_name'] + ' | ' + df_test['violation_type']
        
        # --- Handle Seen and Unseen Keys Separately ---
        seen_mask = df_test['key'].isin(le_key.classes_)
        
        print(f"Found {len(df_test) - seen_mask.sum()} unseen key pairs in the test set out of {len(df_test)} total rows.")
        
        df_test['predicted_count'] = 0.0
        
        # Predict for seen keys
        if seen_mask.sum() > 0:
            df_test_seen = df_test[seen_mask].copy()
            df_test_seen['key_encoded'] = le_key.transform(df_test_seen['key'])
            X_test_seen = df_test_seen[features]
            predictions_seen = model.predict(X_test_seen)
            df_test.loc[seen_mask, 'predicted_count'] = predictions_seen

        # Handle unseen keys by predicting the mean of the training data
        if (~seen_mask).sum() > 0:
            mean_violation_count = y_train.mean()
            df_test.loc[~seen_mask, 'predicted_count'] = mean_violation_count
        
        # Post-processing
        df_test['predicted_count'] = df_test['predicted_count'].clip(0)
        df_test['predicted_count'] = np.round(df_test['predicted_count'])

        submission_df = df_test[['street_name', 'violation_type', 'predicted_count']]
        submission_df.to_csv('submission.csv', index=False)
        print("Generated submission.csv")

        if 'violation_count' in df_test.columns:
            test_rmse = np.sqrt(mean_squared_error(df_test['violation_count'], df_test['predicted_count']))
            print(f"Test RMSE on {args.test_path}: {test_rmse:.4f}")

if __name__ == '__main__':
    main()
