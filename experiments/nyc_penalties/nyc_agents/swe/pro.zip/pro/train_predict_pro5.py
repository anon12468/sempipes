import pandas as pd
import numpy as np
import lightgbm as lgb
from sklearn.model_selection import GroupKFold
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder
import argparse
import os

def load_and_preprocess_augmentation_data(corpus_path):
    """Loads and preprocesses augmentation datasets."""
    # 1. Parking Meters Data
    meters_path = os.path.join(corpus_path, 'parking_meters_locations_and_status__693u-uax6.parquet')
    try:
        meters_df = pd.read_parquet(meters_path)
        meters_df['Street Name'] = meters_df['On_Street'].str.upper()
        meter_counts = meters_df.groupby('Street Name').size().reset_index(name='meter_count')
    except Exception as e:
        print(f"Warning: Could not load or process parking meters data. {e}")
        meter_counts = pd.DataFrame(columns=['Street Name', 'meter_count'])

    # 2. Pavement Ratings Data
    pavement_path = os.path.join(corpus_path, 'street_pavement_ratings__6yyb-pb25.parquet')
    try:
        pavement_df = pd.read_parquet(pavement_path)
        pavement_df['Street Name'] = pavement_df['OnStreetName'].str.upper()
        # Ensure SystemRating is numeric, coerce errors to NaN and fill
        pavement_df['SystemRating'] = pd.to_numeric(pavement_df['SystemRating'], errors='coerce')
        avg_pavement_rating = pavement_df.groupby('Street Name')['SystemRating'].mean().reset_index(name='avg_pavement_rating')
        avg_pavement_rating['avg_pavement_rating'] = avg_pavement_rating['avg_pavement_rating'].fillna(avg_pavement_rating['avg_pavement_rating'].median())
    except Exception as e:
        print(f"Warning: Could not load or process pavement data. {e}")
        avg_pavement_rating = pd.DataFrame(columns=['Street Name', 'avg_pavement_rating'])
        
    return meter_counts, avg_pavement_rating

def feature_engineering(df, meter_counts, avg_pavement_rating):
    """Applies feature engineering to the main dataframe."""
    df['Street Name'] = df['Street Name'].str.upper()
    df['Violation Description'] = df['Violation Description'].str.upper()
    
    # Merge with augmentation data
    df = pd.merge(df, meter_counts, on='Street Name', how='left')
    df = pd.merge(df, avg_pavement_rating, on='Street Name', how='left')
    
    # Fill missing values for augmented features
    df['meter_count'] = df['meter_count'].fillna(0)
    if not avg_pavement_rating.empty:
        median_rating = avg_pavement_rating['avg_pavement_rating'].median()
        df['avg_pavement_rating'] = df['avg_pavement_rating'].fillna(median_rating)
    else:
        df['avg_pavement_rating'] = df.get('avg_pavement_rating', pd.Series(5.0, index=df.index)).fillna(5.0) # A neutral default


    # Label Encoding for categorical features
    for col in ['Street Name', 'Violation Description']:
        le = LabelEncoder()
        df[col + '_encoded'] = le.fit_transform(df[col].astype(str))

    # Basic interaction features
    df['street_violation_interaction'] = df['Street Name_encoded'] * df['Violation Description_encoded']
    
    return df

def train_and_evaluate(train_df):
    """Trains the model and evaluates it using cross-validation."""
    features = [
        'Street Name_encoded', 
        'Violation Description_encoded',
        'meter_count',
        'avg_pavement_rating',
        'street_violation_interaction'
    ]
    target = 'violation_count'
    
    X = train_df[features]
    y = train_df[target]
    
    # Use GroupKFold to prevent leakage, groups are street names
    groups = train_df['Street Name_encoded']
    gkf = GroupKFold(n_splits=5)
    
    models = []
    val_scores = []
    
    print("Starting training with 5-fold cross-validation...")
    for fold, (train_idx, val_idx) in enumerate(gkf.split(X, y, groups)):
        print(f"--- Fold {fold+1} ---")
        X_train, y_train = X.iloc[train_idx], y.iloc[train_idx]
        X_val, y_val = X.iloc[val_idx], y.iloc[val_idx]
        
        model = lgb.LGBMRegressor(objective='rmse',
                                  metric='rmse',
                                  n_estimators=1000,
                                  learning_rate=0.05,
                                  feature_fraction=0.8,
                                  bagging_fraction=0.8,
                                  bagging_freq=1,
                                  lambda_l1=0.1,
                                  lambda_l2=0.1,
                                  num_leaves=31,
                                  verbose=-1,
                                  n_jobs=-1,
                                  seed=42)
        
        model.fit(X_train, y_train,
                  eval_set=[(X_val, y_val)],
                  eval_metric='rmse',
                  callbacks=[lgb.early_stopping(100, verbose=False)])
        
        preds = model.predict(X_val)
        rmse = np.sqrt(mean_squared_error(y_val, preds))
        val_scores.append(rmse)
        models.append(model)
        print(f"Fold {fold+1} Validation RMSE: {rmse}")
        
    avg_rmse = np.mean(val_scores)
    print(f"\nAverage Cross-Validation RMSE: {avg_rmse}")
    
    # Retrain on full data for final model
    print("Retraining model on full 2022 dataset...")
    final_model = lgb.LGBMRegressor(objective='rmse', n_estimators=1200, learning_rate=0.05, seed=42, verbose=-1, n_jobs=-1)
    final_model.fit(X, y)
    
    return final_model, features

def predict(model, test_df, features, train_df):
    """Generates predictions for the test set."""
    
    # Handle unseen keys
    train_street_names = set(train_df['Street Name'].unique())
    test_street_names = set(test_df['Street Name'].unique())
    unseen_streets = test_street_names - train_street_names
    
    train_violation_types = set(train_df['Violation Description'].unique())
    test_violation_types = set(test_df['Violation Description'].unique())
    unseen_violations = test_violation_types - train_violation_types

    print(f"Found {len(unseen_streets)} street names in test set not present in training data.")
    print(f"Found {len(unseen_violations)} violation types in test set not present in training data.")
    
    # A simple strategy for unseen keys: use global average or a default value
    # For now, the feature engineering handles this by NaNs -> 0/median
    # and LabelEncoder will assign new numbers to them.
    # LightGBM can handle new categories to some extent.
    
    # Re-apply label encoding based on the combined vocabulary of train and test
    combined_streets = pd.concat([train_df['Street Name'], test_df['Street Name']]).astype(str).unique()
    combined_violations = pd.concat([train_df['Violation Description'], test_df['Violation Description']]).astype(str).unique()

    le_street = LabelEncoder().fit(combined_streets)
    le_violation = LabelEncoder().fit(combined_violations)

    test_df['Street Name_encoded'] = le_street.transform(test_df['Street Name'].astype(str))
    test_df['Violation Description_encoded'] = le_violation.transform(test_df['Violation Description'].astype(str))
    test_df['street_violation_interaction'] = test_df['Street Name_encoded'] * test_df['Violation Description_encoded']

    X_test = test_df[features]
    predictions = model.predict(X_test)
    
    # Ensure predictions are non-negative
    predictions[predictions < 0] = 0
    
    return predictions.round()


def main():
    parser = argparse.ArgumentParser(description="Parking Violation Prediction")
    parser.add_argument('--train-path', type=str, default='violations_per_street_2022.csv',
                        help='Path to the training data file.')
    parser.add_argument('--test-path', type=str, default='/Users/USER/Documents/UNI/SS26/nyc_open_data/violations_per_street_2023.csv',
                        help='Optional path to the test/evaluation data file.')
    parser.add_argument('--corpus-path', type=str, default='corpus/',
                        help='Path to the corpus data folder.')
    args = parser.parse_args()

    # Load and process augmentation data
    print("Loading augmentation data...")
    meter_counts, avg_pavement_rating = load_and_preprocess_augmentation_data(args.corpus_path)
    
    # Load and prepare training data
    print("Loading training data...")
    train_df = pd.read_csv(args.train_path)
    train_df = feature_engineering(train_df, meter_counts, avg_pavement_rating)
    
    # Train model
    model, features = train_and_evaluate(train_df)
    
    # Handle test/evaluation if path is provided
    if args.test_path:
        print(f"\nProcessing test file: {args.test_path}")
        test_df = pd.read_csv(args.test_path)
        
        # Store original keys for submission file
        submission_df = test_df[['Street Name', 'Violation Description']].copy()
        
        # Check if ground truth is present for scoring
        has_ground_truth = 'violation_count' in test_df.columns
        
        # Feature engineering on test data
        test_df_featured = feature_engineering(test_df.copy(), meter_counts, avg_pavement_rating)
        
        # Generate predictions
        predictions = predict(model, test_df_featured, features, train_df)
        submission_df['predicted_count'] = predictions
        
        # Save submission file
        submission_df.to_csv('submission.csv', index=False, header=['street_name', 'violation_type', 'predicted_count'])
        print("Generated submission.csv")
        
        # Score if ground truth is available
        if has_ground_truth:
            test_rmse = np.sqrt(mean_squared_error(test_df['violation_count'], predictions))
            print(f"RMSE on test file '{args.test_path}': {test_rmse}")

if __name__ == '__main__':
    main()
