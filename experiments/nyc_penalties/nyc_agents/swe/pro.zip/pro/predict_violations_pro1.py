import pandas as pd
import numpy as np
import argparse
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import warnings

warnings.filterwarnings('ignore', category=UserWarning)

def create_features(df, pavement_features=None, target_stats=None):
    """
    Creates features for the model.
    - Merges pavement data.
    - Creates target-encoded features.
    """
    df['street_name_std'] = df['street_name'].str.upper().str.strip()
    
    if pavement_features is not None:
        df = pd.merge(df, pavement_features, on='street_name_std', how='left')
        mean_rating = pavement_features['mean_pavement_rating'].mean()
        df['mean_pavement_rating'].fillna(mean_rating, inplace=True)
    
    if target_stats is None:
        street_mean = df.groupby('street_name_std')['violation_count'].mean().to_dict()
        violation_mean = df.groupby('violation_description')['violation_count'].mean().to_dict()
        target_stats = {'street_mean': street_mean, 'violation_mean': violation_mean}
    
    global_street_mean = np.mean(list(target_stats['street_mean'].values())) if target_stats['street_mean'] else 0
    global_violation_mean = np.mean(list(target_stats['violation_mean'].values())) if target_stats['violation_mean'] else 0
    
    df['street_mean_count'] = df['street_name_std'].map(target_stats['street_mean']).fillna(global_street_mean)
    df['violation_mean_count'] = df['violation_description'].map(target_stats['violation_mean']).fillna(global_violation_mean)
    
    return df, target_stats

def train_and_predict_lgbm(train_df, test_df=None, test_original_cols=None, corpus_path='corpus/street_pavement_ratings__6yyb-pb25.parquet'):
    """
    Main function to train a LightGBM model, validate it, and make predictions.
    """
    try:
        pavement_df = pd.read_parquet(corpus_path)
        pavement_df['street_name_std'] = pavement_df['OnStreetName'].str.upper().str.strip()
        pavement_features = pavement_df.groupby('street_name_std').agg(
            mean_pavement_rating=('SystemRating', 'mean')
        ).reset_index()
    except Exception as e:
        print(f"Warning: Could not load or process corpus file {corpus_path}: {e}")
        pavement_features = None

    train_set, val_set = train_test_split(train_df, test_size=0.2, random_state=42)
    
    train_set_featured, target_stats = create_features(train_set.copy(), pavement_features)
    val_set_featured, _ = create_features(val_set.copy(), pavement_features, target_stats)
    
    features = ['street_mean_count', 'violation_mean_count']
    if pavement_features is not None:
        features.append('mean_pavement_rating')
    
    categorical_features = ['street_name', 'violation_description']
    
    X_train = train_set_featured[features + categorical_features]
    y_train_log = np.log1p(train_set_featured['violation_count'])
    X_val = val_set_featured[features + categorical_features]
    y_val_true = val_set_featured['violation_count']

    for col in categorical_features:
        X_train[col] = X_train[col].astype('category')
        X_val[col] = X_val[col].astype('category')

    lgb_params = {'objective': 'regression_l1', 'metric': 'rmse', 'n_estimators': 1000, 'learning_rate': 0.05, 'feature_fraction': 0.8, 'bagging_fraction': 0.8, 'bagging_freq': 1, 'verbose': -1, 'n_jobs': -1, 'seed': 42}
    
    model = lgb.LGBMRegressor(**lgb_params)
    model.fit(X_train, y_train_log, eval_set=[(X_val, np.log1p(y_val_true))], eval_metric='rmse', callbacks=[lgb.early_stopping(100, verbose=False)])

    val_preds = np.maximum(0, np.expm1(model.predict(X_val)))
    val_rmse = np.sqrt(mean_squared_error(y_val_true, val_preds))
    print(f"--- Development Validation (using LightGBM) ---")
    print(f"Validation RMSE: {val_rmse:.4f}")
    print("-" * 30)

    if test_df is not None:
        full_train_featured, full_target_stats = create_features(train_df.copy(), pavement_features)
        test_df_featured, _ = create_features(test_df.copy(), pavement_features, full_target_stats)
        
        X_full_train = full_train_featured[features + categorical_features]
        y_full_train_log = np.log1p(full_train_featured['violation_count'])
        X_test = test_df_featured[features + categorical_features]
        
        for col in categorical_features:
            X_full_train[col] = X_full_train[col].astype('category')
            X_test[col] = X_test[col].astype('category')

        final_model = lgb.LGBMRegressor(**lgb_params)
        final_model.fit(X_full_train, y_full_train_log)
        
        test_preds = np.maximum(0, np.expm1(final_model.predict(X_test)))
        test_df_featured['predicted_count'] = test_preds

        unseen_streets = test_df_featured['street_name_std'].map(full_target_stats['street_mean']).isna().sum()
        unseen_violations = test_df_featured['violation_description'].map(full_target_stats['violation_mean']).isna().sum()
        print(f"--- Test Set Inference ({args.test_path}) ---")
        print(f"Unseen Streets: {unseen_streets}, Unseen Violations: {unseen_violations} (handled by global mean features)")

        if 'violation_count' in test_df_featured.columns:
            test_rmse = np.sqrt(mean_squared_error(test_df_featured['violation_count'], test_df_featured['predicted_count']))
            print(f"Test RMSE: {test_rmse:.4f}")
        
        submission_df = test_df_featured[['street_name', 'violation_description', 'predicted_count']]
        submission_df.columns = [test_original_cols[0], test_original_cols[1], 'predicted_count']
        submission_df.to_csv('submission.csv', index=False)
        print("Generated submission.csv")

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Predict NYC parking violations with LightGBM.")
    parser.add_argument('--train-path', type=str, default='/Users/USER/Documents/UNI/SS26/nyc_open_data/train/all_data/violations_per_street_2022.csv', help='Path to the training data CSV file.')
    parser.add_argument('--test-path', type=str, default='/Users/USER/Documents/UNI/SS26/nyc_open_data/violations_per_street_2023.csv', help='(Optional) Path to the test data CSV file.')
    args = parser.parse_args()

    try:
        train_df = pd.read_csv(args.train_path)
        train_df.columns = [c.lower().replace(' ', '_') for c in train_df.columns]
    except FileNotFoundError:
        print(f"Fatal: Training file not found at {args.train_path}")
        exit(1)

    test_df = None
    test_original_cols = None
    if args.test_path:
        try:
            test_df = pd.read_csv(args.test_path)
            test_original_cols = list(test_df.columns)
            test_df.columns = [c.lower().replace(' ', '_') for c in test_df.columns]
        except FileNotFoundError:
            print(f"Warning: Test file not found at {args.test_path}, proceeding without generating predictions.")
    
    train_and_predict_lgbm(train_df, test_df, test_original_cols)
