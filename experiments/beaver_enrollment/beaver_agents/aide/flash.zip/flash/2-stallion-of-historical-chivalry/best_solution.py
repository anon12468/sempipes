import pandas as pd
import numpy as np
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import f1_score
import os
from pathlib import Path

# --- Configuration Block ---
BASE_DATA_DIR = "/Users/USER/Documents/UNI/SS26/BEAVER/table_splits/train"
# Gold labels path
# Description says 'eval/gold_enrollment_train.csv' but file listing shows 'input/gold_enrollment_train.csv'.
# We'll use the latter, relative to BASE_DATA_DIR.
TRAIN_LABELS_FILE = "gold_enrollment_train.csv"

# Test split (future terms); see table_splits/goal.txt
TEST_DATA_DIR = "/Users/USER/Documents/UNI/SS26/BEAVER/test"

# Core feature tables
SUBJECT_OFFERED_SUMMARY_FILE = "SUBJECT_OFFERED_SUMMARY.csv"
ENROLLMENT_HISTORY_FEATURES_FILE = "ENROLLMENT_HISTORY_FEATURES.csv"
ACADEMIC_TERMS_FILE = "ACADEMIC_TERMS.csv"


# --- Load Data ---
def load_data():
    """Loads necessary dataframes from the specified paths."""
    train_labels = pd.read_csv(os.path.join(BASE_DATA_DIR, TRAIN_LABELS_FILE))
    subject_summary = pd.read_csv(
        os.path.join(BASE_DATA_DIR, SUBJECT_OFFERED_SUMMARY_FILE)
    )
    enroll_history = pd.read_csv(
        os.path.join(BASE_DATA_DIR, ENROLLMENT_HISTORY_FEATURES_FILE)
    )
    academic_terms = pd.read_csv(os.path.join(BASE_DATA_DIR, ACADEMIC_TERMS_FILE))
    test_subject_summary = pd.read_csv(
        os.path.join(TEST_DATA_DIR, SUBJECT_OFFERED_SUMMARY_FILE)
    )
    test_enroll_history = pd.read_csv(
        os.path.join(TEST_DATA_DIR, ENROLLMENT_HISTORY_FEATURES_FILE)
    )
    return (
        train_labels,
        subject_summary,
        enroll_history,
        academic_terms,
        test_subject_summary,
        test_enroll_history,
    )


# --- Feature Engineering ---
def engineer_features(subject_summary, enroll_history, academic_terms):
    """
    Merges dataframes and creates features for the model.
    Assumes subject_summary contains all terms (train+test).
    """
    # Merge core features
    features_df = subject_summary.merge(
        enroll_history, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left"
    )

    # Merge academic term details
    # Only keep relevant term columns to avoid memory/redundancy.
    academic_terms_slim = academic_terms[
        [
            "TERM_CODE",
            "ACADEMIC_YEAR",
            "TERM_DESCRIPTION",
            "TERM_START_DATE",
            "TERM_END_DATE",
        ]
    ].copy()
    features_df = features_df.merge(academic_terms_slim, on="TERM_CODE", how="left")

    # Derive additional temporal features
    features_df["TERM_SEASON"] = (
        features_df["TERM_CODE"].astype(str).str[-2:]
    )  # E.g., '01', '05', '09'

    # Impute missing historical enrollment features with 0 (a simple baseline)
    for col in ["lag1_enrollment", "lag2_enrollment", "roll3_enrollment_mean"]:
        features_df[col] = features_df[col].fillna(0)

    # Impute other potential missing numerical features (e.g. total_units can be nan for some cases)
    # Filling with 0 assuming 0 units when missing.
    features_df["TOTAL_UNITS"] = features_df["TOTAL_UNITS"].fillna(0)
    features_df["LECTURE_UNITS"] = features_df["LECTURE_UNITS"].fillna(0)
    features_df["LAB_UNITS"] = features_df["LAB_UNITS"].fillna(0)
    features_df["PREPARATION_UNITS"] = features_df["PREPARATION_UNITS"].fillna(0)

    # Define features to use in the model
    # Dropping subject title for simplicity for initial model
    # 'SUBJECT_ID_SORT' or 'MASTER_SUBJECT_ID_SORT' as IDs (can be categorical too)
    numerical_features = [
        "lag1_enrollment",
        "lag2_enrollment",
        "roll3_enrollment_mean",
        "TOTAL_UNITS",
        "LECTURE_UNITS",
        "LAB_UNITS",
        "PREPARATION_UNITS",
    ]
    categorical_features = [
        "OFFER_DEPT_CODE",
        "OFFER_SCHOOL_NAME",
        "CLUSTER_TYPE",
        "HGN_CODE",
        "ACADEMIC_YEAR",
        "TERM_SEASON",
    ]  # ACADEMIC_YEAR also treated as categorical for LGBM

    # Convert categorical features to 'category' dtype for LightGBM
    for col in categorical_features:
        if col in features_df.columns:
            features_df[col] = features_df[col].astype("category")
        else:
            print(f"Warning: Categorical feature '{col}' not found in DataFrame.")

    return features_df, numerical_features, categorical_features


# --- Main Execution ---
if __name__ == "__main__":
    (
        train_labels,
        subject_summary,
        enroll_history,
        academic_terms,
        test_subject_summary,
        test_enroll_history,
    ) = load_data()

    # Create master ID column for merging and identifying train/test rows later
    train_labels["TERM_SUBJECT_ID"] = (
        train_labels["TERM_CODE"].astype(str) + "_" + train_labels["SUBJECT_ID_SORT"]
    )
    subject_summary["TERM_SUBJECT_ID"] = (
        subject_summary["TERM_CODE"].astype(str)
        + "_"
        + subject_summary["SUBJECT_ID_SORT"]
    )

    # Generate all features from global files
    all_features_df, numerical_cols, categorical_cols = engineer_features(
        subject_summary, enroll_history, academic_terms
    )
    test_features_df, _, _ = engineer_features(
        test_subject_summary, test_enroll_history, academic_terms
    )

    # Split into actual train_df and potential test_df based on gold labels
    # `all_features_df` contains all available term/subject pairs.
    # `train_df_raw` are those for which we have labels.
    train_df_raw = all_features_df.merge(
        train_labels,
        on=["TERM_CODE", "SUBJECT_ID_SORT", "TERM_SUBJECT_ID"],
        how="inner",
    )

    # Test data: all offerings from the held-out test split
    test_df_prediction_input = test_features_df

    # Define final features set
    features_to_use = numerical_cols + [
        col for col in categorical_cols if col in all_features_df.columns
    ]

    X_full_train = train_df_raw[features_to_use]
    y_full_train = train_df_raw["HIGH_ENROLLMENT"]

    # --- Time-based Validation Split within Training Data ---
    # Sort by TERM_CODE to ensure chronological split
    train_df_raw = train_df_raw.sort_values(by="TERM_CODE").reset_index(drop=True)

    # Find unique term codes and split
    unique_terms = train_df_raw["TERM_CODE"].unique()
    # Let's take approximately the latest 20% of terms for validation
    split_idx = int(len(unique_terms) * 0.8)
    train_terms = unique_terms[:split_idx]
    val_terms = unique_terms[split_idx:]

    X_train = train_df_raw[train_df_raw["TERM_CODE"].isin(train_terms)][features_to_use]
    y_train = train_df_raw[train_df_raw["TERM_CODE"].isin(train_terms)][
        "HIGH_ENROLLMENT"
    ]
    X_val = train_df_raw[train_df_raw["TERM_CODE"].isin(val_terms)][features_to_use]
    y_val = train_df_raw[train_df_raw["TERM_CODE"].isin(val_terms)]["HIGH_ENROLLMENT"]

    print(f"Training set size: {len(X_train)}")
    print(f"Validation set size: {len(X_val)}")
    print(f"Test prediction set size: {len(test_df_prediction_input)}")

    # Ensure LightGBM recognizes categorical features
    # If the categories for a feature differ between X_train and X_val/X_test,
    # it can lead to issues or suboptimal performance. Setting explicitly during init.
    categorical_feature_indices = [
        X_train.columns.get_loc(col)
        for col in categorical_cols
        if col in X_train.columns
    ]

    # --- Model Training ---
    # LightGBM Classifier parameters - simple starting point
    lgbm = lgb.LGBMClassifier(
        objective="binary",
        metric="binary_f1",  # Evaluate using F1 during training
        random_state=42,
        n_estimators=500,  # A moderate number of estimators
        learning_rate=0.05,
        num_leaves=31,
        is_unbalance=True,  # Handles imbalanced classes by default, good for binary F1.
        n_jobs=-1,  # Use all available cores
        categorical_feature=[col for col in categorical_cols if col in X_train.columns],
    )  # Explicitly pass categorical column names

    lgbm.fit(
        X_train,
        y_train,
        eval_set=[(X_val, y_val)],
        eval_metric="f1_macro",  # Eval metric for early stopping (though not using early stopping here)
        callbacks=[lgb.log_evaluation(100)],
    )

    # --- Evaluation ---
    val_preds = lgbm.predict(X_val)
    macro_f1 = f1_score(y_val, val_preds, average="macro")
    print(f"Validation Macro F1 Score: {macro_f1:.4f}")

    # --- Test Prediction and Submission ---
    # Prepare test data for prediction
    X_test_final = test_df_prediction_input[features_to_use]

    # Make sure columns are consistent and categorical dtypes are consistent
    for col in categorical_cols:
        if col in X_test_final.columns:
            # Ensure the test data has the same categories as train data.
            # Convert to category and then reindex to train categories to align.
            X_test_final[col] = pd.Categorical(
                X_test_final[col], categories=X_train[col].cat.categories
            )

    test_preds = lgbm.predict(X_test_final)

    submission_df = pd.DataFrame(
        {
            "TERM_CODE": test_df_prediction_input["TERM_CODE"],
            "SUBJECT_ID_SORT": test_df_prediction_input["SUBJECT_ID_SORT"],
            "HIGH_ENROLLMENT": test_preds,
        }
    )

    # Save submission file
    submission_df.to_csv("submission.csv", index=False)
    print("Submission file created successfully in ./working/submission.csv")
