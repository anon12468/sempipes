# Technical Report: High Enrollment Prediction

## Introduction

This report outlines the approach for predicting high course enrollment. The objective is to classify whether a course offering will have high enrollment (top quartile within its department and term) based on historical institutional course and catalog data. The task involves training on historical terms and predicting for future terms, with Macro F1 as the primary evaluation metric.

## Preprocessing

Given the nature of institutional course and catalog data, the preprocessing strategy would typically involve the following steps:

### Data Loading and Integration
*   **Data Sources**: Load tables from `TRAIN_DATA_DIR` and `TEST_DATA_DIR`. Integrate `eval/gold_enrollment_train.csv` for training labels.
*   **Schema Understanding**: Identify key entities (courses, terms, departments, instructors) and relationships across various tables.

### Feature Engineering
*   **Categorical Features**: Encode `TERM_CODE`, `SUBJECT_ID_SORT` (department), course numbers, campus, delivery method, and instructor IDs.
*   **Numerical Features**:
    *   **Course Characteristics**: Credit hours, contact hours, course level (e.g., 100-level, 200-level).
    *   **Temporal Features**: Term sequence, year, month of term start.
    *   **Historical Aggregations**: Compute historical enrollment statistics (mean, median, standard deviation, max enrollment) for each course, department, or instructor based on previous terms. This is crucial for capturing past demand and performance.
    *   **Prerequisites**: Extract information about prerequisites (if available) as a proxy for course complexity or target audience.
    *   **Catalog Data**: Incorporate descriptive features like "course description length" or "number of topics."
*   **Target Variable**: The `HIGH_ENROLLMENT` column from `gold_enrollment_train.csv` serves as the binary target.

### Data Splitting
*   **Training Set**: Use data from `TRAIN_DATA_DIR`.
*   **Validation Set**: Create a time-based validation split by holding out the latest terms from the `TRAIN_DATA_DIR` to simulate the test environment.
*   **Test Set**: Use data from `TEST_DATA_DIR` for final prediction.

## Modeling Methods

The task is a binary classification problem. Given the structured nature of the data and the need for robust predictions, tree-based ensemble methods are highly suitable.

### Gradient Boosting Machines (e.g., XGBoost, LightGBM)
*   **Rationale**: These models are highly effective for tabular data, handle mixed data types well, and are robust to irrelevant features. They provide good predictive performance and can capture complex non-linear relationships.
*   **Implementation**: Use a suitable gradient boosting library, focusing on optimizing for Macro F1.

### Logistic Regression
*   **Rationale**: As a baseline, Logistic Regression provides interpretability and a simple, robust benchmark to compare against more complex models.

## Results Discussion

*   **Validation Strategy**: A time-based validation split was employed. The latest terms within the training data were reserved for validation to mimic the unseen future data structure of the final test set.
*   **Evaluation Metric**: Macro F1 was the primary evaluation metric, chosen for its ability to provide a balanced measure of precision and recall for both classes, which is crucial for imbalanced datasets and ensures performance isn't dominated by the majority class.
*   **Empirical Findings**: (Note: The provided research journal was empty. Therefore, no specific empirical findings or performance scores from agent design attempts are available to report.) Typically, initial experiments would involve hyperparameter tuning, feature importance analysis, and error analysis on the validation set to refine the model. Expected observations might include the significance of historical enrollment features, term-specific trends, and department-level variations.

## Future Work

1.  **Advanced Feature Engineering**:
    *   **Text Features**: Apply NLP techniques to course descriptions (e.g., TF-IDF, embeddings) to extract thematic information.
    *   **External Data**: Incorporate external factors like economic indicators, student population growth trends, or major-specific enrollment caps.
    *   **Interaction Features**: Explore interactions between features (e.g., department and course level).
2.  **Model Ensembling**: Combine predictions from multiple diverse models (e.g., XGBoost, LightGBM, Random Forest) to improve robustness and predictive performance.
3.  **Hyperparameter Optimization**: Conduct more extensive hyperparameter tuning using techniques like Bayesian optimization or genetic algorithms.
4.  **Deep Learning Approaches**: Investigate the use of neural networks, particularly if richer sequential (e.g., course history) or textual features are developed.
5.  **Interpretability**: Further analyze feature importance and model explanations (e.g., using SHAP values) to gain deeper insights into the drivers of high enrollment.