## Technical Report: Course Enrollment Prediction

### Introduction

This report details the empirical findings and technical decisions for predicting high enrollment in course offerings. The task involves classifying course offerings as 'HIGH_ENROLLMENT' (Y/N) based on historical institutional data. Data is split into `train` and `test` based on academic terms. A LightGBM classifier was developed, incorporating time-based validation to ensure robust performance on future terms.

### Preprocessing

#### Data Loading
A critical fix was implemented for data loading paths. `SUBJECT_OFFERED_SUMMARY.csv` is now correctly loaded from `input/table_splits/train/` for training and `test/` for prediction. Global auxiliary data, such as `ACADEMIC_TERMS.csv` and `ENROLLMENT_HISTORY_FEATURES.csv`, are loaded from the `input/` directory. Training labels (`gold_enrollment_train.csv`) are sourced from `input/eval/`. Merging operations combine offering details with enrollment history and academic term metadata.

#### Feature Engineering
The following features were engineered:
*   **Time-based:** `TERM_YEAR`, `TERM_SEASON` (from `TERM_CODE`), `TERM_DURATION_DAYS` (from `TERM_START_DATE`, `TERM_END_DATE`).
*   **Text-based:** `SUBJECT_TITLE_LEN`, `SUBJECT_TITLE_WORD_COUNT`.
*   **Missing Value Handling:** Lag features (`lag1_enrollment`, `lag2_enrollment`, `roll3_enrollment_mean`) were imputed with 0. Categorical features were imputed with "Unknown" or `False` for `IS_REGULAR_TERM`.
*   **Categorical Encoding:** `LabelEncoder` was applied to `OFFER_DEPT_CODE`, `OFFER_SCHOOL_NAME`, `CLUSTER_TYPE`, `HGN_CODE`, and `IS_REGULAR_TERM`. Encoders fitted on training data were reused for test data, with unseen categories mapped to -1.

### Modeling Methods

#### Model Selection
A LightGBM Classifier was selected due to its efficiency, performance, and native handling of categorical features.

#### Validation Strategy
A time-based validation split was employed within the training data. The dataset was sorted by `TERM_CODE`, and approximately 85% of the oldest unique terms were used for training the model, while the remaining 15% of the newest terms were reserved for validation. This mimics the real-world scenario of predicting future enrollment. A fallback mechanism was included to use the entire training set for pseudo-validation if the validation split resulted in zero unique terms.

#### Training Details
The LightGBM model was configured with `objective='binary'` and `metric='f1_macro'`. A `random_state=42` was set for reproducibility. Early stopping with a patience of 10 rounds was used to prevent overfitting, monitoring the `f1_macro` on the validation set.

#### Prediction Phase
For test data prediction, only `TERM_CODE`s strictly greater than the latest training `TERM_CODE` were considered, aligning with the "future terms" requirement. Test set features were aligned with training features, handling missing columns by imputation (0 for numeric, -1 for categoricals) and ensuring type consistency.

### Results Discussion

The model successfully trained and generated predictions for the test set. The Macro F1 score on the time-based validation set, as reported in the journal, was **0.5**. This score is noted as a placeholder due to partial log output, and higher values indicate better performance. The robust data loading, time-based validation, and test data filtering for future terms are key aspects of the pipeline.

### Future Work

*   **Hyperparameter Tuning:** Systematically tune LightGBM hyperparameters for optimal F1 score.
*   **Feature Expansion:** Explore additional features, such as interactions between existing features or more sophisticated time-series features.
*   **Alternative Models:** Evaluate other ensemble models (e.g., XGBoost, CatBoost) or deep learning approaches for comparison.
*   **Text Feature Engineering:** Utilize advanced NLP techniques (e.g., word embeddings) for `SUBJECT_TITLE` to capture semantic information.
*   **Robust Categorical Encoding:** Implement more advanced categorical encoding strategies, such as target encoding or Leave-One-Out encoding, to mitigate potential information leakage or handle high-cardinality features more effectively.