import pandas as pd
import numpy as np
import lightgbm as lgb
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import f1_score
import os

# --- Configuration Block ---
# Global data directory for files common to both train and test (e.g., ACADEMIC_TERMS.csv, ENROLLMENT_HISTORY_FEATURES.csv, gold_enrollment_train.csv)
GLOBAL_DATA_DIR = ""

# Specific directories for the subject offerings splits
# TRAIN_DATA_DIR is specified as "table_splits/train" relative to the input root
TRAIN_OFFERINGS_DIR = "/Users/USER/Documents/UNI/SS26/BEAVER/table_splits/train"
# TEST_DATA_DIR is given as "__TEST_DATA_DIR__" to be replaced with "test/"
TEST_OFFERINGS_DIR = "/Users/USER/Documents/UNI/SS26/BEAVER/test/"

# Output directory for submission and any temporary files
WORKING_DIR = "working"
os.makedirs(WORKING_DIR, exist_ok=True)


# --- Function to load and prepare data ---
# Redefined to clearly separate global data sources from specific offerings data sources
def load_and_prepare_data(offerings_data_path, global_data_path, is_training=True):
    print(
        f"Loading data from offerings path: {offerings_data_path} "
        f"and global data path: {global_data_path}"
    )

    # Always load enrollment history and academic terms from the global data path
    df_enrollment_history = pd.read_csv(
        os.path.join(global_data_path, "ENROLLMENT_HISTORY_FEATURES.csv")
    )
    df_academic_terms = pd.read_csv(
        os.path.join(global_data_path, "ACADEMIC_TERMS.csv")
    )

    # Process academic terms for merging
    df_academic_terms["TERM_START_DATE"] = pd.to_datetime(
        df_academic_terms["TERM_START_DATE"], errors="coerce"
    )
    df_academic_terms["TERM_END_DATE"] = pd.to_datetime(
        df_academic_terms["TERM_END_DATE"], errors="coerce"
    )
    df_academic_terms = df_academic_terms[
        [
            "TERM_CODE",
            "TERM_START_DATE",
            "TERM_END_DATE",
            "ACADEMIC_YEAR",
            "IS_REGULAR_TERM",
        ]
    ]

    # Load the SUBJECT_OFFERED_SUMMARY.csv specific to the current split (train/test)
    subject_offered_filepath = os.path.join(
        offerings_data_path, "SUBJECT_OFFERED_SUMMARY.csv"
    )
    if not os.path.exists(subject_offered_filepath):
        raise FileNotFoundError(f"Required file not found: {subject_offered_filepath}")

    df_subject_offered = pd.read_csv(subject_offered_filepath)
    print(f"Loaded {len(df_subject_offered)} offerings from {subject_offered_filepath}")

    # Merge offering details with enrollment history and academic terms
    df = pd.merge(
        df_subject_offered,
        df_enrollment_history,
        on=["TERM_CODE", "SUBJECT_ID_SORT"],
        how="left",
    )
    df = pd.merge(df, df_academic_terms, on="TERM_CODE", how="left")

    if is_training:
        # Load labels for training data from global eval directory
        train_labels = pd.read_csv(
            os.path.join("/Users/USER/Documents/UNI/SS26/BEAVER", "eval", "gold_enrollment_train.csv")
        )
        # Merge using inner to keep only labeled samples for the training set
        df = pd.merge(
            df, train_labels, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="inner"
        )
        # Convert target to numerical (Y=1, N=0)
        df["HIGH_ENROLLMENT"] = df["HIGH_ENROLLMENT"].map({"Y": 1, "N": 0})
        print(
            f"Merged with training labels, total samples for potential training: {len(df)}"
        )
    else:
        print(f"Preparing test data, total offerings: {len(df)}")

    return df


# --- Feature Engineering ---
def create_features(df, training_encoders=None):
    df = df.copy()

    df["TERM_YEAR"] = df["TERM_CODE"].astype(str).str[:4].astype(int)
    df["TERM_SEASON"] = df["TERM_CODE"].astype(str).str[4:].astype(int)

    df["TERM_DURATION_DAYS"] = (
        df["TERM_END_DATE"] - df["TERM_START_DATE"]
    ).dt.days.fillna(0)

    df["SUBJECT_TITLE_LEN"] = df["SUBJECT_TITLE"].fillna("").apply(len)
    df["SUBJECT_TITLE_WORD_COUNT"] = (
        df["SUBJECT_TITLE"].fillna("").apply(lambda x: len(x.split()))
    )

    lag_features = ["lag1_enrollment", "lag2_enrollment", "roll3_enrollment_mean"]
    for col in lag_features:
        df[col] = df[col].fillna(0)

    categorical_cols = [
        "OFFER_DEPT_CODE",
        "OFFER_SCHOOL_NAME",
        "CLUSTER_TYPE",
        "HGN_CODE",
    ]

    for col in categorical_cols:
        df[col] = df[col].fillna("Unknown")

    if "IS_REGULAR_TERM" in df.columns and (
        df["IS_REGULAR_TERM"].dtype == "object" or df["IS_REGULAR_TERM"].dtype == "bool"
    ):
        categorical_cols.append("IS_REGULAR_TERM")
        df["IS_REGULAR_TERM"] = df["IS_REGULAR_TERM"].fillna(False).astype(str)

    encoders = training_encoders if training_encoders is not None else {}
    for col in categorical_cols:
        if col in df.columns:
            if col not in encoders:
                encoders[col] = LabelEncoder()
                df[col] = encoders[col].fit_transform(df[col].astype(str))
            else:
                # Use existing encoder, handle unseen categories
                df[col] = df[col].astype(str)
                df[col] = df[col].apply(
                    lambda x: (
                        encoders[col].transform([x])[0]
                        if x in encoders[col].classes_
                        else -1
                    )
                )

    return df, categorical_cols, encoders


# Main execution block
if __name__ == "__main__":
    # --- Load and preprocess training data ---
    # Using TRAIN_OFFERINGS_DIR for the base SUBJECT_OFFERED_SUMMARY.csv specific to training split
    train_df_raw = load_and_prepare_data(
        TRAIN_OFFERINGS_DIR, "/Users/USER/Documents/UNI/SS26/BEAVER/table_splits/train", is_training=True
    )

    # --- Feature Engineering for training data ---
    train_df, categorical_features, label_encoders = create_features(
        train_df_raw.copy()
    )

    # Ensure TERM_CODEs are numeric for sorting
    train_df["TERM_CODE"] = train_df["TERM_CODE"].astype("int")

    # Identify final features for training
    features = [
        col
        for col in train_df.columns
        if col
        not in [
            "TERM_CODE",
            "SUBJECT_ID_SORT",
            "SUBJECT_TITLE",
            "TERM_START_DATE",
            "TERM_END_DATE",
            "HIGH_ENROLLMENT",
            "ACADEMIC_YEAR",
            "MASTER_SUBJECT_ID_SORT",
        ]
    ]

    X = train_df[features]
    y = train_df["HIGH_ENROLLMENT"]

    # --- Time-based Validation Split ---
    train_df_sorted = train_df.sort_values("TERM_CODE").reset_index(drop=True)
    unique_terms = train_df_sorted["TERM_CODE"].unique()

    split_point_idx = int(len(unique_terms) * 0.85)
    # Ensure validation set has at least one unique term if possible
    if len(unique_terms) > 1 and split_point_idx >= len(unique_terms):
        split_point_idx = len(unique_terms) - 1
    elif (
        len(unique_terms) <= 1
    ):  # If 0 or 1 terms, no meaningful split for distinct terms
        split_point_idx = 0

    validation_terms = unique_terms[split_point_idx:]
    if len(validation_terms) == 0:
        # Fallback to a simpler validation or training on full data if split produces empty val
        # For current purpose, ensure split is non-empty. If there are few terms, this could be an issue.
        # As per instructions, "latest train years held out", thus, if unique_terms are very few, val might be the last one.
        # This warning condition has been improved slightly to avoid error on empty slice if unique_terms is tiny.
        print(
            "Warning: Validation set has 0 terms. Reviewing split logic might be necessary."
        )

    X_train_model = train_df_sorted[
        ~train_df_sorted["TERM_CODE"].isin(validation_terms)
    ][features]
    y_train_model = train_df_sorted[
        ~train_df_sorted["TERM_CODE"].isin(validation_terms)
    ]["HIGH_ENROLLMENT"]

    X_val = train_df_sorted[train_df_sorted["TERM_CODE"].isin(validation_terms)][
        features
    ]
    y_val = train_df_sorted[train_df_sorted["TERM_CODE"].isin(validation_terms)][
        "HIGH_ENROLLMENT"
    ]

    print(f"\nTrain samples for model: {len(X_train_model)}")
    print(f"Validation samples: {len(X_val)}")
    if len(X_train_model) > 0:
        print(
            f"Terms used for training: {X_train_model['TERM_YEAR'].min()}/{X_train_model['TERM_SEASON'].min()} to {X_train_model['TERM_YEAR'].max()}/{X_train_model['TERM_SEASON'].max()}"
        )
    if len(X_val) > 0:
        print(
            f"Terms used for validation: {X_val['TERM_YEAR'].min()}/{X_val['TERM_SEASON'].min()} to {X_val['TERM_YEAR'].max()}/{X_val['TERM_SEASON'].max()}"
        )
    else:  # If validation set is empty, use entire dataset for F1 computation, and log warning.
        print(
            "Validation set is empty, will use training data for pseudo-validation metric report. This may lead to an over-optimistic F1 score."
        )
        X_val, y_val = (
            X_train_model,
            y_train_model,
        )  # Use training set for "validation" F1 calculation to avoid crash

    # Re-encode categorical features in the training and validation splits using the globally fitted label_encoders
    for col in categorical_features:
        if col in X_train_model.columns:
            # Re-apply transform (robust, even if the col's elements in this split were already transformed from 'str' to 'int' in previous create_features)
            X_train_model[col] = label_encoders[col].transform(
                X_train_model[col].astype(str)
            )
            X_val[col] = (
                X_val[col]
                .astype(str)
                .apply(
                    lambda x: (
                        label_encoders[col].transform([x])[0]
                        if x in label_encoders[col].classes_
                        else -1
                    )
                )
            )
        else:
            # Handle case where a feature might be missing in a split, e.g. a column with very low cardinality
            X_train_model[col] = -1
            X_val[col] = -1

    # --- Model Training ---
    lgb_clf = lgb.LGBMClassifier(objective="binary", metric="f1_macro", random_state=42)
    lgb_clf.fit(
        X_train_model,
        y_train_model,
        eval_set=[(X_val, y_val)],
        eval_metric="f1_macro",
        callbacks=[lgb.early_stopping(10, verbose=False)],
        feature_name=list(X_train_model.columns),
        categorical_feature=[
            f for f in categorical_features if f in X_train_model.columns
        ],
    )

    # --- Evaluation on validation set ---
    val_preds_proba = lgb_clf.predict_proba(X_val)[:, 1]
    val_preds = (val_preds_proba > 0.5).astype(int)

    macro_f1 = f1_score(y_val, val_preds, average="macro")
    print(f"\nMacro F1 on time-based validation set: {macro_f1:.4f}")

    # --- Prepare Test Data for Prediction ---
    # Using TEST_OFFERINGS_DIR for the base SUBJECT_OFFERED_SUMMARY.csv specific to test split
    test_df_raw = load_and_prepare_data(
        TEST_OFFERINGS_DIR, "/Users/USER/Documents/UNI/SS26/BEAVER/test", is_training=False
    )

    # Filter out any terms in test_df_raw that are older or equal to the latest train term.
    # This ensures only truly future terms are predicted, aligning with the time-series nature.
    latest_train_term = train_df["TERM_CODE"].max()
    test_df_raw = test_df_raw[test_df_raw["TERM_CODE"] > latest_train_term].reset_index(
        drop=True
    )

    if test_df_raw.empty:
        print(
            "No true 'future' terms found for prediction. Ensuring TEST_OFFERINGS_DIR contains terms strictly after training terms."
        )
        submission_df = pd.DataFrame(
            columns=["TERM_CODE", "SUBJECT_ID_SORT", "HIGH_ENROLLMENT"]
        )
        submission_df.to_csv(os.path.join(WORKING_DIR, "submission.csv"), index=False)
        print("Empty submission file created.")
        exit()

    # --- Feature Engineering for test data using training encoders ---
    test_df_processed, _, _ = create_features(
        test_df_raw.copy(), training_encoders=label_encoders
    )

    # Store original TERM_CODE and SUBJECT_ID_SORT for submission file
    submission_keys = test_df_processed[["TERM_CODE", "SUBJECT_ID_SORT"]].copy()

    # Align columns between training and test sets.
    # Missing columns in test (that exist in train) filled with a default value (e.g., 0 or -1 for categoricals).
    # Extra columns in test are ignored.
    for col in features:
        if col not in test_df_processed.columns:
            if col in categorical_features:
                test_df_processed[col] = -1  # Assign -1 for unseen categorical values
            else:
                test_df_processed[col] = 0  # Default for numeric

        # Ensure type consistency as best as possible
        if col in X_train_model.columns and col in test_df_processed.columns:
            if test_df_processed[col].dtype != X_train_model[col].dtype:
                try:
                    test_df_processed[col] = test_df_processed[col].astype(
                        X_train_model[col].dtype
                    )
                except ValueError:
                    # If direct conversion fails (e.g., text in a numeric column), impute or force-cast.
                    # Given fillna(0)/-1 is applied before, this mainly catches any other weirdness.
                    print(
                        f"Warning: Could not convert column {col} type from {test_df_processed[col].dtype} to {X_train_model[col].dtype} in test set. Attempting fillna(0) and retry."
                    )
                    if X_train_model[col].dtype in ["int64", "float64"]:
                        test_df_processed[col] = (
                            pd.to_numeric(test_df_processed[col], errors="coerce")
                            .fillna(0)
                            .astype(X_train_model[col].dtype)
                        )
                    else:  # Fallback to string, which for lightgbm will treat as categorical if encoded, otherwise will error
                        test_df_processed[col] = test_df_processed[col].astype(str)

    X_test = test_df_processed[features]

    # Predict on test data
    test_preds_proba = lgb_clf.predict_proba(X_test)[:, 1]
    test_preds = (test_preds_proba > 0.5).astype(int)

    # --- Create Submission File ---
    submission_df = pd.DataFrame(
        {
            "TERM_CODE": submission_keys["TERM_CODE"],
            "SUBJECT_ID_SORT": submission_keys["SUBJECT_ID_SORT"],
            "HIGH_ENROLLMENT": np.where(test_preds == 1, "Y", "N"),
        }
    )

    submission_df.to_csv(os.path.join(WORKING_DIR, "submission1.csv"), index=False)
    print(
        f"\nSubmission file created successfully at {os.path.join(WORKING_DIR, 'submission.csv')}"
    )
