import pandas as pd
import numpy as np
import os
import lightgbm as lgb
from pathlib import Path
from sklearn.metrics import f1_score

# Define data paths based on the problem description and typical Kaggle structure
PROJECT_ROOT = Path(__file__).resolve().parents[3]
INPUT_DIR = PROJECT_ROOT / "table_splits" / "train"
TEST_DATA_DIR = PROJECT_ROOT / "test"
GOLD_TRAIN_PATH = PROJECT_ROOT / "eval" / "gold_enrollment_train.csv"
WORKING_DIR = Path(__file__).resolve().parent / "working"

# Ensure the working directory exists
os.makedirs(WORKING_DIR, exist_ok=True)

# --- 1. Load Data ---
# Gold labels for training
df_train_labels = pd.read_csv(GOLD_TRAIN_PATH)

# Core course summary data, historical enrollment, and academic term information
df_summary = pd.read_csv(INPUT_DIR / "SUBJECT_OFFERED_SUMMARY.csv")
df_history = pd.read_csv(INPUT_DIR / "ENROLLMENT_HISTORY_FEATURES.csv")
df_academic_terms = pd.read_csv(INPUT_DIR / "ACADEMIC_TERMS.csv")

# Held-out test split (future terms)
df_test_summary = pd.read_csv(TEST_DATA_DIR / "SUBJECT_OFFERED_SUMMARY.csv")
df_test_history = pd.read_csv(TEST_DATA_DIR / "ENROLLMENT_HISTORY_FEATURES.csv")


# --- 2. Feature Engineering and Merging for Training Data ---
# Merge labels with course summary and historical features to form the full training dataset
train_data = pd.merge(
    df_train_labels, df_summary, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left"
)
train_data = pd.merge(
    train_data, df_history, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left"
)

# Add academic year and term start date for time-based splitting
train_data = pd.merge(
    train_data,
    df_academic_terms[["TERM_CODE", "ACADEMIC_YEAR", "TERM_START_DATE"]],
    on="TERM_CODE",
    how="left",
)
train_data["TERM_START_DATE"] = pd.to_datetime(train_data["TERM_START_DATE"])

# Define features and target
numerical_features = [
    "TOTAL_UNITS",
    "LECTURE_UNITS",
    "LAB_UNITS",
    "lag1_enrollment",
    "lag2_enrollment",
    "roll3_enrollment_mean",
]
# Filter for existence to avoid KeyError if features are not present in data
numerical_features = [col for col in numerical_features if col in train_data.columns]


categorical_features = [
    "CLUSTER_TYPE",
    "HGN_CODE",
    "OFFER_DEPT_CODE",
    "OFFER_SCHOOL_NAME",
]
# Ensure categorical features exist in data too
categorical_features = [
    col for col in categorical_features if col in train_data.columns
]

target_column = "HIGH_ENROLLMENT"

all_features = numerical_features + categorical_features

# --- Add missing indicator features for numerical columns (always created for robustness) ---
numerical_features_for_missing_indicators = [
    "lag1_enrollment",
    "lag2_enrollment",
    "roll3_enrollment_mean",
]
missing_indicator_features = []

for col in numerical_features_for_missing_indicators:
    # Ensure column exists before creating a missing indicator. If not, the feature will simply not be added.
    if col in train_data.columns:
        train_data[f"{col}_IS_MISSING"] = train_data[col].isna().astype(int)
        missing_indicator_features.append(f"{col}_IS_MISSING")

all_features.extend(missing_indicator_features)


# --- 3. Time-based Validation Split ---
unique_terms = (
    train_data[["TERM_CODE", "ACADEMIC_YEAR", "TERM_START_DATE"]]
    .drop_duplicates()
    .sort_values(["ACADEMIC_YEAR", "TERM_START_DATE"])
)

latest_train_academic_year = unique_terms["ACADEMIC_YEAR"].max()

train_terms = unique_terms[unique_terms["ACADEMIC_YEAR"] < latest_train_academic_year][
    "TERM_CODE"
].unique()
val_terms = unique_terms[unique_terms["ACADEMIC_YEAR"] == latest_train_academic_year][
    "TERM_CODE"
].unique()

X_train_split = train_data[train_data["TERM_CODE"].isin(train_terms)].copy()
X_val_split = train_data[train_data["TERM_CODE"].isin(val_terms)].copy()

y_train = X_train_split[target_column]
y_val = X_val_split[target_column]

X_train_split.drop(columns=[target_column], inplace=True)
X_val_split.drop(columns=[target_column], inplace=True)


# --- New Improvement: Frequency Encoding for selected categorical features ---
frequency_encoded_features = []
fe_cols = ["OFFER_DEPT_CODE", "OFFER_SCHOOL_NAME"]  # Features to frequency encode
fe_maps = {}  # To store frequency maps for consistency with test data

for col in fe_cols:
    if (
        col in categorical_features
    ):  # Only frequency encode if the original categorical feature exists
        # Calculate frequency counts from the X_train_split (training split data only)
        freq_map = X_train_split[col].value_counts().to_dict()
        fe_maps[col] = freq_map  # Store map for test set application

        # Apply frequency encoding to training, validation sets
        # Fill unseen categories in validation/test with 0 frequency
        X_train_split[f"{col}_FREQ"] = X_train_split[col].map(freq_map).fillna(0)
        X_val_split[f"{col}_FREQ"] = X_val_split[col].map(freq_map).fillna(0)

        frequency_encoded_features.append(f"{col}_FREQ")

# Add these new frequency features to numerical_features and all_features
numerical_features.extend(
    frequency_encoded_features
)  # Treat new freq features as numerical
all_features.extend(frequency_encoded_features)


# --- Apply imputation logic (medians and zeros) ---
zero_impute_cols = [
    col
    for col in numerical_features_for_missing_indicators
    if col in X_train_split.columns
]
# Define numerical features for median imputation (excluding those already zero-imputed and current FE features as they are filled by 0)
median_impute_cols = [
    col
    for col in numerical_features
    if col not in zero_impute_cols
    and col not in frequency_encoded_features
    and col in X_train_split.columns
]


# Impute historical enrollment with 0
for col in zero_impute_cols:
    X_train_split[col].fillna(0, inplace=True)
    X_val_split[col].fillna(0, inplace=True)

# Impute other numerical features with the median from the training set
median_values = {col: X_train_split[col].median() for col in median_impute_cols}
for col in median_impute_cols:
    X_train_split[col].fillna(median_values[col], inplace=True)
    X_val_split[col].fillna(median_values[col], inplace=True)


# Convert categorical features to 'category' dtype for LightGBM
for col in categorical_features:
    if col in X_train_split.columns:
        X_train_split[col] = X_train_split[col].astype("category")
        X_val_split[col] = X_val_split[col].astype("category")


# Filter feature sets
final_features_for_model = [f for f in all_features if f in X_train_split.columns]
X_train = X_train_split[final_features_for_model]
X_val = X_val_split[final_features_for_model]


# Make sure categorical_features used in LGBM are also in final_features_for_model
categorical_features_for_lgbm = [
    f for f in categorical_features if f in final_features_for_model
]


# --- 4. Model Training ---
lgbm = lgb.LGBMClassifier(
    objective="binary", metric="macro_f1", random_state=42, n_estimators=200
)
lgbm.fit(X_train, y_train, categorical_feature=categorical_features_for_lgbm)

# --- 5. Evaluate on Validation Set ---
val_preds = lgbm.predict(X_val)
macro_f1_validation = f1_score(y_val, val_preds, average="macro")
print(f"Validation Macro F1 Score: {macro_f1_validation}")

# --- 6. Prepare Test Data for Submission ---
submission_keys = (
    df_test_summary[["TERM_CODE", "SUBJECT_ID_SORT"]]
    .drop_duplicates()
    .copy()
)

X_test_submission = pd.merge(
    submission_keys, df_test_summary, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left"
)
X_test_submission = pd.merge(
    X_test_submission, df_test_history, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left"
)
X_test_submission = pd.merge(
    X_test_submission,
    df_academic_terms[["TERM_CODE", "ACADEMIC_YEAR", "TERM_START_DATE"]],
    on="TERM_CODE",
    how="left",
)

# --- Apply missing indicator creation for test data (consistent with training) ---
for col in numerical_features_for_missing_indicators:
    if col in X_test_submission.columns:
        X_test_submission[f"{col}_IS_MISSING"] = (
            X_test_submission[col].isna().astype(int)
        )

# --- Apply frequency encoding for test data (consistent with training using stored maps) ---
for col in fe_cols:
    if col in categorical_features:
        # Use stored frequency map (default to empty dict if map for some reason not found, .map will handle NaNs)
        freq_map_for_test = fe_maps.get(col, {})
        X_test_submission[f"{col}_FREQ"] = (
            X_test_submission[col].map(freq_map_for_test).fillna(0)
        )

# --- Apply imputation for test data (consistent with training using stored medians/zeros) ---
# Zero imputation for historical enrollment
for col in zero_impute_cols:
    if col in X_test_submission.columns:
        X_test_submission[col].fillna(0, inplace=True)

# Median imputation for other numerical features
for col in median_impute_cols:
    if col in X_test_submission.columns and col in median_values:
        X_test_submission[col].fillna(median_values[col], inplace=True)

# Convert categorical features (for test)
for col in categorical_features:
    if col in X_test_submission.columns:
        X_test_submission[col] = X_test_submission[col].astype("category")

# Final feature alignment for test data
# Add any columns present in final_features_for_model but missing in X_test_submission with 0
missing_cols_in_test_df = set(final_features_for_model) - set(
    X_test_submission.columns
)
for c in missing_cols_in_test_df:
    X_test_submission[c] = 0

# Ensure columns are in the same order as training data for LightGBM consistency
X_test_submission = X_test_submission[final_features_for_model]

test_preds = lgbm.predict(X_test_submission)

submission_df = submission_keys.copy()
submission_df["HIGH_ENROLLMENT"] = test_preds

submission_file_path = WORKING_DIR / "submission.csv"
submission_df.to_csv(submission_file_path, index=False)
print(
    f"Submission file generated at {submission_file_path} with {len(submission_df)} rows."
)
