# Technical Report: High Enrollment Prediction

## Introduction

This report details the development of a machine learning model to predict high course enrollment for academic offerings. The task involves binary classification: determining if a course offering will experience "high enrollment" (top quartile within its department and term). The primary evaluation metric is the Macro F1 score, reported on a time-based validation split. A LightGBM classifier was selected for its performance and efficiency with tabular data.

## Preprocessing

### Data Loading and Merging
The following datasets were utilized:
*   `gold_enrollment_train.csv`: Contains training labels (`HIGH_ENROLLMENT`).
*   `SUBJECT_OFFERED_SUMMARY.csv`: Provides core course attributes.
*   `ENROLLMENT_HISTORY_FEATURES.csv`: Offers historical enrollment data.
*   `ACADEMIC_TERMS.csv`: Supplies academic year and term start dates.
*   `SUBJECT_OFFERED.csv`: Attempted to source course capacity (`ENRL_MAX_CRSE_CAP` or `MAX_ENROLLMENT`).

All datasets were merged onto `gold_enrollment_train.csv` using `TERM_CODE` and `SUBJECT_ID_SORT`.

### Feature Engineering
Initially, numerical features included `TOTAL_UNITS`, `LECTURE_UNITS`, `LAB_UNITS`, `lag1_enrollment`, `lag2_enrollment`, and `roll3_enrollment_mean`. Categorical features comprised `CLUSTER_TYPE`, `HGN_CODE`, `OFFER_DEPT_CODE`, and `OFFER_SCHOOL_NAME`.

Subsequent feature engineering steps included:
*   **Missing Indicators:** Binary `_IS_MISSING` flags were generated for numerical features prone to missing values, specifically `lag1_enrollment`, `lag2_enrollment`, and `roll3_enrollment_mean`, to signal the presence of imputed values to the model. An attempt was made to add missing indicators for `ENRL_MAX_CRSE_CAP` as well, but this feature was not found in the provided data.
*   **Course Capacity:** An effort was made to extract `ENRL_MAX_CRSE_CAP` or `MAX_ENROLLMENT` from `SUBJECT_OFFERED.csv` by summing capacity per `(TERM_CODE, SUBJECT_ID_SORT)`. However, this feature was consistently absent from the provided data and thus excluded.
*   **Frequency Encoding:** For high-cardinality categorical features (`OFFER_DEPT_CODE`, `OFFER_SCHOOL_NAME`), new numerical features were created representing the frequency of each category in the training set.
*   **Temporal Features:** `MONTH_OF_TERM_START` and `QUARTER_OF_TERM_START` were extracted from `TERM_START_DATE` to capture seasonality. Missing dates were imputed with -1.

### Imputation Strategy
The imputation strategy for numerical features evolved:
1.  **Initial:** All missing numerical features were imputed with the median from the training set.
2.  **Refinement:** After creating `_IS_MISSING` flags, `lag1_enrollment`, `lag2_enrollment`, and `roll3_enrollment_mean` were imputed with `0`, to signify a lack of prior enrollment data. Other numerical features (`TOTAL_UNITS`, `LECTURE_UNITS`, `LAB_UNITS`) continued to be imputed with their training-derived medians. This distinct approach aimed to provide clearer signals to the model. All imputation values (medians, zeros) were derived exclusively from the training split to prevent data leakage.
3.  **Categorical Handling:** Categorical features were directly converted to LightGBM's `category` dtype, which efficiently handles them internally.

### Time-based Validation
A time-based validation split was performed by holding out the most recent academic year present in the training labels as the validation set. All earlier academic years constituted the training set. This simulates real-world prediction scenarios for future terms.

## Modeling Methods

### Model Selection
A LightGBM Classifier (`lgb.LGBMClassifier`) was chosen. LightGBM is an ensemble tree-based algorithm known for its speed and efficiency, particularly with large datasets and categorical features.

### Hyperparameters
The model was configured with the following parameters:
*   `objective="binary"`: For binary classification.
*   `metric="macro_f1"`: To align with the evaluation metric.
*   `random_state=42`: For reproducibility.
*   `n_estimators=200`: The number of boosting rounds.

## Results Discussion

The model's performance was evaluated using the Macro F1 score on the time-based validation set. The progression of scores with each major enhancement is summarized below:

*   **Initial Baseline (Median Imputation):** Macro F1: 0.5978
*   **Adding Missing Indicators:** Macro F1: 0.5989 (a slight improvement, indicating the utility of missingness as a feature).
*   **Refined Imputation (Zero for Lagged, Median for Others):** This change, after addressing an implementation bug, also yielded Macro F1: 0.5989, demonstrating consistency but no further gain beyond missing indicators.
*   **Attempted `ENRL_MAX_CRSE_CAP` Feature:** This feature was not found in the provided data. Macro F1: 0.5989 (no change).
*   **Frequency Encoding for Categorical Features:** Macro F1: **0.6008** (the highest score achieved, indicating that frequency information significantly improved the model's understanding of categorical patterns).
*   **Date-derived Temporal Features (Month, Quarter):** Macro F1: 0.5989 (a slight decrease or stagnation compared to frequency encoding, suggesting these features did not add substantial predictive power in this iteration, or interacted negatively with other features).

The peak performance was observed after implementing frequency encoding, achieving a Macro F1 score of 0.6008. The final solution consistently handles the absence of strictly "future terms" by generating predictions for all unlabeled entries in the summary data.

## Future Work

*   **Advanced Feature Engineering:** Explore interaction terms, target encoding (with robust cross-validation to prevent leakage), or more sophisticated temporal features (e.g., term-specific trends, year-over-year growth rates).
*   **Hyperparameter Optimization:** Conduct a more extensive hyperparameter search for LightGBM using techniques like GridSearchCV or RandomizedSearchCV.
*   **Ensemble Methods:** Combine predictions from multiple models (e.g., stacking, blending) to potentially improve robustness and performance.
*   **Class Imbalance:** Investigate techniques to explicitly address class imbalance, such as SMOTE, given that the positive class (high enrollment) constitutes a small fraction (approx. 8.2%) of the data. While Macro F1 already accounts for imbalance, explicit handling might yield further gains.
*   **External Data:** If available, integrate external data sources that might influence course enrollment (e.g., faculty reputation, labor market demand for specific skills).