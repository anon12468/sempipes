import pandas as pd
import numpy as np
import lightgbm as lgb
from sklearn.metrics import f1_score
from sklearn.preprocessing import LabelEncoder
import os
import warnings

warnings.filterwarnings("ignore")

# Configuration Block
# Adjusting data paths based on the observed file structure under './input/'
# The task description gives 'table_splits/train' directly. Given the 'input/' structure,
# the effective paths for files in 'table_splits/train' and 'table_splits/test' are under './input/'.
TRAIN_DATA_DIR = "/Users/USER/Documents/UNI/SS26/BEAVER/table_splits/train"
TEST_DATA_DIR = "/Users/USER/Documents/UNI/SS26/BEAVER/test"  # Assuming __TEST_DATA_DIR__ resolves to './input/table_splits/test'

# --- Data Loading ---

# Load global datasets that apply to both train and test terms
df_enroll_history = pd.read_csv("/Users/USER/Documents/UNI/SS26/BEAVER/table_splits/train/ENROLLMENT_HISTORY_FEATURES.csv")
df_academic_terms = pd.read_csv("/Users/USER/Documents/UNI/SS26/BEAVER/table_splits/train/ACADEMIC_TERMS.csv")

# Load train-specific datasets
df_gold_train = pd.read_csv("/Users/USER/Documents/UNI/SS26/BEAVER/eval/gold_enrollment_train.csv")
df_subject_offered_summary_train = pd.read_csv(
    os.path.join(TRAIN_DATA_DIR, "SUBJECT_OFFERED_SUMMARY.csv")
)

# --- Feature Engineering and Merging for Training Data ---

# Start with subject offerings for train
df_train = df_subject_offered_summary_train.copy()

# Merge with gold labels to get the target variable 'HIGH_ENROLLMENT'
df_train = pd.merge(
    df_train, df_gold_train, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left"
)

# Merge historical enrollment features
df_train = pd.merge(
    df_train, df_enroll_history, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left"
)

# Merge academic year information using 'TERM_CODE'
df_train = pd.merge(
    df_train,
    df_academic_terms[["TERM_CODE", "ACADEMIC_YEAR"]],
    on="TERM_CODE",
    how="left",
)

# Drop rows where HIGH_ENROLLMENT is NaN, as these courses are not labeled for the prediction task.
df_train.dropna(subset=["HIGH_ENROLLMENT"], inplace=True)
df_train["HIGH_ENROLLMENT"] = df_train["HIGH_ENROLLMENT"].map({"Y": 1, "N": 0})

# --- Feature Definition and Preprocessing ---
numerical_features = [
    "lag1_enrollment",
    "lag2_enrollment",
    "roll3_enrollment_mean",
    "TOTAL_UNITS",
    "LECTURE_UNITS",
    "LAB_UNITS",
    "PREPARATION_UNITS",
]
# 'IS_VARIABLE_UNITS' is a boolean-like numerical feature (0/1)
if "IS_VARIABLE_UNITS" in df_train.columns:
    numerical_features.append("IS_VARIABLE_UNITS")

# Categorical features. ACADEMIC_YEAR is treated as categorical to capture year-specific effects.
categorical_features = [
    "OFFER_DEPT_CODE",
    "CLUSTER_TYPE",
    "HGN_CODE",
    "ACADEMIC_YEAR",
    "SUBJECT_TITLE",
    "MASTER_SUBJECT_ID_SORT",
]

# Ensure all defined features exist in the training dataframe
numerical_features = [f for f in numerical_features if f in df_train.columns]
categorical_features = [f for f in categorical_features if f in df_train.columns]

# Impute NaNs for numerical features with 0
for col in numerical_features:
    df_train[col] = df_train[col].fillna(0)

# Impute NaNs for categorical features with 'UNKNOWN' and convert to string type
for col in categorical_features:
    df_train[col] = df_train[col].astype(str).fillna("UNKNOWN")

# Combine all selected features for the model
features_to_use = numerical_features + categorical_features
X = df_train[features_to_use]
y = df_train["HIGH_ENROLLMENT"]

# Apply Label Encoding for LightGBM's native categorical feature handling.
# Store encoders to ensure consistent transformation of the test set.
label_encoders = {}
for col in categorical_features:
    le = LabelEncoder()
    # Fit LabelEncoder on the full range of values seen across both training and potential test sets
    # This prevents errors if test data contains categories not seen in training.
    # However, to avoid 'data leakage' from test set during train LE fitting, we will apply this robustness for test set preparation,
    # but for X (training features) fit only on X.
    # For now, fit on `X` and deal with test categories later in the test preprocessing step.
    X[col] = le.fit_transform(X[col])
    label_encoders[col] = le

# --- Time-based Validation Split ---
# Use the actual academic year from `df_train` (before its column `ACADEMIC_YEAR` in `X` was label-encoded)
# to define the validation split.
academic_years_in_data = df_train["ACADEMIC_YEAR"].unique()
latest_academic_year = academic_years_in_data.max()

# Split X and y into training and validation sets based on the academic year
X_train_model = X[df_train["ACADEMIC_YEAR"] != latest_academic_year]
y_train_model = y[df_train["ACADEMIC_YEAR"] != latest_academic_year]
X_val = X[df_train["ACADEMIC_YEAR"] == latest_academic_year]
y_val = y[df_train["ACADEMIC_YEAR"] == latest_academic_year]

print(
    f"Academic years used for model training: {sorted(academic_years_in_data[academic_years_in_data != latest_academic_year])}"
)
print(f"Academic year held out for validation: {latest_academic_year}")


# --- Model Training ---
# Initialize LightGBM Classifier with objective for binary classification and f1 as metric.
lgb_clf = lgb.LGBMClassifier(
    objective="binary", metric="f1", random_state=42, n_jobs=-1
)

# Train the model, explicitly indicating which features are categorical by their index.
categorical_feature_indices = [
    X_train_model.columns.get_loc(col)
    for col in categorical_features
    if col in X_train_model.columns
]
lgb_clf.fit(
    X_train_model, y_train_model, categorical_feature=categorical_feature_indices
)

# --- Evaluation on Validation Set ---
y_pred_val = lgb_clf.predict(X_val)
macro_f1 = f1_score(y_val, y_pred_val, average="macro")
print(
    f"Macro F1 Score on validation set (academic year {latest_academic_year}): {macro_f1:.4f}"
)

# --- Test Data Prediction ---

# Load test-specific datasets
df_subject_offered_summary_test = pd.read_csv(
    os.path.join(TEST_DATA_DIR, "SUBJECT_OFFERED_SUMMARY.csv")
)

# Store original columns for the final submission file
df_test_submission_cols = df_subject_offered_summary_test[
    ["TERM_CODE", "SUBJECT_ID_SORT"]
].copy()

# Merge historical enrollment features and academic year info for the test set
df_test = pd.merge(
    df_subject_offered_summary_test,
    df_enroll_history,
    on=["TERM_CODE", "SUBJECT_ID_SORT"],
    how="left",
)
df_test = pd.merge(
    df_test,
    df_academic_terms[["TERM_CODE", "ACADEMIC_YEAR"]],
    on="TERM_CODE",
    how="left",
)

# Prepare test features in the same way as training
X_test = df_test[features_to_use].copy()

# Impute numerical NaNs with 0
for col in numerical_features:
    if col in X_test.columns:
        X_test[col] = X_test[col].fillna(0)
    else:  # If a numerical feature is entirely missing from test set, create and fill with 0
        X_test[col] = 0

# Impute categorical NaNs with 'UNKNOWN' and convert to string
for col in categorical_features:
    if col in X_test.columns:
        X_test[col] = X_test[col].astype(str).fillna("UNKNOWN")
    else:  # If a categorical feature is entirely missing from test set, create and fill with 'UNKNOWN'
        X_test[col] = "UNKNOWN"

# Apply Label Encoding using updated LabelEncoders (fitted on a union of train and test values).
# This ensures consistency and handles any new categories gracefully for the test set.
for col in categorical_features:
    if col in X_test.columns:
        # Create a LabelEncoder for this column and fit it on unique values from both train and test.
        # This prevents 'unknown label' errors if test has new categories.
        # This operation is safe as it doesn't involve target labels.
        full_categorical_values = pd.concat(
            [
                df_train[col].astype(str).fillna("UNKNOWN"),
                df_test[col].astype(str).fillna("UNKNOWN"),
            ]
        ).unique()
        temp_le = LabelEncoder()
        temp_le.fit(full_categorical_values)
        X_test[col] = temp_le.transform(X_test[col])

# Ensure feature columns in X_test are in the same order as the trained model (X_train_model)
X_test = X_test[X_train_model.columns]

# Predict on the prepared test data
test_predictions_encoded = lgb_clf.predict(X_test)
df_test_submission_cols["HIGH_ENROLLMENT"] = test_predictions_encoded

# Map the numerical predictions (0/1) back to 'N'/'Y' as required for submission
df_test_submission_cols["HIGH_ENROLLMENT"] = df_test_submission_cols[
    "HIGH_ENROLLMENT"
].map({1: "Y", 0: "N"})

# Save the submission file to the working directory
submission = df_test_submission_cols[
    ["TERM_CODE", "SUBJECT_ID_SORT", "HIGH_ENROLLMENT"]
]
submission.to_csv("/Users/USER/Documents/UNI/SS26/BEAVER/AIDE/logs/2-watchful-brilliant-mouse/submission.csv", index=False)

print("Submission file generated successfully at ./working/submission.csv")
