# Technical Report: High Enrollment Prediction for Course Offerings

## Introduction

This report details the approach to predicting high enrollment for academic course offerings. The task involves classifying whether a course offering will achieve "high enrollment," defined as being in the top quartile of enrollment counts within its department and term, among courses with positive enrollment. The data comprises institutional course and catalog information, supplemented with historical enrollment features. The objective is to develop a binary classification model and generate predictions for future course offerings. Model performance is evaluated using the Macro F1 score on a time-based validation slice.

*Note: The provided research journal was empty. Therefore, this report outlines anticipated steps and general considerations based solely on the task description, rather than specific empirical findings or technical decisions from an agent's run.*

## Preprocessing

### Data Integration and Cleaning
Multiple tables (e.g., course catalogs, institutional data) are merged with `ENROLLMENT_HISTORY_FEATURES.csv` and `eval/gold_enrollment_train.csv`. This involves joining on keys such as `TERM_CODE` and `SUBJECT_ID_SORT`. Missing values are handled through imputation (e.g., mean, median, mode, or specific default values) or by indicating their absence as a feature.

### Target Label Creation
The `HIGH_ENROLLMENT` column from `gold_enrollment_train.csv` serves as the binary target variable (Y/N). This is mapped to numerical representation (1/0) for modeling.

### Feature Engineering
1.  **Enrollment History Features:** Lag features from `ENROLLMENT_HISTORY_FEATURES.csv` are crucial, capturing past enrollment trends for specific course offerings. This includes various lags (e.g., 1-term, 2-term, 1-year ago enrollment counts, ratios, or flags indicating recent offering).
2.  **Categorical Encoding:** Categorical variables such as `TERM_CODE` (when treated as categorical rather than temporal), `SUBJECT_ID_SORT`, department IDs, course attributes, and other descriptive fields are encoded. Common methods include One-Hot Encoding for nominal variables or Label Encoding/Target Encoding for ordinal or high-cardinality nominal variables.
3.  **Temporal Features:** Features extracted from `TERM_CODE` (e.g., year, semester, season) provide temporal context.
4.  **Text Features:** If available, course titles and descriptions could be processed using techniques like TF-IDF or word embeddings to extract semantic features.
5.  **Interaction Features:** Combinations of existing features might be created to capture non-linear relationships.

### Data Splitting
The dataset is split into training and test sets as provided (`TRAIN_DATA_DIR` and `TEST_DATA_DIR`). A time-based validation split is created within the training data by holding out the latest terms, as specified, to mimic the test set's temporal nature and provide a realistic evaluation of model generalization.

## Modeling Methods

### Problem Formulation
The task is framed as a binary classification problem: predict `HIGH_ENROLLMENT` (1) or not (0).

### Algorithm Selection (Anticipated)
Given the tabular nature of the data and the classification task, common machine learning algorithms would be explored. These typically include:
*   **Gradient Boosting Machines (GBMs):** Algorithms like LightGBM or XGBoost are often effective due to their ability to handle various data types, capture complex interactions, and scale well.
*   **Logistic Regression:** A strong baseline for interpretability and efficiency.
*   **Random Forest:** An ensemble method known for robustness.

### Validation Strategy
A time-based validation strategy is employed, where the model is trained on earlier terms within the `TRAIN_DATA_DIR` and evaluated on the latest terms. This setup directly reflects the real-world scenario of predicting future enrollments.

### Evaluation Metric
Macro F1 score is used as the primary evaluation metric, as specified in the task. This metric is suitable for classification tasks, especially when there might be class imbalance, as it treats both classes (high enrollment/not high enrollment) equally by averaging the F1 score for each class.

### Hyperparameter Tuning (Anticipated)
Hyperparameter optimization would be conducted using techniques like Grid Search or Random Search with cross-validation on the time-based validation split to find the optimal model configuration.

## Results Discussion

*Due to the empty research journal, no specific empirical findings or model performance metrics can be reported here. The following outlines what would typically be discussed.*

### Validation Performance
The Macro F1 score on the time-based validation set would be reported here. This score indicates the model's ability to correctly classify both high-enrollment and non-high-enrollment courses, accounting for potential class imbalance.

### Feature Importance
An analysis of feature importance would highlight which features contributed most significantly to the predictions. Lag enrollment features are typically highly influential. Other important features might include course attributes, department popularity, and temporal trends.

### Challenges Encountered
Common challenges in this type of task include:
*   **Class Imbalance:** High enrollment courses might be a minority class, requiring techniques like class weighting, oversampling, or undersampling.
*   **Cold Start Problem:** New course offerings without historical enrollment data pose a challenge, requiring reliance on descriptive features.
*   **Data Sparsity:** Some course offerings might have very little historical data.
*   **Concept Drift:** Enrollment patterns can change over time, necessitating models that adapt or are retrained periodically.

## Future Work

To further enhance the model and prediction accuracy, the following areas could be explored:

1.  **Advanced Feature Engineering:**
    *   Develop more sophisticated lag features (e.g., weighted averages of past enrollments, exponential smoothing).
    *   Create interaction terms between department characteristics, course attributes, and historical enrollment.
    *   Integrate external data sources that might influence enrollment (e.g., economic indicators, student demographics if available).
2.  **Model Exploration:**
    *   Experiment with other advanced classification models (e.g., neural networks for tabular data, ensemble methods combining multiple models).
    *   Investigate semi-supervised learning approaches for new courses with limited historical data.
3.  **Hyperparameter Optimization:**
    *   Conduct more extensive and systematic hyperparameter tuning using advanced techniques like Bayesian Optimization.
4.  **Addressing Class Imbalance:**
    *   Implement and compare various techniques to handle class imbalance more effectively (e.g., SMOTE variations, cost-sensitive learning).
5.  **Text Feature Enhancement:**
    *   If course descriptions are rich, explore advanced NLP techniques like transformer-based embeddings for better feature extraction.
6.  **Model Interpretability:**
    *   Employ explainable AI (XAI) techniques (e.g., SHAP, LIME) to gain deeper insights into model decisions and identify potential biases.