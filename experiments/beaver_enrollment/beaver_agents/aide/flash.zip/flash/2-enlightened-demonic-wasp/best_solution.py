import pandas as pd
import re
from collections import defaultdict
import numpy as np
import nltk
from nltk.corpus import stopwords
import os

# Ensure NLTK resources are available
try:
    stopwords.words("english")
except LookupError:
    nltk.download("stopwords")

# --- Configuration ---
MAX_CANDIDATE_PAIRS = 2_000_000
# Generate slightly more candidates to ensure we can hit 2M after uniqueness/sorting
# This factor is chosen to be small enough not to violate the "no building huge list then truncating" constraint
TARGET_CANDIDATES_TO_COLLECT = int(
    MAX_CANDIDATE_PAIRS * 1.10
)  # Increased buffer slightly

# Parameters for blocking to manage bucket sizes and pair generation
# These are chosen with the full ~2M record dataset in mind.
# For the smaller sample_data, they might result in fewer than 2M candidates, which is expected.
WINDOW_SIZE = 250  # Keep window size for O(k*N) feasibility, rely on more keys
COMMON_TOKEN_THRESHOLD = 0.1  # Filter out tokens appearing in more than 10% of records

# --- Preprocessing Functions ---
stop_words = set(stopwords.words("english"))


def clean_text(text):
    """Cleans text by lowercasing, removing punctuation, and normalizing whitespace."""
    if pd.isna(text):
        return ""
    text = str(text).lower()
    text = re.sub(r"[^a-z0-9\s]", "", text)  # Remove punctuation and special characters
    text = re.sub(r"\s+", " ", text).strip()  # Normalize whitespace
    return text


def get_tokens(text):
    """Extracts significant tokens from cleaned text, filtering stop words and short tokens."""
    tokens = [
        token for token in text.split() if token not in stop_words and len(token) > 1
    ]
    return tokens


def normalize_brand(brand):
    """Normalizes brand names to a canonical form."""
    if pd.isna(brand):
        return ""
    brand = str(brand).lower()
    brand = re.sub(r"[^a-z0-9]", "", brand)
    # Common brand variations
    if "sandisk" in brand:
        return "sandisk"
    if "sony" in brand:
        return "sony"
    if "kingston" in brand:
        return "kingston"
    if "samsung" in brand:
        return "samsung"
    if "toshiba" in brand:  # Added more common brands
        return "toshiba"
    if "adata" in brand:
        return "adata"
    if "lexar" in brand:
        return "lexar"
    if "transcend" in brand:
        return "transcend"
    return brand


# --- Main Processing ---

# Load X2.csv
df = pd.read_csv("./input/X2.csv")
# Sort by ID to ensure consistent (lid < rid) pairing and deterministic output
df = df.sort_values(by="id").reset_index(drop=True)

# Preprocess columns in a vectorized way first to speed up feature extraction
df["cleaned_name"] = df["name"].apply(clean_text)
df["name_tokens"] = df["cleaned_name"].apply(get_tokens)
df["cleaned_description"] = df["description"].apply(clean_text)
df["desc_tokens"] = df["cleaned_description"].apply(get_tokens)
df["normalized_brand"] = df["brand"].apply(normalize_brand)
df["cleaned_category"] = df["category"].apply(clean_text)

# Generate blocking keys for each record using preprocessed columns
all_blocking_keys = []
for idx, row in df.iterrows():
    keys = set()

    brand = row["normalized_brand"]
    if brand:
        keys.add(f"BRAND_{brand}")

    name_tokens = row["name_tokens"]
    if name_tokens:
        keys.add(f"NAME_FIRST_{name_tokens[0]}")
        # Add up to 5 tokens from name
        for token in name_tokens[1:6]:
            keys.add(f"NAME_TOKEN_{token}")
        # Add 2-grams from name (first 3 bigrams)
        for i in range(len(name_tokens) - 1):
            if i >= 3:  # Limit bigrams to avoid too many keys
                break
            keys.add(f"NAME_BIGRAM_{name_tokens[i]}_{name_tokens[i+1]}")

    desc_tokens = row["desc_tokens"]
    if desc_tokens:
        keys.add(f"DESC_FIRST_{desc_tokens[0]}")
        # Add up to 3 tokens from description
        for token in desc_tokens[1:4]:
            keys.add(f"DESC_TOKEN_{token}")

    category = row["cleaned_category"]
    # Filter out common, less discriminative category values
    if category and category not in [
        "pagina",
        "home",
        "startseite",
        "samsung",
        "startsida",
        "online",
        "shop",
        "elektronik",
        "zubehör",
    ]:  # Added more generic categories
        keys.add(f"CATEGORY_{category}")

    # --- New specific extractions using regex ---
    text_to_search = row["cleaned_name"] + " " + row["cleaned_description"]

    # Capacity (e.g., 16GB, 32 Go, 128 MB)
    # Regex: find digits followed by common unit abbreviations
    capacity_matches = re.findall(
        r"(\d+)\s*(gb|mb|tb|go|g)\b", text_to_search, re.IGNORECASE
    )
    for val, unit in capacity_matches:
        normalized_unit = unit.lower().replace("go", "gb").replace("g", "gb")
        keys.add(f"CAPACITY_{val}{normalized_unit}")
        if brand:  # Combined key: brand + capacity
            keys.add(f"BRAND_CAPACITY_{brand}_{val}{normalized_unit}")

    # Speed Class/Type (e.g., Class 10, UHS-I, U1)
    # Regex: find patterns like "class N", "UHS-X", "U1", "U3"
    speed_matches = re.findall(
        r"(class\s*\d+|uhs-[ivx]+|u\d)\b", text_to_search, re.IGNORECASE
    )
    for match in speed_matches:
        keys.add(f"SPEED_{match.lower().replace(' ', '')}")

    # Form Factor/Type (e.g., SD, microSD, USB, flash drive)
    # Regex: find common storage device types
    type_matches = re.findall(
        r"\b(sd|sdhc|sdxc|microsd|microsdhc|microsdxc|usb|flash\s*drive|memory\s*card)\b",
        text_to_search,
        re.IGNORECASE,
    )
    for match in type_matches:
        keys.add(f"TYPE_{match.lower().replace(' ', '')}")

    # Model numbers (alphanumeric sequences, at least 4 chars, containing both letters and numbers)
    # This regex looks for sequences with at least one letter and one digit, common in product IDs
    model_matches = re.findall(
        r"\b(?:[a-z0-9]*[a-z][a-z0-9]*\d[a-z0-9]*|[a-z0-9]*\d[a-z0-9]*[a-z][a-z0-9]*)\b",
        text_to_search,
        re.IGNORECASE,
    )
    for match in model_matches:
        # Filter by length to avoid generic words or very long codes
        if 4 <= len(match) <= 15:  # Reasonable length for model numbers
            keys.add(f"MODEL_{match.lower()}")

    all_blocking_keys.append(list(keys))
df["blocking_keys"] = all_blocking_keys


# Build inverted index: map each blocking key to a sorted list of record IDs
inverted_index = defaultdict(list)
for _, row in df.iterrows():
    record_id = row["id"]
    for key in row["blocking_keys"]:
        inverted_index[key].append(record_id)

# Filter out extremely common keys to prevent huge buckets and manage memory/runtime
num_records = len(df)
filtered_inverted_index = {}  # Use dict for sorting
for key, ids in inverted_index.items():
    # Only use keys that appear in less than COMMON_TOKEN_THRESHOLD of records
    if len(ids) / num_records < COMMON_TOKEN_THRESHOLD:
        # Ensure IDs are unique and sorted within each posting list
        filtered_inverted_index[key] = sorted(list(set(ids)))

# Sort keys by posting list length (least frequent first) to prioritize more specific keys
# This helps in generating higher quality candidates earlier if we stop generation at a limit
sorted_keys = sorted(
    filtered_inverted_index.keys(), key=lambda k: len(filtered_inverted_index[k])
)

# Candidate generation
candidate_pairs = set()
stop_generation = False  # Flag to break out of nested loops

# Iterate through the filtered and sorted inverted index
for key in sorted_keys:
    posting_list = filtered_inverted_index[key]
    k = len(posting_list)

    if k <= 1:  # No pairs possible from a list with 0 or 1 element
        continue

    # Uniformly apply windowed comparison strategy (O(k * WINDOW_SIZE) work)
    for i in range(k):
        id1 = posting_list[i]
        # Compare id1 with records in a fixed-size window after it in the sorted list
        for j in range(i + 1, min(k, i + 1 + WINDOW_SIZE)):
            id2 = posting_list[j]
            candidate_pairs.add(tuple(sorted((id1, id2))))
            if len(candidate_pairs) >= TARGET_CANDIDATES_TO_COLLECT:
                stop_generation = True
                break
        if stop_generation:
            break
    if stop_generation:
        break  # Break from outer loop if target reached

# Finalize candidate pairs
candidates_df = pd.DataFrame(list(candidate_pairs), columns=["lid", "rid"])
# Sort candidates for deterministic output and to enable consistent truncation
candidates_df = candidates_df.sort_values(by=["lid", "rid"]).reset_index(drop=True)

# Truncate to exactly MAX_CANDIDATE_PAIRS
if len(candidates_df) > MAX_CANDIDATE_PAIRS:
    candidates_df = candidates_df.head(MAX_CANDIDATE_PAIRS)
elif len(candidates_df) < MAX_CANDIDATE_PAIRS:
    # This warning is expected for the small sample_data as it cannot generate 2M pairs
    print(
        f"Warning: Generated {len(candidates_df)} candidates, less than target {MAX_CANDIDATE_PAIRS}."
    )
    print(
        "This is expected for the small sample dataset. For the full dataset, parameters would be tuned to reach 2M."
    )

# Save output.csv
output_path = "./working/output.csv"
candidates_df.to_csv(output_path, index=False)

# --- Evaluation ---
# Load ground truth (Z2.csv) for evaluation
ground_truth_df = pd.read_csv("./input/Z2.csv")
# Convert ground truth to a set of tuples for efficient lookup
ground_truth_pairs = set(tuple(row) for row in ground_truth_df[["lid", "rid"]].values)

# Calculate recall
matched_pairs = 0
# Iterate through the generated candidate pairs and check against ground truth
for _, row in candidates_df.iterrows():
    pair = tuple(row[["lid", "rid"]].values)
    if pair in ground_truth_pairs:
        matched_pairs += 1

recall = matched_pairs / len(ground_truth_pairs)
print(f"Recall: {recall:.4f}")
