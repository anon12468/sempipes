# Technical Report: Entity Resolution Blocking for Electronic Products

## Introduction

This report details an iterative approach to implement an entity resolution blocking strategy for the X2 electronic products dataset. The primary goal is to generate exactly 2,000,000 candidate pairs for potential duplicates, maximizing recall while strictly adhering to feasibility constraints, particularly avoiding O(k^2) operations within any blocking bucket. The development process involved refining preprocessing techniques, enhancing blocking key generation, and tuning blocking parameters through multiple iterations, evaluated against the Z2.csv ground truth on a sample dataset.

## Preprocessing

Initial preprocessing focused on standard text normalization and tokenization:
*   **Text Cleaning**: All text fields (`name`, `brand`, `description`, `category`) were converted to lowercase, punctuation and special