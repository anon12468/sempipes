# Technical Report: Predicting High Course Enrollment

## Introduction

This report summarises the methods and findings for predicting whether a university course will have high enrollment. The task is a binary classification problem where "high enrollment" is defined as being in the top quartile of enrollment figures for a given department and academic term. The primary evaluation metric is the macro F1 score, assessed using a time-based validation strategy that holds out the most recent academic year of data. The final model leverages a LightGBM classifier with extensive feature engineering to achieve strong predictive performance.

## Preprocessing

A unified dataset was created by merging several data sources: gold standard labels, subject summary information, historical enrollment features, and academic term details. The following preprocessing and feature engineering steps were applied.

### Data Cleaning and Imputation
- The target variable `HIGH_ENROLLMENT` was encoded from 'Y'/'N' to a binary 1/0 format.
- Missing numerical values, particularly in historical enrollment lag features, were imputed with `-1`. This allows tree-based models to treat missing history as a distinct category.
- Missing categorical values were imputed with the string `"missing"`.

### Feature Engineering
The primary driver of model performance was feature engineering. The following features were created to provide the model with temporal, contextual, and relative performance signals:

- **Temporal Features**: The `ACADEMIC_YEAR` and `TERM_SEASON` (e.g., 'FA', 'SP') were extracted from the `TERM_CODE`. The academic year served as both a trend feature and the key for the time-based validation split.
- **Course Level**: A categorical feature, `COURSE_LEVEL`, was created by extracting the numeric component of the course ID and binning it into academic tiers (e.g., 100-level, 200-level). This captures the intrinsic difference in expected size between introductory and advanced courses.
- **Term-Level Workload**: `dept_course_count_term` and `faculty_course_count_term` were engineered to quantify the number of courses offered by each department and faculty member per term, acting as a proxy for operational scale.
- **Relative Historical Performance**: As the target is defined relative to departmental peers, features were created to model this relationship directly.
  - `lag1_dept_rank_pct`: The percentile rank of a course's enrollment in the prior term, calculated relative to other courses in the same department and term. This proved to be a highly predictive feature.
  - `lag1_enrollment_vs_dept_avg`: The absolute difference between a course's prior term enrollment and the departmental average for that term.

## Modelling Methods

### Model Selection
An initial baseline was established with a Random Forest classifier. However, the final and best-performing model was a LightGBM (LGBM) classifier. LGBM was chosen for its efficiency, native handling of categorical features, and high performance on structured data. The model was trained with robust default hyperparameters and an early stopping mechanism to prevent overfitting.

### Validation Strategy
A strict time-based validation split was employed to simulate a real-world forecasting scenario. The dataset was divided chronologically by `ACADEMIC_YEAR`. The final year was held out as the validation set, while all preceding years were used for training. This ensures the model is evaluated on its ability to generalize to a future, unseen time period.

## Results Discussion

The iterative development process demonstrated that feature engineering was the most significant factor in improving model performance. The LightGBM model consistently outperformed the initial Random Forest baseline.

| Model / Feature Set                                      | Validation Macro F1 |
| -------------------------------------------------------- | ------------------- |
| Baseline (Random Forest)                                 | 0.7623              |
| LightGBM with basic features and time-split fix          | 0.8070              |
| LGBM with temporal and workload features                 | 0.8355              |
| LGBM with added `COURSE_LEVEL` feature                   | 0.8363              |
| **Final Model (LGBM with relative performance features)** | **0.8380**          |

The most substantial performance gains were achieved by introducing features that directly modeled the relative nature of the prediction target. The `lag1_dept_rank_pct` feature, which captures a course's historical popularity within its department, was the most impactful. The final model, incorporating all engineered features, achieved a macro F1 score of **0.8380** on the hold-out validation set, indicating a strong ability to predict high-enrollment courses.

## Future Work

- **Hyperparameter Tuning**: A systematic search of the LightGBM hyperparameter space using methods like Bayesian optimization could yield further performance improvements.
- **Advanced Feature Engineering**: Explore more complex time-series features, such as exponentially weighted moving averages of enrollment, to better capture evolving trends. Interaction features (e.g., `COURSE_LEVEL` x `OFFER_DEPT_NAME`) could also uncover more granular patterns.
- **Model Ensembling**: Combine the predictions of the LGBM model with other gradient boosting models (e.g., XGBoost, CatBoost) to potentially improve robustness and accuracy.