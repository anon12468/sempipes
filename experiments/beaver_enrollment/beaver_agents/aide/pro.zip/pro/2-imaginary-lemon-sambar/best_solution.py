import os
from pathlib import Path

import lightgbm as lgb
import numpy as np
import pandas as pd
from sklearn.metrics import f1_score

SCRIPT_DIR = Path(__file__).resolve().parent
REPO_ROOT = SCRIPT_DIR.parents[2]


def _first_existing_dir(candidates):
    for candidate in candidates:
        if os.path.isdir(candidate):
            return candidate
    return candidates[0]


TRAIN_DATA_DIR = _first_existing_dir(
    [
        os.getenv("TRAIN_DATA_DIR", ""),
        "./input",
        str(REPO_ROOT / "table_splits" / "train"),
    ]
)
TEST_DATA_DIR = _first_existing_dir(
    [
        os.getenv("TEST_DATA_DIR", ""),
        os.path.join(TRAIN_DATA_DIR, "test"),
        str(REPO_ROOT / "test"),
    ]
)
WORKING_DIR = "./working"
os.makedirs(WORKING_DIR, exist_ok=True)


def _load_csv_with_fallback(paths):
    for path in paths:
        if os.path.exists(path):
            return pd.read_csv(path, low_memory=False)
    raise FileNotFoundError(f"None of the files exist: {paths}")


def _find_existing_file(paths):
    for path in paths:
        if os.path.exists(path):
            return path
    raise FileNotFoundError(f"None of the files exist: {paths}")


def load_split(split_dir, global_dir, labels_path=None):
    summary = _load_csv_with_fallback([os.path.join(split_dir, "SUBJECT_OFFERED_SUMMARY.csv")])
    history = _load_csv_with_fallback(
        [
            os.path.join(split_dir, "ENROLLMENT_HISTORY_FEATURES.csv"),
            os.path.join(global_dir, "ENROLLMENT_HISTORY_FEATURES.csv"),
        ]
    )
    terms = _load_csv_with_fallback(
        [
            os.path.join(split_dir, "ACADEMIC_TERMS.csv"),
            os.path.join(global_dir, "ACADEMIC_TERMS.csv"),
        ]
    )
    if labels_path is None:
        base = summary[["TERM_CODE", "SUBJECT_ID_SORT"]].drop_duplicates().copy()
    else:
        base = pd.read_csv(labels_path)

    out = pd.merge(base, summary, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")
    out = pd.merge(out, history, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")
    out = pd.merge(out, terms[["TERM_CODE", "ACADEMIC_YEAR"]], on="TERM_CODE", how="left")
    return out


def engineer(df):
    out = df.copy()
    out["OFFER_DEPT_NAME"] = out["OFFER_DEPT_NAME"].fillna("missing")
    out["RESPONSIBLE_FACULTY_NAME"] = out["RESPONSIBLE_FACULTY_NAME"].fillna("missing")
    out["dept_course_count_term"] = out.groupby(["TERM_CODE", "OFFER_DEPT_NAME"])[
        "SUBJECT_ID_SORT"
    ].transform("nunique")
    out["faculty_course_count_term"] = out.groupby(["TERM_CODE", "RESPONSIBLE_FACULTY_NAME"])[
        "SUBJECT_ID_SORT"
    ].transform("nunique")
    out["lag1_dept_rank_pct"] = out.groupby(["TERM_CODE", "OFFER_DEPT_NAME"])[
        "lag1_enrollment"
    ].rank(method="dense", pct=True)

    out["ACADEMIC_YEAR"] = pd.to_numeric(out["ACADEMIC_YEAR"], errors="coerce").fillna(-1).astype(int)
    out["TERM_SEASON"] = out["TERM_CODE"].astype(str).str[-2:]

    out["COURSE_NUM"] = out["SUBJECT_ID_SORT"].astype(str).str.extract(r"(\d+)")[0].astype(float)
    bins = [-np.inf, 99, 199, 299, 399, 499, np.inf]
    labels = ["<100", "100-level", "200-level", "300-level", "400-level", "500+-level"]
    out["COURSE_LEVEL"] = pd.cut(out["COURSE_NUM"], bins=bins, labels=labels)
    out["COURSE_LEVEL"] = out["COURSE_LEVEL"].cat.add_categories("missing").fillna("missing")
    out = out.drop(columns=["COURSE_NUM"])
    return out


print("Loading train/test data...")
train_df = load_split(
    TRAIN_DATA_DIR,
    TRAIN_DATA_DIR,
    labels_path=_find_existing_file(
        [
            os.path.join(TRAIN_DATA_DIR, "gold_enrollment_train.csv"),
            str(REPO_ROOT / "eval" / "gold_enrollment_train.csv"),
        ]
    ),
)
test_df = load_split(TEST_DATA_DIR, TRAIN_DATA_DIR, labels_path=None)

print("Engineering features...")
train_df = engineer(train_df)
test_df = engineer(test_df)
train_df["HIGH_ENROLLMENT"] = (train_df["HIGH_ENROLLMENT"] == "Y").astype(int)

categorical_features = [
    "OFFER_DEPT_NAME",
    "OFFER_SCHOOL_NAME",
    "RESPONSIBLE_FACULTY_NAME",
    "CLUSTER_TYPE_DESC",
    "HGN_CODE_DESC",
    "TERM_SEASON",
    "COURSE_LEVEL",
]
numerical_features = [
    "TOTAL_UNITS",
    "lag1_enrollment",
    "lag2_enrollment",
    "roll3_enrollment_mean",
    "ACADEMIC_YEAR",
    "dept_course_count_term",
    "faculty_course_count_term",
    "lag1_dept_rank_pct",
]
features = categorical_features + numerical_features

for col in numerical_features:
    train_df[col] = pd.to_numeric(train_df[col], errors="coerce").fillna(-1)
    test_df[col] = pd.to_numeric(test_df[col], errors="coerce").fillna(-1)
for col in categorical_features:
    train_df[col] = train_df[col].fillna("missing").astype("category")
    test_df[col] = test_df[col].fillna("missing").astype("category")

print("Creating time-based validation split...")
latest_year = train_df["ACADEMIC_YEAR"].max()
fit_df = train_df[train_df["ACADEMIC_YEAR"] < latest_year].copy()
val_df = train_df[train_df["ACADEMIC_YEAR"] == latest_year].copy()
if fit_df.empty or val_df.empty:
    raise ValueError("Time-based split failed: check ACADEMIC_YEAR distribution.")

X_train, y_train = fit_df[features], fit_df["HIGH_ENROLLMENT"]
X_val, y_val = val_df[features], val_df["HIGH_ENROLLMENT"]

print(f"Training set size: {len(X_train)}")
print(f"Validation set size: {len(X_val)}")

print("Training LightGBM model...")
lgbm = lgb.LGBMClassifier(
    objective="binary",
    metric="logloss",
    random_state=42,
    n_estimators=1000,
    learning_rate=0.05,
    num_leaves=31,
)
lgbm.fit(
    X_train,
    y_train,
    eval_set=[(X_val, y_val)],
    eval_metric="logloss",
    callbacks=[lgb.early_stopping(100, verbose=False)],
    categorical_feature=categorical_features,
)

print("Evaluating model performance...")
val_preds = lgbm.predict(X_val)
macro_f1 = f1_score(y_val, val_preds, average="macro")
print(f"Validation Macro F1 Score: {macro_f1:.4f}")

# Refit on all labeled train rows before test inference.
lgbm.fit(train_df[features], train_df["HIGH_ENROLLMENT"], categorical_feature=categorical_features)

print("Generating submission.csv for test split...")
test_preds = lgbm.predict(test_df[features])
submission_df = test_df[["TERM_CODE", "SUBJECT_ID_SORT"]].copy()
submission_df["HIGH_ENROLLMENT"] = np.where(test_preds == 1, "Y", "N")
submission_path = os.path.join(WORKING_DIR, "submission.csv")
submission_df.to_csv(submission_path, index=False)
print(f"Submission file saved to {submission_path}")
print("Script finished successfully.")
