import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OrdinalEncoder
import lightgbm as lgb
from sklearn.metrics import f1_score
import optuna
import os
import warnings
from pathlib import Path

# --- Code Implementation ---

# Set up environment
warnings.filterwarnings("ignore")
optuna.logging.set_verbosity(optuna.logging.WARNING)

# --- 1. Load and Prepare Data ---

# Define data and output directories
def _find_repo_root(start_path):
    start = Path(start_path).resolve()
    for candidate in [start.parent, *start.parents]:
        if (candidate / "table_splits" / "train").is_dir() and (
            candidate / "test"
        ).is_dir():
            return candidate
    return Path.cwd()


REPO_ROOT = _find_repo_root(__file__)
TRAIN_DATA_DIR = os.getenv("TRAIN_DATA_DIR", str(REPO_ROOT / "table_splits" / "train"))
TEST_DATA_DIR = os.getenv("TEST_DATA_DIR", str(REPO_ROOT / "test"))
OUTPUT_DIR = "./working"


def _read_csv_with_fallback(candidates, **kwargs):
    for path in candidates:
        if os.path.exists(path):
            return pd.read_csv(path, **kwargs)
    raise FileNotFoundError(f"None of the candidate files exist: {candidates}")


def load_split_data(split_dir, global_dir, labels_path=None):
    summary = _read_csv_with_fallback(
        [os.path.join(split_dir, "SUBJECT_OFFERED_SUMMARY.csv")], low_memory=False
    )
    history = _read_csv_with_fallback(
        [
            os.path.join(split_dir, "ENROLLMENT_HISTORY_FEATURES.csv"),
            os.path.join(global_dir, "ENROLLMENT_HISTORY_FEATURES.csv"),
        ]
    )
    terms = _read_csv_with_fallback(
        [
            os.path.join(split_dir, "ACADEMIC_TERMS.csv"),
            os.path.join(global_dir, "ACADEMIC_TERMS.csv"),
        ]
    )

    if labels_path is None:
        base = summary[["TERM_CODE", "SUBJECT_ID_SORT"]].copy()
    else:
        if isinstance(labels_path, (list, tuple)):
            base = _read_csv_with_fallback(labels_path)
        else:
            base = pd.read_csv(labels_path)

    merged = pd.merge(base, summary, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")
    merged = pd.merge(
        merged, history, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left"
    )
    merged = pd.merge(
        merged, terms[["TERM_CODE", "ACADEMIC_YEAR"]], on="TERM_CODE", how="left"
    )
    return merged


print("Merging training data sources...")
train_data = load_split_data(
    split_dir=TRAIN_DATA_DIR,
    global_dir=TRAIN_DATA_DIR,
    labels_path=[
        os.path.join(TRAIN_DATA_DIR, "gold_enrollment_train.csv"),
        os.path.join(REPO_ROOT, "eval", "gold_enrollment_train.csv"),
    ],
)

print("Merging test data sources...")
test_data = load_split_data(
    split_dir=TEST_DATA_DIR,
    global_dir=TRAIN_DATA_DIR,
    labels_path=None,
)


# --- 2. Feature Engineering ---
print("Engineering features...")


def add_engineered_features(df):
    out = df.copy()
    out["YEAR"] = pd.to_numeric(out["TERM_CODE"].astype(str).str[:4], errors="coerce")
    out["SEMESTER_CODE"] = out["TERM_CODE"].astype(str).str[4:]
    semester_map = {"JA": 0, "SP": 1, "SU": 2, "FA": 3}
    out["TERM_SORTABLE"] = (
        out["YEAR"] + out["SEMESTER_CODE"].map(semester_map).fillna(0) / 4.0
    )
    return out


# Convert target variable to binary for train only
train_data["HIGH_ENROLLMENT"] = (train_data["HIGH_ENROLLMENT"] == "Y").astype(int)

train_data = add_engineered_features(train_data)
test_data = add_engineered_features(test_data)

# Department-level trend features fit on train and applied to both splits
print("Engineering department-level trend features...")
dept_term_stats = (
    train_data.groupby(["TERM_CODE", "OFFER_DEPT_CODE"])["lag1_enrollment"]
    .agg(["mean", "std", "count"])
    .reset_index()
)
dept_term_stats.rename(
    columns={
        "mean": "dept_lag1_enroll_mean",
        "std": "dept_lag1_enroll_std",
        "count": "dept_course_count_in_term",
    },
    inplace=True,
)

# Merge these new contextual features back into train/test
train_data = pd.merge(
    train_data, dept_term_stats, on=["TERM_CODE", "OFFER_DEPT_CODE"], how="left"
)
test_data = pd.merge(
    test_data, dept_term_stats, on=["TERM_CODE", "OFFER_DEPT_CODE"], how="left"
)


# --- 3. Model Training and Validation Setup ---

# Define features and target
# Added the new features to the list of numeric features
numeric_features = [
    "TOTAL_UNITS",
    "lag1_enrollment",
    "lag2_enrollment",
    "roll3_enrollment_mean",
    "YEAR",
    # New features
    "dept_lag1_enroll_mean",
    "dept_lag1_enroll_std",
    "dept_course_count_in_term",
]

categorical_features = [
    "OFFER_DEPT_CODE",
    "OFFER_SCHOOL_NAME",
    "RESPONSIBLE_FACULTY_NAME",
    "CLUSTER_TYPE",
    "SEMESTER_CODE",
    "HGN_CODE_DESC",
]

features = numeric_features + categorical_features
target = "HIGH_ENROLLMENT"

# Ensure feature columns have appropriate types
for col in categorical_features:
    train_data[col] = train_data[col].astype("category")
    if col in test_data.columns:
        test_data[col] = test_data[col].astype("category")
for col in numeric_features:
    train_data[col] = pd.to_numeric(train_data[col], errors="coerce")
    if col in test_data.columns:
        test_data[col] = pd.to_numeric(test_data[col], errors="coerce")

# Time-based validation split: train on earlier terms, validate on recent terms
print("Performing time-based split for validation...")
data_sorted = train_data.sort_values("TERM_SORTABLE").reset_index(drop=True)
unique_terms = sorted(data_sorted["TERM_SORTABLE"].unique())

# Hold out the last year (approximated as 4 terms) for validation
if len(unique_terms) > 4:
    split_term = unique_terms[-4]
else:
    # Fallback for very few terms, split 80/20
    split_term = unique_terms[int(len(unique_terms) * 0.8)] if unique_terms else 0

train_df = data_sorted[data_sorted["TERM_SORTABLE"] < split_term].copy()
val_df = data_sorted[data_sorted["TERM_SORTABLE"] >= split_term].copy()

# Final check for empty split to prevent errors
if train_df.empty or val_df.empty:
    print(
        "Warning: Train or validation set is empty after time-based split. Performing random 80/20 split as fallback."
    )
    train_df, val_df = train_test_split(
        data_sorted, test_size=0.2, random_state=42, stratify=data_sorted[target]
    )

X_train = train_df[features]
y_train = train_df[target]
X_val = val_df[features]
y_val = val_df[target]

# Keep full train for final fit before test prediction
X_full_train = train_data[features]
y_full_train = train_data[target]

print(f"Training on {len(X_train)} samples, validating on {len(X_val)} samples.")

# --- 4. Preprocessing and Hyperparameter Tuning ---

# Create preprocessing pipelines for numerical and categorical features
numeric_transformer = Pipeline(
    steps=[("imputer", SimpleImputer(strategy="median")), ("scaler", StandardScaler())]
)

categorical_transformer = Pipeline(
    steps=[
        ("imputer", SimpleImputer(strategy="constant", fill_value="missing")),
        (
            "encoder",
            OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1),
        ),
    ]
)

preprocessor = ColumnTransformer(
    transformers=[
        ("num", numeric_transformer, numeric_features),
        ("cat", categorical_transformer, categorical_features),
    ],
    remainder="drop",
)


def objective(trial):
    """Optuna objective function to tune LGBM hyperparameters."""
    params = {
        "objective": "binary",
        "metric": "binary_logloss",
        "verbosity": -1,
        "boosting_type": "gbdt",
        "n_estimators": trial.suggest_int("n_estimators", 200, 1200),
        "learning_rate": trial.suggest_float("learning_rate", 0.01, 0.2, log=True),
        "num_leaves": trial.suggest_int("num_leaves", 20, 300),
        "max_depth": trial.suggest_int("max_depth", 4, 15),
        "lambda_l1": trial.suggest_float("lambda_l1", 1e-8, 10.0, log=True),
        "lambda_l2": trial.suggest_float("lambda_l2", 1e-8, 10.0, log=True),
        "feature_fraction": trial.suggest_float("feature_fraction", 0.6, 1.0),
        "bagging_fraction": trial.suggest_float("bagging_fraction", 0.6, 1.0),
        "bagging_freq": trial.suggest_int("bagging_freq", 1, 7),
        "min_child_samples": trial.suggest_int("min_child_samples", 5, 100),
        "random_state": 42,
        "n_jobs": -1,
        "class_weight": "balanced",
    }

    model = lgb.LGBMClassifier(**params)
    pipeline = Pipeline(steps=[("preprocessor", preprocessor), ("classifier", model)])
    pipeline.fit(X_train, y_train)
    preds = pipeline.predict(X_val)
    f1 = f1_score(y_val, preds, average="macro")
    return f1


print("Starting hyperparameter optimization with Optuna...")
study = optuna.create_study(direction="maximize", pruner=optuna.pruners.MedianPruner())
study.optimize(
    objective, n_trials=50, timeout=1800
)  # Search for 50 trials or 30 minutes

print(f"Best trial F1 score: {study.best_value:.4f}")
print("Best hyperparameters found:", study.best_params)

# --- 5. Execution and Evaluation ---

# Create the final model with the best hyperparameters found
best_params = study.best_params
best_params["random_state"] = 42
best_params["n_jobs"] = -1
best_params["class_weight"] = "balanced"

final_model = lgb.LGBMClassifier(**best_params)

# Create the final pipeline that includes preprocessing and classification
final_pipeline = Pipeline(
    steps=[("preprocessor", preprocessor), ("classifier", final_model)]
)

# Train the model with best parameters on full train data
print("\nTraining the final LightGBM model on full training data...")
final_pipeline.fit(X_full_train, y_full_train)

# Make predictions on the validation set
print("Evaluating the final model on the validation set...")
y_pred = final_pipeline.predict(X_val)

# Calculate and print the macro F1 score
final_f1 = f1_score(y_val, y_pred, average="macro")
print(f"Final Validation Macro F1 Score: {final_f1:.4f}")


# --- 6. Generate Submission File on test split ---
print("Generating test submission file...")
X_test = test_data[features].copy()
test_preds = final_pipeline.predict(X_test)
submission_df = test_data[["TERM_CODE", "SUBJECT_ID_SORT"]].copy()
submission_df["HIGH_ENROLLMENT"] = np.where(test_preds == 1, "Y", "N")

# Ensure the output directory exists
os.makedirs(OUTPUT_DIR, exist_ok=True)
submission_path = os.path.join(OUTPUT_DIR, "submission.csv")
submission_df.to_csv(submission_path, index=False)

print(f"Submission file successfully created at: {submission_path}")
