# Technical Report: High Enrollment Prediction

## Introduction

This report summarizes the development of a binary classification model to predict whether a university course offering will achieve "high enrollment." The target is defined as being in the top quartile of enrollment for courses within the same department and term. The primary evaluation metric is the macro F1 score, assessed using a time-based validation split to simulate a real-world forecasting scenario. The solution utilizes historical course catalog and enrollment data.

## Preprocessing

The solution involved merging several data sources, including course summaries, enrollment history, and academic term information, into a unified feature set. The preprocessing and feature engineering pipeline evolved through several iterations to capture the necessary signals for the prediction task.

### Temporal Feature Engineering

A critical step was creating a consistent, sortable temporal index. The `TERM_CODE` column contained mixed formats (e.g., `2016FA` and `201701`). A robust parsing function was implemented to extract the year and map the semester suffix (FA, SP, etc.) to a numeric representation. This produced a `TERM_CODE_NUMERIC` column, which was essential for correctly ordering the data and creating a chronological train-validation split.

### Contextual Feature Engineering

The most impactful features were those that framed a course's enrollment in the context of its peers, directly aligning the features with the relative nature of the target variable.

- **Departmental Relative Enrollment:** The final model's success is largely attributed to features that measure a course's historical enrollment relative to its department for a given term. Using historical lag features (`lag1_enrollment`, `lag2_enrollment`), we calculated the mean and standard deviation for each department-term group. These statistics were then used to compute z-scores and normalized enrollment ratios for each course, providing a powerful signal of its standing within its group.

- **Course Level:** A categorical feature, `COURSE_LEVEL`, was engineered by extracting the first digit from the `SUBJECT_ID_SORT` (e.g., '1' for 100-level, '4' for 400-level). This feature provides a strong structural signal about expected class size, as introductory courses are inherently designed for larger audiences than advanced seminars.

### Data Handling

- **Missing Values:** Missing numerical values in historical enrollment features were imputed with 0, assuming a null value indicates no prior offering. Other numerical features were imputed with their median. Missing categorical features were treated as a distinct `__MISSING__` category.
- **Categorical Features:** All categorical features were converted to the `category` dtype for efficient handling by LightGBM.

## Modeling Methods

### Model Selection

A LightGBM Classifier (`lgb.LGBMClassifier`) was chosen for its performance and efficiency on tabular data, as well as its native handling of categorical features.

### Validation Strategy

To prevent data leakage and accurately assess the model's forecasting ability, a time-based validation split was employed. The dataset was sorted chronologically using the engineered `TERM_CODE_NUMERIC` feature. The last three academic terms were held out as the validation set, with all preceding terms used for training.

### Training

The model was trained using early stopping with a patience of 100 rounds, using the validation set's logloss to monitor performance and prevent overfitting.

## Results Discussion

The final model achieved a **macro F1 score of 0.9431** on the time-based validation set.

The high performance is primarily attributed to the feature engineering strategy that directly models the problem's core requirement: predicting relative success. While initial models using raw enrollment history performed adequately (macro F1 ≈ 0.81), the introduction of departmental z-scores and course-level features provided the necessary context for the model to distinguish top-performing courses with high accuracy. The robust handling of temporal information was also critical for establishing a valid training and evaluation framework.

## Future Work

While the current model is highly effective, several avenues for further improvement exist:

- **Hyperparameter Tuning:** A systematic search for optimal LightGBM hyperparameters (e.g., using Bayesian optimization) could yield incremental performance gains.
- **Advanced Feature Engineering:** Further value could be extracted by creating features related to instructors (e.g., average historical enrollment per faculty member) or interaction features between `COURSE_LEVEL` and `SUBJECT_DEPARTMENT`.
- **Alternative Models:** Exploring other gradient boosting frameworks like XGBoost or CatBoost could provide different perspectives and potentially better performance.
- **Threshold Optimization:** The prediction threshold is currently fixed at 0.5. Tuning this threshold on the validation set could further optimize the macro F1 score.