import os
import gc
from pathlib import Path

import lightgbm as lgb
import numpy as np
import pandas as pd
from sklearn.metrics import f1_score

SCRIPT_DIR = Path(__file__).resolve().parent
REPO_ROOT = SCRIPT_DIR.parents[2]
WORKING_DIR = "./working"
os.makedirs(WORKING_DIR, exist_ok=True)


def _first_existing_dir(candidates):
    for candidate in candidates:
        if candidate and os.path.isdir(candidate):
            return candidate
    return candidates[-1]


TRAIN_DATA_DIR = _first_existing_dir(
    [
        os.getenv("TRAIN_DATA_DIR", ""),
        "./input",
        str(REPO_ROOT / "table_splits" / "train"),
    ]
)
TEST_DATA_DIR = _first_existing_dir(
    [
        os.getenv("TEST_DATA_DIR", ""),
        os.path.join(TRAIN_DATA_DIR, "test"),
        str(REPO_ROOT / "test"),
    ]
)


def _load_csv(paths):
    for path in paths:
        if os.path.exists(path):
            return pd.read_csv(path, low_memory=False)
    raise FileNotFoundError(f"None of the files exist: {paths}")


def _gold_train_paths():
    return [
        os.path.join(TRAIN_DATA_DIR, "gold_enrollment_train.csv"),
        str(REPO_ROOT / "eval" / "gold_enrollment_train.csv"),
    ]


def load_split(split_dir, global_dir, labels_path=None):
    offered_summary = _load_csv([os.path.join(split_dir, "SUBJECT_OFFERED_SUMMARY.csv")])
    history = _load_csv(
        [
            os.path.join(split_dir, "ENROLLMENT_HISTORY_FEATURES.csv"),
            os.path.join(global_dir, "ENROLLMENT_HISTORY_FEATURES.csv"),
        ]
    )
    subject_summary = _load_csv(
        [
            os.path.join(split_dir, "SUBJECT_SUMMARY.csv"),
            os.path.join(global_dir, "SUBJECT_SUMMARY.csv"),
        ]
    )

    if labels_path is None:
        base = offered_summary[["TERM_CODE", "SUBJECT_ID_SORT"]].drop_duplicates()
    else:
        base = _load_csv(labels_path)

    data = pd.merge(base, offered_summary, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")
    data = pd.merge(data, history, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")
    data = pd.merge(
        data,
        subject_summary,
        on=["TERM_CODE", "SUBJECT_ID_SORT"],
        how="left",
        suffixes=("", "_dup"),
    )
    return data[[c for c in data.columns if not c.endswith("_dup")]]


def engineer_features(df):
    out = df.copy()
    out["TERM_CODE"] = out["TERM_CODE"].astype(str)
    out["ACADEMIC_YEAR"] = out["TERM_CODE"].str[:4].astype(int)
    semester_str = out["TERM_CODE"].str[4:]
    term_map = {"FA": 9, "SP": 2, "IA": 1, "SU": 3, "JA": 1}
    numeric_semester = pd.to_numeric(semester_str, errors="coerce")
    mapped_semester = semester_str.map(term_map)
    out["SEMESTER"] = numeric_semester.fillna(mapped_semester).fillna(0).astype(int)
    out["TERM_CODE_NUMERIC"] = out["ACADEMIC_YEAR"] * 100 + out["SEMESTER"]

    out["SUBJECT_DEPARTMENT"] = (
        out["SUBJECT_ID_SORT"].astype(str).str.extract(r"^([A-Za-z]*)")[0].fillna("UNKNOWN")
    )
    out["SUBJECT_DEPARTMENT"] = out["SUBJECT_DEPARTMENT"].astype("category")

    enrollment_features = ["lag1_enrollment", "lag2_enrollment", "roll3_enrollment_mean"]
    existing_enrollment_features = [f for f in enrollment_features if f in out.columns]

    if existing_enrollment_features:
        for col in existing_enrollment_features:
            out[col] = out[col].fillna(0)

        groupby_cols = ["TERM_CODE_NUMERIC", "SUBJECT_DEPARTMENT"]
        grouped = out.groupby(groupby_cols, observed=False)[existing_enrollment_features]
        means = grouped.transform("mean")
        stds = grouped.transform("std")

        for col in existing_enrollment_features:
            zscore_col_name = f"{col}_dept_term_zscore"
            out[zscore_col_name] = (out[col] - means[col]) / (stds[col] + 1e-6)
            out[zscore_col_name] = out[zscore_col_name].fillna(0)

    return out


def prepare_model_frame(df, numeric_medians=None, fit_medians=False):
    out = df.copy()

    if "HIGH_ENROLLMENT" in out.columns:
        out["HIGH_ENROLLMENT"] = out["HIGH_ENROLLMENT"].map({"Y": 1, "N": 0})

    for col in out.select_dtypes(include=["object"]).columns:
        if col in ["TERM_CODE", "SUBJECT_ID_SORT"]:
            continue
        if set(out[col].dropna().unique()) <= {"Y", "N"}:
            out[col] = out[col].map({"Y": 1, "N": 0}).fillna(-1).astype(int)
        else:
            out[col] = out[col].astype("category")

    medians = {} if numeric_medians is None else dict(numeric_medians)
    for col in out.select_dtypes(include=np.number).columns:
        if col == "HIGH_ENROLLMENT":
            continue
        if fit_medians:
            medians[col] = out[col].median()
        if out[col].isnull().any():
            out[col] = out[col].fillna(medians.get(col, 0))

    return out, medians


print("Loading train and test data...")
train_data = load_split(TRAIN_DATA_DIR, TRAIN_DATA_DIR, labels_path=_gold_train_paths())
test_data = load_split(TEST_DATA_DIR, TRAIN_DATA_DIR, labels_path=None)

print("Engineering features...")
train_data = engineer_features(train_data)
test_data = engineer_features(test_data)

train_data, numeric_medians = prepare_model_frame(train_data, fit_medians=True)
test_data, _ = prepare_model_frame(test_data, numeric_medians=numeric_medians)

target = "HIGH_ENROLLMENT"
features = [
    col
    for col in train_data.columns
    if col not in ["TERM_CODE", "SUBJECT_ID_SORT", target, "TERM_CODE_NUMERIC"]
]
categorical_features = [col for col in features if train_data[col].dtype.name == "category"]

unique_terms = sorted(train_data["TERM_CODE_NUMERIC"].unique())
N_VAL_TERMS = 3
if len(unique_terms) > N_VAL_TERMS:
    val_terms = unique_terms[-N_VAL_TERMS:]
    train_terms = unique_terms[:-N_VAL_TERMS]
    fit_df = train_data[train_data["TERM_CODE_NUMERIC"].isin(train_terms)].copy()
    val_df = train_data[train_data["TERM_CODE_NUMERIC"].isin(val_terms)].copy()
else:
    fit_df = train_data
    val_df = train_data.sample(frac=0.2, random_state=42)

X_train = fit_df[features]
y_train = fit_df[target]
X_val = val_df[features]
y_val = val_df[target]

print(f"Training set size: {len(X_train)}")
print(f"Validation set size: {len(X_val)}")

lgbm = lgb.LGBMClassifier(
    objective="binary",
    metric="logloss",
    random_state=42,
    n_estimators=1000,
    learning_rate=0.05,
    num_leaves=31,
    max_depth=-1,
    n_jobs=-1,
    colsample_bytree=0.8,
    subsample=0.8,
)

lgbm.fit(
    X_train,
    y_train,
    eval_set=[(X_val, y_val)],
    eval_metric="logloss",
    callbacks=[lgb.early_stopping(100, verbose=False)],
    categorical_feature=categorical_features,
)

y_pred_val = lgbm.predict(X_val)
macro_f1 = f1_score(y_val, y_pred_val, average="macro")
print(f"Validation Macro F1 Score: {macro_f1:.4f}")

print("Retraining on full labeled train data...")
lgbm.fit(
    train_data[features],
    train_data[target],
    categorical_feature=categorical_features,
)

print("Generating test submission...")
test_preds = lgbm.predict(test_data[features])
submission_df = test_data[["TERM_CODE", "SUBJECT_ID_SORT"]].copy()
submission_df["HIGH_ENROLLMENT"] = np.where(test_preds == 1, "Y", "N")

submission_path = os.path.join(WORKING_DIR, "submission.csv")
submission_df.to_csv(submission_path, index=False)
print(f"Submission file saved to {submission_path}")

gold_test_path = REPO_ROOT / "eval" / "gold_enrollment_test.csv"
if gold_test_path.exists():
    gold_test = pd.read_csv(gold_test_path)
    merged = gold_test.merge(
        submission_df,
        on=["TERM_CODE", "SUBJECT_ID_SORT"],
        suffixes=("_gold", "_pred"),
    )
    if len(merged):
        y_true = merged["HIGH_ENROLLMENT_gold"].map({"Y": 1, "N": 0})
        y_pred = merged["HIGH_ENROLLMENT_pred"].map({"Y": 1, "N": 0})
        test_f1 = f1_score(y_true, y_pred, average="macro")
        print(f"Test Macro F1 Score: {test_f1:.4f}")

del train_data, test_data
gc.collect()
