import pandas as pd
import numpy as np
import lightgbm as lgb
from sklearn.metrics import f1_score
from sklearn.model_selection import train_test_split
import os
import gc

# Configuration block
TRAIN_DATA_DIR = "./input/table_splits/train"
# The __TEST_DATA_DIR__ placeholder will be replaced by the evaluation environment.
# For local development, we point to the logical path where test data would be.
TEST_DATA_DIR = "./input/table_splits/test"
EVAL_DIR = "./input/eval"
INPUT_DIR = "./input"
WORKING_DIR = "./working"


def create_feature_set(summary_df, history_df, terms_df):
    """
    Merges summary, history, and academic term data, and engineers basic features.
    """
    # Merge summary and history
    df = pd.merge(
        summary_df, history_df, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left"
    )

    # Merge with academic terms to get ACADEMIC_YEAR
    df = pd.merge(
        df, terms_df[["TERM_CODE", "ACADEMIC_YEAR"]], on="TERM_CODE", how="left"
    )

    # --- Basic Feature Engineering ---

    # Impute missing historical enrollment. -1 signifies 'no history'.
    for col in ["lag1_enrollment", "lag2_enrollment", "roll3_enrollment_mean"]:
        df[col] = df[col].fillna(-1)

    # Simple time features from TERM_CODE
    df["term_season"] = df["TERM_CODE"] % 100

    # Fill NA for key numerical features with their median
    for col in ["TOTAL_UNITS", "ENROLLMENT_CAP"]:
        if col in df.columns:
            median_val = df[col].median()
            df[col] = df[col].fillna(median_val)

    return df


def engineer_context_features(df):
    """
    Engineers context-aware features like rank and z-score within department-term groups.
    This function should be applied independently to train and test sets to prevent leakage.
    """
    group_cols = ["TERM_CODE", "OFFER_DEPT_CODE"]
    features_to_normalize = [
        f
        for f in [
            "ENROLLMENT_CAP",
            "TOTAL_UNITS",
            "lag1_enrollment",
            "lag2_enrollment",
            "roll3_enrollment_mean",
        ]
        if f in df.columns
    ]

    context_features = []
    for col in features_to_normalize:
        # Rank within the department-term group
        rank_col_name = f"{col}_rank_in_group"
        df[rank_col_name] = df.groupby(group_cols)[col].rank(pct=True).fillna(0.5)
        context_features.append(rank_col_name)

        # Z-score within the department-term group
        zscore_col_name = f"{col}_zscore_in_group"
        group_mean = df.groupby(group_cols)[col].transform("mean")
        group_std = (
            df.groupby(group_cols)[col].transform("std").fillna(1)
        )  # Use fillna(1) for groups with one member
        df[zscore_col_name] = (df[col] - group_mean) / (group_std + 1e-6)
        # Fill any remaining NaNs, e.g. if the original column had NaNs not caught before
        df[zscore_col_name] = df[zscore_col_name].fillna(0)
        context_features.append(zscore_col_name)

    return df, context_features


def main():
    """
    Main function to run the entire pipeline.
    """
    # Create working directory if it doesn't exist
    os.makedirs(WORKING_DIR, exist_ok=True)

    # Load core data files
    print("Loading data...")
    try:
        train_summary = pd.read_csv(
            os.path.join(TRAIN_DATA_DIR, "SUBJECT_OFFERED_SUMMARY.csv"),
            low_memory=False,
        )
        train_history = pd.read_csv(
            os.path.join(TRAIN_DATA_DIR, "ENROLLMENT_HISTORY_FEATURES.csv"),
            low_memory=False,
        )
        test_summary = pd.read_csv(
            os.path.join(TEST_DATA_DIR, "SUBJECT_OFFERED_SUMMARY.csv"), low_memory=False
        )
        test_history = pd.read_csv(
            os.path.join(TEST_DATA_DIR, "ENROLLMENT_HISTORY_FEATURES.csv"),
            low_memory=False,
        )
        train_labels = pd.read_csv(
            os.path.join(EVAL_DIR, "gold_enrollment_train.csv"), low_memory=False
        )
        academic_terms = pd.read_csv(
            os.path.join(INPUT_DIR, "ACADEMIC_TERMS.csv"), low_memory=False
        )
    except FileNotFoundError as e:
        print(f"Error loading data: {e}")
        print(
            "Please ensure the data paths are correct and all necessary files are in the 'input' directory."
        )
        return

    # Process target variable
    if train_labels["HIGH_ENROLLMENT"].dtype == "object":
        train_labels["HIGH_ENROLLMENT"] = train_labels["HIGH_ENROLLMENT"].map(
            {"yes": 1, "no": 0}
        )

    # --- Basic Feature Engineering ---
    print("Engineering basic features...")

    train_df = create_feature_set(train_summary, train_history, academic_terms)
    test_df = create_feature_set(test_summary, test_history, academic_terms)

    # --- Instructor-Level Features ---
    print("Engineering instructor-level features (leakage-free)...")

    # 1. Calculate stats *only* from the training data to prevent leakage
    faculty_stats = (
        train_df.groupby("RESPONSIBLE_FACULTY_NAME")
        .agg(
            faculty_enroll_mean=("lag1_enrollment", "mean"),
            faculty_cap_mean=("ENROLLMENT_CAP", "mean"),
        )
        .reset_index()
    )

    # 2. Map these historical stats to both train and test sets
    train_df = pd.merge(
        train_df, faculty_stats, on="RESPONSIBLE_FACULTY_NAME", how="left"
    )
    test_df = pd.merge(
        test_df, faculty_stats, on="RESPONSIBLE_FACULTY_NAME", how="left"
    )

    # 3. Fill NaNs using global stats calculated *only* from the training set.
    global_avg_faculty_enroll = faculty_stats["faculty_enroll_mean"].mean()
    global_avg_faculty_cap = faculty_stats["faculty_cap_mean"].mean()

    for df in [train_df, test_df]:
        df["faculty_enroll_mean"] = df["faculty_enroll_mean"].fillna(
            global_avg_faculty_enroll
        )
        df["faculty_cap_mean"] = df["faculty_cap_mean"].fillna(global_avg_faculty_cap)

    instructor_features = ["faculty_enroll_mean", "faculty_cap_mean"]

    # --- BUGFIX: Context-Aware Features (Leakage Fixed) ---
    # Apply feature engineering separately to train and test sets to prevent data leakage.
    print("Engineering context-aware features (leakage-free)...")
    train_df, context_features = engineer_context_features(train_df)
    test_df, _ = engineer_context_features(test_df)  # Use the same feature list name

    # --- End of Feature Engineering ---

    # Merge labels into the training set
    train_df = pd.merge(
        train_df, train_labels, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="inner"
    )

    del (
        train_summary,
        train_history,
        test_summary,
        test_history,
        train_labels,
        academic_terms,
    )
    gc.collect()

    # Define features
    numerical_cols = (
        [
            "TOTAL_UNITS",
            "ENROLLMENT_CAP",
            "lag1_enrollment",
            "lag2_enrollment",
            "roll3_enrollment_mean",
            "term_season",
            "ACADEMIC_YEAR",
        ]
        + context_features
        + instructor_features
    )

    categorical_cols = [
        "OFFER_DEPT_CODE",
        "OFFER_SCHOOL_NAME",
        "CLUSTER_TYPE",
        "HGN_CODE_DESC",
        "RESPONSIBLE_FACULTY_NAME",
    ]

    # Check for columns that might not exist in the data and remove them from the list
    for df in [train_df, test_df]:
        for col in numerical_cols[:]:
            if col not in df.columns:
                print(
                    f"Warning: Numerical column '{col}' not found. Removing from features."
                )
                numerical_cols.remove(col)
        for col in categorical_cols[:]:
            if col not in df.columns:
                print(
                    f"Warning: Categorical column '{col}' not found. Removing from features."
                )
                categorical_cols.remove(col)

    features = numerical_cols + categorical_cols

    # Align columns and handle categoricals
    for col in categorical_cols:
        all_categories = (
            pd.concat([train_df[col], test_df[col]])
            .astype(str)
            .astype("category")
            .cat.categories
        )
        train_df[col] = pd.Categorical(
            train_df[col].astype(str), categories=all_categories
        )
        test_df[col] = pd.Categorical(
            test_df[col].astype(str), categories=all_categories
        )

    # --- Time-based Validation Split ---
    print("Creating time-based validation split...")

    # Ensure ACADEMIC_YEAR is present and not all null
    if "ACADEMIC_YEAR" in train_df.columns and train_df["ACADEMIC_YEAR"].notna().any():
        latest_year = train_df["ACADEMIC_YEAR"].max()
        print(f"Using academic year {int(latest_year)} for validation.")

        train_indices = train_df["ACADEMIC_YEAR"] < latest_year
        val_indices = train_df["ACADEMIC_YEAR"] == latest_year

        X_train = train_df.loc[train_indices, features]
        y_train = train_df.loc[train_indices, "HIGH_ENROLLMENT"]

        X_val = train_df.loc[val_indices, features]
        y_val = train_df.loc[val_indices, "HIGH_ENROLLMENT"]

        if len(X_val) == 0 or len(X_train) == 0:
            print(
                "Warning: Validation or Training set is empty using time-based split."
            )
            print("Falling back to a random 20% split for validation metric.")
            X_train, X_val, y_train, y_val = train_test_split(
                train_df[features],
                train_df["HIGH_ENROLLMENT"],
                test_size=0.2,
                random_state=42,
                stratify=train_df["HIGH_ENROLLMENT"],
            )
    else:
        print(
            "ACADEMIC_YEAR column not available for time-based split. Falling back to random split."
        )
        X_train, X_val, y_train, y_val = train_test_split(
            train_df[features],
            train_df["HIGH_ENROLLMENT"],
            test_size=0.2,
            random_state=42,
            stratify=train_df["HIGH_ENROLLMENT"],
        )

    print(f"Training set size: {len(X_train)}")
    print(f"Validation set size: {len(X_val)}")

    # --- Model Training & Evaluation ---
    print("Training LightGBM model for validation...")

    lgb_params = {
        "objective": "binary",
        "metric": "binary_logloss",
        "boosting_type": "gbdt",
        "n_estimators": 2000,
        "learning_rate": 0.02,
        "num_leaves": 40,
        "max_depth": 7,
        "seed": 42,
        "n_jobs": -1,
        "verbose": -1,
        "colsample_bytree": 0.7,
        "subsample": 0.7,
        "reg_alpha": 0.1,
        "reg_lambda": 0.1,
    }

    model = lgb.LGBMClassifier(**lgb_params)

    model.fit(
        X_train,
        y_train,
        eval_set=[(X_val, y_val)],
        eval_metric="logloss",
        callbacks=[lgb.early_stopping(100, verbose=False)],
    )

    val_preds = model.predict(X_val)
    macro_f1 = f1_score(y_val, val_preds, average="macro")
    print(f"\nMacro F1 on validation set: {macro_f1:.4f}\n")

    best_iteration = (
        model.best_iteration_
        if model.best_iteration_ is not None and model.best_iteration_ > 0
        else 500
    )

    del X_train, y_train, X_val, y_val, model
    gc.collect()

    # --- Final Training & Test Prediction ---
    print("Training final model on all training data...")

    X_full_train = train_df[features]
    y_full_train = train_df["HIGH_ENROLLMENT"]
    X_test = test_df[features]

    final_model = lgb.LGBMClassifier(**lgb_params)
    final_model.n_estimators = best_iteration
    final_model.fit(X_full_train, y_full_train)

    print("Predicting on test set...")
    test_preds = final_model.predict(X_test)

    # --- Create Submission File ---
    submission_df = test_df[["TERM_CODE", "SUBJECT_ID_SORT"]].copy()
    submission_df["HIGH_ENROLLMENT"] = test_preds
    submission_df["HIGH_ENROLLMENT"] = submission_df["HIGH_ENROLLMENT"].map(
        {1: "yes", 0: "no"}
    )

    submission_path = os.path.join(WORKING_DIR, "submission.csv")
    submission_df.to_csv(submission_path, index=False)

    print(f"Submission file created successfully at {submission_path}")


if __name__ == "__main__":
    main()
