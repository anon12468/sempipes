### Technical Report: Predicting High Course Enrollment

### Introduction

This report outlines the methodology and findings for a project aimed at predicting high course enrollment. The objective is to classify whether a course offered in a specific term will achieve enrollment in the top quartile relative to other courses within the same department and term. The final model is a LightGBM classifier that leverages carefully engineered features to address the relative nature of the prediction target.

### Preprocessing

The initial step involved merging course summary data, historical enrollment features, and academic term information. A key challenge was handling missing data without introducing information leakage from the test set.

-   **Missing Historical Data:** Missing historical enrollment values (`lag1_enrollment`, etc.) were imputed with a placeholder value of -1 to signify the absence of prior data.
-   **Missing Numerical Features:** Other key numerical features, such as `ENROLLMENT_CAP`, were imputed using the median value. To prevent data leakage, this median was calculated *only* from the training dataset and then applied to fill missing values in both the training and test sets.
-   **Categorical Features:** All categorical columns were handled by creating a unified set of categories from both training and test data. This ensures consistent encoding and prevents errors from unseen categories during prediction.

### Modeling Methods

The modeling process focused on feature engineering to capture the contextual nature of the target variable, followed by training a gradient boosting model.

#### Feature Engineering

The primary challenge was that the "high enrollment" label is relative to a course's peers. To address this, several feature sets were developed:

1.  **Context-Aware Features:** This was the most critical step. To model a course's standing within its department and term, percentile rank and z-score were calculated for key numerical attributes like `ENROLLMENT_CAP` and historical enrollment. These transformations were computed by grouping the data by `TERM_CODE` and `OFFER_DEPT_CODE`. Critically, this process was applied independently to the training and test sets to prevent data leakage, where information from the test set would otherwise influence the training features.
2.  **Enrollment Trend Features:** To capture momentum, features were created to represent the difference and ratio between recent historical enrollment figures (e.g., lag-1 vs. lag-2 enrollment).
3.  **Instructor Features:** The historical performance of an instructor was captured by calculating their average past course enrollment and capacity. These statistics were derived solely from the training data and then mapped to both the train and test sets to avoid leakage.

#### Model and Validation

-   **Model:** A LightGBM (LGBM) classifier was selected for its performance and efficiency with tabular data.
-   **Validation Strategy:** A time-based split was used for validation. The model was trained on all academic years except for the most recent one in the training data, which was held out as a validation set. This approach simulates a realistic prediction scenario of forecasting for a future term.
-   **Metric:** The primary evaluation metric was the Macro F1 score, which is suitable for binary classification tasks and accounts for class imbalance.

### Results Discussion

The final model achieved a **Macro F1 score of 0.873** on the time-based validation set.

The development process revealed several key insights. Initial models performed poorly because they used absolute feature values (e.g., `ENROLLMENT_CAP` = 100) to predict a relative target. The introduction of context-aware rank and z-score features provided the most significant performance increase, confirming the initial hypothesis.

Furthermore, rigorous adherence to a leak-free pipeline was crucial. An intermediate version of the model scored a deceptively high 0.8753, but this was later found to be inflated by a data leakage bug where context-aware features were generated using combined train and test data. After correcting this, the score settled at a more realistic and generalizable 0.873. This highlights the importance of independent data processing to obtain a reliable estimate of model performance.

### Future Work

-   **Advanced Feature Engineering:** Investigate interaction features, such as combining instructor performance with department-level statistics. NLP techniques could also be applied to course descriptions to extract topical features.
-   **Model Exploration:** Experiment with other gradient boosting frameworks like CatBoost, which has specialized handling for categorical features, or conduct more extensive hyperparameter tuning on the existing LightGBM model.
-   **Error Analysis:** Perform a detailed analysis of the model's prediction errors to identify specific course types, departments, or terms where performance is weak, guiding future model improvements.