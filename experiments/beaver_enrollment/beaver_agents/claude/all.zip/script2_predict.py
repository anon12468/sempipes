"""
Inference script for high-enrollment prediction.

Usage:
    python predict.py --test_dir <TEST_DATA_DIR> --out <output.csv>

The test directory must contain SUBJECT_OFFERED_SUMMARY.csv with
(TERM_CODE, SUBJECT_ID_SORT) as prediction keys.

Lag features are computed from training history (SUBJECT_SUMMARY.csv
in TRAIN_DIR), so TRAIN_DIR must be accessible.

Output: CSV with columns TERM_CODE, SUBJECT_ID_SORT, HIGH_ENROLLMENT
"""

import argparse
import pickle
from pathlib import Path

import numpy as np
import pandas as pd

TRAIN_DIR = Path("/Users/USER/Documents/UNI/SS26/BEAVER/table_splits/train")
MODEL_PATH = Path("/Users/USER/Documents/UNI/SS26/BEAVER/table_splits/model_lgbm.pkl")

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def parse_term(df):
    tc     = df["TERM_CODE"].str.strip()
    year   = tc.str[:4].astype(int)
    suffix = tc.str[4:]
    season_map = {"FA": 3, "SP": 1, "SU": 2, "JA": 0, "01": 0, "10": 2}
    season = suffix.map(season_map).fillna(1).astype(int)
    df = df.copy()
    df["year"]     = year
    df["season"]   = season
    df["term_ord"] = year * 4 + season
    return df


def extract_course_features(df):
    df   = df.copy()
    subj = df["SUBJECT_ID_SORT"].str.strip()
    num_str = subj.str.extract(r"\.(\d+)")[0]
    df["course_num"]   = pd.to_numeric(num_str, errors="coerce")
    df["course_level"] = (df["course_num"] // 100).fillna(-1).astype(int)
    df["is_grad"]      = ((df["course_num"] >= 6000) |
                          ((df["course_num"] >= 600) & (df["course_num"] < 1000))
                         ).astype(int)
    df["subj_dept"]    = subj.str.extract(r"^([A-Za-z0-9]+)\.?")[0].str.upper()
    return df


# ---------------------------------------------------------------------------
# Load training history for lag feature computation
# ---------------------------------------------------------------------------

def build_enrollment_history(train_dir):
    """
    Build a per-(SUBJECT_ID_SORT, TERM_CODE) enrollment lookup
    from SUBJECT_SUMMARY training data.
    Returns a DataFrame sorted by term_ord.
    """
    ss = pd.read_csv(train_dir / "SUBJECT_SUMMARY.csv",
                     usecols=["TERM_CODE","SUBJECT_ID_SORT",
                               "SUBJECT_ENROLLMENT_FIFTH_WEEK"])
    ss = parse_term(ss)
    ss = ss.sort_values("term_ord").reset_index(drop=True)
    ss["enroll"] = ss["SUBJECT_ENROLLMENT_FIFTH_WEEK"].fillna(0.0)
    return ss[["TERM_CODE","SUBJECT_ID_SORT","term_ord","enroll"]]


def compute_lag_features_for(test_keys, train_history):
    """
    Vectorized computation of lag features for test keys.
    For each (TERM_CODE, SUBJECT_ID_SORT) in test_keys, finds the
    most recent 3 training enrollment values strictly before test term_ord.
    """
    test_keys = test_keys.copy()
    if "term_ord" not in test_keys.columns:
        test_keys = parse_term(test_keys)

    # Sort training history once
    th = train_history.sort_values(["SUBJECT_ID_SORT","term_ord"]).reset_index(drop=True)

    # For each test key, merge on subject then filter by term_ord
    # Strategy: join test_keys with all training rows for same subject,
    # keep only rows with train.term_ord < test.term_ord, take last 3.

    merged = test_keys[["TERM_CODE","SUBJECT_ID_SORT","term_ord"]].merge(
        th[["SUBJECT_ID_SORT","term_ord","enroll"]].rename(
            columns={"term_ord": "train_term_ord", "enroll": "train_enroll"}),
        on="SUBJECT_ID_SORT", how="left"
    )
    # Only keep strictly past training rows
    merged = merged[merged["train_term_ord"] < merged["term_ord"]]

    # Rank from most recent: 1=lag1, 2=lag2, 3=lag3
    merged["rank"] = merged.groupby(["TERM_CODE","SUBJECT_ID_SORT"])["train_term_ord"].rank(
        ascending=False, method="first").astype(int)

    # Pivot lag1, lag2, lag3
    lag1 = merged[merged["rank"]==1].set_index(["TERM_CODE","SUBJECT_ID_SORT"])["train_enroll"].rename("lag1_enrollment")
    lag2 = merged[merged["rank"]==2].set_index(["TERM_CODE","SUBJECT_ID_SORT"])["train_enroll"].rename("lag2_enrollment")
    lag3 = merged[merged["rank"]==3].set_index(["TERM_CODE","SUBJECT_ID_SORT"])["train_enroll"].rename("lag3_enrollment")

    result = test_keys[["TERM_CODE","SUBJECT_ID_SORT"]].set_index(["TERM_CODE","SUBJECT_ID_SORT"])
    result = result.join(lag1).join(lag2).join(lag3)
    result["lag1_enrollment"] = result["lag1_enrollment"].fillna(0.0)
    result["lag2_enrollment"] = result["lag2_enrollment"].fillna(0.0)
    result["lag3_enrollment"] = result.get("lag3_enrollment", 0.0)
    result["roll3_enrollment_mean"] = (
        result["lag1_enrollment"].fillna(0) +
        result["lag2_enrollment"].fillna(0) +
        result.get("lag3_enrollment", pd.Series(0.0, index=result.index)).fillna(0)
    ) / 3.0

    return result.reset_index()[["TERM_CODE","SUBJECT_ID_SORT","lag1_enrollment","lag2_enrollment","roll3_enrollment_mean"]]


def build_historical_rates(train_dir):
    """
    Load training gold labels and compute per-subject / per-dept
    historical high-enrollment rates (using all training data as history
    for test-time predictions).
    """
    gold = pd.read_csv(train_dir / "gold_enrollment_train.csv")
    gold["label_bin"] = (gold["HIGH_ENROLLMENT"] == "Y").astype(int)

    # Per subject
    subj_rate = gold.groupby("SUBJECT_ID_SORT")["label_bin"].mean().rename("hist_he_rate")
    subj_cnt  = gold.groupby("SUBJECT_ID_SORT")["label_bin"].count().rename("hist_he_count")

    # Per master subject (from SOS)
    sos = pd.read_csv(train_dir / "SUBJECT_OFFERED_SUMMARY.csv",
                      usecols=["TERM_CODE","SUBJECT_ID_SORT","MASTER_SUBJECT_ID_SORT","OFFER_DEPT_CODE"])
    sos = sos.drop_duplicates(["TERM_CODE","SUBJECT_ID_SORT"])
    gold_sos = gold.merge(sos, on=["TERM_CODE","SUBJECT_ID_SORT"], how="left")
    gold_sos["OFFER_DEPT_CODE"]   = gold_sos["OFFER_DEPT_CODE"].fillna("UNKNOWN")
    gold_sos["MASTER_SUBJECT_ID_SORT"] = gold_sos["MASTER_SUBJECT_ID_SORT"].fillna(gold_sos["SUBJECT_ID_SORT"])

    master_rate = gold_sos.groupby("MASTER_SUBJECT_ID_SORT")["label_bin"].mean().rename("hist_mhe_rate")
    dept_rate   = gold_sos.groupby("OFFER_DEPT_CODE")["label_bin"].mean().rename("hist_dept_he_rate")

    # Per subj_dept
    gold["subj_dept"] = gold["SUBJECT_ID_SORT"].str.extract(r"^([A-Za-z0-9]+)\.?")[0].str.upper()
    sdept_rate = gold.groupby("subj_dept")["label_bin"].mean().rename("hist_sdept_he_rate")

    # Per subject lag1 mean (from enrollment history)
    hist = pd.read_csv(train_dir / "ENROLLMENT_HISTORY_FEATURES.csv")
    lag1_mean = hist.groupby("SUBJECT_ID_SORT")["lag1_enrollment"].mean().rename("hist_lag1_mean")

    return subj_rate, subj_cnt, master_rate, dept_rate, sdept_rate, lag1_mean


def build_lag1_dept_pct_mean(train_dir):
    """
    Historical mean of within-dept percentile rank for lag1 enrollment per subject.
    """
    hist = pd.read_csv(train_dir / "ENROLLMENT_HISTORY_FEATURES.csv")
    sos  = pd.read_csv(train_dir / "SUBJECT_OFFERED_SUMMARY.csv",
                       usecols=["TERM_CODE","SUBJECT_ID_SORT","OFFER_DEPT_CODE"])
    sos  = sos.drop_duplicates(["TERM_CODE","SUBJECT_ID_SORT"])
    hist = hist.merge(sos, on=["TERM_CODE","SUBJECT_ID_SORT"], how="left")
    hist["OFFER_DEPT_CODE"] = hist["OFFER_DEPT_CODE"].fillna("UNKNOWN")

    hist["lag1_dept_pct"] = hist.groupby(["TERM_CODE","OFFER_DEPT_CODE"])["lag1_enrollment"].rank(pct=True)
    pct_mean = hist.groupby("SUBJECT_ID_SORT")["lag1_dept_pct"].mean().rename("hist_lag1_dept_pct_mean")
    return pct_mean


# ---------------------------------------------------------------------------
# Main predict function
# ---------------------------------------------------------------------------

def predict(test_dir: Path, out_path: Path):
    # Load model
    with open(MODEL_PATH, "rb") as f:
        bundle = pickle.load(f)
    model     = bundle["model"]
    FEATURES  = bundle["features"]
    threshold = bundle["threshold"]

    print(f"Loaded model. Features: {len(FEATURES)}, threshold: {threshold:.3f}")

    # Load test prediction keys from SUBJECT_OFFERED_SUMMARY
    if test_dir is not None and (test_dir / "SUBJECT_OFFERED_SUMMARY.csv").exists():
        sos_test = pd.read_csv(test_dir / "SUBJECT_OFFERED_SUMMARY.csv",
                               usecols=["TERM_CODE","SUBJECT_ID_SORT","MASTER_SUBJECT_ID_SORT",
                                        "CLUSTER_TYPE","HGN_CODE","OFFER_DEPT_CODE",
                                        "OFFER_SCHOOL_NAME","TOTAL_UNITS","LECTURE_UNITS",
                                        "LAB_UNITS","PREPARATION_UNITS"])
    else:
        raise FileNotFoundError("SUBJECT_OFFERED_SUMMARY.csv not found in test_dir")

    test_keys = sos_test[["TERM_CODE","SUBJECT_ID_SORT"]].drop_duplicates()
    print(f"Test rows: {len(test_keys)}")

    # -----------------------------------------------------------------------
    # Compute lag features
    # -----------------------------------------------------------------------
    print("Computing lag features from training history...")
    train_history = build_enrollment_history(TRAIN_DIR)
    lag_feats = compute_lag_features_for(test_keys, train_history)

    # -----------------------------------------------------------------------
    # Build feature dataframe
    # -----------------------------------------------------------------------

    df = test_keys.copy()
    df = parse_term(df)
    df = extract_course_features(df)
    df["COURSE_NUMBER"] = df["subj_dept"]

    # Merge lag features
    df = df.merge(lag_feats, on=["TERM_CODE","SUBJECT_ID_SORT"], how="left")
    for col in ["lag1_enrollment","lag2_enrollment","roll3_enrollment_mean"]:
        df[col] = df[col].fillna(0.0)

    # Merge course attributes from test SOS
    sos_test = sos_test.drop_duplicates(["TERM_CODE","SUBJECT_ID_SORT"])
    df = df.merge(sos_test, on=["TERM_CODE","SUBJECT_ID_SORT"], how="left")
    for col in ["TOTAL_UNITS","LECTURE_UNITS","LAB_UNITS","PREPARATION_UNITS"]:
        df[col] = df[col].fillna(0.0)

    # Within-test-term dept percentile of lag1
    dept_col = "OFFER_DEPT_CODE"
    df[dept_col] = df[dept_col].fillna(df["subj_dept"])
    df["lag1_dept_pct"] = df.groupby(["TERM_CODE", dept_col])["lag1_enrollment"].rank(pct=True)
    df["roll3_dept_pct"] = df.groupby(["TERM_CODE", dept_col])["roll3_enrollment_mean"].rank(pct=True)
    df["lag1_positive"]  = (df["lag1_enrollment"]       > 0).astype(int)
    df["roll3_positive"] = (df["roll3_enrollment_mean"] > 0).astype(int)
    df["lag1_top25_dept"] = (df["lag1_dept_pct"] >= 0.75).astype(int)

    # Merge historical rates (computed on all training data)
    print("Building historical rates from training labels...")
    subj_rate, subj_cnt, master_rate, dept_rate, sdept_rate, lag1_mean = build_historical_rates(TRAIN_DIR)
    pct_mean = build_lag1_dept_pct_mean(TRAIN_DIR)

    df["hist_he_rate"]  = df["SUBJECT_ID_SORT"].map(subj_rate).fillna(0.0)
    df["hist_he_count"] = df["SUBJECT_ID_SORT"].map(subj_cnt).fillna(0.0)

    mast_col = "MASTER_SUBJECT_ID_SORT" if "MASTER_SUBJECT_ID_SORT" in df.columns else "SUBJECT_ID_SORT"
    df["hist_mhe_rate"] = df[mast_col].map(master_rate).fillna(0.0)

    df["hist_dept_he_rate"]    = df[dept_col].map(dept_rate).fillna(0.1)
    df["hist_sdept_he_rate"]   = df["subj_dept"].map(sdept_rate).fillna(0.0)
    df["hist_lag1_mean"]       = df["SUBJECT_ID_SORT"].map(lag1_mean).fillna(0.0)
    df["hist_lag1_dept_pct_mean"] = df["SUBJECT_ID_SORT"].map(pct_mean).fillna(0.0)

    # Section counts (if test_dir has SUBJECT_OFFERED)
    so_path = test_dir / "SUBJECT_OFFERED.csv" if test_dir else None
    if so_path and so_path.exists():
        so_test = pd.read_csv(so_path, usecols=["TERM_CODE","SUBJECT_ID_SORT","MASTER_SUBJECT_ID_SORT",
                                                  "IS_LECTURE_SECTION","IS_LAB_SECTION","IS_RECITATION_SECTION"])
        so_test["is_lecture"]    = (so_test["IS_LECTURE_SECTION"]    == "Y").astype(int)
        so_test["is_lab"]        = (so_test["IS_LAB_SECTION"]        == "Y").astype(int)
        so_test["is_recitation"] = (so_test["IS_RECITATION_SECTION"] == "Y").astype(int)
        sc = so_test.groupby(["TERM_CODE","MASTER_SUBJECT_ID_SORT"], as_index=False).agg(
            n_lecture=("is_lecture","sum"), n_lab=("is_lab","sum"), n_recitation=("is_recitation","sum"))
        df = df.merge(sc, on=["TERM_CODE","MASTER_SUBJECT_ID_SORT"], how="left")
    for c in ["n_lecture","n_lab","n_recitation"]:
        if c not in df.columns:
            df[c] = 0
        df[c] = df[c].fillna(0).astype(int)

    # Degree level
    scd = pd.read_csv(TRAIN_DIR / "SIS_COURSE_DESCRIPTION.csv",
                      usecols=["COURSE","COURSE_LEVEL","IS_DEGREE_GRANTING","GRADUATE_LEVEL"])
    scd = scd.rename(columns={"COURSE": "COURSE_NUMBER"})
    scd["COURSE_NUMBER"] = scd["COURSE_NUMBER"].astype(str).str.strip()
    scd = scd.drop_duplicates("COURSE_NUMBER")
    df = df.merge(scd[["COURSE_NUMBER","COURSE_LEVEL","IS_DEGREE_GRANTING","GRADUATE_LEVEL"]],
                  on="COURSE_NUMBER", how="left")

    # Categorical encoding
    cat_cols = ["CLUSTER_TYPE","HGN_CODE","OFFER_DEPT_CODE","OFFER_SCHOOL_NAME",
                "subj_dept","COURSE_LEVEL","IS_DEGREE_GRANTING","GRADUATE_LEVEL"]
    for c in cat_cols:
        if c not in df.columns:
            df[c] = "UNK"
        df[c] = df[c].fillna("UNK").astype("category")

    # -----------------------------------------------------------------------
    # Predict
    # -----------------------------------------------------------------------

    X = df[FEATURES]
    probs = model.predict_proba(X)[:, 1]
    labels = np.where(probs >= threshold, "Y", "N")

    out = df[["TERM_CODE","SUBJECT_ID_SORT"]].copy()
    out["HIGH_ENROLLMENT"] = labels
    out["PRED_PROB"]       = probs

    out.to_csv(out_path, index=False)
    print(f"Saved {len(out)} predictions to {out_path}")
    print(f"Y rate: {(labels == 'Y').mean():.3f}")
    return out


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--test_dir", required=True)
    parser.add_argument("--out", default="predictions.csv")
    args = parser.parse_args()

    predict(Path(args.test_dir), Path(args.out))
