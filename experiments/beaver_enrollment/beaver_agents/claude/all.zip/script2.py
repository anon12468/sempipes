"""
High-enrollment prediction for course offerings.
Target: HIGH_ENROLLMENT (Y/N) = top quartile by enrollment within dept+term,
        among courses with positive enrollment.
~8% are Y because only ~29% of courses have positive enrollment.
"""

import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.metrics import f1_score
import lightgbm as lgb
import pickle

TRAIN_DIR = Path("/Users/USER/Documents/UNI/SS26/BEAVER/table_splits/train")
OUT_DIR   = Path("/Users/USER/Documents/UNI/SS26/BEAVER/table_splits")

# ---------------------------------------------------------------------------
# 1. Load base tables
# ---------------------------------------------------------------------------

gold = pd.read_csv(TRAIN_DIR / "gold_enrollment_train.csv")
hist = pd.read_csv(TRAIN_DIR / "ENROLLMENT_HISTORY_FEATURES.csv")
sos  = pd.read_csv(TRAIN_DIR / "SUBJECT_OFFERED_SUMMARY.csv",
                   usecols=["TERM_CODE","SUBJECT_ID_SORT","MASTER_SUBJECT_ID_SORT",
                             "CLUSTER_TYPE","HGN_CODE","OFFER_DEPT_CODE",
                             "OFFER_SCHOOL_NAME","TOTAL_UNITS","LECTURE_UNITS",
                             "LAB_UNITS","PREPARATION_UNITS"])

# Section counts per master subject
so_all = pd.read_csv(TRAIN_DIR / "SUBJECT_OFFERED.csv",
                     usecols=["TERM_CODE","SUBJECT_ID_SORT","MASTER_SUBJECT_ID_SORT",
                               "IS_LECTURE_SECTION","IS_LAB_SECTION","IS_RECITATION_SECTION"])
so_all["is_lecture"]    = (so_all["IS_LECTURE_SECTION"]    == "Y").astype(int)
so_all["is_lab"]        = (so_all["IS_LAB_SECTION"]        == "Y").astype(int)
so_all["is_recitation"] = (so_all["IS_RECITATION_SECTION"] == "Y").astype(int)
section_counts = so_all.groupby(["TERM_CODE","MASTER_SUBJECT_ID_SORT"], as_index=False).agg(
    n_lecture=("is_lecture","sum"),
    n_lab=("is_lab","sum"),
    n_recitation=("is_recitation","sum"),
)

# Course degree level
scd = pd.read_csv(TRAIN_DIR / "SIS_COURSE_DESCRIPTION.csv",
                  usecols=["COURSE","COURSE_LEVEL","IS_DEGREE_GRANTING","GRADUATE_LEVEL"])
scd = scd.rename(columns={"COURSE": "COURSE_NUMBER"})
scd["COURSE_NUMBER"] = scd["COURSE_NUMBER"].astype(str).str.strip()

print(f"Gold: {gold.shape}  Hist: {hist.shape}  SOS: {sos.shape}")

# ---------------------------------------------------------------------------
# 2. Parse term code → year + season
# ---------------------------------------------------------------------------

def parse_term(df):
    tc     = df["TERM_CODE"].str.strip()
    year   = tc.str[:4].astype(int)
    suffix = tc.str[4:]
    season_map = {"FA": 3, "SP": 1, "SU": 2, "JA": 0, "01": 0, "10": 2}
    season = suffix.map(season_map).fillna(1).astype(int)
    df = df.copy()
    df["year"]     = year
    df["season"]   = season
    df["term_ord"] = year * 4 + season
    return df

gold = parse_term(gold)

# ---------------------------------------------------------------------------
# 3. Extract course features from SUBJECT_ID_SORT
# ---------------------------------------------------------------------------

def extract_course_features(df):
    df = df.copy()
    subj = df["SUBJECT_ID_SORT"].str.strip()
    num_str = subj.str.extract(r"\.(\d+)")[0]
    df["course_num"]   = pd.to_numeric(num_str, errors="coerce")
    df["course_level"] = (df["course_num"] // 100).fillna(-1).astype(int)
    df["is_grad"]      = ((df["course_num"] >= 6000) |
                          ((df["course_num"] >= 600) & (df["course_num"] < 1000))
                         ).astype(int)
    df["subj_dept"] = subj.str.extract(r"^([A-Za-z0-9]+)\.?")[0].str.upper()
    return df

gold = extract_course_features(gold)
gold["COURSE_NUMBER"] = gold["subj_dept"]   # for SIS join

# ---------------------------------------------------------------------------
# 4. Merge lag/historical enrollment features
# ---------------------------------------------------------------------------

gold = gold.merge(hist, on=["TERM_CODE","SUBJECT_ID_SORT"], how="left")

# ---------------------------------------------------------------------------
# 5. Merge course attributes
# ---------------------------------------------------------------------------

sos = sos.drop_duplicates(subset=["TERM_CODE","SUBJECT_ID_SORT"])
gold = gold.merge(sos, on=["TERM_CODE","SUBJECT_ID_SORT"], how="left")

# Section counts via MASTER_SUBJECT_ID_SORT
if "MASTER_SUBJECT_ID_SORT" in gold.columns:
    gold = gold.merge(section_counts, on=["TERM_CODE","MASTER_SUBJECT_ID_SORT"], how="left")
    for c in ["n_lecture","n_lab","n_recitation"]:
        gold[c] = gold[c].fillna(0).astype(int)

# Degree level
scd_clean = scd.drop_duplicates("COURSE_NUMBER")
gold = gold.merge(scd_clean[["COURSE_NUMBER","COURSE_LEVEL","IS_DEGREE_GRANTING","GRADUATE_LEVEL"]],
                  on="COURSE_NUMBER", how="left")

# Fill missing numeric
for col in ["lag1_enrollment","lag2_enrollment","roll3_enrollment_mean",
            "TOTAL_UNITS","LECTURE_UNITS","LAB_UNITS","PREPARATION_UNITS"]:
    gold[col] = gold[col].fillna(0.0)

print("After merges:", gold.shape)

# ---------------------------------------------------------------------------
# 6. Key features: within-dept lag enrollment percentile
#    For each (TERM_CODE, DEPT), compute lag1 rank among peers.
#    This mirrors how the label is computed but using lagged data.
# ---------------------------------------------------------------------------

dept_col = "OFFER_DEPT_CODE"
gold[dept_col] = gold[dept_col].fillna(gold["subj_dept"])

def dept_percentile_of(df, enroll_col, dept_col, out_col):
    """Percentile rank of enroll_col within dept+term group."""
    def pct_rank(g):
        return g[enroll_col].rank(pct=True)
    df[out_col] = df.groupby(["TERM_CODE", dept_col], group_keys=False).apply(pct_rank)
    return df

gold = dept_percentile_of(gold, "lag1_enrollment",       dept_col, "lag1_dept_pct")
gold = dept_percentile_of(gold, "roll3_enrollment_mean", dept_col, "roll3_dept_pct")

# Binary: was lag1 > 0 (had any enrollment last term)
gold["lag1_positive"]       = (gold["lag1_enrollment"] > 0).astype(int)
gold["roll3_positive"]      = (gold["roll3_enrollment_mean"] > 0).astype(int)

# Is lag1 in top quartile of dept? (mirroring the label definition)
gold["lag1_top25_dept"] = (gold["lag1_dept_pct"] >= 0.75).astype(int)

# ---------------------------------------------------------------------------
# 7. Historical high-enrollment rates (leakage-safe, expanding shift-1)
# ---------------------------------------------------------------------------

gold = gold.sort_values("term_ord").reset_index(drop=True)
gold["label_bin"] = (gold["HIGH_ENROLLMENT"] == "Y").astype(int)

def expanding_mean_shift1(df, group_col, target_col):
    grp = df.groupby(group_col)[target_col]
    rate  = grp.transform(lambda x: x.shift(1).expanding().mean()).fillna(0.0)
    count = grp.transform(lambda x: x.shift(1).expanding().count()).fillna(0.0)
    return rate, count

gold["hist_he_rate"], gold["hist_he_count"] = expanding_mean_shift1(gold, "SUBJECT_ID_SORT",       "label_bin")
gold["hist_mhe_rate"], _                    = expanding_mean_shift1(gold, "MASTER_SUBJECT_ID_SORT", "label_bin")
gold["hist_dept_he_rate"], _               = expanding_mean_shift1(gold, dept_col,                 "label_bin")
gold["hist_dept_he_rate"]                  = gold["hist_dept_he_rate"].fillna(0.1)
gold["hist_sdept_he_rate"], _              = expanding_mean_shift1(gold, "subj_dept",               "label_bin")

# Expanding mean of lag1 enrollment per subject (proxy for true enrollment)
gold["hist_lag1_mean"], _ = expanding_mean_shift1(gold, "SUBJECT_ID_SORT", "lag1_enrollment")

# Expanding mean of dept percentile per subject
gold["hist_lag1_dept_pct_mean"], _ = expanding_mean_shift1(gold, "SUBJECT_ID_SORT", "lag1_dept_pct")

# ---------------------------------------------------------------------------
# 8. Categorical encoding
# ---------------------------------------------------------------------------

cat_cols = ["CLUSTER_TYPE","HGN_CODE","OFFER_DEPT_CODE","OFFER_SCHOOL_NAME",
            "subj_dept","COURSE_LEVEL","IS_DEGREE_GRANTING","GRADUATE_LEVEL"]
for c in cat_cols:
    if c not in gold.columns:
        gold[c] = "UNK"
    gold[c] = gold[c].fillna("UNK").astype("category")

# ---------------------------------------------------------------------------
# 9. Feature matrix
# ---------------------------------------------------------------------------

FEATURES = [
    # Lag enrollment (raw)
    "lag1_enrollment","lag2_enrollment","roll3_enrollment_mean",
    # Lag enrollment (within-dept percentile) — mirrors label computation
    "lag1_dept_pct","roll3_dept_pct",
    "lag1_positive","roll3_positive","lag1_top25_dept",
    # Historical high-enrollment rates (leakage-safe)
    "hist_he_rate","hist_he_count","hist_mhe_rate",
    "hist_dept_he_rate","hist_sdept_he_rate",
    "hist_lag1_mean","hist_lag1_dept_pct_mean",
    # Time
    "year","season","term_ord",
    # Course attributes
    "course_num","course_level","is_grad",
    "TOTAL_UNITS","LECTURE_UNITS","LAB_UNITS","PREPARATION_UNITS",
    # Section counts
    "n_lecture","n_lab","n_recitation",
    # Categorical
    "CLUSTER_TYPE","HGN_CODE","OFFER_DEPT_CODE","OFFER_SCHOOL_NAME","subj_dept",
    "COURSE_LEVEL","IS_DEGREE_GRANTING","GRADUATE_LEVEL",
]

FEATURES = [f for f in FEATURES if f in gold.columns]
print("Features used:", len(FEATURES))

X = gold[FEATURES]
y = gold["label_bin"]

# ---------------------------------------------------------------------------
# 10. Time-based train/val split (hold out 2017+)
# ---------------------------------------------------------------------------

val_mask   = gold["year"] >= 2017
train_mask = ~val_mask

X_train, y_train = X[train_mask], y[train_mask]
X_val,   y_val   = X[val_mask],   y[val_mask]

print(f"Train: {train_mask.sum()} | Val: {val_mask.sum()}")

# ---------------------------------------------------------------------------
# 11. Train LightGBM
# ---------------------------------------------------------------------------

lgb_params = dict(
    objective="binary",
    metric="binary_logloss",
    n_estimators=2000,
    learning_rate=0.03,
    num_leaves=127,
    min_child_samples=20,
    feature_fraction=0.8,
    bagging_fraction=0.8,
    bagging_freq=5,
    reg_alpha=0.05,
    reg_lambda=0.1,
    verbose=-1,
    n_jobs=-1,
    class_weight="balanced",
)

model = lgb.LGBMClassifier(**lgb_params)
model.fit(
    X_train, y_train,
    eval_set=[(X_val, y_val)],
    callbacks=[lgb.early_stopping(150, verbose=False), lgb.log_evaluation(200)],
)

# ---------------------------------------------------------------------------
# 12. Evaluate
# ---------------------------------------------------------------------------

val_probs = model.predict_proba(X_val)[:, 1]

best_f1, best_thr = 0, 0.5
for thr in np.arange(0.05, 0.95, 0.005):
    preds = (val_probs >= thr).astype(int)
    f1 = f1_score(y_val, preds, average="macro", zero_division=0)
    if f1 > best_f1:
        best_f1, best_thr = f1, thr

val_preds = (val_probs >= best_thr).astype(int)
print(f"\nVal macro F1: {best_f1:.4f}  (threshold={best_thr:.3f})")
per_class = f1_score(y_val, val_preds, average=None, zero_division=0)
print(f"F1 per class [N, Y]: {per_class}")
print(f"Iterations: {model.best_iteration_}")

fi = pd.Series(model.feature_importances_, index=FEATURES).sort_values(ascending=False)
print("\nTop 15 feature importances:")
print(fi.head(15).to_string())

# ---------------------------------------------------------------------------
# 13. Retrain on full data
# ---------------------------------------------------------------------------

print("\nRetraining on full dataset...")
model_final = lgb.LGBMClassifier(**{**lgb_params, "n_estimators": model.best_iteration_ + 100})
model_final.fit(X, y)

with open(OUT_DIR / "model_lgbm.pkl", "wb") as f:
    pickle.dump({"model": model_final, "features": FEATURES, "threshold": best_thr}, f)
print(f"Saved: {OUT_DIR / 'model_lgbm.pkl'}")

# Save val predictions
gold_val = gold[val_mask].copy()
gold_val["PRED_PROB"]            = val_probs
gold_val["PRED_HIGH_ENROLLMENT"] = np.where(val_probs >= best_thr, "Y", "N")
gold_val[["TERM_CODE","SUBJECT_ID_SORT","HIGH_ENROLLMENT",
          "PRED_HIGH_ENROLLMENT","PRED_PROB"]].to_csv(
    OUT_DIR / "val_predictions.csv", index=False
)

print(f"\nSummary: Val macro F1 = {best_f1:.4f}, threshold = {best_thr:.3f}, iter = {model.best_iteration_}")
