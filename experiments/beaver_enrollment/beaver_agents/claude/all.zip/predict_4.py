"""
Prediction script for high-enrollment classification.
Usage: python predict.py --test_dir <TEST_DATA_DIR> --out <output.csv>
If --test_dir is not provided, predicts on train data as a sanity-check.
"""

import os
import re
import pickle
import argparse
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

TRAIN_DIR = "/Users/USER/Documents/UNI/SS26/BEAVER/table_splits/train"
MODEL_PATH = "/Users/USER/Documents/UNI/SS26/BEAVER/table_splits/lgbm_model.pkl"


# ─── helpers (must match train_model.py) ──────────────────────────────────────

def term_sort_key(term_code):
    season_map = {"JA": 1, "SP": 2, "SU": 3, "FA": 4}
    m = re.match(r"(\d{4})([A-Z]+)", str(term_code))
    if m:
        return int(m.group(1)) * 10 + season_map.get(m.group(2), 0)
    return int(str(term_code)[:4]) * 10


def parse_term(term_code):
    m = re.match(r"(\d{4})([A-Z]+)", str(term_code))
    if m:
        return int(m.group(1)), m.group(2)
    return int(str(term_code)[:4]), "UN"


def extract_course_features(df):
    df["course_prefix"] = df["SUBJECT_ID_SORT"].str.split(".").str[0]
    df["course_number_str"] = df["SUBJECT_ID_SORT"].str.split(".").str[-1]
    df["course_num_numeric"] = pd.to_numeric(
        df["course_number_str"].str.extract(r"(\d+)")[0], errors="coerce"
    )
    df["is_grad_level_num"] = (df["course_num_numeric"] >= 500).astype(int)
    parsed = df["TERM_CODE"].apply(parse_term)
    df["term_year"] = parsed.apply(lambda x: x[0])
    df["term_season"] = parsed.apply(lambda x: x[1])
    return df


def build_features(keys_df, test_dir, train_dir=TRAIN_DIR):
    """
    Build the feature matrix for rows in keys_df (columns: TERM_CODE, SUBJECT_ID_SORT).
    Joins against tables in test_dir (if provided) and falls back to train_dir
    for historical reference tables.
    """
    df = keys_df.copy()
    df = extract_course_features(df)

    # ── lag enrollment ────────────────────────────────────────────────────────
    # Try test dir first, fall back to train
    for d in ([test_dir] if test_dir else []) + [train_dir]:
        p = os.path.join(d, "ENROLLMENT_HISTORY_FEATURES.csv")
        if os.path.exists(p):
            ehf = pd.read_csv(p)
            df = df.merge(
                ehf[["TERM_CODE", "SUBJECT_ID_SORT",
                      "lag1_enrollment", "lag2_enrollment", "roll3_enrollment_mean"]],
                on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left"
            )
            break

    # ── offered summary ───────────────────────────────────────────────────────
    sos_cols = [
        "TERM_CODE", "SUBJECT_ID_SORT",
        "OFFER_DEPT_CODE", "OFFER_SCHOOL_NAME", "CLUSTER_TYPE",
        "HGN_CODE", "HGN_CODE_DESC",
        "TOTAL_UNITS", "LECTURE_UNITS", "LAB_UNITS", "PREPARATION_UNITS",
        "RESPONSIBLE_FACULTY_NAME",
    ]
    for d in ([test_dir] if test_dir else []) + [train_dir]:
        p = os.path.join(d, "SUBJECT_OFFERED_SUMMARY.csv")
        if os.path.exists(p):
            sos = pd.read_csv(p)
            avail = [c for c in sos_cols if c in sos.columns]
            df = df.merge(sos[avail], on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")
            break

    # ── subject history stats (from train only, no leakage) ──────────────────
    ss = pd.read_csv(os.path.join(train_dir, "SUBJECT_SUMMARY.csv"))
    ss_work = ss[["TERM_CODE", "SUBJECT_ID_SORT",
                   "SUBJECT_ENROLLMENT_FIFTH_WEEK",
                   "DEPARTMENT_CODE"]].copy()
    ss_work["term_sort"] = ss_work["TERM_CODE"].apply(term_sort_key)
    ss_work = ss_work.sort_values("term_sort")

    # Expanding stats (shift(1) so current term not included)
    ss_work["subj_hist_mean_enroll"] = (
        ss_work.groupby("SUBJECT_ID_SORT")["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
        .transform(lambda x: x.shift(1).expanding().mean())
    )
    ss_work["subj_hist_count"] = (
        ss_work.groupby("SUBJECT_ID_SORT")["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
        .transform(lambda x: x.shift(1).expanding().count())
    )

    # For test terms not in train, use the full train mean as fallback
    subj_all_mean = (
        ss_work.groupby("SUBJECT_ID_SORT")["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
        .mean().rename("subj_all_time_mean")
    )
    subj_all_count = (
        ss_work.groupby("SUBJECT_ID_SORT")["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
        .count().rename("subj_all_time_count")
    )

    df = df.merge(
        ss_work[["TERM_CODE", "SUBJECT_ID_SORT",
                  "subj_hist_mean_enroll", "subj_hist_count"]],
        on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left"
    )
    # For test rows (no train term match), fill with all-time mean
    df = df.merge(subj_all_mean, on="SUBJECT_ID_SORT", how="left")
    df = df.merge(subj_all_count, on="SUBJECT_ID_SORT", how="left")
    df["subj_hist_mean_enroll"] = df["subj_hist_mean_enroll"].fillna(df["subj_all_time_mean"])
    df["subj_hist_count"] = df["subj_hist_count"].fillna(df["subj_all_time_count"]).fillna(0)
    df = df.drop(columns=["subj_all_time_mean", "subj_all_time_count"], errors="ignore")

    # ── dept historical stats ─────────────────────────────────────────────────
    dept_term = (
        ss.groupby(["TERM_CODE", "DEPARTMENT_CODE"])
        ["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
        .agg(["mean", "median", "count"])
        .rename(columns={"mean": "dept_term_mean_enroll",
                         "median": "dept_term_median_enroll",
                         "count": "dept_term_n_courses"})
        .reset_index()
    )
    dept_term["term_sort"] = dept_term["TERM_CODE"].apply(term_sort_key)
    dept_term = dept_term.sort_values("term_sort")
    dept_term["dept_prev_mean"] = dept_term.groupby("DEPARTMENT_CODE")["dept_term_mean_enroll"].shift(1)
    dept_term["dept_prev_median"] = dept_term.groupby("DEPARTMENT_CODE")["dept_term_median_enroll"].shift(1)
    dept_term["dept_prev_n_courses"] = dept_term.groupby("DEPARTMENT_CODE")["dept_term_n_courses"].shift(1)

    # For test terms, we need to join on OFFER_DEPT_CODE.
    # First try exact term match; for new terms use most recent dept stats.
    dept_feat = dept_term[["TERM_CODE", "DEPARTMENT_CODE",
                            "dept_prev_mean", "dept_prev_median",
                            "dept_prev_n_courses"]].rename(
        columns={"DEPARTMENT_CODE": "OFFER_DEPT_CODE"})

    df = df.merge(dept_feat, on=["TERM_CODE", "OFFER_DEPT_CODE"], how="left")

    # Fallback for test terms: use overall dept mean
    dept_overall = (
        ss.groupby("DEPARTMENT_CODE")["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
        .agg(mean="mean", median="median", count="count")
        .reset_index()
        .rename(columns={
            "DEPARTMENT_CODE": "OFFER_DEPT_CODE",
            "mean": "dept_fb_mean",
            "median": "dept_fb_median",
            "count": "dept_fb_n",
        })
    )
    df = df.merge(dept_overall, on="OFFER_DEPT_CODE", how="left")
    df["dept_prev_mean"] = df["dept_prev_mean"].fillna(df["dept_fb_mean"])
    df["dept_prev_median"] = df["dept_prev_median"].fillna(df["dept_fb_median"])
    df["dept_prev_n_courses"] = df["dept_prev_n_courses"].fillna(df["dept_fb_n"])
    df = df.drop(columns=["dept_fb_mean", "dept_fb_median", "dept_fb_n"], errors="ignore")

    # ── DRUPAL catalog ────────────────────────────────────────────────────────
    drupal = pd.read_csv(os.path.join(train_dir, "DRUPAL_COURSE_CATALOG.csv"), low_memory=False)
    drupal["SUBJECT_ID_SORT"] = (
        drupal["SUBJECT_CODE"].astype(str) + "." + drupal["SUBJECT_NUMBER"].astype(str)
    )
    catalog_cols = [
        "SUBJECT_ID_SORT", "GRADE_TYPE", "GRADE_RULE", "HGN_CODE",
        "GIR_ATTRIBUTE", "COMM_REQ_ATTRIBUTE", "HASS_ATTRIBUTE",
        "IS_OFFERED_FALL_TERM", "IS_OFFERED_SPRING_TERM",
        "IS_OFFERED_IAP", "IS_OFFERED_SUMMER_TERM", "TOTAL_UNITS",
    ]
    catalog_cols = [c for c in catalog_cols if c in drupal.columns]
    drupal_dedup = (drupal.sort_values("ACADEMIC_YEAR", ascending=False)
                    .drop_duplicates("SUBJECT_ID_SORT")[catalog_cols]
                    .rename(columns={"TOTAL_UNITS": "catalog_total_units",
                                     "HGN_CODE": "catalog_hgn_code"}))
    df = df.merge(drupal_dedup, on="SUBJECT_ID_SORT", how="left")

    # ── relative features ─────────────────────────────────────────────────────
    df["lag1_vs_dept"] = df["lag1_enrollment"] / (df["dept_prev_mean"] + 1)
    df["lag1_vs_hist"] = df["lag1_enrollment"] / (df["subj_hist_mean_enroll"] + 1)

    # ── categorical encoding ──────────────────────────────────────────────────
    cat_cols = [
        "OFFER_DEPT_CODE", "OFFER_SCHOOL_NAME", "CLUSTER_TYPE",
        "HGN_CODE", "HGN_CODE_DESC", "term_season", "course_prefix",
        "GRADE_TYPE", "GRADE_RULE", "GIR_ATTRIBUTE", "COMM_REQ_ATTRIBUTE",
        "HASS_ATTRIBUTE", "catalog_hgn_code",
        "IS_OFFERED_FALL_TERM", "IS_OFFERED_SPRING_TERM",
        "IS_OFFERED_IAP", "IS_OFFERED_SUMMER_TERM",
        "RESPONSIBLE_FACULTY_NAME",
    ]
    for col in cat_cols:
        if col in df.columns:
            df[col] = df[col].astype("category")

    return df


def predict(keys_df, test_dir=None, train_dir=TRAIN_DIR, model_path=MODEL_PATH):
    """Predict HIGH_ENROLLMENT for given (TERM_CODE, SUBJECT_ID_SORT) keys."""
    with open(model_path, "rb") as f:
        bundle = pickle.load(f)
    model = bundle["model"]
    features = bundle["features"]
    threshold = bundle["threshold"]

    df = build_features(keys_df, test_dir=test_dir, train_dir=train_dir)

    available = [f for f in features if f in df.columns]
    missing = [f for f in features if f not in df.columns]
    if missing:
        print(f"WARNING: missing features (filling with NaN): {missing}")
        for f in missing:
            df[f] = np.nan

    X = df[features]
    proba = model.predict_proba(X)[:, 1]
    preds = (proba >= threshold).astype(int)

    result = keys_df[["TERM_CODE", "SUBJECT_ID_SORT"]].copy()
    result["HIGH_ENROLLMENT"] = np.where(preds == 1, "Y", "N")
    result["proba"] = proba
    return result


# ─── CLI ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--test_dir", default=None,
                        help="Path to test data directory")
    parser.add_argument("--gold_test", default=None,
                        help="Path to gold_enrollment_test.csv (optional, for eval)")
    parser.add_argument("--out", default="predictions.csv",
                        help="Output CSV path")
    parser.add_argument("--sanity", action="store_true",
                        help="Sanity-check on train data instead of test")
    args = parser.parse_args()

    if args.sanity or args.test_dir is None:
        print("Sanity-check mode: predicting on training data …")
        gold = pd.read_csv(os.path.join(TRAIN_DIR, "gold_enrollment_train.csv"))
        keys = gold[["TERM_CODE", "SUBJECT_ID_SORT"]]
        test_dir = None
    else:
        gold_test_path = args.gold_test or os.path.join(args.test_dir, "gold_enrollment_test.csv")
        gold = pd.read_csv(gold_test_path)
        keys = gold[["TERM_CODE", "SUBJECT_ID_SORT"]]
        test_dir = args.test_dir

    result = predict(keys, test_dir=test_dir)
    result.to_csv(args.out, index=False)
    print(f"Predictions saved to {args.out}")
    print(result["HIGH_ENROLLMENT"].value_counts())

    # Evaluate if gold available
    if "HIGH_ENROLLMENT" in gold.columns:
        from sklearn.metrics import f1_score, classification_report
        merged = result.merge(gold[["TERM_CODE", "SUBJECT_ID_SORT", "HIGH_ENROLLMENT"]],
                              on=["TERM_CODE", "SUBJECT_ID_SORT"], suffixes=("_pred", "_true"))
        y_true = (merged["HIGH_ENROLLMENT_true"] == "Y").astype(int)
        y_pred = (merged["HIGH_ENROLLMENT_pred"] == "Y").astype(int)
        macro_f1 = f1_score(y_true, y_pred, average="macro")
        print(f"\nMacro F1: {macro_f1:.4f}")
        print(classification_report(y_true, y_pred, target_names=["N", "Y"]))
