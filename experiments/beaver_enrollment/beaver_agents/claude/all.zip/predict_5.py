"""
High-enrollment prediction — inference script.

Usage:
    # Sanity-check on train data
    python predict.py --sanity

    # Predict for test data
    python predict.py --test_dir /path/to/test --out predictions.csv

    # Evaluate against gold labels if available
    python predict.py --test_dir /path/to/test --gold_test /path/to/gold_enrollment_test.csv
"""

import os
import re
import pickle
import argparse
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

TRAIN_DIR  = os.path.join(os.path.dirname(__file__), "train")
MODEL_PATH = os.path.join(os.path.dirname(__file__), "lgbm_model.pkl")


# ── helpers ───────────────────────────────────────────────────────────────────

def term_sort_key(tc):
    season_map = {"JA": 1, "SP": 2, "SU": 3, "FA": 4}
    m = re.match(r"(\d{4})([A-Z]+)", str(tc))
    if m:
        return int(m.group(1)) * 10 + season_map.get(m.group(2), 0)
    return int(str(tc)[:4]) * 10


def parse_term(tc):
    m = re.match(r"(\d{4})([A-Z]+)", str(tc))
    if m:
        return int(m.group(1)), m.group(2)
    return int(str(tc)[:4]), "UN"


def _load(directory, fname, **kwargs):
    path = os.path.join(directory, fname)
    if os.path.exists(path):
        return pd.read_csv(path, low_memory=False, **kwargs)
    return None


# ── feature engineering ───────────────────────────────────────────────────────

def build_features(keys_df, test_dir=None, train_dir=TRAIN_DIR):
    """
    Build the feature matrix for (TERM_CODE, SUBJECT_ID_SORT) keys.

    test_dir: directory with new-term tables (SUBJECT_OFFERED, etc.)
              Can be None when running in sanity-check mode.
    train_dir: training directory — always used for historical reference.
    """
    df = keys_df[["TERM_CODE", "SUBJECT_ID_SORT"]].copy()

    # term features
    parsed = df["TERM_CODE"].apply(parse_term)
    df["term_year"]   = parsed.apply(lambda x: x[0])
    df["term_season"] = parsed.apply(lambda x: x[1])
    df["term_sort"]   = df["TERM_CODE"].apply(term_sort_key)

    # course-level features
    df["course_prefix"]      = df["SUBJECT_ID_SORT"].str.split(".").str[0]
    df["course_num_str"]     = df["SUBJECT_ID_SORT"].str.split(".").str[-1]
    df["course_num_numeric"] = pd.to_numeric(
        df["course_num_str"].str.extract(r"(\d+)")[0], errors="coerce"
    )
    df["is_grad_level"] = (df["course_num_numeric"] >= 500).astype(int)

    # ── historical enrollment features (built from training SUBJECT_SUMMARY) ──

    ss_train = pd.read_csv(os.path.join(train_dir, "SUBJECT_SUMMARY.csv"))
    ss_train["term_sort"]   = ss_train["TERM_CODE"].apply(term_sort_key)
    ss_train["term_season"] = ss_train["TERM_CODE"].apply(lambda x: parse_term(x)[1])

    # Gold labels (for computing historical high-enrollment rate)
    gold_train = pd.read_csv(os.path.join(train_dir, "gold_enrollment_train.csv"))
    ss_train = ss_train.merge(
        gold_train[["TERM_CODE", "SUBJECT_ID_SORT", "HIGH_ENROLLMENT"]],
        on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left"
    )
    ss_train["is_high"] = (ss_train["HIGH_ENROLLMENT"] == "Y").astype(float)

    # Sort for expanding computations
    ss_sorted = ss_train.sort_values(["SUBJECT_ID_SORT", "term_sort"])
    ss_ss     = ss_train.sort_values(["SUBJECT_ID_SORT", "term_season", "term_sort"])

    # Lag enrollment features
    ss_sorted["lag1_enroll"]  = ss_sorted.groupby("SUBJECT_ID_SORT")["SUBJECT_ENROLLMENT_FIFTH_WEEK"].shift(1)
    ss_sorted["lag2_enroll"]  = ss_sorted.groupby("SUBJECT_ID_SORT")["SUBJECT_ENROLLMENT_FIFTH_WEEK"].shift(2)
    ss_sorted["lag3_enroll"]  = ss_sorted.groupby("SUBJECT_ID_SORT")["SUBJECT_ENROLLMENT_FIFTH_WEEK"].shift(3)
    ss_sorted["roll3_mean"]   = (
        ss_sorted.groupby("SUBJECT_ID_SORT")["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
        .transform(lambda x: x.shift(1).rolling(3, min_periods=1).mean())
    )
    ss_sorted["hist_mean_enroll"] = (
        ss_sorted.groupby("SUBJECT_ID_SORT")["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
        .transform(lambda x: x.shift(1).expanding().mean())
    )
    ss_sorted["hist_count"] = (
        ss_sorted.groupby("SUBJECT_ID_SORT")["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
        .transform(lambda x: x.shift(1).expanding().count())
    )
    ss_sorted["hist_high_rate"] = (
        ss_sorted.groupby("SUBJECT_ID_SORT")["is_high"]
        .transform(lambda x: x.shift(1).expanding().mean())
    )
    ss_sorted["hist_high_count"] = (
        ss_sorted.groupby("SUBJECT_ID_SORT")["is_high"]
        .transform(lambda x: x.shift(1).expanding().sum())
    )
    ss_sorted["enroll_trend"] = ss_sorted["lag1_enroll"] - ss_sorted["lag2_enroll"]
    ss_sorted["lag1_first_week"] = (
        ss_sorted.groupby("SUBJECT_ID_SORT")["SUBJECT_ENROLLMENT_FIRST_WEEK"].shift(1)
    )

    # Same-season features
    ss_sorted["same_season_lag1"]             = ss_ss.groupby(["SUBJECT_ID_SORT","term_season"])["SUBJECT_ENROLLMENT_FIFTH_WEEK"].shift(1).values
    ss_sorted["same_season_lag2"]             = ss_ss.groupby(["SUBJECT_ID_SORT","term_season"])["SUBJECT_ENROLLMENT_FIFTH_WEEK"].shift(2).values
    ss_sorted["was_high_same_season"]         = ss_ss.groupby(["SUBJECT_ID_SORT","term_season"])["is_high"].shift(1).values
    ss_sorted["hist_high_rate_same_season"]   = ss_ss.groupby(["SUBJECT_ID_SORT","term_season"])["is_high"].transform(lambda x: x.shift(1).expanding().mean()).values

    # Subject units (take most recent known entry per subject)
    unit_cols = ["TOTAL_UNITS", "LECTURE_UNITS", "LAB_UNITS", "PREP_UNITS", "DESIGN_UNITS"]
    ss_units  = ss_train.sort_values("term_sort").groupby("SUBJECT_ID_SORT")[unit_cols].last().reset_index()

    # Positive-enrollment indicator features
    ss_sorted["is_positive"] = (ss_sorted["SUBJECT_ENROLLMENT_FIFTH_WEEK"] > 0).astype(float)
    ss_sorted["hist_positive_rate"] = (
        ss_sorted.groupby("SUBJECT_ID_SORT")["is_positive"]
        .transform(lambda x: x.shift(1).expanding().mean())
    )
    ss_sorted["hist_positive_count"] = (
        ss_sorted.groupby("SUBJECT_ID_SORT")["is_positive"]
        .transform(lambda x: x.shift(1).expanding().sum())
    )

    # Dept all-time mean for subj_vs_dept_alltime
    dept_alltime_mean = (
        ss_train.groupby("DEPARTMENT_CODE")["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
        .mean().rename("dept_all_time_mean").reset_index()
    )
    ss_sorted = ss_sorted.merge(dept_alltime_mean, on="DEPARTMENT_CODE", how="left")
    ss_sorted["subj_vs_dept_alltime"] = ss_sorted["hist_mean_enroll"] / (ss_sorted["dept_all_time_mean"] + 0.01)

    # All-time mean (fallback for test subjects not in training history)
    subj_alltime = (
        ss_sorted.groupby("SUBJECT_ID_SORT")
        .agg(
            subj_all_mean=("SUBJECT_ENROLLMENT_FIFTH_WEEK", "mean"),
            subj_all_high_rate=("is_high", "mean"),
            subj_all_count=("SUBJECT_ENROLLMENT_FIFTH_WEEK", "count"),
        )
        .reset_index()
    )

    # Merge in-sample stats (for training rows where term exists in ss_sorted)
    lag_cols = [
        "lag1_enroll", "lag2_enroll", "lag3_enroll", "roll3_mean",
        "hist_mean_enroll", "hist_count",
        "hist_high_rate", "hist_high_count",
        "enroll_trend", "lag1_first_week",
        "same_season_lag1", "same_season_lag2",
        "was_high_same_season", "hist_high_rate_same_season",
        "hist_positive_rate", "hist_positive_count", "subj_vs_dept_alltime",
    ]
    df = df.merge(
        ss_sorted[["TERM_CODE", "SUBJECT_ID_SORT"] + lag_cols],
        on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left"
    )

    # For test rows where the key doesn't exist in training ss, fall back to all-time
    df = df.merge(subj_alltime, on="SUBJECT_ID_SORT", how="left")
    df["hist_mean_enroll"] = df["hist_mean_enroll"].fillna(df["subj_all_mean"])
    df["hist_high_rate"]   = df["hist_high_rate"].fillna(df["subj_all_high_rate"])
    df["hist_count"]       = df["hist_count"].fillna(df["subj_all_count"]).fillna(0)
    df["hist_high_count"]  = df["hist_high_count"].fillna(0)
    df = df.drop(columns=["subj_all_mean", "subj_all_high_rate", "subj_all_count"], errors="ignore")

    # Units fallback
    df = df.merge(ss_units, on="SUBJECT_ID_SORT", how="left")
    for c in unit_cols:
        if c not in df.columns:
            df[c] = np.nan

    # ── department stats from training history ────────────────────────────────

    dept_stats = (
        ss_train.groupby(["TERM_CODE", "DEPARTMENT_CODE"])["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
        .agg(dept_mean="mean", dept_median="median", dept_std="std", dept_n="count")
        .reset_index()
    )
    dept_stats["term_sort"] = dept_stats["TERM_CODE"].apply(term_sort_key)
    dept_stats = dept_stats.sort_values(["DEPARTMENT_CODE", "term_sort"])
    dept_stats["dept_prev_mean"]   = dept_stats.groupby("DEPARTMENT_CODE")["dept_mean"].shift(1)
    dept_stats["dept_prev_median"] = dept_stats.groupby("DEPARTMENT_CODE")["dept_median"].shift(1)
    dept_stats["dept_prev_n"]      = dept_stats.groupby("DEPARTMENT_CODE")["dept_n"].shift(1)
    dept_stats["dept_prev_std"]    = dept_stats.groupby("DEPARTMENT_CODE")["dept_std"].shift(1)

    # 75th percentile of enrollment per dept-term
    dept_q75 = (
        ss_train[ss_train["SUBJECT_ENROLLMENT_FIFTH_WEEK"] > 0]
        .groupby(["TERM_CODE", "DEPARTMENT_CODE"])["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
        .quantile(0.75).rename("dept_q75_enroll").reset_index()
    )
    dept_q75["term_sort"] = dept_q75["TERM_CODE"].apply(term_sort_key)
    dept_q75 = dept_q75.sort_values(["DEPARTMENT_CODE", "term_sort"])
    dept_q75["dept_prev_q75"] = dept_q75.groupby("DEPARTMENT_CODE")["dept_q75_enroll"].shift(1)
    dept_stats = dept_stats.merge(
        dept_q75[["TERM_CODE", "DEPARTMENT_CODE", "dept_prev_q75"]],
        on=["TERM_CODE", "DEPARTMENT_CODE"], how="left"
    )

    # Dept overall fallback (for test terms)
    dept_overall = (
        ss_train.groupby("DEPARTMENT_CODE")["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
        .agg(dept_fb_mean="mean", dept_fb_median="median",
             dept_fb_n="count", dept_fb_std="std")
        .reset_index()
    )
    dept_q75_overall = (
        ss_train[ss_train["SUBJECT_ENROLLMENT_FIFTH_WEEK"] > 0]
        .groupby("DEPARTMENT_CODE")["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
        .quantile(0.75).rename("dept_fb_q75").reset_index()
    )
    dept_overall = dept_overall.merge(dept_q75_overall, on="DEPARTMENT_CODE", how="left")

    # ── subject-offered features ──────────────────────────────────────────────

    so_dirs = ([test_dir] if test_dir else []) + [train_dir]
    so_all = []
    for d in so_dirs:
        tmp = _load(d, "SUBJECT_OFFERED.csv")
        if tmp is not None:
            so_all.append(tmp)
    if so_all:
        so_combined = pd.concat(so_all).drop_duplicates()
    else:
        so_combined = pd.DataFrame()

    if not so_combined.empty:
        # Section count
        ns = so_combined.groupby(["TERM_CODE","SUBJECT_ID_SORT"]).size().reset_index(name="n_sections")
        ns_sorted = ns.sort_values(["SUBJECT_ID_SORT","TERM_CODE"])
        ns_sorted["term_sort_ns"] = ns_sorted["TERM_CODE"].apply(term_sort_key)
        ns_sorted = ns_sorted.sort_values(["SUBJECT_ID_SORT","term_sort_ns"])
        ns_sorted["lag1_n_sections"] = ns_sorted.groupby("SUBJECT_ID_SORT")["n_sections"].shift(1)
        df = df.merge(ns, on=["TERM_CODE","SUBJECT_ID_SORT"], how="left")
        df = df.merge(ns_sorted[["TERM_CODE","SUBJECT_ID_SORT","lag1_n_sections"]],
                      on=["TERM_CODE","SUBJECT_ID_SORT"], how="left")

        # Instructor and dept from master section
        so_m = so_combined[so_combined.get("IS_MASTER_SECTION", "Y") == "Y"].copy()
        so_cols = ["TERM_CODE","SUBJECT_ID_SORT","OFFER_DEPT_CODE","OFFER_SCHOOL_NAME",
                   "CLUSTER_TYPE","HGN_CODE","HGN_CODE_DESC","RESPONSIBLE_FACULTY_NAME",
                   "IS_LECTURE_SECTION","IS_LAB_SECTION","IS_RECITATION_SECTION","IS_DESIGN_SECTION"]
        so_cols = [c for c in so_cols if c in so_m.columns]
        so_sub  = so_m[so_cols].drop_duplicates(subset=["TERM_CODE","SUBJECT_ID_SORT"])
        df = df.merge(so_sub, on=["TERM_CODE","SUBJECT_ID_SORT"], how="left")

    # Dept stats merge
    dept_feat = dept_stats[["TERM_CODE","DEPARTMENT_CODE",
                             "dept_prev_mean","dept_prev_median",
                             "dept_prev_n","dept_prev_std","dept_prev_q75"]].rename(
        columns={"DEPARTMENT_CODE": "OFFER_DEPT_CODE"}
    )
    df = df.merge(dept_feat, on=["TERM_CODE","OFFER_DEPT_CODE"], how="left")
    # Fallback for unseen test terms
    df = df.merge(dept_overall.rename(columns={"DEPARTMENT_CODE":"OFFER_DEPT_CODE"}),
                  on="OFFER_DEPT_CODE", how="left")
    df["dept_prev_mean"]   = df["dept_prev_mean"].fillna(df["dept_fb_mean"])
    df["dept_prev_median"] = df["dept_prev_median"].fillna(df["dept_fb_median"])
    df["dept_prev_n"]      = df["dept_prev_n"].fillna(df["dept_fb_n"])
    df["dept_prev_std"]    = df["dept_prev_std"].fillna(df["dept_fb_std"])
    df["dept_prev_q75"]    = df["dept_prev_q75"].fillna(df.get("dept_fb_q75", np.nan))
    df = df.drop(columns=["dept_fb_mean","dept_fb_median","dept_fb_n","dept_fb_std","dept_fb_q75"], errors="ignore")

    # Instructor historical stats
    so_train = _load(train_dir, "SUBJECT_OFFERED.csv") if so_combined.empty else \
        so_combined[so_combined["TERM_CODE"].isin(ss_train["TERM_CODE"].unique())]
    if so_train is not None and not so_train.empty:
        instr_hist = ss_sorted.merge(
            so_train[so_train.get("IS_MASTER_SECTION","Y") == "Y"][
                ["TERM_CODE","SUBJECT_ID_SORT","RESPONSIBLE_FACULTY_NAME"]
            ].drop_duplicates(), on=["TERM_CODE","SUBJECT_ID_SORT"], how="left"
        )
        instr_hist = instr_hist[instr_hist["RESPONSIBLE_FACULTY_NAME"].notna()]

        instr_enroll = (
            instr_hist.groupby(["RESPONSIBLE_FACULTY_NAME","TERM_CODE"])
            ["SUBJECT_ENROLLMENT_FIFTH_WEEK"].mean().reset_index()
        )
        instr_enroll["term_sort"] = instr_enroll["TERM_CODE"].apply(term_sort_key)
        instr_enroll = instr_enroll.sort_values(["RESPONSIBLE_FACULTY_NAME","term_sort"])
        instr_enroll["instr_hist_mean_enroll"] = (
            instr_enroll.groupby("RESPONSIBLE_FACULTY_NAME")["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
            .transform(lambda x: x.shift(1).expanding().mean())
        )

        instr_hi = (
            instr_hist.groupby(["RESPONSIBLE_FACULTY_NAME","TERM_CODE"])["is_high"]
            .mean().reset_index()
        )
        instr_hi["term_sort"] = instr_hi["TERM_CODE"].apply(term_sort_key)
        instr_hi = instr_hi.sort_values(["RESPONSIBLE_FACULTY_NAME","term_sort"])
        instr_hi["instr_hist_high_rate"] = (
            instr_hi.groupby("RESPONSIBLE_FACULTY_NAME")["is_high"]
            .transform(lambda x: x.shift(1).expanding().mean())
        )

        instr_feats = instr_enroll[["TERM_CODE","RESPONSIBLE_FACULTY_NAME","instr_hist_mean_enroll"]].merge(
            instr_hi[["TERM_CODE","RESPONSIBLE_FACULTY_NAME","instr_hist_high_rate"]],
            on=["TERM_CODE","RESPONSIBLE_FACULTY_NAME"], how="left"
        )
        df = df.merge(
            instr_feats.rename(columns={"RESPONSIBLE_FACULTY_NAME": "_instr_key"}),
            left_on=["TERM_CODE","RESPONSIBLE_FACULTY_NAME"],
            right_on=["TERM_CODE","_instr_key"], how="left"
        ).drop(columns=["_instr_key"], errors="ignore")

    # ── library indicator ─────────────────────────────────────────────────────

    lib_dirs = ([test_dir] if test_dir else []) + [train_dir]
    lib_dfs  = [_load(d, "LIBRARY_SUBJECT_OFFERED.csv") for d in lib_dirs]
    lib_all  = pd.concat([x for x in lib_dfs if x is not None]).drop_duplicates() if any(x is not None for x in lib_dfs) else pd.DataFrame()

    if not lib_all.empty and "TERM_CODE" in lib_all.columns and "SUBJECT_ID_SORT" in lib_all.columns:
        lib_ind = lib_all[["TERM_CODE","SUBJECT_ID_SORT"]].drop_duplicates()
        lib_ind["has_library"] = 1
        lib_ind["term_sort_lib"] = lib_ind["TERM_CODE"].apply(term_sort_key)
        lib_ind = lib_ind.sort_values(["SUBJECT_ID_SORT","term_sort_lib"])
        lib_ind["lag1_has_library"] = lib_ind.groupby("SUBJECT_ID_SORT")["has_library"].shift(1)
        df = df.merge(lib_ind[["TERM_CODE","SUBJECT_ID_SORT","has_library"]], on=["TERM_CODE","SUBJECT_ID_SORT"], how="left")
        df["has_library"] = df["has_library"].fillna(0)
        df = df.merge(lib_ind[["TERM_CODE","SUBJECT_ID_SORT","lag1_has_library"]], on=["TERM_CODE","SUBJECT_ID_SORT"], how="left")

    # ── catalog features ──────────────────────────────────────────────────────

    cat = _load(train_dir, "COURSE_CATALOG_SUBJECT_OFFERED.csv")
    if cat is not None:
        cat["SUBJECT_ID_SORT"] = cat["SUBJECT_CODE"].astype(str) + "." + cat["SUBJECT_NUMBER"].astype(str)
        cf = ["SUBJECT_ID_SORT","GIR_ATTRIBUTE","HASS_ATTRIBUTE","COMM_REQ_ATTRIBUTE",
              "GRADE_TYPE","GRADE_RULE","IS_OFFERED_FALL_TERM","IS_OFFERED_SPRING_TERM",
              "IS_OFFERED_IAP","IS_OFFERED_SUMMER_TERM","PREREQUISITES","JOINT_SUBJECTS",
              "MEETS_WITH_SUBJECTS","EQUIVALENT_SUBJECTS"]
        cf = [c for c in cf if c in cat.columns]
        catalog = cat.sort_values("ACADEMIC_YEAR", ascending=False).drop_duplicates("SUBJECT_ID_SORT")[cf].copy()
        catalog["has_prereqs"]   = catalog["PREREQUISITES"].notna().astype(int)
        catalog["has_joint"]     = catalog["JOINT_SUBJECTS"].notna().astype(int)
        catalog["has_meets_with"]= catalog["MEETS_WITH_SUBJECTS"].notna().astype(int)
        catalog["gir_is_required"] = catalog["GIR_ATTRIBUTE"].isin(
            ["PHY1","PHY2","CAL1","CAL2","CHEM","BIOL","REST","LAB","LAB2","HE"]
        ).astype(int)
        df = df.merge(catalog, on="SUBJECT_ID_SORT", how="left")

    # ── ratio features ────────────────────────────────────────────────────────

    df["lag1_vs_dept"]    = df["lag1_enroll"] / (df["dept_prev_mean"] + 1)
    df["lag1_vs_hist"]    = df["lag1_enroll"] / (df["hist_mean_enroll"] + 1)
    df["ss_lag1_vs_dept"] = df["same_season_lag1"] / (df["dept_prev_mean"] + 1)
    df["ss_lag1_vs_hist"] = df["same_season_lag1"] / (df["hist_mean_enroll"] + 1)
    df["lag1_vs_dept_q75"] = df["lag1_enroll"] / (df.get("dept_prev_q75", pd.Series([np.nan]*len(df))) + 0.5)
    df["hist_mean_vs_q75"] = df["hist_mean_enroll"] / (df.get("dept_prev_q75", pd.Series([np.nan]*len(df))) + 0.5)
    df["hist_count"]      = df["hist_count"].fillna(0)
    df["hist_high_count"] = df["hist_high_count"].fillna(0)

    # ── categorical encoding ──────────────────────────────────────────────────

    cat_cols = [
        "term_season","course_prefix",
        "OFFER_DEPT_CODE","OFFER_SCHOOL_NAME",
        "CLUSTER_TYPE","HGN_CODE","HGN_CODE_DESC",
        "GIR_ATTRIBUTE","HASS_ATTRIBUTE","COMM_REQ_ATTRIBUTE",
        "GRADE_TYPE","GRADE_RULE",
        "IS_OFFERED_FALL_TERM","IS_OFFERED_SPRING_TERM",
        "IS_OFFERED_IAP","IS_OFFERED_SUMMER_TERM",
        "RESPONSIBLE_FACULTY_NAME",
    ]
    for col in cat_cols:
        if col in df.columns:
            df[col] = df[col].astype("category")

    return df


# ── predict ───────────────────────────────────────────────────────────────────

def predict(keys_df, test_dir=None, train_dir=TRAIN_DIR, model_path=MODEL_PATH):
    with open(model_path, "rb") as f:
        bundle = pickle.load(f)
    # Support both single-model and ensemble bundles
    models    = bundle.get("models", None) or [bundle["model"]]
    features  = bundle["features"]
    threshold = bundle["threshold"]

    df = build_features(keys_df, test_dir=test_dir, train_dir=train_dir)

    for feat in features:
        if feat not in df.columns:
            print(f"WARNING: missing feature '{feat}' — filling with NaN")
            df[feat] = np.nan

    X      = df[features]
    probas = [m.predict_proba(X)[:, 1] for m in models]
    proba  = np.mean(probas, axis=0)
    labels = np.where(proba >= threshold, "Y", "N")

    result = keys_df[["TERM_CODE","SUBJECT_ID_SORT"]].copy()
    result["HIGH_ENROLLMENT"] = labels
    result["proba"]           = proba
    return result


# ── CLI ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--test_dir",  default=None, help="Path to test data directory")
    parser.add_argument("--gold_test", default=None, help="Path to gold_enrollment_test.csv (optional)")
    parser.add_argument("--out",       default="predictions.csv", help="Output CSV path")
    parser.add_argument("--sanity",    action="store_true", help="Sanity-check on training data")
    args = parser.parse_args()

    if args.sanity or args.test_dir is None:
        print("Sanity-check mode: predicting on training data …")
        gold = pd.read_csv(os.path.join(TRAIN_DIR, "gold_enrollment_train.csv"))
        keys     = gold[["TERM_CODE","SUBJECT_ID_SORT"]]
        test_dir = None
    else:
        gold_path = args.gold_test or os.path.join(args.test_dir, "gold_enrollment_test.csv")
        gold      = pd.read_csv(gold_path)
        keys      = gold[["TERM_CODE","SUBJECT_ID_SORT"]]
        test_dir  = args.test_dir

    result = predict(keys, test_dir=test_dir)
    result.to_csv(args.out, index=False)
    print(f"Saved {len(result)} predictions to {args.out}")
    print(result["HIGH_ENROLLMENT"].value_counts())

    if "HIGH_ENROLLMENT" in gold.columns:
        from sklearn.metrics import f1_score, classification_report
        merged = result.merge(
            gold[["TERM_CODE","SUBJECT_ID_SORT","HIGH_ENROLLMENT"]],
            on=["TERM_CODE","SUBJECT_ID_SORT"], suffixes=("_pred","_true")
        )
        y_true = (merged["HIGH_ENROLLMENT_true"] == "Y").astype(int)
        y_pred = (merged["HIGH_ENROLLMENT_pred"] == "Y").astype(int)
        print(f"\nMacro F1: {f1_score(y_true, y_pred, average='macro'):.4f}")
        print(classification_report(y_true, y_pred, target_names=["N","Y"]))
