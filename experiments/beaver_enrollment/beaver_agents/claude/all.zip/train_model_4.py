"""
High-enrollment prediction pipeline for MIT course offerings.
Label: TOP QUARTILE enrollment within dept+term (Y/N).
Features: lag enrollment, course metadata, department, term season/year, catalog attributes.
Model: LightGBM with time-based validation split.
"""

import os
import re
import pickle
import warnings

import numpy as np
import pandas as pd
import lightgbm as lgb
from sklearn.metrics import f1_score, classification_report
from sklearn.preprocessing import LabelEncoder

warnings.filterwarnings("ignore")

TRAIN_DIR = "/Users/USER/Documents/UNI/SS26/BEAVER/table_splits/train"


# ─── helpers ──────────────────────────────────────────────────────────────────

def term_sort_key(term_code):
    """Convert TERM_CODE like '2018FA' to sortable integer (year*10 + season offset)."""
    season_map = {"JA": 1, "SP": 2, "SU": 3, "FA": 4}
    m = re.match(r"(\d{4})([A-Z]+)", str(term_code))
    if m:
        year = int(m.group(1))
        season = m.group(2)
        return year * 10 + season_map.get(season, 0)
    # Handle edge case like '199410'
    return int(str(term_code)[:4]) * 10


def parse_term(term_code):
    """Return (year, season) for a TERM_CODE string."""
    m = re.match(r"(\d{4})([A-Z]+)", str(term_code))
    if m:
        return int(m.group(1)), m.group(2)
    return int(str(term_code)[:4]), "UN"


def extract_course_features(df):
    """Derive features from SUBJECT_ID_SORT and TERM_CODE."""
    # e.g. '21F.503' → prefix='21F', number_str='503'
    df["course_prefix"] = df["SUBJECT_ID_SORT"].str.split(".").str[0]
    df["course_number_str"] = df["SUBJECT_ID_SORT"].str.split(".").str[-1]

    # Numeric part of course number
    df["course_num_numeric"] = pd.to_numeric(
        df["course_number_str"].str.extract(r"(\d+)")[0], errors="coerce"
    )

    # Rough graduate-level indicator: number ≥ 500 (many MIT grad courses)
    df["is_grad_level_num"] = (df["course_num_numeric"] >= 500).astype(int)

    # Term year and season
    parsed = df["TERM_CODE"].apply(parse_term)
    df["term_year"] = parsed.apply(lambda x: x[0])
    df["term_season"] = parsed.apply(lambda x: x[1])

    return df


# ─── load data ────────────────────────────────────────────────────────────────

print("Loading data …")

gold = pd.read_csv(os.path.join(TRAIN_DIR, "gold_enrollment_train.csv"))
print(f"  gold: {gold.shape}")

enrollment_hist = pd.read_csv(os.path.join(TRAIN_DIR, "ENROLLMENT_HISTORY_FEATURES.csv"))
print(f"  enrollment_hist: {enrollment_hist.shape}")

subj_offered_summary = pd.read_csv(os.path.join(TRAIN_DIR, "SUBJECT_OFFERED_SUMMARY.csv"))
print(f"  subj_offered_summary: {subj_offered_summary.shape}")

# SUBJECT_SUMMARY has per-term enrollment counts — use only to build a
# subject-level prior (avg across terms), keeping it leakage-free.
subj_summary = pd.read_csv(os.path.join(TRAIN_DIR, "SUBJECT_SUMMARY.csv"))
print(f"  subj_summary: {subj_summary.shape}")

# DRUPAL_COURSE_CATALOG — catalog-level attributes (grade type, GIR, HASS, etc.)
drupal = pd.read_csv(os.path.join(TRAIN_DIR, "DRUPAL_COURSE_CATALOG.csv"), low_memory=False)
print(f"  drupal catalog: {drupal.shape}")

# ─── build primary feature frame ──────────────────────────────────────────────

print("Building feature frame …")

df = gold.copy()

# ── 1. term-based features ────────────────────────────────────────────────────
df = extract_course_features(df)

# ── 2. lag enrollment features ────────────────────────────────────────────────
df = df.merge(
    enrollment_hist[["TERM_CODE", "SUBJECT_ID_SORT",
                      "lag1_enrollment", "lag2_enrollment", "roll3_enrollment_mean"]],
    on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left"
)

# ── 3. offered summary features ───────────────────────────────────────────────
sos_cols = [
    "TERM_CODE", "SUBJECT_ID_SORT",
    "OFFER_DEPT_CODE", "OFFER_SCHOOL_NAME",
    "CLUSTER_TYPE",
    "HGN_CODE", "HGN_CODE_DESC",
    "TOTAL_UNITS", "LECTURE_UNITS", "LAB_UNITS", "PREPARATION_UNITS",
    "RESPONSIBLE_FACULTY_NAME",
]
df = df.merge(
    subj_offered_summary[sos_cols],
    on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left"
)

# ── 4. historical cross-term subject statistics (no leakage) ──────────────────
# Build look-back stats using only terms *before* the current one.
# Sort subject_summary by term, then for each subject compute cumulative
# mean enrollment up to (but not including) the current term.

# Add sort key to subject_summary
ss_work = subj_summary[["TERM_CODE", "SUBJECT_ID_SORT",
                          "SUBJECT_ENROLLMENT_FIFTH_WEEK",
                          "DEPARTMENT_CODE"]].copy()
ss_work["term_sort"] = ss_work["TERM_CODE"].apply(term_sort_key)
ss_work = ss_work.sort_values("term_sort")

# Expanding mean per subject (up to but not including current term)
ss_work["subj_hist_mean_enroll"] = (
    ss_work.groupby("SUBJECT_ID_SORT")["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
    .transform(lambda x: x.shift(1).expanding().mean())
)
ss_work["subj_hist_count"] = (
    ss_work.groupby("SUBJECT_ID_SORT")["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
    .transform(lambda x: x.shift(1).expanding().count())
)

df = df.merge(
    ss_work[["TERM_CODE", "SUBJECT_ID_SORT",
             "subj_hist_mean_enroll", "subj_hist_count"]],
    on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left"
)

# ── 5. department-level statistics per term (from previous terms) ─────────────
dept_term = (
    subj_summary.groupby(["TERM_CODE", "DEPARTMENT_CODE"])
    ["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
    .agg(["mean", "median", "std", "count"])
    .rename(columns={
        "mean": "dept_term_mean_enroll",
        "median": "dept_term_median_enroll",
        "std": "dept_term_std_enroll",
        "count": "dept_term_n_courses",
    })
    .reset_index()
)
dept_term["term_sort"] = dept_term["TERM_CODE"].apply(term_sort_key)
dept_term = dept_term.sort_values("term_sort")

# Lag-1 dept stats (previous term)
dept_term["dept_prev_mean"] = dept_term.groupby("DEPARTMENT_CODE")["dept_term_mean_enroll"].shift(1)
dept_term["dept_prev_median"] = dept_term.groupby("DEPARTMENT_CODE")["dept_term_median_enroll"].shift(1)
dept_term["dept_prev_n_courses"] = dept_term.groupby("DEPARTMENT_CODE")["dept_term_n_courses"].shift(1)

# Merge via OFFER_DEPT_CODE → DEPARTMENT_CODE
dept_feat = dept_term[["TERM_CODE", "DEPARTMENT_CODE",
                        "dept_prev_mean", "dept_prev_median", "dept_prev_n_courses"]].copy()
dept_feat = dept_feat.rename(columns={"DEPARTMENT_CODE": "OFFER_DEPT_CODE"})

df = df.merge(dept_feat, on=["TERM_CODE", "OFFER_DEPT_CODE"], how="left")

# ── 6. DRUPAL catalog attributes ──────────────────────────────────────────────
drupal["SUBJECT_ID_SORT"] = (
    drupal["SUBJECT_CODE"].astype(str) + "." + drupal["SUBJECT_NUMBER"].astype(str)
)

catalog_cols = [
    "SUBJECT_ID_SORT",
    "GRADE_TYPE", "GRADE_RULE",
    "HGN_CODE",
    "GIR_ATTRIBUTE", "COMM_REQ_ATTRIBUTE",
    "HASS_ATTRIBUTE",
    "IS_OFFERED_FALL_TERM", "IS_OFFERED_SPRING_TERM",
    "IS_OFFERED_IAP", "IS_OFFERED_SUMMER_TERM",
    "TOTAL_UNITS",
]
catalog_cols = [c for c in catalog_cols if c in drupal.columns]

# Take most recent catalog entry per subject
drupal_sorted = drupal.sort_values("ACADEMIC_YEAR", ascending=False)
drupal_dedup = drupal_sorted.drop_duplicates("SUBJECT_ID_SORT")[catalog_cols]
drupal_dedup = drupal_dedup.rename(columns={
    "TOTAL_UNITS": "catalog_total_units",
    "HGN_CODE": "catalog_hgn_code",
})

df = df.merge(drupal_dedup, on="SUBJECT_ID_SORT", how="left")

# ── 7. relative lag features ──────────────────────────────────────────────────
# How does this course's lag1 compare to the dept historical mean?
df["lag1_vs_dept"] = df["lag1_enrollment"] / (df["dept_prev_mean"] + 1)
df["lag1_vs_hist"] = df["lag1_enrollment"] / (df["subj_hist_mean_enroll"] + 1)

# Number of times this subject has been offered (a proxy for "established course")
df["subj_hist_count"] = df["subj_hist_count"].fillna(0)

# ─── encode label ─────────────────────────────────────────────────────────────
df["label"] = (df["HIGH_ENROLLMENT"] == "Y").astype(int)

# ─── categorical encoding ─────────────────────────────────────────────────────
cat_cols = [
    "OFFER_DEPT_CODE", "OFFER_SCHOOL_NAME",
    "CLUSTER_TYPE", "HGN_CODE", "HGN_CODE_DESC",
    "term_season", "course_prefix",
    "GRADE_TYPE", "GRADE_RULE",
    "GIR_ATTRIBUTE", "COMM_REQ_ATTRIBUTE",
    "HASS_ATTRIBUTE",
    "catalog_hgn_code",
    "IS_OFFERED_FALL_TERM", "IS_OFFERED_SPRING_TERM",
    "IS_OFFERED_IAP", "IS_OFFERED_SUMMER_TERM",
    "RESPONSIBLE_FACULTY_NAME",
]
cat_cols = [c for c in cat_cols if c in df.columns]

for col in cat_cols:
    df[col] = df[col].astype("category")

# ─── feature list ─────────────────────────────────────────────────────────────
FEATURES = [
    # lag enrollment (most important)
    "lag1_enrollment", "lag2_enrollment", "roll3_enrollment_mean",
    # subject history
    "subj_hist_mean_enroll", "subj_hist_count",
    # relative features
    "lag1_vs_dept", "lag1_vs_hist",
    # dept historical stats
    "dept_prev_mean", "dept_prev_median", "dept_prev_n_courses",
    # course attributes
    "TOTAL_UNITS", "LECTURE_UNITS", "LAB_UNITS", "PREPARATION_UNITS",
    "catalog_total_units",
    "course_num_numeric", "is_grad_level_num",
    # time
    "term_year",
    # categorical
    "OFFER_DEPT_CODE", "OFFER_SCHOOL_NAME",
    "CLUSTER_TYPE", "HGN_CODE", "HGN_CODE_DESC",
    "term_season", "course_prefix",
    "GRADE_TYPE", "GRADE_RULE",
    "GIR_ATTRIBUTE", "COMM_REQ_ATTRIBUTE",
    "HASS_ATTRIBUTE",
    "catalog_hgn_code",
    "IS_OFFERED_FALL_TERM", "IS_OFFERED_SPRING_TERM",
    "IS_OFFERED_IAP", "IS_OFFERED_SUMMER_TERM",
    "RESPONSIBLE_FACULTY_NAME",
]
FEATURES = [f for f in FEATURES if f in df.columns]
print(f"Using {len(FEATURES)} features.")

# ─── time-based train/val split ───────────────────────────────────────────────
df["term_sort"] = df["TERM_CODE"].apply(term_sort_key)
CUTOFF = term_sort_key("2017FA")  # hold out 2017FA, 2017SP, 2018*

train_mask = df["term_sort"] < CUTOFF
val_mask = df["term_sort"] >= CUTOFF

X_train = df.loc[train_mask, FEATURES]
y_train = df.loc[train_mask, "label"]
X_val = df.loc[val_mask, FEATURES]
y_val = df.loc[val_mask, "label"]

print(f"\nTrain: {train_mask.sum()} rows | Val: {val_mask.sum()} rows")
print(f"Val positive rate: {y_val.mean():.3f}")

# ─── class weight ─────────────────────────────────────────────────────────────
neg_count = (y_train == 0).sum()
pos_count = (y_train == 1).sum()
scale_pos_weight = neg_count / pos_count
print(f"scale_pos_weight: {scale_pos_weight:.2f}")

# ─── LightGBM ─────────────────────────────────────────────────────────────────
print("\nTraining LightGBM …")

params = {
    "objective": "binary",
    "metric": "binary_logloss",
    "n_estimators": 1000,
    "learning_rate": 0.05,
    "num_leaves": 127,
    "max_depth": -1,
    "min_child_samples": 20,
    "feature_fraction": 0.8,
    "bagging_fraction": 0.8,
    "bagging_freq": 5,
    "reg_alpha": 0.1,
    "reg_lambda": 0.1,
    "scale_pos_weight": scale_pos_weight,
    "random_state": 42,
    "n_jobs": -1,
    "verbose": -1,
}

model = lgb.LGBMClassifier(**params)
model.fit(
    X_train, y_train,
    eval_set=[(X_val, y_val)],
    eval_metric="binary_logloss",
    callbacks=[
        lgb.early_stopping(stopping_rounds=50, verbose=False),
        lgb.log_evaluation(period=100),
    ],
    categorical_feature=cat_cols,
)

# ─── evaluate ─────────────────────────────────────────────────────────────────
val_proba = model.predict_proba(X_val)[:, 1]

# Tune threshold for best macro F1
best_f1, best_thresh = 0, 0.5
for t in np.arange(0.2, 0.8, 0.01):
    preds = (val_proba >= t).astype(int)
    f1 = f1_score(y_val, preds, average="macro", zero_division=0)
    if f1 > best_f1:
        best_f1, best_thresh = f1, t

print(f"\nBest threshold: {best_thresh:.2f}  |  Val macro F1: {best_f1:.4f}")
val_preds = (val_proba >= best_thresh).astype(int)
print(classification_report(y_val, val_preds, target_names=["N", "Y"]))

# Also evaluate with default 0.5 threshold
val_preds_05 = (val_proba >= 0.5).astype(int)
f1_05 = f1_score(y_val, val_preds_05, average="macro", zero_division=0)
print(f"Default threshold 0.5 macro F1: {f1_05:.4f}")

# ─── feature importance ───────────────────────────────────────────────────────
fi = pd.Series(model.feature_importances_, index=FEATURES).sort_values(ascending=False)
print("\nTop 20 features:")
print(fi.head(20).to_string())

# ─── retrain on full training set ─────────────────────────────────────────────
print("\nRetraining on full train set …")
X_full = df[FEATURES]
y_full = df["label"]

params_full = dict(params)
params_full["n_estimators"] = model.best_iteration_ + 50  # a bit beyond early-stop point

model_full = lgb.LGBMClassifier(**params_full)
model_full.fit(X_full, y_full, categorical_feature=cat_cols)

# ─── save artefacts ───────────────────────────────────────────────────────────
OUT = "/Users/USER/Documents/UNI/SS26/BEAVER/table_splits"

# Save model
with open(os.path.join(OUT, "lgbm_model.pkl"), "wb") as f:
    pickle.dump({"model": model_full, "features": FEATURES,
                 "cat_cols": cat_cols, "threshold": best_thresh}, f)

# Save validation predictions for analysis
val_df = df.loc[val_mask, ["TERM_CODE", "SUBJECT_ID_SORT", "label"]].copy()
val_df["proba"] = val_proba
val_df["pred"] = val_preds
val_df.to_csv(os.path.join(OUT, "val_predictions.csv"), index=False)

print(f"\nModel saved to {OUT}/lgbm_model.pkl")
print("Done.")
