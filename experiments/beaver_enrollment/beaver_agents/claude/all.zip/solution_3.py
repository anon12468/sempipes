"""
High-enrollment prediction pipeline.
Features: historical lag enrollment, course characteristics, dept-relative rankings.
Model: LightGBM classifier with time-based val split.
"""
import re
import os
import json
import numpy as np
import pandas as pd
import lightgbm as lgb
from sklearn.metrics import f1_score

TRAIN_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "train")
OUT_PRED = os.path.join(os.path.dirname(os.path.abspath(__file__)), "predictions_train.csv")

SEASON_ORDER = {"JA": 0, "SP": 1, "SU": 2, "FA": 3}


def term_to_sortkey(tc: str) -> float:
    tc = str(tc).strip()
    m = re.match(r"(\d{4})(FA|SP|JA|SU|10)$", tc)
    if m:
        year = int(m.group(1))
        season = m.group(2)
        return year + (0.25 if season == "10" else SEASON_ORDER[season] / 10)
    try:
        return float(tc[:4])
    except Exception:
        return 0.0


def extract_course_features(df: pd.DataFrame) -> pd.DataFrame:
    df["dept_prefix"] = df["SUBJECT_ID_SORT"].str.extract(r"^([^.]+)")[0]
    df["course_num"] = pd.to_numeric(
        df["SUBJECT_ID_SORT"].str.extract(r"\.(\d+)")[0], errors="coerce"
    ).fillna(-1)
    df["course_level"] = (df["course_num"] // 100).clip(-1, 20).astype(int)
    df["is_grad_level"] = (df["course_num"] >= 600).astype(int)
    df["term_season"] = df["TERM_CODE"].str.extract(r"(FA|SP|JA|SU|10)$")[0].fillna("UNK")
    df["term_year"] = pd.to_numeric(df["TERM_CODE"].str[:4], errors="coerce").fillna(0).astype(int)
    df["term_sortkey"] = df["TERM_CODE"].apply(term_to_sortkey)
    return df


def load_all_features():
    d = TRAIN_DIR
    print("Loading gold labels…")
    gold = pd.read_csv(f"{d}/gold_enrollment_train.csv")
    gold["label"] = (gold["HIGH_ENROLLMENT"] == "Y").astype(int)

    print("Loading ENROLLMENT_HISTORY_FEATURES…")
    ehf = pd.read_csv(f"{d}/ENROLLMENT_HISTORY_FEATURES.csv")

    print("Loading SUBJECT_OFFERED_SUMMARY…")
    sos = pd.read_csv(
        f"{d}/SUBJECT_OFFERED_SUMMARY.csv",
        usecols=[
            "TERM_CODE", "SUBJECT_ID_SORT", "COURSE_NUMBER",
            "CLUSTER_TYPE", "HGN_CODE", "OFFER_DEPT_CODE", "OFFER_SCHOOL_NAME",
            "TOTAL_UNITS", "LECTURE_UNITS", "LAB_UNITS", "PREPARATION_UNITS",
        ],
        low_memory=False,
    )

    print("Loading CIS_COURSE_CATALOG (GIR/HASS attributes)…")
    ccc = pd.read_csv(
        f"{d}/CIS_COURSE_CATALOG.csv",
        usecols=["SUBJECT_CODE", "SUBJECT_NUMBER", "GIR_ATTRIBUTE", "HASS_ATTRIBUTE"],
        low_memory=False,
    )
    ccc["SUBJECT_ID_SORT"] = (
        ccc["SUBJECT_CODE"].astype(str).str.strip()
        + "."
        + ccc["SUBJECT_NUMBER"].astype(str).str.strip()
    )
    # Use the most common GIR/HASS value per subject
    gir = (
        ccc.groupby("SUBJECT_ID_SORT")["GIR_ATTRIBUTE"]
        .agg(lambda x: x.mode().iloc[0] if x.notna().any() else np.nan)
        .reset_index()
        .rename(columns={"GIR_ATTRIBUTE": "gir_attribute"})
    )
    hass = (
        ccc.groupby("SUBJECT_ID_SORT")["HASS_ATTRIBUTE"]
        .agg(lambda x: x.mode().iloc[0] if x.notna().any() else np.nan)
        .reset_index()
        .rename(columns={"HASS_ATTRIBUTE": "hass_attribute"})
    )

    print("Loading SUBJECT_SUMMARY (historical enrollment stats + same-season lag)…")
    ss = pd.read_csv(
        f"{d}/SUBJECT_SUMMARY.csv",
        usecols=["TERM_CODE", "SUBJECT_ID_SORT", "SUBJECT_ENROLLMENT_CREDIT",
                 "CLUSTER_ENROLLMENT_CREDIT"],
        low_memory=False,
    )
    ss["term_sortkey_ss"] = ss["TERM_CODE"].apply(term_to_sortkey)
    ss["season_ss"] = ss["TERM_CODE"].str.extract(r"(FA|SP|JA|SU|10)$")[0].fillna("UNK")
    ss = ss.sort_values(["SUBJECT_ID_SORT", "season_ss", "term_sortkey_ss"]).reset_index(drop=True)

    # Same-season lags (within season group, strictly before current row)
    def safe_shift(s, n):
        return s.shift(n)

    grp_ss_season = ss.groupby(["SUBJECT_ID_SORT", "season_ss"])
    ss["same_season_lag1"] = grp_ss_season["SUBJECT_ENROLLMENT_CREDIT"].transform(lambda s: s.shift(1))
    ss["same_season_lag2"] = grp_ss_season["SUBJECT_ENROLLMENT_CREDIT"].transform(lambda s: s.shift(2))
    ss["same_season_roll3"] = grp_ss_season["SUBJECT_ENROLLMENT_CREDIT"].transform(
        lambda s: s.shift(1).rolling(3, min_periods=1).mean()
    )
    ss["same_season_cluster_lag1"] = grp_ss_season["CLUSTER_ENROLLMENT_CREDIT"].transform(lambda s: s.shift(1))

    # All-time expanding historical stats (sort by term, use strictly past)
    ss_chron = ss.sort_values(["SUBJECT_ID_SORT", "term_sortkey_ss"]).copy()
    grp_ss_all = ss_chron.groupby("SUBJECT_ID_SORT")["SUBJECT_ENROLLMENT_CREDIT"]
    ss_chron["subj_hist_max"] = grp_ss_all.transform(lambda s: s.shift(1).expanding().max())
    ss_chron["subj_hist_mean"] = grp_ss_all.transform(lambda s: s.shift(1).expanding().mean())
    ss_chron["subj_hist_p75"] = grp_ss_all.transform(
        lambda s: s.shift(1).expanding().quantile(0.75)
    )

    # Merge all-time stats back (indexed by TERM_CODE+SUBJECT_ID_SORT)
    ss_all_stats = ss_chron.set_index(["TERM_CODE", "SUBJECT_ID_SORT"])[
        ["subj_hist_max", "subj_hist_mean", "subj_hist_p75"]
    ]
    ss = ss.join(ss_all_stats, on=["TERM_CODE", "SUBJECT_ID_SORT"])

    ss_feats = ss[["TERM_CODE", "SUBJECT_ID_SORT",
                   "same_season_lag1", "same_season_lag2", "same_season_roll3",
                   "same_season_cluster_lag1",
                   "subj_hist_max", "subj_hist_mean", "subj_hist_p75"]]

    print("Loading SUBJECT_OFFERED (section counts)…")
    so = pd.read_csv(
        f"{d}/SUBJECT_OFFERED.csv",
        usecols=["TERM_CODE", "SUBJECT_ID_SORT",
                 "IS_LECTURE_SECTION", "IS_LAB_SECTION", "IS_RECITATION_SECTION"],
        low_memory=False,
    )
    sections = so.groupby(["TERM_CODE", "SUBJECT_ID_SORT"]).agg(
        n_sections=("IS_LECTURE_SECTION", "count"),
        n_lecture=("IS_LECTURE_SECTION", lambda x: (x == "Y").sum()),
        n_recitation=("IS_RECITATION_SECTION", lambda x: (x == "Y").sum()),
    ).reset_index()

    # ── merge ─────────────────────────────────────────────────────────────────
    df = gold.merge(ehf, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")
    df = df.merge(sos, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")
    df = df.merge(sections, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")
    df = df.merge(ss_feats, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")
    df = df.merge(gir, on="SUBJECT_ID_SORT", how="left")
    df = df.merge(hass, on="SUBJECT_ID_SORT", how="left")

    # ── base features ─────────────────────────────────────────────────────────
    df = extract_course_features(df)
    df = df.sort_values("term_sortkey").reset_index(drop=True)

    # ── derived enrollment features ───────────────────────────────────────────
    df["lag1_log"] = np.log1p(df["lag1_enrollment"])
    df["lag2_log"] = np.log1p(df["lag2_enrollment"])
    df["roll3_log"] = np.log1p(df["roll3_enrollment_mean"])
    df["lag1_nonzero"] = (df["lag1_enrollment"] > 0).astype(int)
    df["lag2_nonzero"] = (df["lag2_enrollment"] > 0).astype(int)
    df["enrollment_trend"] = df["lag1_enrollment"] - df["lag2_enrollment"]
    df["enrollment_trend_pct"] = df["enrollment_trend"] / (df["lag2_enrollment"] + 1)

    # ── within-dept-term lag enrollment percentile (time-safe feature) ────────
    # Ranks relative to peers in same dept × term using LAG enrollment (no leakage)
    for col in ["lag1_enrollment", "roll3_enrollment_mean",
                "same_season_lag1", "same_season_roll3"]:
        df[f"dept_{col}_pct"] = (
            df.groupby(["OFFER_DEPT_CODE", "TERM_CODE"])[col]
            .rank(pct=True, na_option="keep")
        )

    # ── historical high-enrollment rate per subject (time-safe expanding) ────
    print("Computing historical label stats…")
    grouped = df.groupby("SUBJECT_ID_SORT")["label"]
    df["hist_Y_sum"] = grouped.transform(
        lambda s: s.shift(1).expanding().sum().fillna(0)
    )
    df["hist_count"] = grouped.transform(
        lambda s: s.shift(1).expanding().count().fillna(0)
    )
    df["hist_Y_rate"] = (
        df["hist_Y_sum"] / df["hist_count"].replace(0, np.nan)
    ).fillna(-1)

    # ── dept-level history (expanding mean over past terms) ───────────────────
    dept_term_mean = (
        df.groupby(["OFFER_DEPT_CODE", "term_sortkey"])["label"]
        .mean()
        .reset_index(name="dept_term_label_mean")
        .sort_values("term_sortkey")
    )
    dept_term_mean["dept_hist_Y_rate"] = dept_term_mean.groupby("OFFER_DEPT_CODE")[
        "dept_term_label_mean"
    ].transform(lambda s: s.shift(1).expanding().mean())
    df = df.merge(
        dept_term_mean[["OFFER_DEPT_CODE", "term_sortkey", "dept_hist_Y_rate"]],
        on=["OFFER_DEPT_CODE", "term_sortkey"],
        how="left",
    )

    # ── dept size per term ────────────────────────────────────────────────────
    dept_size = (
        df.groupby(["OFFER_DEPT_CODE", "TERM_CODE"])
        .size()
        .reset_index(name="dept_term_size")
    )
    df = df.merge(dept_size, on=["OFFER_DEPT_CODE", "TERM_CODE"], how="left")

    return df


CAT_COLS = [
    "dept_prefix", "COURSE_NUMBER", "CLUSTER_TYPE",
    "HGN_CODE", "OFFER_DEPT_CODE", "OFFER_SCHOOL_NAME",
    "term_season", "SUBJECT_ID_SORT",
    "gir_attribute", "hass_attribute",
]
NUM_COLS = [
    "lag1_enrollment", "lag2_enrollment", "roll3_enrollment_mean",
    "lag1_nonzero", "lag2_nonzero",
    "enrollment_trend", "enrollment_trend_pct",
    "dept_lag1_enrollment_pct", "dept_roll3_enrollment_mean_pct",
    "dept_same_season_lag1_pct", "dept_same_season_roll3_pct",
    "same_season_lag1", "same_season_lag2", "same_season_roll3",
    "same_season_cluster_lag1",
    "subj_hist_max", "subj_hist_mean", "subj_hist_p75",
    "TOTAL_UNITS", "LECTURE_UNITS", "LAB_UNITS", "PREPARATION_UNITS",
    "course_num", "course_level", "is_grad_level",
    "term_year", "term_sortkey",
    "hist_Y_sum", "hist_count", "hist_Y_rate",
    "dept_hist_Y_rate", "dept_term_size",
    "n_sections", "n_lecture", "n_recitation",
]
FEAT_COLS = NUM_COLS + CAT_COLS


def build_X(df: pd.DataFrame) -> pd.DataFrame:
    X = df[FEAT_COLS].copy()
    for col in CAT_COLS:
        X[col] = X[col].astype("category")
    return X


def train_eval(df, val_cutoff=2016.0, params=None):
    X = build_X(df)
    y = df["label"].values

    train_mask = df["term_sortkey"] < val_cutoff
    val_mask = df["term_sortkey"] >= val_cutoff

    X_tr, y_tr = X[train_mask], y[train_mask]
    X_val, y_val = X[val_mask], y[val_mask]
    print(f"Train size: {train_mask.sum():,}  Val size: {val_mask.sum():,}")
    print(f"Train Y%: {y_tr.mean():.3f}  Val Y%: {y_val.mean():.3f}")

    default_params = dict(
        objective="binary",
        metric="binary_logloss",
        num_leaves=255,
        learning_rate=0.04,
        feature_fraction=0.8,
        bagging_fraction=0.8,
        bagging_freq=5,
        min_child_samples=15,
        reg_alpha=0.1,
        reg_lambda=0.1,
        n_estimators=3000,
        class_weight="balanced",
        verbose=-1,
        n_jobs=-1,
        random_state=42,
    )
    if params:
        default_params.update(params)

    model = lgb.LGBMClassifier(**default_params)
    model.fit(
        X_tr, y_tr,
        eval_set=[(X_val, y_val)],
        callbacks=[
            lgb.early_stopping(120, verbose=False),
            lgb.log_evaluation(100),
        ],
        categorical_feature=CAT_COLS,
    )
    print(f"Best iteration: {model.best_iteration_}")

    val_proba = model.predict_proba(X_val)[:, 1]

    # Threshold search on validation
    best_f1, best_thr = 0.0, 0.5
    for thr in np.arange(0.05, 0.95, 0.005):
        preds = (val_proba >= thr).astype(int)
        f1 = f1_score(y_val, preds, average="macro", zero_division=0)
        if f1 > best_f1:
            best_f1, best_thr = f1, thr

    val_preds = (val_proba >= best_thr).astype(int)
    macro_f1 = f1_score(y_val, val_preds, average="macro", zero_division=0)
    f1_n = f1_score(y_val, val_preds, pos_label=0, zero_division=0)
    f1_y = f1_score(y_val, val_preds, pos_label=1, zero_division=0)
    print(f"\nVal macro F1 (thr={best_thr:.3f}): {macro_f1:.4f}  [F1-N={f1_n:.4f}, F1-Y={f1_y:.4f}]")

    fi = pd.Series(model.feature_importances_, index=FEAT_COLS).sort_values(ascending=False)
    print("\nTop 20 features:")
    print(fi.head(20).to_string())

    return model, best_thr, macro_f1


def main():
    df = load_all_features()

    model, best_thr, val_f1 = train_eval(df, val_cutoff=2017.0)

    # ── Retrain on full data with best n_estimators ───────────────────────────
    print("\nRetraining on full data…")
    X_full = build_X(df)
    y_full = df["label"].values

    model_full = lgb.LGBMClassifier(
        objective="binary",
        num_leaves=255,
        learning_rate=0.04,
        feature_fraction=0.8,
        bagging_fraction=0.8,
        bagging_freq=5,
        min_child_samples=15,
        reg_alpha=0.1,
        reg_lambda=0.1,
        n_estimators=model.best_iteration_,
        class_weight="balanced",
        verbose=-1,
        n_jobs=-1,
        random_state=42,
    )
    model_full.fit(X_full, y_full, categorical_feature=CAT_COLS)

    # ── Save predictions ──────────────────────────────────────────────────────
    all_proba = model_full.predict_proba(X_full)[:, 1]
    out = df[["TERM_CODE", "SUBJECT_ID_SORT", "HIGH_ENROLLMENT"]].copy()
    out["prob_Y"] = all_proba
    out["PRED_HIGH_ENROLLMENT"] = np.where(all_proba >= best_thr, "Y", "N")
    out.to_csv(OUT_PRED, index=False)
    print(f"Saved {len(out):,} predictions → {OUT_PRED}")

    model_full.booster_.save_model(
        os.path.join(os.path.dirname(OUT_PRED), "lgb_model.txt")
    )
    with open(os.path.join(os.path.dirname(OUT_PRED), "model_meta.json"), "w") as f:
        json.dump({
            "threshold": best_thr,
            "val_macro_f1": val_f1,
            "best_iter": model.best_iteration_,
            "val_cutoff_sortkey": 2016.0,
            "feature_cols": FEAT_COLS,
            "cat_cols": CAT_COLS,
        }, f, indent=2)
    print("Saved lgb_model.txt and model_meta.json")


if __name__ == "__main__":
    main()
