"""
Inference pipeline for high-enrollment prediction.
Loads a saved LightGBM model and applies the same feature engineering
as solution.py to produce predictions for a test split.

Usage:
    python inference.py --test_dir /path/to/test --train_dir /path/to/train \
                        --model lgb_model.txt --meta model_meta.json \
                        --output predictions_test.csv
"""
import re
import os
import json
import argparse
import numpy as np
import pandas as pd
import lightgbm as lgb

SEASON_ORDER = {"JA": 0, "SP": 1, "SU": 2, "FA": 3}


def term_to_sortkey(tc: str) -> float:
    tc = str(tc).strip()
    m = re.match(r"(\d{4})(FA|SP|JA|SU|10)$", tc)
    if m:
        year = int(m.group(1))
        season = m.group(2)
        return year + (0.25 if season == "10" else SEASON_ORDER[season] / 10)
    try:
        return float(tc[:4])
    except Exception:
        return 0.0


def extract_course_features(df: pd.DataFrame) -> pd.DataFrame:
    df["dept_prefix"] = df["SUBJECT_ID_SORT"].str.extract(r"^([^.]+)")[0]
    df["course_num"] = pd.to_numeric(
        df["SUBJECT_ID_SORT"].str.extract(r"\.(\d+)")[0], errors="coerce"
    ).fillna(-1)
    df["course_level"] = (df["course_num"] // 100).clip(-1, 20).astype(int)
    df["is_grad_level"] = (df["course_num"] >= 600).astype(int)
    df["term_season"] = df["TERM_CODE"].str.extract(r"(FA|SP|JA|SU|10)$")[0].fillna("UNK")
    df["term_year"] = pd.to_numeric(df["TERM_CODE"].str[:4], errors="coerce").fillna(0).astype(int)
    df["term_sortkey"] = df["TERM_CODE"].apply(term_to_sortkey)
    return df


def load_features(
    data_dir: str,
    gold_df: pd.DataFrame,
    train_gold_df: pd.DataFrame | None = None,
    ss_extra: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """Build feature matrix for rows in gold_df using data from data_dir.

    Args:
        data_dir: directory containing CSV tables.
        gold_df: DataFrame with TERM_CODE, SUBJECT_ID_SORT (prediction keys).
        train_gold_df: gold labels from training (for hist_Y_rate computation).
                       Pass None at training time (will use gold_df labels).
        ss_extra: extra SUBJECT_SUMMARY rows from train_dir (for same-season lags).
    """
    d = data_dir

    ehf = pd.read_csv(f"{d}/ENROLLMENT_HISTORY_FEATURES.csv")

    sos = pd.read_csv(
        f"{d}/SUBJECT_OFFERED_SUMMARY.csv",
        usecols=[
            "TERM_CODE", "SUBJECT_ID_SORT", "COURSE_NUMBER",
            "CLUSTER_TYPE", "HGN_CODE", "OFFER_DEPT_CODE", "OFFER_SCHOOL_NAME",
            "TOTAL_UNITS", "LECTURE_UNITS", "LAB_UNITS", "PREPARATION_UNITS",
        ],
        low_memory=False,
    )

    so = pd.read_csv(
        f"{d}/SUBJECT_OFFERED.csv",
        usecols=["TERM_CODE", "SUBJECT_ID_SORT",
                 "IS_LECTURE_SECTION", "IS_LAB_SECTION", "IS_RECITATION_SECTION"],
        low_memory=False,
    )
    sections = so.groupby(["TERM_CODE", "SUBJECT_ID_SORT"]).agg(
        n_sections=("IS_LECTURE_SECTION", "count"),
        n_lecture=("IS_LECTURE_SECTION", lambda x: (x == "Y").sum()),
        n_recitation=("IS_RECITATION_SECTION", lambda x: (x == "Y").sum()),
    ).reset_index()

    ccc = pd.read_csv(
        f"{d}/CIS_COURSE_CATALOG.csv",
        usecols=["SUBJECT_CODE", "SUBJECT_NUMBER", "GIR_ATTRIBUTE", "HASS_ATTRIBUTE"],
        low_memory=False,
    )
    ccc["SUBJECT_ID_SORT"] = (
        ccc["SUBJECT_CODE"].astype(str).str.strip()
        + "."
        + ccc["SUBJECT_NUMBER"].astype(str).str.strip()
    )
    gir = (
        ccc.groupby("SUBJECT_ID_SORT")["GIR_ATTRIBUTE"]
        .agg(lambda x: x.mode().iloc[0] if x.notna().any() else np.nan)
        .reset_index().rename(columns={"GIR_ATTRIBUTE": "gir_attribute"})
    )
    hass = (
        ccc.groupby("SUBJECT_ID_SORT")["HASS_ATTRIBUTE"]
        .agg(lambda x: x.mode().iloc[0] if x.notna().any() else np.nan)
        .reset_index().rename(columns={"HASS_ATTRIBUTE": "hass_attribute"})
    )

    # Load SUBJECT_SUMMARY from this dir
    ss_test = pd.read_csv(
        f"{d}/SUBJECT_SUMMARY.csv",
        usecols=["TERM_CODE", "SUBJECT_ID_SORT", "SUBJECT_ENROLLMENT_CREDIT",
                 "CLUSTER_ENROLLMENT_CREDIT"],
        low_memory=False,
    )
    # Combine with extra historical ss if provided
    if ss_extra is not None:
        ss_all = pd.concat([ss_extra, ss_test], ignore_index=True).drop_duplicates(
            subset=["TERM_CODE", "SUBJECT_ID_SORT"]
        )
    else:
        ss_all = ss_test

    ss_all["term_sortkey_ss"] = ss_all["TERM_CODE"].apply(term_to_sortkey)
    ss_all["season_ss"] = ss_all["TERM_CODE"].str.extract(r"(FA|SP|JA|SU|10)$")[0].fillna("UNK")
    ss_all = ss_all.sort_values(["SUBJECT_ID_SORT", "season_ss", "term_sortkey_ss"]).reset_index(drop=True)

    grp_ss_season = ss_all.groupby(["SUBJECT_ID_SORT", "season_ss"])
    ss_all["same_season_lag1"] = grp_ss_season["SUBJECT_ENROLLMENT_CREDIT"].transform(lambda s: s.shift(1))
    ss_all["same_season_lag2"] = grp_ss_season["SUBJECT_ENROLLMENT_CREDIT"].transform(lambda s: s.shift(2))
    ss_all["same_season_roll3"] = grp_ss_season["SUBJECT_ENROLLMENT_CREDIT"].transform(
        lambda s: s.shift(1).rolling(3, min_periods=1).mean()
    )
    ss_all["same_season_cluster_lag1"] = grp_ss_season["CLUSTER_ENROLLMENT_CREDIT"].transform(lambda s: s.shift(1))

    ss_chron = ss_all.sort_values(["SUBJECT_ID_SORT", "term_sortkey_ss"]).copy()
    grp_ss_all = ss_chron.groupby("SUBJECT_ID_SORT")["SUBJECT_ENROLLMENT_CREDIT"]
    ss_chron["subj_hist_max"] = grp_ss_all.transform(lambda s: s.shift(1).expanding().max())
    ss_chron["subj_hist_mean"] = grp_ss_all.transform(lambda s: s.shift(1).expanding().mean())
    ss_chron["subj_hist_p75"] = grp_ss_all.transform(
        lambda s: s.shift(1).expanding().quantile(0.75)
    )
    ss_all_stats = ss_chron.set_index(["TERM_CODE", "SUBJECT_ID_SORT"])[
        ["subj_hist_max", "subj_hist_mean", "subj_hist_p75"]
    ]
    ss_all = ss_all.join(ss_all_stats, on=["TERM_CODE", "SUBJECT_ID_SORT"])
    ss_feats = ss_all[["TERM_CODE", "SUBJECT_ID_SORT",
                        "same_season_lag1", "same_season_lag2", "same_season_roll3",
                        "same_season_cluster_lag1",
                        "subj_hist_max", "subj_hist_mean", "subj_hist_p75"]]

    # ── merge all features onto gold keys ─────────────────────────────────────
    df = gold_df.merge(ehf, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")
    df = df.merge(sos, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")
    df = df.merge(sections, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")
    df = df.merge(ss_feats, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")
    df = df.merge(gir, on="SUBJECT_ID_SORT", how="left")
    df = df.merge(hass, on="SUBJECT_ID_SORT", how="left")
    df = extract_course_features(df)

    # ── derived enrollment features ───────────────────────────────────────────
    df["lag1_nonzero"] = (df["lag1_enrollment"] > 0).astype(int)
    df["lag2_nonzero"] = (df["lag2_enrollment"] > 0).astype(int)
    df["enrollment_trend"] = df["lag1_enrollment"] - df["lag2_enrollment"]
    df["enrollment_trend_pct"] = df["enrollment_trend"] / (df["lag2_enrollment"] + 1)

    for col in ["lag1_enrollment", "roll3_enrollment_mean",
                "same_season_lag1", "same_season_roll3"]:
        df[f"dept_{col}_pct"] = (
            df.groupby(["OFFER_DEPT_CODE", "TERM_CODE"])[col]
            .rank(pct=True, na_option="keep")
        )

    # ── historical label stats ─────────────────────────────────────────────────
    if train_gold_df is not None:
        # Use training labels to compute hist_Y_rate
        hist = (
            train_gold_df.assign(label=lambda x: (x.HIGH_ENROLLMENT == "Y").astype(int))
            .groupby("SUBJECT_ID_SORT")["label"]
            .agg(hist_Y_sum="sum", hist_count="count")
            .reset_index()
        )
        hist["hist_Y_rate"] = hist["hist_Y_sum"] / hist["hist_count"].replace(0, np.nan)
        df = df.merge(hist, on="SUBJECT_ID_SORT", how="left")
        df["hist_Y_sum"] = df["hist_Y_sum"].fillna(0)
        df["hist_count"] = df["hist_count"].fillna(0)
        df["hist_Y_rate"] = df["hist_Y_rate"].fillna(-1)

        # dept hist Y rate
        dept_hist = (
            train_gold_df.assign(label=lambda x: (x.HIGH_ENROLLMENT == "Y").astype(int))
            .merge(sos[["TERM_CODE", "SUBJECT_ID_SORT", "OFFER_DEPT_CODE"]],
                   on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")
            .groupby("OFFER_DEPT_CODE")["label"]
            .mean()
            .reset_index(name="dept_hist_Y_rate")
        )
        df = df.merge(dept_hist, on="OFFER_DEPT_CODE", how="left")
    else:
        # Fill with zeros (will be overridden at training time)
        df["hist_Y_sum"] = 0.0
        df["hist_count"] = 0.0
        df["hist_Y_rate"] = -1.0
        df["dept_hist_Y_rate"] = np.nan

    dept_size = (
        df.groupby(["OFFER_DEPT_CODE", "TERM_CODE"])
        .size()
        .reset_index(name="dept_term_size")
    )
    df = df.merge(dept_size, on=["OFFER_DEPT_CODE", "TERM_CODE"], how="left")

    return df


CAT_COLS = [
    "dept_prefix", "COURSE_NUMBER", "CLUSTER_TYPE",
    "HGN_CODE", "OFFER_DEPT_CODE", "OFFER_SCHOOL_NAME",
    "term_season", "SUBJECT_ID_SORT",
    "gir_attribute", "hass_attribute",
]
NUM_COLS = [
    "lag1_enrollment", "lag2_enrollment", "roll3_enrollment_mean",
    "lag1_nonzero", "lag2_nonzero",
    "enrollment_trend", "enrollment_trend_pct",
    "dept_lag1_enrollment_pct", "dept_roll3_enrollment_mean_pct",
    "dept_same_season_lag1_pct", "dept_same_season_roll3_pct",
    "same_season_lag1", "same_season_lag2", "same_season_roll3",
    "same_season_cluster_lag1",
    "subj_hist_max", "subj_hist_mean", "subj_hist_p75",
    "TOTAL_UNITS", "LECTURE_UNITS", "LAB_UNITS", "PREPARATION_UNITS",
    "course_num", "course_level", "is_grad_level",
    "term_year", "term_sortkey",
    "hist_Y_sum", "hist_count", "hist_Y_rate",
    "dept_hist_Y_rate", "dept_term_size",
    "n_sections", "n_lecture", "n_recitation",
]
FEAT_COLS = NUM_COLS + CAT_COLS


def build_X(df: pd.DataFrame) -> pd.DataFrame:
    X = df[FEAT_COLS].copy()
    for col in CAT_COLS:
        X[col] = X[col].astype("category")
    return X


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--test_dir", required=True)
    parser.add_argument("--train_dir", default="train")
    parser.add_argument("--model", default="lgb_model.txt")
    parser.add_argument("--meta", default="model_meta.json")
    parser.add_argument("--output", default="predictions_test.csv")
    args = parser.parse_args()

    with open(args.meta) as f:
        meta = json.load(f)

    threshold = meta["threshold"]
    print(f"Model threshold: {threshold}")

    # Load gold test keys
    test_gold = pd.read_csv(f"{args.test_dir}/gold_enrollment_test.csv")

    # Load training labels for hist_Y_rate computation
    train_gold = pd.read_csv(f"{args.train_dir}/gold_enrollment_train.csv")

    # Load training SUBJECT_SUMMARY for same-season lag lookback
    ss_train = pd.read_csv(
        f"{args.train_dir}/SUBJECT_SUMMARY.csv",
        usecols=["TERM_CODE", "SUBJECT_ID_SORT", "SUBJECT_ENROLLMENT_CREDIT",
                 "CLUSTER_ENROLLMENT_CREDIT"],
        low_memory=False,
    )

    df = load_features(
        data_dir=args.test_dir,
        gold_df=test_gold[["TERM_CODE", "SUBJECT_ID_SORT"]],
        train_gold_df=train_gold,
        ss_extra=ss_train,
    )

    booster = lgb.Booster(model_file=args.model)
    X = build_X(df)
    proba = booster.predict(X.values, num_iteration=booster.best_iteration)

    out = test_gold[["TERM_CODE", "SUBJECT_ID_SORT"]].copy()
    out["prob_Y"] = proba
    out["HIGH_ENROLLMENT"] = np.where(proba >= threshold, "Y", "N")
    out.to_csv(args.output, index=False)
    print(f"Saved {len(out):,} predictions → {args.output}")
    print(f"Y predictions: {(out.HIGH_ENROLLMENT=='Y').sum():,} ({(out.HIGH_ENROLLMENT=='Y').mean():.3f})")


if __name__ == "__main__":
    main()
