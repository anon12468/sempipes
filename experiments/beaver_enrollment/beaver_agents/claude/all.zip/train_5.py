"""
High-enrollment prediction — MIT course offerings.
Label: top quartile enrollment within dept+term among courses with positive enrollment (Y/N).

Trains LightGBM with time-based validation split (last ~2 years held out).
Produces lgbm_model.pkl for use by predict.py.
"""

import os
import re
import pickle
import warnings

import numpy as np
import pandas as pd
import lightgbm as lgb
from sklearn.metrics import f1_score, classification_report

warnings.filterwarnings("ignore")

TRAIN_DIR = os.path.join(os.path.dirname(__file__), "train")
OUT_DIR = os.path.dirname(__file__)


# ── helpers ───────────────────────────────────────────────────────────────────

def term_sort_key(tc):
    season_map = {"JA": 1, "SP": 2, "SU": 3, "FA": 4}
    m = re.match(r"(\d{4})([A-Z]+)", str(tc))
    if m:
        return int(m.group(1)) * 10 + season_map.get(m.group(2), 0)
    return int(str(tc)[:4]) * 10


def parse_term(tc):
    m = re.match(r"(\d{4})([A-Z]+)", str(tc))
    if m:
        return int(m.group(1)), m.group(2)
    return int(str(tc)[:4]), "UN"


# ── load raw data ─────────────────────────────────────────────────────────────

print("Loading raw data …")
gold = pd.read_csv(os.path.join(TRAIN_DIR, "gold_enrollment_train.csv"))
ss   = pd.read_csv(os.path.join(TRAIN_DIR, "SUBJECT_SUMMARY.csv"))
so   = pd.read_csv(os.path.join(TRAIN_DIR, "SUBJECT_OFFERED.csv"), low_memory=False)
cat  = pd.read_csv(os.path.join(TRAIN_DIR, "COURSE_CATALOG_SUBJECT_OFFERED.csv"), low_memory=False)
lib  = pd.read_csv(os.path.join(TRAIN_DIR, "LIBRARY_SUBJECT_OFFERED.csv"))
print(f"  gold {gold.shape} | ss {ss.shape} | so {so.shape} | cat {cat.shape} | lib {lib.shape}")

# ── preprocess subject_summary ────────────────────────────────────────────────

ss["term_sort"] = ss["TERM_CODE"].apply(term_sort_key)
ss["term_season"] = ss["TERM_CODE"].apply(lambda x: parse_term(x)[1])
ss = ss.sort_values("term_sort")

# Merge gold labels into ss so we can compute historical high-enrollment stats
ss = ss.merge(
    gold[["TERM_CODE", "SUBJECT_ID_SORT", "HIGH_ENROLLMENT"]],
    on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left"
)
ss["is_high"] = (ss["HIGH_ENROLLMENT"] == "Y").astype(float)

# ── build expanded subject-level history features (shift-1, no leakage) ───────

print("Building lag features …")
ss_s = ss.sort_values(["SUBJECT_ID_SORT", "term_sort"])

# General lags (any-season)
ss_s["lag1_enroll"]  = ss_s.groupby("SUBJECT_ID_SORT")["SUBJECT_ENROLLMENT_FIFTH_WEEK"].shift(1)
ss_s["lag2_enroll"]  = ss_s.groupby("SUBJECT_ID_SORT")["SUBJECT_ENROLLMENT_FIFTH_WEEK"].shift(2)
ss_s["lag3_enroll"]  = ss_s.groupby("SUBJECT_ID_SORT")["SUBJECT_ENROLLMENT_FIFTH_WEEK"].shift(3)

# Rolling mean over last 3 terms
ss_s["roll3_mean"] = (
    ss_s.groupby("SUBJECT_ID_SORT")["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
    .transform(lambda x: x.shift(1).rolling(3, min_periods=1).mean())
)

# Expanding (all-history) mean and count
ss_s["hist_mean_enroll"] = (
    ss_s.groupby("SUBJECT_ID_SORT")["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
    .transform(lambda x: x.shift(1).expanding().mean())
)
ss_s["hist_count"] = (
    ss_s.groupby("SUBJECT_ID_SORT")["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
    .transform(lambda x: x.shift(1).expanding().count())
)

# Historical high-enrollment rate (fraction of terms labeled Y so far)
ss_s["hist_high_rate"] = (
    ss_s.groupby("SUBJECT_ID_SORT")["is_high"]
    .transform(lambda x: x.shift(1).expanding().mean())
)
ss_s["hist_high_count"] = (
    ss_s.groupby("SUBJECT_ID_SORT")["is_high"]
    .transform(lambda x: x.shift(1).expanding().sum())
)

# Trend: lag1 minus lag2 (positive = enrollment growing)
ss_s["enroll_trend"] = ss_s["lag1_enroll"] - ss_s["lag2_enroll"]

# Positive-enrollment indicator (important for sparse-dept courses like NIH)
ss_s["is_positive"] = (ss_s["SUBJECT_ENROLLMENT_FIFTH_WEEK"] > 0).astype(float)
ss_s["hist_positive_rate"] = (
    ss_s.groupby("SUBJECT_ID_SORT")["is_positive"]
    .transform(lambda x: x.shift(1).expanding().mean())
)
ss_s["hist_positive_count"] = (
    ss_s.groupby("SUBJECT_ID_SORT")["is_positive"]
    .transform(lambda x: x.shift(1).expanding().sum())
)

# Dept-relative rank historically: subj_hist_mean / dept_hist_mean (per dept)
# (captures whether this subject is large relative to its dept peers)
dept_hist = (
    ss.groupby("DEPARTMENT_CODE")["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
    .mean().rename("dept_all_time_mean").reset_index()
)
ss_s = ss_s.merge(dept_hist, on="DEPARTMENT_CODE", how="left")
ss_s["subj_vs_dept_alltime"] = ss_s["hist_mean_enroll"] / (ss_s["dept_all_time_mean"] + 0.01)

# Same-season lags (FA→FA, SP→SP, etc.)
ss_ss = ss_s.sort_values(["SUBJECT_ID_SORT", "term_season", "term_sort"])
ss_s["same_season_lag1"] = (
    ss_ss.groupby(["SUBJECT_ID_SORT", "term_season"])["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
    .shift(1).values
)
ss_s["same_season_lag2"] = (
    ss_ss.groupby(["SUBJECT_ID_SORT", "term_season"])["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
    .shift(2).values
)
# Was the course high-enrollment the last time this season was offered?
ss_s["was_high_same_season"] = (
    ss_ss.groupby(["SUBJECT_ID_SORT", "term_season"])["is_high"]
    .shift(1).values
)
# Historical high rate within same season only
ss_s["hist_high_rate_same_season"] = (
    ss_ss.groupby(["SUBJECT_ID_SORT", "term_season"])["is_high"]
    .transform(lambda x: x.shift(1).expanding().mean()).values
)

# First-week enrollment lags (early signal of interest)
ss_s["lag1_first_week"] = ss_s.groupby("SUBJECT_ID_SORT")["SUBJECT_ENROLLMENT_FIRST_WEEK"].shift(1)

# ── department-level per-term stats (lag-1, to avoid leakage) ─────────────────

print("Building department stats …")
dept_stats = (
    ss.groupby(["TERM_CODE", "DEPARTMENT_CODE"])["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
    .agg(dept_mean="mean", dept_median="median", dept_std="std", dept_n="count")
    .reset_index()
)
dept_stats["term_sort"] = dept_stats["TERM_CODE"].apply(term_sort_key)
dept_stats = dept_stats.sort_values(["DEPARTMENT_CODE", "term_sort"])
dept_stats["dept_prev_mean"]   = dept_stats.groupby("DEPARTMENT_CODE")["dept_mean"].shift(1)
dept_stats["dept_prev_median"] = dept_stats.groupby("DEPARTMENT_CODE")["dept_median"].shift(1)
dept_stats["dept_prev_n"]      = dept_stats.groupby("DEPARTMENT_CODE")["dept_n"].shift(1)
dept_stats["dept_prev_std"]    = dept_stats.groupby("DEPARTMENT_CODE")["dept_std"].shift(1)

# Also compute dept's 75th percentile of enrollment per term (proxy for Y threshold)
dept_q75 = (
    ss[ss["SUBJECT_ENROLLMENT_FIFTH_WEEK"] > 0]
    .groupby(["TERM_CODE", "DEPARTMENT_CODE"])["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
    .quantile(0.75).rename("dept_q75_enroll").reset_index()
)
dept_q75["term_sort"] = dept_q75["TERM_CODE"].apply(term_sort_key)
dept_q75 = dept_q75.sort_values(["DEPARTMENT_CODE", "term_sort"])
dept_q75["dept_prev_q75"] = dept_q75.groupby("DEPARTMENT_CODE")["dept_q75_enroll"].shift(1)
dept_stats = dept_stats.merge(
    dept_q75[["TERM_CODE", "DEPARTMENT_CODE", "dept_prev_q75"]],
    on=["TERM_CODE", "DEPARTMENT_CODE"], how="left"
)

# ── subject-offered: instructor & section type ────────────────────────────────

# Section count per course-term (more sections = popular course)
n_sections = (
    so.groupby(["TERM_CODE", "SUBJECT_ID_SORT"]).size()
    .reset_index(name="n_sections")
)
n_sections_s = n_sections.merge(
    gold[["TERM_CODE", "SUBJECT_ID_SORT"]].assign(
        term_sort=gold["TERM_CODE"].apply(term_sort_key)
    ),
    on=["TERM_CODE", "SUBJECT_ID_SORT"], how="right"
).sort_values(["SUBJECT_ID_SORT", "term_sort"])
n_sections_s["lag1_n_sections"] = (
    n_sections_s.groupby("SUBJECT_ID_SORT")["n_sections"].shift(1)
)

# Keep master-section rows only to avoid duplicates
so_master = so[so["IS_MASTER_SECTION"] == "Y"].copy()
so_sub = so_master[["TERM_CODE", "SUBJECT_ID_SORT",
                     "OFFER_DEPT_CODE", "OFFER_SCHOOL_NAME",
                     "CLUSTER_TYPE", "HGN_CODE", "HGN_CODE_DESC",
                     "RESPONSIBLE_FACULTY_NAME",
                     "IS_LECTURE_SECTION", "IS_LAB_SECTION",
                     "IS_RECITATION_SECTION", "IS_DESIGN_SECTION"]].drop_duplicates(
    subset=["TERM_CODE", "SUBJECT_ID_SORT"]
)

# Instructor historical stats: avg enrollment and high-enrollment rate
instr_hist = ss_s.merge(
    so_sub[["TERM_CODE", "SUBJECT_ID_SORT", "RESPONSIBLE_FACULTY_NAME"]],
    on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left"
)
instr_hist = instr_hist[instr_hist["RESPONSIBLE_FACULTY_NAME"].notna()].copy()
instr_hist = instr_hist.sort_values(["RESPONSIBLE_FACULTY_NAME", "term_sort"])

instr_stats = (
    instr_hist.groupby(["RESPONSIBLE_FACULTY_NAME", "TERM_CODE"])
    ["SUBJECT_ENROLLMENT_FIFTH_WEEK"].mean()
    .reset_index()
    .sort_values(["RESPONSIBLE_FACULTY_NAME", "TERM_CODE"])
)
instr_stats["term_sort"] = instr_stats["TERM_CODE"].apply(term_sort_key)
instr_stats = instr_stats.sort_values(["RESPONSIBLE_FACULTY_NAME", "term_sort"])
instr_stats["instr_hist_mean_enroll"] = (
    instr_stats.groupby("RESPONSIBLE_FACULTY_NAME")["SUBJECT_ENROLLMENT_FIFTH_WEEK"]
    .transform(lambda x: x.shift(1).expanding().mean())
)

instr_is_high = (
    instr_hist.groupby(["RESPONSIBLE_FACULTY_NAME", "TERM_CODE"])["is_high"]
    .mean().reset_index()
)
instr_is_high["term_sort"] = instr_is_high["TERM_CODE"].apply(term_sort_key)
instr_is_high = instr_is_high.sort_values(["RESPONSIBLE_FACULTY_NAME", "term_sort"])
instr_is_high["instr_hist_high_rate"] = (
    instr_is_high.groupby("RESPONSIBLE_FACULTY_NAME")["is_high"]
    .transform(lambda x: x.shift(1).expanding().mean())
)

instr_features = instr_stats[["TERM_CODE", "RESPONSIBLE_FACULTY_NAME", "instr_hist_mean_enroll"]].merge(
    instr_is_high[["TERM_CODE", "RESPONSIBLE_FACULTY_NAME", "instr_hist_high_rate"]],
    on=["TERM_CODE", "RESPONSIBLE_FACULTY_NAME"], how="left"
)

# ── library indicator (lagged: was this course in library last term?) ─────────

lib_ind = lib[["TERM_CODE", "SUBJECT_ID_SORT"]].drop_duplicates()
lib_ind["has_library"] = 1
lib_ind["term_sort_lib"] = lib_ind["TERM_CODE"].apply(term_sort_key)
lib_ind = lib_ind.sort_values(["SUBJECT_ID_SORT", "term_sort_lib"])
lib_ind["lag1_has_library"] = lib_ind.groupby("SUBJECT_ID_SORT")["has_library"].shift(1)

# ── course catalog features ───────────────────────────────────────────────────

# Build SUBJECT_ID_SORT for catalog
cat["SUBJECT_ID_SORT"] = cat["SUBJECT_CODE"].astype(str) + "." + cat["SUBJECT_NUMBER"].astype(str)

catalog_feats = ["SUBJECT_ID_SORT", "GIR_ATTRIBUTE", "HASS_ATTRIBUTE",
                 "COMM_REQ_ATTRIBUTE", "GRADE_TYPE", "GRADE_RULE",
                 "TOTAL_UNITS", "IS_OFFERED_FALL_TERM", "IS_OFFERED_SPRING_TERM",
                 "IS_OFFERED_IAP", "IS_OFFERED_SUMMER_TERM",
                 "PREREQUISITES", "JOINT_SUBJECTS", "MEETS_WITH_SUBJECTS",
                 "EQUIVALENT_SUBJECTS"]
catalog_feats = [c for c in catalog_feats if c in cat.columns]

cat_sorted = cat.sort_values("ACADEMIC_YEAR", ascending=False)
catalog = cat_sorted.drop_duplicates("SUBJECT_ID_SORT")[catalog_feats].copy()

# Derived: has prerequisites, has joint subjects
catalog["has_prereqs"] = catalog["PREREQUISITES"].notna().astype(int)
catalog["has_joint"]   = catalog["JOINT_SUBJECTS"].notna().astype(int)
catalog["has_meets_with"] = catalog["MEETS_WITH_SUBJECTS"].notna().astype(int)
catalog["gir_is_required"] = catalog["GIR_ATTRIBUTE"].isin(
    ["PHY1", "PHY2", "CAL1", "CAL2", "CHEM", "BIOL", "REST", "LAB", "LAB2", "HE"]
).astype(int)

# ── assemble main training frame ──────────────────────────────────────────────

print("Assembling feature frame …")
df = gold.copy()
df["label"] = (df["HIGH_ENROLLMENT"] == "Y").astype(int)
df["term_sort"] = df["TERM_CODE"].apply(term_sort_key)

# Term features
df[["term_year", "term_season"]] = df["TERM_CODE"].apply(
    lambda x: pd.Series(parse_term(x))
)

# Course number features
df["course_prefix"]     = df["SUBJECT_ID_SORT"].str.split(".").str[0]
df["course_num_str"]    = df["SUBJECT_ID_SORT"].str.split(".").str[-1]
df["course_num_numeric"] = pd.to_numeric(
    df["course_num_str"].str.extract(r"(\d+)")[0], errors="coerce"
)
df["is_grad_level"] = (df["course_num_numeric"] >= 500).astype(int)

# Section count features
df = df.merge(
    n_sections_s[["TERM_CODE", "SUBJECT_ID_SORT", "n_sections", "lag1_n_sections"]],
    on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left"
)

# Subject units (from SUBJECT_SUMMARY — same for a given term row)
unit_cols = ["TOTAL_UNITS", "LECTURE_UNITS", "LAB_UNITS", "PREP_UNITS", "DESIGN_UNITS"]
df = df.merge(
    ss_s[["TERM_CODE", "SUBJECT_ID_SORT"] + unit_cols].drop_duplicates(["TERM_CODE", "SUBJECT_ID_SORT"]),
    on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left"
)

# Subject history features
lag_cols = [
    "lag1_enroll", "lag2_enroll", "lag3_enroll", "roll3_mean",
    "hist_mean_enroll", "hist_count", "hist_high_rate", "hist_high_count",
    "enroll_trend", "same_season_lag1", "same_season_lag2",
    "was_high_same_season", "hist_high_rate_same_season", "lag1_first_week",
    "hist_positive_rate", "hist_positive_count", "subj_vs_dept_alltime",
]
df = df.merge(
    ss_s[["TERM_CODE", "SUBJECT_ID_SORT"] + lag_cols],
    on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left"
)

# Subject-offered features
df = df.merge(so_sub, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")

# Instructor features
df = df.merge(
    instr_features.rename(columns={"RESPONSIBLE_FACULTY_NAME": "_instr"}),
    left_on=["TERM_CODE", "RESPONSIBLE_FACULTY_NAME"],
    right_on=["TERM_CODE", "_instr"], how="left"
).drop(columns=["_instr"], errors="ignore")

# Department stats
dept_merge = dept_stats[["TERM_CODE", "DEPARTMENT_CODE",
                          "dept_prev_mean", "dept_prev_median",
                          "dept_prev_n", "dept_prev_std", "dept_prev_q75"]].rename(
    columns={"DEPARTMENT_CODE": "OFFER_DEPT_CODE"}
)
df = df.merge(dept_merge, on=["TERM_CODE", "OFFER_DEPT_CODE"], how="left")

# Library features
df = df.merge(lib_ind[["TERM_CODE","SUBJECT_ID_SORT","has_library"]], on=["TERM_CODE","SUBJECT_ID_SORT"], how="left")
df["has_library"] = df["has_library"].fillna(0)
df = df.merge(lib_ind[["TERM_CODE","SUBJECT_ID_SORT","lag1_has_library"]], on=["TERM_CODE","SUBJECT_ID_SORT"], how="left")

# Catalog features
df = df.merge(catalog, on="SUBJECT_ID_SORT", how="left")

# ── relative / ratio features ──────────────────────────────────────────────────

df["lag1_vs_dept"]      = df["lag1_enroll"] / (df["dept_prev_mean"] + 1)
df["lag1_vs_hist"]      = df["lag1_enroll"] / (df["hist_mean_enroll"] + 1)
df["ss_lag1_vs_dept"]   = df["same_season_lag1"] / (df["dept_prev_mean"] + 1)
df["ss_lag1_vs_hist"]   = df["same_season_lag1"] / (df["hist_mean_enroll"] + 1)
# Lag1 vs dept 75th percentile (>1 = was above threshold historically)
df["lag1_vs_dept_q75"]  = df["lag1_enroll"] / (df["dept_prev_q75"] + 0.5)
df["hist_mean_vs_q75"]  = df["hist_mean_enroll"] / (df["dept_prev_q75"] + 0.5)
df["hist_count"]        = df["hist_count"].fillna(0)
df["hist_high_count"]   = df["hist_high_count"].fillna(0)

# ── feature list ──────────────────────────────────────────────────────────────

NUM_FEATURES = [
    # lag enrollment
    "lag1_enroll", "lag2_enroll", "lag3_enroll", "roll3_mean",
    "same_season_lag1", "same_season_lag2", "lag1_first_week",
    # history
    "hist_mean_enroll", "hist_count",
    "hist_high_rate", "hist_high_count",
    "hist_high_rate_same_season",
    "was_high_same_season",
    "hist_positive_rate", "hist_positive_count",
    "subj_vs_dept_alltime",
    # trend
    "enroll_trend",
    # ratios
    "lag1_vs_dept", "lag1_vs_hist", "ss_lag1_vs_dept", "ss_lag1_vs_hist",
    "lag1_vs_dept_q75", "hist_mean_vs_q75",
    # dept stats
    "dept_prev_mean", "dept_prev_median", "dept_prev_n", "dept_prev_std", "dept_prev_q75",
    # instructor stats
    "instr_hist_mean_enroll", "instr_hist_high_rate",
    # section count
    "n_sections", "lag1_n_sections",
    # library indicator
    "has_library", "lag1_has_library",
    # course numeric / units (from SUBJECT_SUMMARY)
    "TOTAL_UNITS", "LECTURE_UNITS", "LAB_UNITS", "PREP_UNITS", "DESIGN_UNITS",
    "course_num_numeric", "is_grad_level",
    # catalog
    "has_prereqs", "has_joint", "has_meets_with", "gir_is_required",
    # time
    "term_year",
]

CAT_FEATURES = [
    "term_season", "course_prefix",
    "OFFER_DEPT_CODE", "OFFER_SCHOOL_NAME",
    "CLUSTER_TYPE", "HGN_CODE", "HGN_CODE_DESC",
    "GIR_ATTRIBUTE", "HASS_ATTRIBUTE", "COMM_REQ_ATTRIBUTE",
    "GRADE_TYPE", "GRADE_RULE",
    "IS_OFFERED_FALL_TERM", "IS_OFFERED_SPRING_TERM",
    "IS_OFFERED_IAP", "IS_OFFERED_SUMMER_TERM",
    "RESPONSIBLE_FACULTY_NAME",
]

FEATURES = [f for f in NUM_FEATURES + CAT_FEATURES if f in df.columns]
print(f"Total features: {len(FEATURES)}")

for col in CAT_FEATURES:
    if col in df.columns:
        df[col] = df[col].astype("category")

# ── time-based train / val split ──────────────────────────────────────────────

VAL_CUTOFF = term_sort_key("2017FA")  # hold out 2017FA … 2018SU

train_mask = df["term_sort"] < VAL_CUTOFF
val_mask   = df["term_sort"] >= VAL_CUTOFF

X_train, y_train = df.loc[train_mask, FEATURES], df.loc[train_mask, "label"]
X_val,   y_val   = df.loc[val_mask,   FEATURES], df.loc[val_mask,   "label"]

print(f"\nTrain: {train_mask.sum():,} rows | Val: {val_mask.sum():,} rows")
print(f"Val positive rate: {y_val.mean():.3f}")

# ── class weight ──────────────────────────────────────────────────────────────

scale_pos_weight = (y_train == 0).sum() / (y_train == 1).sum()
print(f"scale_pos_weight: {scale_pos_weight:.2f}")

# ── LightGBM ──────────────────────────────────────────────────────────────────

print("\nTraining LightGBM ensemble (3 seeds) …")
base_params = {
    "objective": "binary",
    "metric": "binary_logloss",
    "n_estimators": 3000,
    "learning_rate": 0.02,
    "num_leaves": 255,
    "max_depth": -1,
    "min_child_samples": 10,
    "feature_fraction": 0.75,
    "bagging_fraction": 0.75,
    "bagging_freq": 5,
    "reg_alpha": 0.05,
    "reg_lambda": 0.1,
    "min_split_gain": 0.001,
    "scale_pos_weight": scale_pos_weight,
    "n_jobs": -1,
    "verbose": -1,
}

cat_in_features = [c for c in CAT_FEATURES if c in FEATURES]

SEEDS = [42, 137, 271]
val_probas = []
best_iters = []

for seed in SEEDS:
    params = dict(base_params, random_state=seed)
    m = lgb.LGBMClassifier(**params)
    m.fit(
        X_train, y_train,
        eval_set=[(X_val, y_val)],
        eval_metric="binary_logloss",
        callbacks=[
            lgb.early_stopping(stopping_rounds=80, verbose=False),
            lgb.log_evaluation(period=500),
        ],
        categorical_feature=cat_in_features,
    )
    val_probas.append(m.predict_proba(X_val)[:, 1])
    best_iters.append(m.best_iteration_)
    print(f"  seed={seed}: best_iter={m.best_iteration_}")

val_proba = np.mean(val_probas, axis=0)  # ensemble average

# ── evaluate ──────────────────────────────────────────────────────────────────

best_f1, best_thresh = 0, 0.5
for t in np.arange(0.1, 0.9, 0.005):
    preds = (val_proba >= t).astype(int)
    f1 = f1_score(y_val, preds, average="macro", zero_division=0)
    if f1 > best_f1:
        best_f1, best_thresh = f1, t

print(f"\nBest threshold: {best_thresh:.3f}  |  Val macro F1: {best_f1:.4f}")
val_preds = (val_proba >= best_thresh).astype(int)
print(classification_report(y_val, val_preds, target_names=["N", "Y"]))
print(f"Default 0.5 macro F1: {f1_score(y_val, (val_proba>=0.5).astype(int), average='macro'):.4f}")

# Feature importance from last model
fi = pd.Series(m.feature_importances_, index=FEATURES).sort_values(ascending=False)
print("\nTop 25 features:")
print(fi.head(25).to_string())

# ── retrain on full data (ensemble) ──────────────────────────────────────────

print("\nRetraining ensemble on full dataset …")
X_full = df[FEATURES]
y_full = df["label"]

models_full = []
for seed, best_iter in zip(SEEDS, best_iters):
    params_full = dict(base_params, random_state=seed, n_estimators=best_iter + 100)
    mf = lgb.LGBMClassifier(**params_full)
    mf.fit(X_full, y_full, categorical_feature=cat_in_features)
    models_full.append(mf)
    print(f"  seed={seed} done")

model_full = models_full  # list of models

# ── persist artifacts ─────────────────────────────────────────────────────────

bundle = {
    "models": models_full,        # list of LGBMClassifier (ensemble)
    "features": FEATURES,
    "cat_features": cat_in_features,
    "num_features": NUM_FEATURES,
    "threshold": best_thresh,
    "val_macro_f1": best_f1,
    "seeds": SEEDS,
}

model_path = os.path.join(OUT_DIR, "lgbm_model.pkl")
with open(model_path, "wb") as f:
    pickle.dump(bundle, f)
print(f"\nModel saved → {model_path}")

val_out = df.loc[val_mask, ["TERM_CODE", "SUBJECT_ID_SORT", "label"]].copy()
val_out["proba"] = val_proba
val_out["pred"]  = val_preds
val_out.to_csv(os.path.join(OUT_DIR, "val_predictions.csv"), index=False)

print("Done.")
