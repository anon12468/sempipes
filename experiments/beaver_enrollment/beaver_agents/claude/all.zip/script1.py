"""
High-enrollment prediction pipeline v2.
LightGBM with lag + catalog + instructor features.
Predicts HIGH_ENROLLMENT (Y/N) per (TERM_CODE, SUBJECT_ID_SORT).

Usage (training):
  PYTHONPATH=/tmp/lgbm_pkg python3 solve_v2.py

Usage (test inference once test dir is available):
  PYTHONPATH=/tmp/lgbm_pkg python3 solve_v2.py --test <TEST_DATA_DIR>
"""
import os, sys, json, argparse, warnings
sys.path.insert(0, "/tmp/lgbm_pkg")
import numpy as np
import pandas as pd
import lightgbm as lgb
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import f1_score, classification_report
warnings.filterwarnings("ignore")

parser = argparse.ArgumentParser()
parser.add_argument("--test", default="../test", help="Path to test data dir (optional)")
args = parser.parse_args()

TRAIN_DIR   = "train"
RANDOM_STATE = 42
SEASON_ORDER = {"JA": 0, "10": 1, "SP": 2, "SU": 3, "FA": 4}


def term_ord(tc: str) -> float:
    y = int(str(tc)[:4]); s = str(tc)[4:]
    return y + SEASON_ORDER.get(s, 2) / 10.0


# ─────────────────────────────────────────────────────────────────────────────
# 1. Load tables (minimal columns to keep memory low)
# ─────────────────────────────────────────────────────────────────────────────
print("Loading data...", flush=True)
gold = pd.read_csv(os.path.join(TRAIN_DIR, "gold_enrollment_train.csv"))
ss   = pd.read_csv(os.path.join(TRAIN_DIR, "SUBJECT_SUMMARY.csv"), low_memory=False,
         usecols=["TERM_CODE", "SUBJECT_ID_SORT", "DEPARTMENT_CODE",
                  "SUBJECT_ENROLLMENT_FIFTH_WEEK"])
sos  = pd.read_csv(os.path.join(TRAIN_DIR, "SUBJECT_OFFERED_SUMMARY.csv"), low_memory=False,
         usecols=["TERM_CODE", "SUBJECT_ID_SORT", "COURSE_NUMBER", "CLUSTER_TYPE",
                  "HGN_CODE", "OFFER_DEPT_CODE", "OFFER_SCHOOL_NAME",
                  "TOTAL_UNITS", "LECTURE_UNITS", "LAB_UNITS", "PREPARATION_UNITS"])
so   = pd.read_csv(os.path.join(TRAIN_DIR, "SUBJECT_OFFERED.csv"), low_memory=False,
         usecols=["TERM_CODE", "SUBJECT_ID_SORT", "IS_MASTER_SECTION",
                  "RESPONSIBLE_FACULTY_NAME"])

for df in [gold, ss, sos, so]:
    df["term_ord"] = df["TERM_CODE"].map(term_ord)
gold["year"]       = gold["TERM_CODE"].str[:4].astype(int)
gold["season_enc"] = gold["TERM_CODE"].str[4:].map(SEASON_ORDER).fillna(2)
print(f"  gold={gold.shape} ss={ss.shape} sos={sos.shape} so={so.shape}", flush=True)


# ─────────────────────────────────────────────────────────────────────────────
# 2. Enrollment percentile rank within (TERM, DEPT) — source of labels
# ─────────────────────────────────────────────────────────────────────────────
print("Computing enrollment percentile ranks...", flush=True)
ss["enroll_5th"] = pd.to_numeric(ss["SUBJECT_ENROLLMENT_FIFTH_WEEK"], errors="coerce").fillna(0)
ss["enroll_pct"] = 0.0
pos = ss["enroll_5th"] > 0
ss.loc[pos, "enroll_pct"] = (
    ss[pos].groupby(["TERM_CODE", "DEPARTMENT_CODE"])["enroll_5th"]
    .transform(lambda x: x.rank(pct=True, method="average"))
)


# ─────────────────────────────────────────────────────────────────────────────
# 3. Course-level lag features (expanding window, shift-1 → no leakage)
# ─────────────────────────────────────────────────────────────────────────────
print("Building course lag features...", flush=True)
sl = ss.sort_values(["SUBJECT_ID_SORT", "term_ord"]).reset_index(drop=True)
g  = sl.groupby("SUBJECT_ID_SORT", sort=False)

sl["hist_n"]         = g["enroll_pct"].transform(lambda x: x.expanding().count().shift(1))
sl["hist_pct_mean"]  = g["enroll_pct"].transform(lambda x: x.expanding().mean().shift(1))
sl["hist_pct_max"]   = g["enroll_pct"].transform(lambda x: x.expanding().max().shift(1))
sl["hist_pct_last1"] = g["enroll_pct"].transform(lambda x: x.shift(1))
sl["hist_pct_last2"] = g["enroll_pct"].transform(lambda x: x.shift(2))
sl["hist_pct_last3"] = g["enroll_pct"].transform(lambda x: x.shift(3))
sl["hist_hi_frac"]   = g["enroll_pct"].transform(lambda x: (x >= 0.75).expanding().mean().shift(1))
sl["hist_ever_hi"]   = g["enroll_pct"].transform(lambda x: (x >= 0.75).expanding().max().shift(1))
sl["hist_e5_mean"]   = g["enroll_5th"].transform(lambda x: x.expanding().mean().shift(1))
sl["hist_e5_last"]   = g["enroll_5th"].transform(lambda x: x.shift(1))
sl["hist_pct_trend"] = sl["hist_pct_last1"] - sl["hist_pct_mean"]

LAG_COLS = ["TERM_CODE", "SUBJECT_ID_SORT",
            "hist_n", "hist_pct_mean", "hist_pct_max",
            "hist_pct_last1", "hist_pct_last2", "hist_pct_last3",
            "hist_hi_frac", "hist_ever_hi", "hist_e5_mean", "hist_e5_last", "hist_pct_trend"]
hist_df = sl[LAG_COLS].copy()
del sl, g, ss


# ─────────────────────────────────────────────────────────────────────────────
# 4. Instructor historical percentile mean
# ─────────────────────────────────────────────────────────────────────────────
print("Building instructor features...", flush=True)
instr = (so[so["IS_MASTER_SECTION"] == "Y"]
           [["TERM_CODE", "SUBJECT_ID_SORT", "RESPONSIBLE_FACULTY_NAME"]]
           .drop_duplicates())
del so
instr = instr.merge(
    hist_df[["TERM_CODE", "SUBJECT_ID_SORT", "hist_pct_last1"]],
    on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left"
)
instr = instr.sort_values(["RESPONSIBLE_FACULTY_NAME", "TERM_CODE"])
gi    = instr.groupby("RESPONSIBLE_FACULTY_NAME", sort=False)
instr["instr_pct_mean"] = gi["hist_pct_last1"].transform(
    lambda x: x.expanding().mean().shift(1)
)
instr_feats = instr[["TERM_CODE", "SUBJECT_ID_SORT", "instr_pct_mean"]].copy()
del instr, gi


# ─────────────────────────────────────────────────────────────────────────────
# 5. Catalog features from SUBJECT_OFFERED_SUMMARY
# ─────────────────────────────────────────────────────────────────────────────
print("Building catalog features...", flush=True)

def extract_course_num(sid: str) -> float:
    parts = str(sid).split(".")
    if len(parts) >= 2:
        try:
            return float("".join(c for c in parts[1] if c.isdigit()))
        except Exception:
            return np.nan
    return np.nan

for col in ["TOTAL_UNITS", "LECTURE_UNITS", "LAB_UNITS", "PREPARATION_UNITS"]:
    sos[col] = pd.to_numeric(sos[col], errors="coerce").fillna(0)

sos["course_num"]      = sos["SUBJECT_ID_SORT"].apply(extract_course_num)
sos["course_hundreds"] = sos["course_num"].apply(lambda x: int(x // 100) if pd.notna(x) else -1)
sos["is_grad"]         = (sos["course_num"] >= 500).astype(int)
sos["lab_frac"]        = sos["LAB_UNITS"] / sos["TOTAL_UNITS"].clip(lower=0.1)
sos["prep_frac"]       = sos["PREPARATION_UNITS"] / sos["TOTAL_UNITS"].clip(lower=0.1)

# Courses per (dept, term): smaller dept → easier to be top quartile
dt_cnt = (sos.groupby(["TERM_CODE", "OFFER_DEPT_CODE"])
            .size().rename("dept_term_n").reset_index())
sos = sos.merge(dt_cnt, on=["TERM_CODE", "OFFER_DEPT_CODE"], how="left")

for col in ["CLUSTER_TYPE", "HGN_CODE", "OFFER_DEPT_CODE", "OFFER_SCHOOL_NAME", "COURSE_NUMBER"]:
    sos[col] = sos[col].fillna("UNKNOWN")
    le = LabelEncoder()
    sos[col + "_enc"] = le.fit_transform(sos[col].astype(str))

SOS_COLS = ["TERM_CODE", "SUBJECT_ID_SORT",
            "TOTAL_UNITS", "LECTURE_UNITS", "LAB_UNITS", "PREPARATION_UNITS",
            "course_num", "course_hundreds", "is_grad", "lab_frac", "prep_frac",
            "dept_term_n",
            "CLUSTER_TYPE_enc", "HGN_CODE_enc", "OFFER_DEPT_CODE_enc",
            "OFFER_SCHOOL_NAME_enc", "COURSE_NUMBER_enc"]


# ─────────────────────────────────────────────────────────────────────────────
# 6. Merge all features onto gold
# ─────────────────────────────────────────────────────────────────────────────
print("Merging features...", flush=True)
df = gold.merge(sos[SOS_COLS], on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")
df = df.merge(hist_df, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")
df = df.merge(instr_feats, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")
print(f"  final df: {df.shape}", flush=True)

FEATURE_COLS = [
    # catalog
    "TOTAL_UNITS", "LECTURE_UNITS", "LAB_UNITS", "PREPARATION_UNITS",
    "course_num", "course_hundreds", "is_grad", "lab_frac", "prep_frac",
    "dept_term_n",
    "CLUSTER_TYPE_enc", "HGN_CODE_enc", "OFFER_DEPT_CODE_enc",
    "OFFER_SCHOOL_NAME_enc", "COURSE_NUMBER_enc",
    # time
    "season_enc", "year",
    # lag (historical, no leakage)
    "hist_n", "hist_pct_mean", "hist_pct_max",
    "hist_pct_last1", "hist_pct_last2", "hist_pct_last3",
    "hist_hi_frac", "hist_ever_hi", "hist_e5_mean", "hist_e5_last",
    "hist_pct_trend",
    # instructor
    "instr_pct_mean",
]

X = df[FEATURE_COLS].fillna(-1).astype(np.float32)
y = (df["HIGH_ENROLLMENT"] == "Y").astype(int)


# ─────────────────────────────────────────────────────────────────────────────
# 7. Time-based split (val = last 2 years of training data)
# ─────────────────────────────────────────────────────────────────────────────
VAL_CUTOFF = term_ord("2017FA")
tr_mask  = df["term_ord"] < VAL_CUTOFF
val_mask = df["term_ord"] >= VAL_CUTOFF
X_tr, y_tr   = X[tr_mask],  y[tr_mask]
X_val, y_val = X[val_mask], y[val_mask]

print(f"\nTrain: {tr_mask.sum():,}  Val: {val_mask.sum():,}")
print(f"Pos rate — train: {y_tr.mean():.3f}  val: {y_val.mean():.3f}", flush=True)


# ─────────────────────────────────────────────────────────────────────────────
# 8. LightGBM — 1000 trees, fixed (no early stopping)
# ─────────────────────────────────────────────────────────────────────────────
neg_pos = (y_tr == 0).sum() / (y_tr == 1).sum()
print(f"\nneg/pos ratio: {neg_pos:.1f}", flush=True)
print("Training LightGBM (1000 trees, lr=0.02)...", flush=True)

model = lgb.LGBMClassifier(
    n_estimators=1000,
    learning_rate=0.02,
    max_depth=8,
    num_leaves=127,
    min_child_samples=20,
    subsample=0.8,
    colsample_bytree=0.8,
    scale_pos_weight=neg_pos,
    reg_alpha=0.1,
    reg_lambda=1.0,
    random_state=RANDOM_STATE,
    n_jobs=-1,
    verbose=-1,
)
model.fit(X_tr, y_tr)
print("  Training complete.", flush=True)


# ─────────────────────────────────────────────────────────────────────────────
# 9. Threshold tuning for macro F1
# ─────────────────────────────────────────────────────────────────────────────
val_proba = model.predict_proba(X_val)[:, 1]
best_f1, best_thr = 0.0, 0.5
for thr in np.arange(0.03, 0.95, 0.01):
    pred = (val_proba >= thr).astype(int)
    f1   = f1_score(y_val, pred, average="macro")
    if f1 > best_f1:
        best_f1, best_thr = f1, thr

print(f"\n=== Validation Results ===")
print(f"Best threshold: {best_thr:.2f}  Macro F1: {best_f1:.4f}")
print(classification_report(y_val, (val_proba >= best_thr).astype(int),
      target_names=["N", "Y"], digits=4))

fi = pd.Series(
    model.booster_.feature_importance(importance_type="gain"),
    index=FEATURE_COLS
).sort_values(ascending=False)
print("Top 20 features (gain):")
print(fi.head(20).to_string())


# ─────────────────────────────────────────────────────────────────────────────
# 10. Save outputs
# ─────────────────────────────────────────────────────────────────────────────
full_proba = model.predict_proba(X)[:, 1]
submission = df[["TERM_CODE", "SUBJECT_ID_SORT"]].copy()
submission["HIGH_ENROLLMENT"] = ["Y" if p >= best_thr else "N" for p in full_proba]
submission.to_csv("predictions_train_v2.csv", index=False)

model.booster_.save_model("lgbm_model.txt")

with open("model_meta.json", "w") as f:
    json.dump({
        "best_threshold": float(best_thr),
        "val_macro_f1": float(best_f1),
        "feature_cols": FEATURE_COLS,
    }, f, indent=2)

print("\nSaved: predictions_train_v2.csv, lgbm_model.txt, model_meta.json")


# ─────────────────────────────────────────────────────────────────────────────
# 11. (Optional) Test inference
# ─────────────────────────────────────────────────────────────────────────────
if args.test:
    print(f"\n--- Test inference from {args.test} ---", flush=True)

    test_sos = pd.read_csv(
        os.path.join(args.test, "SUBJECT_OFFERED_SUMMARY.csv"), low_memory=False,
        usecols=["TERM_CODE", "SUBJECT_ID_SORT", "COURSE_NUMBER", "CLUSTER_TYPE",
                 "HGN_CODE", "OFFER_DEPT_CODE", "OFFER_SCHOOL_NAME",
                 "TOTAL_UNITS", "LECTURE_UNITS", "LAB_UNITS", "PREPARATION_UNITS"]
    )
    test_sos["term_ord"] = test_sos["TERM_CODE"].map(term_ord)

    for col in ["TOTAL_UNITS", "LECTURE_UNITS", "LAB_UNITS", "PREPARATION_UNITS"]:
        test_sos[col] = pd.to_numeric(test_sos[col], errors="coerce").fillna(0)

    test_sos["course_num"]      = test_sos["SUBJECT_ID_SORT"].apply(extract_course_num)
    test_sos["course_hundreds"] = test_sos["course_num"].apply(lambda x: int(x // 100) if pd.notna(x) else -1)
    test_sos["is_grad"]         = (test_sos["course_num"] >= 500).astype(int)
    test_sos["lab_frac"]        = test_sos["LAB_UNITS"] / test_sos["TOTAL_UNITS"].clip(lower=0.1)
    test_sos["prep_frac"]       = test_sos["PREPARATION_UNITS"] / test_sos["TOTAL_UNITS"].clip(lower=0.1)

    dt_t = test_sos.groupby(["TERM_CODE", "OFFER_DEPT_CODE"]).size().rename("dept_term_n").reset_index()
    test_sos = test_sos.merge(dt_t, on=["TERM_CODE", "OFFER_DEPT_CODE"], how="left")

    for col in ["CLUSTER_TYPE", "HGN_CODE", "OFFER_DEPT_CODE", "OFFER_SCHOOL_NAME", "COURSE_NUMBER"]:
        test_sos[col] = test_sos[col].fillna("UNKNOWN")
        le = LabelEncoder()
        test_sos[col + "_enc"] = le.fit_transform(test_sos[col].astype(str))

    test_df = test_sos[SOS_COLS].copy()
    test_df["year"]       = test_df["TERM_CODE"].str[:4].astype(int)
    test_df["season_enc"] = test_df["TERM_CODE"].str[4:].map(SEASON_ORDER).fillna(2)
    test_df["term_ord"]   = test_df["TERM_CODE"].map(term_ord)
    test_df = test_df.merge(hist_df, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")
    test_df = test_df.merge(instr_feats, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")

    X_test = test_df[FEATURE_COLS].fillna(-1).astype(np.float32)
    test_proba = model.predict_proba(X_test)[:, 1]

    test_sub = test_df[["TERM_CODE", "SUBJECT_ID_SORT"]].copy()
    test_sub["HIGH_ENROLLMENT"] = ["Y" if p >= best_thr else "N" for p in test_proba]
    test_sub.to_csv("predictions_test.csv", index=False)
    pos_rate = test_sub["HIGH_ENROLLMENT"].eq("Y").mean()
    print(f"  Saved predictions_test.csv  (positive rate: {pos_rate:.3f})")

print("\n=== DONE ===")
