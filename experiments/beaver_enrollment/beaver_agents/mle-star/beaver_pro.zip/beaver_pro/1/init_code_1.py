
import pandas as pd
import numpy as np
import lightgbm as lgb
from sklearn.metrics import f1_score
import os

def solve():
    """
    This function implements the entire solution pipeline, from data loading
    and preprocessing to model training and evaluation.
    """
    # Define the path to the training data directory
    TRAIN_DATA_DIR = './input/table_splits/train'

    # --- 1. Data Loading ---
    # Load all necessary tables from the training directory.
    try:
        gold_enrollment_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv'))
        summary_enrollment_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'summary_enrollment_train.csv'))
        summary_courses_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'summary_courses_train.csv'))
        summary_subjects_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'summary_subjects_train.csv'))
    except FileNotFoundError as e:
        print(f"Error loading data files: {e}")
        print("Please ensure the input data is in the './input/table_splits/train/' directory.")
        return

    # --- 2. Data Preprocessing and Merging ---
    # The grain for prediction is (TERM_CODE, SUBJECT_ID_SORT).
    # summary_enrollment_df can have multiple rows per course offering (e.g., multiple instructors).
    # We aggregate this information to create a single row per offering.

    # Create a feature for the number of instructors per course offering.
    instructor_count = summary_enrollment_df.groupby(['TERM_CODE', 'SUBJECT_ID_SORT']).size().reset_index(name='INSTRUCTOR_COUNT')

    # For simplicity, we take the first instructor's info for each course offering.
    # This provides a single COURSE_ID, SUBJECT, and INSTRUCTOR_ID to join on.
    enrollment_agg_df = summary_enrollment_df.groupby(['TERM_CODE', 'SUBJECT_ID_SORT']).first().reset_index()

    # Merge the instructor count back into the aggregated enrollment data.
    enrollment_agg_df = pd.merge(enrollment_agg_df, instructor_count, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')

    # Start building the main dataframe by merging the gold labels with our aggregated enrollment features.
    df = pd.merge(gold_enrollment_df, enrollment_agg_df, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')

    # Merge with course-specific details. A course ID might have multiple entries; we take the latest definition.
    summary_courses_df = summary_courses_df.drop_duplicates(subset=['COURSE_ID'], keep='last')
    df = pd.merge(df, summary_courses_df, on='COURSE_ID', how='left')

    # Merge with subject-specific details.
    df = pd.merge(df, summary_subjects_df, on='SUBJECT', how='left')

    # --- 3. Feature Engineering ---
    # Convert the target variable 'HIGH_ENROLLMENT' from 'Y'/'N' to 1/0.
    df['HIGH_ENROLLMENT'] = df['HIGH_ENROLLMENT'].apply(lambda x: 1 if x == 'Y' else 0)

    # Define features. We explicitly EXCLUDE potential data leaks like 'ENROLLMENT_COUNT' and 'WAITLIST_COUNT'.
    numerical_features = ['UNITS_MAXIMUM', 'UNITS_MINIMUM', 'INSTRUCTOR_COUNT']
    categorical_features = ['SUBJECT', 'COURSE_LEVEL', 'INSTRUCTOR_ID', 'DEPARTMENT_CODE', 'SCHOOL_CODE']
    time_feature = 'TERM_CODE'  # Use TERM_CODE itself as a numerical feature representing time progression.

    # Handle missing values and data types for numerical features.
    for col in numerical_features:
        if col in df.columns:
            df[col] = df[col].fillna(df[col].median())
        else:
            df[col] = 0

    # Handle missing values and data types for categorical features.
    for col in categorical_features:
        if col in df.columns:
            df[col] = df[col].astype(str).fillna('missing')
            df[col] = df[col].astype('category')
        else:
            df[col] = 'missing'
            df[col] = df[col].astype('category')
    
    # Ensure the time feature is numeric and handle potential NaNs
    if time_feature in df.columns:
        df[time_feature] = df[time_feature].fillna(0)


    # Final list of features for the model
    features = numerical_features + categorical_features + [time_feature]
    target = 'HIGH_ENROLLMENT'

    # --- 4. Time-Based Validation Split ---
    # Sort unique term codes to identify the latest terms for validation.
    unique_terms = sorted(df['TERM_CODE'].unique())

    # Hold out the last 3 terms as a validation set to simulate predicting for the future.
    if len(unique_terms) > 3:
        validation_terms = unique_terms[-3:]
    else: # Fallback for very few terms
        validation_terms = [unique_terms[-1]] if unique_terms else []

    train_terms = [t for t in unique_terms if t not in validation_terms]

    train_df = df[df['TERM_CODE'].isin(train_terms)]
    val_df = df[df['TERM_CODE'].isin(validation_terms)]
    
    if val_df.empty:
        print("Validation set is empty. Cannot evaluate performance. Please check TERM_CODE distribution.")
        return

    X_train = train_df[features]
    y_train = train_df[target]
    X_val = val_df[features]
    y_val = val_df[target]

    # --- 5. Model Training (LightGBM) ---
    # Create LightGBM dataset objects. 'auto' correctly uses the pandas category dtype.
    train_data = lgb.Dataset(X_train, label=y_train, feature_name=features, categorical_feature='auto')
    val_data = lgb.Dataset(X_val, label=y_val, reference=train_data, feature_name=features, categorical_feature='auto')

    # Define model parameters for binary classification.
    params = {
        'objective': 'binary',
        'metric': 'binary_logloss',
        'boosting_type': 'gbdt',
        'num_leaves': 31,
        'learning_rate': 0.05,
        'feature_fraction': 0.9,
        'n_jobs': -1,
        'seed': 42,
        'verbose': -1  # Suppress verbose training output.
    }

    # Train the model with early stopping.
    model = lgb.train(
        params,
        train_data,
        num_boost_round=1000,
        valid_sets=[val_data],
        callbacks=[lgb.early_stopping(100, verbose=False)]
    )

    # --- 6. Evaluation ---
    # Predict probabilities on the validation set.
    y_pred_proba = model.predict(X_val, num_iteration=model.best_iteration)

    # Convert probabilities to binary predictions using a 0.5 threshold.
    y_pred = (y_pred_proba > 0.5).astype(int)

    # Calculate the macro F1 score.
    final_validation_score = f1_score(y_val, y_pred, average='macro')

    # Print the final performance metric in the specified format.
    print(f'Final Validation Performance: {final_validation_score}')

if __name__ == '__main__':
    solve()
