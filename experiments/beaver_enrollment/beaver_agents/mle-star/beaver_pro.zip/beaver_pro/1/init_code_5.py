
import os
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score
from tabpfn import TabPFNClassifier

# --- Configuration ---
TRAIN_DATA_DIR = './input'
TARGET_COLUMN = 'HIGH_ENROLLMENT'
MAX_TRAIN_SAMPLES = 1000  # Recommended limit for TabPFN

# --- Data Loading and Merging ---
def load_and_merge_data(data_dir):
    """
    Loads and merges all relevant CSV files from the specified directory.
    This function combines course, offering, subject, instructor, and label data.
    """
    try:
        courses = pd.read_csv(os.path.join(data_dir, 'course_data.csv'))
        offerings = pd.read_csv(os.path.join(data_dir, 'course_offerings.csv'))
        subjects = pd.read_csv(os.path.join(data_dir, 'subject_summary.csv'))
        instructors = pd.read_csv(os.path.join(data_dir, 'instructor_summary.csv'))
        gold_labels = pd.read_csv(os.path.join(data_dir, 'gold_enrollment_train.csv'))
    except FileNotFoundError as e:
        print(f"Error loading data files: {e}")
        return None

    # Merge tables step-by-step
    df = pd.merge(subjects, offerings, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')
    df = pd.merge(df, courses, on='COURSE_ID', how='left')
    df = pd.merge(df, instructors, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')
    df = pd.merge(df, gold_labels, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')

    return df

# --- Feature Engineering ---
def create_features(df):
    """
    Engineers features for the enrollment prediction model.
    This includes time-based features, categorical encoding, and target transformation.
    """
    # Time-based features from TERM_CODE
    df['TERM_YEAR'] = df['TERM_CODE'].astype(str).str[:4].astype(int)
    df['TERM_SEASON'] = df['TERM_CODE'].astype(str).str[4:].astype(int)

    # Encode target variable from 'Y'/'N' to 1/0
    df[TARGET_COLUMN] = (df[TARGET_COLUMN] == 'Y').astype(int)

    # Encode categorical features using integer representation (factorization)
    # This is a simple approach suitable for tree-based models and TabPFN
    df['DEPT_ID_encoded'] = pd.factorize(df['DEPT_ID'])[0]
    df['SUBJECT_ID_encoded'] = pd.factorize(df['SUBJECT_ID'])[0]

    return df

# --- Main Execution ---

# 1. Load and prepare data
# print("Loading and merging data...")
df = load_and_merge_data(TRAIN_DATA_DIR)

if df is not None:
    # 2. Engineer features
    # print("Creating features...")
    df = create_features(df)

    # 3. Time-based validation split
    # Use the most recent year for validation, and all prior years for training
    if 'TERM_YEAR' in df.columns and df['TERM_YEAR'].nunique() > 1:
        latest_year = df['TERM_YEAR'].max()
        train_df = df[df['TERM_YEAR'] < latest_year].copy()
        val_df = df[df['TERM_YEAR'] == latest_year].copy()
        # print(f"Using time-based split: Training on years < {latest_year}, Validating on year {latest_year}.")
    else:
        # Fallback to a random split if only one year of data is present
        # print("Fallback to random split as only one year of data is available.")
        train_df, val_df = train_test_split(df, test_size=0.2, random_state=42, stratify=df[TARGET_COLUMN])

    if train_df.empty or val_df.empty:
        raise ValueError("Data splitting resulted in an empty train or validation set.")

    # 4. Define features to use for the model
    # We exclude identifiers, text, the target, the split column, and leaky columns like ENROLLMENT_COUNT.
    numerical_features = [
        'NUM_INSTRUCTORS', 'MEETING_COUNT', 'ENROLLMENT_CAPACITY',
        'COURSE_LEVEL', 'CREDIT_HOURS', 'NUM_COURSES_TAUGHT', 'TERM_SEASON'
    ]
    categorical_features = ['DEPT_ID_encoded', 'SUBJECT_ID_encoded']
    features = numerical_features + categorical_features

    X_train = train_df[features]
    y_train = train_df[TARGET_COLUMN]
    X_val = val_df[features]
    y_val = val_df[TARGET_COLUMN]

    # 5. Preprocessing: Impute missing values
    # Use the median from the training set to fill NaNs in both train and validation sets
    for col in X_train.columns:
        if X_train[col].isnull().any():
            median_val = X_train[col].median()
            X_train[col] = X_train[col].fillna(median_val)
            X_val[col] = X_val[col].fillna(median_val)

    # 6. Subsample the training data for TabPFN
    # TabPFN performs best on datasets with < 1000 samples.
    if len(X_train) > MAX_TRAIN_SAMPLES:
        # Use stratified sampling to maintain class distribution
        X_train_sampled, _, y_train_sampled, _ = train_test_split(
            X_train, y_train, train_size=MAX_TRAIN_SAMPLES, random_state=42, stratify=y_train
        )
        # print(f"Training set sampled down to {len(X_train_sampled)} instances.")
    else:
        X_train_sampled = X_train
        y_train_sampled = y_train

    # 7. Initialize and train the TabPFN model
    # N_ensemble_configurations controls the number of forward passes. No other tuning is needed.
    # print("Initializing and training TabPFN model...")
    classifier = TabPFNClassifier(device='cpu', N_ensemble_configurations=32)

    # TabPFN fits and predicts in a single forward pass.
    # It requires numpy arrays as input.
    classifier.fit(X_train_sampled.to_numpy(), y_train_sampled.to_numpy())

    # 8. Predict on the validation set
    # print("Predicting on the validation set...")
    y_pred_val, _ = classifier.predict(X_val.to_numpy(), return_winning_probability=True)

    # 9. Evaluate the model performance
    # The evaluation metric is macro F1 score, as specified.
    final_validation_score = f1_score(y_val.to_numpy(), y_pred_val, average='macro')

    # Print the final score in the required format
    print(f"Final Validation Performance: {final_validation_score}")

else:
    print("Script terminated due to data loading failure.")
