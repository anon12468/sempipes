
import os
import pandas as pd
import numpy as np
import subprocess
import sys

# --- Installation of AutoGluon ---
try:
    from autogluon.tabular import TabularPredictor
except ImportError:
    print("AutoGluon not found. Installing...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "autogluon.tabular"])
    from autogluon.tabular import TabularPredictor

# --- Configuration ---
TRAIN_DATA_DIR = './input'
TEST_DATA_DIR = None  # Placeholder for future data
TARGET_COLUMN = 'HIGH_ENROLLMENT'

# --- Data Loading and Merging ---
def load_and_merge_data(data_dir):
    """Loads and merges all relevant CSV files from the specified directory."""
    
    # Load primary tables
    try:
        courses = pd.read_csv(os.path.join(data_dir, 'course_data.csv'))
        offerings = pd.read_csv(os.path.join(data_dir, 'course_offerings.csv'))
        subjects = pd.read_csv(os.path.join(data_dir, 'subject_summary.csv'))
        instructors = pd.read_csv(os.path.join(data_dir, 'instructor_summary.csv'))
        
        # Load gold labels if in training mode
        if 'train' in data_dir:
            gold_labels = pd.read_csv(os.path.join(data_dir, 'gold_enrollment_train.csv'))
        else:
            gold_labels = None

    except FileNotFoundError as e:
        print(f"Error loading data files: {e}")
        return None

    # Merge tables
    df = pd.merge(subjects, offerings, on=['TERM_CODE', 'SUBJECT_ID_SORT'])
    df = pd.merge(df, courses, on='COURSE_ID', how='left')
    df = pd.merge(df, instructors, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')
    
    if gold_labels is not None:
        df = pd.merge(df, gold_labels, on=['TERM_CODE', 'SUBJECT_ID_SORT'])

    return df

# --- Feature Engineering ---
def create_features(df):
    """Creates new features for the model."""
    
    # Time-based features
    df['TERM_YEAR'] = df['TERM_CODE'].astype(str).str[:4].astype(int)
    df['TERM_SEASON'] = df['TERM_CODE'].astype(str).str[4:].astype(int)
    
    # Interaction features
    df['DEPT_LEVEL'] = df['DEPT_ID'] + '_' + df['COURSE_LEVEL'].astype(str)
    
    # Ratio features
    df['ENROLLMENT_CAPACITY_RATIO'] = df['ENROLLMENT_COUNT'] / df['ENROLLMENT_CAPACITY']
    df['ENROLLMENT_CAPACITY_RATIO'].replace([np.inf, -np.inf], np.nan, inplace=True)
    df['ENROLLMENT_CAPACITY_RATIO'].fillna(0, inplace=True)
    
    # Aggregated features
    # Note: More complex aggregations can be added here
    # For example, average enrollment for a course over time
    
    return df

# --- Main Execution ---

# 1. Load Data
print("Loading and merging data...")
train_df = load_and_merge_data(TRAIN_DATA_DIR)

if train_df is None:
    print("Stopping execution due to data loading errors.")
else:
    # 2. Feature Engineering
    print("Creating features...")
    train_df = create_features(train_df)

    # 3. Data Splitting (Time-based validation)
    # Using years before 2022 for training, and 2022 for validation
    print("Splitting data into training and validation sets...")
    train_set = train_df[train_df['TERM_YEAR'] < 2022]
    validation_set = train_df[train_df['TERM_YEAR'] == 2022]

    # Ensure validation set is not empty
    if validation_set.empty:
        print("Validation set is empty. Using a random split instead.")
        train_set = train_df.sample(frac=0.8, random_state=42)
        validation_set = train_df.drop(train_set.index)

    # Sub-sample for faster training if desired (e.g. for debugging)
    # train_set = train_set.sample(n=1000, random_state=42) if len(train_set) > 1000 else train_set


    # 4. Model Training
    print("Starting AutoGluon model training...")
    predictor = TabularPredictor(
        label=TARGET_COLUMN,
        problem_type='binary',
        eval_metric='f1_macro',
        path='./autogluon_models'
    )
    
    # Define training parameters
    # Presets can be 'medium_quality', 'high_quality', 'best_quality'
    # Added time limit for practicality
    predictor.fit(
        train_data=train_set,
        presets='medium_quality',
        time_limit=300, # 5 minutes
        ag_args_fit={'num_gpus': 0} # Explicitly use CPU
    )

    # 5. Model Evaluation
    print("Evaluating model on validation set...")
    performance = predictor.evaluate(validation_set)
    final_validation_score = performance.get('f1_macro', 0)

    # Output the final performance score in the specified format
    print(f"Final Validation Performance: {final_validation_score}")

    # Optional: Display leaderboard
    print("\nAutoGluon Model Leaderboard:")
    leaderboard = predictor.leaderboard(validation_set, silent=True)
    print(leaderboard)

    print("\nScript finished.")
