
import pandas as pd
import numpy as np
import os
import lightgbm as lgb
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score
from sklearn.preprocessing import LabelEncoder

# It is assumed that the required libraries (pandas, numpy, lightgbm, scikit-learn) are installed.
# If not, they can be installed using pip:
# pip install pandas numpy lightgbm scikit-learn

def load_data(data_dir):
    """
    Loads all necessary tables from the specified directory for both models.
    """
    # Verify the directory exists to provide a better error message if it doesn't.
    if not os.path.isdir(data_dir):
        raise FileNotFoundError(f"Data directory not found at: {data_dir}")
        
    offerings = pd.read_csv(os.path.join(data_dir, 'offerings.csv'))
    courses = pd.read_csv(os.path.join(data_dir, 'courses.csv'))
    subjects = pd.read_csv(os.path.join(data_dir, 'subjects.csv'))
    instructors = pd.read_csv(os.path.join(data_dir, 'instructors.csv'))
    gold_labels = pd.read_csv(os.path.join(data_dir, 'gold_enrollment_train.csv'))
    # Load additional file required by the reference solution
    subject_summary = pd.read_csv(os.path.join(data_dir, 'subject_summary.csv'))
    return offerings, courses, subjects, instructors, gold_labels, subject_summary

def create_base_feature_dataframe(offerings, courses, subjects, instructors):
    """
    Merges raw data tables for the base solution model into a single feature dataframe.
    """
    df = pd.merge(offerings, courses, on='COURSE_ID', how='left')
    df = pd.merge(df, instructors, on='INSTRUCTOR_ID', how='left')
    df = pd.merge(df, subjects, on='SUBJECT_ID', how='left')
    return df

def main():
    """
    Main function to run the integrated training, ensembling, and validation pipeline.
    """
    # The traceback indicated a FileNotFoundError. This path corrects it by pointing
    # to the correct sub-directory as specified in the problem description.
    TRAIN_DATA_DIR = 'input/table_splits/train'

    # --- 1. Load All Data ---
    offerings_df, courses_df, subjects_df, instructors_df, gold_df, subject_summary_df = load_data(TRAIN_DATA_DIR)

    # --- 2. Prepare Features for Both Models ---

    # A. Prepare features for the base model (LightGBM)
    base_features_df = create_base_feature_dataframe(offerings_df, courses_df, subjects_df, instructors_df)

    # B. Prepare features for the reference model (RandomForest)
    ref_features_df = subject_summary_df.copy()
    ref_features_df['TERM_YEAR'] = ref_features_df['TERM_CODE'].astype(str).str[:4].astype(int)
    ref_features_df['TERM_SEASON'] = ref_features_df['TERM_CODE'].astype(str).str[4:].astype(int)
    ref_features_df['DEPARTMENT'] = ref_features_df['SUBJECT_ID_SORT'].str.split('_').str[0]
    ref_features_df = pd.get_dummies(ref_features_df, columns=['DEPARTMENT'], drop_first=True)

    # --- 3. Create Master DataFrame by Merging Labels and Features ---

    # Start with gold labels as the ground truth
    data = gold_df.copy()
    
    # Ensure data types of merge keys are consistent
    data['TERM_CODE'] = data['TERM_CODE'].astype(int)
    data['SUBJECT_ID_SORT'] = data['SUBJECT_ID_SORT'].astype(str)
    base_features_df['TERM_CODE'] = base_features_df['TERM_CODE'].astype(int)
    base_features_df['SUBJECT_ID_SORT'] = base_features_df['SUBJECT_ID_SORT'].astype(str)
    ref_features_df['TERM_CODE'] = ref_features_df['TERM_CODE'].astype(int)
    ref_features_df['SUBJECT_ID_SORT'] = ref_features_df['SUBJECT_ID_SORT'].astype(str)

    # Merge features from the base model by aggregating to the subject level
    base_features_agg = base_features_df.groupby(['TERM_CODE', 'SUBJECT_ID_SORT']).first().reset_index()
    data = pd.merge(data, base_features_agg, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')

    # Merge features from the reference model
    data = pd.merge(data, ref_features_df, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')

    # Map target variable 'Y'/'N' to 1/0
    data['HIGH_ENROLLMENT'] = data['HIGH_ENROLLMENT'].map({'Y': 1, 'N': 0})
    target = 'HIGH_ENROLLMENT'

    # --- 4. Feature Finalization and Missing Value Handling ---

    # A. For LightGBM features
    lgbm_features = ['INSTRUCTOR_ID', 'COURSE_ID', 'SUBJECT_ID', 'CREDITS']
    for col in lgbm_features:
        if col in data.columns:
            # For object/categorical types, convert to pandas 'category' dtype
            if data[col].dtype == 'object' or pd.api.types.is_categorical_dtype(data[col]):
                data[col] = data[col].astype('category').cat.add_categories('missing').fillna('missing')
            # For numeric types, fill missing values
            elif pd.api.types.is_numeric_dtype(data[col]):
                data[col].fillna(-1, inplace=True)

    # B. For RandomForest features
    rf_features_all = ref_features_df.columns.tolist()
    rf_id_cols = ['TERM_CODE', 'SUBJECT_ID_SORT']
    rf_features = [f for f in rf_features_all if f not in rf_id_cols and f in data.columns]

    # Handle missing values for RF features with median
    for col in rf_features:
        if col in data.columns and pd.api.types.is_numeric_dtype(data[col]):
            median_val = data[col].median()
            data[col].fillna(median_val, inplace=True)

    # --- 5. Time-based Train-Validation Split ---
    data = data.sort_values('TERM_CODE').reset_index(drop=True)
    unique_terms = sorted(data['TERM_CODE'].unique())
    validation_term = unique_terms[-1]

    train_df = data[data['TERM_CODE'] < validation_term]
    val_df = data[data['TERM_CODE'] == validation_term]

    y_train = train_df[target]
    y_val = val_df[target]

    # Create feature matrices for both models
    X_train_lgb = train_df[lgbm_features]
    X_val_lgb = val_df[lgbm_features]
    
    X_train_rf = train_df[rf_features]
    X_val_rf = val_df[rf_features]

    # --- 6. Model Training ---
    
    # A. Train LightGBM model
    model_lgb = lgb.LGBMClassifier(objective='binary', random_state=42)
    # LightGBM will automatically handle columns with 'category' dtype
    model_lgb.fit(X_train_lgb, y_train)

    # B. Train RandomForest model
    model_rf = RandomForestClassifier(n_estimators=100, random_state=42, class_weight='balanced', n_jobs=-1)
    model_rf.fit(X_train_rf, y_train)

    # --- 7. Prediction, Ensembling, and Evaluation ---

    # Get probability predictions from both models for the positive class (1)
    preds_lgb = model_lgb.predict_proba(X_val_lgb)[:, 1]
    preds_rf = model_rf.predict_proba(X_val_rf)[:, 1]

    # Ensemble by averaging the probabilities
    ensemble_probs = (preds_lgb + preds_rf) / 2

    # Convert averaged probabilities to final class predictions (0 or 1)
    y_pred_ensemble = (ensemble_probs > 0.5).astype(int)

    # Calculate final F1 score on the validation set
    final_validation_score = 0.0
    if y_val.nunique() > 1:
        final_validation_score = f1_score(y_val, y_pred_ensemble, average='macro')
    else:
        print("Warning: Validation set contains only one class. F1 score is ill-defined and set to 0.0.")

    # Print the final score in the specified format
    print(f'Final Validation Performance: {final_validation_score}')


if __name__ == "__main__":
    main()
