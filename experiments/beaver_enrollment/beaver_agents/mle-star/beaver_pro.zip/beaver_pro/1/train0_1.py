
import pandas as pd
import numpy as np
import os
import lightgbm as lgb
from sklearn.metrics import f1_score

# It is assumed that the required libraries (pandas, numpy, lightgbm, scikit-learn) are installed.
# If not, they can be installed using pip:
# pip install pandas numpy lightgbm scikit-learn

def load_data(data_dir):
    """
    Loads all necessary tables from the specified directory.
    """
    try:
        offerings = pd.read_csv(os.path.join(data_dir, 'offerings.csv'))
        courses = pd.read_csv(os.path.join(data_dir, 'courses.csv'))
        subjects = pd.read_csv(os.path.join(data_dir, 'subjects.csv'))
        instructors = pd.read_csv(os.path.join(data_dir, 'instructors.csv'))
        gold_labels = pd.read_csv(os.path.join(data_dir, 'gold_enrollment_train.csv'))
        return offerings, courses, subjects, instructors, gold_labels
    except FileNotFoundError as e:
        print(f"Error loading data files: {e}. Ensure all CSV files are in the '{data_dir}' directory.")
        raise

def create_feature_dataframe(offerings, courses, subjects, instructors):
    """
    Merges the raw data tables into a single feature dataframe.
    One row per course offering.
    """
    # Start with offerings, as it represents each "course offering per term".
    df = pd.merge(offerings, courses, on='COURSE_ID', how='left')
    df = pd.merge(df, instructors, on='INSTRUCTOR_ID', how='left')
    df = pd.merge(df, subjects, on='SUBJECT_ID', how='left')
    return df

def main():
    """
    Main function to run the training and validation pipeline.
    """
    # Define the data directory. The previous fix corrected this path.
    TRAIN_DATA_DIR = './input'

    try:
        # --- 1. Load Data ---
        offerings_df, courses_df, subjects_df, instructors_df, gold_df = load_data(TRAIN_DATA_DIR)

        # --- 2. Create and Merge Features ---
        # Create a single dataframe with all features, at the offering level.
        features_df = create_feature_dataframe(offerings_df, courses_df, subjects_df, instructors_df)

        # The prediction keys are 'TERM_CODE' and 'SUBJECT_ID_SORT'.
        # A common source of error is a mismatch in these keys between feature and label dataframes.
        # Here, we adopt a robust "label-first" merge strategy. We start with the gold labels
        # and merge features onto them. This ensures we only train on data that has a valid label.

        # Verify that the merge keys exist. 'SUBJECT_ID_SORT' is the critical one.
        # It's likely in `courses_df`, so it should be in `features_df` after the merge.
        if 'SUBJECT_ID_SORT' not in features_df.columns:
            # If the specific key 'SUBJECT_ID_SORT' is missing, it causes a critical error.
            # This is a likely reason for the previous script failure.
            raise KeyError("The required merge key 'SUBJECT_ID_SORT' was not found in the feature tables (e.g., courses.csv).")

        # Ensure data types of merge keys are consistent to prevent silent merge failures.
        features_df['TERM_CODE'] = features_df['TERM_CODE'].astype(int)
        gold_df['TERM_CODE'] = gold_df['TERM_CODE'].astype(int)
        features_df['SUBJECT_ID_SORT'] = features_df['SUBJECT_ID_SORT'].astype(str)
        gold_df['SUBJECT_ID_SORT'] = gold_df['SUBJECT_ID_SORT'].astype(str)

        # Perform the merge. `how='left'` keeps all labeled examples from `gold_df`.
        # Features that don't match will be NaN, which we can handle.
        data = pd.merge(gold_df, features_df, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')

        if data.empty or data['HIGH_ENROLLMENT'].isnull().all():
            raise ValueError("Merging labels with features resulted in an empty or unlabeled dataframe. "
                             "Please check the consistency of 'TERM_CODE' and 'SUBJECT_ID_SORT' keys across your files.")

        # --- 3. Feature Engineering ---
        # Map target variable 'Y'/'N' to 1/0
        data['HIGH_ENROLLMENT'] = data['HIGH_ENROLLMENT'].map({'Y': 1, 'N': 0})

        # Define features to use in the model.
        # We select a mix of numerical and categorical features expected to be predictive.
        features = [
            'INSTRUCTOR_ID',
            'COURSE_ID',
            'SUBJECT_ID',
            'CREDITS',
        ]
        target = 'HIGH_ENROLLMENT'
        
        # Handle potential missing values from the left merge
        # For categorical features, fill with a placeholder string.
        # For numerical features, fill with a value like median or -1.
        for col in features:
            if data[col].dtype == 'object' or pd.api.types.is_categorical_dtype(data[col]):
                data[col].fillna('missing', inplace=True)
            elif pd.api.types.is_numeric_dtype(data[col]):
                data[col].fillna(-1, inplace=True)

        # Convert object columns to 'category' dtype for LightGBM.
        # LightGBM has built-in handling for categorical features.
        for col in features:
            if data[col].dtype == 'object':
                data[col] = data[col].astype('category')

        # --- 4. Time-based Train-Validation Split ---
        data = data.sort_values('TERM_CODE').reset_index(drop=True)
        unique_terms = sorted(data['TERM_CODE'].unique())

        if len(unique_terms) < 2:
            raise ValueError("Cannot perform time-based split: The dataset contains fewer than two unique terms.")

        # Use the most recent term for validation.
        validation_term = unique_terms[-1]
        train_df = data[data['TERM_CODE'] < validation_term]
        val_df = data[data['TERM_CODE'] == validation_term]

        if train_df.empty or val_df.empty:
            raise ValueError("Train or validation set is empty after splitting. Check the distribution of data across terms.")

        # Per prompt, do not remove subsampling. This is where it would be applied (on the training set only).
        # For example:
        # if len(train_df) > 100000:
        #     train_df = train_df.sample(n=100000, random_state=42)
        
        X_train = train_df[features]
        y_train = train_df[target]
        X_val = val_df[features]
        y_val = val_df[target]
        
        # --- 5. Model Training ---
        # LightGBM is a good choice for tabular data with categorical features.
        model = lgb.LGBMClassifier(objective='binary', random_state=42)
        
        # The 'categorical_feature="auto"' argument tells LightGBM to use columns with 'category' dtype.
        model.fit(X_train, y_train, categorical_feature='auto')

        # --- 6. Evaluation ---
        y_pred = model.predict(X_val)
        
        final_validation_score = 0.0
        # The macro F1 score is requested. It calculates F1 for each class and finds their unweighted mean.
        # This is a good metric for imbalanced datasets.
        if y_val.nunique() > 1:
            final_validation_score = f1_score(y_val, y_pred, average='macro')
        else:
            print("Warning: Validation set contains only one class. F1 score is ill-defined and set to 0.0.")

        # Print the final score in the specified format.
        print(f'Final Validation Performance: {final_validation_score}')

    except (FileNotFoundError, KeyError, ValueError) as e:
        print(f"An error occurred during the script execution: {e}")

if __name__ == "__main__":
    main()
