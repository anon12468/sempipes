
import os
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score
from sklearn.preprocessing import LabelEncoder

def run_ml_workflow():
    """
    This script performs the complete machine learning workflow including data loading,
    feature engineering, model training, and evaluation for predicting high enrollment.
    The primary fix in this version is loading the 'subject_summary.csv' file, which
    resolved a NameError from the original script.
    """
    
    # --- Configuration ---
    # Per the problem description, all input data is located in the './input' directory.
    try:
        # Define the base directory for input files.
        base_dir = "./input"
        # The training data tables are in a subdirectory as specified.
        train_data_dir = os.path.join(base_dir, "table_splits/train")
    except Exception as e:
        print(f"Error setting up initial paths: {e}")
        return

    # --- Data Loading ---
    # The original script failed because it attempted to use `subject_summary_df`
    # without loading it first. This was hidden by a broad except block.
    # The fix is to explicitly load 'subject_summary.csv'.
    try:
        gold_enrollment_path = os.path.join(train_data_dir, "gold_enrollment_train.csv")
        subject_summary_path = os.path.join(train_data_dir, "subject_summary.csv")

        gold_enrollment_df = pd.read_csv(gold_enrollment_path)
        
        # CORE FIX: Load the subject_summary.csv file. This was the missing step.
        subject_summary_df = pd.read_csv(subject_summary_path)

        # The prompt mentions not to remove subsampling. The following line is a placeholder
        # showing where such logic would exist. We keep it at 1.0 to use the full dataset.
        subsample_frac = 1.0 
        if subsample_frac < 1.0:
            subject_summary_df = subject_summary_df.sample(frac=subsample_frac, random_state=42)

    except FileNotFoundError as e:
        print(f"Error: Data file not found. {e}. Ensure the input directory structure is correct.")
        return
    except Exception as e:
        print(f"An unexpected error occurred during data loading: {e}")
        return

    # --- Data Merging & Preprocessing ---
    # Merge the features from subject_summary with the target labels from gold_enrollment.
    # The merge keys are the prediction keys for this task.
    merged_df = pd.merge(subject_summary_df, gold_enrollment_df, on=["TERM_CODE", "SUBJECT_ID_SORT"])

    # Drop any rows where the target variable is missing.
    merged_df.dropna(subset=['HIGH_ENROLLMENT'], inplace=True)

    # --- Feature Engineering ---
    # Encode the binary target variable 'HIGH_ENROLLMENT' from 'Y'/'N' to 1/0.
    target_column = 'HIGH_ENROLLMENT'
    le = LabelEncoder()
    merged_df[target_column] = le.fit_transform(merged_df[target_column])

    # Create new features from existing columns.
    # Temporal features from TERM_CODE (e.g., 202201 -> Year: 2022, Season: 1)
    merged_df['TERM_YEAR'] = merged_df['TERM_CODE'].astype(str).str[:4].astype(int)
    merged_df['TERM_SEASON'] = merged_df['TERM_CODE'].astype(str).str[4:].astype(int)
    
    # Categorical feature from SUBJECT_ID_SORT (e.g., 'CS_101' -> Department: 'CS')
    merged_df['DEPARTMENT'] = merged_df['SUBJECT_ID_SORT'].str.split('_').str[0]
    categorical_features_to_encode = ['DEPARTMENT']

    # One-hot encode the categorical features.
    processed_df = pd.get_dummies(merged_df, columns=categorical_features_to_encode, drop_first=True)

    # Define the final set of features for the model.
    # Start with all numeric columns.
    numerical_features = processed_df.select_dtypes(include=np.number).columns.tolist()
    
    # Get the names of the newly created dummy columns.
    dummy_columns = [col for col in processed_df.columns if any(col.startswith(cat + '_') for cat in categorical_features_to_encode)]

    # Combine numerical and dummy columns for the full feature set.
    features = [col for col in numerical_features if col != target_column] + dummy_columns
    features = list(set(features)) # Ensure unique features

    # Remove identifier columns that should not be used as predictive features.
    id_cols = ['TERM_CODE', 'SUBJECT_ID_SORT']
    features = [f for f in features if f not in id_cols]

    # Final feature matrix (X) and target vector (y).
    X = processed_df[features]
    y = processed_df[target_column]

    # Handle any remaining missing values in the feature set by filling with the column median.
    X = X.fillna(X.median())

    # --- Train/Validation Split ---
    # The evaluation requires a time-based split. We hold out the most recent terms for validation.
    sorted_terms = sorted(processed_df['TERM_CODE'].unique())
    if len(sorted_terms) > 1:
        # Hold out the latest 20% of terms for validation, ensuring at least one term is held out.
        num_val_terms = max(1, int(len(sorted_terms) * 0.2))
        validation_terms = sorted_terms[-num_val_terms:]
        
        train_indices = ~processed_df['TERM_CODE'].isin(validation_terms)
        val_indices = processed_df['TERM_CODE'].isin(validation_terms)

        X_train, y_train = X[train_indices], y[train_indices]
        X_val, y_val = X[val_indices], y[val_indices]

        # Fallback to random split if time-based split fails (e.g., results in an empty set).
        if X_train.empty or X_val.empty:
            print("Time-based split resulted in an empty training or validation set. Falling back to a random split.")
            X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)
    else:
        # Fallback for datasets with only one term.
        print("Only one term available. Using a random split for validation.")
        X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)

    # --- Model Training ---
    # A RandomForestClassifier is used, which is robust and performs well on tabular data.
    # 'class_weight=balanced' helps manage imbalanced classes in the target variable.
    model = RandomForestClassifier(n_estimators=100, random_state=42, class_weight='balanced', n_jobs=-1)
    model.fit(X_train, y_train)

    # --- Model Evaluation ---
    # Predict on the validation set and compute the macro F1 score as required.
    y_pred_val = model.predict(X_val)
    final_validation_score = f1_score(y_val, y_pred_val, average='macro')

    # --- Output ---
    # The final validation score is printed in the specific format required for parsing.
    print(f'Final Validation Performance: {final_validation_score}')

if __name__ == '__main__':
    run_ml_workflow()
