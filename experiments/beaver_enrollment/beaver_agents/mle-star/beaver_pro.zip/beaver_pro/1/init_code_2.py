
import pandas as pd
import numpy as np
import os
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score
from sklearn.preprocessing import LabelEncoder

# This script predicts high course enrollment based on institutional data.
# It fixes a SyntaxError from a previous version by ensuring all code is valid Python.

# Define file paths using the specified input directory structure
try:
    # Ensure the base directory for input data exists
    if not os.path.exists("./input"):
        raise FileNotFoundError("The './input' directory is missing.")

    TRAIN_DATA_DIR = './input/table_splits/train'
    if not os.path.exists(TRAIN_DATA_DIR):
        raise FileNotFoundError(f"The training data directory is missing: {TRAIN_DATA_DIR}")

    GOLD_ENROLLMENT_TRAIN_PATH = os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv')
    COURSE_OFFERING_PATH = os.path.join(TRAIN_DATA_DIR, 'course_offering.csv.gz')
    SUBJECT_PATH = os.path.join(TRAIN_DATA_DIR, 'subject.csv.gz')
    COURSE_SCHEDULE_PATH = os.path.join(TRAIN_DATA_DIR, 'course_schedule.csv.gz')

    # Load dataframes
    gold_df = pd.read_csv(GOLD_ENROLLMENT_TRAIN_PATH)
    offering_df = pd.read_csv(COURSE_OFFERING_PATH, compression='gzip', on_bad_lines='warn')
    subject_df = pd.read_csv(SUBJECT_PATH, compression='gzip', on_bad_lines='warn')
    schedule_df = pd.read_csv(COURSE_SCHEDULE_PATH, compression='gzip', on_bad_lines='warn')

    # --- Feature Engineering ---

    # 1. Aggregate course offering data to the course level (TERM_CODE, SUBJECT_ID)
    course_features = offering_df.groupby(['TERM_CODE', 'SUBJECT_ID']).agg(
        NUM_SECTIONS=('CRN', 'count'),
        TOTAL_MAX_ENROLLMENT=('MAX_ENROLLMENT', 'sum')
    ).reset_index()

    # 2. Engineer features from instruction method
    offering_schedule_df = pd.merge(offering_df[['TERM_CODE', 'CRN', 'SUBJECT_ID']],
                                    schedule_df[['TERM_CODE', 'CRN', 'INSTRUCTION_METHOD_CODE']],
                                    on=['TERM_CODE', 'CRN'], how='left')

    # Create dummy variables for instruction method and aggregate to course level
    if 'INSTRUCTION_METHOD_CODE' in offering_schedule_df.columns:
        instruction_method_dummies = pd.get_dummies(offering_schedule_df['INSTRUCTION_METHOD_CODE'], prefix='INSTR_METHOD')
        offering_schedule_dummies_df = pd.concat([offering_schedule_df[['TERM_CODE', 'SUBJECT_ID']], instruction_method_dummies], axis=1)
        instr_method_features = offering_schedule_dummies_df.groupby(['TERM_CODE', 'SUBJECT_ID']).sum().reset_index()
        # Merge instruction method features
        course_features = pd.merge(course_features, instr_method_features, on=['TERM_CODE', 'SUBJECT_ID'], how='left')


    # --- Data Merging and Preprocessing ---

    # 1. Prepare main DataFrame by merging gold labels with subject info
    df = pd.merge(gold_df, subject_df[['SUBJECT_ID_SORT', 'SUBJECT_ID', 'DEPARTMENT_ID']], on='SUBJECT_ID_SORT')

    # 2. Merge with the engineered features
    df = pd.merge(df, course_features, on=['TERM_CODE', 'SUBJECT_ID'], how='left')

    # 3. Clean data
    # Fill NaNs that may have resulted from left joins. 0 is a reasonable default for counts.
    df.fillna(0, inplace=True)
    # Convert term code to numeric for sorting
    df['TERM_CODE'] = pd.to_numeric(df['TERM_CODE'])


    # --- Model Training and Validation ---

    # 1. Encode target and categorical features
    df['HIGH_ENROLLMENT'] = df['HIGH_ENROLLMENT'].apply(lambda x: 1 if x == 'Y' else 0)
    le = LabelEncoder()
    df['DEPARTMENT_ID_ENCODED'] = le.fit_transform(df['DEPARTMENT_ID'])

    # 2. Define feature set
    feature_columns = [
        'NUM_SECTIONS',
        'TOTAL_MAX_ENROLLMENT',
        'DEPARTMENT_ID_ENCODED'
    ]
    # Add dummy columns for instruction methods if they exist
    for col in df.columns:
        if 'INSTR_METHOD_' in str(col):
            feature_columns.append(col)
    
    feature_columns = [col for col in feature_columns if col in df.columns]

    # 3. Time-based split for validation
    df = df.sort_values('TERM_CODE').reset_index(drop=True)
    X = df[feature_columns]
    y = df['HIGH_ENROLLMENT']
    
    unique_terms = sorted(df['TERM_CODE'].unique())

    if len(unique_terms) > 2:
        # Use last two terms for validation
        validation_terms = unique_terms[-2:]
        train_mask = ~df['TERM_CODE'].isin(validation_terms)
        val_mask = df['TERM_CODE'].isin(validation_terms)
        
        train_indices = df[train_mask].index
        val_indices = df[val_mask].index

        # Fallback if split results in an empty set
        if len(train_indices) == 0 or len(val_indices) == 0:
            train_size = int(len(df) * 0.8)
            train_indices = df.index[:train_size]
            val_indices = df.index[train_size:]
    else:
        # Fallback for datasets with few terms
        train_size = int(len(df) * 0.8)
        train_indices = df.index[:train_size]
        val_indices = df.index[train_size:]

    X_train, X_val = X.loc[train_indices], X.loc[val_indices]
    y_train, y_val = y.loc[train_indices], y.loc[val_indices]

    # 4. Train the model
    # RandomForest is robust for this type of tabular data.
    # class_weight='balanced' helps manage the imbalanced nature of the "top quartile" target.
    model = RandomForestClassifier(n_estimators=100, random_state=42, class_weight='balanced', n_jobs=-1)
    model.fit(X_train, y_train)

    # 5. Evaluate the model
    y_pred_val = model.predict(X_val)
    final_validation_score = f1_score(y_val, y_pred_val, average='macro')

    # Print the final validation score in the specified format
    print(f'Final Validation Performance: {final_validation_score}')

except FileNotFoundError as e:
    print(f"An error occurred: {e}")
    print("Please ensure the data is correctly placed in the './input/table_splits/train/' directory.")
except Exception as e:
    print(f"An unexpected error occurred: {e}")

