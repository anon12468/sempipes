
import os
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler, LabelEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import f1_score
import xgboost as xgb
import warnings

# Suppress warnings for a cleaner output
warnings.filterwarnings('ignore')

def load_and_merge_data(data_dir):
    """
    Loads all tables from the specified directory and merges them into a single DataFrame.
    """
    try:
        courses = pd.read_csv(os.path.join(data_dir, 'courses.csv'))
        instructors = pd.read_csv(os.path.join(data_dir, 'instructors.csv'))
        schedules = pd.read_csv(os.path.join(data_dir, 'schedules.csv'))
        subjects = pd.read_csv(os.path.join(data_dir, 'subjects.csv'))
    except FileNotFoundError as e:
        print(f"Error loading data files: {e}")
        print("Please ensure the input data is in the './input/train' directory.")
        return None

    # Merge courses with schedules
    df = pd.merge(courses, schedules, on=['TERM_CODE', 'COURSE_ID', 'SECTION_ID'], how='left')
    # Merge with instructors
    df = pd.merge(df, instructors, on=['TERM_CODE', 'COURSE_ID', 'SECTION_ID'], how='left')
    # Merge with subjects
    df = pd.merge(df, subjects, on='SUBJECT_ID', how='left')
    
    return df

def feature_engineer(df, target_df):
    """
    Performs feature engineering and merges with the target labels.
    """
    # Create a unique key for merging with target
    df['SUBJECT_ID_SORT'] = df['SUBJECT_ID'] + '-' + df['COURSE_ID'].astype(str)
    
    # Merge with gold labels
    df = pd.merge(df, target_df, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')

    # Drop rows where the target is NaN (courses not in the gold file summary)
    df.dropna(subset=['HIGH_ENROLLMENT'], inplace=True)

    # Basic Feature Engineering
    df['IS_GRAD_LEVEL'] = df['COURSE_ID'].astype(str).str.match(r'^[5-9]').astype(int)
    df['CREDITS_LOW'] = df['CREDITS_LOW'].fillna(0)
    df['CREDITS_HIGH'] = df['CREDITS_HIGH'].fillna(df['CREDITS_LOW'])
    df['CREDITS_AVG'] = (df['CREDITS_LOW'] + df['CREDITS_HIGH']) / 2
    
    # Instructor features
    df['INSTRUCTOR_ID'] = df['INSTRUCTOR_ID'].fillna('UNKNOWN')
    df['INSTRUCTOR_ROLE'] = df['INSTRUCTOR_ROLE'].fillna('UNKNOWN')
    
    # Handle NaNs in categorical features before encoding
    for col in ['INSTRUCTOR_ROLE', 'INSTRUCTION_MODE']:
        df[col] = df[col].fillna('UNKNOWN')

    # Label encode the target variable
    le = LabelEncoder()
    df['HIGH_ENROLLMENT'] = le.fit_transform(df['HIGH_ENROLLMENT'].astype(str))
    
    return df

def main(train_dir, gold_file_path):
    """
    Main function to run the training and validation pipeline.
    """
    # Load and process data
    raw_df = load_and_merge_data(train_dir)
    if raw_df is None:
        return

    try:
        gold_enrollment_train = pd.read_csv(gold_file_path)
    except FileNotFoundError:
        print(f"Gold file not found at: {gold_file_path}")
        return

    df = feature_engineer(raw_df, gold_enrollment_train)

    # Subsample for faster iteration if needed (as per instructions, don't remove)
    # Set frac=1.0 to use all data
    subsample_frac = 1.0 
    if subsample_frac < 1.0:
        df = df.sample(frac=subsample_frac, random_state=42)

    # Time-based split for validation
    # Sort by term and use the latest term(s) for validation
    df = df.sort_values('TERM_CODE').reset_index(drop=True)
    unique_terms = sorted(df['TERM_CODE'].unique())
    
    # Use the last term for validation, all others for training
    if len(unique_terms) < 2:
        print("Not enough terms for a time-based split. Using random split.")
        train_df, val_df = train_test_split(df, test_size=0.2, random_state=42, stratify=df['HIGH_ENROLLMENT'])
    else:
        val_term = unique_terms[-1]
        train_df = df[df['TERM_CODE'] < val_term]
        val_df = df[df['TERM_CODE'] == val_term]
        # Ensure validation set is not empty
        if len(val_df) == 0:
             print("Validation set is empty. Falling back to random split.")
             train_df, val_df = train_test_split(df, test_size=0.2, random_state=42, stratify=df['HIGH_ENROLLMENT'])


    # Define features and target
    TARGET = 'HIGH_ENROLLMENT'
    
    # Select a subset of features for the model
    categorical_features = ['INSTRUCTOR_ROLE', 'INSTRUCTION_MODE', 'SUBJECT_ID']
    numerical_features = ['CREDITS_AVG', 'IS_GRAD_LEVEL', 'TERM_CODE']
    
    features = categorical_features + numerical_features
    
    X_train = train_df[features]
    y_train = train_df[TARGET]
    X_val = val_df[features]
    y_val = val_df[TARGET]

    # Create preprocessing pipelines for numerical and categorical features
    numeric_transformer = StandardScaler()
    categorical_transformer = OneHotEncoder(handle_unknown='ignore')

    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numeric_transformer, numerical_features),
            ('cat', categorical_transformer, categorical_features)
        ])

    # Define the model pipeline
    model = Pipeline(steps=[('preprocessor', preprocessor),
                            ('classifier', xgb.XGBClassifier(objective='binary:logistic',
                                                             eval_metric='logloss',
                                                             use_label_encoder=False,
                                                             random_state=42))])

    # Train the model
    model.fit(X_train, y_train)

    # Evaluate the model
    y_pred = model.predict(X_val)
    
    # Calculate Macro F1 score
    final_validation_score = f1_score(y_val, y_pred, average='macro')
    
    print(f'Final Validation Performance: {final_validation_score}')


if __name__ == '__main__':
    # Using argparse for configuration, with defaults pointing to the specified directory structure
    parser = argparse.ArgumentParser()
    parser.add_argument('--train_dir', type=str, default='./input/train',
                        help='Directory containing the training data tables.')
    
    args = parser.parse_args()
    
    gold_file = os.path.join(args.train_dir, 'gold_enrollment_train.csv')
    
    main(args.train_dir, gold_file)
