
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score
from sklearn.preprocessing import LabelEncoder
import os
import warnings
import gc
import copy

# Suppress warnings for a cleaner output
warnings.filterwarnings('ignore')

# --- Configuration and Paths ---
TRAIN_DATA_DIR = './input/'

# --- Memory Reduction Helper ---
def reduce_mem_usage(df, verbose=False):
    start_mem = df.memory_usage().sum() / 1024**2
    for col in df.columns:
        col_type = df[col].dtype
        if col_type != object and col_type.name != 'category' and 'datetime' not in col_type.name:
            c_min = df[col].min()
            c_max = df[col].max()
            if str(col_type)[:3] == 'int':
                if c_min > np.iinfo(np.int8).min and c_max < np.iinfo(np.int8).max:
                    df[col] = df[col].astype(np.int8)
                elif c_min > np.iinfo(np.int16).min and c_max < np.iinfo(np.int16).max:
                    df[col] = df[col].astype(np.int16)
                elif c_min > np.iinfo(np.int32).min and c_max < np.iinfo(np.int32).max:
                    df[col] = df[col].astype(np.int32)
                elif c_min > np.iinfo(np.int64).min and c_max < np.iinfo(np.int64).max:
                    df[col] = df[col].astype(np.int64)
            else:
                if c_min > np.finfo(np.float32).min and c_max < np.finfo(np.float32).max:
                    df[col] = df[col].astype(np.float32)
                else:
                    df[col] = df[col].astype(np.float64)
        elif col_type == object:
            if len(df[col].unique()) / len(df[col]) < 0.5:
                df[col] = df[col].astype('category')
    return df

def run_experiment(ablation_name, use_numerical_features=True, nan_handling='fill_zero', validation_split_strategy='20_percent'):
    """
    Runs a single experiment with a specific configuration.
    """
    # --- Data Loading and Feature Engineering ---
    subject_summary_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'subject_summary.csv'))
    gold_enrollment_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv'))

    subject_summary_df = reduce_mem_usage(subject_summary_df)
    gold_enrollment_df = reduce_mem_usage(gold_enrollment_df)

    # --- Base Dataframe Preparation ---
    df = pd.merge(subject_summary_df, gold_enrollment_df, on=['TERM_CODE', 'SUBJECT_ID_SORT'])
    df['HIGH_ENROLLMENT'] = (df['HIGH_ENROLLMENT'] == 'Y').astype(int)
    df = df.sort_values('TERM_CODE').reset_index(drop=True)

    del subject_summary_df, gold_enrollment_df
    gc.collect()

    df_base = df.copy()

    # --- Ablation: Feature Selection ---
    excluded_cols = ['TERM_CODE', 'SUBJECT_ID_SORT', 'HIGH_ENROLLMENT']
    all_features = [col for col in df_base.columns if col not in excluded_cols]
    categorical_features = df_base[all_features].select_dtypes(include=['object', 'category']).columns
    numerical_features = df_base[all_features].select_dtypes(exclude=['object', 'category']).columns
    
    if use_numerical_features:
        features = all_features
    else: # Use only categorical features
        features = list(categorical_features)
        
    # Apply Label Encoding to categorical features.
    for col in categorical_features:
        le = LabelEncoder()
        df_base[col] = le.fit_transform(df_base[col].astype(str))

    # --- Ablation: NaN Handling ---
    if nan_handling == 'fill_zero':
        df_base[features] = df_base[features].fillna(0)
    elif nan_handling == 'drop_na':
        df_base.dropna(subset=features, inplace=True)

    # --- Ablation: Time-based Validation Split ---
    unique_terms = df_base['TERM_CODE'].unique()
    
    if len(unique_terms) > 1 and validation_split_strategy != 'random':
        if validation_split_strategy == '20_percent':
            num_validation_terms = max(1, int(len(unique_terms) * 0.2))
            train_terms = unique_terms[:-num_validation_terms]
            validation_terms = unique_terms[-num_validation_terms:]
        elif validation_split_strategy == 'single_term':
            train_terms = unique_terms[:-1]
            validation_terms = unique_terms[-1:]
            
        train_df = df_base[df_base['TERM_CODE'].isin(train_terms)]
        validation_df = df_base[df_base['TERM_CODE'].isin(validation_terms)]
    else:
        indices = df_base.index.to_numpy()
        train_indices, validation_indices = train_test_split(
            indices, test_size=0.2, random_state=42, stratify=df_base['HIGH_ENROLLMENT']
        )
        train_df = df_base.loc[train_indices]
        validation_df = df_base.loc[validation_indices]

    y_train = train_df['HIGH_ENROLLMENT']
    y_val = validation_df['HIGH_ENROLLMENT']
    X_train = train_df[features]
    X_val = validation_df[features]

    # --- Model Training and Evaluation ---
    score = 0.0
    if not X_train.empty and not y_train.empty and not X_val.empty:
        model = RandomForestClassifier(n_estimators=100, random_state=42, class_weight='balanced', n_jobs=-1)
        model.fit(X_train, y_train)
        y_pred = model.predict(X_val)
        score = f1_score(y_val, y_pred, average='macro')

    print(f'Performance for "{ablation_name}": {score:.4f}')
    return score

if __name__ == '__main__':
    ablation_results = {}

    # --- Baseline Experiment ---
    baseline_score = run_experiment("Baseline (All features, fillna(0), 20% terms for validation)")
    ablation_results["Baseline"] = baseline_score

    # --- Ablation 1: Remove Numerical Features ---
    score_no_numerical = run_experiment("Ablation: No Numerical Features", use_numerical_features=False)
    ablation_results["Removing Numerical Features"] = baseline_score - score_no_numerical
    
    # --- Ablation 2: Change NaN handling to dropna() ---
    score_dropna = run_experiment("Ablation: Drop Rows with NaN", nan_handling='drop_na')
    ablation_results["Using dropna() instead of fillna(0)"] = baseline_score - score_dropna
    
    # --- Ablation 3: Change Validation Split to single term ---
    score_single_term_val = run_experiment("Ablation: Single Term Validation", validation_split_strategy='single_term')
    ablation_results["Using Single Term Validation"] = baseline_score - score_single_term_val

    # --- Conclusion ---
    # Find the component whose removal caused the largest drop in performance
    if ablation_results:
        # Exclude baseline from the components to be compared
        performance_drops = {k: v for k, v in ablation_results.items() if k != "Baseline"}
        
        if performance_drops:
            most_impactful_component = max(performance_drops, key=performance_drops.get)
            print("\n--- Conclusion ---")
            print(f"The '{most_impactful_component}' contributes the most to the overall performance.")
        else:
            print("\n--- Conclusion ---")
            print("Could not determine the most impactful component.")
    else:
        print("Ablation study did not produce any results.")
