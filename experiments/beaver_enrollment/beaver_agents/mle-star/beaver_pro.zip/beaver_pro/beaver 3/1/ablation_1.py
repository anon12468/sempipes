
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score
from sklearn.preprocessing import LabelEncoder
import os
import warnings
import gc

# Suppress warnings for a cleaner output
warnings.filterwarnings('ignore')

# --- Configuration and Paths ---
TRAIN_DATA_DIR = './input/'

# --- Memory Reduction Helper ---
def reduce_mem_usage(df):
    start_mem = df.memory_usage().sum() / 1024**2
    for col in df.columns:
        col_type = df[col].dtype
        if col_type != object and col_type.name != 'category' and 'datetime' not in col_type.name:
            c_min, c_max = df[col].min(), df[col].max()
            if str(col_type)[:3] == 'int':
                if c_min > np.iinfo(np.int8).min and c_max < np.iinfo(np.int8).max:
                    df[col] = df[col].astype(np.int8)
                elif c_min > np.iinfo(np.int16).min and c_max < np.iinfo(np.int16).max:
                    df[col] = df[col].astype(np.int16)
                elif c_min > np.iinfo(np.int32).min and c_max < np.iinfo(np.int32).max:
                    df[col] = df[col].astype(np.int32)
                elif c_min > np.iinfo(np.int64).min and c_max < np.iinfo(np.int64).max:
                    df[col] = df[col].astype(np.int64)
            else:
                if c_min > np.finfo(np.float32).min and c_max < np.finfo(np.float32).max:
                    df[col] = df[col].astype(np.float32)
                else:
                    df[col] = df[col].astype(np.float64)
        elif col_type == object and col != 'TERM_CODE':
            if len(df[col].unique()) / len(df[col]) < 0.5:
                df[col] = df[col].astype('category')
    return df

def run_experiment(use_mem_reduce, use_advanced_features, use_special_nan_fill):
    """
    Runs a single training and evaluation pipeline with specified components enabled/disabled.
    """
    # --- Data Loading ---
    subject_summary_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'subject_summary.csv'))
    gold_enrollment_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv'))

    # --- Memory Reduction ---
    if use_mem_reduce:
        subject_summary_df = reduce_mem_usage(subject_summary_df)
        gold_enrollment_df = reduce_mem_usage(gold_enrollment_df)

    # --- Base Dataframe Preparation ---
    df = pd.merge(subject_summary_df, gold_enrollment_df, on=['TERM_CODE', 'SUBJECT_ID_SORT'])
    df['HIGH_ENROLLMENT'] = (df['HIGH_ENROLLMENT'] == 'Y').astype(int)
    
    del subject_summary_df, gold_enrollment_df
    gc.collect()
    
    df_base = df.copy()

    # --- Advanced Feature Engineering ---
    if use_advanced_features:
        if 'ENRL_CNT' in df_base.columns and 'MAX_ENRL' in df_base.columns:
            df_base['enrollment_to_capacity_ratio'] = (df_base['ENRL_CNT'] / df_base['MAX_ENRL']).replace([np.inf, -np.inf], 0).fillna(0)
            df_base = df_base.sort_values(['SUBJECT_ID_SORT', 'TERM_CODE'])
            grouped_ratio = df_base.groupby('SUBJECT_ID_SORT')['enrollment_to_capacity_ratio']
            df_base['ratio_lag_1'] = grouped_ratio.shift(1)
            df_base['ratio_rolling_mean_3'] = grouped_ratio.transform(lambda x: x.rolling(window=3, min_periods=1).mean())
            df_base['ratio_rolling_std_3'] = grouped_ratio.transform(lambda x: x.rolling(window=3, min_periods=1).std())

            if use_special_nan_fill:
                temporal_features_with_nans = ['ratio_lag_1', 'ratio_rolling_std_3']
                for col in temporal_features_with_nans:
                    group_mean = df_base.groupby('SUBJECT_ID_SORT')[col].transform('mean')
                    df_base[col] = df_base[col].fillna(group_mean)
    
    # --- Feature Selection and Preprocessing ---
    excluded_cols = ['TERM_CODE', 'SUBJECT_ID_SORT', 'HIGH_ENROLLMENT']
    features = [col for col in df_base.columns if col not in excluded_cols]
    categorical_features = df_base[features].select_dtypes(include=['object', 'category']).columns

    for col in categorical_features:
        le = LabelEncoder()
        df_base[col] = le.fit_transform(df_base[col].astype(str))

    df_base[features] = df_base[features].fillna(0)

    # --- Time-based Validation Split ---
    df_base = df_base.sort_values('TERM_CODE').reset_index(drop=True)
    unique_terms = df_base['TERM_CODE'].unique()
    if len(unique_terms) > 4:
        num_validation_terms = max(1, int(len(unique_terms) * 0.2))
        train_terms = unique_terms[:-num_validation_terms]
        validation_terms = unique_terms[-num_validation_terms:]
        train_df = df_base[df_base['TERM_CODE'].isin(train_terms)]
        validation_df = df_base[df_base['TERM_CODE'].isin(validation_terms)]
    else:
        indices = df_base.index.to_numpy()
        train_indices, validation_indices = train_test_split(
            indices, test_size=0.2, random_state=42, stratify=df_base['HIGH_ENROLLMENT']
        )
        train_df = df_base.loc[train_indices]
        validation_df = df_base.loc[validation_indices]

    y_train = train_df['HIGH_ENROLLMENT']
    X_train = train_df[features]
    y_val = validation_df['HIGH_ENROLLMENT']
    X_val = validation_df[features]

    # --- Model Training and Evaluation ---
    score = 0.0
    if not X_train.empty and not y_train.empty and not X_val.empty:
        model = RandomForestClassifier(n_estimators=100, random_state=42, class_weight='balanced', n_jobs=-1)
        model.fit(X_train, y_train)
        y_pred = model.predict(X_val)
        score = f1_score(y_val, y_pred, average='macro')
    
    gc.collect()
    return score

# --- Ablation Study Execution ---
ablation_scores = {}

# Baseline: All components enabled
ablation_scores['Baseline (All Features)'] = run_experiment(
    use_mem_reduce=True, 
    use_advanced_features=True, 
    use_special_nan_fill=True
)

# Ablation 1: Disable Memory Reduction
ablation_scores['No Memory Reduction'] = run_experiment(
    use_mem_reduce=False, 
    use_advanced_features=True, 
    use_special_nan_fill=True
)

# Ablation 2: Disable Advanced Features (temporal, ratio)
ablation_scores['No Advanced Features'] = run_experiment(
    use_mem_reduce=True, 
    use_advanced_features=False, 
    use_special_nan_fill=False
)

# Ablation 3: Use basic NaN fill instead of specialized group-wise fill
ablation_scores['Basic NaN Fill Only'] = run_experiment(
    use_mem_reduce=True, 
    use_advanced_features=True, 
    use_special_nan_fill=False
)


# --- Print Results ---
print("--- Ablation Study Results ---")
for name, score in ablation_scores.items():
    print(f"Performance with '{name}': {score:.4f}")

# --- Conclusion ---
baseline_score = ablation_scores['Baseline (All Features)']
performance_drops = {
    "Advanced Features": baseline_score - ablation_scores['No Advanced Features'],
    "Specialized NaN Fill": baseline_score - ablation_scores['Basic NaN Fill Only'],
    "Memory Reduction": baseline_score - ablation_scores['No Memory Reduction'],
}

# Find the component whose removal caused the biggest drop in performance
if not performance_drops:
    most_impactful_part = "N/A"
else:
    most_impactful_part = max(performance_drops, key=performance_drops.get)

print("\n--- Conclusion ---")
print(f"The '{most_impactful_part}' contributes the most to the overall performance.")
print(f"Removing it resulted in the largest performance drop of {performance_drops.get(most_impactful_part, 0):.4f} in the F1 macro score.")
