
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score
from sklearn.preprocessing import LabelEncoder
import os
import warnings

# Suppress warnings for a cleaner output
warnings.filterwarnings('ignore')

# Define the correct path to the training data directory.
TRAIN_DATA_DIR = './input/'

# --- 1. Data Loading and Merging ---
# Load all relevant tables from the input directory.
# This combines the data loading from both base and reference solutions.
try:
    gold_enrollment_path = os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv')
    subject_summary_path = os.path.join(TRAIN_DATA_DIR, 'subject_summary.csv')
    course_summary_path = os.path.join(TRAIN_DATA_DIR, 'course_summary.csv')
    course_offering_path = os.path.join(TRAIN_DATA_DIR, 'course_offering_details.csv')
    
    gold_enrollment_df = pd.read_csv(gold_enrollment_path)
    subject_summary_df = pd.read_csv(subject_summary_path)
    course_summary_df = pd.read_csv(course_summary_path)
    course_offering_df = pd.read_csv(course_offering_path)

    # Merge dataframes following the more comprehensive approach from the reference solution.
    df = pd.merge(gold_enrollment_df, subject_summary_df, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')
    df = pd.merge(df, course_summary_df, on='SUBJECT_ID_SORT', how='left')

    # --- 2. Common Preprocessing ---
    # Convert the target variable 'HIGH_ENROLLMENT' from 'Y'/'N' to binary 1/0.
    df['HIGH_ENROLLMENT'] = (df['HIGH_ENROLLMENT'] == 'Y').astype(int)

    # Sort data by term to prepare for time-based operations and validation split.
    df = df.sort_values('TERM_CODE').reset_index(drop=True)

    # Create two separate dataframes for different feature engineering strategies.
    df_base = df.copy()
    df_ref = df.copy()

    # --- 3. Feature Engineering (Base Solution Strategy) ---
    excluded_cols_base = ['TERM_CODE', 'SUBJECT_ID_SORT', 'HIGH_ENROLLMENT']
    features_base = [col for col in df_base.columns if col not in excluded_cols_base]
    
    categorical_features_base = df_base[features_base].select_dtypes(include=['object']).columns

    # Apply Label Encoding to categorical features.
    for col in categorical_features_base:
        le = LabelEncoder()
        df_base[col] = le.fit_transform(df_base[col].astype(str))

    # Handle missing values in feature columns with a simple fill-zero strategy.
    df_base[features_base] = df_base[features_base].fillna(0)

    # --- 4. Feature Engineering (Reference Solution Strategy) ---
    # Time-based features
    df_ref['TERM_CODE'] = df_ref['TERM_CODE'].astype(int)
    df_ref['TERM_YEAR'] = df_ref['TERM_CODE'] // 100
    df_ref['TERM_SEASON'] = df_ref['TERM_CODE'] % 100

    # Categorical features from SUBJECT_ID_SORT
    df_ref['DEPARTMENT_CODE'] = df_ref['SUBJECT_ID_SORT'].apply(lambda x: x.split('_')[0])
    df_ref['COURSE_LEVEL'] = df_ref['SUBJECT_ID_SORT'].apply(lambda x: x.split('_')[1][0] + '00' if len(x.split('_')) > 1 and x.split('_')[1] else '000')

    # Aggregate features from course offerings
    instructor_agg = course_offering_df.groupby(['TERM_CODE', 'SUBJECT_ID_SORT'])['INSTRUCTOR_ID'].nunique().reset_index()
    instructor_agg.rename(columns={'INSTRUCTOR_ID': 'UNIQUE_INSTRUCTOR_COUNT'}, inplace=True)
    df_ref = pd.merge(df_ref, instructor_agg, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')

    # Handle Missing Values (Part 1 - before creating lags)
    df_ref['UNIQUE_INSTRUCTOR_COUNT'].fillna(0, inplace=True)
    df_ref['CREDITS_MIN'].fillna(df_ref['CREDITS_MIN'].median(), inplace=True)
    df_ref['CREDITS_MAX'].fillna(df_ref['CREDITS_MAX'].median(), inplace=True)
    for col in ['TOTAL_ENROLLMENT', 'OFFERING_COUNT']:
        df_ref[col].fillna(0, inplace=True)

    # Create Lag Features
    df_ref.sort_values(['SUBJECT_ID_SORT', 'TERM_CODE'], inplace=True)
    df_ref['ENROLLMENT_LAG_1'] = df_ref.groupby('SUBJECT_ID_SORT')['TOTAL_ENROLLMENT'].shift(1)
    df_ref['OFFERING_COUNT_LAG_1'] = df_ref.groupby('SUBJECT_ID_SORT')['OFFERING_COUNT'].shift(1)
    df_ref['ENROLLMENT_ROLLING_AVG_3'] = df_ref.groupby('SUBJECT_ID_SORT')['TOTAL_ENROLLMENT'].shift(1).rolling(window=3, min_periods=1).mean()

    # Handle Missing Values (Part 2 - after creating lags)
    for col in ['ENROLLMENT_LAG_1', 'OFFERING_COUNT_LAG_1', 'ENROLLMENT_ROLLING_AVG_3']:
        df_ref[col].fillna(-1, inplace=True)
    df_ref['DEPARTMENT_CODE'].fillna('missing', inplace=True)
    df_ref['COURSE_LEVEL'].fillna('missing', inplace=True)

    # Define feature set and One-Hot Encode for reference model
    numerical_features_ref = [
        'TERM_YEAR', 'TERM_SEASON', 'CREDITS_MIN', 'CREDITS_MAX',
        'UNIQUE_INSTRUCTOR_COUNT', 'ENROLLMENT_LAG_1', 'OFFERING_COUNT_LAG_1',
        'ENROLLMENT_ROLLING_AVG_3'
    ]
    categorical_features_ref = ['DEPARTMENT_CODE', 'COURSE_LEVEL']
    df_ref = pd.get_dummies(df_ref, columns=categorical_features_ref, dummy_na=False)
    one_hot_cols = [col for col in df_ref.columns if any(cat_feat in col for cat_feat in categorical_features_ref)]
    features_ref = numerical_features_ref + one_hot_cols

    # --- 5. Time-based Validation Split ---
    unique_terms = sorted(df['TERM_CODE'].unique())
    
    if len(unique_terms) > 4:
        num_validation_terms = max(1, int(len(unique_terms) * 0.2))
        train_terms = unique_terms[:-num_validation_terms]
        validation_terms = unique_terms[-num_validation_terms:]

        train_df_base = df_base[df_base['TERM_CODE'].isin(train_terms)]
        validation_df_base = df_base[df_base['TERM_CODE'].isin(validation_terms)]
        train_df_ref = df_ref[df_ref['TERM_CODE'].isin(train_terms)]
        validation_df_ref = df_ref[df_ref['TERM_CODE'].isin(validation_terms)]
    else:
        # Fallback to a random split, ensuring consistency across both feature sets
        indices = df.index.to_numpy()
        train_indices, validation_indices = train_test_split(
            indices, test_size=0.2, random_state=42, stratify=df['HIGH_ENROLLMENT']
        )
        train_df_base = df_base.loc[train_indices]
        validation_df_base = df_base.loc[validation_indices]
        train_df_ref = df_ref.loc[train_indices]
        validation_df_ref = df_ref.loc[validation_indices]

    # Prepare feature matrices and target vectors
    y_train = train_df_base['HIGH_ENROLLMENT']
    y_val = validation_df_base['HIGH_ENROLLMENT']
    
    X_train_base = train_df_base[features_base]
    X_val_base = validation_df_base[features_base]
    
    X_train_ref = train_df_ref[features_ref]
    X_val_ref = validation_df_ref[features_ref]
    
    # Align columns for reference model data (due to one-hot encoding)
    X_train_ref, X_val_ref = X_train_ref.align(X_val_ref, join='left', axis=1, fill_value=0)

    # --- 6. Model Training and Ensembling ---
    final_validation_score = 0.0
    if not X_train_base.empty and not y_train.empty:
        # Model 1 (from Base Solution)
        model_base = RandomForestClassifier(n_estimators=100, random_state=42, class_weight='balanced', n_jobs=-1)
        model_base.fit(X_train_base, y_train)

        # Model 2 (from Reference Solution)
        model_ref = RandomForestClassifier(n_estimators=100, random_state=42, class_weight='balanced', n_jobs=-1)
        model_ref.fit(X_train_ref, y_train)

        # --- 7. Evaluation with Simple Averaging Ensemble ---
        if not X_val_base.empty:
            # Get prediction probabilities from both models
            y_pred_proba_base = model_base.predict_proba(X_val_base)[:, 1]
            y_pred_proba_ref = model_ref.predict_proba(X_val_ref)[:, 1]

            # Average the probabilities for the ensemble prediction
            y_pred_proba_ensemble = (y_pred_proba_base + y_pred_proba_ref) / 2.0
            
            # Convert final probabilities to class predictions
            y_pred_ensemble = (y_pred_proba_ensemble > 0.5).astype(int)

            # Calculate the macro F1 score for the ensembled model
            final_validation_score = f1_score(y_val, y_pred_ensemble, average='macro')

    # Print the final performance metric in the required format.
    print(f'Final Validation Performance: {final_validation_score}')

except FileNotFoundError as e:
    print(f"Error: A required data file was not found. Please check the contents of '{TRAIN_DATA_DIR}'.")
    print(f"Details: {e}")
    # Print a zero score to indicate failure if data is missing
    print(f'Final Validation Performance: 0.0')
except Exception as e:
    print(f"An unexpected error occurred during script execution: {e}")
    # Print a zero score for other errors
    print(f'Final Validation Performance: 0.0')

