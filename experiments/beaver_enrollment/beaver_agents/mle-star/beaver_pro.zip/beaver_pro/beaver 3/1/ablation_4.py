
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import f1_score
from sklearn.preprocessing import LabelEncoder
import os
import warnings
import gc

# Suppress warnings for a cleaner output
warnings.filterwarnings('ignore')

# --- Configuration and Paths ---
TRAIN_DATA_DIR = './input/'

# --- Memory Reduction Helper ---
def reduce_mem_usage(df, verbose=False):
    start_mem = df.memory_usage().sum() / 1024**2
    for col in df.columns:
        col_type = df[col].dtype
        if col_type != object and col_type.name != 'category' and 'datetime' not in col_type.name:
            c_min = df[col].min()
            c_max = df[col].max()
            if str(col_type)[:3] == 'int':
                if c_min > np.iinfo(np.int8).min and c_max < np.iinfo(np.int8).max:
                    df[col] = df[col].astype(np.int8)
                elif c_min > np.iinfo(np.int16).min and c_max < np.iinfo(np.int16).max:
                    df[col] = df[col].astype(np.int16)
                elif c_min > np.iinfo(np.int32).min and c_max < np.iinfo(np.int32).max:
                    df[col] = df[col].astype(np.int32)
                elif c_min > np.iinfo(np.int64).min and c_max < np.iinfo(np.int64).max:
                    df[col] = df[col].astype(np.int64)
            else:
                if c_min > np.finfo(np.float32).min and c_max < np.finfo(np.float32).max:
                    df[col] = df[col].astype(np.float32)
                else:
                    df[col] = df[col].astype(np.float64)
        elif col_type == object:
            if len(df[col].unique()) / len(df[col]) < 0.5:
                df[col] = df[col].astype('category')
    return df

# --- Data Loading ---
subject_summary_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'subject_summary.csv'))
gold_enrollment_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv'))

subject_summary_df = reduce_mem_usage(subject_summary_df)
gold_enrollment_df = reduce_mem_usage(gold_enrollment_df)

# --- Base Dataframe Preparation ---
df_original = pd.merge(subject_summary_df, gold_enrollment_df, on=['TERM_CODE', 'SUBJECT_ID_SORT'])
df_original['HIGH_ENROLLMENT'] = (df_original['HIGH_ENROLLMENT'] == 'Y').astype(int)

del subject_summary_df, gold_enrollment_df
gc.collect()

# Store results
ablation_results = {}

# --- Helper Function for Running Experiments ---
def run_experiment(df, experiment_name, model_class=RandomForestClassifier, sort_data=True, model_params=None):
    if model_params is None:
        model_params = {'n_estimators': 100, 'random_state': 42, 'class_weight': 'balanced', 'n_jobs': -1}

    # --- Data Preparation ---
    if sort_data:
        df = df.sort_values('TERM_CODE').reset_index(drop=True)

    df_base = df.copy()

    excluded_cols = ['TERM_CODE', 'SUBJECT_ID_SORT', 'HIGH_ENROLLMENT']
    features = [col for col in df_base.columns if col not in excluded_cols]
    categorical_features = df_base[features].select_dtypes(include=['object', 'category']).columns

    for col in categorical_features:
        le = LabelEncoder()
        df_base[col] = le.fit_transform(df_base[col].astype(str))

    df_base[features] = df_base[features].fillna(0)

    # --- Time-based Validation Split ---
    unique_terms = df['TERM_CODE'].unique()
    if len(unique_terms) > 4:
        num_validation_terms = max(1, int(len(unique_terms) * 0.2))
        train_terms = unique_terms[:-num_validation_terms]
        validation_terms = unique_terms[-num_validation_terms:]
        train_df = df_base[df_base['TERM_CODE'].isin(train_terms)]
        validation_df = df_base[df_base['TERM_CODE'].isin(validation_terms)]
    else:
        indices = df.index.to_numpy()
        train_indices, validation_indices = train_test_split(
            indices, test_size=0.2, random_state=42, stratify=df['HIGH_ENROLLMENT']
        )
        train_df = df_base.loc[train_indices]
        validation_df = df_base.loc[validation_indices]

    y_train = train_df['HIGH_ENROLLMENT']
    y_val = validation_df['HIGH_ENROLLMENT']
    X_train = train_df[features]
    X_val = validation_df[features]

    # --- Model Training and Evaluation ---
    score = 0.0
    if not X_train.empty and not y_train.empty and not X_val.empty:
        model = model_class(**model_params)
        model.fit(X_train, y_train)
        y_pred = model.predict(X_val)
        score = f1_score(y_val, y_pred, average='macro')

    print(f'Performance for "{experiment_name}": {score:.4f}')
    return score

# --- Experiment 1: Baseline ---
# This is the original script's configuration.
baseline_score = run_experiment(
    df_original.copy(),
    "Baseline (Random Forest, Chronological Sort, Unconstrained Depth)"
)
ablation_results["Baseline"] = baseline_score

# --- Experiment 2: Ablation of Model Type ---
# Replace RandomForest with a simpler DecisionTree.
dt_params = {'random_state': 42, 'class_weight': 'balanced'}
score_no_ensemble = run_experiment(
    df_original.copy(),
    "Ablation: Use single Decision Tree",
    model_class=DecisionTreeClassifier,
    model_params=dt_params
)
ablation_results["Model Type (single Decision Tree)"] = baseline_score - score_no_ensemble

# --- Experiment 3: Ablation of Data Sorting ---
# Remove the chronological sorting of data before the time-based split.
score_no_sort = run_experiment(
    df_original.copy(),
    "Ablation: Remove chronological sort",
    sort_data=False
)
ablation_results["Chronological Sort"] = baseline_score - score_no_sort

# --- Experiment 4: Ablation of Model Complexity ---
# Constrain the max_depth of the RandomForest trees.
rf_depth_params = {'n_estimators': 100, 'random_state': 42, 'class_weight': 'balanced', 'n_jobs': -1, 'max_depth': 10}
score_constrained_depth = run_experiment(
    df_original.copy(),
    "Ablation: Constrain RF max_depth=10",
    model_params=rf_depth_params
)
ablation_results["Model Complexity (Unconstrained Depth)"] = baseline_score - score_constrained_depth

# --- Conclusion ---
# Find the component whose removal caused the biggest drop in performance.
# We remove "Baseline" as it's not an ablation.
performance_drops = {k: v for k, v in ablation_results.items() if k != "Baseline"}
most_impactful_component = max(performance_drops, key=performance_drops.get)
max_drop = performance_drops[most_impactful_component]

print("\n--- Ablation Study Summary ---")
for component, drop in performance_drops.items():
    print(f"Impact of '{component}': {drop:.4f} F1 score drop")

print(f"\nConclusion: The '{most_impactful_component}' contributes the most to the overall performance, with a performance drop of {max_drop:.4f} when altered.")

