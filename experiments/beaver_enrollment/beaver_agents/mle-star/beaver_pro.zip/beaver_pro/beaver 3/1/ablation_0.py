
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score
from sklearn.preprocessing import LabelEncoder
import os
import warnings
import gc

# Suppress warnings for a cleaner output
warnings.filterwarnings('ignore')

def run_experiment(class_weight_param='balanced', validation_strategy='time'):
    """
    Runs a single experiment with specified configurations.
    
    Args:
        class_weight_param (str or None): The 'class_weight' parameter for RandomForestClassifier.
        validation_strategy (str): 'time' for time-based split, 'random' for random split.

    Returns:
        float: The F1 score on the validation set.
    """
    
    # --- Configuration and Paths ---
    TRAIN_DATA_DIR = './input/'

    # --- Memory Reduction Helper ---
    def reduce_mem_usage(df):
        start_mem = df.memory_usage().sum() / 1024**2
        for col in df.columns:
            col_type = df[col].dtype
            if col_type != object and col_type.name != 'category' and 'datetime' not in col_type.name:
                c_min, c_max = df[col].min(), df[col].max()
                if str(col_type)[:3] == 'int':
                    if c_min > np.iinfo(np.int8).min and c_max < np.iinfo(np.int8).max: df[col] = df[col].astype(np.int8)
                    elif c_min > np.iinfo(np.int16).min and c_max < np.iinfo(np.int16).max: df[col] = df[col].astype(np.int16)
                    elif c_min > np.iinfo(np.int32).min and c_max < np.iinfo(np.int32).max: df[col] = df[col].astype(np.int32)
                    elif c_min > np.iinfo(np.int64).min and c_max < np.iinfo(np.int64).max: df[col] = df[col].astype(np.int64)
                else:
                    if c_min > np.finfo(np.float32).min and c_max < np.finfo(np.float32).max: df[col] = df[col].astype(np.float32)
                    else: df[col] = df[col].astype(np.float64)
            elif col_type == object:
                if len(df[col].unique()) / len(df[col]) < 0.5: df[col] = df[col].astype('category')
        return df

    # --- Data Loading and Feature Engineering ---
    subject_summary_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'subject_summary.csv'))
    gold_enrollment_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv'))

    subject_summary_df = reduce_mem_usage(subject_summary_df)
    gold_enrollment_df = reduce_mem_usage(gold_enrollment_df)

    # --- Base Dataframe Preparation ---
    df = pd.merge(subject_summary_df, gold_enrollment_df, on=['TERM_CODE', 'SUBJECT_ID_SORT'])
    df['HIGH_ENROLLMENT'] = (df['HIGH_ENROLLMENT'] == 'Y').astype(int)
    df = df.sort_values('TERM_CODE').reset_index(drop=True)

    del subject_summary_df, gold_enrollment_df
    gc.collect()

    # --- Feature Engineering ---
    df_base = df.copy()
    excluded_cols = ['TERM_CODE', 'SUBJECT_ID_SORT', 'HIGH_ENROLLMENT']
    features = [col for col in df_base.columns if col not in excluded_cols]
    categorical_features = df_base[features].select_dtypes(include=['object', 'category']).columns

    for col in categorical_features:
        le = LabelEncoder()
        df_base[col] = le.fit_transform(df_base[col].astype(str))

    df_base[features] = df_base[features].fillna(0)

    # --- Validation Split ---
    if validation_strategy == 'time':
        unique_terms = df['TERM_CODE'].unique()
        if len(unique_terms) > 4:
            num_validation_terms = max(1, int(len(unique_terms) * 0.2))
            train_terms = unique_terms[:-num_validation_terms]
            validation_terms = unique_terms[-num_validation_terms:]
            train_df = df_base[df_base['TERM_CODE'].isin(train_terms)]
            validation_df = df_base[df_base['TERM_CODE'].isin(validation_terms)]
        else:
             # Fallback for safety, though we force random split in the else block
            indices = df.index.to_numpy()
            train_indices, validation_indices = train_test_split(indices, test_size=0.2, random_state=42, stratify=df['HIGH_ENROLLMENT'])
            train_df = df_base.loc[train_indices]
            validation_df = df_base.loc[validation_indices]

    elif validation_strategy == 'random':
        indices = df.index.to_numpy()
        train_indices, validation_indices = train_test_split(indices, test_size=0.2, random_state=42, stratify=df['HIGH_ENROLLMENT'])
        train_df = df_base.loc[train_indices]
        validation_df = df_base.loc[validation_indices]
    
    else:
        raise ValueError("validation_strategy must be 'time' or 'random'")


    y_train = train_df['HIGH_ENROLLMENT']
    y_val = validation_df['HIGH_ENROLLMENT']
    X_train = train_df[features]
    X_val = validation_df[features]

    # --- Model Training and Evaluation ---
    final_validation_score = 0.0
    if not X_train.empty and not y_train.empty:
        model = RandomForestClassifier(n_estimators=100, random_state=42, class_weight=class_weight_param, n_jobs=-1)
        model.fit(X_train, y_train)

        if not X_val.empty:
            y_pred = model.predict(X_val)
            final_validation_score = f1_score(y_val, y_pred, average='macro')
    
    # Clean up memory
    del df, df_base, train_df, validation_df, X_train, y_train, X_val, y_val
    gc.collect()

    return final_validation_score


# --- Ablation Study ---
if __name__ == '__main__':
    ablation_results = {}

    # Baseline: Original model
    print("Running: Baseline model")
    baseline_score = run_experiment(class_weight_param='balanced', validation_strategy='time')
    ablation_results['Baseline'] = baseline_score
    print(f"  - Performance (F1 Macro): {baseline_score:.4f}\n")

    # Ablation 1: Remove class weighting
    print("Running: Ablation 1 - No Class Weighting")
    no_weight_score = run_experiment(class_weight_param=None, validation_strategy='time')
    ablation_results['No Class Weighting'] = no_weight_score
    print(f"  - Performance (F1 Macro): {no_weight_score:.4f}\n")

    # Ablation 2: Use random split instead of time-based split
    print("Running: Ablation 2 - Random Validation Split")
    random_split_score = run_experiment(class_weight_param='balanced', validation_strategy='random')
    ablation_results['Random Validation Split'] = random_split_score
    print(f"  - Performance (F1 Macro): {random_split_score:.4f}\n")
    
    # --- Conclusion ---
    print("-" * 30)
    print("Ablation Study Summary:")
    print(f"Baseline Performance: {ablation_results['Baseline']:.4f}")
    
    perf_drop_no_weight = ablation_results['Baseline'] - ablation_results['No Class Weighting']
    perf_drop_random_split = ablation_results['Baseline'] - ablation_results['Random Validation Split']

    print(f"Removing Class Weighting changed performance by: {perf_drop_no_weight:+.4f}")
    print(f"Using Random Split changed performance by: {perf_drop_random_split:+.4f} (Note: positive value means random split was 'easier' and thus likely overestimates performance)")

    contributions = {
        'Class Weighting': perf_drop_no_weight,
        'Time-Based Validation Split': perf_drop_random_split
    }

    # The most important feature is the one whose removal causes the biggest drop in true performance.
    # The time-based split is a more realistic estimate of performance, so we compare other ablations to it.
    # A higher score on random split indicates it's an easier, less realistic validation, making the time-split strategy important.
    
    most_important_feature = max(contributions, key=contributions.get)

    print("-" * 30)
    if perf_drop_random_split > 0 and perf_drop_random_split > perf_drop_no_weight:
         print("The 'Time-Based Validation Split' contributes the most to a realistic performance estimate, as removing it (using a random split) inflates the score significantly.")
    elif perf_drop_no_weight > 0 :
        print("The 'Class Weighting' contributes the most to the overall performance, as its removal caused the largest drop in the F1 score.")
    else:
        print("No single tested component removal resulted in a significant performance drop.")

