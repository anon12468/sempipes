
import pandas as pd
import numpy as np
import os
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score
import gc

# Define constants
TRAIN_DATA_DIR = './input/'
TARGET_COL = 'HIGH_ENROLLMENT'

# Load data
try:
    subject_summary_path = os.path.join(TRAIN_DATA_DIR, 'subject_summary.csv')
    gold_enrollment_path = os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv')
    df_summary = pd.read_csv(subject_summary_path)
    df_gold = pd.read_csv(gold_enrollment_path)
except FileNotFoundError as e:
    print(f"Error loading data: {e}. Please ensure input files are in './input/'.")
    # In a real scenario, we might exit, but per instructions, we'll let it fail later.
    df_summary = pd.DataFrame() # Create empty dataframes to avoid name errors
    df_gold = pd.DataFrame()

if not df_summary.empty and not df_gold.empty:
    # --- Preprocessing & Feature Engineering ---

    # Merge dataframes
    df = pd.merge(df_summary, df_gold, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')
    del df_summary, df_gold
    gc.collect()

    # Drop rows where the target is not available (from left merge)
    df.dropna(subset=[TARGET_COL], inplace=True)

    # Convert target to numeric and optimize types
    df[TARGET_COL] = (df[TARGET_COL] == 'Y').astype('int8')
    df['TERM_CODE'] = df['TERM_CODE'].astype('int32')
    df['ENROLLED_STUDENTS'] = pd.to_numeric(df['ENROLLED_STUDENTS'], errors='coerce').fillna(0).astype('int32')

    # Sort for time-series feature generation
    df.sort_values(by=['SUBJECT_ID_SORT', 'TERM_CODE'], inplace=True)
    df.reset_index(drop=True, inplace=True)

    # --- Feature Engineering ---

    # Lag features
    for lag in range(1, 4):
        df[f'ENROLLED_STUDENTS_lag_{lag}'] = df.groupby('SUBJECT_ID_SORT')['ENROLLED_STUDENTS'].shift(lag)
        df[f'{TARGET_COL}_lag_{lag}'] = df.groupby('SUBJECT_ID_SORT')[TARGET_COL].shift(lag)

    # Rolling window features (with shift to prevent data leakage)
    for window in [2, 3]:
        # Use transform for clean, aligned output and shift to use only past data
        df[f'ENROLLED_STUDENTS_rolling_mean_{window}'] = df.groupby('SUBJECT_ID_SORT')['ENROLLED_STUDENTS'].transform(
            lambda x: x.shift(1).rolling(window, min_periods=1).mean()
        )
        df[f'{TARGET_COL}_rolling_sum_{window}'] = df.groupby('SUBJECT_ID_SORT')[TARGET_COL].transform(
            lambda x: x.shift(1).rolling(window, min_periods=1).sum()
        )

    # Term-based features
    df['TERM_SEASON'] = (df['TERM_CODE'] % 100).astype('int8')

    # Interaction features
    # FillNa before multiplication to avoid propagating NaNs
    df['ENROLLED_LAG1_X_TERM'] = df['ENROLLED_STUDENTS_lag_1'].fillna(0) * df['TERM_SEASON']

    # Fill all remaining NaNs (from lags/rolling)
    df.fillna(-1, inplace=True)

    # --- Time-based Validation Split ---
    unique_terms = sorted(df['TERM_CODE'].unique())
    
    if len(unique_terms) >= 2:
        validation_term = unique_terms[-2]
        train_terms = [t for t in unique_terms if t < validation_term]
        
        train_df = df[df['TERM_CODE'].isin(train_terms)].copy()
        val_df = df[df['TERM_CODE'] == validation_term].copy()
    else:
        # Handle edge case with insufficient terms for a split
        train_df = pd.DataFrame()
        val_df = pd.DataFrame()

    if train_df.empty or val_df.empty:
        print("Train or validation split is empty. Cannot train model.")
        final_validation_score = 0.0
    else:
        # --- Subsampling (on training set only) ---
        neg_class = train_df[train_df[TARGET_COL] == 0]
        pos_class = train_df[train_df[TARGET_COL] == 1]
        
        if not pos_class.empty and len(neg_class) > len(pos_class) * 3:
            neg_class_subsampled = neg_class.sample(n=len(pos_class) * 3, random_state=42)
            train_df = pd.concat([pos_class, neg_class_subsampled]).sample(frac=1, random_state=42).reset_index(drop=True)

        # --- Model Training ---
        id_cols = ['SUBJECT_ID_SORT', 'TERM_CODE']
        features = [col for col in train_df.columns if col not in [TARGET_COL] + id_cols]

        X_train = train_df[features]
        y_train = train_df[TARGET_COL]
        X_val = val_df[features]
        y_val = val_df[TARGET_COL]
        
        # Add some regularization and keep n_jobs for performance
        model = RandomForestClassifier(
            n_estimators=100,
            random_state=42,
            n_jobs=-1,
            class_weight='balanced',
            min_samples_leaf=5,
            max_features='sqrt'
        )
        
        model.fit(X_train, y_train)

        # --- Evaluation ---
        y_pred = model.predict(X_val)
        final_validation_score = f1_score(y_val, y_pred, average='macro')
else:
    # Set score to 0 if data loading failed
    final_validation_score = 0.0

print(f'Final Validation Performance: {final_validation_score}')
