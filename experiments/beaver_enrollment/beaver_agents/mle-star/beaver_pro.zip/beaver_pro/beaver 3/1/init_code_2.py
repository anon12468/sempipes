
import pandas as pd
import numpy as np
import xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score
from sklearn.preprocessing import LabelEncoder
import os

def solve():
    """
    Main function to train an XGBoost model and predict high enrollment.
    """
    # Define data directories
    TRAIN_DATA_DIR = './input/table_splits/train/'

    # --- 1. Load Data ---
    # Load all relevant tables from the training directory
    try:
        gold_enrollment_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv'))
        subject_summary_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'subject_summary.csv'))
        course_summary_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'course_summary.csv'))
        course_offering_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'course_offering_details.csv'))
    except FileNotFoundError as e:
        print(f"Error loading data files: {e}")
        print("Please ensure the data is in the './input/table_splits/train/' directory.")
        return

    # --- 2. Merge DataFrames ---
    # Start with the gold labels which define our prediction keys and target
    df = gold_enrollment_df.copy()

    # Merge with subject summary to get term-specific details
    df = pd.merge(df, subject_summary_df, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')

    # Merge with course summary to get static course details
    df = pd.merge(df, course_summary_df, on='SUBJECT_ID_SORT', how='left')

    # --- 3. Feature Engineering ---
    # Create the binary target variable
    df['target'] = (df['HIGH_ENROLLMENT'] == 'Y').astype(int)

    # Time-based features from TERM_CODE
    df['TERM_CODE'] = df['TERM_CODE'].astype(int)
    df['TERM_YEAR'] = df['TERM_CODE'] // 100
    df['TERM_SEASON'] = df['TERM_CODE'] % 100  # e.g., 10 for Fall, 40 for Spring, 60 for Summer

    # Categorical features from SUBJECT_ID_SORT
    df['DEPARTMENT_CODE'] = df['SUBJECT_ID_SORT'].apply(lambda x: x.split('_')[0])
    df['COURSE_LEVEL'] = df['SUBJECT_ID_SORT'].apply(lambda x: x.split('_')[1][0] + '00' if len(x.split('_')) > 1 and x.split('_')[1] else '000')

    # Aggregate features from course offerings (number of unique instructors)
    instructor_agg = course_offering_df.groupby(['TERM_CODE', 'SUBJECT_ID_SORT'])['INSTRUCTOR_ID'].nunique().reset_index()
    instructor_agg.rename(columns={'INSTRUCTOR_ID': 'UNIQUE_INSTRUCTOR_COUNT'}, inplace=True)
    df = pd.merge(df, instructor_agg, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')
    df['UNIQUE_INSTRUCTOR_COUNT'].fillna(0, inplace=True)

    # Fill NaNs in credit columns with the median
    df['CREDITS_MIN'].fillna(df['CREDITS_MIN'].median(), inplace=True)
    df['CREDITS_MAX'].fillna(df['CREDITS_MAX'].median(), inplace=True)

    # --- Lag Features (Historical Data) ---
    # Sort by subject and term to ensure correct temporal order for lags
    df.sort_values(['SUBJECT_ID_SORT', 'TERM_CODE'], inplace=True)

    # Create lag features for enrollment and offering count from the previous term.
    # shift(1) uses data from the previous row (which is the previous term for that subject).
    df['ENROLLMENT_LAG_1'] = df.groupby('SUBJECT_ID_SORT')['TOTAL_ENROLLMENT'].shift(1)
    df['OFFERING_COUNT_LAG_1'] = df.groupby('SUBJECT_ID_SORT')['OFFERING_COUNT'].shift(1)
    df['ENROLLMENT_ROLLING_AVG_3'] = df.groupby('SUBJECT_ID_SORT')['TOTAL_ENROLLMENT'].shift(1).rolling(window=3, min_periods=1).mean()

    # Fill NaNs created by lag/rolling features with -1.
    # This signals to the model that "no historical data" is a distinct case.
    for col in ['ENROLLMENT_LAG_1', 'OFFERING_COUNT_LAG_1', 'ENROLLMENT_ROLLING_AVG_3']:
        df[col].fillna(-1, inplace=True)

    # --- 4. Prepare for Modeling ---
    # Define feature set
    features = [
        'TERM_YEAR',
        'TERM_SEASON',
        'CREDITS_MIN',
        'CREDITS_MAX',
        'UNIQUE_INSTRUCTOR_COUNT',
        'ENROLLMENT_LAG_1',
        'OFFERING_COUNT_LAG_1',
        'ENROLLMENT_ROLLING_AVG_3',
        'DEPARTMENT_CODE',
        'COURSE_LEVEL',
    ]
    categorical_features = ['DEPARTMENT_CODE', 'COURSE_LEVEL']
    
    # XGBoost requires numerical inputs. Use one-hot encoding for categorical features.
    df = pd.get_dummies(df, columns=categorical_features, dummy_na=False)

    # Update feature list to include new one-hot encoded columns
    final_features = [col for col in df.columns if col.startswith(tuple(features))]


    # --- 5. Train-Validation Split (Time-based) ---
    # Use the latest time period for validation, as specified in the task.
    all_terms = sorted(df['TERM_CODE'].unique())
    validation_term = all_terms[-1] # Hold out the most recent term
    
    train_df = df[df['TERM_CODE'] < validation_term]
    val_df = df[df['TERM_CODE'] == validation_term]
    
    X_train = train_df[final_features]
    y_train = train_df['target']
    X_val = val_df[final_features]
    y_val = val_df['target']
    
    # Ensure columns are in the same order for train and val
    X_val = X_val[X_train.columns]

    print(f"Training on {len(X_train)} samples, validating on {len(X_val)} samples.")
    print(f"Validation term: {validation_term}")

    # --- 6. Model Training ---
    # Initialize the XGBoost Classifier as specified
    xgboost = xgb.XGBClassifier(objective='binary:logistic',
                                eval_metric='logloss',
                                use_label_encoder=False,
                                random_state=42)

    print("Training XGBoost model...")
    xgboost.fit(X_train, y_train)

    # --- 7. Evaluation ---
    # Make predictions on the hold-out validation set
    y_pred = xgboost.predict(X_val)

    # Calculate the macro F1 score
    final_validation_score = f1_score(y_val, y_pred, average='macro')
    
    # Print the final performance metric in the required format
    print(f"Final Validation Performance: {final_validation_score}")

if __name__ == '__main__':
    solve()
