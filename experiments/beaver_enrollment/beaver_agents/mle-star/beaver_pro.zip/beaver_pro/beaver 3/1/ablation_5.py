
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score
from sklearn.preprocessing import LabelEncoder
import os
import warnings
import gc

# Suppress warnings for a cleaner output
warnings.filterwarnings('ignore')

# --- Configuration and Paths ---
TRAIN_DATA_DIR = './input/'

# --- Memory Reduction Helper ---
def reduce_mem_usage(df, verbose=False):
    start_mem = df.memory_usage().sum() / 1024**2
    for col in df.columns:
        col_type = df[col].dtype
        if col_type != object and col_type.name != 'category' and 'datetime' not in col_type.name:
            c_min, c_max = df[col].min(), df[col].max()
            if str(col_type)[:3] == 'int':
                if c_min > np.iinfo(np.int8).min and c_max < np.iinfo(np.int8).max:
                    df[col] = df[col].astype(np.int8)
                elif c_min > np.iinfo(np.int16).min and c_max < np.iinfo(np.int16).max:
                    df[col] = df[col].astype(np.int16)
                elif c_min > np.iinfo(np.int32).min and c_max < np.iinfo(np.int32).max:
                    df[col] = df[col].astype(np.int32)
                elif c_min > np.iinfo(np.int64).min and c_max < np.iinfo(np.int64).max:
                    df[col] = df[col].astype(np.int64)
            else:
                if c_min > np.finfo(np.float32).min and c_max < np.finfo(np.float32).max:
                    df[col] = df[col].astype(np.float32)
                else:
                    df[col] = df[col].astype(np.float64)
        elif col_type == object and len(df[col].unique()) / len(df[col]) < 0.5:
            df[col] = df[col].astype('category')
    return df

# --- Data Loading and Base Preparation ---
subject_summary_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'subject_summary.csv'))
gold_enrollment_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv'))

subject_summary_df = reduce_mem_usage(subject_summary_df)
gold_enrollment_df = reduce_mem_usage(gold_enrollment_df)

df = pd.merge(subject_summary_df, gold_enrollment_df, on=['TERM_CODE', 'SUBJECT_ID_SORT'])
df['HIGH_ENROLLMENT'] = (df['HIGH_ENROLLMENT'] == 'Y').astype(int)
df = df.sort_values('TERM_CODE').reset_index(drop=True)

del subject_summary_df, gold_enrollment_df
gc.collect()

# --- Ablation Study ---
performance_scores = {}

def run_experiment(df_orig, experiment_name, use_missing_indicators=True, min_samples_leaf=1):
    """Function to run a single experiment configuration."""
    df_base = df_orig.copy()

    # Feature Engineering
    excluded_cols = ['TERM_CODE', 'SUBJECT_ID_SORT', 'HIGH_ENROLLMENT']
    features = [col for col in df_base.columns if col not in excluded_cols]
    categorical_features = df_base[features].select_dtypes(include=['object', 'category']).columns

    for col in categorical_features:
        le = LabelEncoder()
        df_base[col] = le.fit_transform(df_base[col].astype(str))

    # --- Ablation Point: Missing Value Indicators ---
    if use_missing_indicators:
        cols_with_missing = [col for col in features if df_base[col].isnull().any()]
        for col in cols_with_missing:
            indicator_col_name = f'{col}_is_missing'
            df_base[indicator_col_name] = df_base[col].isnull().astype(int)
            if indicator_col_name not in features:
                 features.append(indicator_col_name)

    df_base[features] = df_base[features].fillna(0)

    # Time-based Validation Split
    unique_terms = df_base['TERM_CODE'].unique()
    if len(unique_terms) > 4:
        num_validation_terms = max(1, int(len(unique_terms) * 0.2))
        train_terms = unique_terms[:-num_validation_terms]
        validation_terms = unique_terms[-num_validation_terms:]
        train_df = df_base[df_base['TERM_CODE'].isin(train_terms)]
        validation_df = df_base[df_base['TERM_CODE'].isin(validation_terms)]
    else:
        indices = df_base.index.to_numpy()
        train_indices, validation_indices = train_test_split(indices, test_size=0.2, random_state=42, stratify=df_base['HIGH_ENROLLMENT'])
        train_df = df_base.loc[train_indices]
        validation_df = df_base.loc[validation_indices]

    y_train, y_val = train_df['HIGH_ENROLLMENT'], validation_df['HIGH_ENROLLMENT']
    X_train, X_val = train_df[features], validation_df[features]

    # --- Ablation Point: Model Regularization (min_samples_leaf) ---
    model = RandomForestClassifier(n_estimators=100, random_state=42, class_weight='balanced', n_jobs=-1, min_samples_leaf=min_samples_leaf)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_val)
    score = f1_score(y_val, y_pred, average='macro')
    
    print(f"Performance for '{experiment_name}': {score:.4f}")
    return score

# --- Run Experiments ---
# 1. Baseline: Full model with missing value indicators and default leaf size.
baseline_score = run_experiment(df, 'Baseline', use_missing_indicators=True, min_samples_leaf=1)
performance_scores['Baseline'] = baseline_score

# 2. Ablation: Remove Missing Value Indicators.
no_indicators_score = run_experiment(df, 'No Missing Value Indicators', use_missing_indicators=False, min_samples_leaf=1)
performance_scores['Missing Value Indicators'] = baseline_score - no_indicators_score

# 3. Ablation: Increase min_samples_leaf to regularize the model.
regularized_score = run_experiment(df, 'Increased Min Samples Leaf (Regularization)', use_missing_indicators=True, min_samples_leaf=10)
performance_scores['Model Regularization (min_samples_leaf)'] = baseline_score - regularized_score

# --- Conclusion ---
if performance_scores:
    # Find the component whose removal caused the biggest drop in performance
    most_impactful_component = max(performance_scores, key=lambda k: performance_scores[k] if k != 'Baseline' else -1)
    impact_value = performance_scores[most_impactful_component]
    
    print(f"\n--- Ablation Study Conclusion ---")
    print(f"The '{most_impactful_component}' contributes the most to the overall performance.")
    print(f"Removing or altering it caused a performance drop of {impact_value:.4f}.")

