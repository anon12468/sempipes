
import pandas as pd
import numpy as np
import os
import gc
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score

# --- Configuration ---
# Set base directory for input data
# All input data is expected to be in './input/'
BASE_DIR = "./input" 
TRAIN_DATA_DIR = os.path.join(BASE_DIR, "table_splits/train")
GOLD_LABELS_PATH = os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv')

# --- Memory Reduction Helper ---
def reduce_mem_usage(df, verbose=False):
    """
    Iterate through all the columns of a dataframe and modify the data types
    to reduce memory usage.
    """
    start_mem = df.memory_usage().sum() / 1024**2
    if verbose:
        print(f'Memory usage of dataframe is {start_mem:.2f} MB')

    for col in df.columns:
        col_type = df[col].dtype
        if col_type != object and col_type.name != 'category' and 'datetime' not in col_type.name:
            c_min = df[col].min()
            c_max = df[col].max()
            if str(col_type)[:3] == 'int':
                if c_min > np.iinfo(np.int8).min and c_max < np.iinfo(np.int8).max:
                    df[col] = df[col].astype(np.int8)
                elif c_min > np.iinfo(np.int16).min and c_max < np.iinfo(np.int16).max:
                    df[col] = df[col].astype(np.int16)
                elif c_min > np.iinfo(np.int32).min and c_max < np.iinfo(np.int32).max:
                    df[col] = df[col].astype(np.int32)
                elif c_min > np.iinfo(np.int64).min and c_max < np.iinfo(np.int64).max:
                    df[col] = df[col].astype(np.int64)
            else:
                if c_min > np.finfo(np.float32).min and c_max < np.finfo(np.float32).max:
                    df[col] = df[col].astype(np.float32)
                else:
                    df[col] = df[col].astype(np.float64)
        elif col_type == object:
            # Convert object columns that have a low cardinality to category type
            if len(df[col].unique()) / len(df[col]) < 0.5:
                df[col] = df[col].astype('category')
    
    end_mem = df.memory_usage().sum() / 1024**2
    if verbose:
        print(f'Memory usage after optimization is: {end_mem:.2f} MB')
        print(f'Decreased by {100 * (start_mem - end_mem) / start_mem:.1f}%')
    
    return df

# --- Data Loading and Feature Engineering ---
def create_features():
    """
    Loads necessary tables, merges them, and engineers features for the model.
    The function is designed to be memory-efficient.
    """
    print("Loading data tables...")
    try:
        # Per problem description, 'subject_summary' defines the prediction rows. Use it as the base.
        base_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'subject_summary.csv'))
        base_df = reduce_mem_usage(base_df)

        gold_labels = pd.read_csv(GOLD_LABELS_PATH)
        gold_labels = reduce_mem_usage(gold_labels)

        offerings = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'course_offering.csv'))
        offerings = reduce_mem_usage(offerings)

        sections = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'section.csv'))
        sections = reduce_mem_usage(sections)

        instructors = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'instructor_assignment.csv'))
        instructors = reduce_mem_usage(instructors)
        
    except FileNotFoundError as e:
        print(f"Error: A required data file was not found. {e}")
        return None
    
    print("Starting feature engineering...")
    
    # 1. Aggregate section-level information
    section_agg = sections.groupby('SUBJECT_ID_SORT').agg(
        SECTION_COUNT=('SECTION_ID', 'nunique'),
        TOTAL_CAPACITY=('MAX_ENROLLMENT', 'sum'),
        AVG_CAPACITY=('MAX_ENROLLMENT', 'mean')
    ).reset_index()
    section_agg = reduce_mem_usage(section_agg)

    # 2. Aggregate instructor-level information
    instructor_agg = instructors.groupby('SUBJECT_ID_SORT').agg(
        INSTRUCTOR_COUNT=('PERSON_ID', 'nunique')
    ).reset_index()
    instructor_agg = reduce_mem_usage(instructor_agg)

    # 3. Merging features
    df = base_df
    df = pd.merge(df, gold_labels, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')
    df.dropna(subset=['HIGH_ENROLLMENT'], inplace=True) # Keep only labeled data

    df = pd.merge(df, offerings, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')
    df = pd.merge(df, section_agg, on='SUBJECT_ID_SORT', how='left')
    df = pd.merge(df, instructor_agg, on='SUBJECT_ID_SORT', how='left')
    
    # 4. Post-merge feature creation and cleanup
    fill_cols = ['SECTION_COUNT', 'TOTAL_CAPACITY', 'AVG_CAPACITY', 'INSTRUCTOR_COUNT']
    for col in fill_cols:
        if col in df.columns:
            df[col] = df[col].fillna(0)

    df['TERM_YEAR'] = df['TERM_CODE'] // 100
    df['TERM_SEASON'] = df['TERM_CODE'] % 100

    if 'COURSE_NUMBER' in df.columns:
        df['COURSE_NUMBER'] = df['COURSE_NUMBER'].astype(str)
        course_num_part = df['COURSE_NUMBER'].str.extract('(\d+)').astype(float)
        df['COURSE_LEVEL'] = (course_num_part // 100).fillna(0) * 100
    
    df = reduce_mem_usage(df)
    
    # Clean up to free memory
    del base_df, gold_labels, offerings, sections, instructors, section_agg, instructor_agg
    gc.collect()

    return df

# --- Model Training and Evaluation ---
def main():
    """
    Main function to execute the full training and validation pipeline.
    """
    df = create_features()

    if df is None or df.empty:
        print("Feature creation failed or resulted in an empty DataFrame. Cannot proceed.")
        return

    print("Feature creation complete.")
    
    # --- Target Encoding ---
    df['HIGH_ENROLLMENT'] = df['HIGH_ENROLLMENT'].map({'Y': 1, 'N': 0})

    # --- Feature Selection and Preprocessing ---
    features_to_exclude = ['TERM_CODE', 'SUBJECT_ID_SORT', 'HIGH_ENROLLMENT', 'COURSE_NUMBER']
    features = [col for col in df.columns if col not in features_to_exclude]
    
    for col in df.select_dtypes(include=['category', 'object']).columns:
        if col in features:
            df[col] = df[col].cat.codes
            
    df[features] = df[features].fillna(-1)

    # --- Time-based Validation Split ---
    df = df.sort_values('TERM_CODE').reset_index(drop=True)
    unique_terms = sorted(df['TERM_CODE'].unique())
    
    if len(unique_terms) < 2:
        print("Warning: Not enough terms for a time-based split. Using a random 80/20 split.")
        train_df, val_df = train_test_split(df, test_size=0.2, random_state=42, stratify=df['HIGH_ENROLLMENT'])
    else:
        val_term = unique_terms[-1]
        train_df = df[df['TERM_CODE'] < val_term].copy()
        val_df = df[df['TERM_CODE'] == val_term].copy()
        print(f"Using term {val_term} for validation ({len(val_df)} samples).")
    
    # --- Subsampling ---
    subsample_frac = 1.0 # Using 1.0 to include all data, can be lowered if memory is an issue.
    if 0 < subsample_frac < 1.0:
        print(f"Subsampling training data with fraction: {subsample_frac}")
        train_df = train_df.sample(frac=subsample_frac, random_state=42)
    print(f"Training on {len(train_df)} samples.")
    
    if len(train_df) == 0 or len(val_df) == 0:
        print("Training or validation set is empty. Cannot proceed with training.")
        print('Final Validation Performance: 0.0')
        return

    X_train, y_train = train_df[features], train_df['HIGH_ENROLLMENT']
    X_val, y_val = val_df[features], val_df['HIGH_ENROLLMENT']

    # --- Model Training ---
    print("Training LightGBM model...")
    lgb_params = {
        'objective': 'binary',
        'metric': 'binary_logloss',
        'boosting_type': 'gbdt',
        'n_estimators': 1000,
        'learning_rate': 0.05,
        'num_leaves': 31,
        'max_depth': -1,
        'seed': 42,
        'n_jobs': -1,
        'verbose': -1,
        'colsample_bytree': 0.8,
        'subsample': 0.8,
    }

    model = lgb.LGBMClassifier(**lgb_params)
    model.fit(X_train, y_train,
              eval_set=[(X_val, y_val)],
              eval_metric='f1',
              callbacks=[lgb.early_stopping(100, verbose=False)])

    # --- Evaluation ---
    print("Evaluating model...")
    val_preds = model.predict(X_val)
    final_validation_score = f1_score(y_val, val_preds, average='macro')
    
    print(f'Final Validation Performance: {final_validation_score}')

if __name__ == "__main__":
    main()
