
import pandas as pd
import numpy as np
import os
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
from sklearn.preprocessing import LabelEncoder
from catboost import CatBoostClassifier
from sklearn.exceptions import ConvergenceWarning
import warnings

# Suppress warnings for a cleaner output
warnings.filterwarnings("ignore", category=ConvergenceWarning)
warnings.filterwarnings("ignore", category=UserWarning)

# Define file paths
# All input data is stored in the "./input" directory as specified.
TRAIN_DATA_DIR = './input/table_splits/train'
data = pd.DataFrame()

# --- 1. Load Data ---
# Load only the available datasets. 'course_summary.csv' is omitted as it does not exist.
try:
    subject_summary = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'subject_summary.csv'), low_memory=False)
    instructor_summary = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'instructor_summary.csv'), low_memory=False)
    gold_enrollment = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv'), low_memory=False)
    
    # --- 2. Merge Data ---
    # Merge the loaded summaries with the gold labels.
    # Start with subject_summary and merge other available data onto it.
    data = pd.merge(subject_summary, instructor_summary, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')
    data = pd.merge(data, gold_enrollment, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')

except FileNotFoundError as e:
    print(f"Error loading data: {e}. Make sure the input files are in the correct directory.")
    # Do not exit, allow the program to fail downstream if data is empty

if not data.empty:
    # --- 3. Feature Engineering ---
    # Convert TERM_CODE to a numerical feature representing time
    data['TERM_SORT'] = data['TERM_CODE'].astype(int)

    # One-hot encode categorical features with high cardinality
    # For simplicity and to avoid excessive dimensions, we'll focus on a few key ones.
    # In a more complex scenario, target encoding or other methods would be better.
    categorical_cols = [
        'INSTRUCTOR_PRIMARY_DEPT_CODE',
        'SUBJECT_ID_SORT'
    ]
    for col in categorical_cols:
        data[col] = data[col].astype('category')

    # Fill missing numerical values
    # Identify numeric columns automatically, excluding identifiers and the target
    numeric_cols = data.select_dtypes(include=np.number).columns.tolist()
    numeric_cols.remove('TERM_CODE')
    numeric_cols.remove('TERM_SORT')

    for col in numeric_cols:
        data[col] = data[col].fillna(data[col].median())

    # Create interaction features or polynomial features if needed
    # Example: interaction between offerings and instructor count
    data['OFFERINGS_X_INSTRUCTORS'] = data['UNIQUE_INSTRUCTOR_COUNT'] * data['OFFERING_COUNT']


    # --- 4. Prepare Data for Modeling ---
    # Drop rows where the target is missing (if any, from the left merge)
    data.dropna(subset=['HIGH_ENROLLMENT'], inplace=True)

    # Encode the target variable 'HIGH_ENROLLMENT'
    le = LabelEncoder()
    data['HIGH_ENROLLMENT'] = le.fit_transform(data['HIGH_ENROLLMENT'])

    # Define features (X) and target (y)
    features = data.select_dtypes(include=np.number).columns.tolist()
    features.remove('HIGH_ENROLLMENT')
    if 'TERM_CODE' in features:
        features.remove('TERM_CODE') # Use TERM_SORT instead for temporal ordering

    # Categorical features need to be handled by models that support them (like CatBoost)
    cat_features_indices = [data.columns.get_loc(c) for c in categorical_cols if c in data.columns]


    # --- 5. Time-Based Validation Split ---
    # Sort data by term to ensure a proper time-based split
    data = data.sort_values('TERM_SORT').reset_index(drop=True)

    # Use the last 20% of terms for validation
    unique_terms = sorted(data['TERM_SORT'].unique())
    split_point = int(len(unique_terms) * 0.8)
    train_terms = unique_terms[:split_point]
    validation_terms = unique_terms[split_point:]

    train_df = data[data['TERM_SORT'].isin(train_terms)]
    validation_df = data[data['TERM_SORT'].isin(validation_terms)]

    X_train = train_df.drop(columns=['HIGH_ENROLLMENT', 'TERM_CODE'])
    y_train = train_df['HIGH_ENROLLMENT']
    X_val = validation_df.drop(columns=['HIGH_ENROLLMENT', 'TERM_CODE'])
    y_val = validation_df['HIGH_ENROLLMENT']

    # For models that don't handle categoricals directly, we use only numeric features
    X_train_numeric = X_train[features]
    X_val_numeric = X_val[features]


    # --- 6. Train Ensemble Model ---
    # We build an ensemble (stacking) of RandomForest and CatBoost, with a Logistic Regression meta-learner.

    # Model 1: RandomForest (works with numeric features)
    rf_model = RandomForestClassifier(
        n_estimators=200,
        random_state=42,
        class_weight='balanced',
        n_jobs=-1,
        max_depth=10,
        min_samples_leaf=5
    )
    rf_model.fit(X_train_numeric, y_train)
    val_preds_rf = rf_model.predict_proba(X_val_numeric)[:, 1]

    # Model 2: CatBoost (handles categorical features natively)
    cb_model = CatBoostClassifier(
        iterations=500,
        random_seed=42,
        verbose=0,
        auto_class_weights='Balanced',
        cat_features=categorical_cols # Pass column names
    )
    cb_model.fit(X_train, y_train, cat_features=categorical_cols)
    val_preds_cb = cb_model.predict_proba(X_val)[:, 1]

    # Create new features for the meta-learner from base model predictions
    stacked_features_val = np.column_stack((val_preds_rf, val_preds_cb))

    # Meta-Learner: Logistic Regression
    # To train the meta-learner, we need out-of-fold predictions on the training set.
    X_train_base, X_meta_train_base, y_train_base, y_meta_train_base = train_test_split(
        X_train, y_train, test_size=0.5, random_state=42, stratify=y_train
    )

    # Train base models on the first half
    rf_model_base = RandomForestClassifier(n_estimators=100, random_state=42, class_weight='balanced', n_jobs=-1).fit(X_train_base[features], y_train_base)
    cb_model_base = CatBoostClassifier(iterations=200, random_seed=42, verbose=0, auto_class_weights='Balanced').fit(X_train_base, y_train_base, cat_features=categorical_cols)

    # Predict on the second half to create features for the meta-learner
    meta_preds_rf = rf_model_base.predict_proba(X_meta_train_base[features])[:, 1]
    meta_preds_cb = cb_model_base.predict_proba(X_meta_train_base)[:, 1]
    stacked_features_meta_train = np.column_stack((meta_preds_rf, meta_preds_cb))

    # Train the meta-learner
    meta_model = LogisticRegression(random_state=42)
    meta_model.fit(stacked_features_meta_train, y_meta_train_base)


    # --- 7. Evaluate on Validation Set ---
    # Final prediction using the trained ensemble
    final_predictions_probs = meta_model.predict_proba(stacked_features_val)[:, 1]
    final_predictions = (final_predictions_probs > 0.5).astype(int)

    # Calculate Macro F1 Score
    final_validation_score = f1_score(y_val, final_predictions, average='macro')

    # Print the final performance metric in the specified format
    print(f'Final Validation Performance: {final_validation_score}')
else:
    # If data loading failed, print a zero score to indicate failure.
    print(f'Final Validation Performance: 0.0')
