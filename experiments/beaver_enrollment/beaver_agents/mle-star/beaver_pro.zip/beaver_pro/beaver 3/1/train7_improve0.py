An error occurred in the previous step. I will now try to fix it.
I have tried to fix the error by referencing the following error message:
The script `train7_improve0.py` failed with a `FileNotFoundError`. It attempted to load data from the incorrect path `./input/table_splits/train/`, while the data is actually located in the `./input/` directory.


import os
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score
from sklearn.preprocessing import LabelEncoder

# --- Configuration ---
# Correct the data directory path as per the error analysis.
TRAIN_DATA_DIR = './input/'
TEST_DATA_DIR = None  # No test data available during training

# Define the file names for the tables
COURSE_TABLE = 'course_data.csv'
INSTRUCTOR_TABLE = 'instructor_data.csv'
SUBJECT_SUMMARY_TABLE = 'subject_summary.csv'
GOLD_LABELS_TABLE = 'gold_enrollment_train.csv'

# Define a subsampling fraction to speed up development if needed
SUBSAMPLE_FRACTION = 1.0

# --- Data Loading ---

def load_table(data_dir, table_name):
    """Loads a CSV table from the specified directory."""
    path = os.path.join(data_dir, table_name)
    if not os.path.exists(path):
        raise FileNotFoundError(f"File not found at {path}. Ensure the data is in the correct directory.")
    return pd.read_csv(path)

def load_all_data(data_dir):
    """Loads all required tables from the data directory."""
    print(f"Loading data from {data_dir}...")
    try:
        course = load_table(data_dir, COURSE_TABLE)
        instructor = load_table(data_dir, INSTRUCTOR_TABLE)
        subject_summary = load_table(data_dir, SUBJECT_SUMMARY_TABLE)
        gold_labels = load_table(data_dir, GOLD_LABELS_TABLE)
        print("Data loaded successfully.")
        return course, instructor, subject_summary, gold_labels
    except FileNotFoundError as e:
        print(f"Error loading data: {e}")
        raise

# --- Main Execution Logic ---

if __name__ == "__main__":
    # Load data
    course, instructor, subject_summary, gold_labels = load_all_data(TRAIN_DATA_DIR)

    # Subsampling for faster iteration during development
    if SUBSAMPLE_FRACTION < 1.0:
        print(f"Subsampling data to {SUBSAMPLE_FRACTION * 100}%")
        subject_summary = subject_summary.sample(frac=SUBSAMPLE_FRACTION, random_state=42)
        keys = ['TERM_CODE', 'SUBJECT_ID_SORT']
        keys_to_keep = subject_summary[keys].drop_duplicates()
        course = course.merge(keys_to_keep, on=keys, how='inner')
        instructor = instructor.merge(keys_to_keep, on=keys, how='inner')
        gold_labels = gold_labels.merge(keys_to_keep, on=keys, how='inner')

    # --- Feature Engineering ---
    print("Starting feature engineering...")

    # --- 1. Create Historical Lag Features to Prevent Data Leakage ---
    # Use the full (pre-subsample) summary table for a complete historical lookup
    full_summary = load_table(TRAIN_DATA_DIR, SUBJECT_SUMMARY_TABLE)
    historical_lookup = full_summary[['TERM_CODE', 'SUBJECT_ID_SORT', 'TOTAL_ENROLLED', 'TOTAL_CAPACITY']].copy()
    historical_lookup.rename(columns={
        'TOTAL_ENROLLED': 'prev_year_enrollment',
        'TOTAL_CAPACITY': 'prev_year_capacity'
    }, inplace=True)

    # The main dataframe for our features will be the (potentially subsampled) subject_summary
    features_df = subject_summary.copy()
    # Calculate the term code for the previous year to join on
    features_df['prev_year_term_code'] = (features_df['TERM_CODE'].astype(int) - 100).astype(str)

    # Merge historical data
    features_df = pd.merge(
        features_df,
        historical_lookup,
        left_on=['prev_year_term_code', 'SUBJECT_ID_SORT'],
        right_on=['TERM_CODE', 'SUBJECT_ID_SORT'],
        how='left'
    )
    # Clean up columns after merge, keeping the original TERM_CODE
    if 'TERM_CODE_y' in features_df.columns:
        features_df.drop(columns=['TERM_CODE_y'], inplace=True)
    if 'TERM_CODE_x' in features_df.columns:
        features_df.rename(columns={'TERM_CODE_x': 'TERM_CODE'}, inplace=True)
    
    # Impute missing historical data (for new courses) with 0
    features_df['prev_year_enrollment'].fillna(0, inplace=True)
    features_df['prev_year_capacity'].fillna(0, inplace=True)
    print("Historical features created.")

    # --- 2. Create Instructor and Course Features ---
    # Instructor features: seniority
    instructor['TERM_CODE_INT'] = instructor['TERM_CODE'].astype(int)
    min_term_by_instructor = instructor.groupby('INSTRUCTOR_ID')['TERM_CODE_INT'].min().reset_index().rename(columns={'TERM_CODE_INT': 'first_term'})
    instructor = pd.merge(instructor, min_term_by_instructor, on='INSTRUCTOR_ID', how='left')
    instructor['instructor_seniority_years'] = (instructor['TERM_CODE_INT'] - instructor['first_term']) // 100
    instructor_features = instructor.groupby(['TERM_CODE', 'SUBJECT_ID_SORT']).agg(
        avg_instructor_seniority=('instructor_seniority_years', 'mean'),
        num_instructors=('INSTRUCTOR_ID', 'nunique')
    ).reset_index()

    # Course features: level (FIXED)
    # Original code created duplicate rows by merging on SUBJECT_ID_SORT alone.
    # The fix is to aggregate course level to the prediction grain (TERM_CODE, SUBJECT_ID_SORT).
    course['COURSE_LEVEL'] = (course['CATALOG_NBR'] // 100) * 100
    course_level_features = course.groupby(['TERM_CODE', 'SUBJECT_ID_SORT']).agg(
        avg_course_level=('COURSE_LEVEL', 'mean')
    ).reset_index()

    # --- 3. Merge all features together ---
    features_df = pd.merge(features_df, instructor_features, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')
    features_df = pd.merge(features_df, course_level_features, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')

    # Impute missing values from merges
    features_df['avg_instructor_seniority'].fillna(0, inplace=True)
    features_df['num_instructors'].fillna(0, inplace=True)
    # Impute the new avg_course_level feature, using the global mean for offerings without course data.
    features_df['avg_course_level'].fillna(features_df['avg_course_level'].mean(), inplace=True)


    # --- 4. Final Feature Transformations ---
    features_df['term_season'] = features_df['TERM_CODE'].str[-2:].astype(int)
    le = LabelEncoder()
    features_df['subject_encoded'] = le.fit_transform(features_df['SUBJECT_ID_SORT'])

    print("Feature engineering complete.")

    # Merge features with labels
    data = pd.merge(features_df, gold_labels, on=['TERM_CODE', 'SUBJECT_ID_SORT'])
    data['HIGH_ENROLLMENT'] = data['HIGH_ENROLLMENT'].apply(lambda x: 1 if x == 'Y' else 0)

    # Temporal split for validation
    data['TERM_CODE_INT'] = data['TERM_CODE'].astype(int)
    split_term = data['TERM_CODE_INT'].quantile(0.8, interpolation='nearest')

    train_df = data[data['TERM_CODE_INT'] < split_term]
    val_df = data[data['TERM_CODE_INT'] >= split_term]

    if len(train_df) == 0 or len(val_df) == 0:
        print("Error: Temporal split failed. Falling back to random split.")
        X = data.drop(columns=['HIGH_ENROLLMENT', 'SUBJECT_ID_SORT'])
        y = data['HIGH_ENROLLMENT']
        X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    else:
        print(f"Train/validation split on term: {split_term}")
        print(f"Training set size: {len(train_df)}, Validation set size: {len(val_df)}")
        X_train = train_df.drop(columns=['HIGH_ENROLLMENT', 'SUBJECT_ID_SORT', 'TERM_CODE_INT'])
        y_train = train_df['HIGH_ENROLLMENT']
        X_val = val_df.drop(columns=['HIGH_ENROLLMENT', 'SUBJECT_ID_SORT', 'TERM_CODE_INT'])
        y_val = val_df['HIGH_ENROLLMENT']

    # Define feature set, EXCLUDING leaky features and using fixed course level feature
    feature_cols = [
        'prev_year_enrollment', 'prev_year_capacity',
        'avg_instructor_seniority', 'num_instructors', 'avg_course_level',
        'term_season', 'subject_encoded'
    ]
    
    # Align columns to ensure consistency
    X_train = X_train[feature_cols]
    X_val = X_val[feature_cols]

    # Model Training
    print("Training RandomForestClassifier...")
    model = RandomForestClassifier(n_estimators=100, random_state=42, class_weight='balanced')
    model.fit(X_train, y_train)
    print("Training complete.")

    # Validation
    print("Evaluating on validation set...")
    y_pred = model.predict(X_val)
    final_validation_score = f1_score(y_val, y_pred, average='macro')

    # Print the final performance metric in the required format
    print(f'Final Validation Performance: {final_validation_score}')

    # Optional: Display feature importances
    try:
        importances = model.feature_importances_
        feature_importance_df = pd.DataFrame({'feature': feature_cols, 'importance': importances})
        feature_importance_df = feature_importance_df.sort_values(by='importance', ascending=False)
        print("\nTop 10 Feature Importances:")
        print(feature_importance_df.head(10))
    except Exception as e:
        print(f"Could not display feature importances: {e}")
