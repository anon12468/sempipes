
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score
from sklearn.preprocessing import LabelEncoder
import os
import warnings
import gc

# Suppress warnings for a cleaner output
warnings.filterwarnings('ignore')

# --- Configuration and Paths ---
TRAIN_DATA_DIR = './input/'

# --- Memory Reduction Helper ---
def reduce_mem_usage(df, verbose=False):
    """ iterate through all the columns of a dataframe and modify the data type
        to reduce memory usage.        
    """
    start_mem = df.memory_usage().sum() / 1024**2
    if verbose:
        print('Memory usage of dataframe is {:.2f} MB'.format(start_mem))
    
    for col in df.columns:
        col_type = df[col].dtype
        
        if col_type != object and col_type.name != 'category' and 'datetime' not in col_type.name:
            c_min = df[col].min()
            c_max = df[col].max()
            if str(col_type)[:3] == 'int':
                if c_min > np.iinfo(np.int8).min and c_max < np.iinfo(np.int8).max:
                    df[col] = df[col].astype(np.int8)
                elif c_min > np.iinfo(np.int16).min and c_max < np.iinfo(np.int16).max:
                    df[col] = df[col].astype(np.int16)
                elif c_min > np.iinfo(np.int32).min and c_max < np.iinfo(np.int32).max:
                    df[col] = df[col].astype(np.int32)
                elif c_min > np.iinfo(np.int64).min and c_max < np.iinfo(np.int64).max:
                    df[col] = df[col].astype(np.int64)  
            else:
                if c_min > np.finfo(np.float32).min and c_max < np.finfo(np.float32).max:
                    df[col] = df[col].astype(np.float32)
                else:
                    df[col] = df[col].astype(np.float64)
        elif col_type == object:
            # Convert object columns with low cardinality to 'category'
            if len(df[col].unique()) / len(df[col]) < 0.5:
                df[col] = df[col].astype('category')

    end_mem = df.memory_usage().sum() / 1024**2
    if verbose:
        print('Memory usage after optimization is: {:.2f} MB'.format(end_mem))
        print('Decreased by {:.1f}%'.format(100 * (start_mem - end_mem) / start_mem))
    
    return df

# --- Data Loading and Base Preparation ---
subject_summary_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'subject_summary.csv'))
gold_enrollment_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv'))

subject_summary_df = reduce_mem_usage(subject_summary_df)
gold_enrollment_df = reduce_mem_usage(gold_enrollment_df)

df = pd.merge(subject_summary_df, gold_enrollment_df, on=['TERM_CODE', 'SUBJECT_ID_SORT'])
df['HIGH_ENROLLMENT'] = (df['HIGH_ENROLLMENT'] == 'Y').astype(int)
df = df.sort_values('TERM_CODE').reset_index(drop=True)

del subject_summary_df, gold_enrollment_df
gc.collect()

# --- Ablation Study ---
ablation_results = {}
baseline_score = 0.0
final_validation_score = 0.0

# Define experiments
experiments = {
    "Baseline (One-Hot Encoding, Gini)": {
        "encoding": "one-hot",
        "criterion": "gini"
    },
    "Ablation: Use Label Encoding": {
        "encoding": "label",
        "criterion": "gini"
    },
    "Ablation: Use 'entropy' criterion": {
        "encoding": "one-hot",
        "criterion": "entropy"
    }
}

for name, config in experiments.items():
    print(f"--- Running Experiment: {name} ---")
    
    # --- Feature Engineering ---
    df_exp = df.copy()
    
    excluded_cols = ['TERM_CODE', 'SUBJECT_ID_SORT', 'HIGH_ENROLLMENT']
    features = [col for col in df_exp.columns if col not in excluded_cols]
    categorical_features = df_exp[features].select_dtypes(include=['object', 'category']).columns

    if config["encoding"] == "one-hot":
        # TIMEOUT FIX: Use hybrid encoding to prevent feature explosion from high-cardinality features.
        CARDINALITY_LIMIT = 50 
        ohe_cols = [col for col in categorical_features if df_exp[col].nunique() <= CARDINALITY_LIMIT]
        label_encode_cols = [col for col in categorical_features if df_exp[col].nunique() > CARDINALITY_LIMIT]

        if label_encode_cols:
            print(f"Applying Label Encoding to high-cardinality features: {label_encode_cols}")
            for col in label_encode_cols:
                le = LabelEncoder()
                df_exp[col] = le.fit_transform(df_exp[col].astype(str))
        
        if ohe_cols:
            print(f"Applying One-Hot Encoding to low-cardinality features: {ohe_cols}")
            df_exp = pd.get_dummies(df_exp, columns=ohe_cols, dummy_na=False)
        
        # Update features list after encoding
        features = [col for col in df_exp.columns if col not in excluded_cols]

    elif config["encoding"] == "label":
        for col in categorical_features:
            le = LabelEncoder()
            df_exp[col] = le.fit_transform(df_exp[col].astype(str))
            
    # Handle missing values with a simple fill-zero strategy.
    # This needs to be done on the full feature set after any potential encoding changes.
    current_features = [col for col in df_exp.columns if col not in excluded_cols]
    df_exp[current_features] = df_exp[current_features].fillna(0)

    # --- Time-based Validation Split ---
    unique_terms = df['TERM_CODE'].unique()
    num_validation_terms = max(1, int(len(unique_terms) * 0.2))
    train_terms = unique_terms[:-num_validation_terms]
    validation_terms = unique_terms[-num_validation_terms:]

    train_df = df_exp[df_exp['TERM_CODE'].isin(train_terms)]
    validation_df = df_exp[df_exp['TERM_CODE'].isin(validation_terms)]

    y_train = train_df['HIGH_ENROLLMENT']
    y_val = validation_df['HIGH_ENROLLMENT']

    # Must re-calculate features for training set to avoid data leakage from future columns
    train_features = [col for col in train_df.columns if col not in excluded_cols]
    X_train = train_df[train_features]
    # Ensure validation set has the same columns as the training set
    X_val = validation_df[train_features]

    # --- Model Training and Evaluation ---
    model = RandomForestClassifier(
        n_estimators=100, 
        random_state=42, 
        class_weight='balanced', 
        n_jobs=-1,
        criterion=config["criterion"]
    )
    model.fit(X_train, y_train)

    y_pred = model.predict(X_val)
    score = f1_score(y_val, y_pred, average='macro')
    ablation_results[name] = score
    
    if name.startswith("Baseline"):
        baseline_score = score

    print(f"Performance (Macro F1): {score:.4f}\n")
    del df_exp, X_train, X_val, y_train, y_val, train_df, validation_df
    gc.collect()

# --- Analysis and Conclusion ---
print("\n--- Ablation Study Summary ---")
performance_drops = {}
for name, score in ablation_results.items():
    print(f"{name}: {score:.4f}")
    if not name.startswith("Baseline"):
        drop = baseline_score - score
        performance_drops[name.replace("Ablation: ", "")] = drop

# Find the component that caused the biggest drop in performance
if performance_drops:
    most_impactful_component = max(performance_drops, key=performance_drops.get)
    max_drop = performance_drops[most_impactful_component]

    if max_drop > 0:
        print(f"\nConclusion: The '{most_impactful_component}' contributes the most to the overall performance, with a performance drop of {max_drop:.4f} upon modification.")
    else:
        print("\nConclusion: No tested component modification resulted in a significant performance drop. The baseline configuration is robust.")
else:
    print("\nConclusion: Not enough experiments to draw a conclusion.")

final_validation_score = baseline_score
print(f'Final Validation Performance: {final_validation_score}')
