
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score
from sklearn.preprocessing import LabelEncoder
import os
import warnings

# Suppress warnings for a cleaner output
warnings.filterwarnings('ignore')

# Define the correct path to the training data directory.
# The original script failed with a FileNotFoundError.
# The path is corrected to './input/' as specified in the problem description.
TRAIN_DATA_DIR = './input/'

try:
    # --- Data Loading ---
    # Load the primary data file and the gold labels.
    subject_summary_path = os.path.join(TRAIN_DATA_DIR, 'subject_summary.csv')
    gold_enrollment_path = os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv')
    
    subject_summary_df = pd.read_csv(subject_summary_path)
    gold_enrollment_df = pd.read_csv(gold_enrollment_path)

    # Merge the datasets to combine features and labels.
    df = pd.merge(subject_summary_df, gold_enrollment_df, on=['TERM_CODE', 'SUBJECT_ID_SORT'])

    # --- Preprocessing and Feature Engineering ---

    # Convert the target variable 'HIGH_ENROLLMENT' from 'Y'/'N' to binary 1/0.
    df['HIGH_ENROLLMENT'] = (df['HIGH_ENROLLMENT'] == 'Y').astype(int)

    # Sort data by term to prepare for a time-based validation split.
    df = df.sort_values('TERM_CODE').reset_index(drop=True)

    # Automatically identify features for the model.
    # We exclude identifier columns and the target variable itself.
    excluded_cols = ['TERM_CODE', 'SUBJECT_ID_SORT', 'HIGH_ENROLLMENT']
    features = [col for col in df.columns if col not in excluded_cols]
    
    categorical_features = df[features].select_dtypes(include=['object']).columns

    # Apply Label Encoding to categorical features.
    for col in categorical_features:
        le = LabelEncoder()
        df[col] = le.fit_transform(df[col].astype(str))

    # Handle missing values with a simple fill-zero strategy.
    df[features] = df[features].fillna(0)

    # --- Time-based Validation Split ---

    # The evaluation metric is based on a time-based validation slice.
    # We will use the latest 20% of terms for validation.
    unique_terms = df['TERM_CODE'].unique()
    
    if len(unique_terms) > 4: # Ensure there are enough terms for a meaningful split
        num_validation_terms = max(1, int(len(unique_terms) * 0.2))
        train_terms = unique_terms[:-num_validation_terms]
        validation_terms = unique_terms[-num_validation_terms:]

        train_df = df[df['TERM_CODE'].isin(train_terms)]
        validation_df = df[df['TERM_CODE'].isin(validation_terms)]
    else:
        # Fallback to a random split if there are too few terms.
        train_df, validation_df = train_test_split(df, test_size=0.2, random_state=42, stratify=df['HIGH_ENROLLMENT'])

    X_train = train_df[features]
    y_train = train_df['HIGH_ENROLLMENT']
    X_val = validation_df[features]
    y_val = validation_df['HIGH_ENROLLMENT']

    # --- Model Training ---
    
    final_validation_score = 0.0
    if not X_train.empty and not y_train.empty:
        # We use a RandomForestClassifier, which is effective for tabular data.
        # 'class_weight="balanced"' helps address potential class imbalance.
        model = RandomForestClassifier(n_estimators=100, random_state=42, class_weight='balanced', n_jobs=-1)
        model.fit(X_train, y_train)

        # --- Evaluation ---
        if not X_val.empty:
            # Make predictions on the validation set.
            y_pred = model.predict(X_val)

            # Calculate the macro F1 score, the specified development metric.
            final_validation_score = f1_score(y_val, y_pred, average='macro')

    # Print the final performance metric in the required format.
    print(f'Final Validation Performance: {final_validation_score}')

except FileNotFoundError as e:
    print(f"Error: A required data file was not found. Please check the contents of '{TRAIN_DATA_DIR}'.")
    print(f"Details: {e}")
except Exception as e:
    print(f"An unexpected error occurred during script execution: {e}")
