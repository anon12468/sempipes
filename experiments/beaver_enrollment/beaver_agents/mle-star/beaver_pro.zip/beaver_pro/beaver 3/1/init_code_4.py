
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score
import os

def solve():
    """
    Main function to train a Random Forest model and predict high enrollment.
    """
    # Define data directories
    TRAIN_DATA_DIR = './input/table_splits/train/'

    # --- 1. Load Data ---
    # Load all relevant tables from the training directory
    try:
        gold_enrollment_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv'))
        subject_summary_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'subject_summary.csv'))
        course_summary_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'course_summary.csv'))
        course_offering_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'course_offering_details.csv'))
    except FileNotFoundError as e:
        print(f"Error loading data files: {e}")
        print("Please ensure the data is in the './input/table_splits/train/' directory.")
        return

    # --- 2. Merge DataFrames ---
    # Start with the gold labels which define our prediction keys and target
    df = gold_enrollment_df.copy()

    # Merge with subject summary to get term-specific details
    df = pd.merge(df, subject_summary_df, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')

    # Merge with course summary to get static course details
    df = pd.merge(df, course_summary_df, on='SUBJECT_ID_SORT', how='left')

    # --- 3. Feature Engineering ---
    # Create the binary target variable
    df['target'] = (df['HIGH_ENROLLMENT'] == 'Y').astype(int)

    # Time-based features from TERM_CODE
    df['TERM_CODE'] = df['TERM_CODE'].astype(int)
    df['TERM_YEAR'] = df['TERM_CODE'] // 100
    df['TERM_SEASON'] = df['TERM_CODE'] % 100  # e.g., 10 for Fall, 40 for Spring, 60 for Summer

    # Categorical features from SUBJECT_ID_SORT
    df['DEPARTMENT_CODE'] = df['SUBJECT_ID_SORT'].apply(lambda x: x.split('_')[0])
    df['COURSE_LEVEL'] = df['SUBJECT_ID_SORT'].apply(lambda x: x.split('_')[1][0] + '00' if len(x.split('_')) > 1 and x.split('_')[1] else '000')

    # Aggregate features from course offerings (number of unique instructors)
    instructor_agg = course_offering_df.groupby(['TERM_CODE', 'SUBJECT_ID_SORT'])['INSTRUCTOR_ID'].nunique().reset_index()
    instructor_agg.rename(columns={'INSTRUCTOR_ID': 'UNIQUE_INSTRUCTOR_COUNT'}, inplace=True)
    df = pd.merge(df, instructor_agg, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')
    
    # --- 4. Handle Missing Values (Part 1 - before creating lags) ---
    df['UNIQUE_INSTRUCTOR_COUNT'].fillna(0, inplace=True)
    df['CREDITS_MIN'].fillna(df['CREDITS_MIN'].median(), inplace=True)
    df['CREDITS_MAX'].fillna(df['CREDITS_MAX'].median(), inplace=True)
    for col in ['TOTAL_ENROLLMENT', 'OFFERING_COUNT']:
        df[col].fillna(0, inplace=True)
    
    # --- 5. Lag Features (Historical Data) ---
    # Sort by subject and term to ensure correct temporal order for lags
    df.sort_values(['SUBJECT_ID_SORT', 'TERM_CODE'], inplace=True)

    # Create lag features for enrollment and offering count from the previous term.
    df['ENROLLMENT_LAG_1'] = df.groupby('SUBJECT_ID_SORT')['TOTAL_ENROLLMENT'].shift(1)
    df['OFFERING_COUNT_LAG_1'] = df.groupby('SUBJECT_ID_SORT')['OFFERING_COUNT'].shift(1)
    df['ENROLLMENT_ROLLING_AVG_3'] = df.groupby('SUBJECT_ID_SORT')['TOTAL_ENROLLMENT'].shift(1).rolling(window=3, min_periods=1).mean()

    # --- 6. Handle Missing Values (Part 2 - after creating lags) ---
    for col in ['ENROLLMENT_LAG_1', 'OFFERING_COUNT_LAG_1', 'ENROLLMENT_ROLLING_AVG_3']:
        df[col].fillna(-1, inplace=True)

    # Fill categorical NaNs with a 'missing' placeholder string
    df['DEPARTMENT_CODE'].fillna('missing', inplace=True)
    df['COURSE_LEVEL'].fillna('missing', inplace=True)


    # --- 7. Prepare for Modeling (Preprocessing) ---
    # Define feature set
    numerical_features = [
        'TERM_YEAR',
        'TERM_SEASON',
        'CREDITS_MIN',
        'CREDITS_MAX',
        'UNIQUE_INSTRUCTOR_COUNT',
        'ENROLLMENT_LAG_1',
        'OFFERING_COUNT_LAG_1',
        'ENROLLMENT_ROLLING_AVG_3',
    ]
    
    categorical_features = ['DEPARTMENT_CODE', 'COURSE_LEVEL']

    # One-hot encode categorical features for Random Forest
    df = pd.get_dummies(df, columns=categorical_features, dummy_na=False)

    # Update feature list with one-hot encoded columns
    one_hot_cols = [col for col in df.columns if any(cat_feat in col for cat_feat in categorical_features)]
    features = numerical_features + one_hot_cols

    # --- 8. Train-Validation Split (Time-based) ---
    # Use the latest time period for validation, as specified in the task.
    all_terms = sorted(df['TERM_CODE'].unique())
    validation_term = all_terms[-1] # Hold out the most recent term
    
    train_df = df[df['TERM_CODE'] < validation_term].copy()
    val_df = df[df['TERM_CODE'] == validation_term].copy()
    
    X_train = train_df[features]
    y_train = train_df['target']
    X_val = val_df[features]
    y_val = val_df['target']
    
    # Align columns between train and validation sets to handle cases where a
    # category might be present in one set but not the other.
    X_train, X_val = X_train.align(X_val, join='left', axis=1, fill_value=0)

    print(f"Training on {len(X_train)} samples, validating on {len(X_val)} samples.")
    print(f"Validation term: {validation_term}")

    # --- 9. Model Training ---
    # Initialize the RandomForestClassifier as specified
    rf_model = RandomForestClassifier(n_estimators=100,
                                      random_state=42,
                                      oob_score=False, # Using a dedicated validation set
                                      n_jobs=-1) # Use all available cores

    print("Training Random Forest model...")
    rf_model.fit(X_train, y_train)

    # --- 10. Evaluation ---
    # Make predictions on the hold-out validation set
    y_pred = rf_model.predict(X_val)

    # Calculate the macro F1 score, which is a reasonable metric for this classification task
    final_validation_score = f1_score(y_val, y_pred, average='macro')
    
    # Print the final performance metric in the required format
    print(f'Final Validation Performance: {final_validation_score}')

if __name__ == '__main__':
    solve()
