
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score
from sklearn.preprocessing import LabelEncoder
import os
import warnings
import gc

# Suppress warnings for a cleaner output
warnings.filterwarnings('ignore')

# --- Configuration and Paths ---
# Define the correct path to the training data directory.
TRAIN_DATA_DIR = './input/'

# --- Memory Reduction Helper (from reference solution) ---
def reduce_mem_usage(df, verbose=False):
    """
    Iterate through all the columns of a dataframe and modify the data types
    to reduce memory usage.
    """
    start_mem = df.memory_usage().sum() / 1024**2
    if verbose:
        print(f'Memory usage of dataframe is {start_mem:.2f} MB')

    for col in df.columns:
        col_type = df[col].dtype
        if col_type != object and col_type.name != 'category' and 'datetime' not in col_type.name:
            c_min = df[col].min()
            c_max = df[col].max()
            if str(col_type)[:3] == 'int':
                if c_min > np.iinfo(np.int8).min and c_max < np.iinfo(np.int8).max:
                    df[col] = df[col].astype(np.int8)
                elif c_min > np.iinfo(np.int16).min and c_max < np.iinfo(np.int16).max:
                    df[col] = df[col].astype(np.int16)
                elif c_min > np.iinfo(np.int32).min and c_max < np.iinfo(np.int32).max:
                    df[col] = df[col].astype(np.int32)
                elif c_min > np.iinfo(np.int64).min and c_max < np.iinfo(np.int64).max:
                    df[col] = df[col].astype(np.int64)
            else:
                if c_min > np.finfo(np.float32).min and c_max < np.finfo(np.float32).max:
                    df[col] = df[col].astype(np.float32)
                else:
                    df[col] = df[col].astype(np.float64)
        elif col_type == object:
            # Exclude 'TERM_CODE' from conversion to category as it's used for sorting
            if len(df[col].unique()) / len(df[col]) < 0.5 and col != 'TERM_CODE':
                df[col] = df[col].astype('category')
    
    end_mem = df.memory_usage().sum() / 1024**2
    if verbose:
        print(f'Memory usage after optimization is: {end_mem:.2f} MB')
        print(f'Decreased by {100 * (start_mem - end_mem) / start_mem:.1f}%')
    
    return df

# --- Data Loading and Feature Engineering ---
# Load the available data files.
subject_summary_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'subject_summary.csv'))
gold_enrollment_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv'))

# Apply memory reduction
subject_summary_df = reduce_mem_usage(subject_summary_df)
gold_enrollment_df = reduce_mem_usage(gold_enrollment_df)

# --- Base Dataframe Preparation ---
# Merge base features and labels.
df = pd.merge(subject_summary_df, gold_enrollment_df, on=['TERM_CODE', 'SUBJECT_ID_SORT'])
df['HIGH_ENROLLMENT'] = (df['HIGH_ENROLLMENT'] == 'Y').astype(int)
df = df.sort_values('TERM_CODE').reset_index(drop=True)

# Clean up to free memory
del subject_summary_df, gold_enrollment_df
gc.collect()

# --- Feature Engineering for Base Model (RandomForest) ---
df_base = df.copy()

# Create more meaningful interaction and ratio features.
# FIX: The original code used incorrect column names 'ENROLLMENT_COUNT' and 'MAX_ENROLLMENT'.
# The correct names are likely abbreviated as 'ENRL_CNT' and 'MAX_ENRL' in the dataset.
# Handle potential division by zero or 0/0 by replacing resulting inf/NaN with 0.
if 'ENRL_CNT' in df_base.columns and 'MAX_ENRL' in df_base.columns:
    df_base['enrollment_to_capacity_ratio'] = (df_base['ENRL_CNT'] / df_base['MAX_ENRL']).replace([np.inf, -np.inf], 0).fillna(0)

    # Sort by subject and term to ensure correct temporal ordering for feature generation.
    df_base = df_base.sort_values(['SUBJECT_ID_SORT', 'TERM_CODE'])

    # Generate lagged and rolling window features on the new, more informative ratio feature.
    # Group by subject to create features within each subject's history.
    grouped_ratio = df_base.groupby('SUBJECT_ID_SORT')['enrollment_to_capacity_ratio']
    df_base['ratio_lag_1'] = grouped_ratio.shift(1)
    df_base['ratio_rolling_mean_3'] = grouped_ratio.transform(lambda x: x.rolling(window=3, min_periods=1).mean())
    df_base['ratio_rolling_std_3'] = grouped_ratio.transform(lambda x: x.rolling(window=3, min_periods=1).std())

    # Replace the naive fillna(0) with a more robust group-wise imputation for temporal features.
    # For each subject, fill NaNs with the mean of that feature for that specific subject.
    temporal_features_with_nans = ['ratio_lag_1', 'ratio_rolling_std_3']
    for col in temporal_features_with_nans:
        # Calculate the mean for each group and use transform to align it for filling NaNs.
        group_mean = df_base.groupby('SUBJECT_ID_SORT')[col].transform('mean')
        df_base[col] = df_base[col].fillna(group_mean)

# Automatically identify features for the model.
excluded_cols = ['TERM_CODE', 'SUBJECT_ID_SORT', 'HIGH_ENROLLMENT']
features = [col for col in df_base.columns if col not in excluded_cols]
categorical_features = df_base[features].select_dtypes(include=['object', 'category']).columns

# Apply Label Encoding to categorical features.
for col in categorical_features:
    le = LabelEncoder()
    df_base[col] = le.fit_transform(df_base[col].astype(str))

# Handle any remaining missing values with a simple fill-zero strategy.
# This is now a safer fallback, as the most critical NaNs (from temporal features)
# have been imputed using a more logical, group-wise strategy.
df_base[features] = df_base[features].fillna(0)


# --- Time-based Validation Split ---
# Sort by term to ensure chronological split
df_base = df_base.sort_values('TERM_CODE').reset_index(drop=True)
unique_terms = df_base['TERM_CODE'].unique()

if len(unique_terms) > 4:
    num_validation_terms = max(1, int(len(unique_terms) * 0.2))
    train_terms = unique_terms[:-num_validation_terms]
    validation_terms = unique_terms[-num_validation_terms:]

    train_df = df_base[df_base['TERM_CODE'].isin(train_terms)]
    validation_df = df_base[df_base['TERM_CODE'].isin(validation_terms)]
else:
    # Fallback to a random split if there are too few terms.
    indices = df_base.index.to_numpy()
    train_indices, validation_indices = train_test_split(
        indices, test_size=0.2, random_state=42, stratify=df_base['HIGH_ENROLLMENT']
    )
    train_df = df_base.loc[train_indices]
    validation_df = df_base.loc[validation_indices]

# Prepare feature matrices and target vectors
y_train = train_df['HIGH_ENROLLMENT']
y_val = validation_df['HIGH_ENROLLMENT']

X_train = train_df[features]
X_val = validation_df[features]

# --- Model Training and Evaluation ---
final_validation_score = 0.0
if not X_train.empty and not y_train.empty:
    
    model = RandomForestClassifier(n_estimators=100, random_state=42, class_weight='balanced', n_jobs=-1)
    model.fit(X_train, y_train)

    # Evaluate the model on the validation set
    if not X_val.empty:
        y_pred = model.predict(X_val)
        final_validation_score = f1_score(y_val, y_pred, average='macro')

# Print the final performance metric in the required format.
print(f'Final Validation Performance: {final_validation_score}')
