
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score
from sklearn.preprocessing import LabelEncoder
import os
import warnings
import gc

# Suppress warnings for a cleaner output
warnings.filterwarnings('ignore')

# --- Configuration and Paths ---
TRAIN_DATA_DIR = './input/'

# --- Memory Reduction Helper ---
def reduce_mem_usage(df, verbose=False):
    start_mem = df.memory_usage().sum() / 1024**2
    for col in df.columns:
        col_type = df[col].dtype
        if col_type != object and col_type.name != 'category' and 'datetime' not in col_type.name:
            c_min = df[col].min()
            c_max = df[col].max()
            if str(col_type)[:3] == 'int':
                if c_min > np.iinfo(np.int8).min and c_max < np.iinfo(np.int8).max:
                    df[col] = df[col].astype(np.int8)
                elif c_min > np.iinfo(np.int16).min and c_max < np.iinfo(np.int16).max:
                    df[col] = df[col].astype(np.int16)
                elif c_min > np.iinfo(np.int32).min and c_max < np.iinfo(np.int32).max:
                    df[col] = df[col].astype(np.int32)
                else: df[col] = df[col].astype(np.int64)
            else:
                if c_min > np.finfo(np.float32).min and c_max < np.finfo(np.float32).max:
                    df[col] = df[col].astype(np.float32)
                else: df[col] = df[col].astype(np.float64)
        elif col_type == object:
            if len(df[col].unique()) / len(df[col]) < 0.5: df[col] = df[col].astype('category')
    return df

# --- Data Loading Function ---
def load_data():
    subject_summary_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'subject_summary.csv'))
    gold_enrollment_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv'))
    subject_summary_df = reduce_mem_usage(subject_summary_df)
    gold_enrollment_df = reduce_mem_usage(gold_enrollment_df)
    df = pd.merge(subject_summary_df, gold_enrollment_df, on=['TERM_CODE', 'SUBJECT_ID_SORT'])
    df['HIGH_ENROLLMENT'] = (df['HIGH_ENROLLMENT'] == 'Y').astype(int)
    df = df.sort_values('TERM_CODE').reset_index(drop=True)
    del subject_summary_df, gold_enrollment_df
    gc.collect()
    return df

# --- Common Preprocessing and Splitting Function ---
def get_split_data(df_processed, features):
    unique_terms = df_processed['TERM_CODE'].unique()
    if len(unique_terms) > 4:
        num_validation_terms = max(1, int(len(unique_terms) * 0.2))
        train_terms = unique_terms[:-num_validation_terms]
        validation_terms = unique_terms[-num_validation_terms:]
        train_df = df_processed[df_processed['TERM_CODE'].isin(train_terms)]
        validation_df = df_processed[df_processed['TERM_CODE'].isin(validation_terms)]
    else:
        indices = df_processed.index.to_numpy()
        train_indices, validation_indices = train_test_split(
            indices, test_size=0.2, random_state=42, stratify=df_processed['HIGH_ENROLLMENT']
        )
        train_df = df_processed.loc[train_indices]
        validation_df = df_processed.loc[validation_indices]

    y_train = train_df['HIGH_ENROLLMENT']
    y_val = validation_df['HIGH_ENROLLMENT']
    X_train = train_df[features]
    X_val = validation_df[features]
    return X_train, X_val, y_train, y_val

# --- Model Training Function ---
def train_and_evaluate(X_train, X_val, y_train, y_val, n_estimators=100):
    if X_train.empty or y_train.empty: return 0.0
    model = RandomForestClassifier(n_estimators=n_estimators, random_state=42, class_weight='balanced', n_jobs=-1)
    model.fit(X_train, y_train)
    if X_val.empty: return 0.0
    y_pred = model.predict(X_val)
    return f1_score(y_val, y_pred, average='macro')

# --- Ablation Study ---
ablation_results = {}

# 1. Baseline Model
df = load_data()
df_base = df.copy()
excluded_cols = ['TERM_CODE', 'SUBJECT_ID_SORT', 'HIGH_ENROLLMENT']
features = [col for col in df_base.columns if col not in excluded_cols]
categorical_features = df_base[features].select_dtypes(include=['object', 'category']).columns
for col in categorical_features:
    le = LabelEncoder()
    df_base[col] = le.fit_transform(df_base[col].astype(str))
df_base[features] = df_base[features].fillna(0)
X_train, X_val, y_train, y_val = get_split_data(df_base, features)
baseline_score = train_and_evaluate(X_train, X_val, y_train, y_val, n_estimators=100)
ablation_results['Baseline'] = baseline_score
print(f"Baseline Performance (100 estimators, Label Encoding, fillna(0)): {baseline_score:.4f}")

# 2. Ablation: Fewer Estimators (Reduced Model Complexity)
# Re-uses the same processed data as baseline, just changes the model parameter
fewer_estimators_score = train_and_evaluate(X_train, X_val, y_train, y_val, n_estimators=10)
ablation_results['Number of Estimators'] = baseline_score - fewer_estimators_score
print(f"Ablation Performance (10 estimators): {fewer_estimators_score:.4f}")

# 3. Ablation: No Categorical Features
df = load_data()
df_no_cat = df.copy()
excluded_cols = ['TERM_CODE', 'SUBJECT_ID_SORT', 'HIGH_ENROLLMENT']
features_no_cat = [col for col in df_no_cat.columns if col not in excluded_cols]
categorical_features = df_no_cat[features_no_cat].select_dtypes(include=['object', 'category']).columns
# Instead of encoding, we drop the categorical features
features_no_cat = [f for f in features_no_cat if f not in categorical_features]
df_no_cat[features_no_cat] = df_no_cat[features_no_cat].fillna(0)
X_train_nc, X_val_nc, y_train_nc, y_val_nc = get_split_data(df_no_cat, features_no_cat)
no_cat_score = train_and_evaluate(X_train_nc, X_val_nc, y_train_nc, y_val_nc)
ablation_results['Label Encoding for Categorical Features'] = baseline_score - no_cat_score
print(f"Ablation Performance (No Categorical Features): {no_cat_score:.4f}")

# 4. Ablation: Median Imputation for NaNs
df = load_data()
df_median_imp = df.copy()
excluded_cols = ['TERM_CODE', 'SUBJECT_ID_SORT', 'HIGH_ENROLLMENT']
features_median_imp = [col for col in df_median_imp.columns if col not in excluded_cols]
categorical_features = df_median_imp[features_median_imp].select_dtypes(include=['object', 'category']).columns
for col in categorical_features:
    le = LabelEncoder()
    df_median_imp[col] = le.fit_transform(df_median_imp[col].astype(str))
# We will apply median imputation after splitting to avoid data leakage
X_train_mi, X_val_mi, y_train_mi, y_val_mi = get_split_data(df_median_imp, features_median_imp)
# Calculate median on training data and apply to both sets
medians = X_train_mi.median()
X_train_mi = X_train_mi.fillna(medians)
X_val_mi = X_val_mi.fillna(medians)
# Fill any remaining NaNs (if a column was all NaN in train) with 0
X_train_mi = X_train_mi.fillna(0)
X_val_mi = X_val_mi.fillna(0)
median_imp_score = train_and_evaluate(X_train_mi, X_val_mi, y_train_mi, y_val_mi)
ablation_results['Zero-based NaN Imputation'] = baseline_score - median_imp_score
print(f"Ablation Performance (Median NaN Imputation): {median_imp_score:.4f}")


# --- Conclusion ---
# Remove baseline from consideration for impact calculation
impacts = {k: v for k, v in ablation_results.items() if k != 'Baseline'}

if not impacts or max(impacts.values()) <= 0:
    most_impactful_component = "None of the ablated components had a significant positive impact."
else:
    # Find the component whose removal caused the biggest drop in performance
    most_impactful_key = max(impacts, key=impacts.get)
    most_impactful_component = f"The '{most_impactful_key}' contributes the most to the overall performance."

print("\n--- Ablation Study Summary ---")
print(most_impactful_component)
