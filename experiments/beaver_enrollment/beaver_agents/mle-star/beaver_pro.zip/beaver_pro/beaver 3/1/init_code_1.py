
import pandas as pd
import numpy as np
import lightgbm as lgb
from sklearn.metrics import f1_score
import os

def solve():
    """
    Main function to train a LightGBM model and predict high enrollment.
    """
    # Define data directories
    TRAIN_DATA_DIR = './input/table_splits/train/'

    # --- 1. Load Data ---
    # Load all relevant tables from the training directory
    try:
        gold_enrollment_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv'))
        subject_summary_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'subject_summary.csv'))
        course_summary_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'course_summary.csv'))
        course_offering_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'course_offering_details.csv'))
    except FileNotFoundError as e:
        print(f"Error loading data files: {e}")
        print("Please ensure the data is in the './input/table_splits/train/' directory.")
        return

    # --- 2. Merge DataFrames ---
    # Start with the gold labels which define our prediction keys and target
    df = gold_enrollment_df.copy()

    # Merge with subject summary to get term-specific details like total enrollment
    df = pd.merge(df, subject_summary_df, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')

    # Merge with course summary to get static course details like credits
    df = pd.merge(df, course_summary_df, on='SUBJECT_ID_SORT', how='left')

    # --- 3. Feature Engineering ---
    # Create the binary target variable
    df['target'] = (df['HIGH_ENROLLMENT'] == 'Y').astype(int)

    # Time-based features from TERM_CODE
    df['TERM_CODE'] = df['TERM_CODE'].astype(int)
    df['TERM_YEAR'] = df['TERM_CODE'] // 100
    df['TERM_SEASON'] = df['TERM_CODE'] % 100

    # Categorical features from SUBJECT_ID_SORT
    df['DEPARTMENT_CODE'] = df['SUBJECT_ID_SORT'].apply(lambda x: x.split('_')[0])
    df['COURSE_LEVEL'] = df['SUBJECT_ID_SORT'].apply(lambda x: x.split('_')[1][0] + '00' if len(x.split('_')) > 1 and x.split('_')[1] else '000')

    # Aggregate features from course offerings (e.g., number of unique instructors)
    instructor_agg = course_offering_df.groupby(['TERM_CODE', 'SUBJECT_ID_SORT'])['INSTRUCTOR_ID'].nunique().reset_index()
    instructor_agg.rename(columns={'INSTRUCTOR_ID': 'UNIQUE_INSTRUCTOR_COUNT'}, inplace=True)
    df = pd.merge(df, instructor_agg, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')
    df['UNIQUE_INSTRUCTOR_COUNT'].fillna(0, inplace=True)

    # Fill NaNs in credit columns before creating lag features
    df['CREDITS_MIN'].fillna(df['CREDITS_MIN'].median(), inplace=True)
    df['CREDITS_MAX'].fillna(df['CREDITS_MAX'].median(), inplace=True)

    # --- Lag Features (Historical Data) ---
    # Sort by subject and term to ensure correct temporal order for lags
    df.sort_values(['SUBJECT_ID_SORT', 'TERM_CODE'], inplace=True)

    # Create lag features for enrollment and offering count from previous terms.
    # shift(1) uses data from the previous row (which is the previous term for that subject).
    # This is the most critical step to prevent data leakage from the current term.
    df['ENROLLMENT_LAG_1'] = df.groupby('SUBJECT_ID_SORT')['TOTAL_ENROLLMENT'].shift(1)
    df['OFFERING_COUNT_LAG_1'] = df.groupby('SUBJECT_ID_SORT')['OFFERING_COUNT'].shift(1)
    df['ENROLLMENT_ROLLING_AVG_3'] = df.groupby('SUBJECT_ID_SORT')['TOTAL_ENROLLMENT'].shift(1).rolling(window=3, min_periods=1).mean()

    # Fill NaNs created by lag/rolling features (for courses with no history) with -1
    # This allows the model to treat "no historical data" as a distinct case.
    for col in ['ENROLLMENT_LAG_1', 'OFFERING_COUNT_LAG_1', 'ENROLLMENT_ROLLING_AVG_3']:
        df[col].fillna(-1, inplace=True)

    # --- 4. Prepare for Modeling ---
    # Define feature set and categorical features
    features = [
        'TERM_YEAR',
        'TERM_SEASON',
        'CREDITS_MIN',
        'CREDITS_MAX',
        'UNIQUE_INSTRUCTOR_COUNT',
        'ENROLLMENT_LAG_1',
        'OFFERING_COUNT_LAG_1',
        'ENROLLMENT_ROLLING_AVG_3',
        'DEPARTMENT_CODE',
        'COURSE_LEVEL',
    ]
    categorical_features = ['DEPARTMENT_CODE', 'COURSE_LEVEL']

    # Convert categorical feature columns to 'category' dtype for LightGBM
    for col in categorical_features:
        df[col] = df[col].astype('category')

    # --- 5. Train-Validation Split (Time-based) ---
    # Per the task description, use the latest time period for validation.
    all_terms = sorted(df['TERM_CODE'].unique())
    validation_term = all_terms[-1] # Hold out the most recent term
    
    train_df = df[df['TERM_CODE'] < validation_term]
    val_df = df[df['TERM_CODE'] == validation_term]
    
    X_train = train_df[features]
    y_train = train_df['target']
    X_val = val_df[features]
    y_val = val_df['target']
    
    print(f"Training on {len(X_train)} samples, validating on {len(X_val)} samples.")
    print(f"Validation term: {validation_term}")

    # --- 6. Model Training ---
    # Initialize the LightGBM Classifier as specified
    lgbm = lgb.LGBMClassifier(objective='binary',
                              metric='auc',
                              random_state=42)

    print("Training LightGBM model...")
    # Train the model, informing it of the categorical features for optimal handling
    lgbm.fit(X_train, y_train,
             categorical_feature=categorical_features)

    # --- 7. Evaluation ---
    # Make predictions on the hold-out validation set
    y_pred = lgbm.predict(X_val)

    # Calculate the macro F1 score, as specified
    final_validation_score = f1_score(y_val, y_pred, average='macro')
    
    # Print the final performance metric in the required format
    print(f"Final Validation Performance: {final_validation_score}")

if __name__ == '__main__':
    solve()
