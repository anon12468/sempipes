
import pandas as pd
import numpy as np
import os
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score
import gc
import warnings

# Suppress warnings for cleaner output
warnings.filterwarnings('ignore')

def train_and_evaluate(
    enable_ts_features=True,
    enable_subsampling=True
):
    """
    Trains and evaluates the model with specific components enabled or disabled.
    
    Args:
        enable_ts_features (bool): If True, creates lag and rolling window features.
        enable_subsampling (bool): If True, performs undersampling on the majority class.
        
    Returns:
        float: The macro F1 score on the validation set.
    """
    # --- Configuration and Data Loading ---
    TRAIN_DATA_DIR = './input/'
    TARGET_COL = 'HIGH_ENROLLMENT'

    try:
        subject_summary_path = os.path.join(TRAIN_DATA_DIR, 'subject_summary.csv')
        gold_enrollment_path = os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv')
        df_summary = pd.read_csv(subject_summary_path)
        df_gold = pd.read_csv(gold_enrollment_path)
    except FileNotFoundError:
        # If data is not found, we cannot run the experiment.
        return 0.0

    # --- Preprocessing & Base Feature Engineering ---
    df = pd.merge(df_summary, df_gold, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')
    del df_summary, df_gold
    gc.collect()

    df.dropna(subset=[TARGET_COL], inplace=True)

    df[TARGET_COL] = (df[TARGET_COL] == 'Y').astype('int8')
    df['TERM_CODE'] = df['TERM_CODE'].astype('int32')
    df['ENROLLED_STUDENTS'] = pd.to_numeric(df['ENROLLED_STUDENTS'], errors='coerce').fillna(0).astype('int32')

    df.sort_values(by=['SUBJECT_ID_SORT', 'TERM_CODE'], inplace=True)
    df.reset_index(drop=True, inplace=True)

    # --- Ablation Component 1: Time-Series Features ---
    if enable_ts_features:
        # Lag features
        for lag in range(1, 4):
            df[f'ENROLLED_STUDENTS_lag_{lag}'] = df.groupby('SUBJECT_ID_SORT')['ENROLLED_STUDENTS'].shift(lag)
            df[f'{TARGET_COL}_lag_{lag}'] = df.groupby('SUBJECT_ID_SORT')[TARGET_COL].shift(lag)

        # Rolling window features
        for window in [2, 3]:
            df[f'ENROLLED_STUDENTS_rolling_mean_{window}'] = df.groupby('SUBJECT_ID_SORT')['ENROLLED_STUDENTS'].transform(
                lambda x: x.shift(1).rolling(window, min_periods=1).mean()
            )
            df[f'{TARGET_COL}_rolling_sum_{window}'] = df.groupby('SUBJECT_ID_SORT')[TARGET_COL].transform(
                lambda x: x.shift(1).rolling(window, min_periods=1).sum()
            )

    # Term-based and interaction features
    df['TERM_SEASON'] = (df['TERM_CODE'] % 100).astype('int8')
    # Use .get() to safely access lag feature, which might not exist in the ablation run
    enrolled_lag1 = df.get('ENROLLED_STUDENTS_lag_1', pd.Series(0, index=df.index))
    df['ENROLLED_LAG1_X_TERM'] = enrolled_lag1.fillna(0) * df['TERM_SEASON']
    
    df.fillna(-1, inplace=True)

    # --- Time-based Validation Split ---
    unique_terms = sorted(df['TERM_CODE'].unique())
    if len(unique_terms) < 2:
        return 0.0

    validation_term = unique_terms[-2]
    train_terms = [t for t in unique_terms if t < validation_term]

    train_df = df[df['TERM_CODE'].isin(train_terms)].copy()
    val_df = df[df['TERM_CODE'] == validation_term].copy()

    if train_df.empty or val_df.empty:
        return 0.0

    # --- Ablation Component 2: Subsampling ---
    if enable_subsampling:
        neg_class = train_df[train_df[TARGET_COL] == 0]
        pos_class = train_df[train_df[TARGET_COL] == 1]
        
        # Subsample only if positive class exists and negative class is significantly larger
        if not pos_class.empty and len(neg_class) > len(pos_class) * 3:
            neg_class_subsampled = neg_class.sample(n=len(pos_class) * 3, random_state=42)
            train_df = pd.concat([pos_class, neg_class_subsampled]).sample(frac=1, random_state=42).reset_index(drop=True)

    # --- Model Training & Evaluation ---
    id_cols = ['SUBJECT_ID_SORT', 'TERM_CODE']
    features = [col for col in train_df.columns if col not in [TARGET_COL] + id_cols]

    # Align columns between train and validation sets
    val_df = val_df.reindex(columns=train_df.columns, fill_value=-1)

    X_train = train_df[features]
    y_train = train_df[TARGET_COL]
    X_val = val_df[features]
    y_val = val_df[TARGET_COL]
    
    model = RandomForestClassifier(
        n_estimators=100,
        random_state=42,
        n_jobs=-1,
        class_weight='balanced',
        min_samples_leaf=5,
        max_features='sqrt'
    )
    
    model.fit(X_train, y_train)

    y_pred = model.predict(X_val)
    score = f1_score(y_val, y_pred, average='macro')
    
    return score


# --- Main execution block for the ablation study ---
if __name__ == "__main__":
    performance_scores = {}

    # 1. Baseline Experiment (All components enabled)
    baseline_score = train_and_evaluate(enable_ts_features=True, enable_subsampling=True)
    performance_scores["Baseline"] = baseline_score
    
    # 2. Ablation 1: Disable Time-Series Features
    score_no_ts = train_and_evaluate(enable_ts_features=False, enable_subsampling=True)
    performance_scores["No Time-Series Features"] = score_no_ts

    # 3. Ablation 2: Disable Subsampling
    score_no_subsampling = train_and_evaluate(enable_ts_features=True, enable_subsampling=False)
    performance_scores["No Subsampling"] = score_no_subsampling

    # --- Print Results ---
    print("Ablation Study Results:")
    print(f"Baseline performance: {performance_scores.get('Baseline', 0.0):.4f}")
    print(f"Performance without Time-Series Features: {performance_scores.get('No Time-Series Features', 0.0):.4f}")
    print(f"Performance without Subsampling: {performance_scores.get('No Subsampling', 0.0):.4f}")
    
    # --- Determine the most impactful component ---
    performance_drops = {
        "Time-Series Features": baseline_score - score_no_ts,
        "Subsampling": baseline_score - score_no_subsampling
    }

    if not any(performance_drops.values()):
         most_impactful_component = "None of the tested components"
    else:
        most_impactful_component = max(performance_drops, key=performance_drops.get)
    
    print(f"\nThe '{most_impactful_component}' contributes the most to the overall performance.")
