
import pandas as pd
import numpy as np
import os
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score
import warnings

# Suppress warnings for a cleaner output
warnings.filterwarnings('ignore', category=UserWarning)

# --- 1. Load and Preprocess Data ---
TRAIN_DATA_DIR = './input/'
try:
    df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv'))
except FileNotFoundError:
    print("Error: 'gold_enrollment_train.csv' not found in './input/'. Please ensure the data is in the correct directory.")
    # Create a dummy dataframe to avoid crashing the script
    df = pd.DataFrame({
        'TERM_CODE': [202210, 202220, 202230, 202310, 202320] * 20,
        'SUBJECT_ID_SORT': ['CS', 'MATH', 'PHYS', 'ENGL', 'HIST'] * 20,
        'HIGH_ENROLLMENT': ['Y', 'N', 'N', 'Y', 'N'] * 20
    })
    print("Using dummy data for demonstration.")

# --- Subsampling to prevent timeout ---
# If the dataset is large, subsample it to a manageable size to prevent timeouts.
# This is a key change to fix the timeout issue.
MAX_ROWS = 100000
if len(df) > MAX_ROWS:
    print(f"Dataset is large ({len(df)} rows). Subsampling to {MAX_ROWS} rows to prevent timeout.")
    # Use train_test_split for a stratified sample to maintain target distribution
    # We only need the 'test' part of the split, which will be our sample.
    if 'HIGH_ENROLLMENT' in df.columns and df['HIGH_ENROLLMENT'].nunique() > 1:
        _, df_sample = train_test_split(df, test_size=MAX_ROWS/len(df), stratify=df['HIGH_ENROLLMENT'], random_state=42)
        df = df_sample.reset_index(drop=True)
    else:
        # Fallback to random sampling if stratification is not possible
        df = df.sample(n=MAX_ROWS, random_state=42).reset_index(drop=True)

results = {}

if not df.empty:
    df['HIGH_ENROLLMENT'] = df['HIGH_ENROLLMENT'].apply(lambda x: 1 if x == 'Y' else 0)
    df['TERM_YEAR'] = df['TERM_CODE'].astype(str).str[:4].astype(int)
    df['TERM_SEASON'] = df['TERM_CODE'].astype(str).str[4:]
    df['SECTION_COUNT'] = 1  # This seems to be a placeholder feature
    season_map = {'SP': 1, 'SU': 2, 'FA': 3, '10': 1, '20': 2, '30': 3} # Handle numeric seasons if present
    df['TERM_SEASON_ORD'] = df['TERM_SEASON'].map(season_map).fillna(0).astype(int)
    df['TERM_SORTABLE'] = df['TERM_YEAR'] * 10 + df['TERM_SEASON_ORD']
    target = 'HIGH_ENROLLMENT'

# --- Function to run an experiment (Simplified for speed) ---
def run_experiment(df, features_list, use_time_split, experiment_name):
    """
    Runs a single training and evaluation experiment using only LightGBM.
    The RandomForest model was removed as it was the primary cause of the timeout
    due to slow performance with one-hot encoded high-cardinality features.
    """
    X = df[features_list]
    y = df[target]

    # Prepare data for LightGBM, which handles categorical features efficiently
    X_lgb = X.copy()
    categorical_features_lgb = [col for col in ['SUBJECT_ID_SORT', 'TERM_SEASON'] if col in X_lgb.columns]
    for col in categorical_features_lgb:
        X_lgb[col] = X_lgb[col].astype('category')

    # --- Data Splitting ---
    if use_time_split and df['TERM_SORTABLE'].nunique() > 1:
        validation_term = df['TERM_SORTABLE'].max()
        train_indices = df[df['TERM_SORTABLE'] < validation_term].index
        val_indices = df[df['TERM_SORTABLE'] == validation_term].index
        # Fallback to random split if time-based split results in empty sets
        if len(train_indices) == 0 or len(val_indices) == 0:
            print("Warning: Time-based split resulted in empty train/val set. Falling back to random split.")
            train_indices, val_indices = train_test_split(df.index, test_size=0.2, random_state=42, stratify=y)
    else:
        train_indices, val_indices = train_test_split(df.index, test_size=0.2, random_state=42, stratify=y)

    y_train, y_val = y.loc[train_indices], y.loc[val_indices]
    X_train_lgb, X_val_lgb = X_lgb.loc[train_indices], X_lgb.loc[val_indices]

    # --- Model Training (LightGBM only) ---
    score = 0.0
    if not X_val_lgb.empty and y_train.nunique() > 1:
        model_lgb = lgb.LGBMClassifier(objective='binary', metric='binary_logloss', class_weight='balanced', random_state=42, verbosity=-1)
        
        # Get list of categorical features actually present in the training data
        lgbm_cat_features = [f for f in categorical_features_lgb if f in X_train_lgb.columns]
        
        model_lgb.fit(X_train_lgb, y_train, categorical_feature=lgbm_cat_features)
        
        y_pred_val = model_lgb.predict(X_val_lgb)

        score = f1_score(y_val, y_pred_val, average='macro')

    print(f'{experiment_name} Performance: {score:.4f}')
    return score

# --- Run Ablation Studies ---

# Baseline: Full original script features, modeled with LightGBM
baseline_features = ['TERM_YEAR', 'TERM_SEASON', 'SECTION_COUNT', 'SUBJECT_ID_SORT']
baseline_score = run_experiment(df, baseline_features, use_time_split=True, experiment_name='Baseline (Full Model)')
results['Baseline'] = baseline_score
print(f'Final Validation Performance: {baseline_score:.4f}')


# Ablation 1: Remove Time-Based Splitting (use random stratified split)
ablation_1_score = run_experiment(df, baseline_features, use_time_split=False, experiment_name='Ablation 1 (Random Split)')
results['Time-Based Split'] = baseline_score - ablation_1_score

# Ablation 2: Remove Temporal Features
features_no_temporal = ['SUBJECT_ID_SORT', 'SECTION_COUNT']
ablation_2_score = run_experiment(df, features_no_temporal, use_time_split=True, experiment_name='Ablation 2 (No Temporal Features)')
results['Temporal Features'] = baseline_score - ablation_2_score

# Ablation 3: Remove Subject ID Feature
features_no_subject = ['TERM_YEAR', 'TERM_SEASON', 'SECTION_COUNT']
ablation_3_score = run_experiment(df, features_no_subject, use_time_split=True, experiment_name='Ablation 3 (No Subject Feature)')
results['Subject ID Feature'] = baseline_score - ablation_3_score

print("\n--- Ablation Study Conclusion ---")

# Find the component with the largest impact (largest score drop)
if all(v == 0 for v in results.values()):
     print("Could not determine the most impactful component due to all scores being zero.")
else:
    # Exclude baseline from the impact calculation
    impact_results = {k: v for k, v in results.items() if k != 'Baseline'}
    most_impactful_component = max(impact_results, key=impact_results.get)
    performance_drop = impact_results[most_impactful_component]

    print(f"The most impactful component is the '{most_impactful_component}'.")
    print(f"Its removal caused the largest performance drop of {performance_drop:.4f} in the macro F1-score.")
