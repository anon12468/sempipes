
import pandas as pd
import numpy as np
import os
import lightgbm as lgb
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score
import warnings

warnings.filterwarnings('ignore')

# --- Helper Function to run a training and evaluation cycle ---
def evaluate_model(description, model_lgb, model_rf, X_train_lgb, y_train, X_val_lgb, y_val, X_train_rf, X_val_rf, use_lgb=True, use_rf=True):
    """
    Trains and evaluates a specified combination of models.
    """
    y_pred_val = None
    y_pred_proba_lgb = None
    y_pred_proba_rf = None

    if X_val_lgb.empty:
        print(f"Skipping '{description}': Validation set is empty.")
        return description, 0.0

    if y_train.nunique() < 2:
        trivial_prediction = y_train.unique()[0]
        y_pred_val = np.full(y_val.shape, trivial_prediction)
    else:
        # Train and predict with LightGBM if enabled
        if use_lgb:
            model_lgb.fit(X_train_lgb, y_train, categorical_feature=['SUBJECT_ID_SORT', 'TERM_SEASON'])
            y_pred_proba_lgb = model_lgb.predict_proba(X_val_lgb)[:, 1]

        # Train and predict with RandomForest if enabled
        if use_rf:
            model_rf.fit(X_train_rf, y_train)
            y_pred_proba_rf = model_rf.predict_proba(X_val_rf)[:, 1]

        # Ensemble predictions
        if use_lgb and use_rf:
            y_pred_proba_ensemble = (y_pred_proba_lgb + y_pred_proba_rf) / 2
        elif use_lgb:
            y_pred_proba_ensemble = y_pred_proba_lgb
        elif use_rf:
            y_pred_proba_ensemble = y_pred_proba_rf
        else:
             # No models used, predict majority class
            y_pred_proba_ensemble = np.full(y_val.shape, y_train.mode()[0])


        y_pred_val = (y_pred_proba_ensemble > 0.5).astype(int)

    score = f1_score(y_val, y_pred_val, average='macro')
    print(f"Performance for '{description}': {score:.4f}")
    return description, score


# --- 1. Load and Prepare Data (Done once) ---
TRAIN_DATA_DIR = './input/'
df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv'))
ablation_scores = {}
baseline_score = 0.0

if not df.empty:
    df['HIGH_ENROLLMENT'] = df['HIGH_ENROLLMENT'].apply(lambda x: 1 if x == 'Y' else 0)
    df['TERM_YEAR'] = df['TERM_CODE'].astype(str).str[:4].astype(int)
    df['TERM_SEASON'] = df['TERM_CODE'].astype(str).str[4:]
    season_map = {'SP': 1, 'SU': 2, 'FA': 3}
    df['TERM_SEASON_ORD'] = df['TERM_SEASON'].map(season_map).fillna(0).astype(int)
    df['TERM_SORTABLE'] = df['TERM_YEAR'] * 10 + df['TERM_SEASON_ORD']

    # Removed 'SECTION_COUNT' as it's a constant and provides no predictive value.
    features = ['TERM_YEAR', 'TERM_SEASON', 'SUBJECT_ID_SORT']
    target = 'HIGH_ENROLLMENT'
    X = df[features]
    y = df[target]

    X_lgb = X.copy()
    X_lgb['SUBJECT_ID_SORT'] = X_lgb['SUBJECT_ID_SORT'].astype('category')
    X_lgb['TERM_SEASON'] = X_lgb['TERM_SEASON'].astype('category')
    X_rf = pd.get_dummies(X, columns=['SUBJECT_ID_SORT', 'TERM_SEASON'], drop_first=True)

    if df['TERM_SORTABLE'].nunique() > 1:
        validation_term = df['TERM_SORTABLE'].max()
        train_indices = df[df['TERM_SORTABLE'] < validation_term].index
        val_indices = df[df['TERM_SORTABLE'] == validation_term].index
        if len(train_indices) == 0 or len(val_indices) == 0:
            train_indices, val_indices = train_test_split(df.index, test_size=0.2, random_state=42, stratify=y)
    else:
        train_indices, val_indices = train_test_split(df.index, test_size=0.2, random_state=42, stratify=y)

    y_train, y_val = y.loc[train_indices], y.loc[val_indices]
    X_train_lgb, X_val_lgb = X_lgb.loc[train_indices], X_lgb.loc[val_indices]
    X_train_rf, X_val_rf = X_rf.loc[train_indices], X_rf.loc[val_indices]
    
    # Align columns after one-hot encoding to ensure train and val sets have same features
    X_train_rf, X_val_rf = X_train_rf.align(X_val_rf, join='left', axis=1, fill_value=0)

    # --- Ablation Study Runs ---
    print("--- Starting Ablation Study ---")

    # Baseline: Full solution
    # Reduced n_estimators and added n_jobs=-1 to RandomForest to prevent timeout.
    model_lgb_base = lgb.LGBMClassifier(objective='binary', metric='binary_logloss', class_weight='balanced', random_state=42)
    model_rf_base = RandomForestClassifier(class_weight='balanced', random_state=42, n_estimators=20, n_jobs=-1)
    desc, score = evaluate_model("Baseline (LGBM + RF Ensemble)", model_lgb_base, model_rf_base, X_train_lgb, y_train, X_val_lgb, y_val, X_train_rf, X_val_rf)
    ablation_scores[desc] = score
    baseline_score = score

    # Ablation 1: Only LightGBM
    desc, score = evaluate_model("Ablation 1 (LGBM Only)", model_lgb_base, model_rf_base, X_train_lgb, y_train, X_val_lgb, y_val, X_train_rf, X_val_rf, use_rf=False)
    ablation_scores[desc] = score

    # Ablation 2: Only RandomForest
    desc, score = evaluate_model("Ablation 2 (RandomForest Only)", model_lgb_base, model_rf_base, X_train_lgb, y_train, X_val_lgb, y_val, X_train_rf, X_val_rf, use_lgb=False)
    ablation_scores[desc] = score
    
    # Ablation 3: Remove 'class_weight=balanced'
    model_lgb_no_weight = lgb.LGBMClassifier(objective='binary', metric='binary_logloss', random_state=42)
    # Reduced n_estimators and added n_jobs=-1 to RandomForest to prevent timeout.
    model_rf_no_weight = RandomForestClassifier(random_state=42, n_estimators=20, n_jobs=-1)
    desc, score = evaluate_model("Ablation 3 (Ensemble without class_weight)", model_lgb_no_weight, model_rf_no_weight, X_train_lgb, y_train, X_val_lgb, y_val, X_train_rf, X_val_rf)
    ablation_scores[desc] = score

    print("--- Ablation Study Finished ---\n")

    # --- Analysis of Results ---
    if baseline_score > 0 and 'Ablation 1 (LGBM Only)' in ablation_scores and 'Ablation 3 (Ensemble without class_weight)' in ablation_scores:
        performance_drops = {
            'Ensembling (contribution of adding RF to LGBM)': ablation_scores.get('Ablation 1 (LGBM Only)', baseline_score) - baseline_score,
            'class_weight=\'balanced\'': ablation_scores.get('Ablation 3 (Ensemble without class_weight)', baseline_score) - baseline_score,
        }

        # Find the component whose removal caused the biggest drop in performance
        most_impactful_component = min(performance_drops, key=performance_drops.get)
        impact_value = performance_drops[most_impactful_component]

        print("--- Ablation Analysis ---")
        print(f"The baseline score is {baseline_score:.4f}.")
        print(f"Removing the RandomForest from the ensemble changes the score by {performance_drops['Ensembling (contribution of adding RF to LGBM)']:.4f}.")
        print(f"Removing 'class_weight=balanced' changes the score by {performance_drops['class_weight=\'balanced\'']:.4f}.")
        print("\nConclusion:")
        print(f"The component that contributes the most to the overall performance is '{most_impactful_component}'.")
        print(f"Its removal resulted in the largest performance drop of {abs(impact_value):.4f}.")
    else:
        print("Could not perform analysis due to a baseline score of 0 or missing ablation results.")
else:
    print("Input data is empty. Cannot run ablation study.")

print(f'Final Validation Performance: {baseline_score:.4f}')

