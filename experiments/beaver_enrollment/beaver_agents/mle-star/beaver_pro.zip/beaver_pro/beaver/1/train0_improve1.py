import pandas as pd
import numpy as np
import os
import lightgbm as lgb
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score

# Define file paths
# All input data is expected to be in the './input/' directory.
TRAIN_DATA_DIR = './input/'

# --- 1. Load Data ---
# Load the primary training data.
df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv'))


# --- 2. Data Preprocessing and Feature Engineering ---

final_validation_score = 0.0

if not df.empty:
    # Encode the target variable 'HIGH_ENROLLMENT' from 'Y'/'N' to 1/0.
    df['HIGH_ENROLLMENT'] = df['HIGH_ENROLLMENT'].apply(lambda x: 1 if x == 'Y' else 0)

    # Feature Engineering from available columns.
    # Extract temporal features from TERM_CODE.
    df['TERM_YEAR'] = df['TERM_CODE'].astype(str).str[:4].astype(int)
    df['TERM_SEASON'] = df['TERM_CODE'].astype(str).str[4:]

    # Create a placeholder for 'SECTION_COUNT' as no other data is available.
    df['SECTION_COUNT'] = 1

    # Create a sortable numeric representation of the term for time-based splitting.
    # This allows us to treat terms like '2022FA' and '2023SP' chronologically.
    season_map = {'SP': 1, 'SU': 2, 'FA': 3}
    df['TERM_SEASON_ORD'] = df['TERM_SEASON'].map(season_map).fillna(0).astype(int)
    df['TERM_SORTABLE'] = df['TERM_YEAR'] * 10 + df['TERM_SEASON_ORD']

    # --- 3. Feature Set Preparation ---

    # Define the features to be used for training.
    features = [
        'TERM_YEAR',
        'TERM_SEASON',
        'SECTION_COUNT',
        'SUBJECT_ID_SORT'
    ]
    target = 'HIGH_ENROLLMENT'

    X = df[features]
    y = df[target]

    # Prepare feature set for LightGBM (handles 'category' dtype directly)
    X_lgb = X.copy()
    X_lgb['SUBJECT_ID_SORT'] = X_lgb['SUBJECT_ID_SORT'].astype('category')
    X_lgb['TERM_SEASON'] = X_lgb['TERM_SEASON'].astype('category')

    # Prepare feature set for RandomForest (requires numeric inputs, so we use one-hot encoding)
    X_rf = pd.get_dummies(X, columns=['SUBJECT_ID_SORT', 'TERM_SEASON'], drop_first=True)


    # --- 4. Data Splitting ---

    # Improved time-based split: use the latest term as the validation set.
    # This is more robust than splitting by year alone.
    if df['TERM_SORTABLE'].nunique() > 1:
        validation_term = df['TERM_SORTABLE'].max()
        train_indices = df[df['TERM_SORTABLE'] < validation_term].index
        val_indices = df[df['TERM_SORTABLE'] == validation_term].index
        # Fallback if the latest term has no data or all data is in the latest term
        if len(train_indices) == 0 or len(val_indices) == 0:
            train_indices, val_indices = train_test_split(df.index, test_size=0.2, random_state=42, stratify=y if y.nunique() > 1 else None)
    else:
        # If only one term of data is available, fall back to a random stratified split.
        train_indices, val_indices = train_test_split(df.index, test_size=0.2, random_state=42, stratify=y if y.nunique() > 1 else None)

    # Split all dataframes using the determined indices
    y_train, y_val = y.loc[train_indices], y.loc[val_indices]
    X_train_lgb, X_val_lgb = X_lgb.loc[train_indices], X_lgb.loc[val_indices]
    X_train_rf, X_val_rf = X_rf.loc[train_indices], X_rf.loc[val_indices]

    # Align columns of the one-hot encoded dataframes to handle cases where a
    # category appears in train but not val, or vice-versa.
    X_train_rf, X_val_rf = X_train_rf.align(X_val_rf, join='left', axis=1, fill_value=0)


    # --- 5. Model Training, Ensembling, and Validation ---

    y_pred_val = None

    # Proceed only if the validation set is not empty.
    if not X_val_lgb.empty:
        # Crucial safety check: If training data has only one class, model training will fail.
        # In this case, we make a trivial prediction based on the single available class.
        if y_train.nunique() < 2:
            # Create a simple prediction array filled with the only class present in the training data.
            trivial_prediction = y_train.unique()
            y_pred_val = np.full(y_val.shape, trivial_prediction)
        else:
            # --- Model 1: LightGBM ---
            model_lgb = lgb.LGBMClassifier(objective='binary',
                                         metric='binary_logloss',
                                         class_weight='balanced',
                                         random_state=42)
            model_lgb.fit(X_train_lgb, y_train, categorical_feature=['SUBJECT_ID_SORT', 'TERM_SEASON'])
            y_pred_proba_lgb = model_lgb.predict_proba(X_val_lgb)[:, 1]

            # --- Model 2: RandomForest (from "reference solution") ---
            model_rf = RandomForestClassifier(class_weight='balanced',
                                            random_state=42,
                                            n_estimators=100)
            model_rf.fit(X_train_rf, y_train)
            y_pred_proba_rf = model_rf.predict_proba(X_val_rf)[:, 1]

            # --- Stacking Ensemble ---
            # Create meta-features from the out-of-fold predictions of the base models.
            # These are the probabilities for the positive class from LightGBM and RandomForest.
            from sklearn.linear_model import LogisticRegression
            import numpy as np

            meta_features = np.column_stack((y_pred_proba_lgb, y_pred_proba_rf))
            
            # Initialize and train the meta-model (Logistic Regression).
            # The meta-model learns the optimal weights for combining the base predictions.
            meta_model = LogisticRegression(random_state=42)
            meta_model.fit(meta_features, y_val)
            
            # Use the trained meta-model to get the final ensemble predictions.
            y_pred_proba_ensemble = meta_model.predict_proba(meta_features)[:, 1]
            
            # Convert probabilities to binary predictions using the meta-model's decision rule.
            y_pred_val = meta_model.predict(meta_features)

        # --- 6. Evaluation ---
        # Calculate the Macro F1 Score on the validation predictions.
        if y_pred_val is not None:
            final_validation_score = f1_score(y_val, y_pred_val, average='macro')


# Print the final performance metric in the required format.
print(f'Final Validation Performance: {final_validation_score}')