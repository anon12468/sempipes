
import pandas as pd
import numpy as np
import os
from catboost import CatBoostClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score
import re

# Define file paths for the training data
TRAIN_DATA_DIR = './input/'

# --- 1. Load Data ---
# Load all available tables from the training directory
try:
    df_gold = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv'))
    df_courses = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'courses.csv'))
    df_sections = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'sections.csv'))
    df_subjects = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'subjects.csv'))
    df_terms = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'terms.csv'))
except FileNotFoundError as e:
    # This case should not happen in the evaluation environment
    # as per the problem description.
    print(f"Error loading data: {e}")
    # Create a dummy dataframe to avoid crashing and ensure a score of 0.
    df_gold = pd.DataFrame(columns=['TERM_CODE', 'SUBJECT_ID_SORT', 'HIGH_ENROLLMENT'])


# --- 2. Feature Engineering ---

# If the main gold file is empty, we cannot proceed.
if not df_gold.empty:
    # Aggregate section-level data to the course-offering level (TERM_CODE, SUBJECT_ID_SORT)
    section_features = df_sections.groupby(['TERM_CODE', 'SUBJECT_ID_SORT']).agg(
        section_count=('SECTION_NBR', 'count'),
        total_seats=('ENRL_CAP', 'sum'),
        avg_seats_per_section=('ENRL_CAP', 'mean'),
        instructor_count=('INSTRUCTOR_EMPLID', 'nunique')
    ).reset_index()

    # Start building the feature matrix from the gold standard file
    df = pd.merge(df_gold, section_features, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')

    # Merge with course-level information
    df = pd.merge(df, df_courses, on='SUBJECT_ID_SORT', how='left')

    # Create SUBJECT_ID from SUBJECT_ID_SORT to merge with subjects table
    # e.g., 'CS      101' -> 'CS'
    df['SUBJECT_ID'] = df['SUBJECT_ID_SORT'].apply(lambda x: re.split(r'\s+', x.strip())[0])

    # Merge with subject-level information (department name)
    df = pd.merge(df, df_subjects, on='SUBJECT_ID', how='left')

    # Merge with term-level information
    df = pd.merge(df, df_terms, on='TERM_CODE', how='left')

    # Create temporal features from TERM_CODE
    df['TERM_YEAR'] = df['TERM_CODE'].astype(str).str[:4].astype(int)
    df['TERM_SEASON'] = df['TERM_CODE'].astype(str).str[4:]

    # --- 3. Data Preprocessing ---

    # Encode target variable
    df['HIGH_ENROLLMENT'] = df['HIGH_ENROLLMENT'].apply(lambda x: 1 if x == 'Y' else 0)

    # Define features and target
    features = [
        'section_count', 'total_seats', 'avg_seats_per_section', 'instructor_count', # from sections
        'CATALOG_NBR', 'UNITS_MINIMUM', 'UNITS_MAXIMUM', 'COURSE_LEVEL', # from courses
        'DEPT_NAME', # from subjects
        'TERM_DESCR', 'TERM_SEASON', # from terms/term_code
        'SUBJECT_ID', # created feature
        'TERM_YEAR' # created feature for splitting
    ]
    
    # Identify categorical features for CatBoost
    categorical_features = [
        'COURSE_LEVEL', 'DEPT_NAME', 'TERM_DESCR', 'TERM_SEASON', 'SUBJECT_ID'
    ]
    
    # Filter for features that were successfully loaded and created
    final_features = [f for f in features if f in df.columns]
    final_categorical_features = [f for f in categorical_features if f in df.columns]
    
    # Fill missing values
    for col in final_features:
        if df[col].dtype == 'object' or col in final_categorical_features:
            df[col] = df[col].fillna('missing')
        else:
            df[col] = df[col].fillna(0) # Simple imputation for numeric features

    X = df[final_features]
    y = df['HIGH_ENROLLMENT']

    # --- 4. Model Training and Validation ---

    # Time-based split: Use the latest year for validation
    validation_year = df['TERM_YEAR'].max()
    train_indices = df[df['TERM_YEAR'] < validation_year].index
    val_indices = df[df['TERM_YEAR'] == validation_year].index

    # Fallback to random split if only one year of data is available
    if len(val_indices) == 0 or len(train_indices) == 0:
        X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    else:
        X_train, X_val = X.loc[train_indices], X.loc[val_indices]
        y_train, y_val = y.loc[train_indices], y.loc[val_indices]
        
    # Drop the TERM_YEAR column after splitting
    X_train = X_train.drop(columns=['TERM_YEAR'])
    X_val = X_val.drop(columns=['TERM_YEAR'])
    final_categorical_features_indices = [X_train.columns.get_loc(c) for c in final_categorical_features if c in X_train.columns]


    # Initialize the CatBoost classifier
    model = CatBoostClassifier(iterations=200, # Increased iterations for better performance
                               learning_rate=0.1,
                               depth=6,
                               loss_function='Logloss',
                               verbose=False,
                               random_state=42,
                               auto_class_weights='Balanced') # Handle class imbalance

    # Train the model
    model.fit(X_train, y_train, cat_features=final_categorical_features_indices)

    # Make predictions on the validation set
    y_pred_val = model.predict(X_val)

    # --- 5. Evaluation ---
    # Calculate the Macro F1 Score
    final_validation_score = f1_score(y_val, y_pred_val, average='macro')

else:
    # If data loading failed, the score is 0.
    final_validation_score = 0.0

# Print the final performance metric in the required format
print(f'Final Validation Performance: {final_validation_score}')
