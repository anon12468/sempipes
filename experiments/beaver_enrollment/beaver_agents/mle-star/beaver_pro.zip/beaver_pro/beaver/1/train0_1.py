
import pandas as pd
import numpy as np
import os
import re
import lightgbm as lgb
from catboost import CatBoostClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score

# Define file paths
# All input data is expected to be in the './input/' directory.
TRAIN_DATA_DIR = './input/'

# --- 1. Load Data (from Reference Solution) ---
# This section adopts the more comprehensive data loading from the reference solution.
try:
    df_gold = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv'))
    df_courses = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'courses.csv'))
    df_sections = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'sections.csv'))
    df_subjects = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'subjects.csv'))
    df_terms = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'terms.csv'))
except FileNotFoundError:
    # If any data file is missing, we can't proceed with feature engineering.
    # Create a dummy dataframe to avoid crashing and ensure a score of 0.
    df_gold = pd.DataFrame(columns=['TERM_CODE', 'SUBJECT_ID_SORT', 'HIGH_ENROLLMENT'])

final_validation_score = 0.0

# Proceed only if the core data file was loaded successfully.
if not df_gold.empty:
    # --- 2. Feature Engineering (from Reference Solution) ---

    # Aggregate section-level data
    section_features = df_sections.groupby(['TERM_CODE', 'SUBJECT_ID_SORT']).agg(
        section_count=('SECTION_NBR', 'count'),
        total_seats=('ENRL_CAP', 'sum'),
        avg_seats_per_section=('ENRL_CAP', 'mean'),
        instructor_count=('INSTRUCTOR_EMPLID', 'nunique')
    ).reset_index()

    # Start building the main dataframe from the gold standard file
    df = pd.merge(df_gold, section_features, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')

    # Merge with other data sources
    df = pd.merge(df, df_courses, on='SUBJECT_ID_SORT', how='left')
    df['SUBJECT_ID'] = df['SUBJECT_ID_SORT'].apply(lambda x: re.split(r'\s+', x.strip())[0])
    df = pd.merge(df, df_subjects, on='SUBJECT_ID', how='left')
    df = pd.merge(df, df_terms, on='TERM_CODE', how='left')

    # Create temporal features
    df['TERM_YEAR'] = df['TERM_CODE'].astype(str).str[:4].astype(int)
    df['TERM_SEASON'] = df['TERM_CODE'].astype(str).str[4:]

    # --- 3. Data Preprocessing (Combined Approach) ---

    # Encode the target variable
    df['HIGH_ENROLLMENT'] = df['HIGH_ENROLLMENT'].apply(lambda x: 1 if x == 'Y' else 0)

    # Define feature sets
    features = [
        'section_count', 'total_seats', 'avg_seats_per_section', 'instructor_count', # from sections
        'CATALOG_NBR', 'UNITS_MINIMUM', 'UNITS_MAXIMUM', 'COURSE_LEVEL', # from courses
        'DEPT_NAME', # from subjects
        'TERM_DESCR', 'TERM_SEASON', # from terms/term_code
        'SUBJECT_ID', # created feature
        'TERM_YEAR' # created feature for splitting
    ]
    
    categorical_features = [
        'COURSE_LEVEL', 'DEPT_NAME', 'TERM_DESCR', 'TERM_SEASON', 'SUBJECT_ID'
    ]

    # Filter for features that were successfully created
    final_features = [f for f in features if f in df.columns]
    final_categorical_features = [f for f in categorical_features if f in df.columns]

    # Fill missing values (from Reference Solution)
    for col in final_features:
        if col in final_categorical_features:
            df[col] = df[col].fillna('missing')
        else: # Numeric features
            df[col] = df[col].fillna(0)

    # Convert categorical features to 'category' dtype for LightGBM (from Base Solution)
    for col in final_categorical_features:
        df[col] = df[col].astype('category')

    # --- 4. Model Training and Validation ---

    X = df[final_features]
    y = df['HIGH_ENROLLMENT']

    # Time-based split for validation (common approach)
    validation_year = df['TERM_YEAR'].max()
    train_indices = df[df['TERM_YEAR'] < validation_year].index
    val_indices = df[df['TERM_YEAR'] == validation_year].index

    # Fallback to random split if only one year of data is available
    if len(val_indices) == 0 or len(train_indices) == 0:
        X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    else:
        X_train, X_val = X.loc[train_indices], X.loc[val_indices]
        y_train, y_val = y.loc[train_indices], y.loc[val_indices]

    # Drop the TERM_YEAR column after splitting to prevent data leakage
    X_train = X_train.drop(columns=['TERM_YEAR'])
    X_val = X_val.drop(columns=['TERM_YEAR'])
    
    if not X_val.empty:
        # --- Model 1: LightGBM (from Base Solution) ---
        model_lgbm = lgb.LGBMClassifier(objective='binary',
                                      metric='binary_logloss',
                                      class_weight='balanced',
                                      random_state=42)
        model_lgbm.fit(X_train, y_train)
        probs_lgbm = model_lgbm.predict_proba(X_val)[:, 1]

        # --- Model 2: CatBoost (from Reference Solution) ---
        # Get categorical feature indices for CatBoost
        cat_features_indices = [X_train.columns.get_loc(c) for c in final_categorical_features if c in X_train.columns]
        
        model_cat = CatBoostClassifier(iterations=200,
                                     learning_rate=0.1,
                                     depth=6,
                                     loss_function='Logloss',
                                     verbose=False,
                                     random_state=42,
                                     auto_class_weights='Balanced')
        
        # We need to convert category dtypes back to string for catboost fit
        X_train_cat = X_train.copy()
        for col in final_categorical_features:
            if col in X_train_cat.columns:
                X_train_cat[col] = X_train_cat[col].astype(str)

        model_cat.fit(X_train_cat, y_train, cat_features=cat_features_indices)
        probs_cat = model_cat.predict_proba(X_val)[:, 1]

        # --- 5. Ensembling and Evaluation ---
        
        # Simple averaging of probabilities (soft voting)
        avg_probs = (probs_lgbm + probs_cat) / 2
        
        # Convert probabilities to binary predictions
        ensembled_preds = (avg_probs >= 0.5).astype(int)

        # Calculate the Macro F1 Score on ensembled predictions
        final_validation_score = f1_score(y_val, ensembled_preds, average='macro')

# Print the final performance metric in the required format
print(f'Final Validation Performance: {final_validation_score}')
