
import os
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import f1_score

# Define file paths
TRAIN_DATA_DIR = "./input"
GOLD_FILE = "gold_enrollment_train.csv"
TERMS_FILE = "terms.csv"
COURSES_FILE = "courses.csv"

def load_and_merge_data(data_dir):
    """
    Loads and merges the terms, courses, and gold standard enrollment data.
    """
    try:
        terms_path = os.path.join(data_dir, TERMS_FILE)
        courses_path = os.path.join(data_dir, COURSES_FILE)
        gold_path = os.path.join(data_dir, GOLD_FILE)

        terms_df = pd.read_csv(terms_path)
        courses_df = pd.read_csv(courses_path)
        gold_df = pd.read_csv(gold_path)

        # Merge dataframes
        data = pd.merge(courses_df, terms_df, on='TERM_CODE')
        data = pd.merge(data, gold_df, on=['TERM_CODE', 'SUBJECT_ID_SORT'])

        return data

    except FileNotFoundError as e:
        print(f"Error loading data files: {e}")
        # In a real scenario, you might want to raise the exception
        # or handle it more gracefully. For this script, we'll return None.
        return None

def feature_engineering(df):
    """
    Performs feature engineering on the merged dataframe.
    """
    # Convert 'Y'/'N' to 1/0 for the target variable
    df['HIGH_ENROLLMENT'] = df['HIGH_ENROLLMENT'].apply(lambda x: 1 if x == 'Y' else 0)

    # Feature engineering examples:
    # Extract year from TERM_CODE
    df['YEAR'] = df['TERM_CODE'].astype(str).str[:4].astype(int)

    # One-hot encode categorical features that are not high-cardinality
    df = pd.get_dummies(df, columns=['INSTRUCTION_MODE'], drop_first=True)

    # For this example, we will keep it simple and use a subset of columns
    # In a real project, more sophisticated feature engineering would be applied.
    features = [
        'YEAR',
        'INSTRUCTION_MODE_P', # Example one-hot encoded column
        # Other potential features could be derived from 'COURSE_CAREER_NAME', 'ACADEMIC_GROUP_NAME', etc.
    ]
    
    # Check for created dummy columns and add them to features list
    dummy_cols = [col for col in df.columns if 'INSTRUCTION_MODE_' in col]
    features = ['YEAR'] + dummy_cols
    
    # Ensure all selected features exist in the dataframe
    existing_features = [f for f in features if f in df.columns]
    
    return df, existing_features


def main():
    """
    Main function to run the training and validation pipeline.
    """
    # Load and preprocess data
    data = load_and_merge_data(TRAIN_DATA_DIR)
    
    if data is None:
        print("Aborting due to missing data files.")
        return

    data, features = feature_engineering(data)
    
    if not features:
        print("No features were created. Aborting.")
        return

    # Define target variable
    target = 'HIGH_ENROLLMENT'

    # Time-based validation split
    # We'll use the most recent year in the training data as our validation set.
    if 'YEAR' not in data.columns:
        print("'YEAR' column not found for time-based split. Aborting.")
        return
        
    validation_year = data['YEAR'].max()
    train_df = data[data['YEAR'] < validation_year]
    val_df = data[data['YEAR'] == validation_year]
    
    if train_df.empty or val_df.empty:
        print("Train or validation set is empty. Cannot proceed.")
        return

    X_train = train_df[features]
    y_train = train_df[target]
    X_val = val_df[features]
    y_val = val_df[target]

    # Model training pipeline
    pipeline = Pipeline([
        ('scaler', StandardScaler()),
        ('model', LogisticRegression(random_state=42, class_weight='balanced'))
    ])

    # Train the model
    pipeline.fit(X_train, y_train)

    # Make predictions on the validation set
    val_predictions = pipeline.predict(X_val)

    # Evaluate performance
    final_validation_score = f1_score(y_val, val_predictions, average='macro')

    # Print final validation performance
    print(f'Final Validation Performance: {final_validation_score}')


if __name__ == '__main__':
    main()
