
import pandas as pd
import numpy as np
import os
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score

# Define file paths
# All input data is expected to be in the './input/' directory.
TRAIN_DATA_DIR = './input/'

# --- 1. Load Data ---
# The original error was 'FileNotFoundError' for 'courses.csv'.
# This version fixes the error by only loading 'gold_enrollment_train.csv', which is guaranteed to be available.
# A try-except block is used for robust file loading.
try:
    df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv'))
except FileNotFoundError:
    # If the primary data file is missing, we can't proceed.
    # Create a dummy dataframe to avoid crashing and ensure a score of 0.
    df = pd.DataFrame(columns=['TERM_CODE', 'SUBJECT_ID_SORT', 'HIGH_ENROLLMENT'])


# --- 2. Data Preprocessing and Feature Engineering ---

final_validation_score = 0.0

if not df.empty:
    # Encode the target variable 'HIGH_ENROLLMENT' from 'Y'/'N' to 1/0.
    df['HIGH_ENROLLMENT'] = df['HIGH_ENROLLMENT'].apply(lambda x: 1 if x == 'Y' else 0)

    # Feature Engineering from available columns.
    # Extract temporal features from TERM_CODE.
    df['TERM_YEAR'] = df['TERM_CODE'].astype(str).str[:4].astype(int)
    # FIX: The seasonal part of TERM_CODE can be a string (e.g., 'FA' for Fall).
    # It cannot be directly converted to an integer. Extract it as a string.
    df['TERM_SEASON'] = df['TERM_CODE'].astype(str).str[4:]

    # Create a placeholder for 'SECTION_COUNT' as no other data is available.
    df['SECTION_COUNT'] = 1

    # For LightGBM to handle categorical features automatically, we convert the columns to 'category' dtype.
    if 'SUBJECT_ID_SORT' in df.columns:
        df['SUBJECT_ID_SORT'] = df['SUBJECT_ID_SORT'].astype('category')
    if 'TERM_SEASON' in df.columns:
        df['TERM_SEASON'] = df['TERM_SEASON'].astype('category')


    # --- 3. Model Training and Validation ---

    # Define the features to be used for training.
    # We can only use features derived from the available data.
    features = [
        'TERM_YEAR',
        'TERM_SEASON',
        'SECTION_COUNT',
        'SUBJECT_ID_SORT'
    ]
    target = 'HIGH_ENROLLMENT'

    # Ensure all selected features exist in the dataframe.
    features = [f for f in features if f in df.columns]

    X = df[features]
    y = df[target]

    # Time-based split for validation: use the latest year as the validation set.
    if 'TERM_YEAR' in df.columns and df['TERM_YEAR'].nunique() > 1:
        validation_year = df['TERM_YEAR'].max()
        train_indices = df[df['TERM_YEAR'] < validation_year].index
        val_indices = df[df['TERM_YEAR'] == validation_year].index
    else:
        # If only one year of data is available, fall back to a random stratified split.
        train_indices, val_indices = train_test_split(df.index, test_size=0.2, random_state=42, stratify=y if y.nunique() > 1 else None)


    X_train, X_val = X.loc[train_indices], X.loc[val_indices]
    y_train, y_val = y.loc[train_indices], y.loc[val_indices]

    # Proceed only if the validation set is not empty.
    if not X_val.empty:
        # Initialize the LightGBM classifier.
        model = lgb.LGBMClassifier(objective='binary',
                                 metric='binary_logloss',
                                 class_weight='balanced',
                                 random_state=42)

        # Train the model.
        # By converting categorical columns to category dtype, LightGBM handles them automatically.
        model.fit(X_train, y_train)

        # Make predictions on the validation set.
        y_pred_val = model.predict(X_val)

        # --- 4. Evaluation ---
        # Calculate the Macro F1 Score.
        final_validation_score = f1_score(y_val, y_pred_val, average='macro')

# Print the final performance metric in the required format.
print(f'Final Validation Performance: {final_validation_score}')
