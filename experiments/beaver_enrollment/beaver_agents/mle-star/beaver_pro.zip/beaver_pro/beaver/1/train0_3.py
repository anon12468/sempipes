
import pandas as pd
import numpy as np
import os
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

# --- 1. Load and Merge Data (integrating Reference Solution's approach) ---

# Define file paths
TRAIN_DATA_DIR = './input/'
final_validation_score = 0.0
df = pd.DataFrame()

# Load and merge data, handling potential file not found errors
try:
    df_gold = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv'))
    df_courses = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'courses.csv'))
    df_terms = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'terms.csv'))

    # Merge dataframes using inner joins as implicitly done in the reference solution
    # This ensures we only work with data points present across all relevant files
    df = pd.merge(df_courses, df_terms, on='TERM_CODE', how='inner')
    df = pd.merge(df, df_gold, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='inner')
except FileNotFoundError:
    # If any file is missing, df will remain empty, leading to a score of 0.
    pass

# Proceed only if data was loaded and merged successfully
if not df.empty:
    # --- 2. Data Preprocessing and Feature Engineering (Combined Approach) ---

    # Encode target variable (common step in both solutions)
    df['HIGH_ENROLLMENT'] = df['HIGH_ENROLLMENT'].apply(lambda x: 1 if x == 'Y' else 0)

    # Create temporal features (from Base Solution)
    df['TERM_YEAR'] = df['TERM_CODE'].astype(str).str[:4].astype(int)
    df['TERM_SEASON'] = df['TERM_CODE'].astype(str).str[4:]

    # Define categorical features to use, combining ideas from both solutions
    categorical_features = [
        'SUBJECT_ID_SORT',    # From Base Solution
        'INSTRUCTION_MODE',   # From Reference Solution
        'COURSE_CAREER_NAME', # Potential feature from Reference
        'ACADEMIC_GROUP_NAME',# Potential feature from Reference
        'TERM_SEASON'         # From Base Solution
    ]

    # Filter for features that actually exist in the merged dataframe
    features_to_use = [f for f in categorical_features if f in df.columns]

    # One-hot encode categorical features for compatibility with both models.
    # This is necessary for Logistic Regression.
    X = pd.get_dummies(df[features_to_use + ['TERM_YEAR']], columns=features_to_use, drop_first=True)
    y = df['HIGH_ENROLLMENT']

    # --- 3. Model Training and Validation Split ---

    # Time-based split for validation (from Base Solution)
    if 'TERM_YEAR' in X.columns and X['TERM_YEAR'].nunique() > 1:
        validation_year = X['TERM_YEAR'].max()
        train_indices = X[X['TERM_YEAR'] < validation_year].index
        val_indices = X[X['TERM_YEAR'] == validation_year].index
    else:
        # Fallback to a random stratified split if time-based split is not possible
        train_indices, val_indices = train_test_split(df.index, test_size=0.2, random_state=42, stratify=y if y.nunique() > 1 else None)

    X_train = X.loc[train_indices]
    X_val = X.loc[val_indices]
    y_train = y.loc[train_indices]
    y_val = y.loc[val_indices]

    # Drop TERM_YEAR after splitting is complete
    X_train = X_train.drop(columns=['TERM_YEAR'])
    X_val = X_val.drop(columns=['TERM_YEAR'])
    
    # Align columns: ensures validation set has the same feature columns as the training set,
    # filling any missing columns with 0. This is crucial after one-hot encoding with a time split.
    train_cols = X_train.columns
    X_val = X_val.reindex(columns=train_cols, fill_value=0)

    # Proceed only if both train and validation sets are non-empty
    if not X_val.empty and not X_train.empty:
        # --- Model 1: LightGBM (from Base Solution) ---
        model_lgbm = lgb.LGBMClassifier(objective='binary',
                                        metric='binary_logloss',
                                        class_weight='balanced',
                                        random_state=42)
        model_lgbm.fit(X_train, y_train)
        probs_lgbm = model_lgbm.predict_proba(X_val)[:, 1]

        # --- Model 2: Logistic Regression (from Reference Solution) ---
        pipeline_lr = Pipeline([
            ('scaler', StandardScaler()),
            ('model', LogisticRegression(random_state=42, class_weight='balanced'))
        ])
        pipeline_lr.fit(X_train, y_train)
        probs_lr = pipeline_lr.predict_proba(X_val)[:, 1]

        # --- 4. Ensembling and Evaluation ---
        
        # Ensemble by averaging the predicted probabilities from both models (soft voting)
        avg_probs = (probs_lgbm + probs_lr) / 2
        
        # Convert averaged probabilities to binary predictions
        ensembled_preds = (avg_probs >= 0.5).astype(int)

        # Calculate the Macro F1 Score on the ensembled predictions
        final_validation_score = f1_score(y_val, ensembled_preds, average='macro')

# Print the final performance metric in the required format
print(f'Final Validation Performance: {final_validation_score}')
