
import pandas as pd
import numpy as np
import os
from xgboost import XGBClassifier
from sklearn.metrics import f1_score
from sklearn.model_selection import train_test_split

# --- 1. Data Loading ---
# The error analysis indicates that the main data files are in the './input' directory,
# while the gold labels are in a 'train' subdirectory as per the instructions.
# This script assumes the following file structure:
# ./input/course_summary.csv
# ./input/courses.csv
# ./input/sections.csv
# ./input/train/gold_enrollment_train.csv

INPUT_DIR = './input'
TRAIN_DATA_DIR = os.path.join(INPUT_DIR, 'train')

# Based on the problem description and error logs, the main data files
# are in the root of the input directory, while the gold label file is in the 'train' subdirectory.
try:
    course_summary = pd.read_csv(os.path.join(INPUT_DIR, 'course_summary.csv'))
    courses = pd.read_csv(os.path.join(INPUT_DIR, 'courses.csv'))
    sections = pd.read_csv(os.path.join(INPUT_DIR, 'sections.csv'))
    labels = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv'))
except FileNotFoundError as e:
    print(f"Error loading data files: {e}")
    print("This script expects the following file structure:")
    print("- ./input/course_summary.csv")
    print("- ./input/courses.csv")
    print("- ./input/sections.csv")
    print("- ./input/train/gold_enrollment_train.csv")
    raise

# --- 2. Feature Engineering ---
# The goal is to create a single feature matrix for prediction.
# The prediction key is (TERM_CODE, SUBJECT_ID_SORT), the grain of `course_summary`.

# Start with the course summary and merge the supervised labels.
df = pd.merge(course_summary, labels, on=['TERM_CODE', 'SUBJECT_ID_SORT'])

# Merge features from the `courses` table.
df = pd.merge(df, courses[['COURSE_ID', 'DEPARTMENT_ID', 'COURSE_LEVEL', 'CREDITS_MAXIMUM']], on='COURSE_ID', how='left')

# Aggregate features from the `sections` table to the course level.
section_features = sections.groupby(['TERM_CODE', 'SUBJECT_ID_SORT']).agg(
    NUM_SECTIONS=('SECTION_ID', 'count'),
    TOTAL_CAPACITY=('MAX_ENROLLMENT', 'sum')
).reset_index()

# Merge the aggregated section features into the main dataframe.
df = pd.merge(df, section_features, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')


# --- 3. Data Preprocessing ---

# Convert the binary target variable 'Y'/'N' to 1/0 for the model.
df['HIGH_ENROLLMENT'] = df['HIGH_ENROLLMENT'].map({'Y': 1, 'N': 0})

# Define feature sets
categorical_features = ['DEPARTMENT_ID', 'COURSE_LEVEL']
numerical_features = ['TERM_OFFERED_SEQUENCE', 'CREDITS_MAXIMUM', 'NUM_SECTIONS', 'TOTAL_CAPACITY']
target = 'HIGH_ENROLLMENT'

# Handle missing values
for col in numerical_features:
    median_val = df[col].median()
    df[col].fillna(median_val, inplace=True)

for col in categorical_features:
    df[col].fillna('missing', inplace=True)
    df[col] = df[col].astype(str)

# Perform one-hot encoding for categorical features.
features_df = pd.get_dummies(df[numerical_features + categorical_features], columns=categorical_features, dummy_na=False)
target_series = df[target]

# --- 4. Time-based Train-Validation Split ---
# The task requires a time-based split. The latest terms will be used for validation.
# This section is made robust to handle cases with few unique terms.

all_terms = sorted(df['TERM_CODE'].unique())

# If there are fewer than 2 terms, a time-based split that leaves a non-empty training set is impossible.
# In this case, fall back to a stratified random split.
if len(all_terms) < 2:
    print("Warning: Less than 2 unique terms found. Falling back to a random stratified split.")
    X_train, X_val, y_train, y_val = train_test_split(
        features_df,
        target_series,
        test_size=0.2,
        random_state=42,
        stratify=target_series
    )
else:
    # Proceed with the time-based split.
    # Use the last 20% of terms for validation, ensuring at least one term is used.
    validation_term_count = max(1, int(len(all_terms) * 0.2))
    validation_terms = all_terms[-validation_term_count:]

    # Create boolean masks for training and validation sets based on the original dataframe `df`
    train_mask = ~df['TERM_CODE'].isin(validation_terms)
    val_mask = df['TERM_CODE'].isin(validation_terms)

    # Apply masks to create the final data splits
    X_train = features_df.loc[train_mask]
    y_train = target_series.loc[train_mask]

    X_val = features_df.loc[val_mask]
    y_val = target_series.loc[val_mask]

    # A final check to prevent errors if a split results in an empty set (e.g., due to sparse data).
    if X_train.empty or X_val.empty:
        print("Warning: Time-based split resulted in an empty train or validation set. Falling back to a random stratified split.")
        X_train, X_val, y_train, y_val = train_test_split(
            features_df,
            target_series,
            test_size=0.2,
            random_state=42,
            stratify=target_series
        )

# --- 5. Model Training ---

# Initialize the XGBoost classifier.
model = XGBClassifier(
    objective='binary:logistic',
    use_label_encoder=False,
    eval_metric='logloss',
    random_state=42
)

# Train the model on the training data.
model.fit(X_train, y_train)


# --- 6. Evaluation ---

# Make predictions on the hold-out validation set.
y_pred = model.predict(X_val)

# Calculate the Macro F1 score.
final_validation_score = f1_score(y_val, y_pred, average='macro')

# Print the final performance metric in the required format.
print(f"Final Validation Performance: {final_validation_score}")
