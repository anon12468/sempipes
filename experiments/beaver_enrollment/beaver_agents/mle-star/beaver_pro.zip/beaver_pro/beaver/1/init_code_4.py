
import pandas as pd
import numpy as np
import os
import re
from tabpfn import TabPFNClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score
import warnings

# Suppress potential warnings from TabPFN about model loading
warnings.filterwarnings("ignore", category=UserWarning)

# Define file paths for the training data
TRAIN_DATA_DIR = './input/'

# --- 1. Load Data ---
# Load all available tables from the training directory
try:
    df_gold = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv'))
    df_courses = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'courses.csv'))
    df_sections = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'sections.csv'))
    df_subjects = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'subjects.csv'))
    df_terms = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'terms.csv'))
except FileNotFoundError:
    # This case should not happen in the evaluation environment as per the problem description.
    # If it does, create a dummy dataframe to avoid crashing and ensure a score of 0.
    df_gold = pd.DataFrame(columns=['TERM_CODE', 'SUBJECT_ID_SORT', 'HIGH_ENROLLMENT'])

# --- 2. Feature Engineering & Preprocessing ---

final_validation_score = 0.0

if not df_gold.empty:
    # Aggregate section-level data to the course-offering level
    section_features = df_sections.groupby(['TERM_CODE', 'SUBJECT_ID_SORT']).agg(
        section_count=('SECTION_NBR', 'count'),
        total_seats=('ENRL_CAP', 'sum'),
        avg_seats_per_section=('ENRL_CAP', 'mean'),
        instructor_count=('INSTRUCTOR_EMPLID', 'nunique')
    ).reset_index()

    # Start building the feature matrix from the gold standard file
    df = pd.merge(df_gold, section_features, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')

    # Merge with course-level information
    df = pd.merge(df, df_courses, on='SUBJECT_ID_SORT', how='left')

    # Create SUBJECT_ID from SUBJECT_ID_SORT to merge with subjects table
    df['SUBJECT_ID'] = df['SUBJECT_ID_SORT'].apply(lambda x: re.split(r'\s+', x.strip())[0])

    # Merge with subject-level information
    df = pd.merge(df, df_subjects, on='SUBJECT_ID', how='left')

    # Merge with term-level information
    df = pd.merge(df, df_terms, on='TERM_CODE', how='left')

    # Create temporal features for the time-based split
    df['TERM_YEAR'] = df['TERM_CODE'].astype(str).str[:4].astype(int)
    df['TERM_SEASON'] = df['TERM_CODE'].astype(str).str[4:]

    # Encode target variable
    df['HIGH_ENROLLMENT'] = df['HIGH_ENROLLMENT'].apply(lambda x: 1 if x == 'Y' else 0)

    # Define features to be used in the model
    features = [
        'section_count', 'total_seats', 'avg_seats_per_section', 'instructor_count', # from sections
        'CATALOG_NBR', 'UNITS_MINIMUM', 'UNITS_MAXIMUM', 'COURSE_LEVEL',             # from courses
        'DEPT_NAME',                                                                # from subjects
        'TERM_DESCR', 'TERM_SEASON',                                                # from terms
        'SUBJECT_ID',                                                               # created feature
        'TERM_YEAR'                                                                 # for splitting
    ]
    
    # Filter for columns that actually exist in the merged dataframe
    final_features = [f for f in features if f in df.columns]
    
    # Create the final processed dataframe with features and target
    df_processed = df[final_features + ['HIGH_ENROLLMENT']].copy()

    # Preprocessing for TabPFN
    # 1. Fill missing values
    for col in df_processed.columns:
        if df_processed[col].dtype == 'object':
            df_processed[col] = df_processed[col].fillna('missing')
        else:
            # Simple imputation for numeric features. TabPFN can handle NaNs, but explicit filling is safer.
            df_processed[col] = df_processed[col].fillna(0)

    # 2. Encode all categorical (object) features to integers, as TabPFN requires numeric inputs
    for col in df_processed.columns:
        if df_processed[col].dtype == 'object':
            df_processed[col], _ = pd.factorize(df_processed[col])
    
    X = df_processed.drop(columns=['HIGH_ENROLLMENT'])
    y = df_processed['HIGH_ENROLLMENT']

    # --- 3. Model Training and Validation ---

    # Time-based split: Use the latest year for validation
    validation_year = X['TERM_YEAR'].max()
    train_indices = X[X['TERM_YEAR'] < validation_year].index
    val_indices = X[X['TERM_YEAR'] == validation_year].index
    
    # Fallback to a random split if only one year of data is available
    if len(train_indices) == 0 or len(val_indices) == 0:
        if len(X) > 1:
            X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
        else: # Not enough data to train or validate
            X_train, y_train = X, y
            X_val, y_val = pd.DataFrame(), pd.Series()
    else:
        X_train, X_val = X.loc[train_indices], X.loc[val_indices]
        y_train, y_val = y.loc[train_indices], y.loc[val_indices]

    # Drop the TERM_YEAR column after splitting is complete
    if 'TERM_YEAR' in X_train.columns:
        X_train = X_train.drop(columns=['TERM_YEAR'])
    if 'TERM_YEAR' in X_val.columns:
        X_val = X_val.drop(columns=['TERM_YEAR'])
    
    # TabPFN is designed for datasets up to 1024 training samples.
    # If our training set is larger, we must down-sample it.
    TABPFN_TRAINING_LIMIT = 1024
    if len(X_train) > TABPFN_TRAINING_LIMIT:
        sample_indices = X_train.sample(n=TABPFN_TRAINING_LIMIT, random_state=42).index
        X_train_sampled = X_train.loc[sample_indices]
        y_train_sampled = y_train.loc[sample_indices]
    else:
        X_train_sampled = X_train
        y_train_sampled = y_train

    # Proceed only if we have data to train and validate on
    if not X_train_sampled.empty and not X_val.empty:
        # Convert data to numpy arrays for the model
        X_train_np = X_train_sampled.to_numpy()
        y_train_np = y_train_sampled.to_numpy()
        X_val_np = X_val.to_numpy()

        # Initialize the TabPFN classifier. No hyperparameter tuning is needed.
        # N_ensemble_configurations=32 is a robust setting.
        clf = TabPFNClassifier(device='cpu', N_ensemble_configurations=32)

        # Train the model (which is a single forward pass for TabPFN)
        clf.fit(X_train_np, y_train_np)

        # Make predictions on the validation set
        y_pred, _ = clf.predict(X_val_np)

        # --- 4. Evaluation ---
        # Calculate the Macro F1 Score, which is suitable for potentially imbalanced binary classification
        final_validation_score = f1_score(y_val.to_numpy(), y_pred, average='macro')
    else:
        # If there's no data to validate on, the score is 0
        final_validation_score = 0.0

# --- 5. Output ---
# Print the final performance metric in the required format
print(f'Final Validation Performance: {final_validation_score}')
