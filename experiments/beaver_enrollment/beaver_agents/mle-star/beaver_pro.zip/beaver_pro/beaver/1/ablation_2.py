
import pandas as pd
import numpy as np
import os
import lightgbm as lgb
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score, precision_recall_curve
import warnings

warnings.filterwarnings('ignore')

# Define file paths
TRAIN_DATA_DIR = './input/'

def run_experiment(df, ablation_name="baseline"):
    """
    Runs a training and evaluation experiment with specified ablations.

    Args:
        df (pd.DataFrame): The input dataframe.
        ablation_name (str): Name of the ablation to run.
            - "baseline": Full model.
            - "no_section_count": Removes the 'SECTION_COUNT' feature.
            - "no_align": Removes the .align() step for one-hot encoded features.
            - "simple_threshold": Uses a fixed 0.5 threshold instead of optimized one.
    """
    if df.empty:
        return 0.0

    # --- 2. Data Preprocessing and Feature Engineering ---
    df['HIGH_ENROLLMENT'] = df['HIGH_ENROLLMENT'].apply(lambda x: 1 if x == 'Y' else 0)
    df['TERM_YEAR'] = df['TERM_CODE'].astype(str).str[:4].astype(int)
    df['TERM_SEASON'] = df['TERM_CODE'].astype(str).str[4:]
    
    if ablation_name != "no_section_count":
        df['SECTION_COUNT'] = 1

    season_map = {'SP': 1, 'SU': 2, 'FA': 3}
    df['TERM_SEASON_ORD'] = df['TERM_SEASON'].map(season_map).fillna(0).astype(int)
    df['TERM_SORTABLE'] = df['TERM_YEAR'] * 10 + df['TERM_SEASON_ORD']

    # --- 3. Feature Set Preparation ---
    features = [
        'TERM_YEAR',
        'TERM_SEASON',
        'SUBJECT_ID_SORT'
    ]
    if ablation_name != "no_section_count":
        features.append('SECTION_COUNT')
        
    target = 'HIGH_ENROLLMENT'

    X = df[features]
    y = df[target]

    X_lgb = X.copy()
    X_lgb['SUBJECT_ID_SORT'] = X_lgb['SUBJECT_ID_SORT'].astype('category')
    X_lgb['TERM_SEASON'] = X_lgb['TERM_SEASON'].astype('category')

    X_rf = pd.get_dummies(X, columns=['SUBJECT_ID_SORT', 'TERM_SEASON'], drop_first=True)

    # --- 4. Data Splitting ---
    if df['TERM_SORTABLE'].nunique() > 1:
        validation_term = df['TERM_SORTABLE'].max()
        train_indices = df[df['TERM_SORTABLE'] < validation_term].index
        val_indices = df[df['TERM_SORTABLE'] == validation_term].index
        if len(train_indices) == 0 or len(val_indices) == 0:
            train_indices, val_indices = train_test_split(df.index, test_size=0.2, random_state=42, stratify=y if y.nunique() > 1 else None)
    else:
        train_indices, val_indices = train_test_split(df.index, test_size=0.2, random_state=42, stratify=y if y.nunique() > 1 else None)

    y_train, y_val = y.loc[train_indices], y.loc[val_indices]
    X_train_lgb, X_val_lgb = X_lgb.loc[train_indices], X_lgb.loc[val_indices]
    X_train_rf, X_val_rf = X_rf.loc[train_indices], X_rf.loc[val_indices]

    if ablation_name != "no_align":
        X_train_rf, X_val_rf = X_train_rf.align(X_val_rf, join='left', axis=1, fill_value=0)

    # --- 5. Model Training, Ensembling, and Validation ---
    final_score = 0.0
    if not X_val_lgb.empty and y_train.nunique() > 1:
        try:
            model_lgb = lgb.LGBMClassifier(objective='binary', metric='binary_logloss', class_weight='balanced', random_state=42)
            model_lgb.fit(X_train_lgb, y_train, categorical_feature=['SUBJECT_ID_SORT', 'TERM_SEASON'])
            y_pred_proba_lgb = model_lgb.predict_proba(X_val_lgb)[:, 1]

            model_rf = RandomForestClassifier(class_weight='balanced', random_state=42, n_estimators=100)
            model_rf.fit(X_train_rf, y_train)
            y_pred_proba_rf = model_rf.predict_proba(X_val_rf)[:, 1]

            y_pred_val = None
            if ablation_name == "simple_threshold":
                best_f1 = -1
                for w in np.arange(0, 1.01, 0.01):
                    y_pred_proba_ensemble_temp = w * y_pred_proba_rf + (1 - w) * y_pred_proba_lgb
                    y_pred_val_temp = (y_pred_proba_ensemble_temp > 0.5).astype(int)
                    current_f1 = f1_score(y_val, y_pred_val_temp)
                    if current_f1 > best_f1:
                        best_f1 = current_f1
                        best_weight = w
                
                y_pred_proba_ensemble = (best_weight * y_pred_proba_rf + (1 - best_weight) * y_pred_proba_lgb)
                y_pred_val = (y_pred_proba_ensemble > 0.5).astype(int)

            else: # Baseline and all other ablations use joint optimization
                best_f1, best_weight, best_threshold = -1, 0, 0.5
                for w in np.linspace(0, 1, 101):
                    y_pred_proba_ensemble_w = w * y_pred_proba_rf + (1 - w) * y_pred_proba_lgb
                    precisions, recalls, thresholds = precision_recall_curve(y_val, y_pred_proba_ensemble_w)
                    f1_scores = np.divide(2 * precisions * recalls, precisions + recalls, out=np.zeros_like(precisions), where=(precisions + recalls) != 0)
                    if len(f1_scores) > 1:
                        best_f1_idx = np.argmax(f1_scores[:-1])
                        if f1_scores[best_f1_idx] > best_f1:
                            best_f1 = f1_scores[best_f1_idx]
                            best_weight = w
                            if len(thresholds) > best_f1_idx:
                                best_threshold = thresholds[best_f1_idx]
                
                y_pred_proba_ensemble = (best_weight * y_pred_proba_rf + (1 - best_weight) * y_pred_proba_lgb)
                y_pred_val = (y_pred_proba_ensemble > best_threshold).astype(int)
            
            if y_pred_val is not None:
                final_score = f1_score(y_val, y_pred_val, average='macro')
        
        except ValueError as e:
            # This can happen in the "no_align" case if features mismatch
            print(f"Error during {ablation_name} experiment: {e}")
            return 0.0

    return final_score


# --- Main Ablation Study Execution ---

# Load data once
try:
    main_df = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv'))
except FileNotFoundError:
    print("Error: 'gold_enrollment_train.csv' not found in './input/'. Please place the data in the correct directory.")
    main_df = pd.DataFrame()


results = {}

if not main_df.empty:
    # 1. Baseline experiment
    baseline_score = run_experiment(main_df.copy(), ablation_name="baseline")
    results['Baseline (Full Model)'] = baseline_score
    print(f"Baseline (Full Model) Macro F1-Score: {baseline_score:.4f}")
    
    # 2. Ablation: Remove the placeholder 'SECTION_COUNT' feature
    no_section_count_score = run_experiment(main_df.copy(), ablation_name="no_section_count")
    results['Ablation (No SECTION_COUNT feature)'] = no_section_count_score
    print(f"Ablation (No SECTION_COUNT feature) Macro F1-Score: {no_section_count_score:.4f}")

    # 3. Ablation: Use simple 0.5 threshold instead of optimized threshold
    simple_threshold_score = run_experiment(main_df.copy(), ablation_name="simple_threshold")
    results['Ablation (Simple 0.5 Threshold)'] = simple_threshold_score
    print(f"Ablation (Simple 0.5 Threshold) Macro F1-Score: {simple_threshold_score:.4f}")

    # 4. Ablation: Remove the .align() step for one-hot encoded features
    no_align_score = run_experiment(main_df.copy(), ablation_name="no_align")
    results['Ablation (No .align() step)'] = no_align_score
    print(f"Ablation (No .align() step) Macro F1-Score: {no_align_score:.4f}")


    # --- Conclusion ---
    if results:
        # Calculate performance drops
        delta_section = baseline_score - no_section_count_score
        delta_threshold = baseline_score - simple_threshold_score
        delta_align = baseline_score - no_align_score

        impact = {
            "Joint Threshold/Weight Optimization": delta_threshold,
            "Placeholder 'SECTION_COUNT' feature": delta_section,
            "`.align()` step for OHE features": delta_align,
        }
        
        # Find the component with the largest performance drop
        most_impactful_component = max(impact, key=impact.get)
        
        print("\n--- Ablation Study Conclusion ---")
        print(f"The component that contributes most to the overall performance is the '{most_impactful_component}'.")
        print(f"Removing it caused the largest performance drop of {impact[most_impactful_component]:.4f}.")

