
import pandas as pd
import numpy as np
import os
import re
import lightgbm as lgb
from tabpfn import TabPFNClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score
import warnings

# Suppress potential warnings from TabPFN about model loading
warnings.filterwarnings("ignore", category=UserWarning)

# Define file paths
# All input data is expected to be in the './input/' directory.
TRAIN_DATA_DIR = './input/'

# --- 1. Load Data (from Reference Solution) ---
# This section adopts the more comprehensive data loading from the reference solution.
try:
    df_gold = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'gold_enrollment_train.csv'))
    df_courses = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'courses.csv'))
    df_sections = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'sections.csv'))
    df_subjects = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'subjects.csv'))
    df_terms = pd.read_csv(os.path.join(TRAIN_DATA_DIR, 'terms.csv'))
except FileNotFoundError:
    # If any data file is missing, we can't proceed with feature engineering.
    # Create a dummy dataframe to avoid crashing and ensure a score of 0.
    df_gold = pd.DataFrame(columns=['TERM_CODE', 'SUBJECT_ID_SORT', 'HIGH_ENROLLMENT'])

final_validation_score = 0.0

# Proceed only if the core data file was loaded successfully.
if not df_gold.empty:
    # --- 2. Feature Engineering (from Reference Solution) ---

    # Aggregate section-level data
    section_features = df_sections.groupby(['TERM_CODE', 'SUBJECT_ID_SORT']).agg(
        section_count=('SECTION_NBR', 'count'),
        total_seats=('ENRL_CAP', 'sum'),
        avg_seats_per_section=('ENRL_CAP', 'mean'),
        instructor_count=('INSTRUCTOR_EMPLID', 'nunique')
    ).reset_index()

    # Start building the main dataframe from the gold standard file
    df = pd.merge(df_gold, section_features, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')

    # Merge with other data sources
    df = pd.merge(df, df_courses, on='SUBJECT_ID_SORT', how='left')
    df['SUBJECT_ID'] = df['SUBJECT_ID_SORT'].apply(lambda x: re.split(r'\s+', x.strip())[0])
    df = pd.merge(df, df_subjects, on='SUBJECT_ID', how='left')
    df = pd.merge(df, df_terms, on='TERM_CODE', how='left')

    # Create temporal features
    df['TERM_YEAR'] = df['TERM_CODE'].astype(str).str[:4].astype(int)
    df['TERM_SEASON'] = df['TERM_CODE'].astype(str).str[4:]

    # --- 3. Data Preprocessing (Combined Approach) ---

    # Encode the target variable
    df['HIGH_ENROLLMENT'] = df['HIGH_ENROLLMENT'].apply(lambda x: 1 if x == 'Y' else 0)

    # Define features to be used in the models
    features = [
        'section_count', 'total_seats', 'avg_seats_per_section', 'instructor_count', # from sections
        'CATALOG_NBR', 'UNITS_MINIMUM', 'UNITS_MAXIMUM', 'COURSE_LEVEL',             # from courses
        'DEPT_NAME',                                                                # from subjects
        'TERM_DESCR', 'TERM_SEASON',                                                # from terms
        'SUBJECT_ID',                                                               # created feature
        'TERM_YEAR'                                                                 # for splitting
    ]
    
    # Filter for columns that actually exist in the merged dataframe
    final_features = [f for f in features if f in df.columns]
    
    # Create the final processed dataframe with features and target
    df_processed = df[final_features + ['HIGH_ENROLLMENT']].copy()

    # Preprocessing for compatibility with both models
    # 1. Fill missing values (from Reference Solution)
    categorical_feature_names = []
    for col in df_processed.columns:
        if df_processed[col].dtype == 'object':
            df_processed[col] = df_processed[col].fillna('missing')
            categorical_feature_names.append(col)
        elif col not in ['HIGH_ENROLLMENT', 'TERM_YEAR']:
            # Simple imputation for numeric features.
            df_processed[col] = df_processed[col].fillna(0)

    # 2. Encode all categorical (object) features to integers for TabPFN compatibility
    # LGBM can also handle these if told which columns are categorical
    for col in categorical_feature_names:
        df_processed[col], _ = pd.factorize(df_processed[col])

    X = df_processed.drop(columns=['HIGH_ENROLLMENT'])
    y = df_processed['HIGH_ENROLLMENT']

    # --- 4. Model Training and Validation ---

    # Time-based split for validation: use the latest year as the validation set.
    validation_year = X['TERM_YEAR'].max()
    train_indices = X[X['TERM_YEAR'] < validation_year].index
    val_indices = X[X['TERM_YEAR'] == validation_year].index

    # Fallback to a random split if only one year of data is available
    if len(val_indices) == 0 or len(train_indices) == 0:
        if len(X) > 1:
            X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
        else: # Not enough data to train or validate
            X_train, y_train = X, y
            X_val, y_val = pd.DataFrame(), pd.Series()
    else:
        X_train, X_val = X.loc[train_indices], X.loc[val_indices]
        y_train, y_val = y.loc[train_indices], y.loc[val_indices]

    # Drop the TERM_YEAR column after splitting is complete
    if 'TERM_YEAR' in X_train.columns:
        X_train = X_train.drop(columns=['TERM_YEAR'])
    if 'TERM_YEAR' in X_val.columns:
        X_val = X_val.drop(columns=['TERM_YEAR'])

    if not X_val.empty:
        # --- Model 1: LightGBM (from Base Solution) ---
        lgbm_cat_features = [col for col in categorical_feature_names if col in X_train.columns]
        
        model_lgbm = lgb.LGBMClassifier(objective='binary',
                                      metric='binary_logloss',
                                      class_weight='balanced',
                                      random_state=42)
                                      
        # Tell LGBM which integer-encoded columns are categorical
        model_lgbm.fit(X_train, y_train, categorical_feature=lgbm_cat_features)
        probs_lgbm = model_lgbm.predict_proba(X_val)[:, 1]

        # --- Model 2: TabPFN (from Reference Solution) ---
        # TabPFN is designed for datasets up to 1024 training samples.
        TABPFN_TRAINING_LIMIT = 1024
        if len(X_train) > TABPFN_TRAINING_LIMIT:
            sample_indices = X_train.sample(n=TABPFN_TRAINING_LIMIT, random_state=42).index
            X_train_sampled = X_train.loc[sample_indices]
            y_train_sampled = y_train.loc[sample_indices]
        else:
            X_train_sampled = X_train
            y_train_sampled = y_train

        probs_tabpfn = np.zeros_like(y_val, dtype=float)
        if not X_train_sampled.empty:
            # Convert data to numpy arrays for the model
            X_train_np = X_train_sampled.to_numpy()
            y_train_np = y_train_sampled.to_numpy()
            X_val_np = X_val.to_numpy()

            # Initialize and train the TabPFN classifier
            model_tabpfn = TabPFNClassifier(device='cpu', N_ensemble_configurations=32)
            model_tabpfn.fit(X_train_np, y_train_np)
            
            # Predict probabilities on the validation set
            probs_tabpfn = model_tabpfn.predict_proba(X_val_np)[:, 1]

        # --- 5. Ensembling and Evaluation ---
        
        # Simple averaging of probabilities (soft voting)
        avg_probs = (probs_lgbm + probs_tabpfn) / 2
        
        # Convert probabilities to binary predictions
        ensembled_preds = (avg_probs >= 0.5).astype(int)

        # Calculate the Macro F1 Score on ensembled predictions
        final_validation_score = f1_score(y_val, ensembled_preds, average='macro')

# Print the final performance metric in the required format
print(f'Final Validation Performance: {final_validation_score}')
