import argparse
import os
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
from sklearn.preprocessing import LabelEncoder, StandardScaler

def load_and_preprocess_data(data_dir, is_train=True):
    """Loads and preprocesses data from a given directory."""
    print(f"Loading data from {data_dir}...")
    
    # Define paths
    summary_path = os.path.join(data_dir, 'SUBJECT_OFFERED_SUMMARY.csv')
    history_path = os.path.join(data_dir, 'ENROLLMENT_HISTORY_FEATURES.csv')
    
    # Load core tables
    df_summary = pd.read_csv(summary_path, low_memory=False)
    df_history = pd.read_csv(history_path)

    if is_train:
        gold_path = os.path.join(data_dir, 'gold_enrollment_train.csv')
        df_gold = pd.read_csv(gold_path)
        # Merge for training
        df = pd.merge(df_gold, df_summary, on=['TERM_CODE', 'SUBJECT_ID_SORT'])
        df = pd.merge(df, df_history, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')
    else:
        # For test set, keys are in summary. Merge history features.
        df = pd.merge(df_summary, df_history, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')

    # --- Feature Engineering ---
    print("Engineering features...")
    
    # Convert bools to int
    for col in df.columns:
        if df[col].dtype == 'bool':
            df[col] = df[col].astype(int)

    # Fill NaNs
    for col in df.select_dtypes(include=['number']).columns:
        df[col] = df[col].fillna(0) # Fill with 0 instead of median
        
    for col in df.select_dtypes(include=['object']).columns:
        if col not in ['TERM_CODE', 'SUBJECT_ID_SORT', 'HIGH_ENROLLMENT']:
            df[col] = df[col].fillna('missing')

    # Label encode categorical features that are not identifiers or the target
    categorical_cols = df.select_dtypes(include=['object', 'category']).columns
    for col in categorical_cols:
        if col not in ['TERM_CODE', 'SUBJECT_ID_SORT', 'HIGH_ENROLLMENT']:
            df[col] = LabelEncoder().fit_transform(df[col].astype(str))
            
    return df

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train-dir", default="train")
    parser.add_argument("--test-dir")
    args = parser.parse_args()

    # --- Load and Preprocess Training Data ---
    train_df_full = load_and_preprocess_data(args.train_dir, is_train=True)
    features = [col for col in train_df_full.columns if col not in ['TERM_CODE', 'SUBJECT_ID_SORT', 'HIGH_ENROLLMENT']]
    
    if args.test_dir:
        # Train on the entire dataset for final submission
        print("Training on full dataset for test prediction...")
        X_train = train_df_full[features]
        y_train = train_df_full['HIGH_ENROLLMENT'].apply(lambda x: 1 if x == 'Y' else 0)
    else:
        # Perform time-based split for validation
        terms = sorted(train_df_full['TERM_CODE'].unique())
        train_terms, val_term = terms[:-1], terms[-1]
        
        train_df = train_df_full[train_df_full['TERM_CODE'].isin(train_terms)]
        val_df = train_df_full[train_df_full['TERM_CODE'] == val_term]
        
        print(f"Training on terms: {train_terms}")
        print(f"Validating on term: {val_term}")

        X_train = train_df[features]
        y_train = train_df['HIGH_ENROLLMENT'].apply(lambda x: 1 if x == 'Y' else 0)
        X_val = val_df[features]
        y_val = val_df['HIGH_ENROLLMENT'].apply(lambda x: 1 if x == 'Y' else 0)

    # --- Scaling and Model Training ---
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    
    print("Training model...")
    model = LogisticRegression(random_state=42, max_iter=2000, class_weight='balanced')
    model.fit(X_train_scaled, y_train)

    # --- Prediction and Evaluation ---
    if args.test_dir:
        print(f"Generating predictions for test set: {args.test_dir}")
        test_df = load_and_preprocess_data(args.test_dir, is_train=False)
        submission_keys = test_df[['TERM_CODE', 'SUBJECT_ID_SORT']].copy() # Store keys
        
        # Align columns
        missing_cols = set(X_train.columns) - set(test_df.columns)
        for c in missing_cols:
            test_df[c] = 0
        test_df = test_df[X_train.columns]

        X_test_scaled = scaler.transform(test_df)
        predictions = model.predict(X_test_scaled)
        
        submission_df = submission_keys
        submission_df['HIGH_ENROLLMENT'] = ['Y' if p == 1 else 'N' for p in predictions]
    else:
        print("Generating predictions for validation set and evaluating...")
        X_val_scaled = scaler.transform(X_val)
        val_predictions = model.predict(X_val_scaled)
        
        f1 = f1_score(y_val, val_predictions, average='macro')
        print(f"\nValidation Macro F1 Score: {f1:.4f}\n")
        
        submission_df = val_df[['TERM_CODE', 'SUBJECT_ID_SORT']].copy()
        submission_df['HIGH_ENROLLMENT'] = ['Y' if p == 1 else 'N' for p in val_predictions]

    # --- Save Submission ---
    print("Saving submission file to submission.csv...")
    submission_df.to_csv('submission.csv', index=False)
    print("Done.")

if __name__ == "__main__":
    main()
