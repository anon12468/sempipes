import argparse
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
from sklearn.preprocessing import LabelEncoder

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train-dir", default="train")
    parser.add_argument("--test-dir")
    args = parser.parse_args()

    # Load training data
    features_df = pd.read_csv(f"{args.train_dir}/ENROLLMENT_HISTORY_FEATURES.csv")
    labels_df = pd.read_csv(f"{args.train_dir}/gold_enrollment_train.csv")
    
    # Merge features and labels
    train_df = pd.merge(features_df, labels_df, on=["TERM_CODE", "SUBJECT_ID_SORT"])

    # Feature selection and preprocessing
    features = ['lag1_enrollment', 'lag2_enrollment', 'roll3_enrollment_mean']
    target = 'HIGH_ENROLLMENT'
    
    train_df[features] = train_df[features].fillna(0)

    le = LabelEncoder()
    train_df[target] = le.fit_transform(train_df[target]) # Y -> 1, N -> 0

    # Time-based validation split
    # Sort by term to ensure we split chronologically
    terms = pd.read_csv(f"{args.train_dir}/ACADEMIC_TERMS.csv")
    term_order = terms.sort_values('TERM_START_DATE')['TERM_CODE'].unique()
    train_df['TERM_CODE_ORDER'] = pd.Categorical(train_df['TERM_CODE'], categories=term_order, ordered=True)
    train_df = train_df.sort_values('TERM_CODE_ORDER')
    
    # Use last ~20% of terms for validation
    val_terms = term_order[-int(len(term_order) * 0.2):]
    train_indices = train_df[~train_df['TERM_CODE'].isin(val_terms)].index
    val_indices = train_df[train_df['TERM_CODE'].isin(val_terms)].index

    X = train_df[features]
    y = train_df[target]

    X_train, X_val = X.loc[train_indices], X.loc[val_indices]
    y_train, y_val = y.loc[train_indices], y.loc[val_indices]

    print(f"Training on {len(X_train)} samples, validating on {len(X_val)} samples.")

    # Train a model
    model = LogisticRegression(random_state=42, class_weight='balanced')
    model.fit(X_train, y_train)

    # Evaluate on validation set
    val_preds = model.predict(X_val)
    f1 = f1_score(y_val, val_preds, average='macro')
    print(f"Validation Macro F1: {f1:.4f}")

    # --- Prediction Phase ---
    if args.test_dir:
        print(f"Generating predictions for test data in {args.test_dir}")
        # Retrain on full training data
        model.fit(X, y)
        
        # Load test features
        test_features_df = pd.read_csv(f"{args.test_dir}/ENROLLMENT_HISTORY_FEATURES.csv")
        test_features_df = test_features_df.fillna(0)

        # Predict
        test_preds = model.predict(test_features_df[features])
        
        # Format submission file
        submission_df = test_features_df[['TERM_CODE', 'SUBJECT_ID_SORT']].copy()
        submission_df['HIGH_ENROLLMENT'] = le.inverse_transform(test_preds)
        submission_df.to_csv("submission.csv", index=False)
        print("submission.csv created for the test set.")

    else:
        # Create submission for the validation set to check with the provided script
        print("Generating submission.csv for the full training set.")
        submission_df = train_df[['TERM_CODE', 'SUBJECT_ID_SORT']].copy()
        # Retrain on full data to generate predictions for the entire training set
        model.fit(X, y)
        all_train_preds = model.predict(X)
        submission_df['HIGH_ENROLLMENT'] = le.inverse_transform(all_train_preds)
        submission_df.to_csv("submission.csv", index=False)
        print("submission.csv created for the full training set.")


if __name__ == "__main__":
    main()

