import argparse
import pandas as pd
import os
import numpy as np
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import f1_score

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train-dir", default="train")
    parser.add_argument("--test-dir", default=None)
    parser.add_argument("--pred-path", default="submission.csv")
    args = parser.parse_args()

    # --- Load Data ---
    print("Loading data...")
    train_dir = args.train_dir
    gold_labels = pd.read_csv(os.path.join(train_dir, 'gold_enrollment_train.csv'))
    enrollment_history = pd.read_csv(os.path.join(train_dir, 'ENROLLMENT_HISTORY_FEATURES.csv'))
    
    data = pd.merge(gold_labels, enrollment_history, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')

    # --- Feature Engineering ---
    print("Engineering features...")
    data['YEAR'] = data['TERM_CODE'].str[:4].astype(int)
    data['SEMESTER'] = data['TERM_CODE'].str[4:]
    semester_map = {'FA': 0, 'SP': 1, 'JA': 2, 'SU': 3}
    data['SEMESTER_CODE'] = data['SEMESTER'].map(semester_map).fillna(4).astype(int)

    # --- Preprocessing ---
    print("Preprocessing data...")
    data['HIGH_ENROLLMENT_LABEL'] = data['HIGH_ENROLLMENT'].apply(lambda x: 1 if x == 'Y' else 0)

    features = [
        'lag1_enrollment', 'lag2_enrollment', 'roll3_enrollment_mean',
        'YEAR', 'SEMESTER_CODE'
    ]
    target = 'HIGH_ENROLLMENT_LABEL'

    for col in features:
        if data[col].isnull().any():
            data[col] = data[col].fillna(0)

    # --- Model Training ---
    if args.test_dir:
        # If making test predictions, train on the full training data
        print("Training model on full training data...")
        X_train_full = data[features]
        y_train_full = data[target]
        
        # We still need a validation set to find the best number of boosting rounds
        all_years = sorted(data['YEAR'].unique())
        val_year = all_years[-1]
        train_indices = data[data['YEAR'] < val_year].index
        val_indices = data[data['YEAR'] == val_year].index

        X_train_split = data.loc[train_indices, features]
        y_train_split = data.loc[train_indices, target]
        X_val_split = data.loc[val_indices, features]
        y_val_split = data.loc[val_indices, target]

        temp_model = lgb.LGBMClassifier(objective='binary', random_state=42)
        temp_model.fit(X_train_split, y_train_split,
                  eval_set=[(X_val_split, y_val_split)],
                  eval_metric='logloss',
                  callbacks=[lgb.early_stopping(100, verbose=False)])
        
        best_iteration = temp_model.best_iteration_
        print(f"Found best iteration: {best_iteration}")

        model = lgb.LGBMClassifier(objective='binary', random_state=42, n_estimators=best_iteration if best_iteration else 100)
        model.fit(X_train_full, y_train_full)

    else:
        # If just validating, use a time-based split
        print("Splitting data for validation...")
        all_years = sorted(data['YEAR'].unique())
        val_year = all_years[-1]
        
        train_data = data[data['YEAR'] < val_year]
        val_data = data[data['YEAR'] == val_year]

        X_train = train_data[features]
        y_train = train_data[target]
        X_val = val_data[features]
        y_val = val_data[target]
        
        print(f"Training on years < {val_year}. Validating on year {val_year}.")
        print(f"Train shape: {X_train.shape}, Validation shape: {X_val.shape}")

        model = lgb.LGBMClassifier(objective='binary', random_state=42)
        model.fit(X_train, y_train,
                  eval_set=[(X_val, y_val)],
                  eval_metric='logloss',
                  callbacks=[lgb.early_stopping(100, verbose=False)])

        print("Evaluating model...")
        val_preds = model.predict(X_val)
        f1 = f1_score(y_val, val_preds, average='macro')
        print(f"Validation Macro F1 Score: {f1:.4f}")

    # --- Prediction Generation ---
    if args.test_dir:
        print(f"Generating predictions for test set: {args.test_dir}")
        test_summary_path = os.path.join(args.test_dir, 'SUBJECT_OFFERED_SUMMARY.csv')
        test_keys = pd.read_csv(test_summary_path, usecols=['TERM_CODE', 'SUBJECT_ID_SORT'], encoding='latin-1')
        
        test_enrollment_history = pd.read_csv(os.path.join(args.test_dir, 'ENROLLMENT_HISTORY_FEATURES.csv'))
        test_data = pd.merge(test_keys, test_enrollment_history, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')
        
        test_data['YEAR'] = test_data['TERM_CODE'].str[:4].astype(int)
        test_data['SEMESTER'] = test_data['TERM_CODE'].str[4:]
        test_data['SEMESTER_CODE'] = test_data['SEMESTER'].map(semester_map).fillna(4).astype(int)
        
        for col in features:
            if test_data[col].isnull().any():
                test_data[col] = test_data[col].fillna(0)
        
        X_test = test_data[features]
        test_preds = model.predict(X_test)
        
        submission = test_data[['TERM_CODE', 'SUBJECT_ID_SORT']].copy()
        submission['HIGH_ENROLLMENT'] = np.where(test_preds == 1, 'Y', 'N')

    else:
        print("Generating predictions for the full training set...")
        full_train_preds = model.predict(data[features])
        submission = data[['TERM_CODE', 'SUBJECT_ID_SORT']].copy()
        submission['HIGH_ENROLLMENT'] = np.where(full_train_preds == 1, 'Y', 'N')

    print(f"Writing submission to {args.pred_path}")
    submission.to_csv(args.pred_path, index=False)
    print("Done.")

if __name__ == "__main__":
    main()
