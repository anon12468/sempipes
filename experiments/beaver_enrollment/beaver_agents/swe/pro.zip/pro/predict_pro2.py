import argparse
import os
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score

def load_data(data_dir, is_train=True):
    """Loads all necessary CSVs from the given directory."""
    dfs = {}
    
    # Load core tables for features and keys
    summary_path = os.path.join(data_dir, "SUBJECT_OFFERED_SUMMARY.csv")
    if os.path.exists(summary_path):
        dfs['SUBJECT_OFFERED_SUMMARY'] = pd.read_csv(summary_path)

    # Load labels only for the training set
    if is_train:
        gold_labels_path = os.path.join(data_dir, "gold_enrollment_train.csv")
        dfs['gold_enrollment_train'] = pd.read_csv(gold_labels_path)
        
        terms_path = os.path.join(data_dir, "ACADEMIC_TERMS.csv")
        dfs['ACADEMIC_TERMS'] = pd.read_csv(terms_path)

        history_path = os.path.join(data_dir, "ENROLLMENT_HISTORY_FEATURES.csv")
        dfs['ENROLLMENT_HISTORY_FEATURES'] = pd.read_csv(history_path)

    return dfs

def feature_engineering(keys_df, train_dfs, test_dfs=None):
    """Creates features for the given keys."""
    
    # Use historical features from the training set
    history_features = train_dfs['ENROLLMENT_HISTORY_FEATURES']
    data = pd.merge(keys_df, history_features, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')

    # Use course level from both train and test to have all possible levels
    train_summary = train_dfs['SUBJECT_OFFERED_SUMMARY'][['SUBJECT_ID_SORT', 'HGN_CODE']].drop_duplicates('SUBJECT_ID_SORT')
    
    all_summaries = [train_summary]
    if test_dfs and 'SUBJECT_OFFERED_SUMMARY' in test_dfs:
        test_summary = test_dfs['SUBJECT_OFFERED_SUMMARY'][['SUBJECT_ID_SORT', 'HGN_CODE']].drop_duplicates('SUBJECT_ID_SORT')
        all_summaries.append(test_summary)

    full_summary = pd.concat(all_summaries).drop_duplicates('SUBJECT_ID_SORT')
    
    data = pd.merge(data, full_summary, on='SUBJECT_ID_SORT', how='left')

    # Impute and Encode
    for col in data.select_dtypes(include=np.number).columns:
        if data[col].isnull().any():
            data[col] = data[col].fillna(data[col].median())

    data = pd.get_dummies(data, columns=['HGN_CODE'], dummy_na=True, dtype=int)
    
    return data

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train-dir", default="train")
    parser.add_argument("--test-dir", default=None)
    parser.add_argument("--pred-file", default="submission.csv")
    args = parser.parse_args()

    # Load data
    train_dfs = load_data(args.train_dir, is_train=True)
    test_dfs = load_data(args.test_dir, is_train=False) if args.test_dir else None

    # Time-based split for validation
    academic_terms = train_dfs['ACADEMIC_TERMS'].sort_values('TERM_START_DATE', ascending=True)
    all_train_term_codes = academic_terms['TERM_CODE'].unique()
    
    # Hold out the latest year (approx 4 terms) for validation
    val_term_codes = all_train_term_codes[-4:]
    train_term_codes = all_train_term_codes[:-4]

    gold_labels = train_dfs['gold_enrollment_train']
    train_keys = gold_labels[gold_labels['TERM_CODE'].isin(train_term_codes)]
    val_keys = gold_labels[gold_labels['TERM_CODE'].isin(val_term_codes)]

    # Feature Engineering
    train_data = feature_engineering(train_keys, train_dfs, test_dfs)
    val_data = feature_engineering(val_keys, train_dfs, test_dfs)

    # Align columns
    train_cols = set(train_data.columns)
    val_cols = set(val_data.columns)
    
    for col in (train_cols - val_cols):
        if col != 'HIGH_ENROLLMENT':
            val_data[col] = 0
    for col in (val_cols - train_cols):
        if col != 'HIGH_ENROLLMENT':
            train_data[col] = 0
            
    val_data = val_data[train_data.columns]

    # Define features and target
    target_col = 'HIGH_ENROLLMENT'
    feature_cols = [col for col in train_data.columns if col not in ['TERM_CODE', 'SUBJECT_ID_SORT', target_col]]
    
    train_data[target_col] = train_data[target_col].map({'Y': 1, 'N': 0})
    val_data[target_col] = val_data[target_col].map({'Y': 1, 'N': 0})

    X_train, y_train = train_data[feature_cols], train_data[target_col]
    X_val, y_val = val_data[feature_cols], val_data[target_col]
    
    # Train model
    model = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1, class_weight='balanced')
    model.fit(X_train, y_train)

    # Evaluate
    val_preds = model.predict(X_val)
    f1 = f1_score(y_val, val_preds, average='macro')
    print(f"Validation Macro F1: {f1:.4f}")

    # Generate submission file
    if args.test_dir:
        print("Generating predictions for test set...")
        pred_keys = test_dfs['SUBJECT_OFFERED_SUMMARY'][['TERM_CODE', 'SUBJECT_ID_SORT']].drop_duplicates()
        pred_data = feature_engineering(pred_keys, train_dfs, test_dfs)
    else:
        print("Generating predictions for train set...")
        pred_keys = gold_labels[['TERM_CODE', 'SUBJECT_ID_SORT']]
        pred_data = feature_engineering(pred_keys, train_dfs, test_dfs)

    # Align prediction data columns with training data
    pred_cols = set(pred_data.columns)
    for col in (set(X_train.columns) - pred_cols):
        pred_data[col] = 0
    pred_data = pred_data[X_train.columns]

    predictions = model.predict(pred_data)
    
    submission_df = pred_keys.copy()
    submission_df[target_col] = np.where(predictions == 1, 'Y', 'N')
    submission_df.to_csv(args.pred_file, index=False)
    print(f"Predictions saved to {args.pred_file}")

if __name__ == "__main__":
    main()
