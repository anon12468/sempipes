import argparse
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
from sklearn.metrics import f1_score
import bisect

def load_data(path, columns=None):
    """Load a CSV file from the given path."""
    return pd.read_csv(path, low_memory=False, usecols=columns)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train-dir", default="train")
    parser.add_argument("--test-dir", default=None)
    args = parser.parse_args()

    is_test_run = args.test_dir is not None
    
    if is_test_run:
        print("Running in inference mode for test set.")
        # Load test keys
        subject_summary_test = load_data(f"{args.test_dir}/SUBJECT_OFFERED_SUMMARY.csv")
        data = subject_summary_test[['TERM_CODE', 'SUBJECT_ID_SORT']].copy().drop_duplicates()
        
        # Load necessary feature tables from test
        enrollment_history_test = load_data(f"{args.test_dir}/ENROLLMENT_HISTORY_FEATURES.csv")
        
        # Merge features for test data
        data = pd.merge(data, enrollment_history_test, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")
        data = pd.merge(data, subject_summary_test, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")
    else:
        print("Running in training/validation mode.")
        # Load training data and labels
        gold_enrollment = load_data(f"{args.train_dir}/gold_enrollment_train.csv")
        enrollment_history_train = load_data(f"{args.train_dir}/ENROLLMENT_HISTORY_FEATURES.csv")
        subject_summary_train = load_data(f"{args.train_dir}/SUBJECT_OFFERED_SUMMARY.csv")
        
        # Merge training data
        data = pd.merge(gold_enrollment, enrollment_history_train, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")
        data = pd.merge(data, subject_summary_train, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")

    print("Performing feature engineering...")
    data['TERM_YEAR'] = data['TERM_CODE'].str[:4].astype(int)
    data['TERM_SEASON'] = data['TERM_CODE'].str[4:]
    
    # Fill missing values
    for col in ['lag1_enrollment', 'lag2_enrollment', 'roll3_enrollment_mean', 'TOTAL_UNITS', 'LECTURE_UNITS', 'LAB_UNITS', 'PREPARATION_UNITS']:
        data[col] = data[col].fillna(0)

    data['enrollment_trend'] = data['lag1_enrollment'] - data['lag2_enrollment']

    # Historical average enrollment feature
    print("Calculating historical average enrollment...")
    subject_enrollment_train = load_data(f"{args.train_dir}/SUBJECT_SUMMARY.csv", columns=['MASTER_SUBJECT_ID_SORT', 'SUBJECT_ENROLLMENT_FIFTH_WEEK'])
    historical_avg = subject_enrollment_train.groupby('MASTER_SUBJECT_ID_SORT')['SUBJECT_ENROLLMENT_FIFTH_WEEK'].mean().reset_index()
    historical_avg = historical_avg.rename(columns={'SUBJECT_ENROLLMENT_FIFTH_WEEK': 'historical_avg_enrollment'})
    
    data = pd.merge(data, historical_avg, on='MASTER_SUBJECT_ID_SORT', how='left')
    data['historical_avg_enrollment'] = data['historical_avg_enrollment'].fillna(0)

    # Prepare for model training/prediction
    categorical_features = ['OFFER_DEPT_CODE', 'TERM_SEASON', 'CLUSTER_TYPE', 'HGN_CODE', 'OFFER_SCHOOL_NAME']
    features = [
        'lag1_enrollment', 'lag2_enrollment', 'roll3_enrollment_mean',
        'TOTAL_UNITS', 'LECTURE_UNITS', 'LAB_UNITS', 'PREPARATION_UNITS',
        'enrollment_trend', 'historical_avg_enrollment'
    ] + categorical_features

    if is_test_run:
        # Load full training data to fit encoders and model
        print("Loading full training data for final model training...")
        train_gold = load_data(f"{args.train_dir}/gold_enrollment_train.csv")
        train_hist = load_data(f"{args.train_dir}/ENROLLMENT_HISTORY_FEATURES.csv")
        train_subj_summ = load_data(f"{args.train_dir}/SUBJECT_OFFERED_SUMMARY.csv")
        
        train_data = pd.merge(train_gold, train_hist, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")
        train_data = pd.merge(train_data, train_subj_summ, on=["TERM_CODE", "SUBJECT_ID_SORT"], how="left")
        
        train_data['TERM_SEASON'] = train_data['TERM_CODE'].str[4:]
        for col in ['lag1_enrollment', 'lag2_enrollment', 'roll3_enrollment_mean', 'TOTAL_UNITS', 'LECTURE_UNITS', 'LAB_UNITS', 'PREPARATION_UNITS']:
            train_data[col] = train_data[col].fillna(0)
        train_data['enrollment_trend'] = train_data['lag1_enrollment'] - train_data['lag2_enrollment']
        train_data = pd.merge(train_data, historical_avg, on='MASTER_SUBJECT_ID_SORT', how='left')
        train_data['historical_avg_enrollment'] = train_data['historical_avg_enrollment'].fillna(0)
        
        train_data['HIGH_ENROLLMENT'] = (train_data['HIGH_ENROLLMENT'] == 'Y').astype(int)

        # Fit encoders on training data and transform test data
        for col in categorical_features:
            le = LabelEncoder()
            train_data[col] = le.fit_transform(train_data[col].astype(str))
            
            # Handle unseen values in test data
            data[col] = data[col].astype(str).map(lambda s: s if s in le.classes_ else '<unknown>')
            le_classes = le.classes_.tolist()
            if '<unknown>' not in le_classes:
                bisect.insort_left(le_classes, '<unknown>')
            le.classes_ = np.array(le_classes)
            data[col] = le.transform(data[col])
        
        X_full_train = train_data[features]
        y_full_train = train_data['HIGH_ENROLLMENT']
        
        print("Training final model on all training data...")
        lgb_full_train = lgb.Dataset(X_full_train, y_full_train, categorical_feature=categorical_features)
        
        params = { 'objective': 'binary', 'metric': 'binary_logloss', 'boosting_type': 'gbdt', 'num_leaves': 60, 'learning_rate': 0.02,
            'feature_fraction': 0.8, 'bagging_fraction': 0.8, 'bagging_freq': 1, 'min_child_samples': 20, 'verbose': -1, 'n_jobs': -1, 'seed': 42 }
        
        # From validation, a good number of rounds was ~400-600. Let's use a fixed number.
        model = lgb.train(params, lgb_full_train, num_boost_round=500)
        
        print("Making predictions on the test set...")
        test_preds = model.predict(data[features])
        test_preds_binary = (test_preds > 0.5).astype(int)
        
        submission_df = data[['TERM_CODE', 'SUBJECT_ID_SORT']].copy()
        submission_df['HIGH_ENROLLMENT'] = np.where(test_preds_binary == 1, 'Y', 'N')

    else: # Training/validation run
        for col in categorical_features:
            le = LabelEncoder()
            data[col] = le.fit_transform(data[col].astype(str))
        
        data['HIGH_ENROLLMENT'] = (data['HIGH_ENROLLMENT'] == 'Y').astype(int)
        
        max_year = data['TERM_YEAR'].max()
        train_df = data[data['TERM_YEAR'] < max_year]
        val_df = data[data['TERM_YEAR'] == max_year]

        print(f"Training data shape: {train_df.shape}")
        print(f"Validation data shape: {val_df.shape}")

        X_train = train_df[features]
        y_train = train_df['HIGH_ENROLLMENT']
        X_val = val_df[features]
        y_val = val_df['HIGH_ENROLLMENT']
        
        print("Training model for validation...")
        lgb_train = lgb.Dataset(X_train, y_train, categorical_feature=categorical_features)
        lgb_eval = lgb.Dataset(X_val, y_val, reference=lgb_train, categorical_feature=categorical_features)

        params = { 'objective': 'binary', 'metric': 'binary_logloss', 'boosting_type': 'gbdt', 'num_leaves': 60, 'learning_rate': 0.02,
            'feature_fraction': 0.8, 'bagging_fraction': 0.8, 'bagging_freq': 1, 'min_child_samples': 20, 'verbose': -1, 'n_jobs': -1, 'seed': 42 }

        model = lgb.train(params, lgb_train, num_boost_round=2000, valid_sets=[lgb_eval], callbacks=[lgb.early_stopping(150, verbose=False)])
        
        val_preds = model.predict(X_val, num_iteration=model.best_iteration)
        val_preds_binary = (val_preds > 0.5).astype(int)
        macro_f1 = f1_score(y_val, val_preds_binary, average='macro')
        print(f"Validation Macro F1 Score: {macro_f1}")
        
        # Generate submission for evaluation script
        all_preds = model.predict(data[features], num_iteration=model.best_iteration)
        all_preds_binary = (all_preds > 0.5).astype(int)
        submission_df = data[['TERM_CODE', 'SUBJECT_ID_SORT']].copy()
        submission_df['HIGH_ENROLLMENT'] = np.where(all_preds_binary == 1, 'Y', 'N')

    print("Creating submission.csv...")
    submission_df.to_csv("submission.csv", index=False)
    print("Done.")

if __name__ == "__main__":
    main()
