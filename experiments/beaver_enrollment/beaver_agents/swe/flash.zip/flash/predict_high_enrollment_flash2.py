import argparse
import pandas as pd
import os
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score, make_scorer
from sklearn.metrics import confusion_matrix
import numpy as np
import joblib # For saving the model

def main():
    parser = argparse.ArgumentParser(description="Predict high enrollment for course offerings.")
    parser.add_argument("--train-dir", type=str, default="train", help="Path to the training data directory.")
    parser.add_argument("--test-dir", type=str, default="test", help="Path to the test data directory (optional).")
    args = parser.parse_args()

    print(f"Train directory: {args.train_dir}")
    print(f"Test directory: {args.test_dir}")

    # 1. Load data
    try:
        gold_enrollment_train_path = os.path.join(args.train_dir, "gold_enrollment_train.csv")
        subject_offered_summary_path = os.path.join(args.train_dir, "SUBJECT_OFFERED_SUMMARY.csv")
        academic_terms_path = os.path.join(args.train_dir, "ACADEMIC_TERMS.csv")
        subject_summary_path = os.path.join(args.train_dir, "SUBJECT_SUMMARY.csv")
        enrollment_history_path = os.path.join(args.train_dir, "ENROLLMENT_HISTORY_FEATURES.csv")

        gold_enrollment_train_df = pd.read_csv(gold_enrollment_train_path)
        subject_offered_summary_df = pd.read_csv(subject_offered_summary_path, low_memory=False) # Added low_memory=False
        academic_terms_df = pd.read_csv(academic_terms_path)
        subject_summary_df = pd.read_csv(subject_summary_path)
        enrollment_history_df = pd.read_csv(enrollment_history_path)

        print(f"Loaded gold_enrollment_train.csv: {gold_enrollment_train_df.shape}")
        print(f"Loaded SUBJECT_OFFERED_SUMMARY.csv: {subject_offered_summary_df.shape}")
        print(f"Loaded ACADEMIC_TERMS.csv: {academic_terms_df.shape}")
        print(f"Loaded SUBJECT_SUMMARY.csv: {subject_summary_df.shape}")
        print(f"Loaded ENROLLMENT_HISTORY_FEATURES.csv: {enrollment_history_df.shape}")

    except FileNotFoundError as e:
        print(f"Error loading data: {e}. Please ensure data files are in {args.train_dir}.")
        return

    # Merge gold labels with subject offered summary (no conflicting columns here)
    train_df = pd.merge(
        subject_offered_summary_df,
        gold_enrollment_train_df,
        on=["TERM_CODE", "SUBJECT_ID_SORT"],
        how="inner"
    )
    print(f"Merged train_df shape (with gold labels): {train_df.shape}")

    # Add academic terms for time-based splitting and other potential features
    train_df = pd.merge(train_df, academic_terms_df[['TERM_CODE', 'ACADEMIC_YEAR', 'TERM_DESCRIPTION']], on='TERM_CODE', how='left')

    # Add subject summary data. Use suffixes to resolve conflicts.
    train_df = pd.merge(train_df, subject_summary_df, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left', suffixes=('_offered', '_summary'))

    # Add enrollment history features (no conflicting columns)
    train_df = pd.merge(train_df, enrollment_history_df, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')

    print(f"Train_df after all merges shape: {train_df.shape}")
    
    # --- Feature Engineering ---
    # Convert 'HIGH_ENROLLMENT' to numerical (0 or 1)
    train_df['HIGH_ENROLLMENT'] = train_df['HIGH_ENROLLMENT'].map({'N': 0, 'Y': 1})

    # Define features based on expected column names after merges
    numerical_features = [
        'TOTAL_UNITS_offered', 'LECTURE_UNITS_offered', 'LAB_UNITS_offered', 'PREPARATION_UNITS_offered',
        'TOTAL_UNITS_summary', 'LECTURE_UNITS_summary', 'LAB_UNITS_summary', 'PREP_UNITS_summary', 'DESIGN_UNITS_summary',
        'SUBJECT_ENROLLMENT_FIRST_WEEK', 'CLUSTER_ENROLLMENT_FIRST_WEEK',
        'SUBJECT_ENROLLMENT_FIFTH_WEEK', 'CLUSTER_ENROLLMENT_FIFTH_WEEK',
        'SUBJECT_ENROLLMENT_CREDIT', 'SUBJECT_ENROLLMENT_LISTEN',
        'CLUSTER_ENROLLMENT_CREDIT', 'CLUSTER_ENROLLMENT_LISTEN',
        'SUBJECT_ENROLLMENT_1ST_CREDIT', 'SUBJECT_ENROLLMENT_1ST_LISTEN',
        'CLUSTER_ENROLLMENT_1ST_CREDIT', 'CLUSTER_ENROLLMENT_1ST_LISTEN',
        'SUBJECT_ENROLLMENT_5TH_CREDIT', 'SUBJECT_ENROLLMENT_5TH_LISTEN',
        'CLUSTER_ENROLLMENT_5TH_CREDIT', 'CLUSTER_ENROLLMENT_5TH_LISTEN',
        'lag1_enrollment', 'lag2_enrollment', 'roll3_enrollment_mean'
    ]
    
    categorical_features = [
        'CLUSTER_TYPE_offered', 'HGN_CODE_offered', 'OFFER_DEPT_CODE', 'OFFER_SCHOOL_NAME',
        'CLUSTER_TYPE_summary', 'DEPARTMENT_CODE_summary', 'SCHOOL_CODE_summary'
    ]

    # Clean up feature lists to only include columns that actually exist in the dataframe
    numerical_features = [col for col in numerical_features if col in train_df.columns]
    categorical_features = [col for col in categorical_features if col in train_df.columns]
    
    # Fill missing numerical values with 0
    for col in numerical_features:
        train_df[col] = pd.to_numeric(train_df[col], errors='coerce').fillna(0)

    # Fill missing categorical values with 'Unknown'
    for col in categorical_features:
        train_df[col] = train_df[col].fillna('Unknown')

    selected_features = numerical_features + categorical_features
    X = train_df[selected_features]
    y = train_df['HIGH_ENROLLMENT']

    # --- Time-based train-validation split (using TERM_CODE) ---
    train_df = train_df.sort_values(by='TERM_CODE').reset_index(drop=True)
    unique_terms = train_df['TERM_CODE'].unique()
    unique_terms.sort()

    # Hold out the latest 3 terms for validation
    num_validation_terms = min(3, len(unique_terms) // 4) # At least 3 terms, or 25% of terms
    
    if num_validation_terms > 0:
        val_terms = unique_terms[-num_validation_terms:]
        train_set = train_df[~train_df['TERM_CODE'].isin(val_terms)]
        val_set = train_df[train_df['TERM_CODE'].isin(val_terms)]
        
        X_train, y_train = train_set[selected_features], train_set['HIGH_ENROLLMENT']
        X_val, y_val = val_set[selected_features], val_set['HIGH_ENROLLMENT']

        print(f"Train set (by TERM_CODE) shape: {train_set.shape}")
        print(f"Validation set (by TERM_CODE) shape: {val_set.shape}")
        print(f"Validation terms: {val_terms}")
    else:
        print("Warning: Insufficient unique terms for time-based validation. Using 80/20 random split for now.")
        X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
        train_set = train_df.iloc[X_train.index] # To keep original row context if needed
        val_set = train_df.iloc[X_val.index]

        print(f"Train set (random split) shape: {train_set.shape}")
        print(f"Validation set (random split) shape: {val_set.shape}")

    # --- Preprocessing Pipeline ---
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', StandardScaler(), [f for f in numerical_features if f in X_train.columns]),
            ('cat', OneHotEncoder(handle_unknown='ignore'), [f for f in categorical_features if f in X_train.columns])
        ],
        remainder='passthrough' # Keep other columns (e.g., ID columns if any accidentally left)
    )

    # --- Model Training ---
    # Using Logistic Regression as a baseline
    model = Pipeline(steps=[
        ('preprocessor', preprocessor),
        ('classifier', LogisticRegression(solver='liblinear', random_state=42, class_weight='balanced', max_iter=1000)) # class_weight for imbalanced classes
    ])

    print("Training model...")
    model.fit(X_train, y_train)
    print("Model training complete.")

    # --- Evaluation ---
    if not val_set.empty:
        y_pred_val = model.predict(X_val)
        macro_f1 = f1_score(y_val, y_pred_val, average='macro')
        print(f"Validation Macro F1 Score: {macro_f1}")
        print("Validation Confusion Matrix:")
        print(confusion_matrix(y_val, y_pred_val))
    else:
        print("No separate validation set for evaluation.")

    # --- Prediction for test data (if test-dir is provided) ---
    if args.test_dir and os.path.exists(args.test_dir):
        print(f"Loading test data from {args.test_dir} for prediction...")
        subject_offered_summary_test_path = os.path.join(args.test_dir, "SUBJECT_OFFERED_SUMMARY.csv")
        try:
            # Assuming test/SUBJECT_OFFERED_SUMMARY.csv contains all keys for prediction
            test_subject_offered_df = pd.read_csv(subject_offered_summary_test_path, low_memory=False)
            
            test_df = test_subject_offered_df.copy()
            test_df = pd.merge(test_df, academic_terms_df[['TERM_CODE', 'ACADEMIC_YEAR']], on='TERM_CODE', how='left')
            
            # Merge with subject_summary and enrollment_history, using same suffix strategy as training
            test_df = pd.merge(test_df, subject_summary_df, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left', suffixes=('_offered', '_summary'))
            test_df = pd.merge(test_df, enrollment_history_df, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')


            # Prepare test data for prediction
            # Ensure all selected_features exist in test_df, add if missing with default values
            for col in numerical_features:
                if col not in test_df.columns:
                    test_df[col] = 0.0 # Add missing numerical columns with 0
                else:
                    test_df[col] = pd.to_numeric(test_df[col], errors='coerce').fillna(0.0) # Ensure numeric then fill
            
            for col in categorical_features:
                if col not in test_df.columns:
                    test_df[col] = 'Unknown' # Add missing categorical columns with 'Unknown'
                else:
                    test_df[col] = test_df[col].fillna('Unknown')


            X_test = test_df[selected_features]
            
            print(f"Test data shape for prediction: {X_test.shape}")
            # print(f"Test data columns: {X_test.columns.tolist()}") # Commented for less output

            y_pred_test = model.predict(X_test)
            test_df['HIGH_ENROLLMENT'] = np.where(y_pred_test == 1, 'Y', 'N')

            submission_df = test_df[['TERM_CODE', 'SUBJECT_ID_SORT', 'HIGH_ENROLLMENT']]
            submission_df.to_csv("submission.csv", index=False)
            print("Predictions saved to submission.csv")

        except FileNotFoundError as e:
            print(f"Test data error: {e}. Cannot generate test predictions.")
    else:
        print("Test directory not provided or does not exist. Skipping test predictions.")

    # The task asks for submission.csv for *the target split*.
    # If no test-dir, we can optionally save for validation set keys.
    # For now, only generate submission.csv if test_dir is provided.

if __name__ == "__main__":
    main()
