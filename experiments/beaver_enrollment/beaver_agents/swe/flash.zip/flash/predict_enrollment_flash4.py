import argparse
import pandas as pd
import numpy as np
import os
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score, make_scorer
from sklearn.preprocessing import LabelEncoder

def load_data(data_dir, filename):
    filepath = os.path.join(data_dir, filename)
    print(f"Loading {filepath}...")
    return pd.read_csv(filepath)

def feature_engineer(df_subject_offered_summary, df_subject_summary, df_enrollment_history, df_academic_terms, df_subject_offered):
    print("Starting feature engineering...")

    # Merge key tables
    df = df_subject_offered_summary.copy()
    df = df.merge(df_subject_summary, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')
    
    if df_subject_offered is not None:
        df = df.merge(df_subject_offered, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')
    else:
        # If SUBJECT_OFFERED.csv is not available, ensure relevant columns exist and are null
        # Add placeholder columns with NaNs if they don't exist
        for col in ['RESPONSIBLE_FACULTY_NAME_y', 'MASTER_COURSE_NUMBER', 'MASTER_COURSE_NUMBER_SORT', 'MASTER_COURSE_NUMBER_DESC', 'MASTER_SUBJECT_ID_SORT', 'COURSE_NUMBER_y', 'COURSE_NUMBER_SORT', 'COURSE_NUMBER_DESC', 'SUBJECT_TITLE', 'IS_MASTER_SECTION', 'IS_LECTURE_SECTION', 'IS_LAB_SECTION', 'IS_RECITATION_SECTION', 'IS_DESIGN_SECTION', 'OFFER_DEPT_CODE_y', 'OFFER_DEPT_NAME_y', 'OFFER_SCHOOL_NAME_y', 'MEET_TIME', 'MEET_PLACE', 'CLUSTER_TYPE', 'CLUSTER_TYPE_DESC', 'CLUSTER_LIST', 'HGN_CODE_y', 'HGN_CODE_DESC_y', 'FORM_TYPE', 'FORM_TYPE_DESC', 'EVALUATE_THIS_SUBJECT', 'IS_OSE_SUBJECT', 'IS_CREATED_BY_DATA_WAREHOUSE', 'IS_REPEATABLE_SUBJECT']:
            if col not in df.columns:
                df[col] = np.nan
    
    # Merge academic terms for term features
    df = df.merge(df_academic_terms[['TERM_CODE', 'ACADEMIC_YEAR', 'TERM_DESCRIPTION']], on='TERM_CODE', how='left')

    # Basic features
    # Use RESPONSIBLE_FACULTY_NAME_y if it exists, otherwise a placeholder column (which will be NaN)
    if 'RESPONSIBLE_FACULTY_NAME_y' in df.columns:
        df['INSTRUCTOR_COUNT'] = df.groupby(['TERM_CODE', 'SUBJECT_ID_SORT'])['RESPONSIBLE_FACULTY_NAME_y'].transform('nunique')
    else:
        df['INSTRUCTOR_COUNT'] = 0 # Default to 0 if no instructor data
    
    # Fill NaN values for numerical features before creating new features
    numerical_cols = ['SUBJECT_ENROLLMENT_FIFTH_WEEK', 'INSTRUCTOR_COUNT'] # Removed SUBJECT_CAPACITY
    for col in numerical_cols:
        if col in df.columns:
            df[col] = df[col].fillna(0)

    # Lagged features from ENROLLMENT_HISTORY_FEATURES
    # Using 'lag1_enrollment' directly and renaming
    df['TERM_CODE'] = df['TERM_CODE'].astype(str)
    df['SUBJECT_ID_SORT'] = df['SUBJECT_ID_SORT'].astype(str)
    df_enrollment_history['TERM_CODE'] = df_enrollment_history['TERM_CODE'].astype(str)
    df_enrollment_history['SUBJECT_ID_SORT'] = df_enrollment_history['SUBJECT_ID_SORT'].astype(str)
    df = df.merge(df_enrollment_history[['TERM_CODE', 'SUBJECT_ID_SORT', 'lag1_enrollment']], on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left').rename(columns={'lag1_enrollment': 'PREV_ENROLLMENT'})
    df['PREV_ENROLLMENT'] = df['PREV_ENROLLMENT'].fillna(0)

    # Convert categorical features
    df['TERM_DESCRIPTION'] = df['TERM_DESCRIPTION'].astype('category').cat.codes

    print("Feature engineering complete.")
    return df

def train_model(X_train, y_train):
    print("Training model...")
    model = RandomForestClassifier(n_estimators=100, random_state=42, class_weight='balanced')
    model.fit(X_train, y_train)
    print("Model training complete.")
    return model

def main():
    parser = argparse.ArgumentParser(description="Predict high enrollment for course offerings.")
    parser.add_argument("--train-dir", type=str, default="train", help="Path to the training data directory.")
    parser.add_argument("--test-dir", type=str, default=None, help="Path to the test data directory (optional).")
    args = parser.parse_args()

    # --- Load Training Data ---
    gold_enrollment_train = load_data(args.train_dir, 'gold_enrollment_train.csv')
    subject_offered_summary_train = load_data(args.train_dir, 'SUBJECT_OFFERED_SUMMARY.csv')
    subject_summary_train = load_data(args.train_dir, 'SUBJECT_SUMMARY.csv')
    
    subject_offered_train_filepath = os.path.join(args.train_dir, 'SUBJECT_OFFERED.csv')
    subject_offered_train = load_data(args.train_dir, 'SUBJECT_OFFERED.csv') if os.path.exists(subject_offered_train_filepath) else None

    enrollment_history_features_train = load_data(args.train_dir, 'ENROLLMENT_HISTORY_FEATURES.csv')
    academic_terms_train = load_data(args.train_dir, 'ACADEMIC_TERMS.csv')

    # --- Feature Engineering for Training Data ---
    df_train_features = feature_engineer(
        subject_offered_summary_train,
        subject_summary_train,
        enrollment_history_features_train,
        academic_terms_train,
        subject_offered_train # Pass potentially None
    )

    # Merge with gold labels
    df_train = df_train_features.merge(gold_enrollment_train, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='inner')

    # Filter out rows where HIGH_ENROLLMENT is missing after merge (shouldn't happen with inner, but good practice)
    df_train = df_train.dropna(subset=['HIGH_ENROLLMENT'])

    # Encode target variable
    le = LabelEncoder()
    df_train['HIGH_ENROLLMENT_ENCODED'] = le.fit_transform(df_train['HIGH_ENROLLMENT'])

    # Select features and target
    features = [
        'ACADEMIC_YEAR',
        'TERM_DESCRIPTION',
        'INSTRUCTOR_COUNT',
        'SUBJECT_ENROLLMENT_FIFTH_WEEK',
        # 'SUBJECT_CAPACITY', # Removed
        # 'ENROLLMENT_RATIO', # Removed
        'PREV_ENROLLMENT'
    ]
    
    # Ensure all features exist, fill with 0 if not (temporary for skeleton)
    for f in features:
        if f not in df_train.columns:
            df_train[f] = 0

    X = df_train[features]
    y = df_train['HIGH_ENROLLMENT_ENCODED']

    # --- Validation Split (Time-based) ---
    df_train = df_train.sort_values(by='TERM_CODE')
    
    # Get unique terms and split them
    unique_terms = df_train['TERM_CODE'].unique()
    validation_term_count = int(len(unique_terms) * 0.2)
    train_terms = unique_terms[:-validation_term_count]
    val_terms = unique_terms[-validation_term_count:]

    X_train_val = df_train[df_train['TERM_CODE'].isin(train_terms)][features]
    y_train_val = df_train[df_train['TERM_CODE'].isin(train_terms)]['HIGH_ENROLLMENT_ENCODED']
    X_val = df_train[df_train['TERM_CODE'].isin(val_terms)][features]
    y_val = df_train[df_train['TERM_CODE'].isin(val_terms)]['HIGH_ENROLLMENT_ENCODED']

    print(f"Training on {len(X_train_val)} samples, validating on {len(X_val)} samples.")

    # --- Train Model ---
    model = train_model(X_train_val, y_train_val)

    # --- Validate Model ---
    y_pred_val = model.predict(X_val)
    macro_f1 = f1_score(y_val, y_pred_val, average='macro')
    print(f"Validation Macro F1 Score: {macro_f1:.4f}")

    # --- Generate Predictions for Submission ---
    if args.test_dir:
        print("Generating predictions for the test set...")
        # Load test data
        subject_offered_summary_test = load_data(args.test_dir, 'SUBJECT_OFFERED_SUMMARY.csv')
        subject_summary_test = load_data(args.test_dir, 'SUBJECT_SUMMARY.csv')
        
        subject_offered_test_filepath = os.path.join(args.test_dir, 'SUBJECT_OFFERED.csv')
        subject_offered_test = load_data(args.test_dir, 'SUBJECT_OFFERED.csv') if os.path.exists(subject_offered_test_filepath) else None

        enrollment_history_features_test = load_data(args.test_dir, 'ENROLLMENT_HISTORY_FEATURES.csv')
        academic_terms_test = load_data(args.test_dir, 'ACADEMIC_TERMS.csv')
        
        # Feature engineer for test data (using same function)
        df_test_features = feature_engineer(
            subject_offered_summary_test,
            subject_summary_test,
            enrollment_history_features_test,
            academic_terms_test,
            subject_offered_test # Pass potentially None
        )
        
        # Ensure test features match training features, fill with 0 if missing
        for f in features:
            if f not in df_test_features.columns:
                df_test_features[f] = 0

        X_test = df_test_features[features]

        # Make predictions
        test_predictions_encoded = model.predict(X_test)
        test_predictions = le.inverse_transform(test_predictions_encoded)

        # Create submission file
        submission_df = df_test_features[['TERM_CODE', 'SUBJECT_ID_SORT']].copy()
        submission_df['HIGH_ENROLLMENT'] = test_predictions
        submission_df.to_csv('submission.csv', index=False)
        print("Test predictions saved to submission.csv")

    else:
        print("No test-dir provided. Skipping test prediction generation.")
        X_full_train = df_train[features]
        y_pred_full_train_encoded = model.predict(X_full_train)
        y_pred_full_train = le.inverse_transform(y_pred_full_train_encoded)

        submission_df = df_train[['TERM_CODE', 'SUBJECT_ID_SORT']].copy()
        submission_df['HIGH_ENROLLMENT'] = y_pred_full_train
        submission_df.to_csv('submission.csv', index=False)
        print("Train predictions saved to submission.csv for evaluation.")


if __name__ == "__main__":
    main()
