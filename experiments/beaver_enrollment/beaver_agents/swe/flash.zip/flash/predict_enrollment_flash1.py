import pandas as pd
import argparse
import os
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score, make_scorer
from sklearn.preprocessing import LabelEncoder
import numpy as np

# A simple script to evaluate predictions.
# In a real setup, this would be a separate script.
def evaluate_predictions(pred_df, gold_df):
    merged_df = pd.merge(pred_df, gold_df, on=['TERM_CODE', 'SUBJECT_ID_SORT'], suffixes=('_pred', '_gold'))
    if merged_df.empty:
        print("Error: No matching entries between predictions and gold labels.")
        return 0.0

    # Ensure consistent label encoding for F1 score
    le = LabelEncoder() # Create a new LabelEncoder to avoid issues with previous state if any
    le.fit(['N', 'Y'])
    
    y_true = le.transform(merged_df['HIGH_ENROLLMENT_gold'])
    y_pred = le.transform(merged_df['HIGH_ENROLLMENT_pred'])
    
    macro_f1 = f1_score(y_true, y_pred, average='macro')
    print(f"Validation Macro F1 Score: {macro_f1:.4f}")
    return macro_f1

def load_data(data_dir, is_training=True):
    print(f"Loading data from: {data_dir}")
    
    subject_offered_summary_path = os.path.join(data_dir, "SUBJECT_OFFERED_SUMMARY.csv")
    subject_summary_path = os.path.join(data_dir, "SUBJECT_SUMMARY.csv")
    enrollment_history_features_path = os.path.join(data_dir, "ENROLLMENT_HISTORY_FEATURES.csv")
    academic_terms_path = os.path.join(data_dir, "ACADEMIC_TERMS.csv")

    subject_offered_summary = pd.read_csv(subject_offered_summary_path, low_memory=False)
    subject_summary = pd.read_csv(subject_summary_path, low_memory=False)
    enrollment_history_features = pd.read_csv(enrollment_history_features_path, low_memory=False)
    academic_terms = pd.read_csv(academic_terms_path, low_memory=False)

    df = subject_offered_summary.copy()
    
    # Merge with Subject Summary
    df = pd.merge(df, subject_summary, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left', suffixes=('', '_subj_sum'))
    
    # Merge with Enrollment History Features
    df = pd.merge(df, enrollment_history_features, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left', suffixes=('', '_hist'))

    # Merge with Academic Terms to get term metadata
    df = pd.merge(df, academic_terms, on='TERM_CODE', how='left')

    if is_training:
        gold_enrollment_path = os.path.join(data_dir, "gold_enrollment_train.csv")
        gold_enrollment = pd.read_csv(gold_enrollment_path)
        df = pd.merge(df, gold_enrollment, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='inner')
        print(f"Merged training dataframe shape: {df.shape}")
        print("\nMerged Training Data Head:")
        print(df.head())
    else:
        # For test data, we only need the keys for prediction
        print(f"Merged test dataframe shape (before final key check): {df.shape}")
        print("\nMerged Test Data Head:")
        print(df.head())

    return df

def feature_engineer(df_input):
    print("Performing feature engineering...")
    df = df_input.copy() # Work on a copy to avoid modifying original dataframe unexpectedly
    
    # Extract year and term type from TERM_CODE
    df['TERM_YEAR'] = df['TERM_CODE'].astype(str).str[:4].astype(int)
    df['TERM_SEASON'] = df['TERM_CODE'].astype(str).str[4:]
    
    # Example enrollment features from SUBJECT_SUMMARY (already merged)
    # Filling NaNs for numerical columns that will be used as features
    numerical_cols = [
        'TOTAL_ENROLLMENT', 'SUBJECT_ENROLLMENT_FIFTH_WEEK', 'SUBJECT_ENROLLMENT_FIFTH_WEEK_LISTEN',
        'SUBJECT_ENROLLMENT_FINAL', 'SUBJECT_ENROLLMENT_FINAL_LISTEN',
        'TOTAL_ENROLLMENT_subj_sum', 'SUBJECT_ENROLLMENT_FIFTH_WEEK_subj_sum',
        'AVG_ENROLLMENT_PREV_1_YEAR', 'AVG_ENROLLMENT_PREV_3_YEARS',
        'MEDIAN_ENROLLMENT_PREV_1_YEAR', 'MEDIAN_ENROLLMENT_PREV_3_YEARS',
        'STD_ENROLLMENT_PREV_1_YEAR', 'STD_ENROLLMENT_PREV_3_YEARS',
        'AVG_ENROLLMENT_PREV_5_YEARS', # Added more history features
        'MEDIAN_ENROLLMENT_PREV_5_YEARS',
        'STD_ENROLLMENT_PREV_5_YEARS',
        'HIGH_ENROLLMENT_COUNT_PREV_1_YEAR', # More history
        'HIGH_ENROLLMENT_COUNT_PREV_3_YEARS',
        'HIGH_ENROLLMENT_COUNT_PREV_5_YEARS',
        'HIGH_ENROLLMENT_RATE_PREV_1_YEAR',
        'HIGH_ENROLLMENT_RATE_PREV_3_YEARS',
        'HIGH_ENROLLMENT_RATE_PREV_5_YEARS'
    ]
    # Add other potentially useful numerical columns if they exist
    additional_numerical_cols = [
        'MAX_UNITS', 'MIN_UNITS', 'LEC_UNITS', 'LAB_UNITS', 'PREPARATION_UNITS'
    ]
    numerical_cols.extend([col for col in additional_numerical_cols if col in df.columns])

    for col in numerical_cols:
        if col in df.columns:
            # Attempt to convert to numeric, coercing errors to NaN, then fill NaN with 0
            df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0)
            
    # Handle categorical features
    categorical_cols = [
        'TERM_SEASON', 'JOINT_SUBJECT_FLAG', 'MEETS_WITH_FLAG', 
        'COURSE_NUMBER', 'SUBJECT_TYPE', 'TERM_ACADEMIC_PERIOD',
        'SUBJECT_LEVEL', 'GRADUATE_UNDERGRADUATE_FLAG', # Add more categorical
        'ACADEMIC_GROUP_CODE', 'INSTRUCTOR_NAME' # Instructor could be a good feature, but high cardinality
    ]
    
    # Filter for columns that actually exist in the dataframe and exclude those already processed or not suitable for OHE
    categorical_cols = [col for col in categorical_cols if col in df.columns and col not in ['INSTRUCTOR_NAME']]

    df = pd.get_dummies(df, columns=categorical_cols, dummy_na=False) # dummy_na=False to not create a dummy for NaNs

    # Define columns to exclude from features (identifiers, target, or original columns that generated new features)
    exclude_cols_from_features = [
        'TERM_CODE', 'SUBJECT_ID_SORT', 'HIGH_ENROLLMENT', 'HIGH_ENROLLMENT_encoded',
        'COURSE_NUMBER', 'SUBJECT_TYPE', 'TERM_SEASON', 'TERM_ACADEMIC_PERIOD', # Original cols that were OHE'd
        'INSTRUCTOR_NAME', # High cardinality, dropping for now
        'GRADUATE_AWARD_END_DATE', # Date column, usually needs specific handling
        'ACADEMIC_GROUP_CODE', # Original categorical, replaced by OHE
        # Drop duplicated columns if they still exist (from suffixes)
    ] + [col for col in df.columns if col.endswith('_subj_sum') or col.endswith('_hist')]
    
    # Final feature selection
    features = [col for col in df.columns if col not in exclude_cols_from_features and df[col].dtype in [np.number, bool]]
    
    print(f"Number of features after engineering: {len(features)}")
    return df, features

def train_model(X_train, y_train):
    print("Training model...")
    model = RandomForestClassifier(n_estimators=200, random_state=42, n_jobs=-1, class_weight='balanced') # Increased estimators
    model.fit(X_train, y_train)
    print("Model training complete.")
    return model

def predict_and_save(model, df_inference, features, output_path, label_encoder):
    print("Generating predictions...")
    
    # Ensure all features used during training are present in the inference data
    # Create X_inference from df_inference using the 'features' list
    X_inference = df_inference[features]
    
    predictions_encoded = model.predict(X_inference)
    predictions = label_encoder.inverse_transform(predictions_encoded)
    
    submission_df = pd.DataFrame({
        'TERM_CODE': df_inference['TERM_CODE'],
        'SUBJECT_ID_SORT': df_inference['SUBJECT_ID_SORT'],
        'HIGH_ENROLLMENT': predictions
    })
    
    submission_df.to_csv(output_path, index=False)
    print(f"Predictions saved to {output_path}")

def main():
    parser = argparse.ArgumentParser(description="Predict high enrollment for course offerings.")
    parser.add_argument("--train-dir", type=str, default="train", help="Path to the training data directory.")
    parser.add_argument("--test-dir", type=str, default=None, help="Path to the test data directory (for inference).") # Changed default to None
    parser.add_argument("--output-file", type=str, default="submission.csv", help="Name of the output submission file.")
    args = parser.parse_args()

    # --- Training Phase ---
    df_full_train = load_data(args.train_dir, is_training=True)
    
    # Sort by TERM_CODE for time-based split
    df_full_train = df_full_train.sort_values(by='TERM_CODE')

    # Define the validation split (e.g., last 2-3 unique terms)
    unique_terms = df_full_train['TERM_CODE'].unique()
    validation_terms = sorted(unique_terms)[-3:] # Get the last three terms for validation
    
    df_train = df_full_train[~df_full_train['TERM_CODE'].isin(validation_terms)].copy()
    df_val = df_full_train[df_full_train['TERM_CODE'].isin(validation_terms)].copy()
    
    print(f"\nTraining data terms: {df_train['TERM_CODE'].unique().min()} to {df_train['TERM_CODE'].unique().max()}")
    print(f"Validation data terms: {df_val['TERM_CODE'].unique().min()} to {df_val['TERM_CODE'].unique().max()}")
    print(f"Training set shape: {df_train.shape}")
    print(f"Validation set shape: {df_val.shape}")

    # Encode target variable
    le = LabelEncoder()
    df_train['HIGH_ENROLLMENT_encoded'] = le.fit_transform(df_train['HIGH_ENROLLMENT'])
    df_val['HIGH_ENROLLMENT_encoded'] = le.transform(df_val['HIGH_ENROLLMENT']) # Use fitted encoder

    # Feature Engineering
    df_train_fe, features = feature_engineer(df_train) # Pass df_train directly, feature_engineer makes copy
    df_val_fe, _ = feature_engineer(df_val) # Pass df_val directly, feature_engineer makes copy

    # Align columns - crucial for consistent feature sets between train and validation
    # Create a list of all features encountered in training
    train_feature_cols = [col for col in features if col != 'HIGH_ENROLLMENT_encoded'] # Exclude target if it somehow got in
    
    # Add missing columns to validation set (and fill with 0)
    missing_in_val = set(train_feature_cols) - set(df_val_fe.columns)
    for c in missing_in_val:
        df_val_fe[c] = 0

    # Drop extra columns from validation set
    extra_in_val = set(df_val_fe.columns) - set(train_feature_cols) - {'TERM_CODE', 'SUBJECT_ID_SORT', 'HIGH_ENROLLMENT', 'HIGH_ENROLLMENT_encoded'}
    if extra_in_val:
        df_val_fe = df_val_fe.drop(columns=list(extra_in_val))
    
    # Ensure order of columns for X_val matches X_train
    X_train = df_train_fe[train_feature_cols]
    y_train = df_train_fe['HIGH_ENROLLMENT_encoded']

    X_val = df_val_fe[train_feature_cols] # Select validation features using the same ordered list
    y_val = df_val_fe['HIGH_ENROLLMENT_encoded']

    # Train model
    model = train_model(X_train, y_train)

    # --- Validation Phase ---
    val_predictions_encoded = model.predict(X_val)
    val_predictions = le.inverse_transform(val_predictions_encoded)
    
    val_submission_df = pd.DataFrame({
        'TERM_CODE': df_val['TERM_CODE'], # Use original df_val for identifiers
        'SUBJECT_ID_SORT': df_val['SUBJECT_ID_SORT'],
        'HIGH_ENROLLMENT': val_predictions
    })
    
    print("\n--- Validation Results ---")
    evaluate_predictions(val_submission_df, df_val[['TERM_CODE', 'SUBJECT_ID_SORT', 'HIGH_ENROLLMENT']])
    
    # --- Inference Phase (if test-dir is provided) ---
    if args.test_dir:
        print(f"\n--- Generating test predictions for {args.test_dir} ---")
        df_test_raw = load_data(args.test_dir, is_training=False)
        df_test_fe, _ = feature_engineer(df_test_raw.copy()) # Make a copy before FE

        # Align columns for test set with training features
        test_feature_cols = train_feature_cols # Use the same feature list as training

        # Add missing columns with 0
        missing_in_test = set(test_feature_cols) - set(df_test_fe.columns)
        for c in missing_in_test:
            df_test_fe[c] = 0
        
        # Drop extra columns
        extra_in_test = set(df_test_fe.columns) - set(test_feature_cols) - {'TERM_CODE', 'SUBJECT_ID_SORT'}
        if extra_in_test:
            df_test_fe = df_test_fe.drop(columns=list(extra_in_test))
        
        # Ensure the order of columns is the same as in training before passing to predict
        df_test_fe_aligned = df_test_fe[test_feature_cols + ['TERM_CODE', 'SUBJECT_ID_SORT']] # Make sure identifiers are there for saving
        
        predict_and_save(model, df_test_fe_aligned, test_feature_cols, args.output_file, le)
    else:
        print("\nTest directory not provided. Skipping test prediction.")

if __name__ == "__main__":
    main()
