import argparse
import pandas as pd
import os
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score, make_scorer
from sklearn.preprocessing import LabelEncoder
import numpy as np

def term_code_to_features(df):
    """Converts TERM_CODE into numerical features (year, semester)."""
    if 'TERM_CODE' not in df.columns:
        return df

    semester_map = {
        'WI': 0, 'JA': 0,
        'SP': 1,
        'SU': 2, 'AU': 2,
        'FA': 3
    }

    df['TERM_YEAR'] = df['TERM_CODE'].str[:4].astype(int)
    df['TERM_SEMESTER'] = df['TERM_CODE'].str[4:].map(semester_map).fillna(-1).astype(int)
    return df

def extract_department(df):
    """Extracts department code from SUBJECT_ID_SORT."""
    if 'SUBJECT_ID_SORT' in df.columns:
        df['DEPARTMENT_FROM_SUBJECT'] = df['SUBJECT_ID_SORT'].apply(lambda x: str(x).split('.')[0] if '.' in str(x) else str(x))
    return df

def load_and_preprocess_data(data_dir, is_train=True):
    """
    Loads and preprocesses data from the given directory.
    If is_train is True, it loads gold labels.
    If is_train is False (for test prediction), it constructs a dataframe from test data.
    """
    if is_train:
        # Load gold labels for training
        gold_enrollment_path_symlink_target = '/Users/USER/Documents/UNI/SS26/BEAVER/eval/gold_enrollment_train.csv'
        gold_df = pd.read_csv(gold_enrollment_path_symlink_target, dtype={'TERM_CODE': str, 'SUBJECT_ID_SORT': str})
        # Ensure 'HIGH_ENROLLMENT' is mapped
        gold_df['HIGH_ENROLLMENT'] = gold_df['HIGH_ENROLLMENT'].map({'Y': 1, 'N': 0})
        # Start merged_df with gold_df's keys and target
        merged_df = gold_df.copy()
    else:
        # For test prediction, we need to get the keys (TERM_CODE, SUBJECT_ID_SORT) from the test data itself.
        test_keys_path = os.path.join(data_dir, 'SUBJECT_OFFERED_SUMMARY.csv')
        
        try:
            test_keys_df = pd.read_csv(test_keys_path, usecols=['TERM_CODE', 'SUBJECT_ID_SORT'], dtype={'TERM_CODE': str, 'SUBJECT_ID_SORT': str}, low_memory=False)
            merged_df = test_keys_df.copy()
            # Add a dummy target column for consistency during feature engineering
            merged_df['HIGH_ENROLLMENT'] = np.nan
        except FileNotFoundError:
            print(f"Error: Could not find SUBJECT_OFFERED_SUMMARY.csv in {data_dir}. Cannot generate test keys.")
            return None
    
    # Load key feature tables from the specified data_dir (train_dir or test_dir)
    # Cast TERM_CODE and SUBJECT_ID_SORT to string immediately upon loading to prevent dtype issues
    subject_offered_summary_df = pd.read_csv(os.path.join(data_dir, 'SUBJECT_OFFERED_SUMMARY.csv'), 
                                             dtype={'TERM_CODE': str, 'SUBJECT_ID_SORT': str}, 
                                             low_memory=False)
    subject_summary_df = pd.read_csv(os.path.join(data_dir, 'SUBJECT_SUMMARY.csv'), 
                                     dtype={'TERM_CODE': str, 'SUBJECT_ID_SORT': str}, 
                                     low_memory=False)
    enrollment_history_df = pd.read_csv(os.path.join(data_dir, 'ENROLLMENT_HISTORY_FEATURES.csv'), 
                                        dtype={'TERM_CODE': str, 'SUBJECT_ID_SORT': str}, 
                                        low_memory=False)
    academic_terms_df = pd.read_csv(os.path.join(data_dir, 'ACADEMIC_TERMS.csv'), 
                                    dtype={'TERM_CODE': str}, # Only TERM_CODE for this table
                                    low_memory=False)

    # Merge dataframes
    merged_df = pd.merge(merged_df, subject_offered_summary_df, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')
    merged_df = pd.merge(merged_df, subject_summary_df, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left', suffixes=('_OFFERED', '_SUMMARY'))
    merged_df = pd.merge(merged_df, enrollment_history_df, on=['TERM_CODE', 'SUBJECT_ID_SORT'], how='left')
    merged_df = pd.merge(merged_df, academic_terms_df, on='TERM_CODE', how='left', suffixes=('', '_TERM'))

    # Feature Engineering
    merged_df = term_code_to_features(merged_df)
    merged_df = extract_department(merged_df)

    return merged_df

def train_predict(train_dir, test_dir=None):
    print("Loading and preprocessing training data...")
    df_train_full = load_and_preprocess_data(train_dir, is_train=True)
    print(f"Full training data shape after merging: {df_train_full.shape}")

    df_train_full.dropna(subset=['HIGH_ENROLLMENT'], inplace=True)

    # Time-based validation split
    terms_sorted = sorted(df_train_full['TERM_CODE'].unique())
    split_idx = int(len(terms_sorted) * 0.8)
    train_terms = set(terms_sorted[:split_idx])
    val_terms = set(terms_sorted[split_idx:])

    df_val = df_train_full[df_train_full['TERM_CODE'].isin(val_terms)].copy()
    df_train_model = df_train_full[df_train_full['TERM_CODE'].isin(train_terms)].copy()

    print(f"\nTraining set terms: {df_train_model['TERM_CODE'].min()} to {df_train_model['TERM_CODE'].max()}")
    print(f"Validation set terms: {df_val['TERM_CODE'].min()} to {df_val['TERM_CODE'].max()}")
    print(f"Training data shape for model: {df_train_model.shape}")
    print(f"Validation data shape: {df_val.shape}")

    # Identify features
    numerical_cols = df_train_full.select_dtypes(include=np.number).columns.tolist()
    cols_to_remove = ['HIGH_ENROLLMENT', 'TOTAL_UNITS_OFFERED', 'TOTAL_UNITS_SUMMARY',
                      'LECTURE_UNITS_OFFERED', 'LAB_UNITS_OFFERED', 'PREPARATION_UNITS_OFFERED',
                      'LECTURE_UNITS_SUMMARY', 'LAB_UNITS_SUMMARY', 'PREP_UNITS_SUMMARY', 'DESIGN_UNITS_SUMMARY']
    id_cols_for_removal = ['TERM_CODE', 'SUBJECT_ID_SORT']

    features_raw_numerical = [col for col in numerical_cols if col not in cols_to_remove + id_cols_for_removal]

    categorical_cols = ['COURSE_NUMBER', 'DEPARTMENT_CODE_OFFERED', 'SCHOOL_CODE_OFFERED',
                        'DEPARTMENT_FROM_SUBJECT', 'CLUSTER_TYPE', 'DEPARTMENT_CODE_SUMMARY',
                        'SCHOOL_CODE_SUMMARY']

    final_features = list(features_raw_numerical)

    label_encoders = {}
    for col in categorical_cols:
        if col in df_train_model.columns:
            df_train_model[col] = df_train_model[col].astype(str).fillna('UNKNOWN')
            df_val[col] = df_val[col].astype(str).fillna('UNKNOWN')

            le = LabelEncoder()
            df_train_model[col + '_encoded'] = le.fit_transform(df_train_model[col])
            
            val_labels_not_in_train = set(df_val[col].unique()) - set(le.classes_)
            if val_labels_not_in_train:
                le.classes_ = np.append(le.classes_, list(val_labels_not_in_train))
            df_val[col + '_encoded'] = le.transform(df_val[col])
            
            label_encoders[col] = le
            final_features.append(col + '_encoded')
    
    final_features = [f for f in final_features if f in df_train_model.columns and f in df_val.columns]
    print(f"\nSelected features ({len(final_features)}): {final_features}")

    X_train = df_train_model[final_features].fillna(0)
    y_train = df_train_model['HIGH_ENROLLMENT']
    X_val = df_val[final_features].fillna(0)
    y_val = df_val['HIGH_ENROLLMENT']

    print("\nTraining RandomForestClassifier...")
    model = RandomForestClassifier(n_estimators=100, random_state=42, class_weight='balanced')
    model.fit(X_train, y_train)

    y_pred_val = model.predict(X_val)
    f1_macro_val = f1_score(y_val, y_pred_val, average='macro')
    print(f"Validation Macro F1 Score: {f1_macro_val:.4f}")

    submission_df = pd.DataFrame(columns=['TERM_CODE', 'SUBJECT_ID_SORT', 'HIGH_ENROLLMENT'])

    if test_dir:
        print(f"\n--- Generating Test Predictions for {test_dir} ---")
        df_test = load_and_preprocess_data(test_dir, is_train=False)
        
        if df_test is None:
            print("Skipping test prediction due to data loading error.")
            return

        print(f"Test data shape after merging: {df_test.shape}")
        
        for col in categorical_cols:
            if col in df_test.columns and col in label_encoders:
                df_test[col] = df_test[col].astype(str).fillna('UNKNOWN')
                le = label_encoders[col]
                test_labels_not_in_train = set(df_test[col].unique()) - set(le.classes_)
                if test_labels_not_in_train:
                    le.classes_ = np.append(le.classes_, list(test_labels_not_in_train))
                df_test[col + '_encoded'] = le.transform(df_test[col])
            elif col in df_test.columns:
                # If a categorical column exists in test but not in train, it won't have an encoder.
                # For robustness, we should decide a strategy: drop, or encode with a new encoder.
                # For this problem, assume training data is comprehensive. Fill with 0 or NaN for now.
                df_test[col + '_encoded'] = 0 # Default to 0 for unseen categorical features

        X_test = df_test[final_features].fillna(0)

        y_pred_test = model.predict(X_test)
        
        submission_df = df_test[['TERM_CODE', 'SUBJECT_ID_SORT']].copy()
        submission_df['HIGH_ENROLLMENT'] = np.where(y_pred_test == 1, 'Y', 'N')

    else:
        print("\n--- Generating Submission for Validation Set ---")
        submission_df = df_val[['TERM_CODE', 'SUBJECT_ID_SORT']].copy()
        submission_df['HIGH_ENROLLMENT'] = np.where(y_pred_val == 1, 'Y', 'N')

    submission_file = 'submission.csv'
    submission_df.to_csv(submission_file, index=False)
    print(f"Submission file '{submission_file}' created with {len(submission_df)} predictions.")

def main():
    parser = argparse.ArgumentParser(description="Predict high enrollment for course offerings.")
    parser.add_argument('--train-dir', type=str, default='train',
                        help='Path to the directory containing training tables.')
    parser.add_argument('--test-dir', type=str, default=None,
                        help='Path to the directory containing test tables (for inference only).')
    args = parser.parse_args()

    print(f"Using train directory: {args.train_dir}")
    if args.test_dir:
        print(f"Using test directory: {args.test_dir}")

    train_predict(args.train_dir, args.test_dir)

if __name__ == "__main__":
    main()
