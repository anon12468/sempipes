import argparse
import pandas as pd
import os
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score, make_scorer
from sklearn.impute import SimpleImputer
import numpy as np
import subprocess # To call the evaluation script

# Custom scorer for macro F1, compatible with sklearn's cross_val_score
macro_f1_scorer = make_scorer(f1_score, average='macro')

def load_table(data_dir, filename):
    """Loads a single CSV table."""
    path = os.path.join(data_dir, filename)
    print(f"Loading {filename} from {path}")
    # Handle DtypeWarning by specifying dtype for known problematic column or setting low_memory=False
    if 'SUBJECT_OFFERED_SUMMARY.csv' in filename:
        df = pd.read_csv(path, low_memory=False) # 'COLLEGE_ADVISORY_KEY_ID' often has mixed types
    else:
        df = pd.read_csv(path)
    print(f"Loaded {filename} with shape: {df.shape}")
    return df

def preprocess_data(data_dir, is_train=True):
    """Loads and preprocesses data tables."""
    print(f"\n--- Loading and Merging Data for {'Training' if is_train else 'Inference'} ---")
    
    # Load core tables
    subject_offered_summary_df = load_table(data_dir, 'SUBJECT_OFFERED_SUMMARY.csv')
    subject_summary_df = load_table(data_dir, 'SUBJECT_SUMMARY.csv')
    enrollment_history_features_df = load_table(data_dir, 'ENROLLMENT_HISTORY_FEATURES.csv')
    academic_terms_df = load_table(data_dir, 'ACADEMIC_TERMS.csv')
    
    # Base dataframe for merging (keys)
    if is_train:
        labels_df = load_table(data_dir, 'gold_enrollment_train.csv')
        base_df = labels_df
    else:
        # For test, the keys for prediction come from SUBJECT_OFFERED_SUMMARY.csv
        base_df = subject_offered_summary_df[['TERM_CODE', 'SUBJECT_ID_SORT']].copy()

    # Merge dataframes
    df = pd.merge(base_df, subject_offered_summary_df, 
                  on=['TERM_CODE', 'SUBJECT_ID_SORT'], 
                  how='left')
    
    df = pd.merge(df, subject_summary_df, 
                  on=['TERM_CODE', 'SUBJECT_ID_SORT'], 
                  how='left')

    df = pd.merge(df, enrollment_history_features_df, 
                  on=['TERM_CODE', 'SUBJECT_ID_SORT'], 
                  how='left')
    
    df = pd.merge(df, academic_terms_df,
                  on='TERM_CODE',
                  how='left',
                  suffixes=('', '_term')) # Avoid column name clashes

    print(f"\nMerged dataframe shape after all joins: {df.shape}")
    print("Merged dataframe head:")
    print(df.head())
    
    return df

def feature_engineer(df):
    """
    Performs feature engineering on the merged dataframe.
    """
    print(f"\nOriginal DF columns before feature engineering: {df.columns.tolist()}")

    # Convert TERM_CODE to a numerical representation for time-based splitting/features
    df['TERM_YEAR'] = df['TERM_CODE'].astype(str).str[:4].astype(int)
    df['TERM_SEASON'] = df['TERM_CODE'].astype(str).str[4:] 

    # Corrected features from ENROLLMENT_HISTORY_FEATURES.csv
    # Fill NaN with 0 for calculation, but check if column exists first
    for col in ['SUBJECT_ENROLLMENT_FIFTH_WEEK', 'lag1_enrollment', 'lag2_enrollment', 'roll3_enrollment_mean']:
        if col in df.columns:
            df[col] = df[col].fillna(0)
        else:
            print(f"Warning: '{col}' not found. Creating with zeros.")
            df[col] = 0.0

    # Basic interaction features (example) using corrected history features
    df['ENROLLMENT_VS_LAG1_RATIO'] = df['SUBJECT_ENROLLMENT_FIFTH_WEEK'] / (df['lag1_enrollment'] + 1e-6)
    df['ENROLLMENT_VS_LAG1_DIFF'] = df['SUBJECT_ENROLLMENT_FIFTH_WEEK'] - df['lag1_enrollment']
    df['ENROLLMENT_VS_ROLL3_MEAN_RATIO'] = df['SUBJECT_ENROLLMENT_FIFTH_WEEK'] / (df['roll3_enrollment_mean'] + 1e-6)
    df['ENROLLMENT_VS_ROLL3_MEAN_DIFF'] = df['SUBJECT_ENROLLMENT_FIFTH_WEEK'] - df['roll3_enrollment_mean']


    # Select numerical features (updated based on actual available columns)
    numerical_features = [
        'TOTAL_CAPACITY', 'ENROLLMENT_LIMIT', 'MAX_ENROLLMENT', 
        'SUBJECT_ENROLLMENT_FIFTH_WEEK', 'SUBJECT_MAX_ENROLLMENT', 
        'SUBJECT_SECTION_COUNT', 'ENROLLMENT_CAP', 
        'lag1_enrollment', 'lag2_enrollment', 'roll3_enrollment_mean', # Corrected history features
        'ENROLLMENT_VS_LAG1_RATIO', 'ENROLLMENT_VS_LAG1_DIFF',
        'ENROLLMENT_VS_ROLL3_MEAN_RATIO', 'ENROLLMENT_VS_ROLL3_MEAN_DIFF',
        'ACADEMIC_YEAR_START', 'ACADEMIC_YEAR_END', 'TERM_YEAR' # TERM_YEAR is numerical
    ]
    # Select categorical features (updated and checked for presence)
    categorical_features = [
        'PRIMARY_DEPT_ID', 'SUBJECT_TYPE', 'GRADING_SCHEME_TYPE', 
        'TERM_SEASON', 'TERM_TYPE', # From ACADEMIC_TERMS
        'INSTITUTION_ID', 'SCHOOL_ID', 'COLLEGE_ADVISORY_KEY_ID' # Often categorical and may have mixed types
    ]

    # Ensure all selected features exist, remove those that don't
    available_features = df.columns.tolist()
    numerical_features = [f for f in numerical_features if f in available_features]
    categorical_features = [f for f in categorical_features if f in available_features]

    print(f"\nSelected Numerical Features: {numerical_features}")
    print(f"Selected Categorical Features: {categorical_features}")

    return df, numerical_features, categorical_features

def run_pipeline(train_df, test_df, output_dir):
    """
    Runs the full ML pipeline: feature engineering, train/val split, training, prediction.
    """
    train_df_fe, numerical_features, categorical_features = feature_engineer(train_df.copy())
    
    # Time-based validation split
    unique_years = sorted(train_df_fe['TERM_YEAR'].unique())
    
    # Hold out the latest year for validation
    if len(unique_years) < 2:
        print("Not enough unique years for time-based validation. Using all data for training.")
        X_train_combined = train_df_fe.copy()
        y_train_combined = X_train_combined['HIGH_ENROLLMENT'].map({'Y': 1, 'N': 0})
        # No separate validation set, so evaluation will be on the full training set
        is_validation_split = False
    else:
        validation_year = unique_years[-1]
        
        X_train_val = train_df_fe[train_df_fe['TERM_YEAR'] < validation_year].copy()
        X_val = train_df_fe[train_df_fe['TERM_YEAR'] >= validation_year].copy()

        y_train_val = X_train_val['HIGH_ENROLLMENT'].map({'Y': 1, 'N': 0})
        y_val = X_val['HIGH_ENROLLMENT'].map({'Y': 1, 'N': 0})

        X_train_combined = pd.concat([X_train_val, X_val]).copy() # For full predictions for eval script
        y_train_combined = pd.concat([y_train_val, y_val]).copy() # For full predictions for eval script
        is_validation_split = True
    
    # Store TERM_CODE and SUBJECT_ID_SORT for full training set before dropping
    train_submission_keys = train_df_fe[['TERM_CODE', 'SUBJECT_ID_SORT']].copy()

    # Drop target and identifier columns from features
    cols_to_drop = ['HIGH_ENROLLMENT', 'TERM_CODE', 'SUBJECT_ID_SORT']
    
    # Prepare data for preprocessing
    if is_validation_split:
        X_train_val_processed = X_train_val.drop(columns=cols_to_drop, errors='ignore')
        X_val_processed = X_val.drop(columns=cols_to_drop, errors='ignore')
    else:
        X_train_val_processed = X_train_combined.drop(columns=cols_to_drop, errors='ignore')
        X_val_processed = pd.DataFrame(columns=X_train_val_processed.columns) # Empty for consistent pipeline

    print(f"\nTraining data (for model fit) shape: {X_train_val_processed.shape}")
    if is_validation_split:
        print(f"Validation data (for model eval) shape: {X_val_processed.shape}")
        print(f"Validation year(s): {validation_year}")
    else:
        print("No separate validation set due to insufficient unique years. Training on all data.")

    # Numerical Imputation
    num_imputer = SimpleImputer(strategy='mean')
    if not X_train_val_processed.empty and numerical_features:
        X_train_val_processed[numerical_features] = num_imputer.fit_transform(X_train_val_processed[numerical_features])
    
    if not X_val_processed.empty and numerical_features:
        X_val_processed[numerical_features] = num_imputer.transform(X_val_processed[numerical_features])

    # Categorical Imputation and One-Hot Encoding
    # Keep track of all OHE columns from training to align validation/test
    trained_ohe_columns = [] 

    for col in categorical_features:
        # Impute missing categorical values with the mode
        mode_val = None
        if not X_train_val_processed.empty and col in X_train_val_processed.columns:
            mode_val = X_train_val_processed[col].mode()[0]
            X_train_val_processed[col] = X_train_val_processed[col].fillna(mode_val).astype(str)
        if not X_val_processed.empty and col in X_val_processed.columns:
            mode_val_val = mode_val if mode_val is not None else X_val_processed[col].mode()[0]
            X_val_processed[col] = X_val_processed[col].fillna(mode_val_val).astype(str)

        # One-hot encode
        if not X_train_val_processed.empty and col in X_train_val_processed.columns:
            train_dummies = pd.get_dummies(X_train_val_processed[col], prefix=col, dummy_na=False)
            X_train_val_processed = pd.concat([X_train_val_processed, train_dummies], axis=1)
            X_train_val_processed = X_train_val_processed.drop(columns=[col])
            trained_ohe_columns.extend(train_dummies.columns.tolist())
        
        if not X_val_processed.empty and col in X_val_processed.columns:
            val_dummies = pd.get_dummies(X_val_processed[col], prefix=col, dummy_na=False)
            
            # Align validation dummies with training dummies
            for c in set(trained_ohe_columns) - set(val_dummies.columns):
                val_dummies[c] = 0
            val_dummies = val_dummies[trained_ohe_columns] # Ensure order and only include cols seen in training

            X_val_processed = pd.concat([X_val_processed, val_dummies], axis=1)
            X_val_processed = X_val_processed.drop(columns=[col])
        else: # if X_val_processed is empty, add dummy columns to keep structure consistent
            for c in [d_col for d_col in trained_ohe_columns if d_col.startswith(col + '_')]:
                X_val_processed[c] = 0.0 # Make sure they are float for numeric consistency

    # Final selection of numerical features and alignment
    X_train_val_final = X_train_val_processed.select_dtypes(include=np.number)
    
    if not X_val_processed.empty:
        X_val_final = X_val_processed.select_dtypes(include=np.number)
        for col in X_train_val_final.columns:
            if col not in X_val_final.columns:
                X_val_final[col] = 0.0
        X_val_final = X_val_final[X_train_val_final.columns] # Ensure same column order
    else:
        X_val_final = pd.DataFrame(columns=X_train_val_final.columns, dtype=float)


    print(f"\nFinal training features shape for model: {X_train_val_final.shape}")
    print(f"Final validation features shape for model: {X_val_final.shape}")

    # Model Training
    print("\nTraining RandomForestClassifier...")
    model = RandomForestClassifier(n_estimators=100, random_state=42, class_weight='balanced') # Use class_weight due to imbalance
    model.fit(X_train_val_final, y_train_val) # Train only on training slice
    print("Model training complete.")

    # Generate predictions for the *entire* training dataset (including the validation slice)
    # Combine X_train_val_final and X_val_final for full prediction on the training set
    X_full_train_for_pred = pd.concat([X_train_val_final, X_val_final])
    
    # Ensure correct index alignment for y_train_combined for evaluation
    y_full_train_preds_proba = model.predict_proba(X_full_train_for_pred)[:, 1]
    y_full_train_preds = (y_full_train_preds_proba > 0.5).astype(int)
    y_full_train_pred_labels = np.where(y_full_train_preds == 1, 'Y', 'N')

    # Create full training submission file for evaluation
    full_train_submission_df = pd.DataFrame({
        'TERM_CODE': train_submission_keys['TERM_CODE'],
        'SUBJECT_ID_SORT': train_submission_keys['SUBJECT_ID_SORT'],
        'HIGH_ENROLLMENT': y_full_train_pred_labels
    })
    full_train_submission_path = os.path.join(output_dir, 'submission.csv')
    full_train_submission_df.to_csv(full_train_submission_path, index=False)
    print(f"\nFull training set predictions saved to {full_train_submission_path}")

    # Evaluate validation predictions (using the full submission file)
    print("\nEvaluating full training set predictions for macro F1...")
    try:
        eval_script_path = os.path.join(os.path.dirname(__file__), '../scripts/print_eval_metric.py')
        command = ['python', eval_script_path, '--pred', full_train_submission_path, '--split', 'train']
        result = subprocess.run(command, capture_output=True, text=True, check=True)
        print("Evaluation Script Output:")
        print(result.stdout)
    except subprocess.CalledProcessError as e:
        print(f"Error running evaluation script: {e}")
        print(f"Stdout: {e.stdout}")
        print(f"Stderr: {e.stderr}")
    except FileNotFoundError:
        print(f"Error: Evaluation script not found at {eval_script_path}. Make sure the path is correct.")

    # --- Test Data Prediction (if test_dir is provided) ---
    if test_df is not None:
        print("\n--- Generating Test Predictions ---")
        test_df_fe, _, _ = feature_engineer(test_df.copy())

        test_submission_keys = test_df_fe[['TERM_CODE', 'SUBJECT_ID_SORT']].copy()
        test_df_processed = test_df_fe.drop(columns=cols_to_drop, errors='ignore')

        # Numerical Imputation (using train's fitted imputer)
        if numerical_features:
            test_df_processed[numerical_features] = num_imputer.transform(test_df_processed[numerical_features])

        # Categorical Imputation and One-Hot Encoding
        for col in categorical_features:
            if col in test_df_processed.columns:
                mode_val = train_df_fe[col].mode()[0] if col in train_df_fe.columns else test_df_processed[col].mode()[0]
                test_df_processed[col] = test_df_processed[col].fillna(mode_val).astype(str)

                test_dummies = pd.get_dummies(test_df_processed[col], prefix=col, dummy_na=False)
                
                # Align test dummies with training dummies
                for c in set(trained_ohe_columns) - set(test_dummies.columns):
                    test_dummies[c] = 0
                test_dummies = test_dummies[trained_ohe_columns] # Ensure order and only include cols seen in training

                test_df_processed = pd.concat([test_df_processed, test_dummies], axis=1)
                test_df_processed = test_df_processed.drop(columns=[col])
            else:
                for c in [d_col for d_col in trained_ohe_columns if d_col.startswith(col + '_')]:
                    test_df_processed[c] = 0.0

        # Ensure test features match training features
        test_df_processed = test_df_processed.select_dtypes(include=np.number)
        for col in X_train_val_final.columns:
            if col not in test_df_processed.columns:
                test_df_processed[col] = 0.0 # Fill with 0.0 as it's a numerical dataframe
        test_df_processed = test_df_processed[X_train_val_final.columns] # Ensure same column order

        test_preds_proba = model.predict_proba(test_df_processed)[:, 1]
        test_preds = (test_preds_proba > 0.5).astype(int)
        test_pred_labels = np.where(test_preds == 1, 'Y', 'N')

        test_submission_df = pd.DataFrame({
            'TERM_CODE': test_submission_keys['TERM_CODE'],
            'SUBJECT_ID_SORT': test_submission_keys['SUBJECT_ID_SORT'],
            'HIGH_ENROLLMENT': test_pred_labels
        })
        test_submission_path = os.path.join(output_dir, 'submission.csv')
        test_submission_df.to_csv(test_submission_path, index=False)
        print(f"Test predictions saved to {test_submission_path}")


def main():
    parser = argparse.ArgumentParser(description="Predict high enrollment for course offerings.")
    parser.add_argument('--train-dir', type=str, default='train',
                        help='Directory containing training data tables.')
    parser.add_argument('--test-dir', type=str, default=None,
                        help='Directory containing test data tables (optional, for inference).')
    parser.add_argument('--output-dir', type=str, default='.',
                        help='Directory to save submission.csv.')
    
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    train_df = preprocess_data(args.train_dir, is_train=True)
    
    test_df = None
    if args.test_dir and os.path.exists(args.test_dir):
        test_df = preprocess_data(args.test_dir, is_train=False)

    run_pipeline(train_df, test_df, args.output_dir)

if __name__ == '__main__':
    main()
