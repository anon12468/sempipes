"""
X2 Blocking — Electronic Products
==================================
Strategy (all feasible for ~2M records):
  1. Inverted index on extracted model codes   → high precision, small buckets
  2. Inverted index on brand+product_line+cap  → broader recall, capped buckets
  3. Inverted index on rare / discriminative tokens (freq-adaptive cap)
  4. MinHash LSH on feature vectors            → cross-language fuzzy matching

Bucket-size cap (MAX_BUCKET) keeps every bucket O(k²) with k≤MAX_BUCKET.
Token frequencies are computed live so the cap scales with the actual dataset.
A global pair budget prevents unbounded memory on the full 2M-record dataset.

Output: results/output.csv  (exactly 2,000,000 lid,rid pairs; lid<rid; no dupes)
"""

import pandas as pd
import numpy as np
import re
import os
import hashlib
from collections import defaultdict, Counter

# ────────────────────────────────────────────────────────────
#  Configuration
# ────────────────────────────────────────────────────────────
MAX_BUCKET        = 200      # cap: skip inverted-index buckets larger than this
PAIR_BUDGET       = 12_000_000  # soft ceiling on stored candidate pairs
OUTPUT_SIZE       = 2_000_000

# MinHash LSH: 64 hashes split into 16 bands × 4 rows
# P(collision | Jaccard=j) = 1-(1-j^4)^16  ≈50% at j≈0.5
N_HASHES = 64
N_BANDS  = 16
N_ROWS   = 4   # N_HASHES // N_BANDS


# ────────────────────────────────────────────────────────────
#  Text normalisation helpers
# ────────────────────────────────────────────────────────────
def normalize(text):
    t = str(text).lower()
    t = re.sub(r'(\d+)\s*go\b',   r'\1gb', t)   # French: Go = GB
    t = re.sub(r'(\d+)\s*mo\b',   r'\1mb', t)   # French: Mo = MB
    t = re.sub(r'(\d+)\s*gig\b',  r'\1gb', t)
    t = re.sub(r'[^a-z0-9 ]', ' ', t)
    return re.sub(r'\s+', ' ', t).strip()


def extract_capacity(norm_name):
    for m in re.finditer(r'(\d+)\s*tb\b', norm_name):
        return str(int(m.group(1)) * 1024) + 'gb'
    for m in re.finditer(r'(\d+)\s*gb\b', norm_name):
        return m.group(1) + 'gb'
    return None


# ────────────────────────────────────────────────────────────
#  Brand lookup
# ────────────────────────────────────────────────────────────
BRAND_MAP = {
    'sandisk':       'sandisk', 'san disk':    'sandisk',
    'kingston':      'kingston',
    'toshiba':       'toshiba',
    'sony':          'sony',
    'lexar':         'lexar',
    'intenso':       'intenso',
    'samsung':       'samsung',
    'transcend':     'transcend',
    'verbatim':      'verbatim',
    'pny':           'pny',
    'emtec':         'emtec',
    'goodram':       'goodram',
    'strontium':     'strontium',
    'patriot':       'patriot',
    'corsair':       'corsair',
    'integral':      'integral',
    'hama':          'hama',
    'mediarange':    'mediarange',
    'platinet':      'platinet',
    'silicon power': 'silicon_power',
    'imation':       'imation',
    'pretec':        'pretec',
}

def extract_brand(brand_field, norm_name):
    # 1. Check the explicit brand field first
    brand_str = normalize(str(brand_field))
    if brand_str and brand_str != 'nan':
        for b, bn in BRAND_MAP.items():
            if b in brand_str:
                return bn
    # 2. Find the FIRST occurrence of any known brand in the name.
    #    Walking token-by-token ensures we pick the primary brand, not a
    #    competitor brand that might appear later in catalog descriptions.
    tokens = norm_name.split()
    for i, tok in enumerate(tokens):
        if tok in BRAND_MAP:
            return BRAND_MAP[tok]
        if i + 1 < len(tokens):
            two = tok + ' ' + tokens[i + 1]
            if two in BRAND_MAP:
                return BRAND_MAP[two]
    return None


# ────────────────────────────────────────────────────────────
#  Product-line patterns  (checked against condensed/no-space text)
# ────────────────────────────────────────────────────────────
PRODUCT_LINES = [
    # SanDisk USB sticks
    ('cruzerblade',   'cblade'), ('cruzerglide',  'cglide'),
    ('cruzerfit',     'cfit'),   ('cruzerforce',  'cforce'),
    ('cruzerextreme', 'cextr'),
    ('ultraflair',    'uflair'), ('ultradual',    'udual'),
    ('ultrafit',      'ufit'),
    # SanDisk SD / specific product codes
    ('sdsdxs', 'sdsdxs'), ('sdcz80', 'sdcz80'), ('sdcz60', 'sdcz60'),
    ('sdcz48', 'sdcz48'), ('sdcz50', 'sdcz50'), ('sdcz36', 'sdcz36'),
    ('sddd3',  'sddd3'),
    # Lexar
    ('jumpdrive', 'jd'),    ('ljdc20m', 'ljdc20m'), ('c20m', 'c20m'),
    ('ljdc20c', 'ljdc20c'), ('c20c', 'c20c'),
    ('ljds70',  's70'),     ('ljds25', 's25'),       ('ljds45', 's45'),
    ('ljdp20',  'p20'),
    ('s70', 's70'), ('s25', 's25'), ('s45', 's45'), ('p20', 'p20'),
    # Kingston
    ('datatraveler', 'dt'),
    ('dt101', 'dt101'), ('dt100', 'dt100'), ('dt50', 'dt50'),
    ('dt104', 'dt104'), ('dt109', 'dt109'),
    ('hyperx', 'hx'),
    # Intenso
    ('basicline',    'basic'),  ('premiumline',  'prem'),
    ('rainbowline',  'rain'),   ('speedline',    'speed'),
    ('miniline',     'mini'),   ('ultraline',    'ultra'),
    ('slimline',     'slim'),   ('twister',      'twist'),
    ('imobile',      'imob'),   ('splashline',   'splash'),
    # Toshiba
    ('transmemory',  'tmem'),   ('exceria',      'exceria'),
    ('exceriapro',   'expro'),  ('exeria',       'exceria'),  # typo variant
    ('u401', 'u401'), ('u202', 'u202'), ('u203', 'u203'), ('u301', 'u301'),
    ('n302', 'n302'), ('n401', 'n401'), ('m401', 'm401'),
    # Sony  (USM prefix is Sony's MicroVault line)
    ('microvault', 'mv'), ('usm', 'mv'),
    # PNY
    ('attache4', 'att4'), ('attach4', 'att4'),
    # Kingston – DataTraveler variants with explicit model number in name
    ('datatraveler101', 'dt101'), ('datatraveler100', 'dt100'),
    ('datatraveler50',  'dt50'),  ('datatraveler104', 'dt104'),
    ('datatraveler109', 'dt109'),
    # Generic type markers (useful combined with brand)
    ('microsdhc', 'msdhc'), ('microsdxc', 'msdxc'),
    ('sdxc', 'sdxc'), ('sdhc', 'sdhc'),
]

# Terms that look like model codes but are just category descriptors
AM_BLACKLIST = {
    'CL10', 'CL4', 'CL6', 'CL2', 'U1C', 'U3C',
    'UHS1', 'UHS2', 'USB2', 'USB3', 'USB4',
    'SDXC', 'SDHC', 'SDSC', 'MSDHC', 'MSDXC',
    'CFAST', 'V30', 'V60', 'V90',
    'TYPE', 'MBPS', 'GBPS', 'KBPS',
    'CLASS', 'CLASSE', 'KLASSE',
}


# ────────────────────────────────────────────────────────────
#  Model-code extraction
# ────────────────────────────────────────────────────────────
def get_model_codes(name_upper):
    """
    Returns {(key_type, code): weight}.
    Requires at least one digit so generic tech terms (USB-STICK, UHS-II) are dropped.
    """
    codes = {}

    # Long hyphenated/slashed codes, e.g. SDCZ80-016G-B35, THN-U202W1280E4
    for m in re.finditer(r'[A-Z0-9]{2,}(?:[-/][A-Z0-9]{2,})+', name_upper):
        code = m.group().replace('/', '-')
        if len(code) >= 6 and re.search(r'\d', code):
            codes[('lm', code)] = 15

    # Short alphanumeric codes, e.g. N401, CZ80, S70, DT101G2
    for m in re.finditer(r'\b[A-Z]{1,4}\d{2,}[A-Z0-9]{0,8}\b', name_upper):
        code = m.group()
        if (len(code) >= 4
                and code not in AM_BLACKLIST
                and re.search(r'[A-Z]', code)
                and re.search(r'\d', code)):
            codes[('am', code)] = 8

    # Pure numeric catalog codes, e.g. 3503470 (Intenso)
    for m in re.finditer(r'\b\d{6,}\b', name_upper):
        codes[('nm', m.group())] = 12

    return codes


# ────────────────────────────────────────────────────────────
#  Full key extraction for one record
# ────────────────────────────────────────────────────────────
def get_all_keys(norm_name, name_upper, brand_field, pl_found, brand, cap):
    """
    Returns {(key_type, key_value): score}.
    Score is used later to rank candidate pairs.
    """
    keys = {}

    # 1. Model codes (highest specificity)
    keys.update(get_model_codes(name_upper))

    # 2. Brand + capacity combinations
    if brand and cap:
        keys[('bc',   brand + '_' + cap)] = 4
        for pl in pl_found:
            keys[('bplc', brand + '_' + pl + '_' + cap)] = 7

    if cap:
        for pl in pl_found:
            keys[('plc', pl + '_' + cap)] = 6

    if brand:
        for pl in pl_found:
            keys[('bp',  brand + '_' + pl)] = 3

    return keys


# ────────────────────────────────────────────────────────────
#  Feature set for MinHash
# ────────────────────────────────────────────────────────────
def make_features(name_upper, brand, cap, pl_found):
    feats = set()
    if brand:
        feats.add('B_' + brand)
    if cap:
        feats.add('C_' + cap)
    for pl in pl_found:
        feats.add('P_' + pl)
    # Prefix of model codes keeps cross-listing robustness
    for ktype, code in get_model_codes(name_upper):
        feats.add('M_' + code[:10])
    return frozenset(feats)


# ────────────────────────────────────────────────────────────
#  MinHash
# ────────────────────────────────────────────────────────────
_HP = None

def _hash_params():
    global _HP
    if _HP is None:
        rng = np.random.RandomState(42)
        p = np.uint64(2**31 - 1)
        a = rng.randint(1, int(p), size=N_HASHES, dtype=np.uint64)
        b = rng.randint(0, int(p), size=N_HASHES, dtype=np.uint64)
        _HP = (a, b, p)
    return _HP

def compute_minhash(feats):
    if not feats:
        return np.zeros(N_HASHES, dtype=np.uint64)
    a, b, p = _hash_params()
    sig = np.full(N_HASHES, np.iinfo(np.uint64).max, dtype=np.uint64)
    for feat in feats:
        h = np.uint64(int(hashlib.md5(feat.encode()).hexdigest()[:8], 16) & 0xFFFFFFFF)
        vals = (a * h + b) % p
        sig = np.minimum(sig, vals)
    return sig


# ────────────────────────────────────────────────────────────
#  Core blocking
# ────────────────────────────────────────────────────────────
def generate_candidates(X2, max_bucket=MAX_BUCKET, pair_budget=PAIR_BUDGET):
    """
    Returns a list of (real_id_a, real_id_b) pairs sorted by descending quality.
    a < b guaranteed.  Length may exceed OUTPUT_SIZE; caller truncates.
    """
    n = len(X2)
    ids   = X2['id'].values
    names = X2['name'].values
    has_brand = 'brand' in X2.columns
    brands = X2['brand'].values if has_brand else [None] * n

    # ── Pre-compute token frequencies for adaptive rare-token threshold ──
    print("  Computing token frequencies …")
    tok_freq = Counter()
    norm_names = []
    for raw in names:
        nn = normalize(str(raw))
        norm_names.append(nn)
        for t in nn.split():
            tok_freq[t] += 1

    # Scale rare-token cap with dataset size so full-dataset buckets stay ≤ max_bucket
    # rt_max_freq ~ 0.5% of records, minimum 50 occurrences
    rt_max_freq = max(50, min(int(n * 0.005), max_bucket))
    print(f"  Rare-token max freq: {rt_max_freq}  (n={n})")

    # ── Extract per-record keys and features ──────────────────────────────
    print("  Extracting per-record keys …")
    rec_keys    = []   # [{(ktype, kval): score}]
    rec_feats   = []   # [frozenset]
    rec_rt_toks = []   # [{token, …}]  rare discriminative tokens

    # Pre-allocate sigs as uint32 (values are < 2^31 so safe to down-cast from uint64)
    # This halves memory vs uint64 and avoids an intermediate large allocation.
    sigs = np.empty((n, N_HASHES), dtype=np.uint32)   # (n, N_HASHES)

    for i in range(n):
        raw       = str(names[i])
        n_upper   = raw.upper()
        n_norm    = norm_names[i]
        condensed = n_norm.replace(' ', '')

        brand = extract_brand(brands[i], n_norm)
        cap   = extract_capacity(n_norm)
        pl    = [v for p, v in PRODUCT_LINES if p in condensed]

        keys  = get_all_keys(n_norm, n_upper, brands[i], pl, brand, cap)
        feats = make_features(n_upper, brand, cap, pl)
        sigs[i] = compute_minhash(feats)  # uint64 auto-cast to uint32 (safe)

        # Rare (discriminative) tokens: ≥4 chars, not pure digits, freq in [2, rt_max_freq]
        rt = {t for t in n_norm.split()
              if len(t) >= 4 and not t.isdigit()
              and 2 <= tok_freq[t] <= rt_max_freq}

        rec_keys.append(keys)
        rec_feats.append(feats)
        rec_rt_toks.append(rt)

    # ── Build inverted index ──────────────────────────────────────────────
    print("  Building inverted index …")
    # Group by key-type for efficient priority iteration
    inv_by_type: dict = {t: {} for t in ['lm','nm','am','bplc','plc','bc','bp','rt']}

    for i in range(n):
        for key in rec_keys[i]:
            kt, kv = key
            if kt in inv_by_type:
                inv_by_type[kt].setdefault(kv, []).append(i)
        for tok in rec_rt_toks[i]:
            inv_by_type['rt'].setdefault(tok, []).append(i)

    total_keys = sum(len(d) for d in inv_by_type.values())
    print(f"  Inverted index: {total_keys:,} keys")

    # Scoring weights per key type
    KEY_WEIGHT = {'lm': 15, 'nm': 12, 'am': 8, 'bplc': 7, 'plc': 6,
                  'bc': 4, 'bp': 3, 'rt': 2}

    # Sorted-Neighborhood window for buckets that exceed max_bucket
    # (linear-time alternative to O(k²): compare each record to next SNM_W neighbours
    # when sorted by normalised name within the bucket)
    SNM_W = 40          # window size for SNM pass on large buckets
    MAX_SNM_K = 50_000  # skip entirely if bucket exceeds this

    def _emit_all(bucket, w):
        """Emit all O(k²) pairs from a small bucket."""
        bucket_s = sorted(bucket)
        k = len(bucket_s)
        for ii in range(k):
            for jj in range(ii + 1, k):
                ia, ib = bucket_s[ii], bucket_s[jj]
                ra, rb = int(ids[ia]), int(ids[ib])
                if ra > rb: ra, rb = rb, ra
                pair = (ra, rb)
                if pair in pair_scores:
                    pair_scores[pair] += w
                else:
                    pair_scores[pair] = w

    def _emit_snm(bucket, w):
        """Emit O(k × SNM_W) pairs via Sorted-Neighbourhood Method."""
        # Sort by normalised name within the bucket for locality
        bucket_s = sorted(bucket, key=lambda i: norm_names[i])
        k = len(bucket_s)
        for ii in range(k):
            for jj in range(ii + 1, min(ii + SNM_W + 1, k)):
                ia, ib = bucket_s[ii], bucket_s[jj]
                ra, rb = int(ids[ia]), int(ids[ib])
                if ra > rb: ra, rb = rb, ra
                pair = (ra, rb)
                if pair in pair_scores:
                    pair_scores[pair] += w
                else:
                    pair_scores[pair] = w

    # ── Collect pairs (priority order: most specific first) ───────────────
    print("  Collecting inverted-index pairs …")
    pair_scores = {}   # (id_a, id_b) → cumulative score

    priority_types = ['lm', 'nm', 'am', 'bplc', 'plc', 'bc', 'bp', 'rt']

    budget_exceeded = False
    for ktype in priority_types:
        if budget_exceeded:
            break
        w = KEY_WEIGHT.get(ktype, 1)
        for kv, bucket in inv_by_type[ktype].items():
            k = len(bucket)
            if k < 2:
                continue
            if k <= max_bucket:
                _emit_all(bucket, w)
            elif k <= MAX_SNM_K:
                _emit_snm(bucket, w - 1)   # SNM pairs are slightly lower quality
            # else: skip (k > MAX_SNM_K)

            if len(pair_scores) >= pair_budget:
                print(f"    Pair budget reached at key type '{ktype}' – stopping early")
                budget_exceeded = True
                break

    print(f"  Pairs after inverted index: {len(pair_scores):,}")

    # ── MinHash LSH ────────────────────────────────────────────────────────
    if not budget_exceeded:
        print("  Running MinHash LSH …")
        for band in range(N_BANDS):
            band_idx = defaultdict(list)
            cols = sigs[:, band * N_ROWS: (band + 1) * N_ROWS]
            for i in range(n):
                if not rec_feats[i]:
                    continue
                bkey = tuple(cols[i].tolist())
                band_idx[bkey].append(i)

            for bucket in band_idx.values():
                k = len(bucket)
                if k < 2 or k > max_bucket:
                    continue
                bucket_s = sorted(bucket)
                for ii in range(k):
                    for jj in range(ii + 1, k):
                        ia, ib = bucket_s[ii], bucket_s[jj]
                        ra, rb = int(ids[ia]), int(ids[ib])
                        if ra > rb:
                            ra, rb = rb, ra
                        pair = (ra, rb)
                        if pair in pair_scores:
                            pair_scores[pair] += 2
                        else:
                            pair_scores[pair] = 2

            if len(pair_scores) >= pair_budget:
                print("    Pair budget reached during LSH – stopping early")
                break

        print(f"  Pairs after LSH: {len(pair_scores):,}")

    # ── Sort by score (descending) ─────────────────────────────────────────
    print("  Sorting candidates by score …")
    sorted_pairs = sorted(pair_scores.keys(),
                          key=lambda p: pair_scores[p],
                          reverse=True)
    return sorted_pairs


# ────────────────────────────────────────────────────────────
#  Entry point
# ────────────────────────────────────────────────────────────
def main():
    import time
    t0 = time.time()

    # ── Locate X2 file (tries several common paths) ──────────
    candidates_for_x2 = [
        "/Users/USER/Documents/UNI/SS26/SIGMOD_full_data/X2.csv",
    ]
    x2_path = None
    for p in candidates_for_x2:
        if os.path.exists(p):
            x2_path = p
            break
    if x2_path is None:
        raise FileNotFoundError(
            f"Cannot find X2.csv in any of: {candidates_for_x2}"
        )

    print(f"Reading X2 from '{x2_path}' …")
    X2 = pd.read_csv(x2_path)
    print(f"  {len(X2):,} records")

    print("Generating candidates …")
    candidates = generate_candidates(X2)
    print(f"  {len(candidates):,} unique candidates  ({time.time()-t0:.1f}s)")

    # Pad or trim to exactly OUTPUT_SIZE
    if len(candidates) > OUTPUT_SIZE:
        candidates = candidates[:OUTPUT_SIZE]
    elif len(candidates) < OUTPUT_SIZE:
        candidates += [(0, 0)] * (OUTPUT_SIZE - len(candidates))

    os.makedirs("results", exist_ok=True)
    out = pd.DataFrame(candidates, columns=["lid", "rid"])
    out.to_csv("results/output2.csv", index=False)
    print(f"Saved results/output2.csv  ({len(out):,} rows, {time.time()-t0:.1f}s total)")


if __name__ == "__main__":
    main()
