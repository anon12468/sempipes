"""
Entity Resolution Blocking for X2 (Electronic Products)

Improvements over baseline blocking.py:
- 64-band MinHash LSH (vs 32-band) for better cross-language coverage
- Larger sorted-neighborhood windows for full-scale dataset (window=20 vs 10)
- Normalized model codes (strip punctuation, catch single-letter prefixes like U202)
- Catalog number blocking (6-8 digit product codes like Intenso 3503470)
- Coarse type grouping key (sdhc/sdxc/microsd merged → "sd_family")
- Stop-word-filtered MinHash (exclude very common tokens like "usb", "gb")
- Brand+coarse_type+cap and brand+cap blocking keys
- Additional brand keywords and model-prefix patterns

Feasibility for 2M records:
  - Sorted neighborhood is O(k × window) per bucket; no O(k²) for large k
  - LSH buckets capped at LSH_MAX to prevent quadratic blowup
  - Total candidates ≤ ~50M → scoring in numpy takes < 2 min
  - Total runtime target: < 20 min on a single machine
"""

import os
import re
from collections import defaultdict

import numpy as np
import pandas as pd

# ── MinHash parameters ────────────────────────────────────────────────────────
NUM_HASHES    = 64
NUM_BANDS     = 64        # 64 bands × 1 row → more sensitive than 32×2
ROWS_PER_BAND = 1

np.random.seed(42)
_PRIME  = (1 << 31) - 1
_HASH_A = np.random.randint(1, _PRIME, NUM_HASHES, dtype=np.int64)
_HASH_B = np.random.randint(0, _PRIME, NUM_HASHES, dtype=np.int64)

MAX_PAIRS = 2_000_000

# ── Brand detection ──────────────────────────────────────────────────────────
BRAND_KEYWORDS = {
    'sandisk': 'sandisk', 'san disk': 'sandisk', 'san-disk': 'sandisk',
    'cruizer': 'sandisk',   # common misspelling of Cruzer → SanDisk
    'sony': 'sony',
    'toshiba': 'toshiba',
    'kingston': 'kingston', 'kingstn': 'kingston',
    'lexar': 'lexar',
    'intenso': 'intenso',
    'transcend': 'transcend',
    'samsung': 'samsung',
    'pny': 'pny',
    'verbatim': 'verbatim',
    'patriot': 'patriot',
    'corsair': 'corsair',
    'strontium': 'strontium',
    'adata': 'adata',
    'hama': 'hama',
    'goodram': 'goodram',
    'emtec': 'emtec',
    'silicon power': 'silicon power',
    'silicone power': 'silicon power',
    'takeMS': 'takems',
    'takems': 'takems',
    'integral': 'integral',
    'platinet': 'platinet',
    'blueray': 'blueray',
    'saber': 'saber',
}

LINE_TO_BRAND = {
    'cruzer':        'sandisk',
    'ultra dual':    'sandisk',
    'ultra usb':     'sandisk',
    'extreme pro':   'sandisk',
    'extreme plus':  'sandisk',
    'extreme':       'sandisk',
    'glide':         'sandisk',   # Cruzer Glide
    'blade':         'sandisk',   # Cruzer Blade
    'datatraveler':  'kingston',
    'data traveler': 'kingston',
    'hyperx':        'kingston',
    'canvas go':     'kingston',
    'canvas react':  'kingston',
    'canvas select': 'kingston',
    'canvas':        'kingston',
    'jumpdrive':     'lexar',
    'jumpsdrive':    'lexar',
    'exceria pro':   'toshiba',
    'exceria':       'toshiba',
    'transmemory':   'toshiba',
    'flashair':      'toshiba',
    'rainbow':       'intenso',
    'basic line':    'intenso',
    'premium line':  'intenso',
    'attache4':      'pny',
    'attache 4':     'pny',
    'attache':       'pny',
    'memory stick':  'sony',
    'micro vault':   'sony',
    'evo plus':      'samsung',
    'evo select':    'samsung',
    'evo':           'samsung',
    'pro endurance': 'samsung',
}

MODEL_PREFIX_BRAND = {
    'USM':  'sony',
    'SF':   'sony',
    'SR':   'sony',
    'SFD':  'sony',
    'THN':  'toshiba',
    'THNM': 'toshiba',
    'SDCZ': 'sandisk',
    'SDSD': 'sandisk',
    'SDXC': 'sandisk',
    'SDSQX': 'sandisk',
    'SDSQUA': 'sandisk',
    'DT':   'kingston',
    'SDA':  'kingston',
    'SDC':  'kingston',
    'LJDS': 'lexar',
    'LJDC': 'lexar',
    'LJDP': 'lexar',
    'LJDT': 'lexar',
    'LJDX': 'lexar',
    'TS':   'transcend',
    'MB':   'samsung',
    'MSD':  'samsung',
}

# Toshiba short model codes: U202, U301, U401
_TOSHIBA_U_RE = re.compile(r'\bU[0-9]{3}[A-Z0-9]*\b', re.IGNORECASE)

_VALID_CAPS = frozenset({1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048})


def _norm(s: str) -> str:
    s = re.sub(r'&[a-z]+;', ' ', str(s).lower())
    s = re.sub(r'[^a-z0-9\s]', ' ', s)
    return re.sub(r'\s+', ' ', s).strip()


def _snap_cap(v: float):
    if v <= 0:
        return None
    best = min(_VALID_CAPS, key=lambda c: abs(c - v))
    return best if abs(best - v) / v < 0.12 else None


def extract_brand(name: str, brand_col) -> str:
    b = _norm(str(brand_col))
    n = _norm(str(name))
    n_head = n[:100]

    for kw, brand in BRAND_KEYWORDS.items():
        if kw in b or kw in n_head:
            return brand

    for line_kw, brand in LINE_TO_BRAND.items():
        if line_kw in n_head:
            return brand

    name_up = str(name).upper()
    if re.search(r'\bSR-[A-Z0-9]', name_up):
        return 'sony'
    if _TOSHIBA_U_RE.search(name_up):
        return 'toshiba'
    for prefix, brand in MODEL_PREFIX_BRAND.items():
        if re.search(r'\b' + re.escape(prefix) + r'\d', name_up):
            return brand

    # TOS- prefix (e.g. TOS-U202-128GB-WHI)
    if re.search(r'\bTOS-', name_up):
        return 'toshiba'

    if b and b not in ('nan', ''):
        toks = [t for t in b.split() if len(t) > 2 and not t.isdigit()]
        if toks:
            return toks[0][:10]
    return 'unk'


def extract_cap_gb(s: str) -> int:
    """Extract storage capacity in GB; returns -1 if not found."""
    s_clean = re.sub(r'&[a-z]+;', ' ', str(s).lower())
    s_up    = str(s).upper()

    caps = []

    for m in re.finditer(r'(\d+(?:\.\d+)?)\s*g[ob](?![\w/])', s_clean):
        v = _snap_cap(float(m.group(1)))
        if v:
            caps.append(v)

    for m in re.finditer(r'(\d+(?:\.\d+)?)\s*t[ob](?![\w/])', s_clean):
        v = _snap_cap(float(m.group(1)) * 1024)
        if v:
            caps.append(v)

    for m in re.finditer(r'(\d+)\s*m[ob](?![\w/s])', s_clean):
        raw = int(m.group(1))
        if raw >= 1024:
            v = _snap_cap(raw / 1024)
            if v:
                caps.append(v)

    if caps:
        # Use median to avoid garbage values; filter to valid capacities
        valid = [c for c in caps if c in _VALID_CAPS]
        if valid:
            return int(max(valid))
        return int(max(caps))

    # Infer from known model-code patterns
    for pat in [r'\bUSM(\d+)', r'\bSF(\d+)', r'\bSRG(\d+)', r'\bSFD(\d+)']:
        m = re.search(pat, s_up)
        if m:
            v = _snap_cap(float(m.group(1)))
            if v:
                return int(v)

    m = re.search(r'\bTS(\d+)G', s_up)
    if m:
        v = _snap_cap(float(m.group(1)))
        if v:
            return int(v)

    m = re.search(r'-(\d+)G(?:-|$)', s_up)
    if m:
        v = _snap_cap(float(m.group(1)))
        if v:
            return int(v)

    # Toshiba U-series: e.g. THN-U202W0320E4 → -032- or -064-
    m = re.search(r'U\d{3}[A-Z]?(\d{3,4})', s_up)
    if m:
        raw = int(m.group(1))
        if raw >= 8:
            v = _snap_cap(raw)
            if v:
                return int(v)

    return -1


def extract_type(s: str) -> str:
    t = _norm(str(s)).replace(' ', '')
    if 'microsdhc' in t or 'microsdhx' in t:
        return 'msdhc'
    if 'microsdxc' in t:
        return 'msdxc'
    if 'microsd' in t:
        return 'msd'
    if 'sdxc' in t:
        return 'sdxc'
    if 'sdhc' in t:
        return 'sdhc'
    if 'usb' in t:
        return 'usb'
    s_up = str(s).upper()
    if re.search(r'\bUSM\d', s_up):
        return 'usb'
    if re.search(r'\bSF\d', s_up):
        return 'sdhc'
    if re.search(r'\bSR', s_up) and re.search(r'\bMICRO\b', s_up):
        return 'msd'
    # Toshiba U-series (THN-U*) → USB
    if re.search(r'\bTHN-U\d', s_up) or re.search(r'\bU[0-9]{3}\b', s_up):
        return 'usb'
    return 'unk'


def _coarse_type(t: str) -> str:
    """Group microSD variants and SD variants together."""
    if t in ('msd', 'msdhc', 'msdxc'):
        return 'microsd'
    if t in ('sdhc', 'sdxc'):
        return 'sd'
    return t   # usb, unk stay as-is


_PRODUCT_LINES = [
    ('cruzrglid',    'cruzer glid'),
    ('cruzrblade',   'cruzer blade'),
    ('cruzrforc',    'cruzer forc'),
    ('cruzrflip',    'cruzer flip'),
    ('cruzrspark',   'cruzer spark'),
    ('cruzer',       'cruzer'),
    ('xtremepro',    'extreme pro'),
    ('xtreplus',     'extreme plus'),
    ('xtreme',       'extreme'),
    ('ultradual',    'ultra dual'),
    ('ultraplus',    'ultra plus'),
    ('ultra',        'ultra'),
    ('datatrav',     'datatraveler'),
    ('datatrav',     'data traveler'),
    ('hyperx',       'hyperx'),
    ('jmpdrvs25',    'jumpdrive s25'),
    ('jmpdrvs70',    'jumpdrive s70'),
    ('jmpdrvc20m',   'jumpdrive c20m'),
    ('jmpdrvc20',    'jumpdrive c20'),
    ('jmpdrvp20',    'jumpdrive p20'),
    ('jmpdrv',       'jumpdrive'),
    ('exceriapro',   'exceria pro'),
    ('exceria',      'exceria'),
    ('rainbow',      'rainbow'),
    ('basicline',    'basic line'),
    ('premiumline',  'premium line'),
    ('transmem',     'transmemory'),
    ('canvago',      'canvas go'),
    ('canvareact',   'canvas react'),
    ('canvassel',    'canvas select'),
    ('canvas',       'canvas'),
    ('evoplust',     'evo plus'),
    ('evosel',       'evo select'),
    ('evo',          'evo'),
    ('flashair',     'flashair'),
    ('memorystk',    'memory stick'),
    ('microvault',   'micro vault'),
    ('attache4',     'attache 4'),
    ('attache4',     'attache4'),
    ('attache',      'attache'),
    ('usmseries',    'usm'),
    ('sfseries',     'sf-'),
]


def extract_line(s: str) -> str:
    n = _norm(str(s))
    for code, kw in _PRODUCT_LINES:
        if kw in n:
            return code
    return ''


# ── Model-code extraction ─────────────────────────────────────────────────────
_MODEL_RE = re.compile(
    r'\b(?:'
    r'[A-Z]{2,6}-[A-Z0-9]{2,}'        # SDA3-128G, THN-U202W, LJDS25-64G
    r'|[A-Z]{2,6}\d{2,}[A-Z]{0,4}'    # CZ80, DT101G2, USM32GR, SF16N4, TS64GSD2U3
    r')\b'
)

# Single-letter model codes: U202, U301, U401, T64 etc. (≥ 3 digits, known prefixes)
_SHORT_MODEL_RE = re.compile(r'\b(U|T|B|F|M)[0-9]{3}[A-Z0-9]*\b', re.IGNORECASE)


def extract_model_codes(s: str):
    codes = set()
    text = str(s).upper()
    for m in _MODEL_RE.finditer(text):
        c = m.group(0)
        if len(c) >= 4:
            codes.add(c)
    for m in _SHORT_MODEL_RE.finditer(text):
        c = m.group(0).upper()
        if len(c) >= 4:
            codes.add(c)
    return codes


def extract_norm_model_codes(s: str):
    """Normalized codes: strip all non-alphanumeric, lowercase → e.g. 'sdcz80064g'."""
    codes = extract_model_codes(s)
    return {re.sub(r'[^a-z0-9]', '', c.lower()) for c in codes if len(c) >= 4}


# Catalog numbers: 6–8-digit pure numeric codes (e.g. Intenso 3503470)
_CATALOG_RE = re.compile(r'\b([0-9]{6,8})\b')


def extract_catalog_nums(s: str):
    return set(_CATALOG_RE.findall(str(s)))


# ── MinHash ───────────────────────────────────────────────────────────────────

# Stopwords to exclude from MinHash (reduce noise from very common tokens)
_STOPWORDS = frozenset({
    'usb', 'gb', 'mb', 'tb', 'class', 'card', 'flash', 'drive',
    'memory', 'stick', 'sd', 'micro', 'speed', 'read', 'write',
    'high', 'ultra', 'pro', 'plus', 'max', 'new', 'black', 'white',
    'blue', 'red', 'silver', 'gold', 'with', 'for', 'and', 'the',
    'de', 'le', 'la', 'cl', 'go', 'mo', 'ko', 'in', 'zu', 'von',
})


def _tokenize(name: str):
    """Word tokens (stopword-filtered) + char 3-grams for robustness."""
    n = _norm(name)
    words = [w for w in n.split() if w not in _STOPWORDS and len(w) >= 2]
    chars = n.replace(' ', '')
    trigrams = [chars[i:i+3] for i in range(len(chars) - 2)]
    return words + trigrams


def compute_minhash(token_list) -> np.ndarray:
    if not token_list:
        return np.zeros(NUM_HASHES, dtype=np.int64)
    toks = list(set(token_list))
    h = np.array([hash(t) & 0x7FFF_FFFF for t in toks], dtype=np.int64)
    vals = (_HASH_A[:, None] * h[None, :] + _HASH_B[:, None]) % _PRIME
    return vals.min(axis=1)


# ── Blocking helpers ──────────────────────────────────────────────────────────

def _process_bucket(bucket, norms, max_all: int, window: int,
                    out: list, N_enc: int,
                    max_bucket: int = 0, raw_cap: int = 0):
    """
    Append int64-encoded positional pairs (i*N_enc+j, i<j) to out.
    Small buckets: all pairs. Large buckets: sorted-neighborhood with
    adaptive window (halved for k>2000, quartered for k>10000).
    max_bucket: skip if bucket exceeds this (0 = no skip).
    raw_cap: stop appending once out reaches this length (0 = no cap).
    """
    k = len(bucket)
    if k < 2:
        return
    if max_bucket and k > max_bucket:
        return
    if raw_cap and len(out) >= raw_cap:
        return
    if k <= max_all:
        for a in range(k):
            for b in range(a + 1, k):
                i, j = bucket[a], bucket[b]
                if i > j:
                    i, j = j, i
                out.append(i * N_enc + j)
                if raw_cap and len(out) >= raw_cap:
                    return
    else:
        # Adaptive window: scale down for very large buckets
        if k > 10_000:
            w = max(5, window // 4)
        elif k > 2_000:
            w = max(8, window // 2)
        else:
            w = window
        w = min(w, k - 1)
        s = sorted(bucket, key=lambda idx: norms[idx])
        for pos in range(k):
            for d in range(1, w + 1):
                nxt = pos + d
                if nxt >= k:
                    break
                i, j = s[pos], s[nxt]
                if i > j:
                    i, j = j, i
                out.append(i * N_enc + j)
                if raw_cap and len(out) >= raw_cap:
                    return


# ── Main ──────────────────────────────────────────────────────────────────────

def generate_candidates(df: pd.DataFrame):
    """Return exactly MAX_PAIRS (real_id_left, real_id_right) pairs with lid < rid."""

    N = len(df)
    print(f"[blocking] N = {N:,}")

    ids        = np.array(df['id'].tolist(), dtype=np.int64)
    names      = df['name'].tolist()
    brands_col = df['brand'].tolist()

    # ── Small-N shortcut: all-pairs when feasible ──────────────────────────
    # C(N,2) < MAX_PAIRS → emit every possible pair for guaranteed 100% recall.
    total_possible = N * (N - 1) // 2
    if total_possible < MAX_PAIRS:
        print(f"[blocking] Small N: outputting all C({N},2)={total_possible:,} pairs …")
        result = []
        for a in range(N):
            for b in range(a + 1, N):
                ri, rj = int(ids[a]), int(ids[b])
                result.append((min(ri, rj), max(ri, rj)))
        while len(result) < MAX_PAIRS:
            result.append((0, 0))
        print(f"[blocking] Done. {len(result):,} pairs returned.")
        return result

    # ── Feature extraction ─────────────────────────────────────────────────
    print("[blocking] Extracting features …")
    norms_  = [_norm(n) for n in names]
    brands  = [extract_brand(names[i], brands_col[i]) for i in range(N)]
    caps    = [extract_cap_gb(names[i])  for i in range(N)]
    types_  = [extract_type(names[i])   for i in range(N)]
    ctypes  = [_coarse_type(types_[i])  for i in range(N)]
    lines   = [extract_line(names[i])   for i in range(N)]
    models  = [extract_model_codes(names[i])      for i in range(N)]
    nmodels = [extract_norm_model_codes(names[i]) for i in range(N)]
    catalogs= [extract_catalog_nums(names[i])     for i in range(N)]

    # ── MinHash signatures ─────────────────────────────────────────────────
    print("[blocking] Computing MinHash signatures …")
    sigs = np.zeros((N, NUM_HASHES), dtype=np.int64)
    for i in range(N):
        sigs[i] = compute_minhash(_tokenize(names[i]))

    # ── Adaptive parameters ────────────────────────────────────────────────
    if N <= 5_000:
        # Small dataset: very generous → near-100% recall on sample
        MAX_ALL = 500
        WINDOW  = 150
        LSH_MAX = 100
        RAW_CAP = 50_000_000   # 50M cap (3.6 GB Python, won't be hit at this N)
    elif N <= 100_000:
        MAX_ALL = 50
        WINDOW  = 40
        LSH_MAX = 20
        RAW_CAP = 30_000_000
    else:
        # Full 2M-record scale: conservative to stay feasible
        MAX_ALL = 25
        WINDOW  = 20
        LSH_MAX = 10
        RAW_CAP = 60_000_000   # cap raw pairs at 60M (~1.7 GB as Python ints)

    # Use list of int64-encoded pairs (8 bytes each vs 72 for Python tuples).
    # Encoding: i * N_enc + j (i < j).  N_enc = N+1 so all encodings unique.
    N_enc = N + 1
    raw_enc: list = []   # list of int64-encoded pairs

    # ── Key A: Model codes (exact) ─────────────────────────────────────────
    print("[blocking] Key A – model codes (exact) …")
    model_idx: dict = defaultdict(list)
    for i in range(N):
        for code in models[i]:
            model_idx[code].append(i)
    for bucket in model_idx.values():
        _process_bucket(bucket, norms_, max_all=min(MAX_ALL, 50),
                        window=WINDOW + 10, out=raw_enc, N_enc=N_enc, raw_cap=RAW_CAP)

    # ── Key A2: Normalized model codes ─────────────────────────────────────
    print("[blocking] Key A2 – normalized model codes …")
    nmodel_idx: dict = defaultdict(list)
    for i in range(N):
        for code in nmodels[i]:
            if code and len(code) >= 4:
                nmodel_idx[code].append(i)
    for bucket in nmodel_idx.values():
        _process_bucket(bucket, norms_, max_all=min(MAX_ALL, 50),
                        window=WINDOW + 10, out=raw_enc, N_enc=N_enc, raw_cap=RAW_CAP)

    # ── Key A3: Catalog numbers ────────────────────────────────────────────
    print("[blocking] Key A3 – catalog numbers …")
    cat_idx: dict = defaultdict(list)
    for i in range(N):
        for num in catalogs[i]:
            cat_idx[num].append(i)
    for bucket in cat_idx.values():
        _process_bucket(bucket, norms_, max_all=min(MAX_ALL, 50),
                        window=WINDOW, out=raw_enc, N_enc=N_enc, raw_cap=RAW_CAP)

    # ── Key B: brand + cap + type + line ──────────────────────────────────
    print("[blocking] Key B – brand+cap+type+line …")
    bctl: dict = defaultdict(list)
    for i in range(N):
        bctl[f"{brands[i]}_{caps[i]}_{types_[i]}_{lines[i]}"].append(i)
    for bucket in bctl.values():
        _process_bucket(bucket, norms_, max_all=MAX_ALL, window=WINDOW, out=raw_enc, N_enc=N_enc, raw_cap=RAW_CAP)

    # ── Key I: MinHash LSH (64 bands × 1 row) — run EARLY for guaranteed budget
    # Cross-language pairs (e.g. "Clé USB SanDisk" ↔ "USB-Stick SanDisk") rely on
    # LSH, so we run it before the larger structural keys to ensure it gets budget.
    print("[blocking] Key I – MinHash LSH (early) …")
    for b in range(NUM_BANDS):
        band_idx: dict = defaultdict(list)
        s0 = b * ROWS_PER_BAND
        for i in range(N):
            bkey = int(sigs[i, s0])
            band_idx[bkey].append(i)
        for bucket in band_idx.values():
            if len(bucket) <= LSH_MAX:
                _process_bucket(bucket, norms_, max_all=LSH_MAX, window=0,
                                out=raw_enc, N_enc=N_enc, raw_cap=RAW_CAP)

    # ── Key C: brand + cap + type ─────────────────────────────────────────
    print("[blocking] Key C – brand+cap+type …")
    bct: dict = defaultdict(list)
    for i in range(N):
        bct[f"{brands[i]}_{caps[i]}_{types_[i]}"].append(i)
    for bucket in bct.values():
        _process_bucket(bucket, norms_, max_all=MAX_ALL, window=WINDOW, out=raw_enc, N_enc=N_enc, raw_cap=RAW_CAP)

    # ── Key C2: brand + cap + coarse_type ─────────────────────────────────
    # Catches sdhc/sdxc cross-type pairs (same product listed under different SD variant)
    print("[blocking] Key C2 – brand+cap+coarse_type …")
    bcct: dict = defaultdict(list)
    for i in range(N):
        bcct[f"{brands[i]}_{caps[i]}_{ctypes[i]}"].append(i)
    for bucket in bcct.values():
        _process_bucket(bucket, norms_, max_all=MAX_ALL, window=WINDOW, out=raw_enc, N_enc=N_enc, raw_cap=RAW_CAP)

    # ── Key F: brand + line ───────────────────────────────────────────────
    print("[blocking] Key F – brand+line …")
    bl: dict = defaultdict(list)
    for i in range(N):
        if lines[i]:
            bl[f"{brands[i]}_{lines[i]}"].append(i)
    for bucket in bl.values():
        _process_bucket(bucket, norms_, max_all=MAX_ALL, window=WINDOW, out=raw_enc, N_enc=N_enc, raw_cap=RAW_CAP)

    # ── Key D: brand + cap ────────────────────────────────────────────────
    print("[blocking] Key D – brand+cap …")
    bc: dict = defaultdict(list)
    for i in range(N):
        if caps[i] > 0:
            bc[f"{brands[i]}_{caps[i]}"].append(i)
    for bucket in bc.values():
        _process_bucket(bucket, norms_, max_all=MAX_ALL, window=WINDOW, out=raw_enc, N_enc=N_enc, raw_cap=RAW_CAP)

    # ── Key E: brand + type ───────────────────────────────────────────────
    print("[blocking] Key E – brand+type …")
    bt: dict = defaultdict(list)
    for i in range(N):
        if types_[i] != 'unk':
            bt[f"{brands[i]}_{types_[i]}"].append(i)
    for bucket in bt.values():
        _process_bucket(bucket, norms_, max_all=MAX_ALL, window=WINDOW, out=raw_enc, N_enc=N_enc, raw_cap=RAW_CAP)

    # ── Key F2: brand + coarse_type + cap ─────────────────────────────────
    print("[blocking] Key F2 – brand+coarse_type+cap …")
    bctc: dict = defaultdict(list)
    for i in range(N):
        if caps[i] > 0:
            bctc[f"{brands[i]}_{ctypes[i]}_{caps[i]}"].append(i)
    for bucket in bctc.values():
        _process_bucket(bucket, norms_, max_all=MAX_ALL, window=WINDOW, out=raw_enc, N_enc=N_enc, raw_cap=RAW_CAP)

    # ── Key G: cap + type ─────────────────────────────────────────────────
    print("[blocking] Key G – cap+type …")
    ct: dict = defaultdict(list)
    for i in range(N):
        if caps[i] > 0 and types_[i] != 'unk':
            ct[f"{caps[i]}_{types_[i]}"].append(i)
    for bucket in ct.values():
        _process_bucket(bucket, norms_, max_all=MAX_ALL, window=WINDOW, out=raw_enc, N_enc=N_enc, raw_cap=RAW_CAP)

    # ── Key H: brand sorted-neighbourhood (multi-sort) ────────────────────
    print("[blocking] Key H – brand sorted-neighbourhood …")
    brand_only: dict = defaultdict(list)
    for i in range(N):
        brand_only[brands[i]].append(i)

    def _type_group(t):
        if t in ('msd', 'msdhc', 'msdxc'):
            return 'microsd'
        return t

    def _brand_sort_key(idx):
        c = caps[idx] if caps[idx] > 0 else 99999
        return (_type_group(types_[idx]), c, norms_[idx])

    brand_window  = min(WINDOW + 10, WINDOW * 2) if N <= 5_000 else WINDOW + 5
    H_MAX_BUCKET  = N + 1 if N <= 5_000 else 1_000
    for bucket in brand_only.values():
        if len(bucket) > H_MAX_BUCKET:
            continue
        sorted_bkt = sorted(bucket, key=_brand_sort_key)
        _process_bucket(sorted_bkt, norms_, max_all=MAX_ALL, window=brand_window,
                        out=raw_enc, N_enc=N_enc, raw_cap=RAW_CAP)

    # ── Key H2: brand + coarse_type ────────────────────────────────────────
    print("[blocking] Key H2 – brand+coarse_type …")
    btg: dict = defaultdict(list)
    for i in range(N):
        btg[f"{brands[i]}_{ctypes[i]}"].append(i)
    H2_MAX = N + 1 if N <= 5_000 else 800
    for bucket in btg.values():
        if len(bucket) <= H2_MAX:
            _process_bucket(bucket, norms_, max_all=MAX_ALL, window=WINDOW, out=raw_enc, N_enc=N_enc, raw_cap=RAW_CAP)

    # ── Key I0: type-only SNM (cap=-1 records) ────────────────────────────
    print("[blocking] Key I0 – type-only …")
    type_nocap: dict = defaultdict(list)
    for i in range(N):
        if types_[i] != 'unk':
            type_nocap[types_[i]].append(i)
    I0_MAX = N + 1 if N <= 5_000 else 1_000
    for bucket in type_nocap.values():
        if len(bucket) <= I0_MAX:
            _process_bucket(bucket, norms_, max_all=MAX_ALL, window=WINDOW, out=raw_enc, N_enc=N_enc, raw_cap=RAW_CAP)

    print(f"[blocking] Raw pairs before dedup: {len(raw_enc):,}")

    # ── Deduplicate: raw_enc already stores int64-encoded pairs ───────────
    print("[blocking] Deduplicating …")
    arr = np.array(raw_enc, dtype=np.int64)
    del raw_enc
    arr = np.unique(arr)
    pos_i = (arr // N_enc).astype(np.int32)
    pos_j = (arr %  N_enc).astype(np.int32)
    del arr
    M = len(pos_i)
    print(f"[blocking] Unique candidates: {M:,}")

    # ── MinHash Jaccard scoring ────────────────────────────────────────────
    print("[blocking] Scoring …")
    BATCH  = 2_000_000
    scores = np.empty(M, dtype=np.float32)
    for start in range(0, M, BATCH):
        end = min(start + BATCH, M)
        ls = sigs[pos_i[start:end], :]
        rs = sigs[pos_j[start:end], :]
        scores[start:end] = (ls == rs).mean(axis=1)

    # ── Select top MAX_PAIRS ───────────────────────────────────────────────
    print("[blocking] Selecting top pairs …")
    if M > MAX_PAIRS:
        top_idx = np.argpartition(-scores, MAX_PAIRS)[:MAX_PAIRS]
        top_idx = top_idx[np.argsort(-scores[top_idx])]
    else:
        top_idx = np.argsort(-scores)

    sel_i = pos_i[top_idx]
    sel_j = pos_j[top_idx]

    # ── Convert positional → real IDs ─────────────────────────────────────
    result = []
    for pi, pj in zip(sel_i.tolist(), sel_j.tolist()):
        ri, rj = int(ids[pi]), int(ids[pj])
        result.append((min(ri, rj), max(ri, rj)))

    while len(result) < MAX_PAIRS:
        result.append((0, 0))

    print(f"[blocking] Done. {len(result):,} pairs returned.")
    return result


# ── Entry point ───────────────────────────────────────────────────────────────

def main():
    data_dir = "/Users/USER/Documents/UNI/SS26/SIGMOD_full_data"

    print("[main] Loading X2 …")
    X2 = pd.read_csv(os.path.join(data_dir, "X2.csv"))

    print("[main] Blocking X2 …")
    pairs = generate_candidates(X2)

    os.makedirs("results", exist_ok=True)
    out_df = pd.DataFrame(pairs, columns=["lid", "rid"])
    out_df.to_csv("claude_code/output4.csv", index=False)
    print(f"[main] Saved {len(out_df):,} rows to claude_code/output4.csv")


if __name__ == "__main__":
    main()
