"""
Entity Resolution Blocking for X2 (Electronic Products)

Strategy:
- Multi-key structured blocking (brand+cap+type, brand+line, model codes, brand-only)
- Brand inference via product-line keywords (Cruzer→SanDisk, DataTraveler→Kingston…)
- Capacity extraction from embedded model codes (USM32GR→32 GB, SF16N4→16 GB…)
- MinHash LSH (32 bands × 2 rows) for cross-language / low-overlap pairs
- Adaptive size limits: all-pairs for small buckets, sorted-neighborhood for large ones
- Numpy batched MinHash Jaccard scoring → fast on large datasets
- Deterministic MinHash via CRC32 (not Python hash() which varies with PYTHONHASHSEED)

Improvements over original:
- Key F2: brand + line-prefix catches JumpDrive sub-variants (jmpdrv / jmpdrvc20)
- Key G2: cap + type_group catches cross-sub-type microSD pairs (msd vs msdhc)
- Key J:  word-token inverted index for rare product-line tokens
- extract_type: detects Sony SR- codes → msd, TS\\d+GSD → sdhc,
               "Secure Digital High Capacity" → sdhc
- extract_cap_gb: SR-NxxY codes (e.g. SR-8A4 → 8 GB)
- BRAND_MAX_ALL: brand-only buckets use all-pairs for sample-size datasets

Feasibility for 2 M records:
  – Every blocking bucket uses a configurable max-all-pairs threshold or window size.
  – No O(k²) work for k >> threshold.
  – Scoring uses numpy broadcasting, ~1 s per 2 M pairs.
"""

import os
import re
import zlib
from collections import defaultdict

import numpy as np
import pandas as pd

# ── MinHash parameters ──────────────────────────────────────────────────────
NUM_HASHES    = 64      # 64 hash functions  →  32 bands × 2 rows
NUM_BANDS     = 32
ROWS_PER_BAND = NUM_HASHES // NUM_BANDS   # = 2

np.random.seed(42)
_PRIME  = (1 << 31) - 1
_HASH_A = np.random.randint(1, _PRIME, NUM_HASHES, dtype=np.int64)
_HASH_B = np.random.randint(0, _PRIME, NUM_HASHES, dtype=np.int64)

MAX_PAIRS = 2_000_000

# ── Brand detection ──────────────────────────────────────────────────────────
# (a) Direct text match in name/brand-column
BRAND_KEYWORDS = {
    'sandisk': 'sandisk', 'san disk': 'sandisk',
    'sony': 'sony',
    'toshiba': 'toshiba',
    'kingston': 'kingston', 'kingstn': 'kingston',
    'lexar': 'lexar',
    'intenso': 'intenso',
    'transcend': 'transcend',
    'samsung': 'samsung',
    'pny': 'pny',
    'verbatim': 'verbatim',
    'patriot': 'patriot',
    'corsair': 'corsair',
    'strontium': 'strontium',
    'adata': 'adata',
    'hama': 'hama',
    'goodram': 'goodram',
    'emtec': 'emtec',
}

# (b) Product-line → brand (for when brand text is absent)
LINE_TO_BRAND = {
    'cruzer':       'sandisk',
    'ultra dual':   'sandisk',
    'ultra usb':    'sandisk',
    'extreme':      'sandisk',
    'datatraveler': 'kingston',
    'data traveler':'kingston',
    'hyperx':       'kingston',
    'jumpdrive':    'lexar',
    'jumpsdrive':   'lexar',
    'exceria':      'toshiba',
    'transmemory':  'toshiba',
    'canvas':       'kingston',
    'rainbow':      'intenso',
    'basic line':   'intenso',
    'premium line': 'intenso',
    'attache':      'pny',
    'attache4':     'pny',
    'flashair':     'toshiba',
    'memory stick': 'sony',
    'micro vault':  'sony',
}

# (c) Model-code prefix → brand
MODEL_PREFIX_BRAND = {
    'USM': 'sony',   # Sony USB Memory
    'SF':  'sony',   # Sony Flash
    'SR':  'sony',   # Sony Recz
    'SFD': 'sony',
    'THN': 'toshiba',
    'THNM': 'toshiba',
    'SDCZ': 'sandisk',
    'SDSD': 'sandisk',
    'SDXC': 'sandisk',
    'DT':   'kingston',
    'LJDS': 'lexar',
    'LJDC': 'lexar',
    'LJDP': 'lexar',
    'LJDT': 'lexar',
    'TS':   'transcend',
    'MB':   'samsung',
}

# ── Valid storage capacities ─────────────────────────────────────────────────
_VALID_CAPS = frozenset({1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048})


def _norm(s: str) -> str:
    s = re.sub(r'&[a-z]+;', ' ', str(s).lower())
    s = re.sub(r'[^a-z0-9\s]', ' ', s)
    return re.sub(r'\s+', ' ', s).strip()


def _snap_cap(v: float):
    if v <= 0:
        return None
    best = min(_VALID_CAPS, key=lambda c: abs(c - v))
    return best if abs(best - v) / v < 0.10 else None


def extract_brand(name: str, brand_col) -> str:
    b = _norm(str(brand_col))
    n = _norm(str(name))
    # Limit name search to first ~80 characters to avoid SEO/tag sections
    # Product names often append competitor brands as metadata keywords
    n_head = n[:80]

    # Direct match in brand column or early part of name
    for kw, brand in BRAND_KEYWORDS.items():
        if kw in b or kw in n_head:
            return brand

    # Match via product-line keywords (also use full name for line detection)
    for line_kw, brand in LINE_TO_BRAND.items():
        if line_kw in n_head:
            return brand

    # Match via model-code prefix
    name_up = str(name).upper()
    # Sony SR-* cards (e.g. SR-UY3A, SR-UX2A, SR-G1UX2A)
    if re.search(r'\bSR-[A-Z0-9]', name_up):
        return 'sony'
    for prefix, brand in MODEL_PREFIX_BRAND.items():
        if re.search(r'\b' + re.escape(prefix) + r'\d', name_up):
            return brand

    # Fallback: first token of brand column
    if b and b not in ('nan', ''):
        toks = [t for t in b.split() if len(t) > 2 and not t.isdigit()]
        if toks:
            return toks[0][:10]
    return 'unk'


def extract_cap_gb(s: str) -> int:
    """Extract storage capacity in GB.  Handles GB/Go/TB/To/MB/Mo notation.
    Also infers capacity from embedded model-code digits (e.g. USM32GR → 32).
    Returns -1 if nothing found.
    """
    s_clean = re.sub(r'&[a-z]+;', ' ', str(s).lower())
    s_up    = str(s).upper()

    caps = []

    # ── Explicit unit patterns ────────────────────────────────────────────
    for m in re.finditer(r'(\d+(?:\.\d+)?)\s*g[ob](?![\w/])', s_clean):
        v = _snap_cap(float(m.group(1)))
        if v:
            caps.append(v)

    for m in re.finditer(r'(\d+(?:\.\d+)?)\s*t[ob](?![\w/])', s_clean):
        v = _snap_cap(float(m.group(1)) * 1024)
        if v:
            caps.append(v)

    for m in re.finditer(r'(\d+)\s*m[ob](?![\w/s])', s_clean):
        raw = int(m.group(1))
        if raw >= 1024:
            v = _snap_cap(raw / 1024)
            if v:
                caps.append(v)

    if caps:
        return int(max(caps))

    # ── Infer from known model-code patterns ─────────────────────────────
    # Sony USMnnX  /  SF nn X  /  SRG nn X  (nn = capacity in GB)
    # SR-NxxY codes (e.g. SR-8A4): digit after the hyphen is capacity in GB
    for pat in [r'\bUSM(\d+)', r'\bSF(\d+)', r'\bSR-(\d+)',
                r'\bSR(\d+)(?!-)',
                r'\bUSM(\d+)GR\b', r'\bSFD(\d+)', r'\bSRG(\d+)']:
        m = re.search(pat, s_up)
        if m:
            v = _snap_cap(float(m.group(1)))
            if v:
                return int(v)

    # Transcend TS nn G / TS nn U
    m = re.search(r'\bTS(\d+)G', s_up)
    if m:
        v = _snap_cap(float(m.group(1)))
        if v:
            return int(v)

    # SanDisk SDCZ / SDSD / SDXC codes:  -nnG- or nnG-
    m = re.search(r'-(\d+)G(?:-|$)', s_up)
    if m:
        v = _snap_cap(float(m.group(1)))
        if v:
            return int(v)

    return -1


def extract_type(s: str) -> str:
    t = _norm(str(s)).replace(' ', '')
    if 'microsdhc' in t or 'microsdhx' in t:
        return 'msdhc'
    if 'microsdxc' in t:
        return 'msdxc'
    if 'microsd' in t:
        return 'msd'
    if 'sdxc' in t:
        return 'sdxc'
    if 'sdhc' in t:
        return 'sdhc'
    if 'usb' in t:
        return 'usb'
    # "Secure Digital High Capacity" = SDHC (e.g. "Kingston Secure Digital Card High-Capacity")
    n_spaced = _norm(str(s))
    if 'secure digital' in n_spaced and 'high' in n_spaced and 'capacity' in n_spaced:
        return 'sdhc'
    # Infer from Sony/Transcend model-code prefixes
    s_up = str(s).upper()
    if re.search(r'\bSR-[A-Z0-9]', s_up):  # Sony SR- microSD codes (e.g. SR-8A4)
        return 'msd'
    if re.search(r'\bTS\d+GSD', s_up):     # Transcend GSD = Secure Digital SD card
        return 'sdhc'
    if re.search(r'\bUSM\d', s_up):
        return 'usb'
    if re.search(r'\bSF\d', s_up):
        return 'sdhc'
    if re.search(r'\bSR', s_up) and re.search(r'\bMICRO\b', s_up):
        return 'msd'
    return 'unk'


# Product-line extraction ─────────────────────────────────────────────────────
_PRODUCT_LINES = [
    ('cruzrglid',   'cruzer glid'),
    ('cruzrblade',  'cruzer blade'),
    ('cruzrforc',   'cruzer forc'),
    ('cruzrflip',   'cruzer flip'),
    ('cruzrspark',  'cruzer spark'),
    ('cruzer',      'cruzer'),
    ('xtremepro',   'extreme pro'),
    ('xtreme',      'extreme'),
    ('ultradual',   'ultra dual'),
    ('ultraplus',   'ultra plus'),
    ('ultra',       'ultra'),
    ('datatrav',    'datatraveler'),
    ('datatrav',    'data traveler'),
    ('hyperx',      'hyperx'),
    ('jmpdrvs25',   'jumpdrive s25'),
    ('jmpdrvs70',   'jumpdrive s70'),
    ('jmpdrvc20m',  'jumpdrive c20m'),
    ('jmpdrvc20',   'jumpdrive c20'),
    ('jmpdrvp20',   'jumpdrive p20'),
    ('jmpdrv',      'jumpdrive'),
    ('exceriapro',  'exceria pro'),
    ('exceria',     'exceria'),
    ('rainbow',     'rainbow'),
    ('basicline',   'basic line'),
    ('premiumline', 'premium line'),
    ('transmem',    'transmemory'),
    ('canvago',     'canvas go'),
    ('canvareact',  'canvas react'),
    ('canvassel',   'canvas select'),
    ('evoplust',    'evo plus'),
    ('evo',         'evo'),
    ('flashair',    'flashair'),
    ('memorystk',   'memory stick'),
    ('microvault',  'micro vault'),
    ('attache4',    'attache 4'),
    ('attache4',    'attache4'),
    ('attache',     'attache'),
    ('usmseries',   'usm'),      # Sony USB Memory
    ('sfseries',    'sf-'),      # Sony SF SD card
]


def extract_line(s: str) -> str:
    n = _norm(str(s))
    for code, kw in _PRODUCT_LINES:
        if kw in n:
            return code
    return ''


# Model-code extraction ───────────────────────────────────────────────────────
_MODEL_RE = re.compile(
    r'\b(?:'
    r'[A-Z]{2,6}-[A-Z0-9]{2,}'       # SDA3-128G, THN-U202W, LJDS25-64G
    r'|[A-Z]{2,6}\d{2,}[A-Z]{0,3}'   # CZ80, DT101G2, USM32GR, SF16N4, TS64GSD2U3
    r')\b'
)


def extract_model_codes(s: str):
    codes = set()
    for m in _MODEL_RE.finditer(str(s).upper()):
        c = m.group(0)
        if len(c) >= 4:
            codes.add(c)
    return codes


# ── MinHash ───────────────────────────────────────────────────────────────────

def _tokenize(name: str):
    """Word tokens + character 2-grams."""
    n = _norm(name)
    words = n.split()
    chars = n.replace(' ', '')
    bigrams = [chars[i:i + 2] for i in range(len(chars) - 1)]
    return words + bigrams


def compute_minhash(token_list) -> np.ndarray:
    if not token_list:
        return np.zeros(NUM_HASHES, dtype=np.int64)
    # Use CRC32 instead of hash() — deterministic regardless of PYTHONHASHSEED
    h = np.array([zlib.crc32(t.encode()) & 0x7FFF_FFFF for t in set(token_list)], dtype=np.int64)
    vals = (_HASH_A[:, None] * h[None, :] + _HASH_B[:, None]) % _PRIME
    return vals.min(axis=1)


# ── Blocking helpers ──────────────────────────────────────────────────────────

def _process_bucket(bucket, norms, max_all: int, window: int, out: list):
    """
    Emit positional-index pairs (i < j) from *bucket*.

    - If |bucket| ≤ max_all  →  all C(k,2) pairs.
    - Else                    →  sorted-neighbourhood with *window* steps.
    """
    k = len(bucket)
    if k < 2:
        return
    if k <= max_all:
        for a in range(k):
            for b in range(a + 1, k):
                i, j = bucket[a], bucket[b]
                if i > j:
                    i, j = j, i
                out.append((i, j))
    else:
        s = sorted(bucket, key=lambda idx: norms[idx])
        w = min(window, k - 1)
        for pos in range(k):
            for d in range(1, w + 1):
                nxt = pos + d
                if nxt >= k:
                    break
                i, j = s[pos], s[nxt]
                if i > j:
                    i, j = j, i
                out.append((i, j))


# ── Main ──────────────────────────────────────────────────────────────────────

def generate_candidates(df: pd.DataFrame):
    """Return a list of exactly MAX_PAIRS (real_id_left, real_id_right) pairs
    with lid < rid, sorted by descending MinHash-Jaccard score, padded with (0,0)."""

    N = len(df)
    print(f"[blocking] N = {N:,}")

    ids        = np.array(df['id'].tolist(), dtype=np.int64)
    names      = df['name'].tolist()
    brands_col = df['brand'].tolist()

    # ── Feature extraction ────────────────────────────────────────────────
    print("[blocking] Extracting features …")
    norms_  = [_norm(n) for n in names]
    brands  = [extract_brand(names[i], brands_col[i]) for i in range(N)]
    caps    = [extract_cap_gb(names[i])  for i in range(N)]
    types_  = [extract_type(names[i])   for i in range(N)]
    lines   = [extract_line(names[i])   for i in range(N)]
    models  = [extract_model_codes(names[i]) for i in range(N)]

    # ── MinHash signatures ────────────────────────────────────────────────
    print("[blocking] Computing MinHash signatures …")
    sigs = np.zeros((N, NUM_HASHES), dtype=np.int64)
    for i in range(N):
        sigs[i] = compute_minhash(_tokenize(names[i]))

    # ── Adaptive parameters ───────────────────────────────────────────────
    # Small dataset (dev sample ≈ 2 K): generous  →  high recall on the sample.
    # Large dataset (≥ 100 K):          conservative → feasible runtime.
    if N <= 10_000:
        MAX_ALL = 250
        WINDOW  = 70
        LSH_MAX = 30
    else:
        MAX_ALL = 20
        WINDOW  = 10
        LSH_MAX = 8

    # For brand-only keys (H, H2) use a larger all-pairs threshold on small
    # datasets so that brand buckets up to ~1000 records get all-pairs treatment
    # (catches cross-type/cross-cap duplicate listings within one brand).
    BRAND_MAX_ALL = 1000 if N <= 10_000 else MAX_ALL

    raw_pairs: list = []   # (pos_i, pos_j) with pos_i < pos_j

    # ── Key A: Model codes ────────────────────────────────────────────────
    print("[blocking] Key A – model codes …")
    model_idx: dict = defaultdict(list)
    for i in range(N):
        for code in models[i]:
            model_idx[code].append(i)
    for bucket in model_idx.values():
        _process_bucket(bucket, norms_, max_all=min(MAX_ALL, 50), window=WINDOW, out=raw_pairs)

    # ── Key B: brand + cap + type + line ──────────────────────────────────
    print("[blocking] Key B – brand+cap+type+line …")
    bctl: dict = defaultdict(list)
    for i in range(N):
        bctl[f"{brands[i]}_{caps[i]}_{types_[i]}_{lines[i]}"].append(i)
    for bucket in bctl.values():
        _process_bucket(bucket, norms_, max_all=MAX_ALL, window=WINDOW, out=raw_pairs)

    # ── Key C: brand + cap + type ─────────────────────────────────────────
    print("[blocking] Key C – brand+cap+type …")
    bct: dict = defaultdict(list)
    for i in range(N):
        bct[f"{brands[i]}_{caps[i]}_{types_[i]}"].append(i)
    for bucket in bct.values():
        _process_bucket(bucket, norms_, max_all=MAX_ALL, window=WINDOW, out=raw_pairs)

    # ── Key D: brand + cap ────────────────────────────────────────────────
    print("[blocking] Key D – brand+cap …")
    bc: dict = defaultdict(list)
    for i in range(N):
        if caps[i] > 0:
            bc[f"{brands[i]}_{caps[i]}"].append(i)
    for bucket in bc.values():
        _process_bucket(bucket, norms_, max_all=MAX_ALL, window=WINDOW, out=raw_pairs)

    # ── Key E: brand + type ───────────────────────────────────────────────
    print("[blocking] Key E – brand+type …")
    bt: dict = defaultdict(list)
    for i in range(N):
        if types_[i] != 'unk':
            bt[f"{brands[i]}_{types_[i]}"].append(i)
    for bucket in bt.values():
        _process_bucket(bucket, norms_, max_all=MAX_ALL, window=WINDOW, out=raw_pairs)

    # ── Key F: brand + line ───────────────────────────────────────────────
    print("[blocking] Key F – brand+line …")
    bl: dict = defaultdict(list)
    for i in range(N):
        if lines[i]:
            bl[f"{brands[i]}_{lines[i]}"].append(i)
    for bucket in bl.values():
        _process_bucket(bucket, norms_, max_all=MAX_ALL, window=WINDOW, out=raw_pairs)

    # ── Key F2: brand + line prefix (6 chars) ─────────────────────────────
    # Groups line sub-variants together (e.g. jmpdrv / jmpdrvc20 both → jmpdrv).
    print("[blocking] Key F2 – brand+line prefix …")
    blp: dict = defaultdict(list)
    for i in range(N):
        if len(lines[i]) >= 6:
            blp[f"{brands[i]}_{lines[i][:6]}"].append(i)
    for bucket in blp.values():
        _process_bucket(bucket, norms_, max_all=MAX_ALL, window=WINDOW, out=raw_pairs)

    # ── Key G: cap + type ─────────────────────────────────────────────────
    print("[blocking] Key G – cap+type …")
    ct: dict = defaultdict(list)
    for i in range(N):
        if caps[i] > 0 and types_[i] != 'unk':
            ct[f"{caps[i]}_{types_[i]}"].append(i)
    for bucket in ct.values():
        _process_bucket(bucket, norms_, max_all=MAX_ALL, window=WINDOW, out=raw_pairs)

    # ── Key G2: cap + type_group ──────────────────────────────────────────
    # Coarsens msd/msdhc/msdxc → microsd so cross-sub-type pairs at same
    # capacity (e.g. brand=unk msdhc vs brand=kingston msd) are paired.
    print("[blocking] Key G2 – cap+type_group …")
    ctg: dict = defaultdict(list)
    _tg_map = {'msd': 'microsd', 'msdhc': 'microsd', 'msdxc': 'microsd'}
    for i in range(N):
        if caps[i] > 0 and types_[i] != 'unk':
            tg = _tg_map.get(types_[i], types_[i])
            ctg[f"{caps[i]}_{tg}"].append(i)
    G2_MAX_BUCKET = N + 1 if N <= 10_000 else 300  # skip huge buckets for large N
    for bucket in ctg.values():
        if len(bucket) <= G2_MAX_BUCKET:
            _process_bucket(bucket, norms_, max_all=MAX_ALL, window=WINDOW, out=raw_pairs)

    # ── Key H: brand-only sorted-neighbourhood ────────────────────────────
    # Sort by (type_group, cap, normalised-name) so similar product families
    # cluster together even when text is in different languages.
    print("[blocking] Key H – brand-only sorted-neighbourhood …")
    brand_only: dict = defaultdict(list)
    for i in range(N):
        brand_only[brands[i]].append(i)

    def _type_group(t):
        """Coarsen type so microSD variants (msd/msdhc/msdxc) group together."""
        if t in ('msd', 'msdhc', 'msdxc'):
            return 'microsd'
        return t  # sdhc, sdxc, usb, unk each stay separate

    # Sort: (type_group, cap, norm_name)
    def _brand_sort_key(idx):
        c = caps[idx] if caps[idx] > 0 else 99999
        return (_type_group(types_[idx]), c, norms_[idx])

    # Use a slightly larger window for brand-only (covers cap=-1 vs cap=known).
    # For large datasets, only process small brand buckets (large brands are
    # already covered by brand+cap+type/line keys).
    brand_window = min(WINDOW + 10, WINDOW * 2) if N <= 10_000 else 15
    H_MAX_BUCKET = N + 1 if N <= 10_000 else 500  # skip giant buckets for large N
    for bucket in brand_only.values():
        if len(bucket) > H_MAX_BUCKET:
            continue
        sorted_bkt = sorted(bucket, key=_brand_sort_key)
        _process_bucket(sorted_bkt, norms_, max_all=BRAND_MAX_ALL, window=brand_window, out=raw_pairs)

    # ── Key H2: brand + type_group (merges msd/msdhc/msdxc) ──────────────
    # This catches pairs where type differs within the microSD family.
    print("[blocking] Key H2 – brand+type_group …")
    btg: dict = defaultdict(list)
    for i in range(N):
        tg = _type_group(types_[i])
        btg[f"{brands[i]}_{tg}"].append(i)
    H2_MAX_BUCKET = N + 1 if N <= 10_000 else 500
    for bucket in btg.values():
        if len(bucket) <= H2_MAX_BUCKET:
            _process_bucket(bucket, norms_, max_all=BRAND_MAX_ALL, window=WINDOW, out=raw_pairs)

    # ── Key I0: type-only sorted-neighbourhood for records with unknown cap ─
    # Catches records like "Karta pami?ci SDHC" (no brand, no cap) against
    # known same-type products.  Only used for small type buckets.
    print("[blocking] Key I0 – type-only sorted-neighbourhood (cap=-1) …")
    type_nocap: dict = defaultdict(list)
    for i in range(N):
        if types_[i] != 'unk':
            type_nocap[types_[i]].append(i)
    I0_MAX = N + 1 if N <= 10_000 else 800  # skip huge type buckets for large N
    for bucket in type_nocap.values():
        if len(bucket) <= I0_MAX:
            _process_bucket(bucket, norms_, max_all=MAX_ALL, window=WINDOW, out=raw_pairs)

    # ── Key J: Word-token inverted index (rare product-name words) ───────────
    # Catches pairs sharing a specific product-line token (e.g. a model suffix)
    # that no structured key covers.  Only tokens appearing 2–MAX_TOK_FREQ times
    # are indexed; very common words are skipped automatically.
    print("[blocking] Key J – word token inverted index …")
    tok_count: dict = defaultdict(int)
    for i in range(N):
        for tok in set(norms_[i].split()):
            if len(tok) >= 5:
                tok_count[tok] += 1
    MAX_TOK_FREQ = 30 if N <= 10_000 else 50
    tok_idx: dict = defaultdict(list)
    for i in range(N):
        for tok in set(norms_[i].split()):
            if len(tok) >= 5 and 2 <= tok_count[tok] <= MAX_TOK_FREQ:
                tok_idx[tok].append(i)
    for bucket in tok_idx.values():
        _process_bucket(bucket, norms_, max_all=MAX_ALL, window=WINDOW, out=raw_pairs)

    # ── Key I: MinHash LSH (32 bands × 2 rows) ────────────────────────────
    print("[blocking] Key I – MinHash LSH …")
    for b in range(NUM_BANDS):
        band_idx: dict = defaultdict(list)
        s0 = b * ROWS_PER_BAND
        for i in range(N):
            bkey = (int(sigs[i, s0]), int(sigs[i, s0 + 1]))
            band_idx[bkey].append(i)
        for bucket in band_idx.values():
            if len(bucket) <= LSH_MAX:
                _process_bucket(bucket, norms_, max_all=LSH_MAX, window=0, out=raw_pairs)

    print(f"[blocking] Raw pairs: {len(raw_pairs):,}")

    # ── Deduplicate via int64 encoding ────────────────────────────────────
    print("[blocking] Deduplicating …")
    N_enc = max(N + 1, 3)
    arr = np.fromiter(
        (pi * N_enc + pj for pi, pj in raw_pairs),
        dtype=np.int64, count=len(raw_pairs)
    )
    arr = np.unique(arr)
    pos_i = (arr // N_enc).astype(np.int32)
    pos_j = (arr %  N_enc).astype(np.int32)
    del raw_pairs, arr
    M = len(pos_i)
    print(f"[blocking] Unique candidates: {M:,}")

    # ── MinHash Jaccard scoring (batched) ─────────────────────────────────
    print("[blocking] Scoring …")
    BATCH  = 2_000_000
    scores = np.empty(M, dtype=np.float32)
    for start in range(0, M, BATCH):
        end = min(start + BATCH, M)
        ls = sigs[pos_i[start:end], :]
        rs = sigs[pos_j[start:end], :]
        scores[start:end] = (ls == rs).mean(axis=1)

    # ── Select top MAX_PAIRS ──────────────────────────────────────────────
    print("[blocking] Selecting top pairs …")
    if M > MAX_PAIRS:
        top_idx = np.argpartition(-scores, MAX_PAIRS)[:MAX_PAIRS]
        top_idx = top_idx[np.argsort(-scores[top_idx])]
    else:
        top_idx = np.argsort(-scores)

    sel_i = pos_i[top_idx]
    sel_j = pos_j[top_idx]

    # ── Convert positional → real IDs ─────────────────────────────────────
    result = []
    for pi, pj in zip(sel_i.tolist(), sel_j.tolist()):
        ri, rj = int(ids[pi]), int(ids[pj])
        result.append((min(ri, rj), max(ri, rj)))

    while len(result) < MAX_PAIRS:
        result.append((0, 0))

    print(f"[blocking] Done.  {len(result):,} pairs returned.")
    return result


# ── save_output (legacy signature kept for compatibility) ────────────────────
def save_output(X1_candidate_pairs, X2_candidate_pairs):
    expected_X1 = 1_000_000
    expected_X2 = 2_000_000

    if len(X1_candidate_pairs) > expected_X1:
        X1_candidate_pairs = X1_candidate_pairs[:expected_X1]
    if len(X2_candidate_pairs) > expected_X2:
        X2_candidate_pairs = X2_candidate_pairs[:expected_X2]

    if len(X1_candidate_pairs) < expected_X1:
        X1_candidate_pairs.extend([(0, 0)] * (expected_X1 - len(X1_candidate_pairs)))
    if len(X2_candidate_pairs) < expected_X2:
        X2_candidate_pairs.extend([(0, 0)] * (expected_X2 - len(X2_candidate_pairs)))

    all_pairs = X1_candidate_pairs + X2_candidate_pairs
    out_df = pd.DataFrame(all_pairs, columns=["left_instance_id", "right_instance_id"])
    os.makedirs("results", exist_ok=True)
    out_df.to_csv("results/output.csv", index=False)
    print(f"[output] Saved {len(out_df):,} rows to results/output.csv")


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    data_dir = "/Users/USER/Documents/UNI/SS26/SIGMOD_full_data"
    print("[main] Loading X2 …")
    X2 = pd.read_csv(os.path.join(data_dir, "X2.csv")).reset_index(drop=True)

    print("[main] Blocking X2 …")
    X2_pairs = generate_candidates(X2)

    save_output([], X2_pairs)
    print("[main] All done.")
