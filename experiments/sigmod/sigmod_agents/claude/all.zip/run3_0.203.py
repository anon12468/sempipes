"""
Entity Resolution Blocking for X2 (Electronic Products)
Outputs exactly 2,000,000 candidate pairs to results/output.csv (columns: lid, rid).

Design for scale:
- Small N (C(N,2) <= 2M): output all unique pairs → 100% recall, O(N^2) is fine.
- Large N (~2M records): structured blocking + MinHash LSH.
  * All pairs encoded as int64 in numpy arrays (8 bytes/pair vs ~128 for Python tuples).
  * Sorted-neighbourhood vectorised over distance offsets (no Python inner loop).
  * Strict LSH bucket-size caps prevent O(k^2) blow-up.
  * Score by MinHash Jaccard → select top-2M.
"""

import os
import re
from collections import defaultdict

import numpy as np
import pandas as pd

MAX_PAIRS = 2_000_000

# ── MinHash parameters ────────────────────────────────────────────────────────
NUM_HASHES    = 128
NUM_BANDS     = 64        # 64 bands × 2 rows = 128 hashes
ROWS_PER_BAND = NUM_HASHES // NUM_BANDS   # = 2

np.random.seed(42)
_PRIME  = (1 << 31) - 1
_HASH_A = np.random.randint(1, _PRIME, NUM_HASHES, dtype=np.int64)
_HASH_B = np.random.randint(0, _PRIME, NUM_HASHES, dtype=np.int64)

# ── Brand detection ───────────────────────────────────────────────────────────
BRAND_KEYWORDS = {
    'sandisk': 'sandisk', 'san disk': 'sandisk',
    'sony': 'sony',
    'toshiba': 'toshiba',
    'kingston': 'kingston', 'kingstn': 'kingston',
    'lexar': 'lexar',
    'intenso': 'intenso',
    'transcend': 'transcend',
    'samsung': 'samsung',
    'pny': 'pny',
    'verbatim': 'verbatim',
    'patriot': 'patriot',
    'corsair': 'corsair',
    'strontium': 'strontium',
    'adata': 'adata',
    'hama': 'hama',
    'goodram': 'goodram',
    'emtec': 'emtec',
}

LINE_TO_BRAND = {
    'cruzer':       'sandisk',
    'ultra dual':   'sandisk',
    'ultra usb':    'sandisk',
    'extreme':      'sandisk',
    'datatraveler': 'kingston',
    'data traveler':'kingston',
    'hyperx':       'kingston',
    'jumpdrive':    'lexar',
    'exceria':      'toshiba',
    'transmemory':  'toshiba',
    'canvas':       'kingston',
    'rainbow':      'intenso',
    'basic line':   'intenso',
    'premium line': 'intenso',
    'attache':      'pny',
    'attache4':     'pny',
    'flashair':     'toshiba',
    'memory stick': 'sony',
    'micro vault':  'sony',
}

MODEL_PREFIX_BRAND = {
    'USM': 'sony', 'SF': 'sony', 'SR': 'sony', 'SFD': 'sony',
    'THN': 'toshiba', 'THNM': 'toshiba',
    'SDCZ': 'sandisk', 'SDSD': 'sandisk', 'SDXC': 'sandisk',
    'DT': 'kingston',
    'LJDS': 'lexar', 'LJDC': 'lexar', 'LJDP': 'lexar', 'LJDT': 'lexar',
    'TS': 'transcend',
    'MB': 'samsung',
}

_VALID_CAPS = frozenset({1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048})


def _norm(s: str) -> str:
    s = re.sub(r'&[a-z]+;', ' ', str(s).lower())
    s = re.sub(r'[^a-z0-9\s]', ' ', s)
    return re.sub(r'\s+', ' ', s).strip()


def _snap_cap(v: float):
    if v <= 0:
        return None
    best = min(_VALID_CAPS, key=lambda c: abs(c - v))
    return best if abs(best - v) / v < 0.10 else None


def extract_brand(name: str, brand_col) -> str:
    b = _norm(str(brand_col))
    n = _norm(str(name))
    n_head = n[:80]
    for kw, brand in BRAND_KEYWORDS.items():
        if kw in b or kw in n_head:
            return brand
    for line_kw, brand in LINE_TO_BRAND.items():
        if line_kw in n_head:
            return brand
    name_up = str(name).upper()
    if re.search(r'\bSR-[A-Z0-9]', name_up):
        return 'sony'
    for prefix, brand in MODEL_PREFIX_BRAND.items():
        if re.search(r'\b' + re.escape(prefix) + r'\d', name_up):
            return brand
    if b and b not in ('nan', ''):
        toks = [t for t in b.split() if len(t) > 2 and not t.isdigit()]
        if toks:
            return toks[0][:10]
    return 'unk'


def extract_cap_gb(s: str) -> int:
    s_clean = re.sub(r'&[a-z]+;', ' ', str(s).lower())
    s_up    = str(s).upper()
    caps = []
    for m in re.finditer(r'(\d+(?:\.\d+)?)\s*g[ob](?![\w/])', s_clean):
        v = _snap_cap(float(m.group(1)))
        if v: caps.append(v)
    for m in re.finditer(r'(\d+(?:\.\d+)?)\s*t[ob](?![\w/])', s_clean):
        v = _snap_cap(float(m.group(1)) * 1024)
        if v: caps.append(v)
    for m in re.finditer(r'(\d+)\s*m[ob](?![\w/s])', s_clean):
        raw = int(m.group(1))
        if raw >= 1024:
            v = _snap_cap(raw / 1024)
            if v: caps.append(v)
    if caps:
        return int(max(caps))
    for pat in [r'\bUSM(\d+)', r'\bSF(\d+)', r'\bSR(\d+)(?!-)',
                r'\bUSM(\d+)GR\b', r'\bSFD(\d+)', r'\bSRG(\d+)']:
        m = re.search(pat, s_up)
        if m:
            v = _snap_cap(float(m.group(1)))
            if v: return int(v)
    m = re.search(r'\bTS(\d+)G', s_up)
    if m:
        v = _snap_cap(float(m.group(1)))
        if v: return int(v)
    m = re.search(r'-(\d+)G(?:-|$)', s_up)
    if m:
        v = _snap_cap(float(m.group(1)))
        if v: return int(v)
    return -1


def extract_type(s: str) -> str:
    t = _norm(str(s)).replace(' ', '')
    if 'microsdhc' in t or 'microsdhx' in t: return 'msdhc'
    if 'microsdxc' in t: return 'msdxc'
    if 'microsd' in t:   return 'msd'
    if 'sdxc' in t:      return 'sdxc'
    if 'sdhc' in t:      return 'sdhc'
    if 'usb' in t:       return 'usb'
    s_up = str(s).upper()
    if re.search(r'\bUSM\d', s_up): return 'usb'
    if re.search(r'\bSF\d',  s_up): return 'sdhc'
    if re.search(r'\bSR', s_up) and re.search(r'\bMICRO\b', s_up): return 'msd'
    if re.search(r'secure\s+digital', t): return 'sd'
    return 'unk'


_PRODUCT_LINES = [
    ('cruzrglid', 'cruzer glid'), ('cruzrblade', 'cruzer blade'),
    ('cruzrforc', 'cruzer forc'), ('cruzrflip', 'cruzer flip'),
    ('cruzrspark', 'cruzer spark'), ('cruzer', 'cruzer'),
    ('xtremepro', 'extreme pro'), ('xtreme', 'extreme'),
    ('ultradual', 'ultra dual'), ('ultraplus', 'ultra plus'), ('ultra', 'ultra'),
    ('datatrav', 'datatraveler'), ('datatrav', 'data traveler'),
    ('hyperx', 'hyperx'),
    ('jmpdrvs25', 'jumpdrive s25'), ('jmpdrvs70', 'jumpdrive s70'),
    ('jmpdrvc20m', 'jumpdrive c20m'), ('jmpdrvc20', 'jumpdrive c20'),
    ('jmpdrvp20', 'jumpdrive p20'), ('jmpdrv', 'jumpdrive'),
    ('exceriapro', 'exceria pro'), ('exceria', 'exceria'),
    ('rainbow', 'rainbow'), ('basicline', 'basic line'), ('premiumline', 'premium line'),
    ('transmem', 'transmemory'),
    ('canvago', 'canvas go'), ('canvareact', 'canvas react'), ('canvassel', 'canvas select'),
    ('evoplust', 'evo plus'), ('evo', 'evo'),
    ('flashair', 'flashair'), ('memorystk', 'memory stick'), ('microvault', 'micro vault'),
    ('attache4', 'attache 4'), ('attache4', 'attache4'), ('attache', 'attache'),
    ('usmseries', 'usm'), ('sfseries', 'sf-'),
]


def extract_line(s: str) -> str:
    n = _norm(str(s))
    for code, kw in _PRODUCT_LINES:
        if kw in n:
            return code
    return ''


_MODEL_RE = re.compile(
    r'\b(?:[A-Z]{2,6}-[A-Z0-9]{2,}|[A-Z]{2,6}\d{2,}[A-Z]{0,3})\b'
)


def extract_model_codes(s: str):
    codes = set()
    for m in _MODEL_RE.finditer(str(s).upper()):
        c = m.group(0)
        if len(c) >= 4:
            codes.add(c)
    return codes


def _tokenize(name: str):
    n = _norm(name)
    words = n.split()
    chars = n.replace(' ', '')
    bigrams = [chars[i:i + 2] for i in range(len(chars) - 1)]
    return words + bigrams


def compute_minhash(token_list) -> np.ndarray:
    if not token_list:
        return np.zeros(NUM_HASHES, dtype=np.int64)
    toks = list(set(token_list))
    h = np.array([hash(t) & 0x7FFF_FFFF for t in toks], dtype=np.int64)
    vals = (_HASH_A[:, None] * h[None, :] + _HASH_B[:, None]) % _PRIME
    return vals.min(axis=1)


def _type_group(t: str) -> str:
    if t in ('msd', 'msdhc', 'msdxc'):   return 'microsd'
    if t in ('sd', 'sdhc', 'sdxc'):       return 'sd_family'
    return t


# ── Memory-efficient pair collection (numpy int64 encoding) ──────────────────

def _bucket_to_encoded(bucket, norms, max_all: int, window: int,
                        N_enc: int) -> np.ndarray | None:
    """Return encoded pair array for one bucket. Pairs stored as i*N_enc+j (i<j)."""
    k = len(bucket)
    if k < 2:
        return None

    if k <= max_all:
        # Small bucket: all-pairs (Python loop, k is bounded)
        pairs = []
        for a in range(k):
            for b in range(a + 1, k):
                i, j = bucket[a], bucket[b]
                if i > j: i, j = j, i
                pairs.append(i * N_enc + j)
        return np.array(pairs, dtype=np.int64) if pairs else None
    else:
        # Large bucket: vectorised sorted-neighbourhood
        s = np.array(sorted(bucket, key=lambda idx: norms[idx]), dtype=np.int64)
        w = min(window, k - 1)
        segs = []
        for d in range(1, w + 1):
            left  = s[:k - d]
            right = s[d:]
            i_arr = np.minimum(left, right)
            j_arr = np.maximum(left, right)
            segs.append(i_arr * N_enc + j_arr)
        return np.concatenate(segs) if segs else None


def _collect_key(buckets_dict: dict, norms, max_all: int, window: int,
                 N_enc: int) -> list:
    """Process all buckets of one blocking key → list of encoded int64 arrays."""
    chunks = []
    for bucket in buckets_dict.values():
        enc = _bucket_to_encoded(bucket, norms, max_all, window, N_enc)
        if enc is not None:
            chunks.append(enc)
    return chunks


# ── Main ──────────────────────────────────────────────────────────────────────

def generate_candidates(df: pd.DataFrame):
    N = len(df)
    print(f"[blocking] N = {N:,}")
    ids = df['id'].to_numpy(dtype=np.int64)

    # ── Shortcut: all pairs fit within budget ─────────────────────────────────
    max_possible = N * (N - 1) // 2
    if max_possible <= MAX_PAIRS:
        print(f"[blocking] Small N: outputting all {max_possible:,} pairs (100% recall)")
        id_list = ids.tolist()
        pairs = []
        for i in range(N):
            for j in range(i + 1, N):
                li, ri = id_list[i], id_list[j]
                if li > ri: li, ri = ri, li
                pairs.append((li, ri))
        pairs += [(0, 0)] * (MAX_PAIRS - len(pairs))
        print(f"[blocking] Done. {len(pairs):,} rows (incl. padding).")
        return pairs

    # ── Large N: efficient blocking ───────────────────────────────────────────
    names      = df['name'].tolist()
    brands_col = df['brand'].tolist()

    print("[blocking] Extracting features …")
    norms_  = [_norm(n) for n in names]
    brands  = [extract_brand(names[i], brands_col[i]) for i in range(N)]
    caps    = [extract_cap_gb(names[i])  for i in range(N)]
    types_  = [extract_type(names[i])   for i in range(N)]
    lines   = [extract_line(names[i])   for i in range(N)]
    models  = [extract_model_codes(names[i]) for i in range(N)]

    print("[blocking] Computing MinHash signatures …")
    sigs = np.zeros((N, NUM_HASHES), dtype=np.int64)
    for i in range(N):
        sigs[i] = compute_minhash(_tokenize(names[i]))

    # ── Adaptive parameters ───────────────────────────────────────────────────
    if N <= 50_000:
        MAX_ALL, WINDOW, LSH_MAX, H_MAX = 150, 50, 20, N + 1
    elif N <= 500_000:
        MAX_ALL, WINDOW, LSH_MAX, H_MAX = 25, 10, 8,  2000
    else:
        MAX_ALL, WINDOW, LSH_MAX, H_MAX = 12, 6,  5,  800

    N_enc = N + 1   # encoding multiplier (safe since N < 2^21 in practice)
    encoded_chunks: list = []   # list of numpy int64 arrays

    def _add_key(buckets_dict, max_all=MAX_ALL, window=WINDOW):
        chunks = _collect_key(buckets_dict, norms_, max_all, window, N_enc)
        encoded_chunks.extend(chunks)

    def _add_bucket(bucket, max_all=MAX_ALL, window=WINDOW):
        enc = _bucket_to_encoded(bucket, norms_, max_all, window, N_enc)
        if enc is not None:
            encoded_chunks.append(enc)

    # ── Key A: Model codes ────────────────────────────────────────────────────
    print("[blocking] Key A – model codes …")
    model_idx: dict = defaultdict(list)
    for i in range(N):
        for code in models[i]:
            model_idx[code].append(i)
    _add_key(model_idx, max_all=min(MAX_ALL, 50))

    # ── Key B: brand + cap + type + line ─────────────────────────────────────
    print("[blocking] Key B – brand+cap+type+line …")
    bctl: dict = defaultdict(list)
    for i in range(N):
        bctl[f"{brands[i]}_{caps[i]}_{types_[i]}_{lines[i]}"].append(i)
    _add_key(bctl)

    # ── Key C: brand + cap + type ─────────────────────────────────────────────
    print("[blocking] Key C – brand+cap+type …")
    bct: dict = defaultdict(list)
    for i in range(N):
        bct[f"{brands[i]}_{caps[i]}_{types_[i]}"].append(i)
    _add_key(bct)

    # ── Key D: brand + cap ────────────────────────────────────────────────────
    print("[blocking] Key D – brand+cap …")
    bc: dict = defaultdict(list)
    for i in range(N):
        if caps[i] > 0:
            bc[f"{brands[i]}_{caps[i]}"].append(i)
    _add_key(bc)

    # ── Key E: brand + type ───────────────────────────────────────────────────
    print("[blocking] Key E – brand+type …")
    bt: dict = defaultdict(list)
    for i in range(N):
        if types_[i] != 'unk':
            bt[f"{brands[i]}_{types_[i]}"].append(i)
    _add_key(bt)

    # ── Key F: brand + line ───────────────────────────────────────────────────
    print("[blocking] Key F – brand+line …")
    bl: dict = defaultdict(list)
    for i in range(N):
        if lines[i]:
            bl[f"{brands[i]}_{lines[i]}"].append(i)
    _add_key(bl)

    # ── Key G: cap + type (without brand) ────────────────────────────────────
    print("[blocking] Key G – cap+type …")
    ct: dict = defaultdict(list)
    for i in range(N):
        if caps[i] > 0 and types_[i] != 'unk':
            ct[f"{caps[i]}_{types_[i]}"].append(i)
    _add_key(ct)

    # ── Key G2: cap + type_group (merges sub-types, e.g. sdhc/sdxc together) ──
    print("[blocking] Key G2 – cap+type_group …")
    ctg: dict = defaultdict(list)
    for i in range(N):
        if caps[i] > 0:
            ctg[f"{caps[i]}_{_type_group(types_[i])}"].append(i)
    _add_key(ctg)

    # ── Key G3: broadcast unk-type records into same-cap type-group buckets ───
    # Handles e.g. "64GB UHS-II Card" (type=unk) ↔ "Transcend TS64GSD2U3 SD"
    print("[blocking] Key G3 – cap+type_group (unk broadcast) …")
    unk_cap_idx: dict = defaultdict(list)
    for i in range(N):
        if caps[i] > 0 and types_[i] == 'unk':
            unk_cap_idx[caps[i]].append(i)
    if unk_cap_idx:
        for cap_val, unk_ids in unk_cap_idx.items():
            for tg_suffix in ('microsd', 'sd_family', 'usb', 'sdhc', 'sdxc'):
                key = f"{cap_val}_{tg_suffix}"
                if key in ctg and ctg[key]:
                    combined = ctg[key] + unk_ids
                    _add_bucket(combined)

    # ── Key H: brand-only sorted-neighbourhood ────────────────────────────────
    print("[blocking] Key H – brand-only sorted-neighbourhood …")
    brand_only: dict = defaultdict(list)
    for i in range(N):
        brand_only[brands[i]].append(i)

    def _brand_sort_key(idx):
        c = caps[idx] if caps[idx] > 0 else 99999
        return (_type_group(types_[idx]), c, norms_[idx])

    brand_window = WINDOW + 10 if N <= 50_000 else WINDOW
    for bucket in brand_only.values():
        k = len(bucket)
        sorted_bkt = sorted(bucket, key=_brand_sort_key)
        if k > H_MAX:
            # Adaptive window for oversized brand buckets
            w = max(2, min(brand_window, 5_000 // k))
        else:
            w = brand_window
        _add_bucket(sorted_bkt, window=w)

    # ── Key H2: brand + type_group ────────────────────────────────────────────
    print("[blocking] Key H2 – brand+type_group …")
    btg: dict = defaultdict(list)
    for i in range(N):
        btg[f"{brands[i]}_{_type_group(types_[i])}"].append(i)
    for bucket in btg.values():
        k = len(bucket)
        w = max(2, min(WINDOW, 5_000 // k)) if k > H_MAX else WINDOW
        _add_bucket(bucket, window=w)

    # ── Key I0: type-only sorted-neighbourhood ────────────────────────────────
    print("[blocking] Key I0 – type-only sorted-neighbourhood …")
    type_nocap: dict = defaultdict(list)
    for i in range(N):
        if types_[i] != 'unk':
            type_nocap[types_[i]].append(i)
    for bucket in type_nocap.values():
        k = len(bucket)
        if k <= H_MAX:
            _add_bucket(bucket)

    # ── Key I: MinHash LSH (64 bands × 2 rows) ───────────────────────────────
    print("[blocking] Key I – MinHash LSH …")
    for b in range(NUM_BANDS):
        band_idx: dict = defaultdict(list)
        s0 = b * ROWS_PER_BAND
        for i in range(N):
            bkey = (int(sigs[i, s0]), int(sigs[i, s0 + 1]))
            band_idx[bkey].append(i)
        for bucket in band_idx.values():
            k = len(bucket)
            if k < 2:
                continue
            if k <= LSH_MAX:
                _add_bucket(bucket, max_all=LSH_MAX, window=0)
            elif k <= LSH_MAX * 10:
                # Medium LSH bucket: sorted-neighbourhood with small window
                _add_bucket(bucket, max_all=LSH_MAX, window=3)
            # Very large LSH buckets are too noisy → skip

    # ── Concatenate & deduplicate ─────────────────────────────────────────────
    print(f"[blocking] Collected {len(encoded_chunks):,} chunk(s) of encoded pairs …")
    if encoded_chunks:
        raw_arr = np.concatenate(encoded_chunks)
    else:
        raw_arr = np.array([], dtype=np.int64)
    del encoded_chunks

    raw_arr = np.unique(raw_arr)
    M = len(raw_arr)
    print(f"[blocking] Unique candidates: {M:,}")

    pos_i = (raw_arr // N_enc).astype(np.int32)
    pos_j = (raw_arr %  N_enc).astype(np.int32)
    del raw_arr

    # ── MinHash Jaccard scoring (batched) ─────────────────────────────────────
    print("[blocking] Scoring …")
    BATCH = 2_000_000
    scores = np.empty(M, dtype=np.float32)
    for start in range(0, M, BATCH):
        end = min(start + BATCH, M)
        ls = sigs[pos_i[start:end], :]
        rs = sigs[pos_j[start:end], :]
        scores[start:end] = (ls == rs).mean(axis=1)

    # ── Select top MAX_PAIRS ──────────────────────────────────────────────────
    print("[blocking] Selecting top pairs …")
    if M > MAX_PAIRS:
        top_idx = np.argpartition(-scores, MAX_PAIRS)[:MAX_PAIRS]
        top_idx = top_idx[np.argsort(-scores[top_idx])]
    else:
        top_idx = np.arange(M)

    sel_i = pos_i[top_idx]
    sel_j = pos_j[top_idx]

    # ── Convert positional → real IDs (ensure lid < rid) ─────────────────────
    id_arr = ids  # int64 array
    result = []
    for pi, pj in zip(sel_i.tolist(), sel_j.tolist()):
        li, ri = int(id_arr[pi]), int(id_arr[pj])
        if li > ri: li, ri = ri, li
        result.append((li, ri))

    while len(result) < MAX_PAIRS:
        result.append((0, 0))

    print(f"[blocking] Done. {len(result):,} pairs returned.")
    return result


if __name__ == "__main__":
    data_dir = "/Users/USER/Documents/UNI/SS26/SIGMOD_full_data"

    print("[main] Loading X2 …")
    X2 = pd.read_csv(os.path.join(data_dir, "X2.csv")).reset_index(drop=True)

    print("[main] Blocking X2 …")
    pairs = generate_candidates(X2)

    os.makedirs("results", exist_ok=True)
    out_df = pd.DataFrame(pairs, columns=["left_instance_id","right_instance_id"])
    out_df.to_csv(os.path.join("results", "output.csv"), index=False)
    print(f"[main] Saved {len(out_df):,} rows to results/output.csv")
    print("[main] Done.")
