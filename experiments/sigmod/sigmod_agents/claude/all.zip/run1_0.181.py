"""
Entity Resolution Blocking for X2 (Electronic Products)

Strategy
--------
1.  Text normalisation: ASCII-fold (accents → base), lowercase, punctuation → space.
2.  Feature extraction per record:
      • Canonical brand  ("B:<brand>")
      • Normalised capacity  ("C:<GB>")
      • Product type  ("T:usb" | "T:sd" | "T:microsd")
      • Meaningful word-tokens and alpha-numeric model codes
3.  Four blocking passes (highest → lowest confidence):
      a. Composite keys  (brand × capacity × model/word)
      b. 4-row MinHash LSH  (catches Jaccard ≥ ~0.35)
      c. Brand × product-type buckets  (brand-only / type-only pairs)
      d. 2-row MinHash LSH  (catches Jaccard ≥ ~0.15, strict cap)
4.  Score-rank every candidate pair by Jaccard; keep top 2 000 000.

FEASIBILITY
-----------
Every blocking bucket is hard-capped (MAX_BUCKET_* records).
MinHash is O(n × hashes) with numpy arrays.
Runs on ~2 M records in under 30 min on a single machine.
"""

import os
import re
import random
import unicodedata
from collections import defaultdict

import numpy as np
import pandas as pd

# ── reproducibility ───────────────────────────────────────────────────────────
SEED = 42
random.seed(SEED)
np.random.seed(SEED)

# ── output ────────────────────────────────────────────────────────────────────
OUTPUT_DIR   = "results"
OUTPUT_FILE  = os.path.join(OUTPUT_DIR, "output1.csv")
TARGET_PAIRS = 2_000_000

# Bucket caps (prevent O(k²) blow-up in any single bucket)
MAX_BUCKET_COMPOSITE  = 100  # ≤ 4 950 pairs / bucket
MAX_BUCKET_LSH4       = 150  # 4-row LSH  ≤ 11 175 pairs / bucket
MAX_BUCKET_BRAND_TYPE = 300  # brand+type ≤ 44 850 pairs / bucket
MAX_BUCKET_LSH2       = 100  # 2-row LSH  ≤ 4 950 pairs / bucket

# MinHash parameters (primary pass: 4-row bands)
NUM_HASHES_4    = 64
NUM_BANDS_4     = 16
ROWS_4          = NUM_HASHES_4 // NUM_BANDS_4   # 4

# MinHash parameters (secondary pass: 2-row bands – more sensitive)
NUM_HASHES_2    = 64
NUM_BANDS_2     = 32
ROWS_2          = NUM_HASHES_2 // NUM_BANDS_2   # 2

# ── brand aliases ─────────────────────────────────────────────────────────────
BRAND_ALIASES: dict[str, str] = {
    "sandisk":    "sandisk",
    "san disk":   "sandisk",
    "cruzer":     "sandisk",    # product → brand (robust brand detection)
    "cruizer":    "sandisk",
    "kingston":   "kingston",
    "hyperx":     "kingston",
    "lexar":      "lexar",
    "sony":       "sony",
    "toshiba":    "toshiba",
    "transmemory": "toshiba",
    "intenso":    "intenso",
    "samsung":    "samsung",
    "pny":        "pny",
    "transcend":  "transcend",
    "verbatim":   "verbatim",
    "hama":       "hama",
    "emtec":      "emtec",
    "patriot":    "patriot",
    "corsair":    "corsair",
    "goodram":    "goodram",
    "strontium":  "strontium",
    "adata":      "adata",
}

# ── stop-words (multilingual) ─────────────────────────────────────────────────
STOP_WORDS: set[str] = {
    # English technical
    "usb", "sd", "card", "flash", "drive", "memory", "class", "ultra", "pro",
    "extreme", "plus", "micro", "mini", "nano", "type", "the", "and", "for",
    "with", "from", "in", "of", "to", "a", "an",
    "new", "original", "high", "speed", "read", "write", "gen", "ver",
    # French
    "de", "la", "le", "les", "du", "un", "une", "des", "en", "et",
    "go", "cle", "cla", "carte",
    "achat", "rayon", "dans",
    # German
    "speicherkarte", "laufwerk", "kaufen", "kauf",
    # Italian / Spanish
    "chiavetta", "scheda", "memoria", "unidad", "tarjeta",
    # Portuguese-ish
    "pami",
    # Retail / marketing
    "direct", "tesco", "amazon", "brand", "official", "genuine",
    "accessoires", "montres", "bracelets",    # French category paths
    # Colours (not product-identifying)
    "black", "white", "red", "blue", "silver", "gold", "gray", "grey",
    "negro", "blanc", "rouge", "schwarz", "weiss", "gris", "silber",
    "noir", "argent", "azul", "rojo", "blanco",
    # Speed numbers (mis-matching)
    "90", "80", "70", "60", "150", "200", "260", "280", "300", "400",
    "mbs", "mhz",
    # Generic product words
    "stick", "pendrive", "uhs", "uhsi",
    "000", "line", "series", "pack", "set", "kit", "lot", "item",
    # Common e-commerce noise
    "lecteur", "reader", "llave", "fnac", "rayon", "cles",
    "precio", "kaufen", "products", "product",
}

# ── text normalisation ────────────────────────────────────────────────────────

def _normalise(text: str) -> str:
    text = str(text).lower()
    text = re.sub(r"&[a-z]+;", " ", text)                       # HTML entities
    nfkd = unicodedata.normalize("NFKD", text)
    text = nfkd.encode("ascii", "ignore").decode("ascii")       # ASCII-fold accents
    text = re.sub(r"[^a-z0-9 ]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


# ── brand extraction ──────────────────────────────────────────────────────────

def extract_brand(norm_name: str, brand_field=None) -> str:
    """Detect canonical brand from name + brand field."""
    bf = _normalise(str(brand_field)) if (brand_field is not None and
                                          pd.notna(brand_field)) else ""
    combined = norm_name + " " + bf
    for alias, canonical in BRAND_ALIASES.items():
        if re.search(r"\b" + re.escape(alias) + r"\b", combined):
            return canonical
    return ""


# ── capacity extraction ───────────────────────────────────────────────────────
_VALID_CAPS = {1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048}

def extract_capacity(norm_name: str) -> list[str]:
    caps: set[str] = set()
    for v in re.findall(r"(\d+)\s*tb", norm_name):
        c = int(v) * 1024
        if c in _VALID_CAPS:
            caps.add(str(c))
    for v in re.findall(r"(\d+)\s*(?:gb|go)", norm_name):
        c = int(v)
        if c in _VALID_CAPS:
            caps.add(str(c))
    for v in re.findall(r"(\d+)\s*mb(?!/s|/sec|\d)", norm_name):
        vi = int(v)
        c = vi // 1024
        if c in _VALID_CAPS and vi >= 512:
            caps.add(str(c))
    return sorted(caps)


# ── product type detection ────────────────────────────────────────────────────

def extract_product_type(norm_name: str) -> str:
    """Return 'microsd', 'sd', 'usb', or '' if unknown."""
    if re.search(r"\b(microsdhc|microsdxc|microsd|micro sdhc|micro sdxc)\b",
                 norm_name):
        return "microsd"
    if re.search(r"\b(sdhc|sdxc|cf card|compactflash)\b", norm_name):
        return "sd"
    if re.search(r"\b(usb|pendrive|chiavetta|laufwerk|stick)\b", norm_name):
        return "usb"
    return ""


# ── token extraction ──────────────────────────────────────────────────────────

def extract_tokens(norm_name: str) -> set[str]:
    raw = set(re.findall(r"[a-z0-9]+", norm_name))
    out: set[str] = set()
    for t in raw:
        if t in STOP_WORDS:
            continue
        if len(t) < 3:
            continue
        if t.isdigit() and len(t) > 8:      # very long numbers are noise
            continue
        out.add(t)
    return out


def build_feature_set(norm_name: str, brand: str,
                      caps: list[str], ptype: str) -> set[str]:
    feats: set[str] = set()
    if brand:
        feats.add("B:" + brand)
    for c in caps:
        feats.add("C:" + c)
    if ptype:
        feats.add("T:" + ptype)
    feats |= extract_tokens(norm_name)
    return feats


# ── MinHash ───────────────────────────────────────────────────────────────────

_PRIME = (1 << 31) - 1


def _stable_hash(s: str) -> int:
    """FNV-1a hash: deterministic across runs (unaffected by PYTHONHASHSEED)."""
    h = 0x811C_9DC5
    for byte in s.encode("utf-8", "replace"):
        h ^= byte
        h = (h * 0x0100_0193) & 0xFFFF_FFFF
    return h & 0x7FFF_FFFF


def _make_hash_params(num_hashes: int, seed: int = 42):
    rng = np.random.default_rng(seed)
    a = rng.integers(1, _PRIME, size=num_hashes, dtype=np.int64)
    b = rng.integers(0, _PRIME, size=num_hashes, dtype=np.int64)
    return a, b


_HA4, _HB4 = _make_hash_params(NUM_HASHES_4, seed=42)
_HA2, _HB2 = _make_hash_params(NUM_HASHES_2, seed=99)


def _minhash(feats: set[str], ha: np.ndarray, hb: np.ndarray) -> np.ndarray:
    if not feats:
        return np.full(len(ha), _PRIME, dtype=np.int64)
    # Use stable FNV-1a hash instead of Python's hash() to ensure reproducibility
    fi = np.array([_stable_hash(f) for f in feats], dtype=np.int64)
    hv = (ha[:, None] * fi[None, :] + hb[:, None]) % _PRIME
    return hv.min(axis=1)


def _band_keys(sig: np.ndarray, num_bands: int, rows: int) -> list[int]:
    """Deterministic band bucket keys (no Python hash randomisation)."""
    keys = []
    for b in range(num_bands):
        s = b * rows
        chunk = sig[s: s + rows]
        # FNV-like mix: deterministic across PYTHONHASHSEED
        h = b * 2_654_435_761
        for v in chunk:
            h = ((h ^ int(v)) * 16_777_619) & 0xFFFF_FFFF
        keys.append(h)
    return keys


# ── composite blocking keys ───────────────────────────────────────────────────

def composite_keys(brand: str, caps: list[str],
                   ptype: str, feats: set[str]) -> list[str]:
    keys: list[str] = []

    model_codes = sorted(
        f for f in feats
        if re.search(r"[a-z][0-9]|[0-9][a-z]", f)
        and len(f) >= 4
        and not f.startswith(("B:", "C:", "T:"))
    )
    long_words = sorted(
        f for f in feats
        if f.isalpha() and len(f) >= 5
        and not f.startswith(("B:", "C:", "T:"))
    )

    if brand:
        for c in caps:
            keys.append(f"bc|{brand}|{c}")
            for m in model_codes[:3]:
                keys.append(f"bcm|{brand}|{c}|{m}")
            for w in long_words[:3]:
                keys.append(f"bcw|{brand}|{c}|{w}")
        for m in model_codes[:4]:
            keys.append(f"bm|{brand}|{m}")
        for w in long_words[:4]:
            keys.append(f"bw|{brand}|{w}")

    # Brand-agnostic (for records missing brand detection)
    for c in caps:
        for m in model_codes[:3]:
            keys.append(f"cm|{c}|{m}")
        for w in long_words[:3]:
            keys.append(f"cw|{c}|{w}")

    # Two long words together (product-family key)
    if len(long_words) >= 2:
        lw = long_words[:5]
        for i in range(len(lw)):
            for j in range(i + 1, len(lw)):
                keys.append(f"ww|{lw[i]}|{lw[j]}")

    return keys


def brand_type_keys(brand: str, ptype: str) -> list[str]:
    """Coarse keys: brand+type (catches brand-only pairs within same product category)."""
    if not brand:
        return []
    keys = []
    if ptype:
        keys.append(f"bt|{brand}|{ptype}")
    # Merge sd and microsd into a single "card" bucket (cross-type true matches)
    if ptype in ("sd", "microsd"):
        keys.append(f"bt|{brand}|card")
    # Brand-only key (all product types); used when ptype is unknown
    keys.append(f"b_|{brand}")
    return keys


# ── bucket → pairs (capped) ───────────────────────────────────────────────────

def _pairs_from_bucket(ids: list[int], cap: int) -> list[tuple[int, int]]:
    if len(ids) < 2:
        return []
    if len(ids) > cap:
        ids = random.sample(ids, cap)
    ids = sorted(ids)
    pairs = []
    for i in range(len(ids)):
        for j in range(i + 1, len(ids)):
            pairs.append((ids[i], ids[j]))
    return pairs


# ── Jaccard helper ────────────────────────────────────────────────────────────

def _jaccard(s1: set[str], s2: set[str]) -> float:
    u = len(s1 | s2)
    return 0.0 if u == 0 else len(s1 & s2) / u


# ── main blocking function ────────────────────────────────────────────────────

def block_x2(X2: pd.DataFrame) -> list[tuple[int, int]]:
    n = len(X2)
    print(f"[block_x2] {n:,} records")

    # ── 1. Feature extraction ────────────────────────────────────────────────
    print("[1/5] Extracting features …")

    records: list[dict] = []
    for idx in range(n):
        row     = X2.iloc[idx]
        real_id = int(row["id"])
        norm    = _normalise(row["name"])
        brand   = extract_brand(norm, row.get("brand"))
        caps    = extract_capacity(norm)
        ptype   = extract_product_type(norm)
        feats   = build_feature_set(norm, brand, caps, ptype)
        records.append({
            "id": real_id, "brand": brand,
            "caps": caps, "ptype": ptype, "feats": feats,
        })

    id_to_idx = {rec["id"]: i for i, rec in enumerate(records)}

    # ── 2. Composite-key blocking ────────────────────────────────────────────
    print("[2/5] Composite-key blocking …")

    comp_index: dict[str, list[int]] = defaultdict(list)
    for i, rec in enumerate(records):
        for key in composite_keys(
                rec["brand"], rec["caps"], rec["ptype"], rec["feats"]):
            comp_index[key].append(i)

    comp_pairs: set[tuple[int, int]] = set()
    for bucket in comp_index.values():
        for a_idx, b_idx in _pairs_from_bucket(bucket, MAX_BUCKET_COMPOSITE):
            ra = records[a_idx]["id"]
            rb = records[b_idx]["id"]
            comp_pairs.add((min(ra, rb), max(ra, rb)))

    print(f"  composite pairs: {len(comp_pairs):,}")

    # ── 3. 4-row MinHash LSH ─────────────────────────────────────────────────
    print("[3/5] 4-row MinHash LSH …")

    lsh4_index: dict[int, list[int]] = defaultdict(list)
    sigs4: list[np.ndarray] = []

    for i, rec in enumerate(records):
        sig = _minhash(rec["feats"], _HA4, _HB4)
        sigs4.append(sig)
        for bk in _band_keys(sig, NUM_BANDS_4, ROWS_4):
            lsh4_index[bk].append(i)

    lsh4_pairs: set[tuple[int, int]] = set()
    for bucket in lsh4_index.values():
        for a_idx, b_idx in _pairs_from_bucket(bucket, MAX_BUCKET_LSH4):
            ra = records[a_idx]["id"]
            rb = records[b_idx]["id"]
            lsh4_pairs.add((min(ra, rb), max(ra, rb)))

    print(f"  4-row LSH pairs: {len(lsh4_pairs):,}")

    # ── 4. Brand × product-type blocking ────────────────────────────────────
    print("[4/5] Brand×type blocking …")

    bt_index: dict[str, list[int]] = defaultdict(list)
    for i, rec in enumerate(records):
        for key in brand_type_keys(rec["brand"], rec["ptype"]):
            bt_index[key].append(i)

    bt_pairs: set[tuple[int, int]] = set()
    for bucket in bt_index.values():
        for a_idx, b_idx in _pairs_from_bucket(bucket, MAX_BUCKET_BRAND_TYPE):
            ra = records[a_idx]["id"]
            rb = records[b_idx]["id"]
            bt_pairs.add((min(ra, rb), max(ra, rb)))

    print(f"  brand×type pairs: {len(bt_pairs):,}")

    # ── 5. 2-row MinHash LSH (supplementary) ────────────────────────────────
    print("[5/5] 2-row MinHash LSH (supplementary) …")

    lsh2_index: dict[int, list[int]] = defaultdict(list)
    for i, rec in enumerate(records):
        sig2 = _minhash(rec["feats"], _HA2, _HB2)
        for bk in _band_keys(sig2, NUM_BANDS_2, ROWS_2):
            lsh2_index[bk].append(i)

    lsh2_pairs: set[tuple[int, int]] = set()
    for bucket in lsh2_index.values():
        for a_idx, b_idx in _pairs_from_bucket(bucket, MAX_BUCKET_LSH2):
            ra = records[a_idx]["id"]
            rb = records[b_idx]["id"]
            lsh2_pairs.add((min(ra, rb), max(ra, rb)))

    print(f"  2-row LSH pairs: {len(lsh2_pairs):,}")

    # ── Union and score-rank ─────────────────────────────────────────────────
    # Safety cap: avoid excessive memory on very large datasets
    MAX_TOTAL_CANDIDATES = 10_000_000

    # Merge in priority order (comp > lsh4 > bt > lsh2)
    all_pairs_set: set[tuple[int, int]] = comp_pairs | lsh4_pairs
    if len(all_pairs_set) < MAX_TOTAL_CANDIDATES:
        all_pairs_set |= bt_pairs
    if len(all_pairs_set) < MAX_TOTAL_CANDIDATES:
        all_pairs_set |= lsh2_pairs

    all_pairs = list(all_pairs_set)
    print(f"  total unique candidates: {len(all_pairs):,}")

    if len(all_pairs) <= TARGET_PAIRS:
        print("  fewer candidates than target → padding with (0,0)")
        return all_pairs

    # Score by Jaccard (+ bonus for high-quality blocking passes)
    def score(pair: tuple[int, int]) -> float:
        ra, rb = pair
        ia = id_to_idx.get(ra, -1)
        ib = id_to_idx.get(rb, -1)
        if ia < 0 or ib < 0:
            return 0.0
        j = _jaccard(records[ia]["feats"], records[ib]["feats"])
        bonus = (0.25 if pair in comp_pairs else
                 0.15 if pair in lsh4_pairs else
                 0.10 if pair in bt_pairs else 0.0)
        return j + bonus

    print(f"  ranking {len(all_pairs):,} pairs …")
    all_pairs.sort(key=score, reverse=True)
    return all_pairs[:TARGET_PAIRS]


# ── entry point ───────────────────────────────────────────────────────────────

def main() -> None:
    X2 = pd.read_csv("/Users/USER/Documents/UNI/SS26/SIGMOD_full_data/X2.csv")
    candidates = block_x2(X2)

    while len(candidates) < TARGET_PAIRS:
        candidates.append((0, 0))

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    df = pd.DataFrame(candidates[:TARGET_PAIRS], columns=["lid", "rid"])
    df.to_csv(OUTPUT_FILE, index=False)
    print(f"\nSaved {len(df):,} rows → {OUTPUT_FILE}")


if __name__ == "__main__":
    main()