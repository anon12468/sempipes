import pandas as pd
import re
import collections
from itertools import combinations
import time
import sys

TARGET_NUM_PAIRS = 2_000_000

def preprocess_text(text):
    """A more advanced preprocessing function."""
    if not isinstance(text, str):
        return ""
    text = text.lower()
    # Normalize various units and terms
    text = re.sub(r'(\d+)\s*inch(es)?"', r' \1in ', text)
    text = re.sub(r'(\d+)\s*hertz', r' \1hz ', text)
    text = re.sub(r'(\d+)\s*gb', r' \1gb ', text)
    text = re.sub(r'(\d+)\s*mb', r' \1mb ', text)
    
    # Specific model number patterns
    text = re.sub(r'([a-zA-Z])\-?(\d+)', r'\1\2', text)

    # Remove generic terms that are not useful for blocking
    generic_terms = ['led', 'lcd', 'tv', 'television', 'hdtv', 'smart', 'ultra', 'hd', 'new', 'for', 'with', 'and', 'the', 'a', 'an', 'to', 'in', 'on', 'of', 'is', 'it', 'all']
    for term in generic_terms:
        text = re.sub(r'\b' + term + r'\b', ' ', text)
    
    # Remove punctuation
    text = re.sub(r'[^\w\s]', ' ', text)
    # Remove extra whitespace
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def get_blocking_keys(title):
    keys = set()
    clean_title = preprocess_text(title)
    tokens = clean_title.split()
    
    if not tokens:
        return keys

    # Key Group 1: Model numbers (high confidence)
    for token in tokens:
        if any(char.isdigit() for char in token) and any(char.isalpha() for char in token) and len(token) > 4:
            keys.add(f"M_{token}")

    # Key Group 2: Brand + a dimension (medium confidence)
    brand = tokens[0] if tokens else ''
    if len(brand) > 1:
        for token in tokens:
            if 'in' in token or 'hz' in token or 'gb' in token:
                keys.add(f"BD_{brand}_{token}")

    # Key Group 3: First three tokens (medium confidence)
    if len(tokens) >= 3:
        keys.add(f"T3_{tokens[0]}_{tokens[1]}_{tokens[2]}")
    
    # Key Group 4: Individual significant tokens (lower confidence)
    for token in tokens:
        if len(token) > 2 and not token.isdigit():
            keys.add(f"T_{token}")
            
    return keys

def generate_pairs_snm(ids, records_map, window_size):
    if len(ids) <= 1:
        return
    # The title is at index 0 of the record tuple (title, price)
    sorted_ids = sorted(ids, key=lambda id: records_map[id][0])
    
    for i in range(len(sorted_ids)):
        for j in range(i + 1, min(i + window_size, len(sorted_ids))):
            id1, id2 = sorted_ids[i], sorted_ids[j]
            yield tuple(sorted((id1, id2)))

def add_pairs_from_keys(keys, inverted_index, records_map, candidate_pairs, stop_at):
    MAX_BUCKET_SIZE_COMB = 50 
    WINDOW_SIZE_SNM = 5
    
    keys.sort(key=lambda k: len(inverted_index[k]))

    for key in keys:
        ids = inverted_index[key]
        if len(ids) <= 1:
            continue
            
        if len(ids) <= MAX_BUCKET_SIZE_COMB:
            for id1, id2 in combinations(sorted(ids), 2):
                candidate_pairs.add((id1, id2))
        else:
            for pair in generate_pairs_snm(ids, records_map, WINDOW_SIZE_SNM):
                candidate_pairs.add(pair)
        
        if len(candidate_pairs) >= stop_at:
            return True
    return False

def main():
    start_time = time.time()
    
    df = pd.read_csv('/Users/USER/Documents/UNI/SS26/SIGMOD_full_data/X2.csv')
    records_map = {row.id: (preprocess_text(f"{row.name} {row.description}"), 0) for row in df.itertuples(index=False)}

    inverted_index = collections.defaultdict(list)
    for record_id, (title, price) in records_map.items():
        keys = get_blocking_keys(title)
        for key in keys:
            inverted_index[key].append(record_id)
            
    print(f"Built inverted index with {len(inverted_index)} keys in {time.time() - start_time:.2f}s")

    candidate_pairs = set()
    all_keys = list(inverted_index.keys())

    key_groups = [
        [k for k in all_keys if k.startswith('M_')],
        [k for k in all_keys if k.startswith('BD_')],
        [k for k in all_keys if k.startswith('T3_')],
        [k for k in all_keys if k.startswith('T_')]
    ]
    
    target = TARGET_NUM_PAIRS
    for i, keys in enumerate(key_groups):
        stop_at = target if i == len(key_groups) - 1 else float('inf')
        
        target_reached = add_pairs_from_keys(keys, inverted_index, records_map, candidate_pairs, stop_at)
        if target_reached:
            break

    print(f"Generated {len(candidate_pairs)} unique pairs in {time.time() - start_time:.2f}s")
    
    output_df = pd.DataFrame(list(candidate_pairs), columns=['lid', 'rid'])
    
    if len(output_df) > TARGET_NUM_PAIRS:
        output_df = output_df.sample(n=TARGET_NUM_PAIRS, random_state=42)
    elif len(output_df) < TARGET_NUM_PAIRS:
        num_missing = TARGET_NUM_PAIRS - len(output_df)
        padding = pd.DataFrame({'lid': [0] * num_missing, 'rid': [0] * num_missing})
        output_df = pd.concat([output_df, padding])

    output_df.sort_values(['lid', 'rid'], inplace=True)
    output_df.to_csv('working/output.csv', index=False)
    
    print(f"Finished in {time.time() - start_time:.2f}s")

if __name__ == "__main__":
    main()
