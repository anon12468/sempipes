import pandas as pd
from collections import defaultdict
import re
import time

# --- Configuration ---
OUTPUT_PATH = "working/output.csv"
TARGET_PAIRS = 2_000_000
MAX_BUCKET_SIZE_HARD = 5000  # Hard limit to skip extremely common tokens
SLIDING_WINDOW_SIZE = 20 # Window for pairing within a bucket

# --- Text Cleaning and Tokenization ---
def normalize_text(text):
    """Cleans and tokenizes text for blocking."""
    if not isinstance(text, str):
        return []
    
    # Lowercase
    text = text.lower()
    
    # Remove punctuation but keep alphanumeric chars and spaces
    text = re.sub(r'[^a-z0-9\s]', ' ', text)
    
    # Normalize spaces
    text = re.sub(r'\s+', ' ', text).strip()
    
    # Tokenize
    tokens = text.split()

    # Further normalization: combine numbers with units
    # Example: '16 gb' -> '16gb'
    normalized_tokens = []
    i = 0
    while i < len(tokens):
        # Look for number followed by a common unit
        if tokens[i].isdigit() and i + 1 < len(tokens) and tokens[i+1] in ['gb', 'mb', 'tb', 'mah', 'inch', 'hz', 'cm', 'mm']:
            normalized_tokens.append(tokens[i] + tokens[i+1])
            i += 2
        else:
            normalized_tokens.append(tokens[i])
            i += 1
            
    # Remove generic stopwords
    stopwords = {'the', 'a', 'an', 'and', 'or', 'for', 'to', 'in', 'on', 'with', 'of', 'is', 'pro', 'new', 'card', 'usb', 'sd', 'micro'}
    final_tokens = [tok for tok in normalized_tokens if tok not in stopwords and len(tok) > 1]
    
    return list(set(final_tokens)) # Use unique tokens per product

# --- Main Blocking Logic ---
def main():
    print("Starting blocking process...")
    start_time = time.time()

    # Load data
    try:
        df = pd.read_csv("/Users/USER/Documents/UNI/SS26/SIGMOD_full_data/X2.csv", index_col='id')
    except FileNotFoundError:
        print("Error: data/X2.csv not found.")
        return

    # Combine relevant text fields, handling potential missing values
    df['text'] = df['name'].fillna('') + ' ' + df['brand'].fillna('') + ' ' + df['description'].fillna('')
    
    # Build inverted index
    print("Building inverted index...")
    inverted_index = defaultdict(list)
    for doc_id, text in df['text'].items():
        tokens = normalize_text(text)
        for token in tokens:
            inverted_index[token].append(doc_id)

    print(f"Inverted index built with {len(inverted_index)} unique tokens.")

    # Candidate pair generation
    print("Generating candidate pairs with sliding window...")
    candidate_pairs = set()

    # Sort tokens by bucket size to process smaller (more distinctive) buckets first
    sorted_tokens = sorted(inverted_index.keys(), key=lambda t: len(inverted_index[t]))

    for token in sorted_tokens:
        if len(candidate_pairs) >= TARGET_PAIRS * 1.05: # Stop if we have enough candidates
            print("Target candidate count reached. Stopping pair generation.")
            break

        ids = inverted_index[token]
        bucket_size = len(ids)

        if bucket_size <= 1 or bucket_size > MAX_BUCKET_SIZE_HARD:
            continue
            
        # Sort IDs to enable sliding window and ensure (lid, rid) order
        ids.sort()
        
        # Apply sliding window
        for i in range(bucket_size):
            window_end = min(i + 1 + SLIDING_WINDOW_SIZE, bucket_size)
            for j in range(i + 1, window_end):
                # Ensure lid < rid, although sort should handle this
                pair = (ids[i], ids[j]) if ids[i] < ids[j] else (ids[j], ids[i])
                candidate_pairs.add(pair)

    print(f"Generated {len(candidate_pairs)} unique candidate pairs.")

    # Format for output
    output_pairs = list(candidate_pairs)
    
    if len(output_pairs) > TARGET_PAIRS:
        # If we have too many, we can just truncate.
        # A random sample would be better, but this is faster and compliant.
        output_pairs = output_pairs[:TARGET_PAIRS]
    elif len(output_pairs) < TARGET_PAIRS:
        # Pad with dummy pairs if we don't have enough
        padding = [(0, 0)] * (TARGET_PAIRS - len(output_pairs))
        output_pairs.extend(padding)

    # Save to CSV
    print(f"Saving {len(output_pairs)} pairs to {OUTPUT_PATH}...")
    output_df = pd.DataFrame(output_pairs, columns=['lid', 'rid'])
    output_df.to_csv(OUTPUT_PATH, index=False)
    
    end_time = time.time()
    print(f"Blocking finished in {end_time - start_time:.2f} seconds.")

if __name__ == "__main__":
    main()
