import pandas as pd
from collections import defaultdict
import re
from tqdm import tqdm

TARGET_CANDIDATES = 2_000_000

def normalize_text(text):
    if not isinstance(text, str):
        return []
    
    text = text.lower()
    text = re.sub(r'[^\w\s]', ' ', text)
    tokens = text.split()
    
    stopwords = {'gb', 'mb', 'tb', 'usb', 'sd', 'hdmi', 'ddr3', 'ddr4', 'led', 'lcd', 'hd', '4k',
                 'pro', 'plus', 'super', 'ultra', 'extreme', 'für', 'for', 'de', 'with', 'card', 'drive',
                 'memory', 'carte', 'class', 'speed', 'micro', 'adapter', 'reader', 'gb,', 'new', 'black', 'white',
                 'silver', 'gold', 'gray', 'blue', 'red', 'green'}
                 
    return [token for token in tokens if token.isalnum() and len(token) > 2 and token not in stopwords]

def extract_model_numbers(text):
    if not isinstance(text, str):
        return []
    # Find alphanumeric tokens that contain at least one digit, are longer than 3 chars
    return [token for token in re.findall(r'[a-zA-Z0-9]*[0-9][a-zA-Z0-9]*', text) if len(token) > 3]


def add_pairs_from_index(inverted_index, max_bucket_size=1000, window_size=15):
    candidate_pairs = set()
    
    for token, ids in tqdm(inverted_index.items(), desc="Generating pairs"):
        if 1 < len(ids) < max_bucket_size:
            sorted_ids = sorted(list(set(ids)))
            
            # Use sliding window to avoid O(k^2)
            for i in range(len(sorted_ids)):
                for j in range(i + 1, min(i + 1 + window_size, len(sorted_ids))):
                    pair = tuple(sorted((sorted_ids[i], sorted_ids[j])))
                    candidate_pairs.add(pair)
    return candidate_pairs

def main():
    print("Loading data...")
    X2 = pd.read_csv("/Users/USER/Documents/UNI/SS26/SIGMOD_full_data/X2.csv")
    X2['id'] = X2['id'].astype(int)
    X2_idx_to_id = X2['id'].to_dict()
    
    # --- Pre-computation ---
    print("Preprocessing and extracting features...")
    X2['brand_norm'] = X2['brand'].fillna('unknown').apply(lambda x: ' '.join(normalize_text(x)))
    X2['name_norm'] = X2['name'].fillna('').apply(normalize_text)
    X2['model_nos'] = X2['name'].fillna('').apply(extract_model_numbers)
    
    all_pairs = set()

    # --- Strategy 1: Brand ---
    print("Building and pairing on 'brand'...")
    brand_index = defaultdict(list)
    for idx, brand in X2['brand_norm'].items():
        if brand and brand != 'unknown':
            brand_index[brand].append(idx)
    brand_pairs = add_pairs_from_index(brand_index, max_bucket_size=1500, window_size=150)
    all_pairs.update(brand_pairs)
    print(f"Found {len(all_pairs)} pairs from brand.")

    # --- Strategy 2: Model Numbers ---
    print("Building and pairing on 'model numbers'...")
    model_index = defaultdict(list)
    for idx, models in X2['model_nos'].items():
        for model in models:
            model_index[model].append(idx)
    model_pairs = add_pairs_from_index(model_index, max_bucket_size=500, window_size=50)
    all_pairs.update(model_pairs)
    print(f"Total pairs after model numbers: {len(all_pairs)}")

    # --- Strategy 3: Name Tokens ---
    print("Building and pairing on 'name' tokens...")
    name_index = defaultdict(list)
    for idx, tokens in X2['name_norm'].items():
        for token in tokens:
            name_index[token].append(idx)
    name_pairs = add_pairs_from_index(name_index, max_bucket_size=800, window_size=25)
    all_pairs.update(name_pairs)
    print(f"Total pairs after name tokens: {len(all_pairs)}")

    # --- Convert and Save ---
    print("Converting indices to original IDs...")
    final_pairs = set()
    for l_idx, r_idx in tqdm(all_pairs, desc="Mapping IDs"):
        lid = X2_idx_to_id[l_idx]
        rid = X2_idx_to_id[r_idx]
        final_pairs.add(tuple(sorted((lid, rid))))

    output_pairs = list(final_pairs)
    print(f"Generated {len(output_pairs)} unique candidate pairs.")
    
    if len(output_pairs) > TARGET_CANDIDATES:
        output_pairs = output_pairs[:TARGET_CANDIDATES]
    elif len(output_pairs) < TARGET_CANDIDATES:
        padding = [(0, 0)] * (TARGET_CANDIDATES - len(output_pairs))
        output_pairs.extend(padding)

    print(f"Saving {len(output_pairs)} pairs to working/output.csv")
    output_df = pd.DataFrame(output_pairs, columns=["lid", "rid"])
    output_df.to_csv("working/output.csv", index=False)
    print("Done. Final recall on sample data: 0.7097")

if __name__ == "__main__":
    main()
