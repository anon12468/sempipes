import pandas as pd
import re
from collections import defaultdict
from tqdm import tqdm
import time

def clean_text(text):
    """Normalizes text by lowercasing, removing non-alphanumeric characters,
    and splitting into tokens."""
    if not isinstance(text, str):
        return []
    text = text.lower()
    # Keep alphanumeric sequences, including those with hyphens or dots often found in model numbers
    tokens = re.findall(r'[a-z0-9][a-z0-9-.]*[a-z0-9]|[a-z0-9]+', text)
    # Filter out generic terms that might create huge buckets
    stop_words = {'gb', 'sd', 'usb', 'pro', 'card', 'carte', 'sdhc', 'micro', 's', 'de', 'plus', 'hc', 'class', 'extreme'}
    return [token for token in tokens if len(token) > 2 and token not in stop_words]

def generate_candidates(df, target_count):
    """Generates candidate pairs using an inverted index and a sliding window."""
    inverted_index = defaultdict(list)
    
    print("Building inverted index...")
    # Use real IDs directly
    for doc_id, title in tqdm(zip(df['id'], df['name']), total=len(df)):
        tokens = clean_text(title)
        for token in tokens:
            inverted_index[token].append(doc_id)

    candidate_pairs = set()
    
    # Sort tokens by the size of their posting lists to process more unique tokens first
    sorted_tokens = sorted(inverted_index.keys(), key=lambda t: len(inverted_index[t]))

    print("Generating candidate pairs...")
    window_size = 5
    max_bucket_size = 5000 # Ignore tokens that are extremely common

    for token in tqdm(sorted_tokens):
        if len(candidate_pairs) >= target_count + 10000: # Generate a bit more to have some margin
            print(f"Target count reached. Halting pair generation at {len(candidate_pairs)} pairs.")
            break
            
        ids = sorted(inverted_index[token])
        
        if len(ids) > max_bucket_size or len(ids) < 2:
            continue

        # Use a sliding window to generate pairs: O(k*w) instead of O(k^2)
        for i in range(len(ids)):
            for j in range(i + 1, min(i + 1 + window_size, len(ids))):
                # Ensure lid < rid
                pair = tuple(sorted((ids[i], ids[j])))
                candidate_pairs.add(pair)

    return list(candidate_pairs)

def main():
    start_time = time.time()
    
    print("Loading data...")
    X2 = pd.read_csv("/Users/USER/Documents/UNI/SS26/SIGMOD_full_data/X2.csv")

    TARGET_PAIRS = 2_000_000
    candidate_pairs = generate_candidates(X2, TARGET_PAIRS)
    
    print(f"Generated {len(candidate_pairs)} unique candidate pairs.")

    # Trim to exactly the target size
    if len(candidate_pairs) > TARGET_PAIRS:
        # A simple truncation is used here. A more advanced method could sort by some heuristic.
        # But given the scale, this is a safe and feasible approach.
        final_pairs = candidate_pairs[:TARGET_PAIRS]
    else:
        final_pairs = candidate_pairs
    
    # Pad if necessary
    if len(final_pairs) < TARGET_PAIRS:
        padding = [(0, 0)] * (TARGET_PAIRS - len(final_pairs))
        final_pairs.extend(padding)

    print(f"Writing {len(final_pairs)} pairs to output.csv...")
    output_df = pd.DataFrame(final_pairs, columns=["lid", "rid"])
    output_df.to_csv("working/output.csv", index=False)
    
    end_time = time.time()
    print(f"Total time taken: {end_time - start_time:.2f} seconds.")
    print("Script finished successfully.")

if __name__ == "__main__":
    main()
