import pandas as pd
from collections import defaultdict
import re
from tqdm import tqdm
import random

def normalize_text(text):
    """Normalizes text by lowercasing, removing punctuation, and specific patterns."""
    if not isinstance(text, str):
        return ''
    text = text.lower()
    # Remove punctuation
    text = re.sub(r'[^\w\s]', ' ', text)
    # Remove common irrelevant terms
    stop_words = {'gb', 'tb', 'mb', 'usb', 'sd', 'sdhc', 'sdxc', 'micro', 'class', 'pro', 'extreme', 'ultra'}
    text = ' '.join([word for word in text.split() if word not in stop_words])
    # Standardize capacity units
    text = re.sub(r'(\d+)\s*g[b]?', r'\1gb', text)
    text = re.sub(r'(\d+)\s*t[b]?', r'\1tb', text)
    # Normalize spaces
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def get_tokens(text):
    """Extracts alphanumeric tokens."""
    return re.findall(r'[a-z0-9]+', text)

def add_pairs_from_bucket(bucket):
    """
    Generates candidate pairs from a bucket using a hybrid approach to avoid O(k^2).
    """
    ids = sorted(list(set(bucket)))
    k = len(ids)
    if k < 2:
        return []

    pairs = set()
    
    # For large buckets, use a sliding window to keep it feasible.
    if k > 100:
        window_size = 10
        for i in range(k):
            for j in range(i + 1, min(i + 1 + window_size, k)):
                pairs.add(tuple(sorted((ids[i], ids[j]))))
    else: # For smaller buckets, generating all pairs is feasible and gives better recall.
        for i in range(k):
            for j in range(i + 1, k):
                pairs.add(tuple(sorted((ids[i], ids[j]))))
    
    return list(pairs)


def main():
    # Load data
    print("Loading data...")
    X2 = pd.read_csv("/Users/USER/Documents/UNI/SS26/SIGMOD_full_data/X2.csv")
    X2['idx'] = range(len(X2))

    print("Preprocessing and building inverted indices...")
    inverted_index = defaultdict(list)
    
    model_no_regex = re.compile(r'\b([a-zA-Z]+\d+|\d+[a-zA-Z]+)[\w-]*\b')

    for i, row in tqdm(X2.iterrows(), total=len(X2)):
        # --- Blocking Key 1: Normalized Brand ---
        brand = normalize_text(row['brand'])
        if brand:
            inverted_index[f"brand_{brand}"].append(row['idx'])

        # --- Blocking Key 2: Tokens from Name ---
        name = normalize_text(row['name'])
        tokens = get_tokens(name)
        for token in tokens:
            if len(token) > 2:
                 inverted_index[f"name_token_{token}"].append(row['idx'])

        # --- Blocking Key 3: Model Numbers from Name ---
        model_nos = model_no_regex.findall(name)
        for mn in model_nos:
            inverted_index[f"model_{mn}"].append(row['idx'])

    print("Generating candidate pairs...")
    candidate_pairs = set()
    
    max_bucket_size = 500
    for key, bucket in tqdm(inverted_index.items()):
        if 1 < len(bucket) < max_bucket_size:
            pairs = add_pairs_from_bucket(bucket)
            candidate_pairs.update(pairs)

    print(f"Generated {len(candidate_pairs)} unique candidate pairs.")

    print("Converting indices to original IDs...")
    final_pairs = []
    # Using a list comprehension for potentially faster conversion
    all_indices = list(candidate_pairs)
    id_map = X2['id'].to_dict()

    final_pairs_set = set()
    for idx1, idx2 in tqdm(all_indices):
        id1 = id_map[idx1]
        id2 = id_map[idx2]
        if id1 < id2:
            final_pairs_set.add((id1, id2))
        elif id2 < id1:
            final_pairs_set.add((id2, id1))
            
    final_pairs = list(final_pairs_set)
    
    if len(final_pairs) > 2000000:
        print(f"Sampling down to 2,000,000 pairs from {len(final_pairs)}.")
        final_pairs = random.sample(final_pairs, 2000000)

    num_to_pad = 2000000 - len(final_pairs)
    if num_to_pad > 0:
        print(f"Padding with {num_to_pad} dummy pairs.")
        final_pairs.extend([(0, 0)] * num_to_pad)

    print("Saving output...")
    output_df = pd.DataFrame(final_pairs, columns=["lid", "rid"])
    output_df.to_csv("working/output.csv", index=False)
    
    print("Done.")


if __name__ == "__main__":
    main()

