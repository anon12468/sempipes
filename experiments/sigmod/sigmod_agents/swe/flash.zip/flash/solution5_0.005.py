import pandas as pd
import re
from collections import defaultdict
from itertools import combinations
import numpy as np
import os
import time

def clean_text(text):
    if pd.isna(text):
        return ""
    text = str(text).lower()
    text = re.sub(r'[^a-z0-9\s-]', '', text) 
    text = re.sub(r'\s+', ' ', text).strip() # Replace multiple spaces with single space
    return text

def generate_blocking_keys(record):
    keys = set()
    name_cleaned = clean_text(record['name'])
    description_cleaned = clean_text(record['description'])
    brand_cleaned = clean_text(record['brand'])
    category_cleaned = clean_text(record['category'])

    name_tokens = name_cleaned.split()
    description_tokens = description_cleaned.split()
    brand_tokens = brand_cleaned.split()
    category_tokens = category_cleaned.split()

    all_tokens = name_tokens + description_tokens + brand_tokens + category_tokens

    for token in all_tokens:
        if len(token) > 2: 
            keys.add(token)

    # Add 2-grams and 3-grams from name, brand, and category if meaningful
    for tokens_list in [name_tokens, brand_tokens, category_tokens]:
        if len(tokens_list) > 1:
            for i in range(len(tokens_list) - 1):
                bigram = " ".join(tokens_list[i:i+2])
                if len(bigram) > 5:
                    keys.add(bigram)
        if len(tokens_list) > 2:
            for i in range(len(tokens_list) - 2):
                trigram = " ".join(tokens_list[i:i+3])
                if len(trigram) > 8:
                    keys.add(trigram)
    
    # First few characters of longer tokens (e.g., prefix blocking)
    for token in all_tokens:
        if len(token) > 6:
            keys.add(token[:4]) # First 4 chars
        elif len(token) > 4:
            keys.add(token[:3]) # First 3 chars

    return list(keys)

def solve():
    print("Loading data...")
    X2 = pd.read_csv('data/X2.csv')
    print(f"Loaded {len(X2)} records.")

    X2['cleaned_name'] = X2['name'].apply(clean_text)
    X2['cleaned_description'] = X2['description'].apply(clean_text)
    X2['cleaned_brand'] = X2['brand'].apply(clean_text)
    X2['cleaned_category'] = X2['category'].apply(clean_text)

    # Create a concatenated text field for sorting in large buckets
    X2['text_for_sorting'] = X2['cleaned_name'] + " " + X2['cleaned_description'] + " " + X2['cleaned_brand'] + " " + X2['cleaned_category']

    inverted_index = defaultdict(list)
    record_data = X2.set_index('id') 
    print("Building inverted index...")
    for index, record in X2.iterrows():
        record_id = record['id']
        blocking_keys = generate_blocking_keys(record)
        for key in blocking_keys:
            inverted_index[key].append(record_id)
    print("Inverted index built.")

    candidate_pairs = set()
    MAX_CANDIDATES = 2000000
    # Increasing these limits, but carefully considering feasibility on full dataset
    MAX_BUCKET_SIZE_FOR_EXACT_PAIRING = 2000 # Max bucket size for O(k^2) pairing. 
                                           # 2000^2 = 4M operations, still feasible for few buckets.
    PREFIX_SUFFIX_PAIRING_SIZE = 100       # For larger buckets, pair first/last N records
    DROP_BUCKET_THRESHOLD = 100000          # Drop buckets larger than this (very common tokens)

    print("Generating candidate pairs...")
    
    for key, record_ids_raw in inverted_index.items():
        if len(record_ids_raw) > DROP_BUCKET_THRESHOLD:
            # print(f"Skipping very large bucket for key: '{key}' with size {len(record_ids_raw)}")
            continue

        record_ids = sorted(list(set(record_ids_raw)))

        if len(record_ids) > 1:
            if len(record_ids) <= MAX_BUCKET_SIZE_FOR_EXACT_PAIRING:
                for l_id, r_id in combinations(record_ids, 2):
                    if l_id < r_id: 
                        candidate_pairs.add((l_id, r_id))
            else:
                # Use Sorted Neighborhood Method with a window
                bucket_items = []
                for r_id in record_ids:
                    if r_id in record_data.index:
                        bucket_items.append((record_data.loc[r_id, 'text_for_sorting'], r_id))
                
                bucket_items.sort()

                # Pair within a sliding window (SNM)
                for i in range(len(bucket_items)):
                    for j in range(i + 1, min(i + 1 + PREFIX_SUFFIX_PAIRING_SIZE, len(bucket_items))):
                        l_id = bucket_items[i][1]
                        r_id = bucket_items[j][1]
                        if l_id < r_id: 
                            candidate_pairs.add((l_id, r_id))

            # Early exit if we have enough candidates
            if len(candidate_pairs) >= MAX_CANDIDATES * 1.5: # Aim for 50% more to ensure diversity after sorting
                print(f"Reached {len(candidate_pairs)} candidates, stopping early for generation.")
                break
    
    print(f"Generated {len(candidate_pairs)} candidate pairs (before final truncation).")

    candidate_pairs_list = sorted(list(candidate_pairs))
    final_candidates = candidate_pairs_list[:MAX_CANDIDATES]

    while len(final_candidates) < MAX_CANDIDATES:
        print("Warning: Not enough candidate pairs generated. Duplicating existing pairs for strict output size compliance.")
        if final_candidates:
            current_len = len(final_candidates)
            pairs_to_add = MAX_CANDIDATES - current_len
            final_candidates.extend(final_candidates[i % current_len] for i in range(pairs_to_add))
        else:
            print("Error: No candidates generated at all. Cannot pad meaningfully.")
            break

    final_candidates = final_candidates[:MAX_CANDIDATES]

    output_dir = './results/'
    os.makedirs(output_dir, exist_ok=True)
    output_df = pd.DataFrame(final_candidates, columns=['lid', 'rid'])
    output_df.to_csv(os.path.join(output_dir, 'output.csv'), index=False)
    print(f"Saved {len(output_df)} candidate pairs to {os.path.join(output_dir, 'output.csv')}")

if __name__ == '__main__':
    start_time = time.time()
    solve()
    end_time = time.time()
    print(f"Blocking solution finished in {end_time - start_time:.2f} seconds.")
