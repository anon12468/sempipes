import pandas as pd
import re
from collections import defaultdict
import numpy as np
import os
import random

def normalize_name(name):
    if not isinstance(name, str):
        return ""
    name = name.lower()
    name = re.sub(r'[\s_/-]+', ' ', name)
    return name.strip()

def generate_candidates_with_safeguards(df, blocking_attr='name', target_pairs=2000000):
    processed_names = df[blocking_attr].apply(normalize_name)
    
    token_to_ids = defaultdict(list)
    for idx, name_tokens_str in enumerate(processed_names):
        tokens = name_tokens_str.split()
        
        # Add single tokens to inverted index
        for token in tokens:
            if len(token) > 1: # Avoid very short tokens
                token_to_ids[token].append(idx)
            
        # Add bigrams to inverted index
        bigrams = [' '.join(tokens[i:i+2]) for i in range(len(tokens) - 1)]
        for bigram in bigrams:
            if len(bigram) > 2: # Avoid very short bigrams
                token_to_ids[bigram].append(idx)
    
    candidate_pairs = set()
    
    VERY_SMALL_BUCKET_THRESHOLD = 100  # Generate all pairs for buckets up to this size
    MAX_PAIRS_FROM_LARGER_BUCKET = 50000 # For buckets larger than threshold, sample this many pairs

    # --- Stage 1: Blocking with name tokens and bigrams ---
    print("Starting blocking pass (name tokens and bigrams)...")
    for key, ids_in_bucket in token_to_ids.items(): 
        if len(ids_in_bucket) > 1: 
            sorted_ids = sorted(ids_in_bucket) 
            
            if len(sorted_ids) <= VERY_SMALL_BUCKET_THRESHOLD:
                # Generate all pairs for very small buckets
                for i in range(len(sorted_ids)):
                    for j in range(i + 1, len(sorted_ids)):
                        id1_idx, id2_idx = sorted_ids[i], sorted_ids[j]
                        real_id1, real_id2 = df['id'].iloc[id1_idx], df['id'].iloc[id2_idx]
                        if real_id1 < real_id2:
                            candidate_pairs.add((real_id1, real_id2))
                        else:
                            candidate_pairs.add((real_id2, real_id1))
            else:
                # For larger buckets, randomly sample a fixed number of pairs
                num_pairs_to_generate = min(MAX_PAIRS_FROM_LARGER_BUCKET, (len(sorted_ids) * (len(sorted_ids) - 1)) // 2)
                
                for _ in range(num_pairs_to_generate):
                    if len(candidate_pairs) >= target_pairs:
                        break
                    
                    if len(sorted_ids) < 2:
                        continue
                    idx1, idx2 = random.sample(range(len(sorted_ids)), 2)
                    
                    id1_in_bucket, id2_in_bucket = sorted_ids[idx1], sorted_ids[idx2]
                    real_id1, real_id2 = df['id'].iloc[id1_in_bucket], df['id'].iloc[id2_in_bucket]
                    
                    if real_id1 < real_id2:
                        candidate_pairs.add((real_id1, real_id2))
                    else:
                        candidate_pairs.add((real_id2, real_id1))
            
        if len(candidate_pairs) >= target_pairs:
            print(f"Reached target candidate pairs ({target_pairs}). Stopping further generation.")
            break 

    print(f"Total candidates generated: {len(candidate_pairs)}")
    
    final_candidates = list(candidate_pairs)
    
    if len(final_candidates) > target_pairs:
        print(f"Warning: Generated {len(final_candidates)} candidates, truncating to {target_pairs}.")
        final_candidates = final_candidates[:target_pairs]
    elif len(final_candidates) < target_pairs:
        print(f"Warning: Generated {len(final_candidates)} candidates, padding with (0,0) to reach {target_pairs}.")
        final_candidates.extend([(0, 0)] * (target_pairs - len(final_candidates)))

    return final_candidates

if __name__ == "__main__":
    os.makedirs("results", exist_ok=True)

    X2 = pd.read_csv("/Users/USER/Documents/UNI/SS26/SIGMOD_full_data/X2.csv")
    
    X2_candidate_pairs = generate_candidates_with_safeguards(X2, blocking_attr='name', target_pairs=2000000)
    
    output_df = pd.DataFrame(X2_candidate_pairs, columns=["lid", "rid"])
    output_df.to_csv("results/output3.csv", index=False)
    
    print(f"Generated {len(X2_candidate_pairs)} candidate pairs and saved to results/output.csv")
