import pandas as pd
import re
from collections import defaultdict
import itertools
import numpy as np

def clean_text(text):
    if pd.isna(text):
        return ""
    text = str(text).lower()
    text = re.sub(r'[^a-z0-9\s]', '', text) # remove special characters
    return text

def jaccard_similarity(s1, s2):
    if not s1 or not s2:
        return 0.0
    set1 = set(s1.split())
    set2 = set(s2.split())
    intersection = len(set1.intersection(set2))
    union = len(set1) + len(set2) - intersection
    return intersection / union if union else 0.0

def generate_candidates(df, max_candidate_pairs=2_000_000):
    all_candidate_pairs = set()
    records = df.to_dict('records') # Convert to list of dicts for faster access by index

    # Blocking on cleaned name tokens
    inverted_index = defaultdict(list)
    for i, record in enumerate(records):
        cleaned_name = clean_text(record['name'])
        tokens = cleaned_name.split()
        for token in tokens:
            if len(token) > 2: # Ignore very short tokens
                inverted_index[token].append(i)

    # Inverted index for brand and first two words of name
    brand_name_index = defaultdict(list)
    for i, record in enumerate(records):
        cleaned_brand = clean_text(record['brand'])
        cleaned_name = clean_text(record['name'])
        name_tokens = cleaned_name.split()
        blocking_key = ""
        if cleaned_brand:
            blocking_key += cleaned_brand
        if len(name_tokens) >= 2:
            blocking_key += "_" + name_tokens[0] + "_" + name_tokens[1]
        elif len(name_tokens) == 1:
            blocking_key += "_" + name_tokens[0]

        if blocking_key:
            brand_name_index[blocking_key].append(i)

    # Candidate generation with safeguards
    candidate_list_with_similarity = [] # Store (similarity, (id1, id2))

    # Blocking using inverted_index (tokens from name)
    for token, ids in inverted_index.items():
        if len(ids) > 1 and len(ids) <= 200: # Process small to medium buckets fully
            for i in range(len(ids)):
                for j in range(i + 1, len(ids)):
                    id1_idx, id2_idx = ids[i], ids[j]
                    real_id1, real_id2 = df['id'][id1_idx], df['id'][id2_idx]
                    if real_id1 < real_id2:
                        pair = (real_id1, real_id2)
                    else:
                        pair = (real_id2, real_id1)
                    if pair not in all_candidate_pairs:
                        all_candidate_pairs.add(pair)
                        # Calculate similarity for ranking later
                        s1 = clean_text(records[id1_idx]['name'])
                        s2 = clean_text(records[id2_idx]['name'])
                        sim = jaccard_similarity(s1, s2)
                        candidate_list_with_similarity.append((sim, pair))
        elif len(ids) > 200: # Apply sliding window for large buckets
            # Sort IDs to make windowing consistent
            ids.sort()
            window_size = 10 # Hyperparameter for window size
            for i in range(len(ids)):
                for j in range(i + 1, min(i + 1 + window_size, len(ids))):
                    id1_idx, id2_idx = ids[i], ids[j]
                    real_id1, real_id2 = df['id'][id1_idx], df['id'][id2_idx]
                    if real_id1 < real_id2:
                        pair = (real_id1, real_id2)
                    else:
                        pair = (real_id2, real_id1)
                    if pair not in all_candidate_pairs:
                        all_candidate_pairs.add(pair)
                        s1 = clean_text(records[id1_idx]['name'])
                        s2 = clean_text(records[id2_idx]['name'])
                        sim = jaccard_similarity(s1, s2)
                        candidate_list_with_similarity.append((sim, pair))

    # Blocking using brand_name_index
    for key, ids in brand_name_index.items():
        if len(ids) > 1 and len(ids) <= 200:
            for i in range(len(ids)):
                for j in range(i + 1, len(ids)):
                    id1_idx, id2_idx = ids[i], ids[j]
                    real_id1, real_id2 = df['id'][id1_idx], df['id'][id2_idx]
                    if real_id1 < real_id2:
                        pair = (real_id1, real_id2)
                    else:
                        pair = (real_id2, real_id1)
                    if pair not in all_candidate_pairs:
                        all_candidate_pairs.add(pair)
                        s1 = clean_text(records[id1_idx]['name'])
                        s2 = clean_text(records[id2_idx]['name'])
                        sim = jaccard_similarity(s1, s2)
                        candidate_list_with_similarity.append((sim, pair))
        elif len(ids) > 200: # Apply sliding window for large buckets
            ids.sort()
            window_size = 10
            for i in range(len(ids)):
                for j in range(i + 1, min(i + 1 + window_size, len(ids))):
                    id1_idx, id2_idx = ids[i], ids[j]
                    real_id1, real_id2 = df['id'][id1_idx], df['id'][id2_idx]
                    if real_id1 < real_id2:
                        pair = (real_id1, real_id2)
                    else:
                        pair = (real_id2, real_id1)
                    if pair not in all_candidate_pairs:
                        all_candidate_pairs.add(pair)
                        s1 = clean_text(records[id1_idx]['name'])
                        s2 = clean_text(records[id2_idx]['name'])
                        sim = jaccard_similarity(s1, s2)
                        candidate_list_with_similarity.append((sim, pair))

    # Sort candidates by similarity and truncate
    candidate_list_with_similarity.sort(key=lambda x: x[0], reverse=True)
    final_candidates = [pair for sim, pair in candidate_list_with_similarity[:max_candidate_pairs]]

    # Pad with (0,0) if not enough candidates, as per blocking.py
    if len(final_candidates) < max_candidate_pairs:
        final_candidates.extend([(0, 0)] * (max_candidate_pairs - len(final_candidates)))

    return final_candidates

# Main execution
if __name__ == "__main__":
    df_X2 = pd.read_csv("/Users/USER/Documents/UNI/SS26/SIGMOD_full_data/X2.csv")

    X2_candidate_pairs = generate_candidates(df_X2, max_candidate_pairs=2_000_000)

    output_df = pd.DataFrame(X2_candidate_pairs, columns=["lid", "rid"])
    output_df.to_csv("results/output4.csv", index=False)
