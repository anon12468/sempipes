import pandas as pd
import re
from collections import defaultdict
import itertools

def clean_text(text):
    if isinstance(text, str):
        text = text.lower()
        text = re.sub(r'[^a-z0-9\s]', '', text)
        return text.strip()
    return ''

def get_blocking_tokens(text_field, min_len=1):
    # Get tokens, with very minimal filtering to generate many general blocks
    # Lower min_len to 1 to include single character tokens, if any are meaningful.
    tokens = [token for token in clean_text(text_field).split() if len(token) >= min_len]
    return tokens

def generate_blocking_keys(record):
    keys = set() 

    # Use individual tokens from all fields for broadest blocking
    # Consider all tokens from all relevant fields.

    # Brand tokens
    brand_tokens = get_blocking_tokens(record['brand'])
    for token in brand_tokens:
        keys.add(f"BRAND_T_{token}")

    # Name tokens
    name_tokens = get_blocking_tokens(record['name'])
    for token in name_tokens:
        keys.add(f"NAME_T_{token}")

    # Category tokens
    category_tokens = get_blocking_tokens(record['category'])
    for token in category_tokens:
        keys.add(f"CAT_T_{token}")

    # Description tokens (allow even more description tokens for more keys)
    description_tokens = get_blocking_tokens(record['description'])
    for token in description_tokens[:15]: # Take up to 15 description tokens
        keys.add(f"DESC_T_{token}")

    return list(keys)

def solve():
    df = pd.read_csv('/Users/USER/Documents/UNI/SS26/SIGMOD_full_data/X2.csv')
    
    for col in df.columns:
        if df[col].dtype in ['int64', 'float64']:
            df[col] = df[col].fillna(0)
        else:
            df[col] = df[col].fillna('')

    block_map = defaultdict(list)
    for index, row in df.iterrows():
        record_id = row['id']
        blocking_keys = generate_blocking_keys(row)
        for key in blocking_keys:
            block_map[key].append(record_id)

    candidate_pairs = set()
    MAX_CANDIDATES = 2_000_000
    # Push UNIVERSAL_WINDOW_SIZE to an extreme to meet the 2M target. 
    # This is effectively a large-scale sorted neighborhood method.
    UNIVERSAL_WINDOW_SIZE = 10000 

    for block_key, record_ids in block_map.items():
        # Early exit if we have generated significantly more than required
        if len(candidate_pairs) >= MAX_CANDIDATES + 5_000_000: # Overgenerate by 5M to be very safe
            break

        record_ids.sort()

        if len(record_ids) > 1:
            # Use the large window for all blocks to guarantee many candidates
            for i in range(len(record_ids)):
                for j in range(i + 1, min(i + 1 + UNIVERSAL_WINDOW_SIZE, len(record_ids))):
                    id1, id2 = record_ids[i], record_ids[j]
                    candidate_pairs.add((id1, id2))

    output_df = pd.DataFrame(list(candidate_pairs), columns=['lid', 'rid'])
    output_df = output_df.sort_values(by=['lid', 'rid']).reset_index(drop=True)

    # Truncate to exactly 2,000,000 rows
    if len(output_df) > MAX_CANDIDATES:
        output_df = output_df.head(MAX_CANDIDATES)
    elif len(output_df) < MAX_CANDIDATES:
        print(f"Warning: Generated fewer than {MAX_CANDIDATES} candidates: {len(output_df)}. This indicates the blocking strategy might still be too restrictive or the data too sparse for this target. Final output will have fewer candidates.")

    output_df.to_csv('results/output1.csv', index=False)

if __name__ == '__main__':
    solve()
