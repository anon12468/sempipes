import pandas as pd
import re
from collections import defaultdict
import itertools

def clean_text(text):
    if isinstance(text, str):
        text = text.lower()
        text = re.sub(r'[^a-z0-9\s-]', '', text) 
        return text.strip()
    return ""

def get_model_tokens(text):
    return re.findall(r'\b(?:[a-z0-9]*[a-z][a-z0-9]*\d+[a-z0-9]*|[a-z0-9]+\d+[a-z0-9]*|[0-9]+gb|[0-9]+tb|[0-9]+s|v[0-9]+|mk[0-9]+|gen[0-9]+)\b', text)

def get_significant_tokens(text, min_len=3):
    # Exclude common stop words and very short tokens
    stop_words = set(['a', 'an', 'the', 'of', 'and', 'or', 'in', 'on', 'for', 'with', 'new', 'pack', 'set', 'kit'])
    tokens = [token for token in text.split() if len(token) >= min_len and token not in stop_words]
    return tokens

def generate_candidate_pairs(df):
    candidate_pairs = set()
    blocking_keys_brand_name = defaultdict(list)
    blocking_keys_model_token = defaultdict(list)
    blocking_keys_significant_token = defaultdict(list)

    df['cleaned_name'] = df['name'].apply(clean_text)
    df['cleaned_brand'] = df['brand'].apply(clean_text)

    for idx, row in df.iterrows():
        brand_key = row['cleaned_brand']
        name_tokens = row['cleaned_name'].split()
        
        # Strategy 1.1: Brand + first name token
        if brand_key and name_tokens:
            key = f"B1_{brand_key}_{name_tokens[0]}"
            blocking_keys_brand_name[key].append(idx)
        
        # Strategy 1.2: First two name tokens (if no brand or as an additional key)
        if len(name_tokens) >= 2:
            key = f"B2_{name_tokens[0]}_{name_tokens[1]}"
            blocking_keys_brand_name[key].append(idx)
        elif len(name_tokens) == 1:
            key = f"B2_{name_tokens[0]}"
            blocking_keys_brand_name[key].append(idx)

        # Blocking Strategy 2: Model-like tokens
        model_tokens = get_model_tokens(row['cleaned_name'])
        if model_tokens:
            model_key = '_'.join(sorted(list(set(model_tokens))))
            if model_key:
                blocking_keys_model_token[f"M_{model_key}"].append(idx)
                
        # Blocking Strategy 3: Significant individual tokens
        significant_tokens = get_significant_tokens(row['cleaned_name'])
        for token in significant_tokens:
            blocking_keys_significant_token[f"S_{token}"].append(idx)

    # Helper function to process buckets
    def process_buckets(blocking_dict, max_bucket_size=750):
        pairs = set()
        for key, ids in blocking_dict.items():
            if len(ids) > 1 and len(ids) <= max_bucket_size: # Increased bucket size limit
                ids.sort()
                for i in range(len(ids)):
                    for j in range(i + 1, len(ids)):
                        id1_original = df.loc[ids[i], 'id']
                        id2_original = df.loc[ids[j], 'id']
                        if id1_original < id2_original:
                            pairs.add((id1_original, id2_original))
                        else:
                            pairs.add((id2_original, id1_original))
        return pairs

    candidate_pairs.update(process_buckets(blocking_keys_brand_name))
    candidate_pairs.update(process_buckets(blocking_keys_model_token))
    candidate_pairs.update(process_buckets(blocking_keys_significant_token))

    return list(candidate_pairs)

def save_output(X2_candidate_pairs):
    expected_cand_size_X2 = 2000000

    if len(X2_candidate_pairs) > expected_cand_size_X2:
        X2_candidate_pairs = X2_candidate_pairs[:expected_cand_size_X2]
    elif len(X2_candidate_pairs) < expected_cand_size_X2:
        X2_candidate_pairs.extend([(0, 0)] * (expected_cand_size_X2 - len(X2_candidate_pairs)))

    output_df = pd.DataFrame(X2_candidate_pairs, columns=["lid", "rid"])
    output_df.to_csv("results/output2.csv", index=False)

if __name__ == "__main__":
    X2 = pd.read_csv("/Users/USER/Documents/UNI/SS26/SIGMOD_full_data/X2.csv")
    X2_candidate_pairs = generate_candidate_pairs(X2)
    save_output(X2_candidate_pairs)
