import pandas as pd
import numpy as np
import re
from datasketch import MinHash, MinHashLSH
import os
import time
from nltk.stem import PorterStemmer
import heapq  # Import heapq for implementing a min-priority queue

# --- Configuration ---
INPUT_DIR = "/Users/USER/Documents/UNI/WS25/SIGMOD_full_data"
WORKING_DIR = "logs/2-vague-hare-from-eldorado"
X2_PATH = os.path.join(INPUT_DIR, "X2.csv")
Z2_PATH = os.path.join(INPUT_DIR, "Z2.csv")
OUTPUT_DIR = WORKING_DIR
OUTPUT_FILE = os.path.join(OUTPUT_DIR, "output.csv")
TARGET_CANDIDATES = 2_000_000  # Exactly 2,000,000 candidate pairs

# IMPROVEMENT: Increase MIN_PERMUTATIONS for more accurate MinHash signatures and LSH indexing.
# This will lead to more precise Jaccard similarity estimates and potentially better grouping
# of similar items by LSH, thus contributing to higher recall without unbounded memory use.
MIN_PERMUTATIONS = 256  # Previously 128, increased to improve accuracy

LSH_THRESHOLD = 0.01  # This threshold worked well for recall previously.

# Ensure working directory exists
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Initialize Porter Stemmer
stemmer = PorterStemmer()


def preprocess_text(text):
    """
    Cleans, tokenizes, and stems text for shingling.
    Retains single-character tokens based on previous improvements.
    """
    if pd.isna(text):
        return ""
    text = str(text).lower()
    # Retain lowercase alphabets, digits, and spaces.
    text = re.sub(r"[^a-z0-9\s]", "", text)
    tokens = [stemmer.stem(word) for word in text.split()]
    return " ".join(tokens)


def generate_shingles(text):
    """
    Generates a combination of word 1-grams (unigrams) and 2-grams (bigrams) as shingles from a text.
    """
    words = text.split()
    shingles = set(words)  # Add unigrams

    if len(words) > 1:
        # Add bigrams if there are at least two words
        shingles.update(" ".join(words[i : i + 2]) for i in range(len(words) - 1))

    return shingles if shingles else set()


def calculate_recall(true_matches_df, candidate_pairs_df):
    """
    Calculates recall for the generated candidate pairs.
    """
    # Ensure all pairs are sorted (lid, rid) where lid < rid for consistent comparison
    true_pairs = set(
        tuple(sorted((row["lid"], row["rid"])))
        for index, row in true_matches_df.iterrows()
    )
    candidate_pairs = set(
        tuple(sorted((row["lid"], row["rid"])))
        for index, row in candidate_pairs_df.iterrows()
    )

    # Count how many true matches are in the candidate pairs
    true_positives = len(true_pairs.intersection(candidate_pairs))
    total_true_matches = len(true_pairs)

    if total_true_matches == 0:
        return 0.0
    return true_positives / total_true_matches


# --- Main Blocking Logic ---
print("Starting Kaggle Grandmaster solution script...")
script_start_time = time.time()

# 1. Load data
print(f"Loading {X2_PATH}...")
df_X2 = pd.read_csv(X2_PATH)
print(f"Loaded {len(df_X2)} records from X2.csv.")

# 2. Preprocessing
print("Preprocessing text fields and generating shingles...")
# Expand brand mapping for common electronics brands
brand_mapping = {
    "sandisk": "sandisk",
    "sony": "sony",
    "kingston": "kingston",
    "intenso": "intenso",
    "samsung": "samsung",
    "adata": "adata",
    "toshiba": "toshiba",
    "panasonic": "panasonic",
    "hp": "hp",
    "lexar": "lexar",
    "pny": "pny",
    "lg": "lg",
    "corsair": "corsair",
    "micron": "micron",
    "western digital": "western digital",
    "wd": "western digital",
    "gskill": "gskill",
}
# Apply general lowercasing first, then specific mappings for common brands
df_X2["brand_cleaned"] = df_X2["brand"].fillna("").str.lower().str.strip()
df_X2["brand_cleaned"] = df_X2["brand_cleaned"].apply(lambda x: brand_mapping.get(x, x))

# Combine relevant text fields: name, description, and cleaned brand
df_X2["combined_text"] = (
    df_X2["name"].fillna("")
    + " "
    + df_X2["description"].fillna("")
    + " "
    + df_X2["brand_cleaned"]
)
df_X2["preprocessed_text"] = df_X2["combined_text"].apply(preprocess_text)

# Drop records where preprocessing yields empty text (can't form shingles effectively)
initial_len = len(df_X2)
df_X2_filtered = df_X2[df_X2["preprocessed_text"].str.strip().astype(bool)].copy()
print(
    f"Filtered {initial_len - len(df_X2_filtered)} records with empty preprocessed text."
)


# 3. MinHash LSH Blocking
print("Building MinHash signatures and LSH index...")
minhashes = {}

# Process each record to create MinHash signatures
for _, row in df_X2_filtered.iterrows():
    product_id = row["id"]
    shingles = generate_shingles(row["preprocessed_text"])
    if shingles:  # Only create MinHash if there are valid shingles
        m = MinHash(num_perm=MIN_PERMUTATIONS)
        for d in shingles:
            m.update(d.encode("utf8"))
        minhashes[product_id] = m

# Initialize LSH with the specified threshold
lsh = MinHashLSH(threshold=LSH_THRESHOLD, num_perm=MIN_PERMUTATIONS)
print(
    f"Inserting {len(minhashes)} MinHash objects into LSH index with threshold={LSH_THRESHOLD} and num_perm={MIN_PERMUTATIONS}..."
)
for product_id, m in minhashes.items():
    lsh.insert(product_id, m)

# Use a min-priority queue (min-heap) to keep track of top TARGET_CANDIDATES
# We store (jaccard_similarity, lid, rid) tuples. Heap automatically keeps the smallest at the top.
# For efficiency, pairs are identified by a set before being added to heap to prevent redundant Jaccard calculations.
top_candidates_heap = []  # Stores (similarity, lid, rid)
processed_pairs_tracker = (
    set()
)  # Stores (lid, rid) to avoid duplicate processing (and potential duplicate jaccard calculations)

# Iterate over unique IDs that have MinHash signatures, sorted for deterministic processing
all_unique_ids = sorted(list(minhashes.keys()))
total_records_for_query = len(all_unique_ids)
query_start_time = time.time()
report_interval_percent = 5  # Report progress every 5%

print(
    f"Querying LSH to generate candidate pairs with a bounded heap (target: {TARGET_CANDIDATES})..."
)
for i, current_id in enumerate(all_unique_ids):
    if (
        i % (total_records_for_query // (100 / report_interval_percent) + 1) == 0
    ) and i != 0:
        elapsed_time = time.time() - query_start_time
        print(
            f"  Processed {i}/{total_records_for_query} records ({i/total_records_for_query:.1%}). "
            f"Candidates in heap: {len(top_candidates_heap)}. Elapsed: {elapsed_time:.1f}s"
        )

    # Query LSH for items potentially similar to current_id
    if current_id in minhashes:
        results = lsh.query(minhashes[current_id])

        for candidate_id in results:
            if current_id == candidate_id:  # Self-pair exclusion
                continue

            # Ensure consistent order (lid < rid) for pairs
            lid, rid = sorted((current_id, candidate_id))
            pair = (lid, rid)

            if pair not in processed_pairs_tracker:
                processed_pairs_tracker.add(pair)
                # Calculate the precise Jaccard similarity directly from MinHash objects.
                # Only calculate if we haven't already and if there's potential to add to heap.
                jaccard_similarity = minhashes[lid].jaccard(minhashes[rid])

                if len(top_candidates_heap) < TARGET_CANDIDATES:
                    heapq.heappush(top_candidates_heap, (jaccard_similarity, lid, rid))
                else:
                    # If the heap is full, compare with the smallest similarity (root of min-heap)
                    smallest_sim_in_heap, _, _ = top_candidates_heap[0]
                    if jaccard_similarity > smallest_sim_in_heap:
                        # Replace the smallest with the new, higher similarity pair
                        heapq.heapreplace(
                            top_candidates_heap, (jaccard_similarity, lid, rid)
                        )

print(f"Final candidate pairs collected in heap: {len(top_candidates_heap)}.")

# 4. Filter and select exactly TARGET_CANDIDATES
# Extract candidates from the heap. Heap is a min-heap, so for descending similarity,
# we need to sort it (or repeatedly pop) to get the top N. Sorting is fine here since
# top_candidates_heap is capped at TARGET_CANDIDATES (2M items max), making it feasible.
print(f"Preparing output: Sorting top {len(top_candidates_heap)} candidates...")
# Sort heap items by similarity (descending)
final_candidates_sorted = sorted(top_candidates_heap, key=lambda x: x[0], reverse=True)

# Select the required number of pairs (if fewer are found, it's explicitly allowed for sample data)
final_candidates_tuples = [
    (lid, rid) for _, lid, rid in final_candidates_sorted[:TARGET_CANDIDATES]
]

final_candidates_df = pd.DataFrame(final_candidates_tuples, columns=["lid", "rid"])

# The output only requires 'lid' and 'rid', ensure format is strictly enforced.
# lid < rid and no duplicates are guaranteed by how pairs are canonicalized and processed.
output_df = final_candidates_df[["lid", "rid"]]
# A defensive drop_duplicates to handle any edge cases, though not strictly needed for sorted pairs.
output_df.drop_duplicates(inplace=True)

# Ensure exact TARGET_CANDIDATES output if possible.
if len(output_df) > TARGET_CANDIDATES:
    print(
        f"Truncating {len(output_df)} candidates to exactly {TARGET_CANDIDATES} as per requirement."
    )
    output_df = output_df.head(TARGET_CANDIDATES)
elif len(output_df) < TARGET_CANDIDATES:
    print(
        f"Warning: Found only {len(output_df)} unique candidate pairs, which is less than {TARGET_CANDIDATES}."
    )
    print(
        "This indicates that for the *sample* data, a sufficient number of distinct, high-similarity pairs "
        "could not be found with current LSH parameters. On the full dataset, this approach is "
        "designed to generate and select up to 2M pairs."
    )

# Save output to the specified path
print(f"Saving {len(output_df)} candidate pairs to {OUTPUT_FILE}...")
output_df.to_csv(OUTPUT_FILE, index=False)
print("Output file saved successfully.")


# 5. Evaluation (using Z2.csv for recall, this must NOT be used for candidate generation)
print("Loading ground truth (Z2.csv) for evaluation...")
df_Z2 = pd.read_csv(Z2_PATH)
recall = calculate_recall(df_Z2, output_df)
print(f"Recall: {recall:.4f}")

total_script_time = time.time() - script_start_time
print(f"Total script execution time: {total_script_time:.1f} seconds.")
