## Technical Report: Entity Resolution Blocking with MinHash LSH

### Introduction

This report details the development of an entity resolution blocking solution for the X2 dataset, focusing on identifying duplicate product records. The primary goal was to generate exactly 2,000,000 candidate pairs, prioritizing recall while adhering to strict feasibility constraints for a dataset of approximately 2 million records. The solution employs MinHash Locality Sensitive Hashing (LSH) for efficient candidate generation, coupled with robust memory management techniques to prevent scalability issues.

### Preprocessing

Text preprocessing was crucial for creating effective shingles for MinHash. The evolution of the preprocessing steps is as follows:

1.  **Initial Cleaning and Tokenization**: Text fields (`name`, `description`, and a cleaned `brand`) were

Runtime: 2774 seconds