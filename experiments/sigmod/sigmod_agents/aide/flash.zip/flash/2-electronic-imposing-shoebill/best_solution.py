import os
import pandas as pd
import numpy as np
import re
import itertools
from collections import defaultdict
from tqdm import tqdm

# --- Configuration ---
INPUT_DIR = "/Users/USER/Documents/UNI/WS25/SIGMOD_full_data"
WORKING_DIR = "logs/2-electronic-imposing-shoebill"
X2_PATH = os.path.join(INPUT_DIR, "X2.csv")
Z2_PATH = os.path.join(INPUT_DIR, "Z2.csv")
OUTPUT_PATH = os.path.join(WORKING_DIR, "output.csv")

# Thresholds for blocking strategy (crucial for feasibility and performance)
# If block size <= this, use itertools.combinations (O(k^2), safe for small k)
MAX_BLOCK_SIZE_FOR_COMBINATIONS = 100
# If block size > this, use Sorted Neighborhood Method (SNM) with this window size (O(k*window), scalable)
SNM_WINDOW_SIZE = 20  # IMPROVEMENT: Increased from 15 to 20 to find more true matches among similar products

# The target for a full dataset, not necessarily achieved on a small sample like X2.csv (~2k records)
# On X2.csv (1993 records), the maximum possible unique pairs is ~1.98M.
# We prioritize scalable methods over forcing exactly 2M pairs on sample data, which would imply generating near all possible pairs.
TARGET_CANDIDATE_COUNT_FOR_FULL_DATASET = 2_000_000

# --- Helper Functions ---


def clean_text(text):
    """
    Cleans and tokenizes text for blocking.
    Converts to lowercase, removes non-alphanumeric, removes common stopwords/product terms.
    """
    if pd.isna(text):
        return []

    text = str(text).lower()
    # Remove special characters, keep alphanumeric and spaces
    text = re.sub(r"[^a-z0-9\s]+", " ", text)
    # Remove extra spaces
    text = re.sub(r"\s+", " ", text).strip()

    # Custom stopwords/common product terms that do not add much discriminative power
    stop_words = {
        "us",
        "new",
        "official",
        "device",
        "module",
        "kit",
        "product",
        "compatible",
        "black",
        "white",
        "pc",
        "laptop",
        "desktop",
        "go",
        "for",
        "c",
        "g",
        "r",
        "x",
    }

    # Ensure to only filter tokens that are actual stopwords and are long enough,
    # and not remove important single-letter identifiers unless explicitly listed and unwanted.
    tokens = [
        token for token in text.split() if token not in stop_words and len(token) > 1
    ]
    return tokens


def normalize_brand(brand):
    """Normalizes brand names for consistent blocking keys."""
    if pd.isna(brand):
        return ""
    brand = str(brand).lower()
    brand = re.sub(r"[^a-z0-9]+", "", brand)  # Remove non-alphanumeric

    brand_map = {
        "sandiskcorp": "sandisk",
        "sandsk": "sandisk",
        "sanddisc": "sandisk",
        "kngston": "kingston",
        "kngstone": "kingston",
        "kingson": "kingston",
        "kingstron": "kingston",
        "samsang": "samsung",
        "samsuing": "samsung",
        "samsungltd": "samsung",
        "samgsung": "samsung",
        "transend": "transcend",
        "transcent": "transcend",
        "transcnd": "transcend",
        "toshib": "toshiba",
        "toshibacorp": "toshiba",
        "toshibaamerica": "toshiba",
        "lexxar": "lexar",
        "lexxer": "lexar",
        "lexarkmedia": "lexar",
        "vgenindonesia": "vgen",
        "vgengenie": "vgen",
        "corsaair": "corsair",
        "corsiar": "corsair",
        "corpsair": "corsair",
        "westerndigital": "westerndigital",
        "wd": "westerndigital",
        "wde": "westerndigital",
        "hpinc": "hp",
        "hpmemory": "hp",
        "hewlettpackard": "hp",
        "integralmemory": "integral",
        "integralltd": "integral",
        "verbatimm": "verbatim",
        "verbatum": "verbatim",
        "teamgroupinc": "teamgroup",
        "team_group": "teamgroup",
        "kioxiallc": "kioxia",
        "kioxiacorp": "kioxia",
        "adata_technology": "adata",
        "adatech": "adata",
        "crucialinc": "crucial",
        "crucialmemory": "crucial",
        "siliconpowerinc": "siliconpower",
        "sp_siliconpower": "siliconpower",
        "pnytech": "pny",
        "pnny": "pny",
        "netac_group": "netac",
        "netactech": "netac",
        "kingmax_tech": "kingmax",
        "kingmaxgroup": "kingmax",
        "emtec_group": "emtec",
        "emtectech": "emtec",
        "gigastonecorp": "gigastone",
        "giga_stone": "gigastone",
        "sonyjapan": "sony",
        "sonyjap": "sony",
        "philipselec": "philips",
        "philps": "philips",
        "panasonicta": "panasonic",
        "panasoniccorp": "panasonic",
        "microsd": "genericstorage",
        "no_brand": "genericstorage",
        "nobrand": "genericstorage",
        "unbranded": "genericstorage",
        "pendrive": "genericstorage",
        "flashdrive": "genericstorage",
        "usbstorage": "genericstorage",
        "memorycard": "genericstorage",
        "gostore": "genericstorage",
        "china": "genericstorage",
        "sandisk": "sandisk",
        "sony": "sony",
        "kingston": "kingston",
        "transcend": "transcend",
        "samsung": "samsung",
        "toshiba": "toshiba",
        "lexar": "lexar",
        "vgen": "vgen",
        "corsair": "corsair",
        "pny": "pny",
        "hp": "hp",
        "integral": "integral",
        "intenso": "intenso",
        "adata": "adata",
        "verbatim": "verbatim",
        "teamgroup": "teamgroup",
        "kioxia": "kioxia",
        "crucial": "crucial",
        "siliconpower": "siliconpower",
        "netac": "netac",
        "kingmax": "kingmax",
        "emtec": "emtec",
        "gigastone": "gigastone",
        "goodram": "goodram",
        "philips": "philips",
        "panasonic": "panasonic",
        "genericstorage": "genericstorage",
    }
    return brand_map.get(brand, brand)


def extract_model_numbers(tokens):
    """
    Extracts alphanumeric sequences that might be model numbers.
    Relaxes length constraint for purely numeric tokens (>=2) and mixed alphanumeric tokens (>=2).
    """
    model_numbers = []
    for token in tokens:
        if (
            re.search(r"[a-z]", token)
            and re.search(r"[0-9]", token)
            and len(token) >= 2
        ) or (token.isdigit() and len(token) >= 2):
            model_numbers.append(token)
    return model_numbers


def extract_capacity_keys(tokens):
    """
    Extracts and normalizes storage capacity information (e.g., 16gb, 2tb).
    This function processes the cleaned tokens to find patterns like "NUMBER UNIT" or "NUMBERUNIT".
    """
    capacity_keys = set()
    capacity_units = {
        "gb",
        "mb",
        "tb",
        "g",
        "m",
        "t",
    }  # Common units, 'g', 'm', 't' as shorthand
    unit_mapping = {"g": "gb", "m": "mb", "t": "tb"}

    # Process tokens to identify number-unit combinations
    for i in range(len(tokens)):
        token = tokens[i]

        # Case 1: "NUMBERUNIT" pattern (e.g., "16gb", "128mb")
        # Use regex to find number followed immediately by a unit
        match = re.fullmatch(
            r"(\d+)(\s*)(" + "|".join(re.escape(u) for u in capacity_units) + r")$",
            token,
            re.IGNORECASE,
        )
        if match:
            value = int(match.group(1))
            unit_str = match.group(3).lower()
            normalized_unit = unit_mapping.get(
                unit_str, unit_str
            )  # Normalize 'g' to 'gb' etc.
            capacity_keys.add(f"capacity_{value}{normalized_unit}")
            continue

        # Case 2: "NUMBER UNIT" pattern (e.g., "16 gb", "128 mb")
        if token.isdigit() and i + 1 < len(tokens):
            next_token = tokens[i + 1].lower()
            if next_token in capacity_units:
                value = int(token)
                normalized_unit = unit_mapping.get(next_token, next_token)
                capacity_keys.add(f"capacity_{value}{normalized_unit}")
                # We consume both tokens if a pair is found.
                # The outer loop ensures each token is processed only once, but we can't 'skip' next_token here
                # because the for loop handles its own index. Set logic naturally handles duplicates.
    return list(capacity_keys)


# --- Main Solution ---

print("Starting blocking process...")

# 0. Load Data
df = pd.read_csv(X2_PATH)
df.rename(columns={"id": "record_id"}, inplace=True)

df_cleaned = df[["record_id"]].copy()

# Preprocessing for blocking and SNM sorting
tqdm.pandas(desc="Cleaning text (name)")
df_cleaned["cleaned_name_tokens"] = df["name"].progress_apply(clean_text)
tqdm.pandas(desc="Cleaning text (description)")
df_cleaned["cleaned_description_tokens"] = df["description"].progress_apply(clean_text)
tqdm.pandas(desc="Normalizing brand")
df_cleaned["normalized_brand"] = df["brand"].progress_apply(normalize_brand)

# Combine relevant tokens for full-text sorting for SNM within large blocks
df_cleaned["full_text_for_sorting"] = df_cleaned.apply(
    lambda row: " ".join(
        [row["normalized_brand"]]
        + row["cleaned_name_tokens"]
        + row["cleaned_description_tokens"]
    ),
    axis=1,
)
# Make a map for quick lookup during SNM sorting
record_id_to_full_text = df_cleaned.set_index("record_id")[
    "full_text_for_sorting"
].to_dict()


# 1. Multi-key Blocking
inverted_index = defaultdict(list)
total_records = len(df_cleaned)

print("Generating blocking keys and populating inverted index...")
for _, row in tqdm(
    df_cleaned.iterrows(), total=total_records, desc="Populating inverted index"
):
    record_id = row["record_id"]

    # Key Type 1: Brand + Name prefix (or first informative token)
    # Filter out genericstorage from strong brand block to avoid excessively large blocks with low discriminative power
    if row["normalized_brand"] and row["normalized_brand"] != "genericstorage":
        brand_key = row["normalized_brand"]
        # Strong block on normalized brand
        inverted_index[f"brand_{brand_key}"].append(record_id)

        # Add brand with first name token (if available and discriminative)
        if row["cleaned_name_tokens"] and len(row["cleaned_name_tokens"][0]) > 2:
            inverted_index[
                f'brand_name_prefix_{brand_key}_{row["cleaned_name_tokens"][0]}'
            ].append(record_id)

    # Key Type 2: Important N-grams from Name
    # Each significant token contributes to a block
    name_tokens = row["cleaned_name_tokens"]
    if name_tokens:
        for token in name_tokens:
            # Condition for 'name_token' blocking to include 3-letter discriminative acronyms.
            if len(token) > 2:
                inverted_index[f"name_token_{token}"].append(record_id)

        # Consider bigrams for more specific matches
        for i in range(len(name_tokens) - 1):
            # Sorted bigram for canonical key (e.g., '64gb_kingston' not 'kingston_64gb')
            bigram = "_".join(sorted([name_tokens[i], name_tokens[i + 1]]))
            inverted_index[f"name_bigram_{bigram}"].append(record_id)

    # Key Type 3: Model Numbers (highly discriminative)
    all_cleaned_tokens = row["cleaned_name_tokens"] + row["cleaned_description_tokens"]
    model_numbers = extract_model_numbers(all_cleaned_tokens)
    for model_num in model_numbers:
        inverted_index[f"model_num_{model_num}"].append(record_id)

    # Key Type 4: Storage Capacities
    capacity_keys = extract_capacity_keys(all_cleaned_tokens)
    for capacity_key in capacity_keys:
        inverted_index[capacity_key].append(record_id)


# 2. Candidate Generation (with safeguards for large blocks)
print("Generating candidate pairs...")
candidate_pairs = set()

total_blocks = len(inverted_index)
pbar_blocks = tqdm(total=total_blocks, desc="Processing blocks for candidate pairs")

for block_key, block_ids_raw in inverted_index.items():
    block_ids = sorted(
        list(set(block_ids_raw))
    )  # Ensure unique IDs and sorted for canonical order

    if len(block_ids) <= MAX_BLOCK_SIZE_FOR_COMBINATIONS:
        # For small blocks, O(k^2) combinations is acceptable and thorough
        for id1, id2 in itertools.combinations(block_ids, 2):
            candidate_pairs.add(frozenset({id1, id2}))
    else:
        # For large blocks, use Sorted Neighborhood Method (SNM) to avoid O(k^2)
        # Sort records within the block by their comprehensive cleaned text
        block_ids.sort(key=lambda x: record_id_to_full_text.get(x, ""))

        for i in range(len(block_ids)):
            # Compare each item with items in its forward window
            for j in range(i + 1, min(i + 1 + SNM_WINDOW_SIZE, len(block_ids))):
                id1, id2 = block_ids[i], block_ids[j]
                candidate_pairs.add(frozenset({id1, id2}))

    pbar_blocks.update(1)

pbar_blocks.close()
print(f"Generated {len(candidate_pairs)} raw candidate pairs.")

# 3. Format Output for submission
output_df_rows = []
for p in tqdm(candidate_pairs, desc="Formatting and finalizing candidate pairs"):
    # Convert frozenset to tuple (left_instance_id, right_instance_id) with left < right
    id1, id2 = sorted(list(p))
    output_df_rows.append({"left_instance_id": id1, "right_instance_id": id2})

output_df = pd.DataFrame(output_df_rows)

# Critical: Output exactly 2,000,000 candidate pairs for the full dataset.
# For sample data, we prioritize recall; if generated count is below target, we keep all.
if len(output_df) > TARGET_CANDIDATE_COUNT_FOR_FULL_DATASET:
    print(
        f"Truncating {len(output_df)} candidates to {TARGET_CANDIDATE_COUNT_FOR_FULL_DATASET} for output."
    )
    # Sample randomly to maintain an unbiased selection of candidates
    output_df = output_df.sample(
        n=TARGET_CANDIDATE_COUNT_FOR_FULL_DATASET, random_state=42
    ).reset_index(drop=True)
elif (
    len(output_df) < TARGET_CANDIDATE_COUNT_FOR_FULL_DATASET and len(df) > 5000
):  # Heuristic for distinguishing sample from full dataset
    print(
        f"WARNING: Generated {len(output_df)} candidates, which is less than the {TARGET_CANDIDATE_COUNT_FOR_FULL_DATASET} target for the full dataset. For a small sample like this, it is expected and indicates adherence to scalability rules. However, on the full dataset, additional strategies (e.g., lower blocking stringency for small portion) might be needed to hit target count while preserving high recall."
    )

output_df.to_csv(OUTPUT_PATH, index=False)
print(f"Final outputted {len(output_df)} candidate pairs to {OUTPUT_PATH}")

# 4. Evaluate Recall against ground truth (Z2.csv)
ground_truth_df = pd.read_csv(Z2_PATH)
true_matches = set()
for _, row in ground_truth_df.iterrows():
    # Ensure canonical form (frozenset of sorted IDs) for comparison
    true_matches.add(frozenset({row["lid"], row["rid"]}))

print(f"Number of true matches in Z2.csv: {len(true_matches)}")

# Re-form common_matches using the (potentially truncated) output_df pairs for accurate recall
final_output_pairs = set()
for _, row in output_df.iterrows():
    final_output_pairs.add(
        frozenset({row["left_instance_id"], row["right_instance_id"]})
    )


common_matches = final_output_pairs.intersection(true_matches)
recall = len(common_matches) / len(true_matches) if len(true_matches) > 0 else 0

print(f"Number of common matches found: {len(common_matches)}")
print(f"Recall: {recall:.4f}")
