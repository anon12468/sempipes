## Technical Report: Entity Resolution Blocking for Electronic Products

### 1. Introduction

This report details the development of a blocking strategy for entity resolution on a large dataset of electronic product records (X2.csv). The primary objective was to generate a highly accurate set of candidate pairs for potential duplicates, while strictly adhering to crucial scalability constraints. The solution aims to output exactly 2,000,000 candidate pairs on the full dataset (approximately 2 million records) within a 30-minute time limit, without resorting to `O(k^2)` operations within any blocking bucket. The success metric is maximized recall against a ground truth (Z2.csv).

The core approach involves a multi-key blocking method combined with a hybrid candidate generation strategy that adapts to block size