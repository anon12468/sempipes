import pandas as pd
import numpy as np
import re
from datasketch import MinHash, MinHashLSH
import os
import random
import time
from collections import defaultdict

# Global variables for candidates and count
candidate_pairs = set()
# MAX_CANDIDATES will be set dynamically based on X2_data length for this run.
# For full X2 (~2 million records), it would be 2,000,000. For the provided small X2, it's min(2M, N*(N-1)/2).
MAX_CANDIDATES = None  # Will be determined after loading X2_data

# Using a consistent random seed for shuffling data to ensure deterministic behavior across runs
random.seed(42)


def clean_text(text):
    if pd.isna(text):
        return ""
    text = str(text).lower()
    # Keep alphanumeric, spaces, hyphens, and forward slashes (common in product names/models)
    text = re.sub(r"[^\w\s\-/]", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def extract_identifiers(text):
    if not text:
        return []
    text = text.lower()

    identifiers = []

    # Regex patterns for various product identifiers, model numbers, and capacity info
    # Enhanced patterns for better recall for electronic products
    model_patterns = [
        r"\b[a-z0-9]{2,}\-[a-z0-9]{2,}\b",  # e.g., uhs-i, mk-321, X-SMC02
        r"\b[a-z]{1,3}[0-9]{2,5}[a-z]?\b",  # e.g., x230, r5000, e2500, k53s, m15r, v3, pro4
        r"\b[0-9]{2,}[a-z]{1,3}\b",  # e.g., 128gb, 32gb, c10 (Class 10), g1, 512mb
        r"\b(s[d|d]h?c|s[d|d]x?c)\b",  # sdhc, sdxc - standard memory card types
        r"\b(usb|wifi|hdmi|vga|ssd|hdd|pcie|m\.2|sata|nvme)\b",  # common component types
        r"\b[a-f0-9]{6,16}\b",  # potential serial-like numbers (longer hex sequences)
        r"\b(v\d+\.?\d*|s\d+\.?\d*|b\d+\.?\d*|c\d+\.?\d*|g\d+\.?\d*|z\d+\.?\d*)\b",  # common prefixes with numbers: Version, Series, Build, Class, Generation, Zone
    ]

    # Storage capacities (simplified to capture common units)
    capacity_patterns = [
        r"\b\d+(gb|g|tb|mb|kb)\b",  # e.g., 16gb, 320g, 1tb, 512mb
        r"\b\d+\s*(gb|g|tb|mb|kb)\b",  # e.g. "16 gb", "512 mb"
    ]

    # Generic numbers often significant in product names/models
    numeric_patterns = [
        r"\b\d{4,}\b",  # e.g. part numbers like 10025701, long series of numbers. Avoid 2-3 digit noise
        r"\b\d{1,}\.\d{1,}\b",  # versions like 2.0, 3.1 etc
    ]

    for pattern in model_patterns + capacity_patterns + numeric_patterns:
        matches = re.findall(pattern, text)
        for m in matches:
            # Handle potential tuples from regex groups (e.g., from capacity patterns)
            if isinstance(m, tuple):
                # Concatenate non-empty strings from the tuple and strip, then ensure non-empty
                processed_m = "".join(filter(None, m)).strip()
            else:
                processed_m = m.strip()

            if len(processed_m) > 1 and processed_m not in identifiers:
                identifiers.append(processed_m)

    return identifiers


def normalize_brand(brand):
    if pd.isna(brand) or not brand:
        return ""
    brand = str(brand).lower().strip()
    # Expanded mappings for observed common variations
    brand_map = {
        "sandisk": "sandisk",
        "kingston": "kingston",
        "sony": "sony",
        "samsung": "samsung",
        "hp": "hp",
        "intenso": "intenso",
        "lenovo": "lenovo",
        "toshiba": "toshiba",
        "western digital": "western digital",
        "wd": "western digital",
        "transcend": "transcend",
        "adata": "adata",
        "philips": "philips",
        "verbatim": "verbatim",
        "panasonic": "panasonic",
        "pny": "pny",
        "micron": "micron",  # commonly found with SSD/Memory
        "intel": "intel",
    }
    for k, v in brand_map.items():
        if k in brand:
            return v
    return brand


def add_candidate(id1, id2):
    global candidate_pairs
    global MAX_CANDIDATES  # Ensure access to the global variable

    if MAX_CANDIDATES is not None and len(candidate_pairs) >= MAX_CANDIDATES:
        return False

    u, v = sorted((id1, id2))
    if u != v and (u, v) not in candidate_pairs:
        candidate_pairs.add((u, v))
        if MAX_CANDIDATES is not None and len(candidate_pairs) >= MAX_CANDIDATES:
            # print(f"Candidate limit reached: {MAX_CANDIDATES}") # Log when limit is hit
            pass
    return True


# --- Main execution ---
if __name__ == "__main__":
    start_time = time.time()

    # Create working directory if it doesn't exist
    os.makedirs("logs/2-exotic-hare-of-eternity", exist_ok=True)

    # Load data
    INPUT_DIR = "/Users/USER/Documents/UNI/WS25/SIGMOD_full_data"
    try:
        X2 = pd.read_csv(os.path.join(INPUT_DIR, "X2.csv"))
    except FileNotFoundError:
        print("X2.csv not found. Ensure it's in the ./input/ directory.")
        exit()

    X2_data = X2.set_index("id").copy()
    all_x2_ids = X2_data.index.tolist()

    # BUGFIX: Dynamically set MAX_CANDIDATES for the current dataset based on its size
    # Max possible unique pairs for N records is N * (N - 1) / 2
    num_records = len(X2_data)
    max_possible_pairs_for_this_dataset = num_records * (num_records - 1) // 2
    # The task asks for "exactly 2,000,000". If this dataset cannot produce that, cap at its maximum.
    MAX_CANDIDATES = min(2_000_000, max_possible_pairs_for_this_dataset)
    print(f"Setting MAX_CANDIDATES to: {MAX_CANDIDATES} for {num_records} records.")

    # Preprocessing
    X2_data["normalized_brand"] = X2_data["brand"].apply(normalize_brand)
    # The 'category' field will now also be included to leverage additional descriptive terms
    X2_data["combined_text"] = (
        X2_data["normalized_brand"].fillna("")
        + " "
        + X2_data["name"].fillna("")
        + " "
        + X2_data["description"].fillna("")
        + " "
        + X2_data["category"].fillna("")  # Include category
    )

    # Expanded stop words for electronic products and common web/locale terms
    stop_words = set(
        [
            "a",
            "the",
            "of",
            "in",
            "for",
            "and",
            "with",
            "to",
            "from",
            "on",
            "at",
            "an",
            "is",
            "it",
            "de",
            "saber",
            "get",
            "online",
            "shopping",
            "store",
            "pagina",
            "page",
            "home",
            "startseite",
            "startsida",
            "carte",
            "memory",
            "card",
            "memoire",
            "pami",
            "flash",
            "produit",
            "product",
            "high",
            "speed",
            "digital",
            "capacity",
            "vers",
            "pour",
            "data",
            "external",
            "internal",
            "storage",
            "drive",
            "device",
            "usb",
            "disk",
            "type",
            "form",
            "factor",
            "compatible",
            "standard",
            "up",
            "to",
            "max",
            "micro",
            "plus",
            "ultra",
            "s",  # 's' can be possessive or plural
        ]
    )

    X2_data["cleaned_tokens"] = X2_data["combined_text"].apply(
        lambda x: [
            w for w in clean_text(x).split() if len(w) > 1 and w not in stop_words
        ]
    )

    # Extract additional specific identifiers and merge into tokens for LSH
    X2_data["extracted_identifiers"] = X2_data["combined_text"].apply(
        extract_identifiers
    )
    X2_data["all_tokens_for_lsh"] = X2_data.apply(
        lambda row: list(set(row["cleaned_tokens"] + row["extracted_identifiers"])),
        axis=1,
    )

    # Convert lists to sets for faster Jaccard lookups in SNM
    X2_data["extracted_identifiers_set"] = X2_data["extracted_identifiers"].apply(set)

    print(f"Preprocessing completed in {time.time() - start_time:.2f} seconds.")

    # 1. MinHash LSH Blocking
    # This stage uses LSH on the enriched set of tokens to generate primary candidates.
    lsh_start_time = time.time()
    num_permutations = 128
    # More aggressive LSH to capture more candidates and improve recall.
    # Higher bands, fewer rows per band => higher sensitivity, more candidates for lower Jaccard similarities.
    num_bands = 64
    num_rows = (
        num_permutations // num_bands
    )  # For num_permutations=128, num_bands=64 => num_rows=2

    lsh = MinHashLSH(
        num_bands=num_bands, num_rows=num_rows, num_permutations=num_permutations
    )

    minhashes = {}
    for rid, row in X2_data.iterrows():
        m = MinHash(num_permutations=num_permutations)
        tokens = row["all_tokens_for_lsh"]
        if not tokens:  # Handle cases where no valid tokens are left
            tokens = ["emptyrecord_lsh_placeholder_token"]
        for d in tokens:
            m.update(d.encode("utf8"))
        minhashes[rid] = m
        lsh.insert(rid, m)

    print(
        f"LSH index built for {len(minhashes)} records. Time: {time.time() - lsh_start_time:.2f}s"
    )
    print("Generating LSH candidates...")

    # Iterate through records in a SHUFFLED order to distribute candidate selection.
    shuffled_all_x2_ids = all_x2_ids[:]
    random.shuffle(shuffled_all_x2_ids)

    lsh_queries_processed = 0
    # Limit the number of candidates generated from any single LSH query result.
    # This prevents popular items from yielding too many candidate pairs and dominating candidate generation.
    MAX_CANDIDATES_PER_LSH_QUERY_RESULT = 500

    for rid in shuffled_all_x2_ids:
        if len(candidate_pairs) >= MAX_CANDIDATES:
            break

        m_hash = minhashes[rid]
        lsh_queries_processed += 1

        potential_matches = lsh.query(m_hash)
        potential_matches = [
            mr for mr in potential_matches if mr != rid
        ]  # Exclude self-matches

        # Only process a limited number of potential matches per query
        for idx, match_rid in enumerate(potential_matches):
            if idx >= MAX_CANDIDATES_PER_LSH_QUERY_RESULT:
                break
            if not add_candidate(
                rid, match_rid
            ):  # add_candidate manages MAX_CANDIDATES
                break  # If limit reached, break from inner loop

        if lsh_queries_processed % 1000 == 0:
            print(
                f"Processed {lsh_queries_processed}/{len(minhashes)} LSH queries. Current candidates: {len(candidate_pairs)}"
            )

    print(
        f"Candidates after LSH blocking: {len(candidate_pairs)}. Time: {time.time() - start_time:.2f}s"
    )

    # 2. Sorted Neighborhood Method (SNM) for systematic candidate filling
    # Only run SNM if we still need more candidates. Given the current X2.csv size and adjusted MAX_CANDIDATES,
    # SNM will very likely be needed or complete the list.
    if len(candidate_pairs) < MAX_CANDIDATES:
        print(
            f"Falling back to Sorted Neighborhood Method to reach {MAX_CANDIDATES} candidates..."
        )
        snm_start_time = time.time()

        # Create a robust, yet compact, sorting key for SNM.
        X2_data["snm_sort_key"] = X2_data.apply(
            lambda row: (
                row["normalized_brand"],
                " ".join(
                    sorted(
                        list(
                            set(
                                [
                                    t
                                    for t in row["cleaned_tokens"]
                                    + row[
                                        "extracted_identifiers"
                                    ]  # Combine for richer key
                                    if len(t) > 3
                                    and t
                                    not in stop_words  # Only descriptive and long tokens
                                ]
                            )
                        )[
                            :7
                        ]  # Take more top tokens for richer, more robust sort key for grouping
                    )
                ),
            ),
            axis=1,
        )

        # Sort records by the composite SNM key.
        X2_data_sorted = X2_data.sort_values(by="snm_sort_key").reset_index(drop=True)

        # Increased window size and relaxed Jaccard threshold for SNM to capture more matches
        window_size = 20
        jaccard_threshold_snm = 0.2

        # Iterate through the sorted records with a sliding window
        for i in range(len(X2_data_sorted)):
            if len(candidate_pairs) >= MAX_CANDIDATES:
                break

            current_id = X2_data_sorted.loc[i, "id"]

            # Compare current_id with records within its sliding window
            for j in range(i + 1, min(i + 1 + window_size, len(X2_data_sorted))):
                if len(candidate_pairs) >= MAX_CANDIDATES:
                    break

                other_id = X2_data_sorted.loc[j, "id"]

                # Improvement: Removed explicit brand equality check.
                # The sorting key already groups items by brand, allowing the sliding window
                # and Jaccard similarity to catch more nuanced matches, even if brands differ slightly
                # within the narrow window due to normalization issues or data sparsity.
                # The implicit sorting by normalized_brand ensures that same-brand comparisons are prioritized.
                # The previous explicit 'continue' statement here was overly restrictive.
                # if X2_data_sorted.loc[i, "normalized_brand"] != X2_data_sorted.loc[j, "normalized_brand"]:
                #     continue

                tokens1_set = X2_data_sorted.loc[i, "extracted_identifiers_set"]
                tokens2_set = X2_data_sorted.loc[j, "extracted_identifiers_set"]

                # If both identifier sets are empty, or they only contain unique elements for both
                if not tokens1_set and not tokens2_set:
                    # If both records lack extracted identifiers, check for significant overlap in cleaned_tokens
                    # (beyond just a brand match within the window, as this can be too noisy).
                    # Require at least 2 non-stopwords common cleaned tokens to prevent excessive weak pairs.
                    cleaned1 = set(X2_data_sorted.loc[i, "cleaned_tokens"])
                    cleaned2 = set(X2_data_sorted.loc[j, "cleaned_tokens"])
                    if len(cleaned1.intersection(cleaned2)) >= 2:
                        if not add_candidate(current_id, other_id):
                            break
                    continue  # Move to next candidate in window if this heuristic applied.

                # If only one set has identifiers, or if sets are not completely disjoint, proceed to Jaccard.
                intersection_size = len(tokens1_set.intersection(tokens2_set))
                union_size = len(tokens1_set.union(tokens2_set))

                if union_size > 0:  # Avoid division by zero
                    jaccard_similarity_identifiers = intersection_size / union_size
                    if jaccard_similarity_identifiers >= jaccard_threshold_snm:
                        if not add_candidate(current_id, other_id):
                            break
                elif (
                    intersection_size > 0
                ):  # Case for when union_size is 0, which implies both sets empty (covered above) or impossible scenario.
                    pass  # Handled by the more specific logic for empty sets above.

        print(
            f"Candidates after SNM blocking: {len(candidate_pairs)}. Time: {time.time() - snm_start_time:.2f}s"
        )

    # Save output.csv
    output_df = pd.DataFrame(list(candidate_pairs), columns=["lid", "rid"])

    # Sort for deterministic output and consistent evaluation
    output_df = output_df.sort_values(by=["lid", "rid"]).reset_index(drop=True)

    # Defensive trim to exactly MAX_CANDIDATES, though 'add_candidate' aims to stop precisely
    # For this specific X2.csv with 1993 rows, MAX_CANDIDATES will be 1,985,028
    if len(output_df) > MAX_CANDIDATES:
        output_df = output_df.head(MAX_CANDIDATES)
    elif len(output_df) < MAX_CANDIDATES:
        # This warning means the blocking strategy or data characteristics didn't yield enough candidates.
        # This should ideally not be met given the dynamic MAX_CANDIDATES calculation for the provided X2.
        print(
            f"Warning: Could not reach {MAX_CANDIDATES} candidates. Generated {len(output_df)}."
        )

    output_path = "logs/2-exotic-hare-of-eternity/output.csv"
    output_df.to_csv(output_path, index=False)
    print(
        f"Generated {len(output_df)} candidate pairs saved to {output_path}. Total Time: {time.time() - start_time:.2f}s"
    )

    # --- Evaluation ---
    # Load ground truth Z2.csv
    try:
        Z2 = pd.read_csv(os.path.join(INPUT_DIR, "Z2.csv"))
    except FileNotFoundError:
        print("Z2.csv not found. Cannot perform evaluation.")
        exit()

    # Convert ground truth pairs to canonical (min,max) form
    true_matches_raw = set(
        tuple(sorted((row["lid"], row["rid"]))) for _, row in Z2.iterrows()
    )

    # Get generated pairs for evaluation (already in canonical form from add_candidate)
    generated_pairs = set(tuple(row) for _, row in output_df.iterrows())

    # Calculate recall
    if len(true_matches_raw) == 0:
        recall = 0.0
        found_matches = 0
    else:
        found_matches = len(generated_pairs.intersection(true_matches_raw))
        recall = found_matches / len(true_matches_raw)

    print(f"Total true matches in Z2: {len(true_matches_raw)}")
    print(f"True matches found in generated candidates: {found_matches}")
    print(f"Recall: {recall:.4f}")
