## Technical Report: Entity Resolution Blocking

### Introduction

This report details the development of an entity resolution blocking solution for the `X2.csv` dataset, focusing on electronic product deduplication. The primary objective was to generate exactly 2,000,000 unique candidate pairs (lid < rid, no self-pairs) while ensuring feasibility on a dataset of approximately 2 million records within a 30-minute time limit. The success metric was maximized recall, subject to strict computational complexity constraints (avoiding O(k^2) operations). The solution evolved through several iterations, culminating in a two-stage blocking approach leveraging MinHash Locality Sensitive Hashing (LSH) and a refined Sorted Neighborhood Method (SNM).

### Preprocessing

Textual data preprocessing was crucial for effective blocking. Initially, `brand`, `name`, and `description` fields were combined, lowercased, tokenized, and common English stopwords were removed. Early iterations excluded numeric characters and the `category` field due to perceived noise.

Key preprocessing evolutions:
*   **Numeric Retention:** An early design decision (Trial 4) modified the `clean_text` regex to `r"[^a-z0-9\s]"` to explicitly retain alphanumeric characters. This allowed product identifiers, model numbers, and capacities (e.g., "128gb", "x230") to be captured, significantly boosting recall.
*   **Brand Normalization:** A dedicated `normalize_brand` function was introduced (Trial 8) to standardize common brand variations (e.g., "wd" to "western digital"). This ensured consistent blocking across brand inconsistencies.
*   **Comprehensive Identifier Extraction:** The `extract_identifiers` function (Trial 8) was developed using extensive regex patterns to specifically capture model numbers (`\b[a-z]{1,3}[0-9]{2,5}[a-z]?\b`), storage capacities (`\b\d+(gb|g|tb|mb|kb)\b`), and generic numeric sequences. This enriched the token set with highly discriminative features. A later attempt (Trial 10) to relax numeric patterns to `\b\d{2,}\b` (capturing 2-3 digit numbers) unexpectedly decreased recall, suggesting that 2-3 digit numbers were either too noisy or not sufficiently discriminative for the ground truth.
*   **Field Inclusion:** The `category` field, initially omitted, was later incorporated into the combined text (Trial 3, then Trial 8) to leverage additional descriptive terms, proving beneficial.
*   **Stopword Refinement:** A custom set of expanded stopwords was curated for the electronic product domain, removing generic terms (e.g., "memory card", "product", "high speed") that lacked discriminative power.
*   **Token Filtering:** Tokens were filtered based on document frequency to exclude both very rare (potential noise/typos) and overly common (non-discriminative) terms, ensuring effective blocking keys.

### Modelling Methods

The core blocking strategy combines two methods to efficiently generate candidates, strictly adhering to the output limit.

#### MinHash Locality Sensitive Hashing (LSH)

*   **Initial Candidate Generation:** LSH was employed as the first stage to generate a broad set of potential candidates. Each record's combined and extracted tokens were used to create a MinHash signature.
*   **LSH Configuration:** An aggressive LSH setup was chosen (Trial 8) with `num_permutations=128`, `num_bands=64`, and `num_rows=2`. This configuration increased sensitivity, allowing the detection

Runtime: 2953 seconds