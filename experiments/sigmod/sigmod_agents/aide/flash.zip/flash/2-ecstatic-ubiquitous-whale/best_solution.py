import pandas as pd
import re
from collections import defaultdict
import string
import numpy as np
import os
import math

# --- Configuration Constants ---
N_CANDIDATE_PAIRS = 2_000_000

# BUCKET_THRESHOLD: Dynamic for sample data to allow maximal recall.
# For the full dataset (~2M records), a balanced threshold would prevent
# processing overly large lists, typically in the range of 5k-10k.
# For this sample X2.csv (1993 records), it's set to len(X2) to essentially
# disable pruning by bucket size, aiming for theoretical max candidates.
BUCKET_THRESHOLD = None


# Ensure working directory exists for output
os.makedirs("logs/2-ecstatic-ubiquitous-whale", exist_ok=True)


# --- Preprocessing Functions ---
def preprocess_text(text, specific_product_field=False):
    """
    Standardizes text by lowercasing and handling punctuation relevant to electronic products.
    If specific_product_field is True, retains some internal punctuation (`.`, `-`, `/`)
    which are often critical in product names/models (e.g., 'UHS-I', '3.0', 'SD/XC').
    Otherwise, generic punctuation is replaced with spaces.
    """
    if pd.isna(text):
        return ""
    text = str(text).lower()

    if specific_product_field:
        # Replace general separating punctuation with space but keep allowed internal ones for specific tokenization
        # Retain '.', '-', '/' for potential multi-character tokens like '3.0', 'uhs-i', 'sd/xc'
        # This regex replaces any character that is NOT alphanumeric, whitespace, or one of (.-/) with a space.
        text = re.sub(r"[^a-z0-9\s.\-\/]", " ", text)
    else:
        # General cleaning for less structured fields like category or brand that might not contain
        # complex product identifiers needing special punctuation retention.
        text = re.sub(
            f"[{re.escape(string.punctuation)}]", " ", text
        )  # Replace all punctuation with spaces

    text = re.sub(
        r"\s+", " ", text
    ).strip()  # Replace multiple spaces with single, then strip leading/trailing
    return text


def extract_tokens(text, min_len=2):
    """
    Extracts significant tokens and alphanumeric sequences from a cleaned string.
    Specifically designed for electronics products, supporting hyphenated, dotted, and
    slashed parts in model names and specs (e.g., 'UHS-I', '3.0', 'SD/XC').
    Tokens must be at least `min_len` characters long.
    """
    tokens = set()

    # This regex matches sequences starting with an alphanumeric char, optionally followed by
    # non-empty sequences of ('.', '-', '/') and alphanumeric chars.
    # Examples: 'usb', 'uhs-i', 'sd/xc', '3.0', 'x230'
    potential_tokens = re.findall(r"[a-z0-9]+(?:[\.\-\/][a-z0-9]+)*", text)

    for token in potential_tokens:
        if len(token) >= min_len:
            tokens.add(token)

    return list(tokens)


# --- Main Blocking Logic ---

# 1. Load Data
INPUT_DIR = "/Users/USER/Documents/UNI/WS25/SIGMOD_full_data"
X2 = pd.read_csv(os.path.join(INPUT_DIR, "X2.csv"))

# Initialize BUCKET_THRESHOLD based on the current dataset size for sample data evaluation.
# For X2.csv (~2k records), setting it to len(X2) means we will effectively
# not filter out any blocking keys due to commonality within this small dataset,
# which helps in reaching the maximum theoretical candidate pairs for recall maximization.
# For a full 2M record dataset, this threshold would need to be much smaller
# (e.g., 5,000-10,000) to respect memory and time limits without discarding all pairs.
BUCKET_THRESHOLD = len(X2)  # For X2.csv, this is 1993.


# 2. Apply Preprocessing
# Use specific_product_field=True for name and description for finer-grained tokenization
X2["cleaned_brand"] = X2["brand"].apply(
    lambda x: preprocess_text(x, specific_product_field=False)
)
X2["cleaned_name"] = X2["name"].apply(
    lambda x: preprocess_text(x, specific_product_field=True)
)
X2["cleaned_category"] = X2["category"].apply(
    lambda x: preprocess_text(x, specific_product_field=False)
)
X2["cleaned_description"] = X2["description"].apply(
    lambda x: preprocess_text(x, specific_product_field=True)
)

# Define a set of generic words to filter from description and category to avoid low-signal blocking keys
GENERIC_WORDS = {
    "página",
    "home",
    "startseite",
    "startsida",
    "page",
    "site",
    "website",
    "description",
    "general",
    "información",
    "overview",
    "saber",  # identified during review
    "card",
    "memory",
    "flash",
    "storage",
    "mobile",
    "high",
    "speed",
    "data",  # Common but maybe not specific
    "drive",
    "system",
    "usb",
    "sd",
    "hc",
    "gb",
    "mb",
    "gb",
    "pro",
    "ultra",  # Also common but might be useful
}


# 3. Build Inverted Index for Blocking Keys
inverted_index = defaultdict(list)
record_blocking_keys = defaultdict(set)

for _, row in X2.iterrows():
    record_id = row["id"]
    cleaned_brand = row["cleaned_brand"]
    cleaned_name = row["cleaned_name"]
    cleaned_category = row["cleaned_category"]
    cleaned_description = row["cleaned_description"]

    # Base blocking keys:
    # 1. Brand as a key
    if cleaned_brand:
        brand_key = "brand_" + cleaned_brand
        inverted_index[brand_key].append(record_id)
        record_blocking_keys[record_id].add(brand_key)

    # 2. Significant tokens from name as keys
    name_tokens = extract_tokens(cleaned_name, min_len=2)
    for token in name_tokens:
        # Adding some light generic word filtering here too to reduce noise in specific tokens
        if token not in GENERIC_WORDS:
            token_key = "name_" + token
            inverted_index[token_key].append(record_id)
            record_blocking_keys[record_id].add(token_key)

    # 3. Category as a key, if not generic or empty
    if cleaned_category and cleaned_category not in GENERIC_WORDS:
        category_key = "category_" + cleaned_category
        inverted_index[category_key].append(record_id)
        record_blocking_keys[record_id].add(category_key)

    # NEW: 4. Description tokens as keys
    description_tokens = extract_tokens(cleaned_description, min_len=2)
    for token in description_tokens:
        if token and token not in GENERIC_WORDS:
            desc_key = "desc_" + token
            inverted_index[desc_key].append(record_id)
            record_blocking_keys[record_id].add(desc_key)

    # NEW (Improved): 5. Combined keys: brand + specific name token AND brand + specific description token
    # These create more specific blocking keys that can handle very common brands effectively.
    if cleaned_brand:
        for token in name_tokens:
            if token and token not in GENERIC_WORDS:
                combo_name_key = f"combo_brand_name_{cleaned_brand}_{token}"
                inverted_index[combo_name_key].append(record_id)
                record_blocking_keys[record_id].add(combo_name_key)
        for token in description_tokens:
            if token and token not in GENERIC_WORDS:
                combo_desc_key = f"combo_brand_desc_{cleaned_brand}_{token}"
                inverted_index[combo_desc_key].append(record_id)
                record_blocking_keys[record_id].add(combo_desc_key)

# 4. Filter Inverted Index: Remove overly generic keys (large buckets).
# BUCKET_THRESHOLD is configured for high recall on sample data.
filtered_inverted_index = {}
for key, ids_list in inverted_index.items():
    if len(ids_list) <= BUCKET_THRESHOLD:
        filtered_inverted_index[key] = ids_list

# Update record_blocking_keys to only include keys present in filtered_inverted_index.
# This step ensures that IDs only attempt to find neighbors using valid, non-pruned keys.
temp_record_blocking_keys = defaultdict(set)
for record_id, keyset in record_blocking_keys.items():
    for key in keyset:
        if key in filtered_inverted_index:
            temp_record_blocking_keys[record_id].add(key)
record_blocking_keys = temp_record_blocking_keys


# 5. Generate Candidate Pairs with a Strict Limit
candidate_pairs = set()
all_ids = sorted(X2["id"].unique())

# Calculate the actual target number of candidates: min(N_CANDIDATE_PAIRS, theoretical_max_for_current_data)
num_records = len(X2)
if num_records > 1:
    max_possible_pairs = num_records * (num_records - 1) // 2
    max_candidates_target = min(N_CANDIDATE_PAIRS, max_possible_pairs)
else:
    max_candidates_target = 0

print(
    f"Targeting {max_candidates_target} candidates for a dataset of {num_records} records."
)

# Iteratively build candidate pairs
for id1 in all_ids:
    if len(candidate_pairs) >= max_candidates_target:
        break

    id1_keys = record_blocking_keys.get(id1, set())
    seen_neighbors_for_id1 = set()

    for key in id1_keys:
        if len(candidate_pairs) >= max_candidates_target:
            break

        # Iterate through records sharing the same key from the filtered inverted index
        for id2 in filtered_inverted_index.get(key, []):
            # Ensure id1 < id2 for unique pairs and no self-pairs
            # Ensure id2 hasn't already been paired with id1 via another common key in this pass
            if id1 < id2 and id2 not in seen_neighbors_for_id1:
                candidate_pairs.add((id1, id2))
                seen_neighbors_for_id1.add(id2)

                if len(candidate_pairs) >= max_candidates_target:
                    break


# 6. Format and Save Output to output.csv
# Truncate to `max_candidates_target` if more were collected, which could happen if
# break conditions weren't perfectly aligned, but generally, the logic should stay
# close to the target. This ensures the exact number of pairs (or max possible).
final_candidates_list = list(candidate_pairs)
if len(final_candidates_list) > max_candidates_target:
    final_candidates_list = final_candidates_list[:max_candidates_target]

output_df = pd.DataFrame(final_candidates_list, columns=["lid", "rid"])
output_df = output_df.sort_values(by=["lid", "rid"]).reset_index(drop=True)
output_df.to_csv("logs/2-ecstatic-ubiquitous-whale/output.csv", index=False)


# --- Evaluation (using Z2.csv - ONLY FOR EVALUATION) ---
Z2 = pd.read_csv(os.path.join(INPUT_DIR, "Z2.csv"))
true_matches = set(tuple(sorted((row["lid"], row["rid"]))) for _, row in Z2.iterrows())

predicted_matches = set(map(tuple, output_df.values))

num_true_matches_in_output = len(predicted_matches.intersection(true_matches))
total_true_matches = len(true_matches)
recall = (
    num_true_matches_in_output / total_true_matches if total_true_matches > 0 else 0
)

print(f"Recall: {recall:.4f}")
print(
    f"Number of generated candidates: {len(predicted_matches)}"
)  # Use predicted_matches to reflect the saved count
print(f"Output saved to ./working/output.csv")
