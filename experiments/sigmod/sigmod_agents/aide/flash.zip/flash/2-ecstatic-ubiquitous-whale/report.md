# Technical Report: Entity Resolution Blocking

## Introduction

This report details the development of a blocking mechanism for entity resolution on a dataset of electronic products (X2.csv). The primary objective was to generate a maximum of 2,000,000 unique candidate pairs (`lid < rid`, no self-pairs) for subsequent matching, while achieving high recall against a ground truth (Z2.csv). A critical constraint was feasibility on a full dataset of approximately 2 million records, requiring the avoidance of `O(k^2)` operations within any blocking bucket and dynamic candidate generation to prevent memory exhaustion. The development followed an iterative design process, refining preprocessing and blocking strategies to optimize recall while adhering to strict feasibility requirements.

## Preprocessing

Initial preprocessing involved standard text normalization: lowerc

Runtime: 2996 seconds