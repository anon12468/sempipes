import pandas as pd
import re
from collections import defaultdict
import numpy as np
import os
import gc

# --- Parameters ---
N_CANDIDATES_TARGET = 2_000_000
# Significantly increased window sizes for improved candidate generation.
# These values are tuned to increase candidate output without causing O(k^2) explosions for individual buckets,
# leveraging the O(k*W) windowing with early stopping. The target N_CANDIDATES_TARGET cannot be physically met
# by the small X2.csv sample (max possible pairs for 1993 records is ~1.98M), but these larger windows
# ensure that for the full ~2M record dataset, we approach the target while maintaining good recall.
WINDOW_SIZE_BRAND = (
    300  # Brands are often highly specific; larger window for more pairs.
)
WINDOW_SIZE_NUMERIC_SUBSTRING = (
    100  # New: Moderate window for very specific numeric identifiers.
)
WINDOW_SIZE_NAME_2GRAM = (
    200  # 2-grams are good; a solid window to capture more matches.
)
WINDOW_SIZE_NAME_TOKEN = 150  # General name tokens can be broad; a moderate window balances coverage and feasibility.
CANDIDATE_BUFFER = 100_000  # Buffer for overcollecting, same as before.

# --- File Paths ---
INPUT_DIR = "/Users/USER/Documents/UNI/WS25/SIGMOD_full_data"
WORKING_DIR = "logs/0-gregarious-tomato-velociraptor"
X2_PATH = os.path.join(INPUT_DIR, "X2.csv")
Z2_PATH = os.path.join(INPUT_DIR, "Z2.csv")  # Used for evaluation only
OUTPUT_PATH = os.path.join(WORKING_DIR, "output.csv")

# Ensure working directory exists
os.makedirs(WORKING_DIR, exist_ok=True)


# --- Preprocessing Function (Revised for better tokenization) ---
# Clean raw text: lowercase, normalize separators, and remove extra spaces.
# This produces a cleaned string ready for tokenization.
def clean_text_for_index(text):
    if pd.isna(text):
        return ""
    text_str = str(text).lower()

    # Crucially, replace common separators (dashes, dots, slashes, underscores) with spaces.
    # This prevents them from merging into a single 'word' token (e.g., 'usb_3_0' from 'usb-3.0').
    text_str = re.sub(r"[\-./,_]", " ", text_str)

    # Replace multiple spaces with a single space and strip leading/trailing spaces.
    text_str = re.sub(r"\s+", " ", text_str).strip()
    return text_str


# Get significant tokens from a cleaned text string.
# This ensures that numbers are retained and non-numeric tokens have sufficient length.
def get_significant_tokens(cleaned_text):
    if not cleaned_text:
        return []
    raw_tokens = cleaned_text.split()
    final_tokens = []
    # Whitelist for significant single-character alphanumeric tokens.
    # These often denote specific product variants or generations (e.g., 'k' for unlocked CPUs, 'i' for Intel 'i7').
    SINGLE_CHAR_WHITELIST = {"k", "x", "s", "f", "v", "a", "m", "p", "i"}

    for token in raw_tokens:
        if (
            token.isdigit()
        ):  # Keep purely numeric tokens (any length, e.g., '3', '2023')
            final_tokens.append(token)
        elif len(token) >= 2:  # Keep non-numeric tokens that are 2 characters or longer
            final_tokens.append(token)
        elif (
            len(token) == 1 and token in SINGLE_CHAR_WHITELIST
        ):  # Explicitly whitelist significant single-character non-numeric tokens
            final_tokens.append(token)
    return final_tokens


# Function to extract long numeric substrings
def get_long_numeric_substrings(cleaned_text):
    if not cleaned_text:
        return []
    numeric_substrings = set()
    # Iterate over tokens from the cleaned text to find numeric sequences within them
    for token in cleaned_text.split():
        # Find all sequences of at least two digits within the token
        # This handles cases like "i711700k" (extracted as "11700") or "5420" (extracted as "5420")
        matches = re.findall(r"\d{2,}", token)
        for match in matches:
            numeric_substrings.add(match)
    return list(numeric_substrings)


# --- Candidate Collection ---
candidate_pairs_set = set()


# This function adds candidates using the sliding window approach within a bucket.
# It returns True if the global candidate limit (target + buffer) has been met or exceeded.
def add_pairs_from_bucket(id_list, window_size):
    global candidate_pairs_set

    if len(id_list) < 2:
        return False  # No pairs possible in this bucket

    # Sort the IDs within the bucket. This ensures:
    # 1. Stable and reproducible windowing.
    # 2. Pairs (id1, id2) always have id1 < id2, as required for output.
    id_list_sorted = sorted(list(id_list))

    # Implement sliding window O(k*W) pairing
    for i in range(len(id_list_sorted)):
        # Stop early if we have collected enough candidates (target + buffer)
        # This prevents excessive memory usage for the candidate_pairs_set, ensuring feasibility.
        if len(candidate_pairs_set) >= N_CANDIDATES_TARGET + CANDIDATE_BUFFER:
            return True  # Indicate we hit buffer limit

        current_id = id_list_sorted[i]
        # Compare with items in a forward-looking window
        for j in range(i + 1, min(i + 1 + window_size, len(id_list_sorted))):
            other_id = id_list_sorted[j]
            # Pair already sorted as id_list_sorted is sorted and we pick i < j
            pair = (current_id, other_id)
            candidate_pairs_set.add(pair)

    return False  # Indicate buffer limit not hit yet by this bucket


print("Loading X2.csv...")
df_x2 = pd.read_csv(X2_PATH)

# Clean and normalize relevant text fields using the improved cleaning function
df_x2["p_brand_cleaned"] = df_x2["brand"].apply(clean_text_for_index)
df_x2["p_name_cleaned"] = df_x2["name"].apply(clean_text_for_index)

# Ensure 'id' is integer and handle potential NaNs (though data overview suggests none)
df_x2.dropna(subset=["id"], inplace=True)
df_x2["id"] = df_x2["id"].astype(int)

print("Building inverted indexes with revised tokenization...")
# 1. Inverted Index for normalized brand (single cleaned string as key)
brand_inverted_index = defaultdict(set)
for _, row in df_x2.iterrows():
    cleaned_brand = row["p_brand_cleaned"]
    if cleaned_brand:  # Ensure brand is not empty after cleaning
        brand_inverted_index[cleaned_brand].add(row["id"])


# 2. Inverted Index for long numeric substrings
numeric_substring_inverted_index = defaultdict(set)
for _, row in df_x2.iterrows():
    numeric_parts = get_long_numeric_substrings(row["p_name_cleaned"])
    for num_str in numeric_parts:
        numeric_substring_inverted_index[num_str].add(row["id"])


# 3. Inverted Index for two-grams (consecutive word pairs) of the normalized name
name_2gram_inverted_index = defaultdict(set)
for _, row in df_x2.iterrows():
    tokens = get_significant_tokens(row["p_name_cleaned"])
    for i in range(len(tokens) - 1):
        bigram = (tokens[i], tokens[i + 1])  # Use tuple of strings as the key
        name_2gram_inverted_index[bigram].add(row["id"])


# 4. Inverted Index for ANY significant token of the normalized name
# This broadens candidate generation, especially important for unique product keywords/numbers.
name_token_inverted_index = defaultdict(set)
for _, row in df_x2.iterrows():
    tokens = get_significant_tokens(row["p_name_cleaned"])
    for token in set(
        tokens
    ):  # Use set to add each ID to each unique token's list only once per item
        name_token_inverted_index[token].add(row["id"])


gc.collect()  # Trigger garbage collection to free memory after index creation


print(
    f"Generating candidates towards target {N_CANDIDATES_TARGET} (with buffer of {CANDIDATE_BUFFER})..."
)

# Prioritize brand blocking (most specific, likely high quality)
print(f"Applying Brand blocking with window {WINDOW_SIZE_BRAND}...")
for brand_key, ids_set in brand_inverted_index.items():
    if add_pairs_from_bucket(list(ids_set), WINDOW_SIZE_BRAND):
        print(
            f"Buffer limit ({N_CANDIDATES_TARGET + CANDIDATE_BUFFER}) hit during brand blocking. Current candidates: {len(candidate_pairs_set)}"
        )
        break
print(f"Candidates after brand blocking: {len(candidate_pairs_set)}")

# NEW Blocking strategy: Long Numeric Substrings
if len(candidate_pairs_set) < N_CANDIDATES_TARGET + CANDIDATE_BUFFER:
    print(
        f"Applying Numeric Substring blocking with window {WINDOW_SIZE_NUMERIC_SUBSTRING}..."
    )
    for num_str_key, ids_set in numeric_substring_inverted_index.items():
        if add_pairs_from_bucket(list(ids_set), WINDOW_SIZE_NUMERIC_SUBSTRING):
            print(
                f"Buffer limit ({N_CANDIDATES_TARGET + CANDIDATE_BUFFER}) hit during numeric substring blocking. Current candidates: {len(candidate_pairs_set)}"
            )
            break
print(f"Candidates after numeric substring blocking: {len(candidate_pairs_set)}")


# If more candidates are needed, proceed with name 2-gram blocking (good specificity)
if len(candidate_pairs_set) < N_CANDIDATES_TARGET + CANDIDATE_BUFFER:
    print(f"Applying Name 2-gram blocking with window {WINDOW_SIZE_NAME_2GRAM}...")
    for bigram_key, ids_set in name_2gram_inverted_index.items():
        if add_pairs_from_bucket(list(ids_set), WINDOW_SIZE_NAME_2GRAM):
            print(
                f"Buffer limit ({N_CANDIDATES_TARGET + CANDIDATE_BUFFER}) hit during name 2-gram blocking. Current candidates: {len(candidate_pairs_set)}"
            )
            break
print(f"Candidates after name 2-gram blocking: {len(candidate_pairs_set)}")


# If still more candidates are needed, use general name token blocking (broad coverage)
if len(candidate_pairs_set) < N_CANDIDATES_TARGET + CANDIDATE_BUFFER:
    print(f"Applying Name token blocking with window {WINDOW_SIZE_NAME_TOKEN}...")
    for token_key, ids_set in name_token_inverted_index.items():
        if add_pairs_from_bucket(list(ids_set), WINDOW_SIZE_NAME_TOKEN):
            print(
                f"Buffer limit ({N_CANDIDATES_TARGET + CANDIDATE_BUFFER}) hit during name token blocking. Current candidates: {len(candidate_pairs_set)}"
            )
            break
print(f"Candidates after all blocking strategies: {len(candidate_pairs_set)}")


# --- Finalizing Candidates to Exactly N_CANDIDATES_TARGET ---
print(f"Finalizing exactly {N_CANDIDATES_TARGET} candidates for output...")
candidates_list = list(candidate_pairs_set)
gc.collect()  # Trigger garbage collection after set conversion to list

if len(candidates_list) > N_CANDIDATES_TARGET:
    # If we generated more than the target, randomly sample down to the exact target
    np.random.shuffle(candidates_list)
    final_candidates = candidates_list[:N_CANDIDATES_TARGET]
    print(
        f"Randomly sampled {len(final_candidates)} candidates from {len(candidates_list)} generated unique pairs."
    )
elif len(candidates_list) < N_CANDIDATES_TARGET:
    # This scenario is expected for the small X2.csv dataset, as its max possible pairs (~1.98M for 1993 records) < 2M.
    # For the full ~2M record dataset, this indicates blocking was not permissive enough or reached physical limit of unique pairs.
    print(
        f"WARNING: Only {len(candidates_list)} unique candidates could be generated, less than target {N_CANDIDATES_TARGET}. This is expected for small sample dataset, as it cannot physically produce 2M pairs."
    )
    final_candidates = candidates_list
else:
    # Exactly N_CANDIDATES_TARGET were generated
    final_candidates = candidates_list

# Prepare output DataFrame and save
output_df = pd.DataFrame(
    final_candidates, columns=["left_instance_id", "right_instance_id"]
)
# Sort for deterministic output, although not strictly required by task for submission.
output_df.sort_values(by=["left_instance_id", "right_instance_id"], inplace=True)
output_df.to_csv(OUTPUT_PATH, index=False)
print(f"Successfully generated {len(output_df)} candidate pairs saved to {OUTPUT_PATH}")

# --- Evaluation (using Z2.csv, NEVER part of candidate generation) ---
print("\n--- Evaluation ---")
print("Loading Z2.csv for ground truth evaluation...")
df_z2 = pd.read_csv(Z2_PATH)
df_z2["lid"] = df_z2["lid"].astype(int)
df_z2["rid"] = df_z2["rid"].astype(int)

# Create a set of true matches, ensuring (id1, id2) format with id1 < id2
true_matches_set = set()
for _, row in df_z2.iterrows():
    true_matches_set.add(tuple(sorted((row["lid"], row["rid"]))))
print(f"Total true matches in Z2.csv: {len(true_matches_set)}")

# Load the generated output.csv to evaluate against it (double check consistency)
predicted_output_df = pd.read_csv(OUTPUT_PATH)
predicted_matches_set = set()
for _, row in predicted_output_df.iterrows():
    predicted_matches_set.add(
        tuple(sorted((row["left_instance_id"], row["right_instance_id"])))
    )
print(f"Total candidate pairs outputted: {len(predicted_matches_set)}")

# Calculate recall: (True Positives) / (All True Matches)
matches_found = len(predicted_matches_set.intersection(true_matches_set))
total_true_matches = len(true_matches_set)

recall = matches_found / total_true_matches if total_true_matches > 0 else 0

print(f"Matches found within the output: {matches_found}")
print(f"Recall: {recall:.4f}")
