import pandas as pd
import re
import numpy as np
from collections import defaultdict, Counter
from datasketch import MinHash
from tqdm import tqdm
import os
import random

# Define constants
TARGET_PAIRS = 2_000_000
INPUT_DIR = "./input"
WORKING_DIR = "./working"

# Ensure working directory exists
os.makedirs(WORKING_DIR, exist_ok=True)

# --- Text Preprocessing Functions ---


def normalize_text(text):
    """Cleans and normalizes a string, keeping parts of model numbers."""
    if not isinstance(text, str):
        return ""
    text = text.lower()
    text = re.sub(r"[^\w\s\-\.]", " ", text)  # Keep hyphens and dots
    text = re.sub(r"\s+", " ", text).strip()
    return text


def extract_tokens(text):
    """Extracts alphanumeric tokens from text."""
    return re.findall(r"[a-z0-9]+", text)


def extract_capacity(name):
    """Extracts memory capacity like '64gb' from a product name."""
    if not isinstance(name, str):
        return None

    name = name.lower()
    # Matches patterns like 16gb, 32 gb, 1 tb, etc.
    match = re.search(r"(\d+)\s?(gb|tb)", name)
    if match:
        num, unit = match.groups()
        try:
            num_val = int(num)
            if unit == "tb":
                # Normalize tb to gb for consistency
                num_val = num_val * 1000  # Use 1000 for market convention
            return f"{num_val}gb"
        except ValueError:
            return None
    return None


# --- Main Logic ---

# 1. Load and preprocess data
print("Loading and preprocessing data...")
df = pd.read_csv(os.path.join(INPUT_DIR, "X2.csv"))

# Fill NaNs to avoid errors
df = df.fillna("")

# Apply normalization and feature extraction
df["normalized_name"] = df["name"].apply(normalize_text)
df["normalized_brand"] = df["brand"].apply(normalize_text)
df["capacity"] = df["normalized_name"].apply(extract_capacity)
df["tokens"] = df["normalized_name"].apply(extract_tokens)

# Create a mapping from ID to normalized name for sorting in buckets
id_to_name = dict(zip(df["id"], df["normalized_name"]))

# Set to store unique candidate pairs (lid, rid) where lid < rid
candidate_pairs = set()

# Global flag to stop generation when target is reached
enough_pairs = False


def add_pairs_from_bucket(ids, window_size):
    """Applies Sorted Neighborhood Method to a bucket of IDs and adds pairs."""
    global enough_pairs, candidate_pairs
    if enough_pairs or len(ids) < 2:
        return

    # Sort items in bucket by normalized name
    items = sorted(
        [(id_val, id_to_name.get(id_val, "")) for id_val in ids], key=lambda x: x[1]
    )

    # Use a sliding window to generate pairs
    for i in range(len(items)):
        if enough_pairs:
            break
        for j in range(i + 1, min(i + window_size, len(items))):
            id1, id2 = items[i][0], items[j][0]
            if id1 != id2:
                pair = tuple(sorted((id1, id2)))
                candidate_pairs.add(pair)
                if len(candidate_pairs) >= TARGET_PAIRS:
                    enough_pairs = True
                    break


# --- STAGE 1: High-Precision Blocking (brand, capacity) ---
print("\n--- Stage 1: High-Precision Blocking (brand, capacity) ---")
inverted_index_1 = defaultdict(list)
for _, row in df.iterrows():
    if row["capacity"] and row["normalized_brand"]:
        key = (row["normalized_brand"], row["capacity"])
        inverted_index_1[key].append(row["id"])

for key, ids in tqdm(inverted_index_1.items(), desc="Processing Brand-Capacity Blocks"):
    if enough_pairs:
        break
    if 1 < len(ids) < 1000:  # Relaxed cap
        add_pairs_from_bucket(ids, window_size=15)

print(f"Found {len(candidate_pairs)} pairs after Stage 1.")


# --- STAGE 2: Token-based Blocking ---
if not enough_pairs:
    print("\n--- Stage 2: Token-based blocking on product name ---")

    inverted_index_2 = defaultdict(list)
    for _, row in df.iterrows():
        unique_tokens = set(row["tokens"])
        for token in unique_tokens:
            if len(token) > 2:  # Ignore very short tokens
                inverted_index_2[token].append(row["id"])

    # Filter out tokens that are too common (likely stopwords) or too rare
    # These thresholds are key for feasibility on a large dataset
    MAX_BUCKET_SIZE_TOKEN = 2000
    MIN_BUCKET_SIZE_TOKEN = 2

    # Process smaller, higher-precision buckets first
    sorted_tokens = sorted(inverted_index_2.items(), key=lambda item: len(item[1]))

    for token, ids in tqdm(sorted_tokens, desc="Processing Token Blocks"):
        if enough_pairs:
            break
        if MIN_BUCKET_SIZE_TOKEN < len(ids) < MAX_BUCKET_SIZE_TOKEN:
            add_pairs_from_bucket(ids, window_size=10)

    print(f"Found {len(candidate_pairs)} pairs after Stage 2.")


# --- STAGE 3: LSH Blocking on Product Names ---
if not enough_pairs:
    print("\n--- Stage 3: LSH-style Blocking on Product Name ---")

    # LSH parameters
    num_perm = 128
    bands = 32
    rows = num_perm // bands

    minhashes = {}
    print("Creating MinHashes...")
    for _, row in tqdm(df.iterrows(), total=len(df), desc="MinHashing"):
        shingles = set(
            row["normalized_name"][i : i + 3]
            for i in range(len(row["normalized_name"]) - 2)
        )
        if not shingles:
            continue

        m = MinHash(num_perm=num_perm)
        for s in shingles:
            m.update(s.encode("utf8"))
        minhashes[row["id"]] = m

    print("Generating pairs from LSH buckets...")
    lsh_buckets = [defaultdict(list) for _ in range(bands)]
    for doc_id, m in tqdm(minhashes.items(), desc="Populating Buckets"):
        for i in range(bands):
            band_hashes = m.hashvalues[i * rows : (i + 1) * rows]
            bucket_key = hash(tuple(band_hashes))
            lsh_buckets[i][bucket_key].append(doc_id)

    for i, band_buckets in enumerate(lsh_buckets):
        if enough_pairs:
            break

        sorted_bucket_items = sorted(
            band_buckets.items(), key=lambda item: len(item[1])
        )

        for _, ids in tqdm(
            sorted_bucket_items, desc=f"Processing Band {i+1}/{bands}", leave=False
        ):
            if enough_pairs:
                break
            if 1 < len(ids) < 5000:  # Significantly increased cap
                add_pairs_from_bucket(ids, window_size=20)  # Increased window size

print(f"\nTotal unique pairs generated: {len(candidate_pairs)}")

# 4. Format and save output
print(f"Sampling/truncating to {TARGET_PAIRS} pairs for output.csv...")
output_pairs_list = list(candidate_pairs)

if len(output_pairs_list) > TARGET_PAIRS:
    # Randomly sample to avoid bias from generation order if we overshoot
    final_pairs = random.sample(output_pairs_list, TARGET_PAIRS)
else:
    # On small sample data, we take everything we found.
    final_pairs = output_pairs_list

output_df = pd.DataFrame(final_pairs, columns=["lid", "rid"])

# On full data, we should not see this warning if parameters are tuned well.
if len(output_df) < TARGET_PAIRS and len(df) > 10000:
    print(
        f"Warning: Generated only {len(output_df)} pairs, less than target {TARGET_PAIRS}."
    )
    # In a real scenario, this would indicate the blocking logic needs to be even more relaxed.

output_csv_path = os.path.join(WORKING_DIR, "output.csv")
output_df.to_csv(output_csv_path, index=False)
print(f"Output file saved to {output_csv_path} with {len(output_df)} rows.")

# 5. Evaluation (using the provided ground truth)
print("\n--- Evaluation ---")
try:
    z2_path = os.path.join(INPUT_DIR, "Z2.csv")
    if os.path.exists(z2_path):
        z2 = pd.read_csv(z2_path)
        true_pairs = set(tuple(sorted(x)) for x in z2.to_numpy())
        total_true_pairs = len(true_pairs)

        generated_pairs_set = set(tuple(x) for x in output_df.to_numpy())
        found_matches = len(generated_pairs_set.intersection(true_pairs))
        recall = found_matches / total_true_pairs if total_true_pairs > 0 else 0

        print(f"Total true pairs in Z2.csv: {total_true_pairs}")
        print(f"Pairs in your output.csv: {len(generated_pairs_set)}")
        print(f"True matches found: {found_matches}")
        print(f"Recall: {recall:.4f}")
    else:
        print("Z2.csv not found, skipping evaluation.")
except FileNotFoundError:
    print("Evaluation file Z2.csv not found. Skipping evaluation.")
