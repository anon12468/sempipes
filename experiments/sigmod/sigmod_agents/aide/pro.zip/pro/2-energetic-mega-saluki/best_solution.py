import pandas as pd
import re
from collections import defaultdict
from tqdm import tqdm
import os

# --- Configuration ---
INPUT_DIR = "./input/"
WORKING_DIR = "./working/"
X_PATH = os.path.join(INPUT_DIR, "X2.csv")
Z_PATH = os.path.join(INPUT_DIR, "Z2.csv")
OUTPUT_PATH = os.path.join(WORKING_DIR, "output.csv")

# The task requires exactly 2,000,000 pairs in the final submission.
# On the small dev set, we might not reach this number, which is fine.
TARGET_PAIRS = 2_000_000

# Window size for the Sorted Neighborhood Method.
# A small window is crucial for feasibility on large buckets.
SNM_WINDOW_SIZE = 10

# --- Preprocessing and Feature Extraction Functions ---


def normalize_text(text):
    """Lowercase, remove punctuation, standardize common units and whitespace."""
    if not isinstance(text, str):
        return ""
    text = text.lower()
    text = re.sub(r"[\W_]+", " ", text, flags=re.UNICODE)

    # Standardize storage capacity units for better matching
    text = re.sub(r"(\d+)\s*go\b", r"\1gb", text)
    text = re.sub(r"(\d+)\s*g\b", r"\1gb", text)
    text = re.sub(r"(\d+)\s*to\b", r"\1tb", text)

    return " ".join(text.split())


def extract_capacity(text):
    """Extract storage capacity (e.g., '16gb', '2tb') from normalized text."""
    match = re.search(r"(\d+(?:gb|tb))", text)
    return match.group(1) if match else None


def extract_model_words(text):
    """Extract potential model words (alphanumeric strings) from normalized text."""
    # A common heuristic for model numbers is that they contain both letters and digits.
    return [
        word
        for word in text.split()
        if any(c.isalpha() for c in word) and any(c.isdigit() for c in word)
    ]


def extract_name_words(text):
    """Extract significant words from normalized text, filtering out noise."""
    # Filter out purely numeric tokens (often prices/specs better handled by other extractors)
    # and very short tokens which are usually stop words or noise.
    return [word for word in text.split() if len(word) > 2 and not word.isdigit()]


# --- Core Blocking Logic with Feasibility Safeguards ---


def generate_snm_pairs(
    bucket, id_to_sort_key, window_size, candidates_list, candidates_set, target_size
):
    """
    Applies the Sorted Neighborhood Method (SNM) to a bucket of record IDs.
    This avoids the O(k^2) complexity of pairwise comparisons in large buckets.

    Args:
        bucket (list): A list of record IDs that share a blocking key.
        id_to_sort_key (dict): A mapping from ID to a string (e.g., normalized name)
                               used for sorting within the bucket.
        window_size (int): The number of subsequent records to compare each record with.
        candidates_list (list): The list of candidate pairs to append to, preserving order.
        candidates_set (set): The set of seen pairs for efficient duplicate checking.
        target_size (int): The target number of pairs to stop generation.
    """
    if len(bucket) <= 1:
        return

    # Sort items in the bucket by the full normalized text to bring similar items together.
    sorted_bucket = sorted(bucket, key=lambda i: id_to_sort_key.get(i, ""))

    # Slide a window of size `window_size` over the sorted bucket.
    for i in range(len(sorted_bucket)):
        id1 = sorted_bucket[i]
        for j in range(i + 1, min(i + 1 + window_size, len(sorted_bucket))):
            # Check if we have already generated enough candidates inside the tight loop
            if len(candidates_list) >= target_size:
                return

            id2 = sorted_bucket[j]
            # Ensure a canonical pair representation (lid < rid).
            pair = tuple(sorted((id1, id2)))

            if pair not in candidates_set:
                candidates_set.add(pair)
                candidates_list.append(pair)


def run_blocking_stage(
    stage_name,
    inverted_index,
    id_to_sort_key,
    window_size,
    candidates_list,
    candidates_set,
    target_size,
):
    """
    Manages the execution of a single blocking stage, from pair generation to progress reporting.
    """
    print(f"--- Running Blocking Stage: {stage_name} ---")

    # Heuristic: Process smaller buckets first. They are often more precise and generate
    # high-quality candidates quickly.
    sorted_keys = sorted(inverted_index, key=lambda k: len(inverted_index[k]))

    for key in tqdm(sorted_keys, desc=f"Processing {stage_name} Blocks"):
        if len(candidates_list) >= target_size:
            print(f"\nTarget of {target_size} candidates reached. Halting stage early.")
            break
        bucket = inverted_index[key]
        generate_snm_pairs(
            bucket,
            id_to_sort_key,
            window_size,
            candidates_list,
            candidates_set,
            target_size,
        )

    print(f"Total candidates after {stage_name}: {len(candidates_list)}")


# --- Main Execution Script ---

if __name__ == "__main__":
    if not os.path.exists(WORKING_DIR):
        os.makedirs(WORKING_DIR)

    # 1. Load and Preprocess Data
    print("Loading and preprocessing data from X2.csv...")
    df = pd.read_csv(X_PATH)

    df["norm_name"] = df["name"].apply(normalize_text)
    df["norm_brand"] = df["brand"].apply(normalize_text)
    df["full_norm_text"] = df["norm_brand"] + " " + df["norm_name"]

    # Create a lookup dictionary for SNM sorting. This is kept in memory across stages.
    id_to_sort_key = pd.Series(df["full_norm_text"].values, index=df["id"]).to_dict()

    # BUGFIX: Use a list to preserve generation order and a set for fast duplicate checks.
    candidates_list = []
    candidates_set = set()

    # 2. Stage 1: Blocking on Brand + Capacity (High Precision)
    inv_idx_brand_cap = defaultdict(list)
    for rec in df.itertuples():
        capacity = extract_capacity(rec.full_norm_text)
        if rec.norm_brand and capacity:
            key = f"{rec.norm_brand}_{capacity}"
            inv_idx_brand_cap[key].append(rec.id)

    run_blocking_stage(
        "Brand+Capacity",
        inv_idx_brand_cap,
        id_to_sort_key,
        SNM_WINDOW_SIZE,
        candidates_list,
        candidates_set,
        TARGET_PAIRS,
    )
    del inv_idx_brand_cap  # Free up memory, essential for large-scale runs.

    # 3. Stage 2: Blocking on Model Words (Medium Precision)
    if len(candidates_list) < TARGET_PAIRS:
        inv_idx_model = defaultdict(list)
        for rec in df.itertuples():
            model_words = extract_model_words(rec.full_norm_text)
            for mw in model_words:
                inv_idx_model[mw].append(rec.id)
        run_blocking_stage(
            "Model Words",
            inv_idx_model,
            id_to_sort_key,
            SNM_WINDOW_SIZE,
            candidates_list,
            candidates_set,
            TARGET_PAIRS,
        )
        del inv_idx_model

    # 4. Stage 3: Blocking on Name Words (High Recall Fallback)
    if len(candidates_list) < TARGET_PAIRS:
        inv_idx_words = defaultdict(list)
        for rec in df.itertuples():
            name_words = extract_name_words(rec.full_norm_text)
            for word in name_words:
                inv_idx_words[word].append(rec.id)
        run_blocking_stage(
            "Name Words",
            inv_idx_words,
            id_to_sort_key,
            SNM_WINDOW_SIZE,
            candidates_list,
            candidates_set,
            TARGET_PAIRS,
        )
        del inv_idx_words

    # 5. Format and Save Output
    print(f"\nGenerated a total of {len(candidates_list)} unique candidate pairs.")

    # BUGFIX: Use the ordered list directly for deterministic and higher-quality output.
    # Truncate to the exact target size.
    final_candidates = candidates_list[:TARGET_PAIRS]

    output_df = pd.DataFrame(final_candidates, columns=["lid", "rid"])

    # Sort for deterministic output file content.
    output_df = output_df.sort_values(by=["lid", "rid"]).reset_index(drop=True)

    print(f"Saving {len(output_df)} pairs to {OUTPUT_PATH}")
    output_df.to_csv(OUTPUT_PATH, index=False)

    # 6. Evaluation (cannot be used during candidate generation)
    print("\n--- Evaluating Recall on Z2.csv ---")
    if os.path.exists(Z_PATH):
        ground_truth = pd.read_csv(Z_PATH)
        truth_pairs = set(
            tuple(sorted(x))
            for x in ground_truth[["lid", "rid"]].to_records(index=False)
        )

        output_pairs = set(
            tuple(x) for x in output_df[["lid", "rid"]].to_records(index=False)
        )

        true_positives = len(truth_pairs.intersection(output_pairs))
        recall = true_positives / len(truth_pairs) if len(truth_pairs) > 0 else 0

        print(f"Total True Pairs in Ground Truth: {len(truth_pairs)}")
        print(f"True Positives Found in Output: {true_positives}")
        print(f"Validation Metric: {recall:.4f}")
    else:
        print("Ground truth file (Z2.csv) not found. Skipping evaluation.")
