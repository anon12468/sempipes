import pandas as pd
import re
from collections import defaultdict
import itertools
import os
import time


def main():
    """
    Main function to perform entity resolution blocking on the X2 dataset.
    """
    # --- Configuration ---
    DATA_DIR = "./input/"
    OUTPUT_DIR = "./working/"
    X_FILE = "X2.csv"
    Z_FILE = "Z2.csv"  # Ground truth for evaluation
    OUTPUT_FILE = "output.csv"
    TARGET_PAIRS = 2_000_000

    # --- Parameters for Blocking ---
    # For buckets smaller than this, we generate all pairs (O(k^2) but k is small)
    MAX_BUCKET_SIZE_FOR_ALL_PAIRS = 100
    # For larger buckets, we use sorted neighborhood with this window size
    WINDOW_SIZE_SORTED_NEIGHBORHOOD = 10

    # --- Helper Functions ---
    def normalize_text(text):
        """Lowercase, remove non-alphanumeric chars, and normalize whitespace."""
        if not isinstance(text, str):
            return ""
        text = text.lower()
        text = re.sub(r"[^\w\s]", " ", text)  # Replace punctuation with space
        text = re.sub(r"\s+", " ", text).strip()  # Normalize whitespace
        return text

    def get_tokens(text):
        """Split text into tokens and filter them."""
        tokens = text.split()
        # Keep tokens with length >= 3, not purely numeric
        return [token for token in tokens if len(token) >= 3 and not token.isdigit()]

    def evaluate(candidates_df, ground_truth_path):
        """Calculates recall of the generated candidates against the ground truth."""
        try:
            ground_truth_df = pd.read_csv(ground_truth_path)
        except FileNotFoundError:
            print(
                f"Ground truth file not found at {ground_truth_path}. Skipping evaluation."
            )
            return -1.0

        # Ensure lid < rid in ground truth for consistent comparison
        gt_swapped_mask = ground_truth_df["lid"] > ground_truth_df["rid"]
        ground_truth_df.loc[gt_swapped_mask, ["lid", "rid"]] = ground_truth_df.loc[
            gt_swapped_mask, ["rid", "lid"]
        ].values

        # Create sets for efficient lookup
        candidate_set = set(map(tuple, candidates_df[["lid", "rid"]].values))
        ground_truth_set = set(map(tuple, ground_truth_df[["lid", "rid"]].values))

        true_positives = len(candidate_set.intersection(ground_truth_set))
        total_positives = len(ground_truth_set)

        if total_positives == 0:
            return 0.0

        recall = true_positives / total_positives
        print(
            f"Found {true_positives} true matches out of {total_positives} in ground truth."
        )
        return recall

    # --- Main Logic ---
    start_time = time.time()

    # 1. Load Data
    print("Loading data...")
    df = pd.read_csv(os.path.join(DATA_DIR, X_FILE))
    print(f"Loaded {len(df)} records from {X_FILE}")

    # 2. Preprocessing
    print("Preprocessing text...")
    # Combine relevant text fields and handle NaNs
    df["brand"] = df["brand"].astype(str).fillna("")
    df["name"] = df["name"].astype(str).fillna("")
    df["text_to_block"] = df["brand"] + " " + df["name"]
    df["normalized_text"] = df["text_to_block"].apply(normalize_text)

    # Create a map from id to normalized text for the sorted neighborhood method
    id_to_text_map = df.set_index("id")["normalized_text"].to_dict()

    # 3. Build Inverted Index
    print("Building inverted index...")
    inverted_index = defaultdict(list)
    for doc_id, text in zip(df["id"], df["normalized_text"]):
        tokens = get_tokens(text)
        for token in tokens:
            inverted_index[token].append(doc_id)
    print(f"Inverted index created with {len(inverted_index)} unique tokens.")

    # 4. Candidate Generation
    print("Generating candidate pairs...")
    candidate_pairs = set()

    # Sort tokens by posting list size (ascending) to process rarer tokens first
    sorted_tokens = sorted(inverted_index.keys(), key=lambda t: len(inverted_index[t]))

    for i, token in enumerate(sorted_tokens):
        # Stop if we have enough candidates
        if len(candidate_pairs) >= TARGET_PAIRS:
            print(f"Target of {TARGET_PAIRS} pairs reached. Stopping generation.")
            break

        if (i + 1) % 20000 == 0:
            print(
                f"Processing token {i+1}/{len(sorted_tokens)}... Pairs generated: {len(candidate_pairs)}"
            )

        ids = sorted(list(set(inverted_index[token])))
        if len(ids) <= 1:
            continue

        if len(ids) <= MAX_BUCKET_SIZE_FOR_ALL_PAIRS:
            # For small buckets, generate all pairs
            for id1, id2 in itertools.combinations(ids, 2):
                candidate_pairs.add((id1, id2))
        else:
            # For large buckets, use sorted neighborhood to avoid O(k^2)
            # Sort IDs based on their full normalized text
            sorted_ids = sorted(ids, key=lambda doc_id: id_to_text_map.get(doc_id, ""))

            for j in range(len(sorted_ids)):
                # Compare with next few items in the sorted list (window)
                for k in range(
                    j + 1, min(j + 1 + WINDOW_SIZE_SORTED_NEIGHBORHOOD, len(sorted_ids))
                ):
                    id1, id2 = sorted_ids[j], sorted_ids[k]
                    # Ensure lid < rid
                    if id1 < id2:
                        candidate_pairs.add((id1, id2))
                    else:
                        candidate_pairs.add((id2, id1))

    print(f"Generated a total of {len(candidate_pairs)} unique pairs.")

    # 5. Finalize Output
    print("Finalizing output file...")
    # Convert set to list and truncate to the exact target number
    final_pairs_list = list(candidate_pairs)
    if len(final_pairs_list) > TARGET_PAIRS:
        print(f"Truncating from {len(final_pairs_list)} to {TARGET_PAIRS} pairs.")
        final_pairs_list = final_pairs_list[:TARGET_PAIRS]
    elif len(final_pairs_list) < TARGET_PAIRS:
        print(
            f"Warning: Generated {len(final_pairs_list)} pairs, which is less than the target {TARGET_PAIRS}."
        )
        # This might indicate that blocking parameters are too strict for the dataset.

    output_df = pd.DataFrame(final_pairs_list, columns=["lid", "rid"])
    # Ensure lid < rid, although generation logic should handle this.
    output_df = output_df.sort_values(["lid", "rid"]).reset_index(drop=True)

    # 6. Save Output
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    output_path = os.path.join(OUTPUT_DIR, "output.csv")
    # The problem asks for submission.csv, but the description says output.csv. Sticking to output.csv.
    # Re-reading: "Save output.csv under ./working/". Okay.
    output_df.to_csv(output_path, index=False)
    print(f"Successfully saved {len(output_df)} pairs to {output_path}")

    # 7. Evaluation
    print("\n--- Evaluation ---")
    recall = evaluate(output_df, os.path.join(DATA_DIR, Z_FILE))
    if recall != -1.0:
        print(f"Final Recall: {recall:.4f}")

    end_time = time.time()
    print(f"\nTotal execution time: {end_time - start_time:.2f} seconds")


if __name__ == "__main__":
    main()
