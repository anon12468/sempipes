import pandas as pd
from collections import defaultdict
import re
import time
import os

# --- Configuration ---
TARGET_PAIRS = 2_000_000
SAFEGUARD_BUCKET_SIZE = 20000  # Skip extremely large buckets to prevent slowdown

# --- Normalization and Feature Extraction ---


def normalize_text(text):
    """
    Improved normalization: Lowercase, replace some separators with spaces,
    and remove punctuation except for hyphens and periods crucial for model numbers.
    """
    if not isinstance(text, str):
        return ""
    text = text.lower()
    # Replace common separators and brackets with spaces to tokenize correctly
    text = re.sub(r"[,/()[\]]", " ", text)
    # Remove any character that is not a letter, a digit, a dot, a hyphen, or whitespace
    text = re.sub(r"[^a-z0-9\.\-\s]+", "", text)
    # Consolidate multiple spaces into one
    text = re.sub(r"\s+", " ", text).strip()
    return text


def extract_strong_features(text):
    """
    Extracts tokens that contain at least one digit, preserving hyphens and periods.
    This is effective for capturing model numbers like 'i7-8700k' or specs like '15.6'.
    Operates on text pre-processed by the improved normalize_text.
    """
    tokens = [
        token.strip(".-")
        for token in text.split()
        if any(char.isdigit() for char in token)
    ]
    # Filter out very short tokens which are likely to be noisy
    return [token for token in tokens if len(token) > 2]


# --- Core Blocking Logic ---


def add_pairs_from_index(index, df_dict, candidates, window_size, limit):
    """
    Generates candidate pairs from an inverted index using a sorted sliding window.
    This avoids O(k^2) complexity for a bucket of size k, making it O(k*log(k) + k*w).

    Args:
        index (dict): The inverted index {blocking_key: [id1, id2, ...]}.
        df_dict (dict): A dictionary mapping id to record data for fast lookups.
        candidates (set): The set of candidate pairs to add to.
        window_size (int): The number of subsequent items to pair with in the sorted list.
        limit (int): The target number of pairs to generate.

    Returns:
        bool: True if the pair limit has been reached, False otherwise.
    """
    # Process larger buckets first, as they are more likely to generate pairs
    sorted_items = sorted(index.items(), key=lambda item: len(item[1]), reverse=True)

    for _, ids in sorted_items:
        if not (1 < len(ids) < SAFEGUARD_BUCKET_SIZE):
            continue

        # Sort records within the bucket by a secondary key (normalized name).
        # This groups more similar items together, making the window more effective.
        try:
            sorted_records = sorted([(df_dict[id]["name_norm"], id) for id in ids])
            sorted_ids = [id for _, id in sorted_records]
        except KeyError:
            # Skip if an ID from the index is not in the records dict (should not happen in this script)
            continue

        for i in range(len(sorted_ids)):
            id1 = sorted_ids[i]
            # Create pairs with the next 'window_size' items in the sorted list
            for j in range(i + 1, min(i + 1 + window_size, len(sorted_ids))):
                id2 = sorted_ids[j]

                # Enforce pair ordering (lid < rid) for consistency
                pair = tuple(sorted((id1, id2)))
                candidates.add(pair)

                # Optimization: check limit inside the inner loop to terminate faster
                if len(candidates) >= limit:
                    return True

    return False


# --- Main Execution ---

if __name__ == "__main__":
    start_time = time.time()

    # --- Load and Preprocess Data ---
    print("Loading and preprocessing data...")
    file_path = "/Users/USER/Documents/UNI/SS26/SIGMOD_full_data/X2.csv"
    df = pd.read_csv(file_path, na_filter=False)

    for col in ["brand", "name", "description"]:
        df[col] = df[col].astype(str)

    # Apply normalization to name, brand, and description
    df["brand_norm"] = df["brand"].apply(normalize_text)
    df["name_norm"] = df["name"].apply(normalize_text)
    df["description_norm"] = df["description"].apply(normalize_text)

    # Create a dictionary for fast lookup of record data by ID
    df.set_index("id", inplace=True)
    records_dict = df.to_dict("index")

    candidate_pairs = set()

    # --- Define Blocking Passes ---
    # Passes are ordered from high-precision/low-yield to lower-precision/high-yield.
    passes = [
        {
            "name": "Model Numbers & Specs from Name + Description",
            "window": 50,
            "extractor": lambda r: extract_strong_features(
                r["name_norm"] + " " + r["description_norm"]
            ),
        },
        {
            # IMPROVEMENT: Replaced "Normalized Brand" pass with a more specific compound key
            "name": "Brand + First Name Token",
            "window": 30,  # Buckets are smaller and more relevant, so we can search them a bit deeper
            "extractor": lambda r: (
                [f"{r['brand_norm']}_{r['name_norm'].split()[0]}"]
                if r["brand_norm"] and r["name_norm"].split()
                else []
            ),
        },
        {
            "name": "First 2 Name Tokens",
            "window": 10,
            "extractor": lambda r: r["name_norm"].split()[:2],
        },
        {
            "name": "All Tokens from Name + Description",
            "window": 5,
            "extractor": lambda r: list(
                set(r["name_norm"].split() + r["description_norm"].split())
            ),
        },
    ]

    # Common stop words for product titles to reduce noise in token-based blocking
    stop_words = {
        "a",
        "an",
        "the",
        "and",
        "for",
        "with",
        "gb",
        "mb",
        "go",
        "tb",
        "in",
        "is",
        "it",
        "card",
        "memory",
        "of",
        "to",
        "new",
        "used",
        "pro",
        "plus",
        "ultra",
        "ram",
        "cpu",
        "hdd",
        "ssd",
    }

    # --- Execute Blocking Passes ---
    print("Starting blocking passes...")
    for p in passes:
        if len(candidate_pairs) >= TARGET_PAIRS:
            break

        print(f"Executing Pass: {p['name']}. Current pairs: {len(candidate_pairs)}")

        index = defaultdict(list)
        for doc_id, record in records_dict.items():
            keys = p["extractor"](record)
            for key in keys:
                # Add extra guards for key quality
                if key and len(key) > 2 and key not in stop_words and not key.isdigit():
                    index[key].append(doc_id)

        if add_pairs_from_index(
            index,
            records_dict,
            candidate_pairs,
            window_size=p["window"],
            limit=TARGET_PAIRS,
        ):
            print(f"Target of {TARGET_PAIRS} pairs reached during '{p['name']}' pass.")
            break

    # --- Fallback Pass to meet Target ---
    if len(candidate_pairs) < TARGET_PAIRS:
        print(
            f"Warning: Only {len(candidate_pairs)} pairs generated. Running fallback pass to reach {TARGET_PAIRS}."
        )
        fallback_index = defaultdict(list)
        for doc_id, record in records_dict.items():
            tokens = (record["name_norm"] + " " + record["description_norm"]).split()
            for token in tokens:
                if len(token) > 3 and token not in stop_words and not token.isdigit():
                    fallback_index[token].append(doc_id)
        add_pairs_from_index(
            fallback_index,
            records_dict,
            candidate_pairs,
            window_size=100,
            limit=TARGET_PAIRS,
        )

    # --- Finalize and Save Output ---
    print(f"\nTotal candidate pairs generated: {len(candidate_pairs)}")

    final_pairs = list(candidate_pairs)
    # Ensure we output exactly TARGET_PAIRS by sampling if we overshoot
    if len(final_pairs) > TARGET_PAIRS:
        # Instead of simple slicing, a more robust method might be sampling,
        # but for this competition slicing is deterministic and fast.
        output_df = pd.DataFrame(final_pairs[:TARGET_PAIRS], columns=["lid", "rid"])
    else:
        # If still under target, the problem is more severe and may require adding random pairs,
        # but the current strategy should be sufficient. We output what we have.
        print(f"Still under target. Outputting {len(final_pairs)} pairs.")
        output_df = pd.DataFrame(final_pairs, columns=["lid", "rid"])

    # Per task description, output MUST have 2M rows.
    # Add a final safeguard if we are still short (very unlikely with this strategy)
    if len(output_df) < TARGET_PAIRS:
        print(
            "Safeguard: padding with lexicographically adjacent pairs to meet target..."
        )
        shortfall = TARGET_PAIRS - len(output_df)
        existing_ids = set(df.index)

        sorted_ids = sorted(list(existing_ids))

        new_pairs = set()
        while len(new_pairs) < shortfall:
            for i in range(len(sorted_ids) - 1):
                p = tuple(sorted((sorted_ids[i], sorted_ids[i + 1])))
                if p not in candidate_pairs:
                    new_pairs.add(p)
                    if len(new_pairs) >= shortfall:
                        break

        padding_df = pd.DataFrame(list(new_pairs), columns=["lid", "rid"])
        output_df = pd.concat([output_df, padding_df], ignore_index=True)

    # Final truncate to ensure *exactly* 2M
    output_df = output_df.head(TARGET_PAIRS)

    # Ensure correct column order and type
    output_df["lid"] = pd.to_numeric(output_df["lid"])
    output_df["rid"] = pd.to_numeric(output_df["rid"])

    output_path = "./working/output.csv"
    output_df.to_csv(output_path, index=False)

    end_time = time.time()
    print(f"Finished writing {len(output_df)} pairs to {output_path}.")
    print(f"Total processing time: {end_time - start_time:.2f} seconds")

    # --- Evaluation (for development and validation) ---
    truth_file_path = "/Users/USER/Documents/UNI/SS26/SIGMOD_full_data/Z2.csv"
    if os.path.exists(truth_file_path):
        print("\n--- Evaluating Recall ---")
        truth_df = pd.read_csv(truth_file_path)

        truth_pairs = set()
        for _, row in truth_df.iterrows():
            truth_pairs.add(tuple(sorted((row.lid, row.rid))))

        output_pairs = set()
        for _, row in output_df.iterrows():
            output_pairs.add(tuple(sorted((row.lid, row.rid))))

        true_positives = len(truth_pairs.intersection(output_pairs))
        total_positives = len(truth_pairs)
        recall = true_positives / total_positives if total_positives > 0 else 0

        print(f"True positives found: {true_positives}")
        print(f"Total ground truth pairs: {total_positives}")
        print(f"Recall: {recall:.4f}")
    else:
        print("\nGround truth file (Z2.csv) not found, skipping evaluation.")
