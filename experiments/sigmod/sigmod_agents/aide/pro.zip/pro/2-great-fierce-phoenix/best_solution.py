import pandas as pd
import numpy as np
import re
from collections import defaultdict
import random
import time
from itertools import combinations
import heapq

# --- Configuration ---
# File paths
DATA_FILE = "/Users/USER/Documents/UNI/SS26/SIGMOD_full_data/X2.csv"
GROUND_TRUTH_FILE = "/Users/USER/Documents/UNI/SS26/SIGMOD_full_data/Z2.csv"
OUTPUT_FILE = "working/output.csv"

# LSH parameters
TARGET_PAIRS = 2_000_000
N_PERM = 128  # Number of hash functions for MinHash. b*r must equal this.
BANDS = 32  # Number of bands for LSH
ROWS = N_PERM // BANDS  # Rows per band
SHINGLE_K = 3  # Size of character k-grams (shingles)
SNM_WINDOW_SIZE = 10  # Window size for Sorted Neighborhood Method

# A large prime number for hash functions
HASH_PRIME = 4294967311
RANDOM_SEED = 42  # for reproducibility

# --- 1. Data Loading and Preprocessing ---


def clean_text(text):
    """Normalizes text for blocking."""
    if not isinstance(text, str):
        return ""
    text = text.lower()
    # Remove all non-alphanumeric characters but keep spaces
    text = re.sub(r"[^a-z0-9\s]+", " ", text)
    # Collapse multiple spaces and remove leading/trailing space
    text = re.sub(r"\s+", " ", text).strip()
    return text


def get_shingles(text, k):
    """Creates a set of character k-grams for a string."""
    if len(text) < k:
        return {text} if text else set()
    return {text[i : i + k] for i in range(len(text) - k + 1)}


# --- Main Execution Logic ---
if __name__ == "__main__":
    start_time = time.time()
    random.seed(RANDOM_SEED)
    np.random.seed(RANDOM_SEED)

    print(f"Loading data from {DATA_FILE}...")
    df = pd.read_csv(DATA_FILE)

    # --- Preprocessing and Shingling ---
    print("Preprocessing and creating shingles...")
    df["id"] = df["id"].astype(int)
    # Create a mapping from id to index for quick signature lookup later
    id_to_idx = {doc_id: i for i, doc_id in enumerate(df["id"])}

    # Combine relevant text fields
    df["text"] = (
        df["brand"].fillna("")
        + " "
        + df["name"].fillna("")
        + " "
        + df["description"].fillna("")
    )
    df["clean_text"] = df["text"].apply(clean_text)

    # Create a vocabulary of all shingles to map them to unique integer IDs
    shingle_vocab = {}
    next_shingle_id = 0
    df_shingles = []

    for text in df["clean_text"]:
        shingles = get_shingles(text, SHINGLE_K)
        doc_shingle_ids = set()
        for shingle in shingles:
            if shingle not in shingle_vocab:
                shingle_vocab[shingle] = next_shingle_id
                next_shingle_id += 1
            doc_shingle_ids.add(shingle_vocab[shingle])
        df_shingles.append(list(doc_shingle_ids))

    print(f"Created a vocabulary of {len(shingle_vocab)} unique shingles.")

    # --- MinHash Signature Calculation ---
    print(f"Computing {N_PERM} MinHash signatures for {len(df)} documents...")
    # Generate hash function parameters: (a, b) for h(x) = (a * x + b) % prime
    hash_params = np.random.randint(1, HASH_PRIME - 1, size=(N_PERM, 2))

    # This optimized approach computes signatures column-wise (per shingle)
    sig_matrix = np.full((len(df), N_PERM), np.inf, dtype=np.uint32)

    shingle_to_docs = defaultdict(list)
    for doc_idx, shingle_list in enumerate(df_shingles):
        for shingle_id in shingle_list:
            shingle_to_docs[shingle_id].append(doc_idx)

    # Calculate hashes for each shingle and update the signature matrix
    for shingle_id, doc_indices in shingle_to_docs.items():
        a = hash_params[:, 0]
        b = hash_params[:, 1]
        hash_vector = (a * shingle_id + b) % HASH_PRIME
        sig_matrix[doc_indices, :] = np.minimum(sig_matrix[doc_indices, :], hash_vector)

    # --- LSH Banding and Candidate Generation ---
    print(f"Applying LSH with {BANDS} bands and {ROWS} rows per band...")
    candidate_pairs = set()
    hash_bands = [defaultdict(list) for _ in range(BANDS)]
    doc_ids = df["id"].values

    for i, signature in enumerate(sig_matrix):
        doc_id = doc_ids[i]
        for band_idx in range(BANDS):
            start, end = band_idx * ROWS, (band_idx + 1) * ROWS
            # Create a hashable representation of the band
            band_data = signature[start:end].tobytes()
            hash_bands[band_idx][band_data].append(doc_id)

    print("Generating pairs from LSH buckets using Sorted Neighborhood Method...")
    for band_idx in range(BANDS):
        for bucket in hash_bands[band_idx].values():
            if len(bucket) > 1:
                # Sort the bucket to bring similar items together
                # Using IDs for sorting provides a consistent order.
                sorted_bucket = sorted(bucket)
                # Apply sliding window (Sorted Neighborhood Method)
                for i in range(len(sorted_bucket)):
                    window_end = i + 1 + SNM_WINDOW_SIZE
                    for j in range(i + 1, min(window_end, len(sorted_bucket))):
                        # Ensure lid < rid, which is guaranteed by sorting
                        candidate_pairs.add((sorted_bucket[i], sorted_bucket[j]))

    print(
        f"Generated a total of {len(candidate_pairs)} unique candidate pairs via LSH-SNM."
    )

    # --- Similarity Calculation and Top-K Selection ---
    final_pairs_list = []
    if len(candidate_pairs) > TARGET_PAIRS:
        print(
            f"Ranking {len(candidate_pairs)} pairs by similarity to select the best {TARGET_PAIRS}..."
        )

        # Use a min-heap to keep track of the top-K pairs with the highest similarity
        top_k_heap = []
        for id1, id2 in candidate_pairs:
            idx1 = id_to_idx[id1]
            idx2 = id_to_idx[id2]
            sig1 = sig_matrix[idx1, :]
            sig2 = sig_matrix[idx2, :]

            # Estimate Jaccard similarity from MinHash signatures
            jaccard_est = np.sum(sig1 == sig2) / N_PERM

            if len(top_k_heap) < TARGET_PAIRS:
                # Store (similarity, lid, rid)
                heapq.heappush(top_k_heap, (jaccard_est, id1, id2))
            else:
                # Push the new item, and pop the item with the smallest similarity
                heapq.heappushpop(top_k_heap, (jaccard_est, id1, id2))

        # Extract pairs from the heap
        final_pairs_list = [(lid, rid) for sim, lid, rid in top_k_heap]
    else:
        print(
            f"Warning: Generated {len(candidate_pairs)} pairs, fewer than target {TARGET_PAIRS}."
        )
        final_pairs_list = list(candidate_pairs)
        # Pad with random pairs if necessary (unlikely with SNM)
        if len(final_pairs_list) < TARGET_PAIRS:
            print("Padding with random pairs to meet the target...")
            num_needed = TARGET_PAIRS - len(final_pairs_list)
            existing_pairs = set(final_pairs_list)
            all_doc_ids = df["id"].tolist()
            while len(existing_pairs) < TARGET_PAIRS:
                p1, p2 = random.sample(all_doc_ids, 2)
                pair = tuple(sorted((p1, p2)))
                if pair not in existing_pairs:
                    existing_pairs.add(pair)
            final_pairs_list = list(existing_pairs)

    print(f"Saving {len(final_pairs_list)} pairs to {OUTPUT_FILE}...")
    output_df = pd.DataFrame(final_pairs_list, columns=["lid", "rid"])
    # Truncate just in case of any overages from padding logic
    output_df = output_df.head(TARGET_PAIRS)
    output_df.to_csv(OUTPUT_FILE, index=False)

    total_time = time.time() - start_time
    print(f"Total processing time: {total_time:.2f} seconds.")

    # --- Evaluation ---
    print("\n--- Evaluation ---")
    try:
        ground_truth_df = pd.read_csv(GROUND_TRUTH_FILE)
        true_pairs = set(
            zip(
                np.minimum(ground_truth_df["lid"], ground_truth_df["rid"]),
                np.maximum(ground_truth_df["lid"], ground_truth_df["rid"]),
            )
        )

        total_true_positives = len(true_pairs)
        output_pairs = set(map(tuple, output_df.values))
        true_positives_found = len(output_pairs.intersection(true_pairs))

        recall = (
            true_positives_found / total_true_positives
            if total_true_positives > 0
            else 0
        )

        print(f"Total True Matches in Ground Truth: {total_true_positives}")
        print(f"Matches Found in Output: {true_positives_found}")
        print(f"Recall: {recall:.4f}")

    except FileNotFoundError:
        print(
            f"Ground truth file not found at {GROUND_TRUTH_FILE}. Skipping evaluation."
        )
    except Exception as e:
        print(f"An error occurred during evaluation: {e}")
