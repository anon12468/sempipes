# Technical Report: Scalable Blocking for Product Entity Resolution

## Introduction

This report summarises the empirical research conducted to develop a scalable blocking algorithm for entity resolution on a large dataset of electronic products. The primary goal was to generate a fixed-size candidate set of exactly 2,000,000 pairs while maximising recall. A critical constraint was algorithmic feasibility, strictly prohibiting any process with quadratic complexity relative to the size of a blocking bucket to ensure performance on a dataset of approximately two million records. The research iterated through several designs, primarily revolving around Locality Sensitive Hashing (LSH) and multi-pass standard blocking, with a focus on addressing performance bottlenecks and scalability flaws.

## Preprocessing

Initial data preparation involved standard text normalisation, including lowercasing, removing punctuation, and collapsing whitespace. This baseline was applied to a concatenated field of product `brand`, `name`, and `description`. Two distinct, more advanced feature engineering paths were explored to represent the product information for blocking.

### Shingling for LSH
For methods based on Jaccard similarity, product text was converted into a set of 3-character shingles (n-grams). This technique provides robustness against minor variations like typos and word order differences, which is crucial for matching product titles.

### Domain-Specific Feature Extraction
For standard blocking methods, a domain-aware approach was developed. This involved extracting specific, high-signal features from product text using curated dictionaries and regular expressions. Key extracted features included:
- **Brand:** `sandisk`, `kingston`, etc.
- **Capacity:** `16gb`, `256gb`, etc.
- **Series:** `ultra`, `extreme`, `pro`, etc.
- **Type:** `sdhc`, `usb`, `microsd`, etc.
- **Model Words:** Alphanumeric tokens likely representing model numbers.

This structured feature extraction allowed for the creation of precise, multi-part blocking keys.

## Modelling Methods

The core of the research involved developing and refining scalable blocking strategies. The evolution of the methods focused on improving both recall and computational feasibility.

### Locality Sensitive Hashing (LSH) with MinHash

The most successful approach was based on LSH, an algorithm that approximates Jaccard similarity efficiently.
1.  **Signature Generation:** Each product's shingle set was converted into a compact MinHash signature (128 hash functions). This signature preserves similarity information in a fixed-size vector.
2.  **Candidate Grouping:** LSH's banding technique was applied to the signature matrix. Signatures that hashed to the same bucket in at least one band were considered candidate pairs. This avoids an all-pairs comparison, reducing complexity significantly.
3.  **Scalable Pair Generation:** A critical flaw identified in early attempts was the use of `itertools.combinations` to generate all pairs within an LSH bucket, an O(k²) operation. This was replaced by the **Sorted Neighborhood Method (SNM)**. Items within each bucket were sorted lexically, and pairs were generated only within a small, fixed-size sliding window. This guarantees linear time complexity (O(k * window_size)) and ensures feasibility even for very large buckets.

### Multi-Pass Standard Blocking

An alternative strategy used an inverted index built on the domain-specific features extracted during preprocessing. This method proceeded in stages, from high-precision to high-recall blocking keys:
1.  **Stage 1 (High Precision):** Block on composite keys like (`brand`, `capacity`, `series`).
2.  **Stage 2 (Medium Precision):** Block on keys like (`brand`, `capacity`).
3.  **Stage 3 (High Recall):** Block on broader keys like `brand` or important type words.

Like the LSH approach, SNM was essential within each bucket to manage computational complexity. The process terminated as soon as the 2,000,000 pair target was met.

### Top-K Candidate Selection

Generating candidates often produced more than the required 2,000,000 pairs.
- **Initial Method (Random Sampling):** The first implementation randomly sampled the final set. This was fast but suboptimal, as it discarded high-similarity pairs as readily as low-similarity ones.
- **Refined Method (Similarity Ranking):** A significant improvement involved ranking all generated candidates by their estimated Jaccard similarity (calculated directly from their MinHash signatures) and selecting the top 2,000,000.
- **Final Method (Streaming Selection):** The ranking method, while effective, was memory-intensive as it required materializing the entire candidate set. The most advanced and scalable solution integrated pair generation, scoring, and selection. As each pair was generated via LSH and SNM, its similarity was calculated and the pair was considered for insertion into a fixed-size min-heap. This maintained a running list of the top-K candidates in constant memory, fully adhering to the feasibility constraints.

## Results Discussion

The iterative development process led to significant improvements in recall. The LSH-based methods consistently outperformed the multi-pass standard blocking strategy.

| Method | Key Features | Recall |
| :--- | :--- | :--- |
| Standard Blocking | Multi-pass, SNM | 0.8704 |
| LSH + SNM | Random Sampling to 2M | 0.9135 |
| LSH + SNM | Similarity Ranking (Heap) | 0.9284 |
| **LSH + SNM** | **Streaming Selection (Heap)** | **0.9678** |

The final model, combining LSH, the Sorted Neighborhood Method, and a streaming top-K selection with a min-heap, achieved the highest recall of **0.9678**. This design proved superior because it effectively balanced the comprehensive candidate generation of LSH with the strict scalability requirements of the task. The integration of SNM was the pivotal decision for ensuring feasibility, while the streaming similarity ranking was key to maximizing the quality (and thus recall) of the final candidate set within memory constraints.

## Future Work

While the final model is highly effective, several avenues for further improvement exist:
- **Hybrid Blocking:** A hybrid approach could use the high-precision domain keys from the standard blocking method to generate an initial set of high-confidence candidates, then use LSH to find additional, less obvious matches to fill the remaining quota.
- **Advanced Parameter Tuning:** A systematic grid search on LSH parameters (number of bands, rows per band) and SNM window size could further optimize the trade-off between the number of candidates generated and their average quality.
- **Adaptive Blocking:** The algorithm could be made adaptive, dynamically adjusting the SNM window size or moving to broader blocking keys based on the number of candidate pairs generated so far, ensuring a more efficient path to the 2,000,000 pair target.